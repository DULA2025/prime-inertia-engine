# Summary of changes for run 437b2859-9453-41f3-8c81-30036d96c1df
Gauss' integral representation of the digamma function is now fully formalized and proved in Lean, with no `sorry` and no extra axioms (only `propext`, `Classical.choice`, `Quot.sound`).

All work is in `RequestProject/Digamma.lean` (builds cleanly with `lake build RequestProject.Digamma`).

**Main result** — `Real.digamma_eq_gauss_integral`: for every real `x > 0`,
ψ(x) = ∫_{(0,∞)} ( e^{-t}/t − e^{-xt}/(1−e^{-t}) ) dt,
stated exactly as requested.

**Definition added.** The library only provides the complex digamma function, so the real one is introduced here as `Real.digamma := logDeriv Real.Gamma`, i.e. `deriv Γ x / Γ x`. To confirm this is the standard function, `Complex.digamma_ofReal` shows it agrees with the complex digamma function on the positive reals.

**Structure of the proof.**
- Frullani's integral for the exponential (`Real.frullani_exp`): for `a, b > 0`, ∫_0^∞ (e^{-at} − e^{-bt})/t dt = log b − log a, proved by writing the integrand as an inner integral of `e^{-st}` over `s ∈ [a,b]` and exchanging the order of integration (with the required product-integrability established separately).
- Splitting the Gauss integrand as `(e^{-t} − e^{-xt})/t + e^{-xt}(1/t − 1/(1−e^{-t}))` gives integrability on `(0,∞)` and the estimate `|F(x) − log x| ≤ 1/x`, using the elementary bounds `0 ≤ 1/(1−e^{-t}) − 1/t ≤ 1`.
- The integral satisfies `F(x+1) = F(x) + 1/x`, while the digamma function satisfies the same recurrence, and convexity of `log ∘ Γ` yields `log(x−1) ≤ ψ(x) ≤ log x`, hence `|ψ(x) − log x| ≤ 1/(x−1)`.
- Shifting by integers, the difference ψ − F is invariant and bounded by a sequence tending to 0, so it vanishes identically.

Several supporting statements of independent interest are proved along the way (Frullani's integral, the recurrence and logarithmic bounds for the real digamma function, integrability of the Gauss integrand).