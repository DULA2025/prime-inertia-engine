/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: [DULA], Aristotle (Harmonic), Grok 4.5
-/

import Mathlib

/-!
# Gauss' integral representation of the digamma function

This file proves the classical integral formula of Gauss

$$\psi(x) \;=\; \int_0^\infty \Bigl(\frac{e^{-t}}{t} \;-\; \frac{e^{-x t}}{1 - e^{-t}}\Bigr)\, dt ,
\qquad x > 0 . $$

## Main statements

* `Real.digamma_eq_gauss_integral`:
  `∀ x > 0, Real.digamma x =
    ∫ t in Set.Ioi (0:ℝ), (Real.exp (-t) / t - Real.exp (-x*t) / (1 - Real.exp (-t)))`

## References

* Gauss, *Disquisitiones generales circa seriem infinitam*, 1813.
* Whittaker & Watson, *A Course of Modern Analysis*, §12.3.

-/

namespace Real

open Set MeasureTheory intervalIntegral Filter Topology

/-- The digamma function on the reals: the logarithmic derivative of `Real.Gamma`. -/
noncomputable def digamma : ℝ → ℝ := logDeriv Gamma

lemma digamma_apply (x : ℝ) : digamma x = deriv Gamma x / Gamma x := rfl

/-! ### Elementary estimates -/

lemma one_sub_exp_neg_le {t : ℝ} : 1 - exp (-t) ≤ t := by
  nlinarith [add_one_le_exp (-t)]

lemma one_sub_exp_neg_pos {t : ℝ} (ht : 0 < t) : 0 < 1 - exp (-t) := by
  have : exp (-t) < 1 := by
    rw [exp_lt_one_iff]; linarith
  linarith

/-- For `t > 0`, `0 ≤ 1/(1 - e^{-t}) - 1/t ≤ 1`. -/
lemma inv_one_sub_exp_neg_sub_inv_nonneg {t : ℝ} (ht : 0 < t) :
    0 ≤ 1 / (1 - exp (-t)) - 1 / t := by
  have h1 : 0 < 1 - exp (-t) := one_sub_exp_neg_pos ht
  rw [sub_nonneg]
  exact one_div_le_one_div_of_le h1 one_sub_exp_neg_le

lemma inv_one_sub_exp_neg_sub_inv_le_one {t : ℝ} (ht : 0 < t) :
    1 / (1 - exp (-t)) - 1 / t ≤ 1 := by
  have h1 : 0 < 1 - exp (-t) := one_sub_exp_neg_pos ht
  rw [sub_le_iff_le_add, div_le_iff₀ h1]
  have h2 : (1 + t) * exp (-t) ≤ 1 := by
    have := add_one_le_exp t
    have hpos : (0:ℝ) < exp t := exp_pos t
    rw [exp_neg]
    rw [mul_inv_le_iff₀ hpos]
    linarith [add_one_le_exp t]
  have ht' : t ≠ 0 := ht.ne'
  field_simp
  nlinarith [exp_pos (-t)]

/-! ### Frullani's integral for the exponential function -/

lemma integral_exp_neg_mul_Ioi_zero {c : ℝ} (hc : 0 < c) :
    ∫ t in Ioi (0:ℝ), exp (-(c * t)) = 1 / c := by
  have := integral_exp_mul_Ioi (a := -c) (by linarith) 0
  simpa [neg_mul] using this

lemma integrableOn_exp_neg_mul {c : ℝ} (hc : 0 < c) :
    IntegrableOn (fun t : ℝ => exp (-(c * t))) (Ioi 0) := by
  simpa [neg_mul] using integrableOn_exp_mul_Ioi (a := -c) (by linarith) 0

/-- Integrability of `(s, t) ↦ e^{-st}` on `uIoc a b ×ˢ Ioi 0`. -/
lemma integrable_uncurry_exp_neg_mul {a b : ℝ} (ha : 0 < a) (hab : a ≤ b) :
    Integrable (Function.uncurry (fun s t : ℝ => exp (-(s * t))))
      ((volume.restrict (uIoc a b)).prod (volume.restrict (Ioi 0))) := by
  have hconst : Integrable (fun _ : ℝ => (1:ℝ)) (volume.restrict (uIoc a b)) := by
    refine integrableOn_const (C := (1:ℝ)) ?_
    rw [uIoc_of_le hab]
    exact measure_Ioc_lt_top.ne
  have hdom : Integrable (fun z : ℝ × ℝ => (1:ℝ) * exp (-(a * z.2)))
      ((volume.restrict (uIoc a b)).prod (volume.restrict (Ioi 0))) :=
    hconst.mul_prod (integrableOn_exp_neg_mul ha)
  rw [Measure.prod_restrict] at hdom ⊢
  refine hdom.mono' (Continuous.aestronglyMeasurable (by fun_prop)) ?_
  filter_upwards [ae_restrict_mem (measurableSet_uIoc.prod measurableSet_Ioi)] with z hz
  obtain ⟨hz1, hz2⟩ := hz
  rw [uIoc_of_le hab] at hz1
  have hs : a ≤ z.1 := hz1.1.le
  have ht : (0:ℝ) < z.2 := hz2
  have hz3 : ‖Function.uncurry (fun s t : ℝ => exp (-(s * t))) z‖ = exp (-(z.1 * z.2)) := by
    simp [Function.uncurry, norm_eq_abs, abs_exp]
  rw [hz3, one_mul]
  exact exp_le_exp.mpr (by nlinarith)

lemma integral_exp_neg_mul_interval {t : ℝ} (ht : 0 < t) (a b : ℝ) :
    ∫ s in a..b, exp (-(s * t)) = (exp (-(a * t)) - exp (-(b * t))) / t := by
  have hderiv : ∀ s ∈ uIcc a b,
      HasDerivAt (fun s : ℝ => -exp (-(s * t)) / t) (exp (-(s * t))) s := by
    intro s _
    have h1 : HasDerivAt (fun s : ℝ => -(s * t)) (-t) s := by
      simpa using ((hasDerivAt_id s).mul_const t).neg
    have h2 := (h1.exp.neg).div_const t
    refine h2.congr_deriv ?_
    field_simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hderiv
    ((Continuous.intervalIntegrable (by fun_prop) a b))]
  field_simp
  ring

lemma frullani_exp_aux {a b : ℝ} (ha : 0 < a) (hab : a ≤ b) :
    ∫ t in Ioi (0:ℝ), (exp (-(a * t)) - exp (-(b * t))) / t = log b - log a := by
  have hswap := intervalIntegral_integral_swap (a := a) (b := b)
    (f := fun s t : ℝ => exp (-(s * t))) (μ := volume.restrict (Ioi (0:ℝ)))
    (integrable_uncurry_exp_neg_mul ha hab)
  have hleft : ∫ s in a..b, (∫ t in Ioi (0:ℝ), exp (-(s * t))) = log b - log a := by
    have hcongr : ∀ s ∈ uIcc a b, (∫ t in Ioi (0:ℝ), exp (-(s * t))) = 1 / s := by
      intro s hs
      rw [uIcc_of_le hab] at hs
      exact integral_exp_neg_mul_Ioi_zero (lt_of_lt_of_le ha hs.1)
    rw [intervalIntegral.integral_congr hcongr, integral_one_div, log_div (by linarith) ha.ne']
    rw [uIcc_of_le hab]
    exact fun h => absurd h.1 (not_le.mpr ha)
  have hright : (∫ t in Ioi (0:ℝ), ∫ s in a..b, exp (-(s * t)))
      = ∫ t in Ioi (0:ℝ), (exp (-(a * t)) - exp (-(b * t))) / t := by
    refine setIntegral_congr_fun measurableSet_Ioi ?_
    intro t ht
    exact integral_exp_neg_mul_interval ht a b
  rw [← hright, ← hswap, hleft]

lemma frullani_integrableOn_aux {a b : ℝ} (ha : 0 < a) (hab : a ≤ b) :
    IntegrableOn (fun t => (exp (-(a * t)) - exp (-(b * t))) / t) (Ioi 0) := by
  have h : Integrable (fun t : ℝ => ∫ s in uIoc a b, exp (-(s * t)))
      (volume.restrict (Ioi 0)) :=
    (integrable_uncurry_exp_neg_mul ha hab).integral_prod_right
  refine h.congr ?_
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  have h2 : (∫ s in uIoc a b, exp (-(s * t))) = ∫ s in a..b, exp (-(s * t)) := by
    rw [intervalIntegral.integral_of_le hab, uIoc_of_le hab]
  rw [h2, integral_exp_neg_mul_interval ht a b]

/-- **Frullani's integral** for the exponential function. -/
lemma frullani_exp {a b : ℝ} (ha : 0 < a) (hb : 0 < b) :
    ∫ t in Ioi (0:ℝ), (exp (-(a * t)) - exp (-(b * t))) / t = log b - log a := by
  rcases le_total a b with hab | hba
  · exact frullani_exp_aux ha hab
  · have h := frullani_exp_aux hb hba
    have : ∀ t : ℝ, (exp (-(a * t)) - exp (-(b * t))) / t
        = -((exp (-(b * t)) - exp (-(a * t))) / t) := by
      intro t; ring
    simp_rw [this]
    rw [MeasureTheory.integral_neg, h]
    ring

lemma frullani_integrableOn {a b : ℝ} (ha : 0 < a) (hb : 0 < b) :
    IntegrableOn (fun t => (exp (-(a * t)) - exp (-(b * t))) / t) (Ioi 0) := by
  rcases le_total a b with hab | hba
  · exact frullani_integrableOn_aux ha hab
  · have h := (frullani_integrableOn_aux hb hba).neg
    refine h.congr (Filter.Eventually.of_forall ?_)
    intro t
    simp only [Pi.neg_apply]
    ring

/-! ### The Gauss integral -/

/-- The right-hand side of Gauss' formula. -/
noncomputable def gaussIntegral (x : ℝ) : ℝ :=
  ∫ t in Ioi (0:ℝ), (exp (-t) / t - exp (-x * t) / (1 - exp (-t)))

/-- The remainder term `e^{-xt} (1/t - 1/(1 - e^{-t}))`. -/
noncomputable def gaussRemainder (x t : ℝ) : ℝ :=
  exp (-x * t) * (1 / t - 1 / (1 - exp (-t)))

lemma abs_gaussRemainder_le {x t : ℝ} (ht : 0 < t) :
    |gaussRemainder x t| ≤ exp (-x * t) := by
  have h1 : 0 ≤ 1 / (1 - exp (-t)) - 1 / t := inv_one_sub_exp_neg_sub_inv_nonneg ht
  have h2 : 1 / (1 - exp (-t)) - 1 / t ≤ 1 := inv_one_sub_exp_neg_sub_inv_le_one ht
  have habs : |1 / t - 1 / (1 - exp (-t))| ≤ 1 := by
    rw [abs_le]; constructor <;> linarith
  rw [gaussRemainder, abs_mul, abs_of_pos (exp_pos _)]
  calc exp (-x * t) * |1 / t - 1 / (1 - exp (-t))|
      ≤ exp (-x * t) * 1 := mul_le_mul_of_nonneg_left habs (exp_pos _).le
    _ = exp (-x * t) := mul_one _

lemma continuousOn_gaussRemainder (x : ℝ) : ContinuousOn (gaussRemainder x) (Ioi 0) := by
  intro t ht
  have ht' : (0:ℝ) < t := ht
  have h1 : (1 : ℝ) - exp (-t) ≠ 0 := (one_sub_exp_neg_pos ht').ne'
  apply ContinuousAt.continuousWithinAt
  unfold gaussRemainder
  fun_prop (disch := first | exact ht'.ne' | exact h1)

lemma integrableOn_gaussRemainder {x : ℝ} (hx : 0 < x) :
    IntegrableOn (gaussRemainder x) (Ioi 0) := by
  have hdom : IntegrableOn (fun t : ℝ => exp (-(x * t))) (Ioi 0) := integrableOn_exp_neg_mul hx
  refine hdom.mono' ((continuousOn_gaussRemainder x).aestronglyMeasurable measurableSet_Ioi) ?_
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  rw [norm_eq_abs, ← neg_mul]
  exact abs_gaussRemainder_le ht

lemma gaussIntegrand_eq {x t : ℝ} (ht : 0 < t) :
    exp (-t) / t - exp (-x * t) / (1 - exp (-t))
      = (exp (-(1 * t)) - exp (-(x * t))) / t + gaussRemainder x t := by
  have h1 : (1 : ℝ) - exp (-t) ≠ 0 := (one_sub_exp_neg_pos ht).ne'
  rw [gaussRemainder, one_mul, neg_mul]
  field_simp
  ring

lemma integrableOn_gaussIntegrand {x : ℝ} (hx : 0 < x) :
    IntegrableOn (fun t => exp (-t) / t - exp (-x * t) / (1 - exp (-t))) (Ioi 0) := by
  have h1 : IntegrableOn (fun t => (exp (-(1 * t)) - exp (-(x * t))) / t) (Ioi 0) :=
    frullani_integrableOn one_pos hx
  have h2 := integrableOn_gaussRemainder hx
  refine (h1.add h2).congr ?_
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact (gaussIntegrand_eq ht).symm

lemma gaussIntegral_eq_log_add {x : ℝ} (hx : 0 < x) :
    gaussIntegral x = log x + ∫ t in Ioi (0:ℝ), gaussRemainder x t := by
  have h1 : IntegrableOn (fun t => (exp (-(1 * t)) - exp (-(x * t))) / t) (Ioi 0) :=
    frullani_integrableOn one_pos hx
  have h2 := integrableOn_gaussRemainder hx
  have hcongr : gaussIntegral x
      = ∫ t in Ioi (0:ℝ), ((exp (-(1 * t)) - exp (-(x * t))) / t + gaussRemainder x t) := by
    refine setIntegral_congr_fun measurableSet_Ioi ?_
    intro t ht
    exact gaussIntegrand_eq ht
  rw [hcongr, integral_add h1 h2, frullani_exp one_pos hx, log_one, sub_zero]

lemma abs_gaussIntegral_sub_log_le {x : ℝ} (hx : 0 < x) :
    |gaussIntegral x - log x| ≤ 1 / x := by
  rw [gaussIntegral_eq_log_add hx, add_sub_cancel_left]
  have h2 := integrableOn_gaussRemainder hx
  have hdom : IntegrableOn (fun t : ℝ => exp (-(x * t))) (Ioi 0) := integrableOn_exp_neg_mul hx
  calc |∫ t in Ioi (0:ℝ), gaussRemainder x t|
      ≤ ∫ t in Ioi (0:ℝ), |gaussRemainder x t| := by
        simpa [norm_eq_abs] using
          MeasureTheory.norm_integral_le_integral_norm (μ := volume.restrict (Ioi (0:ℝ)))
            (gaussRemainder x)
    _ ≤ ∫ t in Ioi (0:ℝ), exp (-(x * t)) := by
        refine integral_mono_ae h2.abs hdom ?_
        filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
        have ht' : (0:ℝ) < t := ht
        simpa [← neg_mul] using abs_gaussRemainder_le (x := x) ht'
    _ = 1 / x := integral_exp_neg_mul_Ioi_zero hx

lemma gaussIntegral_add_one {x : ℝ} (hx : 0 < x) :
    gaussIntegral (x + 1) = gaussIntegral x + 1 / x := by
  have hx1 : (0:ℝ) < x + 1 := by linarith
  have h1 := integrableOn_gaussIntegrand hx
  have h2 := integrableOn_gaussIntegrand hx1
  have hdiff : gaussIntegral x - gaussIntegral (x + 1) = -(1 / x) := by
    rw [gaussIntegral, gaussIntegral, ← integral_sub h1 h2]
    have hcongr : ∀ t ∈ Ioi (0:ℝ),
        (exp (-t) / t - exp (-x * t) / (1 - exp (-t)))
          - (exp (-t) / t - exp (-(x + 1) * t) / (1 - exp (-t))) = -exp (-(x * t)) := by
      intro t ht
      have ht' : (0:ℝ) < t := ht
      have h1' : (1 : ℝ) - exp (-t) ≠ 0 := (one_sub_exp_neg_pos ht').ne'
      have hsplit : exp (-(x + 1) * t) = exp (-(x * t)) * exp (-t) := by
        rw [← exp_add]; ring_nf
      have hxt : exp (-x * t) = exp (-(x * t)) := by rw [neg_mul]
      rw [hsplit, hxt]
      field_simp
      ring
    rw [setIntegral_congr_fun measurableSet_Ioi hcongr]
    rw [MeasureTheory.integral_neg, integral_exp_neg_mul_Ioi_zero hx]
  linarith

/-! ### Basic properties of the digamma function -/

lemma differentiableAt_Gamma_of_pos {x : ℝ} (hx : 0 < x) : DifferentiableAt ℝ Gamma x :=
  differentiableAt_Gamma fun m => by
    have : (0:ℝ) ≤ (m : ℝ) := Nat.cast_nonneg m
    intro h
    rw [h] at hx
    linarith

lemma differentiableAt_log_Gamma {x : ℝ} (hx : 0 < x) : DifferentiableAt ℝ (log ∘ Gamma) x :=
  (differentiableAt_Gamma_of_pos hx).log (Gamma_pos_of_pos hx).ne'

lemma log_Gamma_add_one {x : ℝ} (hx : 0 < x) :
    (log ∘ Gamma) (x + 1) = (log ∘ Gamma) x + log x := by
  simp only [Function.comp_apply, Gamma_add_one hx.ne',
    log_mul hx.ne' (Gamma_pos_of_pos hx).ne', add_comm]

lemma digamma_eq_deriv_log_Gamma {x : ℝ} (hx : 0 < x) :
    digamma x = deriv (log ∘ Gamma) x := by
  rw [digamma_apply, Function.comp_def,
    deriv.log (differentiableAt_Gamma_of_pos hx) (Gamma_pos_of_pos hx).ne']

lemma digamma_add_one {x : ℝ} (hx : 0 < x) : digamma (x + 1) = digamma x + 1 / x := by
  rw [digamma_eq_deriv_log_Gamma hx, digamma_eq_deriv_log_Gamma (by linarith : (0:ℝ) < x + 1)]
  rw [← deriv_comp_add_const, one_div, ← deriv_log,
    ← deriv_add (differentiableAt_log_Gamma hx) (differentiableAt_log hx.ne')]
  apply EventuallyEq.deriv_eq
  filter_upwards [eventually_gt_nhds hx] with y hy using log_Gamma_add_one hy

lemma digamma_le_log {x : ℝ} (hx : 0 < x) : digamma x ≤ log x := by
  have hslope : slope (log ∘ Gamma) x (x + 1) = log x := by
    rw [slope_def_field, log_Gamma_add_one hx]
    field_simp
    ring
  rw [digamma_eq_deriv_log_Gamma hx, ← hslope]
  exact convexOn_log_Gamma.deriv_le_slope (mem_Ioi.mpr hx) (mem_Ioi.mpr (by linarith))
    (by linarith) (differentiableAt_log_Gamma hx)

lemma log_le_digamma {x : ℝ} (hx : 1 < x) : log (x - 1) ≤ digamma x := by
  have hx0 : 0 < x - 1 := by linarith
  have hslope : slope (log ∘ Gamma) (x - 1) x = log (x - 1) := by
    have h : (log ∘ Gamma) x = (log ∘ Gamma) (x - 1) + log (x - 1) := by
      have := log_Gamma_add_one hx0
      rwa [sub_add_cancel] at this
    rw [slope_def_field, h]
    field_simp
    ring
  rw [digamma_eq_deriv_log_Gamma (by linarith : (0:ℝ) < x), ← hslope]
  exact convexOn_log_Gamma.slope_le_deriv (mem_Ioi.mpr hx0) (mem_Ioi.mpr (by linarith))
    (by linarith) (differentiableAt_log_Gamma (by linarith))

/-! ### Main theorem -/

lemma digamma_add_nat {x : ℝ} (hx : 0 < x) (n : ℕ) :
    digamma (x + n) = digamma x + ∑ k ∈ Finset.range n, 1 / (x + k) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hxn : 0 < x + n := by positivity
    have : x + ((n : ℝ) + 1) = (x + n) + 1 := by ring
    push_cast
    rw [this, digamma_add_one hxn, ih, Finset.sum_range_succ]
    ring

lemma gaussIntegral_add_nat {x : ℝ} (hx : 0 < x) (n : ℕ) :
    gaussIntegral (x + n) = gaussIntegral x + ∑ k ∈ Finset.range n, 1 / (x + k) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hxn : 0 < x + n := by positivity
    have hstep : x + ((n : ℝ) + 1) = (x + n) + 1 := by ring
    push_cast
    rw [hstep, gaussIntegral_add_one hxn, ih, Finset.sum_range_succ]
    ring

lemma abs_digamma_sub_log_le {y : ℝ} (hy : 1 < y) : |digamma y - log y| ≤ 1 / (y - 1) := by
  have h0 : 0 < y - 1 := by linarith
  have hup : digamma y ≤ log y := digamma_le_log (by linarith)
  have hlow : log (y - 1) ≤ digamma y := log_le_digamma hy
  have hlog : log y - log (y - 1) ≤ 1 / (y - 1) := by
    have : log y - log (y - 1) = log (y / (y - 1)) := (log_div (by linarith) h0.ne').symm
    rw [this]
    have := log_le_sub_one_of_pos (x := y / (y - 1)) (by positivity)
    have hcalc : y / (y - 1) - 1 = 1 / (y - 1) := by field_simp; ring
    linarith [this, hcalc]
  rw [abs_le]
  constructor <;> [linarith; linarith [one_div_pos.mpr h0]]

/-- **Gauss' integral representation of the digamma function.**

For every real `x > 0`,
$$\psi(x)=\int_0^{\infty}\Bigl(\frac{e^{-t}}{t}-\frac{e^{-xt}}{1-e^{-t}}\Bigr)dt .$$
-/
theorem digamma_eq_gauss_integral (x : ℝ) (hx : 0 < x) :
    digamma x =
      ∫ t in Ioi (0 : ℝ),
        (Real.exp (-t) / t - Real.exp (-x * t) / (1 - Real.exp (-t))) := by
  show digamma x = gaussIntegral x
  set G := digamma x - gaussIntegral x with hG
  -- `G` is unchanged by integer shifts
  have hshift : ∀ n : ℕ, digamma (x + n) - gaussIntegral (x + n) = G := by
    intro n
    rw [digamma_add_nat hx n, gaussIntegral_add_nat hx n, hG]
    ring
  -- bound `|G|` by a null sequence
  have hbound : ∀ n : ℕ, 1 < x + n → |G| ≤ 1 / (x + n - 1) + 1 / (x + n) := by
    intro n hn
    rw [← hshift n]
    calc |digamma (x + n) - gaussIntegral (x + n)|
        ≤ |digamma (x + n) - log (x + n)| + |gaussIntegral (x + n) - log (x + n)| := by
          have : digamma (x + n) - gaussIntegral (x + n)
              = (digamma (x + n) - log (x + n)) - (gaussIntegral (x + n) - log (x + n)) := by ring
          rw [this]
          exact abs_sub _ _
      _ ≤ 1 / (x + n - 1) + 1 / (x + n) := by
          gcongr
          · exact abs_digamma_sub_log_le hn
          · exact abs_gaussIntegral_sub_log_le (by linarith)
  have htend : Tendsto (fun n : ℕ => 1 / (x + n - 1) + 1 / (x + n)) atTop (𝓝 0) := by
    have h1 : Tendsto (fun n : ℕ => x + (n : ℝ) - 1) atTop atTop := by
      apply Filter.tendsto_atTop_add_const_right
      exact Filter.tendsto_atTop_add_const_left _ _ tendsto_natCast_atTop_atTop
    have h2 : Tendsto (fun n : ℕ => x + (n : ℝ)) atTop atTop :=
      Filter.tendsto_atTop_add_const_left _ _ tendsto_natCast_atTop_atTop
    simpa using (h1.inv_tendsto_atTop).add (h2.inv_tendsto_atTop)
  have hG0 : |G| ≤ 0 := by
    refine ge_of_tendsto htend ?_
    filter_upwards [eventually_gt_atTop (Nat.ceil (2 - x))] with n hn
    refine hbound n ?_
    have : (2 - x) ≤ n := le_trans (Nat.le_ceil _) (by exact_mod_cast hn.le)
    linarith
  have hzero : G = 0 := abs_eq_zero.mp (le_antisymm hG0 (abs_nonneg G))
  linarith [hzero, hG]

end Real

namespace Complex

/-- The real digamma function agrees with Mathlib's complex digamma function on the
positive reals. -/
lemma digamma_ofReal {x : ℝ} (hx : 0 < x) :
    Complex.digamma (x : ℂ) = (Real.digamma x : ℂ) := by
  have hne : ∀ m : ℕ, (x : ℂ) ≠ -m := by
    intro m h
    rw [← Complex.ofReal_natCast, ← Complex.ofReal_neg, Complex.ofReal_inj] at h
    have hm : (0:ℝ) ≤ (m:ℝ) := Nat.cast_nonneg m
    rw [h] at hx
    linarith
  have hdiff : DifferentiableAt ℂ Complex.Gamma (x : ℂ) := Complex.differentiableAt_Gamma _ hne
  have h1 : HasDerivAt (fun y : ℝ => Complex.Gamma (y : ℂ)) (deriv Complex.Gamma (x : ℂ)) x :=
    hdiff.hasDerivAt.comp_ofReal
  have h2 : HasDerivAt (fun y : ℝ => ((Real.Gamma y : ℂ)))
      (Complex.ofReal (deriv Real.Gamma x)) x :=
    (Real.differentiableAt_Gamma_of_pos hx).hasDerivAt.ofReal_comp
  have h3 : (fun y : ℝ => Complex.Gamma (y : ℂ)) = fun y : ℝ => ((Real.Gamma y : ℂ)) := by
    funext y
    exact Complex.Gamma_ofReal y
  rw [h3] at h1
  have hderiv : deriv Complex.Gamma (x : ℂ) = Complex.ofReal (deriv Real.Gamma x) := h1.unique h2
  rw [Complex.digamma_def, logDeriv_apply, hderiv, Complex.Gamma_ofReal, Real.digamma_apply,
    Complex.ofReal_div]

end Complex
