# Supplement: the even icosahedral representation of conductor 1951

This supplement accompanies the note *The even icosahedral representation of conductor 1951: a conditional reduction and explicit residual bridges* (Dula, 13 October 2026). The note is in `note/`.

Every computational statement in the note is listed below, with the script that produces it and the output that records it.
- **Exact** statements use PARI/GP through `cypari2`.
- **Numerical** statements are marked [N]. Only the Hejhal computation in the introduction is numerical, and it is not used in any proof.

## Requirements and setup

- **Software:** Python 3 with `cypari2` (run with PARI/GP 2.17.4), plus `numpy`, `sympy`, `mpmath` and `scipy`.
- **Paths:** the scripts were run in a directory `/home/claude/research`, and many use absolute paths that begin with that prefix. Before re-running anything, run `sh relocate.sh` once from this folder. It rewrites the prefix to the folder's actual location.
- **Working directory:** run each script from its own folder, for example `cd mod2 && python3 sat.py`, because some scripts read and write files relative to the current directory.
- **Memory:** the field-equality certificates allocate 5–6 GB for the PARI stack.

## Map from the note to the files

### Notation (§2) and smaller exact facts

`note/check_note_claims.py` checks 35 statements; its output is `note/check_note_claims.out` (35 of 35 pass). It runs in about a minute. The statements it checks:

- **The character χ:** χ(3) = ζ₅², 3 is a primitive root mod 1951, χ is Conrey 1951.908, and χ(2) = ζ₅³.
- **Dimensions:** dim S₂(Γ₀(1951), χ) = 161 and dim S₂(Γ₀(1951)) = 162.
- **The quintic field L₅:**
  - disc L₅ = 1951⁴, and poldisc f₅ = 2²·7²·71²·137²·1951⁴;
  - Frob₂ has cycle type (3,1,1) in L₅;
  - the trace-zero lattice of O_{L₅} is A₄ scaled by 1951;
  - the explicit u, v for d = 1 and d = 3 have the stated properties.
- **The fields F and K:**
  - their defining polynomials;
  - h(F) = h(K) = 1, certified with `bnfcertify`;
  - disc K = 225;
  - ζ₅ ∉ F, K.
- **The quaternion algebra (δ, −1):**
  - δ = −(10+2√5) = −4√5·φ, and (2(ζ₅−ζ₅⁻¹))² = δ;
  - over ℚ(√5), (δ, −1) is split at the places above 2 and 5 and ramified at both real places;
  - it is split over F and over K.
- **The fields K₆ and K₂₄:**
  - K₆ has Galois group of order 60 on 6 points and discriminant 1951⁴;
  - disc K₂₄ = 1951¹⁶ = (disc K₆)⁴, so K₂₄/K₆ is unramified at finite places;
  - K₂₄ ⊃ K₆, and K₂₄ is totally imaginary.
- **Section 6 constants:**
  - the Sturm bounds;
  - 24/1950 = 4/325 (the Eisenstein series 𝓔 ≡ 1 mod 4);
  - x + y = z⁴ and xy = z³ in 𝔽₁₆.
- **Remark 6.3 (the √5-conjugate):**
  - σ fixes every trace value modulo √5, so ρ₀″ mod λ = ρ̄;
  - for the character ψ mod 11 with ψ(2) = ζ₅, the first zeros of L(s, ψ) and L(s, ψ²) differ (5.134 and 4.629), so σ does not act on analytic data.

The trace table t_p = tr ρ₀(Frob_p) for p < 3.2·10⁶ comes from `overnight/traces/galois_traces.py 3200000`. That script uses the helper `dokchitser.py` (resolvents for the two classes of 5-cycles) and the files `K24.txt` and `local1951.json`. Its output is `galois_traces_3200000.json`, with log `t3200k.log`.
- `local1951.json` records which class of elements of order 5 carries |t| = φ − 1, fixed by a local computation at 1951. That choice is certified independently by Theorem D (see §6 below and Table 1 of the note).
- The sign choice is fixed by K₂₄, which is unramified over K₆ (checked above).

### Theorem B (§4)

| Statement | Script | Output |
|---|---|---|
| (δ, −1) over ℚ(√5) and the CM quartic fields | `mod5/m5_quartic.py`; also `note/check_note_claims.py` | `mod5/m5_quartic.json` |
| Least certifying prime for the 31 imaginary quadratic fields with \|disc\| ≤ 100 (maximum 53; 13 for ℚ(i), 2 for ℚ(√−7)) | `mod5/m5_least_primes.py` | `mod5/m5_least_primes.json` |
| Density 0.375 ± 0.001 for twelve fields (split primes 7 ≤ p < 3.2·10⁶) | `mod5/m5_quadratic.py` | `mod5/m5_quadratic.json` |

`m5_quadratic.py` starts at p = 7, so its "first" prime can be larger than the least prime in `m5_least_primes.json` (for ℚ(√−7): 37 versus 2).

### Theorem C (§5)

**The curve E₀ over F = ℚ(i, √5), with accessory irrationality √−1.**

| Statement | Script | Output |
|---|---|---|
| Lattice and u, v | `moonshine/lattice.py` | `moonshine/lattice.pkl` |
| j₀ at 600 digits, recognised exactly | `moonshine/klein4.py 600` | `moonshine/j0_exact_600.pkl`, `moonshine/j0_exact.txt`; exported to `audit/j0_exact.json` by `audit/klein_export.py` |
| (i) the 5-isogeny field equals F·K₆ | `moonshine/certify_iso.py` | `moonshine/certify_iso.log` |
| Projective Frobenius orders at 970 primes of F, all four conjugates of j₀ | `moonshine/verify_E.py` | `moonshine/verify_E.log` |
| Integral model, places with v(j₀) < 0, witnesses (30 of the 41 testable split primes < 1200, smallest 89) | `cmmod/efg.py` | `cmmod/efg.json` |
| 44 split primes, the three excluded ones, and the norm-conic point | `audit/klein_export.py` | `audit/klein_counts.json` |

**The curve E₁ over K = ℚ(√5, √−3), with accessory irrationality √−3.**

| Statement | Script | Output |
|---|---|---|
| Lattice vectors with Tr u² = 3·Tr v² | `klein3/lattice3.py` | `klein3/lattice3.pkl` |
| j₁ at 600 digits (residual 10⁻⁵⁹⁴) | `klein3/klein_sqrt3.py 600` | `klein3/j1_exact_600.pkl`, `klein3/j1_exact.json`, `klein3/klein_sqrt3.log` |
| (i) the 5-isogeny field equals K·K₆; a_P² ≡ N(P)·t̄_p² mod 5 at 383 of 383 degree-one primes | `klein3/certify_iso_K.py` | `klein3/certify_iso_K.json`, `klein3/certify_iso_K.log` |
| (ii) places with v(j₁) < 0; integral model; Frobenius orders at 1227 of 1227 primes, all four conjugates; witnesses (34 of 51, smallest 19) | `klein3/certify_K.py` | `klein3/certify_K.json` |

`cmmod/README.md`, `cm_hyp.py` and `dg3.py` record the earlier check of the Caraiani–Newton hypotheses for E₀, including E[3].

### Theorem D (§6)

| Statement | Script | Output |
|---|---|---|
| 2-saturation (rank 153 → 161 in four rounds); the predicted q-expansions lie in S̄ for n ≤ 2400; the controls do not | `mod2/sat.py` (uses `mod2/brute40np.py`) | `mod2/sat_2400.json`, `mod2/sat.log`, `mod2/basis_mod2_sat_k{1,2}_2400.npy` |
| Hecke matrices T₂, T₃, T₅, T₇ on S̄: consistency to n ≤ 2400/ℓ, commutation, joint kernels 4, 3, 2, 1, 1, generalised dimensions 3 + 6 | `mod2/hecke2.py` (reads the saturated bases) | `mod2/hecke2.json` (key `chi^1`; key `chi^2` is the conjugate system ρ″ = ρ₀″ ⊗ χ of Remark 6.3, with T₂-roots 11 = x² and 3 = y² and generalised dimensions 3 and 6) |
| Table 1, v₂(D_ℓ) and controls | `audit/charp2.py`, `audit/charp2_controls.py` | `audit/charp2.json`, `audit/charp2_controls.json` and logs |

`audit/AUDIT_RESPONSE.md` records an earlier outside audit of these computations, and why its negative results came from using the trivial-character space and from reading 𝔽₁₆ codes as integers.

**Encoding of 𝔽₁₆.** 𝔽₁₆ = 𝔽₂[z]/(z⁴+z³+z²+z+1), where z = ζ₅ mod 2. The JSON files write elements as 4-bit codes b₀ + 2b₁ + 4b₂ + 8b₃ ↔ b₀ + b₁z + b₂z² + b₃z³. So x = z + z² is 6, y = 1 + z³ is 9, ā₂ = z⁴ is 15 and χ̄(2) = z³ is 8.

### Introduction, numerical [N]

| Statement | Script | Output |
|---|---|---|
| Hejhal's method on Γ₀(1951) with nebentypus χ and λ = 1/4; agreement 3·10⁻⁸ for n ≤ 800 | `maass/hejhal.py` (see `maass/HEJHAL_README.md`); `maass/h_compare.py` | `maass/hejhal_*.json`, `maass/h_compare.json` |
| Agreement 6·10⁻⁷ for n ≤ 2000, and the √5-conjugate form at level 1951 (nebentypus χ², files `*_k2.json`) | `maass/quartet.py` | `maass/quartet.json` |

The file `hejhal_eps-1_Y4.00e-04_M5000_conj.json` is a control with nebentypus χ̄ (complex conjugation), not the √5-conjugate form.

The helper `div/dcore.py` builds the Dirichlet coefficients of L(ρ, s) from the trace table.

## Labels

- [T] means a theorem or an exact computation.
- [N] means numerical evidence.
- Nothing in this supplement proves that L(ρ, s) is entire. Theorem A of the note is conditional on two open hypotheses, H1 and H2.
