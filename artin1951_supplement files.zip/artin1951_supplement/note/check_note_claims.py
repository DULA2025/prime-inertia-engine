"""Exact checks of the smaller computational statements in the note
"The even icosahedral representation of conductor 1951" (Notation, Sections 4-6).
Each line prints PASS/FAIL. Needs cypari2 (PARI/GP). Runs in about a minute.
Author: Dula."""
import os
import cypari2
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
results = []
def check(name, ok):
    results.append(bool(ok)); print("%s  %s" % ("PASS" if ok else "FAIL", name), flush=True)

N = 1951
# --- the character chi -------------------------------------------------------------------------
check("3 is a primitive root mod 1951", all(pow(3, (N - 1) // q, N) != 1 for q in (2, 3, 5, 13)))
check("3^780 = 908 mod 1951, so chi(3) = e(780/1950) = zeta5^2 is Conrey 1951.908", pow(3, 780, N) == 908)
ind2 = next(k for k in range(N - 1) if pow(3, k, N) == 2)
check("chi(2) = zeta5^3 (ind_3 2 = %d)" % ind2, (2 * ind2) % 5 == 3)
check("dim S_2(Gamma0(1951), chi) = 161 with chi = Mod(908,1951)", int(pari.mfdim([N, 2, pari("Mod(908,1951)")], 1)) == 161)
check("dim S_2(Gamma0(1951)) = 162", int(pari.mfdim([N, 2, 1], 1)) == 162)

# --- the quintic field L5 ---------------------------------------------------------------------
f5 = pari("x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344")
nf = pari.nfinit(f5)
check("disc(L5) = 1951^4", nf[2] == N ** 4)
check("poldisc(f5) = 2^2 7^2 71^2 137^2 1951^4", pari.poldisc(f5) == 2**2 * 7**2 * 71**2 * 137**2 * N**4)
check("Gal(f5) = A5 (order 60)", int(pari.polgalois(f5)[0]) == 60)
check("L5 totally real", int(pari.polsturm(f5)) == 5)
dec2 = sorted(int(P[3]) for P in pari.idealprimedec(nf, 2))
check("Frob_2 has cycle type (3,1,1) in L5, so t_2 = +-1", dec2 == [1, 1, 3])
tr = lambda a: pari.nfelttrace(nf, a)
B = pari.nfbasis(f5)
T = pari.matrix(5, 5, [tr(pari.nfalgtobasis(nf, B[i] * B[j])) for i in range(5) for j in range(5)])
trv = pari.matrix(1, 5, [tr(pari.nfalgtobasis(nf, B[i])) for i in range(5)])
K0 = pari.matkerint(trv)
G = pari.mattranspose(K0) * T * K0
A4 = pari("[2,-1,0,0;-1,2,-1,0;0,-1,2,-1;0,0,-1,2]")
check("trace-zero lattice of O_L5 is isometric to A4 scaled by 1951", pari.qfisom(G, N * A4) != 0)
UV = {1: ("(-229*x^4-27*x^3+180034*x^2+602971*x-653282)/19454", "(689*x^4-386*x^3-535218*x^2-1566799*x+622376)/68089"),
      3: ("(3275*x^4-1143*x^3-2565972*x^2-7306095*x+8710406)/136178", "(-145*x^4-187*x^3+112806*x^2+519501*x+192652)/19454")}
for d, (us, vs) in UV.items():
    u = pari.nfalgtobasis(nf, pari(us)); v = pari.nfalgtobasis(nf, pari(vs))
    integral = all(pari.denominator(c) == 1 for c in list(u) + list(v))
    m = lambda a, b: pari.nfeltmul(nf, a, b)
    ok = integral and tr(u) == 0 and tr(v) == 0 and tr(m(u, v)) == 0 and tr(m(u, u)) == d * tr(m(v, v)) and tr(m(v, v)) == 3902
    check("d=%d: u, v integral, Tr u = Tr v = Tr uv = 0, Tr u^2 = %d * Tr v^2 = %d" % (d, d, d * 3902), ok)

# --- the fields F, K, K6, K24 -----------------------------------------------------------------
Fpol = pari("y^4 + 3*y^2 + 1"); Kpol = pari("a^4 - a^3 + 2*a^2 + a + 1")
check("F = Q(i, sqrt5): polredabs of the compositum", pari.polredabs(pari.polcompositum("x^2+1", "x^2-5")[0]) == pari.substpol(Fpol, "y", "x"))
check("K = Q(sqrt5, sqrt-3): polredabs of the compositum", pari.polredabs(pari.polcompositum("x^2+3", "x^2-5")[0]) == pari.substpol(Kpol, "a", "x"))
bF = pari.bnfinit(Fpol, 1); bK = pari.bnfinit(Kpol, 1)
check("class numbers h(F) = h(K) = 1 (certified with bnfcertify)",
      bF.bnf_get_no() == 1 and bK.bnf_get_no() == 1 and int(pari.bnfcertify(bF)) == 1 and int(pari.bnfcertify(bK)) == 1)
check("disc(K) = 225", bK[6][2] == 225)
iF = pari("Mod(y^3 + 2*y, y^4 + 3*y^2 + 1)"); s5F = pari("Mod(2*y^2 + 3, y^4 + 3*y^2 + 1)")
check("in F: (y^3+2y)^2 = -1 and (2y^2+3)^2 = 5", iF ** 2 == -1 and s5F ** 2 == 5)
check("zeta5 not in F and not in K", len(pari.nfroots(bF, "x^4+x^3+x^2+x+1")) == 0 and len(pari.nfroots(bK, "x^4+x^3+x^2+x+1")) == 0)
z = pari("Mod(t, polcyclo(5, t))"); s5 = 2 * (z + z ** 4) + 1     # sqrt5 = 1 + 2(z + z^-1)
phi = (1 + s5) / 2
delta = -(10 + 2 * s5)
check("sqrt5 = 1 + 2(z + z^4) in Q(zeta5)", s5 ** 2 == 5)
check("delta = -(10 + 2 sqrt5) = -4 sqrt5 phi", delta == -4 * s5 * phi)
check("(2(zeta5 - zeta5^-1))^2 = delta, so Q(zeta5) = Q(sqrt5)(sqrt delta)", (2 * (z - z ** 4)) ** 2 == delta)
# Hilbert symbol (delta, -1) over Q(sqrt5) at the finite places above 2 and 5, and over F, K
k5 = pari.nfinit("w^2 - 5")
dk = pari("Mod(-10 - 2*w, w^2 - 5)").lift()
hs = [int(pari.nfhilbert(k5, dk, -1, P)) for p in (2, 5) for P in pari.idealprimedec(k5, p)]
check("over Q(sqrt5): (delta,-1) split at the places above 2 and 5", hs == [1, 1])
check("over Q(sqrt5): delta totally negative (ramified at both real places)", all(float(pari.real(r)) < 0 for r in pari.polroots(pari.charpoly(pari("Mod(-10 - 2*w, w^2 - 5)")))))
for name, b, s5pol in (("F", bF, "2*y^2+3"), ("K", bK, None)):
    nfb = b
    if s5pol is None:
        r5 = pari.nfroots(nfb, "x^2-5")[0]; s5el = pari.nfbasistoalg(nfb, r5).lift()
    else:
        s5el = pari(s5pol)
    dl = -10 - 2 * s5el
    check("over %s: Hilbert symbol (delta,-1) = 1 (split)" % name, int(pari.nfhilbert(nfb, dl, -1)) == 1)
K6 = pari("x^6 - 75*x^4 - 70*x^3 + 826*x^2 - 210*x - 625")
check("K6: Galois group of order 60 on 6 points, disc 1951^4", int(pari.polgalois(K6)[0]) == 60 and pari.nfdisc(K6) == N ** 4)
K24 = pari(open(os.path.join(ROOT, "overnight", "traces", "K24.txt")).read().strip())
dK24 = pari.nfdisc([K24, [2, 3, 5, 7, 17, 139, 271, 40427, 1951]])
check("K24: disc = 1951^16 = disc(K6)^4 (unramified over K6 at finite places)", dK24 == N ** 16)
check("K24 contains K6", any(pari.nfisisom(pari.polredbest(s[0]), pari.polredbest(K6)) != 0 for s in pari.nfsubfields(K24, 6)))
check("K24 is totally imaginary (so rho0(c) = -I)", int(pari.polsturm(K24)) == 0)

# --- Section 6 numerics -----------------------------------------------------------------------
check("Sturm bounds: 2*1952/12 < 326 and 4*1952/12 < 651", 2 * 1952 / 12 < 326 and 4 * 1952 / 12 < 651)
from fractions import Fraction
check("Eisenstein series: 24/1950 = 4/325 has 2-adic valuation 2", Fraction(24, 1950) == Fraction(4, 325))
# F16 = F2[z]/(z^4+z^3+z^2+z+1): x = z + z^2, y = 1 + z^3
F16 = lambda e: pari("Mod(Mod(1,2)*(%s), Mod(1,2)*(z^4+z^3+z^2+z+1))" % e)
xx, yy = F16("z+z^2"), F16("1+z^3")
check("in F16: x + y = z^4 and x*y = z^3", xx + yy == F16("z^4") and xx * yy == F16("z^3"))
check("sigma (sqrt5 -> -sqrt5) fixes every trace value mod sqrt5 (phi = 3, 1-phi = 3), so rho0'' mod lambda = rhobar",
      all((a - b) % 5 == 0 for a, b in ((3, 1 - 3), (-3, -(1 - 3)), (3 - 1, (1 - 3) - 1), (1 - 3, 1 - (1 - 3)))))
# zeros of Galois-conjugate Dirichlet L-functions differ (sigma does not act on analytic data)
G11 = pari.znstar(11, 1)
z1 = float(pari.lfunzeros(pari.lfuncreate([G11, [2]]), 8)[0]); z2 = float(pari.lfunzeros(pari.lfuncreate([G11, [4]]), 8)[0])
check("psi mod 11 with psi(2) = zeta5: first zeros of L(s,psi), L(s,psi^2) at %.3f, %.3f (different)" % (z1, z2),
      abs(z1 - 5.134) < 1e-3 and abs(z2 - 4.629) < 1e-3)
print("\n%d of %d checks passed" % (sum(results), len(results)))
