/-
Top-level import file for the formalization of

  Alain Connes & Caterina Consani,
  "Weil positivity and Trace formula – the archimedean place", arXiv:2006.13771.

See `RequestProject/Skeleton.lean` for a summary of what is formalized and what is not.
-/
import RequestProject.Basic
import RequestProject.SineIntegral
import RequestProject.SiPositivity
import RequestProject.SiSmooth
import RequestProject.TraceRemainder
import RequestProject.Sonin
import RequestProject.Scaling
import RequestProject.WeilDistribution
import RequestProject.Mellin
import RequestProject.JumpFormula
import RequestProject.DeltaSmooth
import RequestProject.RemainderBound
import RequestProject.Positivity
import RequestProject.KernelBound
import RequestProject.Effective
import RequestProject.FourierSide
import RequestProject.Parseval
import RequestProject.Digamma
import RequestProject.DigammaAsymptotic
import RequestProject.ArchimedeanKernel
import RequestProject.ArchimedeanExplicit
import RequestProject.DeltaDecay
import RequestProject.ThetaGrowth
import RequestProject.DeltaDecaySharp
import RequestProject.DeltaVariation
import RequestProject.FourierSideAnalysis
import RequestProject.SiAsymptotic
import RequestProject.TaylorBounds
import RequestProject.CompactInterval
import RequestProject.DeltaFourierZero
import RequestProject.GammaBound
import RequestProject.NearOrigin
import RequestProject.BandEnergy
import RequestProject.TailEnergy
import RequestProject.Skeleton
