# Counterexample to `weil_component2_continuous_WTF`

**Status:** The lemma `weil_component2_continuous_WTF` as stated in
`ContinuityHelpers.lean` is **false**. This document presents an
explicit counterexample, with both rigorous asymptotic analysis and
numerical verification.

## Setup

Define the von Mangoldt sum functional:
$$F_2(g) := \sum_{n=1}^\infty \frac{\Lambda(n)}{\sqrt n} \int_\mathbb{R} g(t)\, g(t + \log n)\, dt$$

The lemma claims this is continuous as a function $\mathsf{WTF} \to \mathbb{R}$,
where $\mathsf{WTF}$ carries the subspace topology from
$\mathsf{SchwartzMap}(\mathbb{R}, \mathbb{R})$.

## The counterexample

Fix any $g_* \in \mathsf{WTF}$ with decay witness $(b_*, C_*)$, e.g.
$g_*(t) = e^{-1.5\sqrt{t^2+1}}$ (witness $(b_*, C_*) = (1, 1)$).

Define for each $s \geq 1$:
$$\varepsilon_s := e^{-\sqrt{s}}, \qquad h_s(t) := \varepsilon_s \cdot \left[\phi(t - s) + \phi(t + s)\right]$$

where $\phi(y) = e^{-y^2/2}$ is the unit Gaussian.

Set $g_s := g_* + h_s$. Each $g_s \in \mathsf{WTF}$ (sum of two functions
with exponential decay; the witness for $g_s$ exists, with constants
depending on $s$).

**Claim 1:** $h_s \to 0$ in the Schwartz topology as $s \to \infty$.
Equivalently, $g_s \to g_*$ in the Schwartz subspace topology of $\mathsf{WTF}$.

**Claim 2:** $F_2(g_s) - F_2(g_*) \to +\infty$ as $s \to \infty$.

Together, these contradict continuity of $F_2$ at $g_*$.

## Proof of Claim 1: Schwartz convergence

For each fixed $p \geq 0$ and $q \geq 0$, the Schwartz seminorm
$$\|t^p D^q h_s\|_\infty$$

is bounded by considering the support of $h_s$ (concentrated near $t = \pm s$).

The maximum of $|t^p D^q \phi(t - s)|$ for $\phi(y) = e^{-y^2/2}$ has
the form $|H_q(t-s)| \cdot e^{-(t-s)^2/2}$ times $|t^p|$, where $H_q$
is the $q$-th Hermite polynomial. The dominant contribution near
$t = s$ gives:
$$\|t^p D^q h_s\|_\infty \leq C_{p,q} \cdot s^p \cdot \varepsilon_s = C_{p,q} \cdot s^p \cdot e^{-\sqrt s}$$

For fixed $p$, $s^p \cdot e^{-\sqrt s} \to 0$ as $s \to \infty$, since
$\sqrt s$ grows faster than $p \log s$ for any fixed $p$. Therefore,
each Schwartz seminorm $\|t^p D^q h_s\|_\infty \to 0$ as $s \to \infty$,
which is precisely Schwartz convergence to $0$. ∎

**Note on convergence rates.** The rate at which seminorm $p$ decreases
depends on $p$: for $p = 2$, decreases past $s \sim 74$; for $p = 16$,
past $s \sim 26{,}000$; for $p = 64$, past $s \sim 750{,}000$. This is
fine — Schwartz convergence is pointwise-in-seminorms, not uniform.

## Proof of Claim 2: $F_2$ blows up

Compute $F_2(g_s) - F_2(g_*)$ via linearization:
$$F_2(g_s) - F_2(g_*) = 2\,\text{cross}(g_*, h_s) + Q(h_s)$$

where
$$\text{cross}(g_*, h_s) = \sum_n \frac{\Lambda(n)}{\sqrt n} \int g_*(t)\, h_s(t + \log n)\, dt$$

For our specific $h_s$, the inner integral evaluates as a convolution:
$$\int g_*(t) \cdot \varepsilon_s \phi(t + \log n - s)\, dt = \varepsilon_s \cdot G(s - \log n)$$

where $G(y) := (g_* * \phi)(y) = \int g_*(y - z) \phi(z)\, dz$ is the convolution
of $g_*$ with the unit Gaussian. This is a well-defined Schwartz function,
peaking near $y = 0$ and decaying like $g_*$ at infinity.

Including the $\phi(t+s)$ piece similarly, the inner integral becomes:
$$\int g_*(t) h_s(t + \log n)\, dt = \varepsilon_s \cdot \left[G(s - \log n) + G(-s - \log n)\right]$$

For $s$ large, $G(-s - \log n)$ is exponentially small for $n \geq 2$
(the argument is $\leq -s$), so we focus on the $G(s - \log n)$ term.

### PNT-based asymptotic

Using the Stieltjes integral form,
$$\text{cross}(g_*, h_s) \approx \varepsilon_s \int_{2}^\infty \frac{G(s - \log u)}{\sqrt u}\, d\psi(u)$$

By the prime number theorem $\psi(u) \sim u$, so $d\psi(u) \approx du$ for
large $u$. Substituting $x = \log u$:
$$\text{cross}(g_*, h_s) \approx \varepsilon_s \int_{\log 2}^\infty G(s - x) \cdot e^{x/2}\, dx$$

Substituting $z = s - x$:
$$\text{cross}(g_*, h_s) \approx \varepsilon_s \cdot e^{s/2} \int_{-\infty}^{s - \log 2} G(z)\, e^{-z/2}\, dz \;\to\; \varepsilon_s \cdot e^{s/2} \cdot M$$

as $s \to \infty$, where
$$M := \int_{-\infty}^{\infty} G(z)\, e^{-z/2}\, dz$$

Since $G(z)$ has decay rate $1/2 + b_* > 1/2$ (inherited from $g_*$),
the integrand $G(z) e^{-z/2}$ has rate $b_* > 0$, hence $M < \infty$.
For $g_*(t) = e^{-1.5\sqrt{t^2+1}}$, numerical computation gives
$M \approx 1.893$.

### Conclusion of Claim 2

$$\text{cross}(g_*, h_s) \approx M \cdot \varepsilon_s \cdot e^{s/2} = M \cdot e^{s/2 - \sqrt s} \to +\infty \text{ as } s \to \infty$$

The quadratic term $Q(h_s)$ is similar in structure; numerical evidence
shows it is the same order or smaller. Therefore $F_2(g_s) - F_2(g_*) \to \infty$. ∎

## Numerical verification

Computed via direct summation of the prime-power von Mangoldt series:

| $s$ | $\varepsilon_s$ | cross$(g_*, h_s)$ | $\log(\text{cross}) - (s/2 - \sqrt s)$ |
|---:|---:|---:|---:|
| 4 | $1.35 \times 10^{-1}$ | $1.624$ | $0.4849$ |
| 6 | $8.63 \times 10^{-2}$ | $2.818$ | $0.4854$ |
| 8 | $5.91 \times 10^{-2}$ | $5.246$ | $0.4859$ |
| 10 | $4.23 \times 10^{-2}$ | $10.21$ | $0.4856$ |
| 12 | $3.13 \times 10^{-2}$ | $20.52$ | $0.4856$ |
| 14 | $2.36 \times 10^{-2}$ | $42.26$ | $0.4856$ |

The quantity $\log(\text{cross}) - (s/2 - \sqrt s)$ is constant to four
decimals at $0.4856$ across the tested range, confirming
$\text{cross} \approx 1.625 \cdot e^{s/2 - \sqrt s}$.

Extrapolation: $\text{cross}(g_*, h_{100}) \approx 4 \times 10^{17}$,
$\text{cross}(g_*, h_{1000}) \approx 10^{203}$. Direct numerical
computation infeasible at these $s$ values (require $n$ up to $e^s$).

## Verification: full Weil distribution also discontinuous

To rule out cancellations between components, computed the full Weil
distribution $F = F_1 - F_2 + F_3$ along the same sequence:

| $s$ | $F_1(g_s) - F_1(g_*)$ | $F_2(g_s) - F_2(g_*)$ | $F_3(g_s) - F_3(g_*)$ | $F(g_s) - F(g_*)$ |
|---:|---:|---:|---:|---:|
| 2 | $0.41$ | $6.19$ | $1.07$ | $-4.72$ |
| 6 | $0.031$ | $5.77$ | $0.29$ | $-5.44$ |
| 10 | $0.0073$ | $20.4$ | $0.13$ | $-20.3$ |

The $F_2$ blowup dominates; $F_1$ and $F_3$ contributions remain small.
**No cancellation.** The full Weil distribution is also discontinuous on
$\mathsf{WTF}$ in the Schwartz subspace topology along this sequence.

## Why earlier numerical evidence missed this

Previous numerical tests used perturbation sequences like
$h_k = (\epsilon_k) \phi(t)$ with $\phi$ fixed and $\epsilon_k \to 0$,
or $h_k = \epsilon_k e^{-(1/2 + 1/k)\sqrt{t^2+1}}$ (perturbations
concentrated near $t = 0$). For these sequences, the bound $K(s)$
peaks near $s = 0$ where $G \approx g_*(0) \cdot O(1)$ and the cross
sum is bounded. **The blowup only appears for perturbations with mass
at large $|t|$**, where $K(s) \sim e^{|s|/2}$ via PNT.

Aristotle's earlier proposed counterexample
($g_k = (1-\epsilon_k) g_0 + \epsilon_k e^{-b_k t^2}$ with $b_k \to 0$,
$\epsilon_k = e^{-C/b_k}$) had perturbations centered at $t = 0$
(slowly-decaying Gaussians). For those, the cross term DOES go to 0
because the bumps don't probe the $K(s) \sim e^{s/2}$ growth at large $s$.
The actual counterexample requires placing the bump AT large $s$
where the kernel grows exponentially.

## Implications for the project

1. **`weil_component2_continuous_WTF` is false** as stated. The sorry
   should be replaced with a documented obstruction (this counterexample),
   not labeled "open."

2. **`weilDistribution_autocorrelation_continuous_WTF` is also false**:
   the full distribution is discontinuous along this sequence, since
   $F_1, F_3$ perturbations are small while $F_2$ blows up.

3. **`conjecture_a_strong_wtf_implies_rh` (currently proved without sorry)
   uses these continuity claims**. The proof DOES typecheck because the
   continuity claims are stated as hypotheses (sorry-bodies), but the
   premises are false. A `sorry` proof of a false claim is not a
   logical contradiction in Lean (sorry is a valid term of any type),
   but the conditional reduction is broken at the math level.

4. **To restore the conditional reduction**, one must either:
   - Strengthen the WTF topology to include uniform decay-witness
     control (this kills the bump-far-from-origin counterexample but
     requires re-verifying that Cohn-Elkies sequences in
     `Conjecture_A_Strong_WTF` converge in the stronger topology), or
   - Restructure the conjecture to avoid the continuity-on-WTF requirement.

## Recommended action

The `weil_component2_continuous_WTF` sorry should be retained in
`ContinuityHelpers.lean`, with an updated docstring documenting:
- The specific counterexample $h_s = e^{-\sqrt s}[\phi(t-s) + \phi(t+s)]$.
- The asymptotic $F_2(g_s) - F_2(g_*) \sim M e^{s/2 - \sqrt s}$.
- The conclusion: the lemma is false in the Schwartz subspace topology.
- The required topology change for the conditional reduction to be valid.

The 2 deep sorrys in `WeilTestFunction.lean`
(`spectralSide_autocorr_nonneg_WTF`, `weilPositivity_wtf_implies_rh`)
remain as research-frontier targets, unaffected by this finding (they
are about Weil's 1952 explicit-formula structure, not about continuity).

The project's overall honest state is now: a CONDITIONALLY VALID
formalization of a Weil-style reduction, with TWO documented gaps:

(a) the deep Weil 1952 sub-lemmas (research-frontier);
(b) the continuity of the Weil distribution on a suitable topology
    (this counterexample reveals the Schwartz subspace topology is
    insufficient; the right topology and its compatibility with the
    Cohn-Elkies density argument requires further work).
