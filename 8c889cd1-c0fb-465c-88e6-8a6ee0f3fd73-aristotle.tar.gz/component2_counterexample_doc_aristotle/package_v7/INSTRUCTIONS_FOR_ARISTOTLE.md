# Instructions for Aristotle — Documentation update for component 2 counterexample

## Background

Over multiple rounds, this project has tried to prove `weil_component2_continuous_WTF`
(continuity of the von Mangoldt sum functional on `WeilTestFunction` in the
Schwartz subspace topology). Aristotle's first attempt claimed it was "likely
false" with a wrong counterexample (numerically refuted). Aristotle's second
attempt couldn't find a proof.

**This round documents a NEW finding:** the lemma is genuinely **FALSE** in
the Schwartz subspace topology. A rigorous counterexample has been
constructed and numerically verified.

## What this round is for

This is a **documentation-only round.** The task is to:

1. Update the docstring on `weil_component2_continuous_WTF` with the
   counterexample finding.
2. Update the docstring on `weilDistribution_autocorrelation_continuous_WTF`
   to note that it is also false (since component 2 is false and there is
   no cancellation).
3. Add a status note in `ConjectureA.lean` documenting that
   `conjecture_a_strong_wtf_implies_rh` typechecks but its premises are
   now known to be false in the current topology.

**This round does NOT attempt any new proofs.** The sorry count must remain
at 3.

## CRITICAL: What NOT to do

✗ **Do NOT try to "fix" the proof of `weil_component2_continuous_WTF`.**
  The lemma is false; there is no proof. Any attempt to prove it would
  necessarily either: (a) be unsound (using `axiom`/`admit` cheats), or
  (b) work in a different topology than declared. Both are unacceptable.

✗ **Do NOT change the statement** of any lemma to make it provable.
  We need the false statement preserved with documentation, not silently
  rewritten.

✗ **Do NOT strengthen the WTF topology** (e.g., by changing the topology
  declaration in `WeilTestFunction.lean`). That requires cascading changes
  to the density argument in `Conjecture_A_Strong_WTF` that have not been
  worked out. If you change the topology, the `conjecture_a_strong_wtf_implies_rh`
  proof would need to be re-verified against new convergence conditions.

✗ **Do NOT modify any file other than the three files mentioned above**
  (`ContinuityHelpers.lean`, `ConjectureA.lean`, and optionally a new
  `STATUS.md` or similar at the project root for top-level documentation).

✗ **Do NOT modify the proved bodies** of any lemmas that already have
  proofs. Those proofs are correct. The issue is purely with the truth of
  one statement, not with its proof structure.

## The counterexample (for reference in the docstrings)

For any fixed $g_* \in \mathsf{WTF}$ (e.g., $g_*(t) = e^{-1.5\sqrt{t^2+1}}$),
define for each $s \geq 1$:

$$h_s(t) = e^{-\sqrt s} \cdot \left[\phi(t - s) + \phi(t + s)\right]$$

where $\phi(y) = e^{-y^2/2}$ is the unit Gaussian (this makes $h_s$ even,
preserving the EvenSchwartz structure).

Define $g_s = g_* + h_s$. Then:

1. Each $g_s \in \mathsf{WTF}$ (sum of WTF + even Schwartz with Gaussian decay).
2. $h_s \to 0$ in the Schwartz topology as $s \to \infty$:
   each fixed Schwartz seminorm $\|t^p D^q h_s\|_\infty \leq C_{p,q} s^p e^{-\sqrt s} \to 0$.
3. But the von Mangoldt sum diverges:
   $$F_2(g_s) - F_2(g_*) \approx M \cdot e^{s/2 - \sqrt s} \to +\infty$$
   where $M = \int (g_* * \phi)(z) e^{-z/2}\, dz$ is a positive constant.

The asymptotic constant has been numerically verified to four decimal
places across $s \in [4, 14]$:
$\log(\text{cross}) - (s/2 - \sqrt s) = 0.4856$ (essentially constant).

The full Weil distribution $F = F_1 - F_2 + F_3$ also fails continuity
along this sequence: $F_1$ and $F_3$ perturbations remain $O(\varepsilon_s)$
while $F_2$ blows up. **No cancellation saves continuity.**

## Why earlier numerical evidence missed this

Earlier rounds tested perturbations concentrated near $t = 0$ (e.g.,
$h_k = (1/k) \phi(t)$ or $h_k = \epsilon_k e^{-(1/2 + 1/k)\sqrt{t^2+1}}$).
For these, the cross term is bounded because the kernel
$K(s) = \sum_n \Lambda(n)/\sqrt n |g_*(s - \log n)|$ is small at $s = 0$.
The blowup only appears for perturbations with mass at large $|s|$, where
$K(s) \sim e^{|s|/2}$ via PNT.

## Specific edits to make

### Edit 1: `ContinuityHelpers.lean`, docstring of `weil_component2_continuous_WTF`

Replace the current docstring with one stating:

- **Status: KNOWN FALSE in the Schwartz subspace topology.**
- A rigorous counterexample exists: $h_s = e^{-\sqrt s}[\phi(t-s) + \phi(t+s)]$.
- Cross term blows up as $\sim M \cdot e^{s/2 - \sqrt s}$ via PNT.
- Numerical verification: $\log(\text{cross}) - (s/2 - \sqrt s)$ constant to 4 decimals.
- The sorry remains because the lemma cannot be proved (it is false).
- A future fix requires either strengthening the WTF topology or
  restructuring the conditional reduction.

The sorry body itself stays as `sorry` — no proof attempt.

### Edit 2: `ContinuityHelpers.lean`, docstring of `weilDistribution_autocorrelation_continuous_WTF`

Add a note that this theorem ALSO has a false premise (since it depends
on `weil_component2_continuous_WTF`). The proof of this theorem currently
typechecks because it composes lemmas, but its conclusion depends on the
false sub-lemma.

Note this is consistent (in Lean's type system, anything follows from a
sorry-stated false claim), but mathematically the conclusion is not
established. Document this honestly.

**Do not modify the proof body** — leave it as-is. Just update the docstring.

### Edit 3: `ConjectureA.lean`, docstring of `conjecture_a_strong_wtf_implies_rh`

Add a STATUS note: the theorem currently typechecks, but its proof relies
on `weilDistribution_autocorrelation_continuous_WTF`, which in turn relies
on the now-known-FALSE `weil_component2_continuous_WTF`. Therefore the
"proof" of `conjecture_a_strong_wtf_implies_rh` is conditional on a
premise that is false in the current topology setup.

The honest project state: this is a **structural skeleton** of the
intended conditional reduction, with one structurally incorrect step
that needs a topology fix to be valid. The skeleton is still valuable
(other components are correct), but the end-to-end proof requires
addressing the topology issue.

**Do not modify the proof body** — leave it as-is. Just update the docstring.

### Edit 4 (optional): top-level STATUS.md

Create `STATUS.md` at the project root with a short summary:

```
# DULA Project Status

## Sorry inventory (3 total)

1. `spectralSide_autocorr_nonneg_WTF` (WeilTestFunction.lean) — Deep Weil 1952
2. `weilPositivity_wtf_implies_rh` (WeilTestFunction.lean) — Deep Weil 1952
3. `weil_component2_continuous_WTF` (ContinuityHelpers.lean) — KNOWN FALSE

## Honest assessment

- Sorrys 1-2 are research-frontier (Weil's 1952 explicit-formula directions).
- Sorry 3 is provably false in the current Schwartz-subspace topology on WTF
  (counterexample documented). The conditional reduction
  `Conjecture_A_Strong_WTF → RH` is therefore not formally valid, despite
  Lean accepting the proof (which uses sorry 3 as a premise).

## Required fix

Strengthen the WTF topology to include uniform decay-witness control,
then re-verify that the Cohn-Elkies density argument in
`Conjecture_A_Strong_WTF` works in the stronger topology. This is
non-trivial off-Lean math research.
```

## Critical instructions (repeated for emphasis)

- ✗ Do NOT prove `weil_component2_continuous_WTF`. It is false.
- ✗ Do NOT use `axiom`, `admit`, `native_decide`, or any other unsoundness
  shortcut.
- ✗ Do NOT modify lemma statements or proof bodies.
- ✗ Do NOT change the topology declaration on `WeilTestFunction`.
- ✓ DO update docstrings to honestly reflect the state of the project.
- ✓ DO preserve byte-identity of the proof bodies.

## Expected outcome

- Build status: ✅ success (no Lean changes that affect typechecking).
- Sorry count: 3 (unchanged).
- Files modified: `ContinuityHelpers.lean` (docstring), `ConjectureA.lean`
  (docstring), and optionally a new `STATUS.md`.
- All other files: byte-identical.

## Reporting

In `ARISTOTLE_SUMMARY.md`:
- Confirm files modified and that proof bodies were not changed.
- Confirm sorry count is unchanged at 3.
- Confirm build succeeds.
- Note any deviation from the instructions above.

This is a documentation round. The mathematical finding (lemma is false)
is the substantive result. Let's record it honestly.
