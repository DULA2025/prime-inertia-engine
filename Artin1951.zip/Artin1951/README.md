# Artin1951: a Lean 4 formalization project for Artin's conjecture for the conductor-1951 representation

Author: Dula. Lean 4.36.0-rc1 (commit `c9afcdd`), Mathlib at commit `59109b97` (27 October 2026).

**Status (27 October 2026): compiled.**
- `lake build` ends with "Build completed successfully"; all ten modules build.
- No file contains `sorry`.
- `scripts/Axioms.lean` prints the axioms of 23 main results. Every one depends only on `propext`, `Classical.choice` and `Quot.sound` (`axioms.out`). There is no `sorryAx`, and no `native_decide` or `Lean.ofReduceBool`. The eight `decide +kernel` calls are evaluated by the kernel itself.
- `leanchecker`, the kernel replay tool shipped with Lean, re-checks every declaration of the nine non-root modules (`leanchecker.out`).
- The toolchain and Mathlib were built from source in the workspace where these files were written, because its network blocks the release and cache servers.

## What this is

This project does not prove Artin's conjecture for the even icosahedral representation ρ of conductor 1951. It does four things:
1. It *states* the conjecture in Lean (`ArtinConjecture1951 : Prop`), using Mathlib's notions of arithmetic Frobenius, inertia, Euler products and L-series.
2. It proves the arithmetic facts about the data that a reader of the note would check first:
   - the Galois group of the Doud–Moore quintic is A₅;
   - the projective image of every representation with the defining properties is A₅.
3. It formalizes the conditional reduction, Theorem A″ of the note. For every such ρ, the group-theoretic input is proved. The automorphic inputs coming from H1 are explicit hypotheses, never axioms.
4. It lists what remains (roadmap below).

| file | content | lines |
|---|---|---|
| `Artin1951/Character.lean` | The character χ mod 1951: 3 is a primitive root; 3⁷⁸⁰ = 908, 2 = 3⁶⁰⁴, −1 = 3⁹⁷⁵ in ℤ/1951 (`decide +kernel`). Every character with ψ(3) = ζ², ζ⁵ = 1 has ψ(2) = ζ³ and ψ(−1) = 1. `chi : MulChar (ZMod 1951) ℂ` has χ(3) = e^{4πi/5}. | 140 |
| `Artin1951/Quintic.lean` | f₅ = X⁵ − X⁴ − 780X³ − 1795X² + 3106X + 344 is monic of degree 5. It has five real roots, in (−30,−20), (−20,−3), (−1,0), (1,2), (2,30). f₅(X + 1561) is Eisenstein at 1951, so f₅ is irreducible over ℤ and over ℚ (`f5_irreducible`, `f5Q_irreducible`), and 1951 is totally ramified in L₅. | 177 |
| `Artin1951/Discriminant.lean` | Res(f₅, f₅′) = disc f₅ = 2²·7²·71²·137²·1951⁴ = 518348075378² (`resultant_f5Q`, `discr_f5Q`, `discr_f5Q_eq_sq`), via an exact LU factorisation of the 9 × 9 Sylvester matrix. For every enumeration α of the roots in a field K ⊇ ℚ, det(αᵢʲ)² = disc f₅ (`det_vandermonde_sq`). | 196 |
| `Artin1951/GaloisGroup.lean` | **Gal(f₅/ℚ) ≅ A₅** (`galF5MulEquivA5`), of order 60 (`card_galF5`); [M : ℚ] = 60 for the splitting field (`finrank_splittingField_f5Q`). Along the way: 15 ∣ [K : ℚ] for every Galois number field K where f₅ splits (`fifteen_dvd_finrank`), and a subgroup of A₅ of index ≤ 4 is A₅. | 352 |
| `Artin1951/SignLemma.lean` | Every element of A₅ has g² = 1, g³ = 1 or g⁵ = 1 (`decide +kernel` over A₅). The arithmetic core of Step 2 of Theorem A″ (`sign_core`). | 62 |
| `Artin1951/Statement.lean` | Definitions: 2-dimensional Artin representations through a finite Galois N/ℚ; Frobenius (`IsArithFrobAt`); inertia; the local factor det(1 − ρ(Frob)T \| V^I) via the averaging projector; the Euler product (`ArithmeticFunction.eulerProduct`) and `LSeries`; `ArtinHolds` (an entire function equal to L(ρ,s) on Re s > 1); `IsRho1951`; **`ArtinConjecture1951 : Prop`**; `Rho1951Exists : Prop`. | 162 |
| `Artin1951/ProjectiveImage.lean` | For every A with `IsRho1951`: Gal(N/ℚ)/ker(proj ∘ ρ) ≅ A₅ (`ArtinRep2.projImageEquivA5`), of order 60. | 47 |
| `Artin1951/Conditional.lean` | `stepTwo`: Step 2 of Theorem A″ at the level of Satake parameters. `thmA2`: L(ρ,s) is entire, given the cuspidal π with the local properties that H1 yields, the eigenvalue condition, and the analytic last step. | 87 |
| `Artin1951/EigenRatio.lean` | For every A with `IsRho1951` and every σ, the eigenvalue ratio of ρ(σ) has order dividing 2, 3 or 5 (`ArtinRep2.eig_ratio`). This discharges the eigenvalue hypothesis of `thmA2`: `thmA2_of_isRho1951` is Theorem A″ for every such A, with only the automorphic inputs and the analytic last step as hypotheses. | 142 |
| `scripts/Axioms.lean` | `#print axioms` for 23 main results; output in `axioms.out`. | 28 |

## The Galois group of f₅ is A₅ (`GaloisGroup.lean`)

Mathlib has no theorem relating the factorisation of f mod p to cycle types of Frobenius. The proof avoids it:
1. **5 divides the order.** f₅ is irreducible, so a root generates a subfield of degree 5.
2. **3 divides the order.**
   - Modulo 13, f₅ = (X³ + 6X² + 4X − 6)(X² + 6X − 1), and the cubic has no root in 𝔽₁₃.
   - In any Galois number field K where f₅ splits, the residue field of a prime above 13 contains the reductions of the roots of f₅, hence a root of the cubic. So 3 divides the residue degree f.
   - f divides [K : ℚ] by the fundamental identity e·f·g = [K : ℚ] (Mathlib's `Ideal.ncard_primesOver_mul_ramificationIdxIn_mul_inertiaDegIn`).
3. **Every element is even.**
   - The Vandermonde determinant δ of the roots satisfies δ² = disc f₅ = 518348075378². So δ = ±518348075378 is rational and fixed by every σ.
   - But σ(δ) = sign(σ)·δ and δ ≠ 0, so every σ is even.
4. **Group theory.** A subgroup of A₅ of order divisible by 15 has index at most 4. A₅ is simple of order 60 > 4!, so the subgroup is A₅. The proof uses the normal core.

## How ρ is pinned down (`IsRho1951`)

- The projective kernel field is the field generated by the roots of f₅ (`projField_eq`).
- det ρ(Frob_Q) = χ(p) at every prime Q above p ≠ 1951.
- ρ is unramified outside 1951.
- The inertia invariants at a prime above 1951 are one-dimensional.

`ProjectiveImage.lean` proves that any such ρ has projective image A₅. The lifts of the projective representation with determinant χ are ρ, ρ''⊗χ³ and their quadratic twists:
- on inertia at 1951, ρ''⊗χ³ has eigenvalues χ⁴ and χ²;
- a quadratic twist unramified outside 1951 has eigenvalues η, ηχ with η of order 2.

Neither has a fixed vector, so only ρ remains. That uniqueness argument is in §2 of the note and is not formalized.

`ArtinConjecture1951` quantifies over all A with these properties. Their existence (`Rho1951Exists`) is Doud–Moore's construction and is not formalized. Without it, the universal statement would be vacuous in Lean.

## What `thmA2_of_isRho1951` still assumes (all explicit hypotheses)

| hypothesis | where it comes from in the note | formalizable now? |
|---|---|---|
| a cuspidal π and a finite S with Satake parameter ±{a,b} at p ∉ S (`hsign`) | H1 over E; Lemma 3.2 (Langlands' quadratic base change, strong multiplicity one, the Jacquet–Shalika pole); Step 1 (base change to EC) | no: automorphic representations of GL₂ are not in Mathlib |
| = {a,b} at p split in C (`hsplit`); the same ℓ-th powers at p inert in C (`hinert`) | H1 over C; Lemma 3.6 (cyclic base change of odd prime degree, local base change of principal series) | no |
| a cuspidal π matching ρ at almost all p makes L(ρ,s) entire (`hentire`) | proof of Theorem A, last step (L(π,s) entire, functional equations) | no |

The fourth input of the note's Step 2, that b/a has order dividing 2, 3 or 5, is now a theorem (`ArtinRep2.eig_ratio`).

## Roadmap

1. **Done here:**
   - the statement;
   - χ;
   - f₅ irreducible and totally real, with discriminant 2²·7²·71²·137²·1951⁴;
   - Gal(f₅) ≅ A₅;
   - the projective image of ρ is A₅, and its eigenvalue ratios have order 1, 2, 3 or 5;
   - Step 2 of Theorem A″ and the conditional theorem.
2. **Field discriminant 1951⁴:** the ring of integers of L₅, and maximality of ℤ[α] at 2, 7, 71, 137 (the index is 2·7·71·137). At 1951, ℤ[α] is already maximal, since f₅(X + 1561) is Eisenstein there.
3. **Uniqueness of ρ** from `IsRho1951` (the inertia argument above).
4. **Existence of ρ** (`Rho1951Exists`): the A₅-extension, the lift to SL(2,5) × C₅, and the field K₂₄. Months of work.
5. **The automorphic inputs** of `thmA2`: base change for GL₂ and strong multiplicity one are research-level formalization projects far beyond current Mathlib.
6. **H1 itself is open**, so no formal proof of `ArtinConjecture1951` can come from this project.

## Building

On a machine with network access, with `elan` installed:

    lake exe cache get    # Mathlib oleans for commit 59109b97
    lake build            # the ten modules, about a minute after the cache
    lake env lean scripts/Axioms.lean
    lake env leanchecker Artin1951.GaloisGroup   # kernel replay, one module at a time

How it was built here:
- The workspace could not reach GitHub releases or the Mathlib cache.
- Lean v4.36.0-rc1 was compiled from its source tag (`lean --version` reports 4.36.0, commit `c9afcdd`).
- The about 2 850 Mathlib modules this project imports, and their dependencies (Batteries, Aesop, Qq, ProofWidgets, Plausible, LeanSearchClient, ImportGraph, Cli at the revisions of Mathlib's manifest), were compiled with `lake build` on two cores.
- `build_clean.log` is a clean build of the ten project modules; `build_final.log` is the last build, after a docstring edit in `Statement.lean`.

The only warnings are Lake's suggestion to add `module` to each file, since Mathlib now uses the module system.

## Relation to the CFSG formalization (AxiomMath/CFSG, 27 October 2026)

The finite group theory used here is small:
- A₅ is simple (Mathlib);
- its element orders (proved here by `decide +kernel`);
- its subgroups of index at most 4 (proved here).

CFSG does not bear on H1.
