import Artin1951

/-! Prints the axioms used by the main results.  Run with `lake env lean scripts/Axioms.lean`.
Expected: only `propext`, `Classical.choice`, `Quot.sound` (no `sorryAx`, no `Lean.ofReduceBool`). -/

#print axioms Artin1951.orderOf_three
#print axioms Artin1951.chi_three
#print axioms Artin1951.chi_two
#print axioms Artin1951.chi_neg_one
#print axioms Artin1951.f5_real_splits
#print axioms Artin1951.f5_irreducible
#print axioms Artin1951.f5Q_irreducible
#print axioms Artin1951.resultant_f5Q
#print axioms Artin1951.discr_f5Q
#print axioms Artin1951.det_vandermonde_sq
#print axioms Artin1951.fifteen_dvd_finrank
#print axioms Artin1951.sign_galPerm
#print axioms Artin1951.galF5MulEquivA5
#print axioms Artin1951.card_galF5
#print axioms Artin1951.finrank_splittingField_f5Q
#print axioms Artin1951.ArtinRep2.projImageEquivA5
#print axioms Artin1951.ArtinRep2.card_projImage
#print axioms Artin1951.alternatingGroup_five_orders
#print axioms Artin1951.sign_core
#print axioms Artin1951.stepTwo
#print axioms Artin1951.thmA2
#print axioms Artin1951.ArtinRep2.eig_ratio
#print axioms Artin1951.thmA2_of_isRho1951
