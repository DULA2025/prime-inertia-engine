# Summary of changes for run e9341f9b-8cd8-4c24-95a2-87c2507f5edc
I formalized and proved the requested theorems in `RequestProject/Main.lean`. The project now builds cleanly and every theorem depends only on the standard axioms (`propext`, `Classical.choice`, `Quot.sound`); no `sorry` remains in any active code (the only `sorry` occurrences left are inside explanatory comments preserving the original false drafts).

Proved as stated (after minor syntax fixes for the current Mathlib):
- `theorem_1_3` — for prime p ≥ 3, both p−1 and p+1 are <p-smooth.
- `theorem_1_4` — existence of two <p-smooth numbers differing by 2.
- `theorem_1_5` — explicit prime-factorization form. Fixes: `Nat.primesBelow p` is already a `Finset`, so the spurious `.toFinset` was removed, and the `∏ q in s` notation was updated to `∏ q ∈ s`.
- `theorem_1_8` — n in (p, 2p) is prime iff it is not <p-smooth.
- `not_smooth_of_coprime_wheel` — a helper I added: coprimality with the product of all primes below p certifies n is not <p-smooth.

Issues found and corrected (the original drafts were mathematically false — I verified counterexamples computationally, kept the originals as commented-out text with explanations, and supplied corrected, proven versions):
- `theorem_1_9` — the original ("midpoint of two <p-smooth neighbours is prime") is false: p=7, u=8, v=10 are both <7-smooth yet u+1=9 is not prime (three consecutive smooth numbers 8,9,10 can exist). The corrected version certifies primality of n ∈ (p, 2p) via coprimality with the product of all primes below p.
- `theorem_2_1` (band factorization) — the original strict upper bound `q < ((k+1)*p)/m` is false under truncated natural-number division (e.g. p=3, k=4, n=14 gives q=7, m=2 with ((k+1)*p)/m = 15/2 = 7). Corrected to `q ≤ ((k+1)*p)/m`. (Its `hp : Nat.Prime p` is unused but kept for fidelity, as noted in a comment.)
- `theorem_2_2` (small-wheel certification) — the original is false: it derived "n not <p-smooth" from neighbour smoothness via the unsound claim that three consecutive smooth numbers cannot exist (counterexample p=11, k=4, u=48, v=50, n=49=7², gcd(49,6)=1, but 49 is not prime). The corrected version states the certificate directly for the candidate n, taking the genuinely required hypothesis that n is not <p-smooth, and then the small wheel ∏ primes ≤ k correctly certifies primality (using the corrected `theorem_2_1`).

Each false statement is preserved verbatim in comments next to its replacement, with the counterexample and the reason it fails documented in the docstring.