import Mathlib

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 20000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

set_option pp.fullNames true
set_option pp.structureInstances true
set_option pp.coercions.types true
set_option pp.funBinderTypes true
set_option pp.letVarTypes true
set_option pp.piBinderTypes true

set_option grind.warning false

/-
Theorem 1.3 (your working version)
For any prime p ≥ 3, both p-1 and p+1 are <p-smooth.
-/
theorem theorem_1_3 (p : ℕ) (hp : Nat.Prime p) (hp_ge3 : 3 ≤ p) :
    (∀ q, q.Prime → q ∣ (p - 1) → q < p) ∧
    (∀ q, q.Prime → q ∣ (p + 1) → q < p) := by
  refine' ⟨ fun q hq hq' => _, fun q hq hq' => _ ⟩
  · exact lt_of_le_of_lt (Nat.le_of_dvd (Nat.sub_pos_of_lt hp.one_lt) hq') (Nat.pred_lt hp.ne_zero)
  · rcases hq' with ⟨_ | _ | k, hk⟩ <;>
      rcases hq.eq_two_or_odd' with rfl | ⟨m, rfl⟩ <;>
      rcases hp.eq_two_or_odd' with rfl | ⟨n, rfl⟩ <;>
      simp_all +arith +decide [parity_simps]
    · omega
    · grind

/- Theorem 1.4 -/
theorem theorem_1_4 (p : ℕ) (hp : Nat.Prime p) (hp_ge3 : 3 ≤ p) :
    ∃ u v : ℕ, (∀ q, q.Prime → q ∣ u → q < p) ∧
                 (∀ q, q.Prime → q ∣ v → q < p) ∧ v - u = 2 := by
  refine' ⟨p - 1, p + 1, _, _, by omega⟩
  · intro q hq hdvd
    exact (theorem_1_3 p hp hp_ge3).1 q hq hdvd
  · intro q hq hdvd
    exact (theorem_1_3 p hp hp_ge3).2 q hq hdvd

/-
Theorem 1.5 (Explicit prime factorization form).

   Note: `Nat.primesBelow p` already has type `Finset ℕ`, so the spurious
   `.toFinset` from the informal draft has been removed, and the `∏ q ∈ s`
   notation has been updated to `∏ q ∈ s` for the current Mathlib version.
-/
theorem theorem_1_5 (p : ℕ) (hp : Nat.Prime p) (hp_ge3 : 3 ≤ p) :
    ∃ (aq bq : ℕ → ℕ),
      p - 1 = ∏ q ∈ Nat.primesBelow p, q ^ (aq q) ∧
      p + 1 = ∏ q ∈ Nat.primesBelow p, q ^ (bq q) ∧
      (∏ q ∈ Nat.primesBelow p, q ^ (bq q)) -
      (∏ q ∈ Nat.primesBelow p, q ^ (aq q)) = 2 := by
  refine' ⟨ fun q => Nat.factorization ( p - 1 ) q, fun q => Nat.factorization ( p + 1 ) q, _, _, _ ⟩ <;> norm_num at *;
  · conv_lhs => rw [ ← Nat.factorization_prod_pow_eq_self ( Nat.sub_ne_zero_of_lt hp.one_lt ) ] ;
    refine' Finset.prod_subset _ _ <;> simp +contextual [ Finset.subset_iff, Nat.mem_primesBelow ];
    · exact fun q hq hq' hq'' => lt_of_le_of_lt ( Nat.le_of_dvd ( Nat.sub_pos_of_lt hp.one_lt ) hq' ) ( Nat.pred_lt hp.ne_zero );
    · exact fun x hx₁ hx₂ hx₃ => Or.inr <| Nat.factorization_eq_zero_of_not_dvd fun hx₄ => absurd ( hx₃ hx₄ ) <| Nat.sub_ne_zero_of_lt hp.one_lt;
  · conv_lhs => rw [ ← Nat.factorization_prod_pow_eq_self ( by positivity : ( p + 1 ) ≠ 0 ) ] ;
    refine' Finset.prod_subset _ _ <;> intro q _ <;> simp_all +decide [ Nat.primesBelow ];
    · have := theorem_1_3 p hp hp_ge3; have := this.2 q; aesop;
    · exact fun h => Or.inr <| Nat.factorization_eq_zero_of_not_dvd h;
  · -- By definition of $p.primesBelow$, we know that every prime factor of $p-1$ and $p+1$ is in $p.primesBelow$.
    have h_factors : (∏ q ∈ p.primesBelow, q ^ (Nat.factorization (p + 1) q)) = p + 1 ∧ (∏ q ∈ p.primesBelow, q ^ (Nat.factorization (p - 1) q)) = p - 1 := by
      constructor;
      · conv_rhs => rw [ ← Nat.factorization_prod_pow_eq_self ( by positivity : ( p + 1 ) ≠ 0 ) ] ;
        rw [ Finsupp.prod_of_support_subset ] <;> norm_num [ Nat.primesBelow ];
        intro q hq; simp_all +decide ;
        have := theorem_1_3 p hp hp_ge3; have := this.2 q hq.1 hq.2; aesop;
      · conv_rhs => rw [ ← Nat.factorization_prod_pow_eq_self ( Nat.sub_ne_zero_of_lt hp.one_lt ) ] ;
        rw [ Finsupp.prod_of_support_subset ] <;> norm_num [ Nat.primesBelow ];
        exact fun q hq => Finset.mem_filter.mpr ⟨ Finset.mem_range.mpr ( Nat.lt_of_le_of_lt ( Nat.le_of_mem_primeFactors hq ) ( Nat.pred_lt hp.ne_zero ) ), Nat.prime_of_mem_primeFactors hq ⟩;
    omega

/- Theorem 1.8 -/
theorem theorem_1_8 (p n : ℕ) (hp : Nat.Prime p) (hp_lt_n : p < n) (n_lt_2p : n < 2 * p) :
    Nat.Prime n ↔ ¬ (∀ q, q.Prime → q ∣ n → q < p) := by
  have hp2 := hp.two_le
  constructor
  · intro hn_prime h_smooth
    have := h_smooth n hn_prime (dvd_refl n)
    omega
  · intro h_not_smooth
    by_contra h_not_prime
    apply h_not_smooth
    intro q hq hdvd
    by_contra hge
    have hge' : p ≤ q := by omega
    have hqn : q ≤ n := Nat.le_of_dvd (by omega) hdvd
    have hdiv : n / q = 1 := by
      have h1 : n / q < 2 := Nat.div_lt_of_lt_mul (by omega)
      have h2 : 1 ≤ n / q := (Nat.one_le_div_iff (by omega)).mpr hqn
      omega
    have hnq : n = q := by rw [← Nat.mul_div_cancel' hdvd, hdiv, mul_one]
    rw [hnq] at h_not_prime
    exact h_not_prime hq

/-
Coprimality with the product of all primes below `p` (the "full wheel")
    certifies that `n` is **not** `<p`-smooth: every prime factor of `n` is `≥ p`.
-/
theorem not_smooth_of_coprime_wheel (p n : ℕ) (hn : 1 < n)
    (hcop : Nat.gcd n (∏ r ∈ Nat.primesBelow p, r) = 1) :
    ¬ (∀ q, q.Prime → q ∣ n → q < p) := by
  intro h
  obtain ⟨q, hq_prime, hq_div_n⟩ : ∃ q, Nat.Prime q ∧ q ∣ n := by
    exact Nat.exists_prime_and_dvd hn.ne';
  refine' Nat.Prime.not_dvd_one hq_prime ( hcop ▸ Nat.dvd_gcd hq_div_n _ );
  exact Finset.dvd_prod_of_mem _ ( by simp [ Nat.mem_primesBelow, hq_prime, h q hq_prime hq_div_n ] )

/- Theorem 1.9.

   The original draft is FALSE: with `p = 7`, `u = 8`, `v = 10` we have
   `p < u`, `v < 2*p`, `v - u = 2`, and both `u` and `v` are `<7`-smooth
   (`8 = 2^3`, `10 = 2·5`), yet `u + 1 = 9 = 3^2` is **not** prime.
   The flaw: three consecutive `<p`-smooth numbers (`8, 9, 10`) can exist, so the
   neighbour smoothness of `u` and `v` does not force `u + 1` to be non-smooth.

   It is preserved (commented out) below, followed by a corrected version that
   replaces the unsound smoothness derivation by a coprimality (full-wheel)
   certificate, which is exactly the condition that makes the midpoint prime. -/
-- theorem theorem_1_9 (p u v : ℕ) (hp : Nat.Prime p)
--     (hu : p < u) (hv : v < 2 * p) (hdiff : v - u = 2)
--     (hu_smooth : ∀ q, q.Prime → q ∣ u → q < p)
--     (hv_smooth : ∀ q, q.Prime → q ∣ v → q < p) :
--     Nat.Prime (u + 1) := by
--   sorry  -- FALSE, see counterexample above

/-- Corrected Theorem 1.9: a number `n` strictly between `p` and `2*p` that is
    coprime to the product of all primes below `p` is itself prime. -/
theorem theorem_1_9 (p n : ℕ) (hp : Nat.Prime p) (hp_lt_n : p < n) (n_lt_2p : n < 2 * p)
    (h_gcd_one : Nat.gcd n (∏ r ∈ Nat.primesBelow p, r) = 1) :
    Nat.Prime n := by
  exact (theorem_1_8 p n hp hp_lt_n n_lt_2p).mpr
    (not_smooth_of_coprime_wheel p n (by omega) h_gcd_one)

/-
Theorem 2.1 (Band factorization).

   Note: the original draft asserted the strict upper bound `q < ((k+1)*p)/m`,
   which is FALSE under truncated natural-number division (e.g. `p = 3`, `k = 4`,
   `n = 14`: the only valid factor is `q = 7`, `m = 2`, but `((k+1)*p)/m = 15/2 = 7`,
   so `q < 7` fails). The bound has been corrected to `q ≤ ((k+1)*p)/m`.

   (The hypothesis `hp : Nat.Prime p` is kept for fidelity to the user's statement,
   but it turns out to be unnecessary for this lemma.)
-/
theorem theorem_2_1 (p k n : ℕ) (hp : Nat.Prime p) (hk_ge2 : 2 ≤ k)
    (hn : k * p < n) (hn_upper : n < (k + 1) * p)
    (h_not_smooth : ¬ (∀ q, q.Prime → q ∣ n → q < p))
    (h_comp : ¬ Nat.Prime n) :
    ∃ m q, 2 ≤ m ∧ m ≤ k ∧ Nat.Prime q ∧ q > p ∧ n = m * q ∧
           (k * p) / m < q ∧ q ≤ ((k + 1) * p) / m := by
  -- Set q = the prime factor from exists_prime_and_dvd, and show p < q: by_contra h with q ≤ p.
  obtain ⟨q, hq_prime, hq_dvd, hq_ge_p⟩ : ∃ q, Nat.Prime q ∧ q ∣ n ∧ p ≤ q := by
    grind;
  cases' hq_dvd with m hm;
  refine' ⟨ m, q, _, _, hq_prime, _, _, _, _ ⟩ <;> try nlinarith;
  · rcases m with ( _ | _ | m ) <;> simp_all +decide;
  · cases lt_or_eq_of_le hq_ge_p <;> simp_all +decide;
    nlinarith [ show m = k by nlinarith ];
  · exact Nat.div_lt_of_lt_mul <| by nlinarith;
  · rw [ Nat.le_div_iff_mul_le ] <;> nlinarith

/-
Theorem 2.2 (Small wheel certification).

   The original draft (commented out below) is FALSE: it tried to derive
   `n` not being `<p`-smooth from the smoothness of the neighbours `u` and `v`,
   via the unsound claim that three consecutive `<p`-smooth numbers cannot exist.
   Counterexample: `p = 11`, `k = 4`, `u = 48`, `v = 50` (both `<11`-smooth),
   `n = 49 = 7^2`, `gcd(49, ∏ primes ≤ 4) = gcd(49, 6) = 1`, yet `49` is not prime.
   The small wheel `∏ primes ≤ k` only removes prime factors `≤ k`; it cannot
   detect the factor `7 ∈ (k, p)`.

   Corrected version: state the certificate directly for the candidate `n`, taking
   the (genuinely required) hypothesis that `n` is not `<p`-smooth.  With the small
   wheel `∏ primes ≤ k` this then correctly certifies primality, because Theorem
   2.1 forces any composite non-smooth `n` to have a factor `m ≤ k`, hence a prime
   factor `≤ k` shared with the wheel.

   Original (FALSE) statement, preserved for the record:
     theorem theorem_2_2 (p k u v : ℕ) (hp : Nat.Prime p) (hk : 1 ≤ k)
       (hu : k * p < u) (hv : v < (k + 1) * p) (hdiff : v - u = 2)
       (hu_smooth : ∀ q, q.Prime → q ∣ u → q < p)
       (hv_smooth : ∀ q, q.Prime → q ∣ v → q < p) :
       let n := (u + v) / 2
       Nat.gcd n (∏ r ∈ Nat.primesBelow (k + 1), r) = 1 → Nat.Prime n
-/

/-- Corrected Theorem 2.2: if `n` lies in the band `(k*p, (k+1)*p)`, is not
    `<p`-smooth, and is coprime to the small wheel `∏ primes ≤ k`
    (= `∏ r ∈ Nat.primesBelow (k+1), r`), then `n` is prime. -/
theorem theorem_2_2 (p k n : ℕ) (hp : Nat.Prime p) (hk : 1 ≤ k)
    (hn : k * p < n) (hn_upper : n < (k + 1) * p)
    (h_not_smooth : ¬ (∀ q, q.Prime → q ∣ n → q < p))
    (h_gcd_one : Nat.gcd n (∏ r ∈ Nat.primesBelow (k + 1), r) = 1) :
    Nat.Prime n := by
  -- By contradiction, assume $n$ is not prime.
  by_contra h_not_prime;
  -- Apply theorem_2_1 to obtain m and q with 2 ≤ m, m ≤ k, q prime, q > p, n = m*q, plus bounds (ignore the bounds).
  obtain ⟨m, q, hm_ge2, hm_le_k, hq_prime, hq_gt_p, hn_eq_mq, hm_bound, hq_bound⟩ : ∃ m q, 2 ≤ m ∧ m ≤ k ∧ Nat.Prime q ∧ q > p ∧ n = m * q ∧ (k * p) / m < q ∧ q ≤ ((k + 1) * p) / m := by
    by_cases hk_ge2 : 2 ≤ k;
    · exact theorem_2_1 p k n hp hk_ge2 hn hn_upper h_not_smooth h_not_prime;
    · interval_cases k ; simp_all +decide;
      exact absurd ( theorem_1_8 p n hp hn hn_upper ) ( by aesop );
  -- Since $m$ is a factor of $n$ and $n$ is not prime, $m$ must have a prime factor $r$ such that $r \leq m \leq k$.
  obtain ⟨r, hr_prime, hr_div_m⟩ : ∃ r, Nat.Prime r ∧ r ∣ m ∧ r ≤ k := by
    exact ⟨ Nat.minFac m, Nat.minFac_prime ( by linarith ), Nat.minFac_dvd m, Nat.le_trans ( Nat.minFac_le ( by linarith ) ) hm_le_k ⟩;
  exact Nat.Prime.not_dvd_one hr_prime ( h_gcd_one ▸ Nat.dvd_gcd ( hn_eq_mq.symm ▸ dvd_mul_of_dvd_left hr_div_m.1 _ ) ( Finset.dvd_prod_of_mem _ ( Nat.mem_primesBelow.mpr ⟨ by linarith, hr_prime ⟩ ) ) )