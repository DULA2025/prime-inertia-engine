import Mathlib
import EisensteinIntegers
import EisensteinTheta

/-!
# Bridge between `repCount` and `eisNormCount`

This file defines the finset of Eisenstein integers of a given norm,
counts them, and proves the count equals `EisensteinTheta.repCount`.

## Definitions

* `eisNormSet n` : the finset of Eisenstein integers with norm equal to `n`.
* `eisNormCount n` : the cardinality of `eisNormSet n`.

## Main result

* `repCount_eq_eisNormCount` : `repCount n = eisNormCount n`.
  The bijection is `(a, b) ↦ ⟨a, -b⟩`, since `a² + ab + b² = a² - a(-b) + (-b)²`.
-/

namespace EisensteinThetaBridge

open Eisenstein EisensteinTheta

/-- The finset of Eisenstein integers with norm equal to `n`.
We bound the search by `|a|, |b| ≤ n + 1`. -/
def eisNormSet (n : ℕ) : Finset Eisenstein :=
  ((Finset.Icc (-(↑n + 1 : ℤ)) (↑n + 1) ×ˢ
    Finset.Icc (-(↑n + 1 : ℤ)) (↑n + 1)).image
      (fun p : ℤ × ℤ => (⟨p.1, p.2⟩ : Eisenstein))).filter
    (fun z => Eisenstein.norm z = (↑n : ℤ))

/-- The count of Eisenstein integers with norm equal to `n`. -/
def eisNormCount (n : ℕ) : ℕ := (eisNormSet n).card

/-- The bijection map from `ℤ × ℤ` pairs in `repSet` to Eisenstein integers:
`(a, b) ↦ ⟨a, -b⟩`. -/
private def toEis (p : ℤ × ℤ) : Eisenstein := ⟨p.1, -p.2⟩

/-- The inverse map: `⟨a, b⟩ ↦ (a, -b)`. -/
private def fromEis (z : Eisenstein) : ℤ × ℤ := (z.a, -z.b)

/-
`repCount n = eisNormCount n` for all `n`.
-/
theorem repCount_eq_eisNormCount (n : ℕ) :
    EisensteinTheta.repCount n = eisNormCount n := by
  -- To prove the equality of the cardinalities, we show that the mapping between the sets is bijective.
  have h_bij : Finset.image toEis (repSet n) = eisNormSet n := by
    ext z
    simp [toEis, eisNormSet, repSet];
    constructor <;> intro h;
    · rcases h with ⟨ a, b, ⟨ ⟨ ⟨ ha₁, ha₂ ⟩, ⟨ hb₁, hb₂ ⟩ ⟩, hab ⟩, rfl ⟩ ; exact ⟨ ⟨ a, -b, ⟨ ⟨ ha₁, ha₂ ⟩, ⟨ by linarith, by linarith ⟩ ⟩, rfl ⟩, by simpa [ Eisenstein.norm ] using by linarith ⟩ ;
    · rcases h with ⟨ ⟨ a, b, h, rfl ⟩, h' ⟩ ; use a, -b; simp_all +decide [ Eisenstein.norm ] ;
      lia;
  convert congr_arg Finset.card h_bij using 1;
  rw [ Finset.card_image_of_injective ];
  · rfl;
  · exact fun x y h => by injection h with h₁ h₂; aesop;

end EisensteinThetaBridge