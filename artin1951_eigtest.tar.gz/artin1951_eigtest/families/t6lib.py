import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Shared pieces for the order-64 tests (calib23_t6a.py, calib23_t6b.py): the level components O/2^e O, coset
projections between levels, step values of the characters N^j mod 2^e, relator walks (full and lean), tree
normalization, U on whole cochains, GR(2^k, 4) helpers.  The classes and walks are those of calib23_t4.py and
calib23_t5b.py, made generic in the modulus; CompPow2(4) and CompPow2(5) index cosets exactly as Comp16 and Comp32.
Author: Dula."""
import sys, os
sys.path.insert(0, _ROOT + "/families"); sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
import numpy as np, numba as nb
import gf
from sparse_h1 import MUL, INV

# ---------------------------------------------------------------- O/2^e O
def _roots(Q):
    """The 2-adic roots of t^2 - t + 2 mod Q = 2^e: (r_v, r_vbar) with r_v = 6 mod 16 (0 mod 2), r_vbar = 1 mod 2."""
    rv = [t for t in range(Q) if (t * t - t + 2) % Q == 0 and t % 2 == 0 and (Q < 16 or t % 16 == 6)]
    rb = [t for t in range(Q) if (t * t - t + 2) % Q == 0 and t % 2 == 1 and (Q < 16 or t % 16 == 11)]
    assert len(rv) == 1 and len(rb) == 1, (Q, rv, rb)
    return rv[0], rb[0]
class CompPow2:
    """O/QO = Z/Q x Z/Q (Q = 2^e): t -> r_v at v, t -> r_vbar at vbar.  P^1(Z/Q): 0..Q-1 = (1 : d), Q..3Q/2-2 = (2j : 1)
    for j = 1..Q/2-1, 3Q/2-1 = (0 : 1); index i_v + (3Q/2) i_vbar."""
    def __init__(self, e):
        self.e = e; self.Q = Q = 1 << e; self.typ = "O%d" % Q; self.p = 2
        self.r = _roots(Q); self.m1 = 3 * Q // 2; self.size = self.m1 * self.m1
        self.INVQ = {u: pow(u, -1, Q) for u in range(1, Q, 2)}
    def red(self, a):
        x, y = a; Q = self.Q
        return ((x + self.r[0] * y) % Q, (x + self.r[1] * y) % Q)
    def mul(self, a, b): Q = self.Q; return ((a[0] * b[0]) % Q, (a[1] * b[1]) % Q)
    def add(self, a, b): Q = self.Q; return ((a[0] + b[0]) % Q, (a[1] + b[1]) % Q)
    def iszero(self, a): return a == (0, 0)
    def inv(self, a): return (self.INVQ[a[0] % self.Q], self.INVQ[a[1] % self.Q])
    def zero(self): return (0, 0)
    def one(self): return (1, 1)
    def _norm1(self, c, d):
        Q = self.Q; c %= Q; d %= Q
        if c % 2: return (d * self.INVQ[c]) % Q, c
        assert d % 2, "not a primitive row"
        q = (c * self.INVQ[d]) % Q
        return (self.m1 - 1 if q == 0 else Q + q // 2 - 1), d
    def normalize(self, c, d):
        i1, l1 = self._norm1(c[0], d[0]); i2, l2 = self._norm1(c[1], d[1])
        return i1 + self.m1 * i2, (l1, l2)
    def _rep1(self, i):
        Q = self.Q
        if i < Q: return (1, i)
        return (0, 1) if i == self.m1 - 1 else (2 * (i - Q + 1), 1)
    def rep(self, i):
        a = self._rep1(i % self.m1); b = self._rep1(i // self.m1)
        return ((a[0], b[0]), (a[1], b[1]))
    def units(self): return [(a, b) for a in range(1, self.Q, 2) for b in range(1, self.Q, 2)]
    def selftest(self):
        assert all((t * t - t + 2) % self.Q == 0 for t in self.r) and self.red((0, 1)) == self.r
        for i in range(self.size):
            c, d = self.rep(i); j, l = self.normalize(c, d); assert j == i and l == (1, 1)
        return True
def pi1(Chi, Clo):
    """P^1(Z/Q_hi) -> P^1(Z/Q_lo) on indices (normalized representatives reduce to normalized representatives)."""
    out = np.zeros(Chi.m1, dtype=np.int64)
    for i in range(Chi.m1):
        c, d = Chi._rep1(i); j, l = Clo._norm1(c % Clo.Q, d % Clo.Q); assert l == 1
        out[i] = j
    return out
def coset_projection(Lhi, Llo):
    """pi: cosets of Lhi -> cosets of Llo; component 0 is O/2^e O, the others are equal."""
    Chi, Clo = Lhi.comps[0], Llo.comps[0]; P1 = pi1(Chi, Clo)
    xs = np.arange(Lhi.n, dtype=np.int64)
    i0 = (xs // Lhi.strides[0]) % Lhi.sizes[0]
    PI = P1[i0 % Chi.m1] + Clo.m1 * P1[i0 // Chi.m1]
    for k in range(1, len(Lhi.comps)):
        assert Lhi.sizes[k] == Llo.sizes[k]
        PI = PI + ((xs // Lhi.strides[k]) % Lhi.sizes[k]) * Llo.strides[k]
    return PI

# ---------------------------------------------------------------- step values
def leg23(l): return 0 if pow(int(l), 11, 23) == 1 else 1
def step_scalars(L):
    """Per move s (2G of them) and coset x: Nl[s, x] = N(l) mod Q of the local scalar at the O/QO component (uint8 if
    Q <= 256) and sg[s, x] = parity of the number of Legendre signs -1 at the components above 23.  Checked against
    the level tables.  The engine step value of the character with engine exponent a is (-1)^sg N(l)^a mod Q."""
    from o7 import GEN, GINV
    n = L.n; G = len(L.gens); C0 = L.comps[0]; Q = C0.Q
    mats = [GEN[g] for g in L.gens] + [GINV[g] for g in L.gens]
    xs = np.arange(n, dtype=np.int64)
    Nl = np.zeros((2 * G, n), dtype=np.uint8 if Q <= 256 else np.int64); sg = np.zeros((2 * G, n), dtype=np.uint8)
    for s, Mt in enumerate(mats):
        idx = np.zeros(n, dtype=np.int64)
        for k, c in enumerate(L.comps):
            a, b, cm, dm = tuple(c.red(e) for e in Mt)
            lj = np.zeros(c.size, dtype=np.int64); lv = np.zeros(c.size, dtype=np.int64)
            for i in range(c.size):
                cc, dd = c.rep(i)
                nc = c.add(c.mul(cc, a), c.mul(dd, cm)); nd = c.add(c.mul(cc, b), c.mul(dd, dm))
                j, l = c.normalize(nc, nd); lj[i] = j
                lv[i] = (l[0] * l[1]) % Q if k == 0 else leg23(l)
            ik = (xs // L.strides[k]) % L.sizes[k]
            idx += lj[ik] * L.strides[k]
            if k == 0: Nl[s] = lv[ik]
            else: sg[s] ^= lv[ik].astype(np.uint8)
        assert (idx == L.NXT[s]).all(), "local action differs from the level tables"
    return Nl, sg
def char_table(Nl, sg, a, Q):
    """Engine step values (-1)^sg N(l)^a mod Q as an int64 table (a may be negative)."""
    pw = np.zeros(Q, dtype=np.int64)
    for u in range(1, Q, 2): pw[u] = pow(u, a, Q) if a >= 0 else pow(pow(u, -1, Q), -a, Q)
    v = pw[Nl.astype(np.int64)]
    return np.where(sg == 1, (Q - v) % Q, v).astype(np.int64)
def char_table_u8(Nl, sg, a, Q):
    assert Q <= 256
    return char_table(Nl, sg, a, Q).astype(np.uint8)

# ---------------------------------------------------------------- walks
@nb.njit(cache=True, parallel=True)
def rel_eval(nxt, nxv, tg, te, G, n, tree, W, M):
    nr, T = tg.shape
    out = np.zeros((nr * n, 4), dtype=np.int64); bad = np.zeros(n, dtype=np.int64)
    for x in nb.prange(n):
        for r in range(nr):
            a0 = 0; a1 = 0; a2 = 0; a3 = 0
            cur = np.int64(x); wt = np.int64(1)
            for jj in range(T):
                g = np.int64(tg[r, jj])
                if g < 0: break
                if te[r, jj] == 1:
                    u = g * n + cur; c = wt
                    wt = (wt * np.int64(nxv[g, cur])) % M; cur = np.int64(nxt[g, cur])
                else:
                    s = G + g
                    wt = (wt * np.int64(nxv[s, cur])) % M; cur = np.int64(nxt[s, cur])
                    u = g * n + cur; c = (M - wt) % M
                if tree[u]: continue
                a0 += c * np.int64(W[u, 0]); a1 += c * np.int64(W[u, 1]); a2 += c * np.int64(W[u, 2]); a3 += c * np.int64(W[u, 3])
            row = r * n + x
            out[row, 0] = a0 % M; out[row, 1] = a1 % M; out[row, 2] = a2 % M; out[row, 3] = a3 % M
            if cur != x: bad[x] += 1
    return out, bad.sum()
@nb.njit(cache=True, parallel=True)
def rel_bits(nxt, nxv, tg, te, G, n, tree, W, M, kbit):
    """Lean relator walk: per row, the F16 code of bit kbit of the four coefficients of R_M W, and the number of rows
    whose value is not divisible by 2^kbit (and of walks that do not close).  W may be uint8."""
    nr, T = tg.shape
    bits = np.zeros(nr * n, dtype=np.uint8); nd = np.zeros(n, dtype=np.int64); bad = np.zeros(n, dtype=np.int64)
    mlow = (np.int64(1) << kbit) - 1
    for x in nb.prange(n):
        for r in range(nr):
            a0 = 0; a1 = 0; a2 = 0; a3 = 0
            cur = np.int64(x); wt = np.int64(1)
            for jj in range(T):
                g = np.int64(tg[r, jj])
                if g < 0: break
                if te[r, jj] == 1:
                    u = g * n + cur; c = wt
                    wt = (wt * np.int64(nxv[g, cur])) % M; cur = np.int64(nxt[g, cur])
                else:
                    s = G + g
                    wt = (wt * np.int64(nxv[s, cur])) % M; cur = np.int64(nxt[s, cur])
                    u = g * n + cur; c = (M - wt) % M
                if tree[u]: continue
                a0 += c * np.int64(W[u, 0]); a1 += c * np.int64(W[u, 1]); a2 += c * np.int64(W[u, 2]); a3 += c * np.int64(W[u, 3])
            a0 %= M; a1 %= M; a2 %= M; a3 %= M
            if (a0 & mlow) or (a1 & mlow) or (a2 & mlow) or (a3 & mlow): nd[x] += 1
            row = r * n + x
            bits[row] = np.uint8(((a0 >> kbit) & 1) | (((a1 >> kbit) & 1) << 1) | (((a2 >> kbit) & 1) << 2) | (((a3 >> kbit) & 1) << 3))
            if cur != x: bad[x] += 1
    return bits, nd.sum(), bad.sum()
@nb.njit(cache=True)
def tree_normalize(nxt, nxv, G, n, root, par_x, par_g, Wf, M):
    """W = Wf - delta f with f(root) = 0 and W = 0 on the BFS tree; (delta f)(g, x) = nxv[g, x] f(nxt[g, x]) - f(x).
    Wf and the result: (G n, 4) arrays of the same dtype (values mod M)."""
    inv = np.zeros(M, dtype=np.int64)
    for a in range(1, M, 2):
        for b in range(1, M, 2):
            if (a * b) % M == 1: inv[a] = b
    f = np.zeros((n, 4), dtype=np.int64); seen = np.zeros(n, dtype=np.bool_)
    q = np.empty(n, dtype=np.int64); head = 0; tail = 0; bad = 0
    seen[root] = True; q[tail] = root; tail += 1
    while head < tail:
        x = q[head]; head += 1
        for g in range(G):
            y = nxt[g, x]
            if not seen[y]:
                seen[y] = True
                if par_x[y] != x or par_g[y] != g: bad += 1
                u = g * n + x; iv = inv[np.int64(nxv[g, x]) % M]
                for k in range(4): f[y, k] = (iv * (f[x, k] + np.int64(Wf[u, k]))) % M
                q[tail] = y; tail += 1
    W = np.empty_like(Wf)
    for g in range(G):
        for x in range(n):
            u = g * n + x; y = nxt[g, x]; c = np.int64(nxv[g, x]) % M
            for k in range(4): W[u, k] = ((np.int64(Wf[u, k]) - c * f[y, k] + f[x, k]) % M + M) % M
    return W, bad
@nb.njit(cache=True)
def tree_transport(nxt, nxv, G, n, root, par_x, par_g, M):
    lam = np.zeros(n, dtype=np.int64); seen = np.zeros(n, dtype=np.bool_)
    q = np.empty(n, dtype=np.int64); head = 0; tail = 0
    lam[root] = 1; seen[root] = True; q[tail] = root; tail += 1
    bad = 0
    while head < tail:
        x = q[head]; head += 1
        for g in range(G):
            y = nxt[g, x]
            if not seen[y]:
                seen[y] = True; lam[y] = (lam[x] * np.int64(nxv[g, x])) % M
                if par_x[y] != x or par_g[y] != g: bad += 1
                q[tail] = y; tail += 1
    return lam, bad
@nb.njit(cache=True, parallel=True)
def apply_U(cols, ptr, letters, nxt, nxv, tree, laminv, root, G, n, W, M):
    out = np.zeros_like(W); bad = np.zeros(cols.shape[0], dtype=np.int64)
    for k in nb.prange(cols.shape[0]):
        u = cols[k]; x = u % n
        a0 = 0; a1 = 0; a2 = 0; a3 = 0
        for p in range(2 * k, 2 * k + 2):
            cur = np.int64(root); wt = np.int64(1)
            for q in range(ptr[p], ptr[p + 1]):
                l = np.int64(letters[q])
                if l < G:
                    c = l * n + cur; coef = wt
                    wt = (wt * np.int64(nxv[l, cur])) % M; cur = np.int64(nxt[l, cur])
                else:
                    wt = (wt * np.int64(nxv[l, cur])) % M; cur = np.int64(nxt[l, cur])
                    c = (l - G) * n + cur; coef = (M - wt) % M
                if tree[c]: continue
                a0 += coef * W[c, 0]; a1 += coef * W[c, 1]; a2 += coef * W[c, 2]; a3 += coef * W[c, 3]
            if cur != root: bad[k] += 1
        li = laminv[x]
        out[u, 0] = (a0 % M) * li % M; out[u, 1] = (a1 % M) * li % M; out[u, 2] = (a2 % M) * li % M; out[u, 3] = (a3 % M) * li % M
    return out, bad.sum()

# ---------------------------------------------------------------- GR(2^k, 4) and F16 helpers
def naive(codes):
    codes = np.asarray(codes, dtype=np.uint8)
    return np.stack([(codes >> i) & 1 for i in range(4)], axis=-1).astype(np.int64)
def gr_mul(a, b, M):
    c = [0] * 7
    for i in range(4):
        for j in range(4): c[i + j] += int(a[i]) * int(b[j])
    c[0] += c[5]; c[1] += c[6]
    return [(c[i] - c[4]) % M for i in range(4)]
def gr_mulmat(code, M):
    a = naive([code])[0]
    return np.array([gr_mul(a, [1 if k == j else 0 for k in range(4)], M) for j in range(4)], dtype=np.int64).T
def scal(code, W, M): return (np.asarray(W, dtype=np.int64) @ gr_mulmat(int(code), M).T) % M
def to_code(Wl): return ((Wl[:, 0] & 1) | ((Wl[:, 1] & 1) << 1) | ((Wl[:, 2] & 1) << 2) | ((Wl[:, 3] & 1) << 3)).astype(np.uint8)
def bits_at(out, k): return to_code((out >> k) & 1)
def rank16(A):
    A = np.array(A, dtype=np.uint8, copy=True)
    return 0 if A.size == 0 else len(list(gf.rref16(A, gf.MUL16, gf.INV16)))
def solve_t(Tm, tstar):
    m, dd = Tm.shape
    Aug = np.concatenate([Tm, tstar[:, None]], axis=1).astype(np.uint8)
    piv = list(gf.rref16(Aug, MUL, INV))
    if any(p >= dd for p in piv): return None
    c = np.zeros(dd, dtype=np.uint8)
    for r, p in enumerate(piv): c[p] = Aug[r, dd]
    return c
