import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Level prime to 2: H^1(Gamma_0(n), V_{k,k} (x) eps) for PGL_2(O_E), E = Q(sqrt-7), 2 not dividing n, mod 2 and
mod 2^S, with Hecke operators T_pi, for the weight-k Bockstein tower of p2_tower.py.

Differences from vdec.py (Iwahori level 23*2*O_E, U_v and U_vbar):
  * the level is any FastLevel built from components prime to 2 (as in run_big.py).  The nebentypus eps of the level
    (engine convention eps^-1 o N for a form with character eps) takes values in mu_10 = {+-1} x mu_5 inside
    W(F16) = Z_2[zeta_5]: its order-5 part is the Teichmueller lift of FastLevel's F16 tables, its sign part a quadratic
    character given by bit functions on the components (bianchi4.quad_nxa).  A scalar (-1)^b X^j is stored as the index
    e = 5 b + j, X = zeta_5 = the class of x in GR(2^S, 4) = (Z/2^S)[x]/(x^4 + x^3 + x^2 + x + 1); mod 2 it is z^j;
  * Hecke operators T_pi with the N(pi) + 1 pieces of hecke.hecke_reps replace U_v, U_vbar; piece i has the weight
    eps(d_{alpha_i})^-1, as in vbianchi.FpHeckeV;
  * the relator walks, the mod-2 rows, the coboundaries and the Hecke kernels carry these scalars.
Conventions otherwise as in vbock.py and vdec.py: cochains on the non-tree edges; relator block equations
sum_j s_j w_j V(prefix_j) z(u_j) = 0; coboundaries delta m(g, x) = w V(g) m(xg) - m(x);
(T phi)(h) = sum_i eps(d_i)^-1 V(adj alpha_i) phi(h_i), read back through z = lam_x^-1 V(r_x)^-1 phi(h_{x,g}).
Author: Dula."""
import sys, time
sys.path.insert(0, _ROOT + "/families"); sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
import numpy as np, numba as nb
from sparse_h1 import FastLevel, MUL, INV, relator_arrays
from o7 import GEN, GINV, mmul, mdet, onorm, decompose
from bianchi4 import quad_nxa
from vbock import two_adic_root
from vdec import sym_decomposition, nzform, f2_sandwich, pieces, unpieces, symmat, _kmv, _smv2
from t6lib import gr_mul
import hecke, gf

# The scalar group is {+-1} x <tau>, tau of odd order ORD in W(F16): ORD = 5 (tau = X = zeta_5; the default, as before)
# or ORD = 15 (tau = omega X, omega the Teichmueller lift of the cube root of unity with code 12), set by P2_ORD.
# A scalar (-1)^b tau^j is stored as the index e = ORD b + j; the index of -1 is ORD.
import os
ORD = int(os.environ.get("P2_ORD", "5")); assert ORD in (5, 15)
if ORD == 5: POW16 = [1, 2, 4, 8, 15]          # z^j, z = zeta_5 mod 2 (codes of gf.py)
else:
    POW16 = [1]
    for _ in range(14): POW16.append(int(gf.MUL16[POW16[-1], gf.MUL16[12, 2]]))
    assert len(set(POW16)) == 15 and int(gf.MUL16[POW16[-1], gf.MUL16[12, 2]]) == 1
LOG16 = {c: j for j, c in enumerate(POW16)}

def scalar_tables(Q):
    """SMUL, SINV (index arithmetic), MZ[e] (4 x 4 matrix of multiplication by (-1)^b tau^j on GR coordinates), C16[e]."""
    n2 = 2 * ORD; one = [1, 0, 0, 0]; X = [0, 1, 0, 0]
    if ORD == 5: tau = X
    else:
        w = [0, 0, 1, 1]                                  # naive lift of the code 12 = X^2 + X^3 (a cube root of unity mod 2)
        for _ in range(4 * (Q.bit_length() + 2)): w = gr_mul(w, w, Q)       # w -> w^(16^m): the Teichmueller lift mod Q
        assert gr_mul(gr_mul(w, w, Q), w, Q) == one and [(a + b + c) % Q for a, b, c in zip(gr_mul(w, w, Q), w, one)] == [0, 0, 0, 0], "omega is not a primitive cube root of unity"
        assert [t & 1 for t in w] == [0, 0, 1, 1]
        tau = gr_mul(w, X, Q)
    pw = [one]
    for _ in range(ORD - 1): pw.append(gr_mul(pw[-1], tau, Q))
    assert gr_mul(pw[-1], tau, Q) == one, "tau^ORD != 1"
    SMUL = np.zeros((n2, n2), dtype=np.int64); SINV = np.zeros(n2, dtype=np.int64)
    MZ = np.zeros((n2, 4, 4), dtype=np.int64); C16 = np.zeros(n2, dtype=np.uint8)
    for e in range(n2):
        b, j = divmod(e, ORD)
        v = [int(t) % Q for t in pw[j]]
        if b: v = [(Q - t) % Q for t in v]
        MZ[e] = np.array([gr_mul(v, [1 if kk == i else 0 for kk in range(4)], Q) for i in range(4)], dtype=np.int64).T
        C16[e] = POW16[j]
        assert (int(v[0]) & 1) | ((int(v[1]) & 1) << 1) | ((int(v[2]) & 1) << 2) | ((int(v[3]) & 1) << 3) == POW16[j], "tau^j mod 2 is not the code POW16[j]"
        SINV[e] = ORD * b + (-j) % ORD
        for f in range(n2):
            b2, j2 = divmod(f, ORD); SMUL[e, f] = ORD * (b ^ b2) + (j + j2) % ORD
    for e in range(n2):
        for f in range(n2):
            assert ((MZ[e] @ MZ[f]) % Q == MZ[SMUL[e, f]]).all(), "scalar tables inconsistent"
    return SMUL, SINV, MZ, C16

# ---------------------------------------------------------------- numba kernels
@nb.njit(cache=True)
def _mm2(A, B):
    d = A.shape[0]; C = np.zeros((d, d), dtype=np.int64)
    for i in range(d):
        for k in range(d):
            if A[i, k] & 1:
                for j in range(d): C[i, j] ^= B[k, j] & 1
    return C

@nb.njit(cache=True)
def rows_mod2_s(nxt, nxe, Vg2, tg, te, G, n, colpos, dV, Tw, mul):
    """Fixed-width rows (cols int32 -1 padded, vals F16 codes) of the mod-2 block equations with F16 step scalars
    nxe; row (r n + x) dV + a, columns colpos[u] + b.  Returns cols, vals, number of relators that do not close."""
    nr, T = tg.shape; R = nr * n * dV
    cols = -np.ones((R, Tw), dtype=np.int32); vals = np.zeros((R, Tw), dtype=np.uint8)
    eu = np.empty(T, dtype=np.int64); EB = np.zeros((T, dV, dV), dtype=np.uint8)
    bad = 0
    for r in range(nr):
        for x in range(n):
            cur = x; w = np.uint8(1); m = 0
            M = np.zeros((dV, dV), dtype=np.int64)
            for i in range(dV): M[i, i] = 1
            for j in range(T):
                g = tg[r, j]
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; coef = w; blk = M.copy()
                    w = mul[w, nxe[g, cur]]; M = _mm2(M, Vg2[g]); cur = nxt[g, cur]
                else:
                    s = G + g; w = mul[w, nxe[s, cur]]; M = _mm2(M, Vg2[s]); cur = nxt[s, cur]
                    u = g * n + cur; coef = w; blk = M.copy()
                if colpos[u] < 0: continue
                t = -1
                for q in range(m):
                    if eu[q] == u: t = q
                if t < 0:
                    t = m; eu[m] = u; m += 1
                    for a in range(dV):
                        for b in range(dV): EB[t, a, b] = 0
                for a in range(dV):
                    for b in range(dV):
                        if blk[a, b] & 1: EB[t, a, b] ^= coef
            closed = cur == x and w == 1
            for a in range(dV):
                for b in range(dV):
                    if M[a, b] != (1 if a == b else 0): closed = False
            if not closed: bad += 1
            for a in range(dV):
                row = (r * n + x) * dV + a; kk = 0
                for t in range(m):
                    cb = colpos[eu[t]]
                    for b in range(dV):
                        if EB[t, a, b] != 0:
                            cols[row, kk] = cb + b; vals[row, kk] = EB[t, a, b]; kk += 1
    return cols, vals, bad

@nb.njit(cache=True)
def _zmul(Mz, src, a, dst, b, Q):
    for c in range(4):
        s = 0
        for c2 in range(4): s += Mz[c, c2] * src[a, c2]
        dst[b, c] = (dst[b, c] + s) % Q

@nb.njit(cache=True, parallel=True)
def vrel_eval_gr(nxt, SE, SMUL, MZ, Ag, Bg, tg, te, G, n, colpos, W, Q, d1, NEG):
    """R W mod Q for a cochain W (ncol, 4) of GR(Q, 4) coordinates: out (nr n dV, 4), Horner along each relator.
    Also the number of relators that do not close (coset, scalar index 0, matrix checked by the caller's data)."""
    nr, T = tg.shape; dV = d1 * d1
    out = np.zeros((nr * n * dV, 4), dtype=np.int64); bad = np.zeros(n, dtype=np.int64)
    for x in nb.prange(n):
        moves = np.empty(T, dtype=np.int64); ys = np.zeros((T + 1, dV, 4), dtype=np.int64)
        acc = np.zeros((dV, 4), dtype=np.int64); tmp = np.zeros((dV, 4), dtype=np.int64); Z = np.zeros((d1, d1, 4), dtype=np.int64)
        for r in range(nr):
            for j in range(T + 1):
                for a in range(dV):
                    for c in range(4): ys[j, a, c] = 0
            cur = np.int64(x); w = np.int64(0); L = 0
            for j in range(T):
                g = np.int64(tg[r, j])
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; pos = L; coef = w
                    w = SMUL[w, SE[g, cur]]; cur = np.int64(nxt[g, cur]); moves[L] = g; L += 1
                else:
                    s = G + g; w = SMUL[w, SE[s, cur]]; cur = np.int64(nxt[s, cur]); moves[L] = s; L += 1
                    u = g * n + cur; pos = L; coef = SMUL[w, NEG]
                cb = colpos[u]
                if cb < 0: continue
                Mz = MZ[coef]
                for a in range(dV): _zmul(Mz, W, cb + a, ys[pos], a, Q)
            if cur != x or w != 0: bad[x] += 1
            for a in range(dV):
                for c in range(4): acc[a, c] = ys[L, a, c]
            for j in range(L - 1, -1, -1):
                mv = moves[j]
                _kmv(Ag[mv], Bg[mv], acc, Z, tmp, Q, d1)
                for a in range(dV):
                    for c in range(4): acc[a, c] = (ys[j, a, c] + tmp[a, c]) % Q
            base = (r * n + x) * dV
            for a in range(dV):
                for c in range(4): out[base + a, c] = acc[a, c]
    return out, bad.sum()

@nb.njit(cache=True, parallel=True)
def t2_apply(ucols, ptr, letters, npc, nxt, nxe, cA, iA, cB, iB, vcA, viA, vcB, viB, wcode, ntidx, rcA, riA, rcB, riB,
             linv16, root, G, n, Y, d1, mul):
    """T mod 2 on a cochain Y (Nnt, d1, d1) of F16 codes in the adapted basis, evaluated on the edges ucols (npc pieces
    each, words in letters/ptr).  Returns out (len(ucols), d1, d1) and the number of piece words that do not close."""
    N = ucols.shape[0]; out = np.zeros((N, d1, d1), dtype=np.uint8); bad = np.zeros(N, dtype=np.int64)
    for k in nb.prange(N):
        u0 = ucols[k]; x0 = u0 % n
        Tmax = 0
        for p in range(npc * k, npc * k + npc):
            if ptr[p + 1] - ptr[p] > Tmax: Tmax = ptr[p + 1] - ptr[p]
        moves = np.empty(Tmax + 1, dtype=np.int64); ys = np.zeros((Tmax + 1, d1, d1), dtype=np.uint8)
        acc = np.zeros((d1, d1), dtype=np.uint8); tmp = np.zeros((d1, d1), dtype=np.uint8); tot = np.zeros((d1, d1), dtype=np.uint8)
        Z = np.zeros((d1, d1), dtype=np.uint8)
        for b in range(npc):
            p = npc * k + b
            for j in range(Tmax + 1):
                for i in range(d1):
                    for jj in range(d1): ys[j, i, jj] = 0
            cur = np.int64(root); w = np.uint8(1); L = 0
            for q in range(ptr[p], ptr[p + 1]):
                l = np.int64(letters[q])
                if l < G:
                    u = l * n + cur; pos = L; coef = w
                    w = mul[w, nxe[l, cur]]; cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                else:
                    w = mul[w, nxe[l, cur]]; cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                    u = (l - G) * n + cur; pos = L; coef = w
                e = ntidx[u]
                if e < 0: continue
                for i in range(d1):
                    for jj in range(d1): ys[pos, i, jj] ^= mul[coef, Y[e, i, jj]]
            if cur != root: bad[k] += 1
            for i in range(d1):
                for jj in range(d1): acc[i, jj] = ys[L, i, jj]
            for j in range(L - 1, -1, -1):
                mv = moves[j]
                _smv2(cA[mv], iA[mv], cB[mv], iB[mv], acc, Z, tmp, d1)
                for i in range(d1):
                    for jj in range(d1): acc[i, jj] = ys[j, i, jj] ^ tmp[i, jj]
            _smv2(vcA[b], viA[b], vcB[b], viB[b], acc, Z, tmp, d1)
            for i in range(d1):
                for jj in range(d1): tot[i, jj] ^= mul[wcode[b], tmp[i, jj]]
        _smv2(rcA[x0], riA[x0], rcB[x0], riB[x0], tot, Z, tmp, d1)
        for i in range(d1):
            for jj in range(d1): out[k, i, jj] = mul[linv16[x0], tmp[i, jj]]
    return out, bad.sum()

@nb.njit(cache=True, parallel=True)
def tq_apply(ucols, ptr, letters, npc, nxt, SE, SMUL, MZ, Ag, Bg, VaA, VaB, wE, colpos, laminvE, RiA, RiB, root, G, n, W, Q, d1, NEG):
    """T mod Q on a cochain W (ncol, 4) of GR coordinates, evaluated on the edges ucols; out (len(ucols) dV, 4)."""
    dV = d1 * d1; N = ucols.shape[0]
    out = np.zeros((N * dV, 4), dtype=np.int64); bad = np.zeros(N, dtype=np.int64)
    for k in nb.prange(N):
        u0 = ucols[k]; x0 = u0 % n
        Tmax = 0
        for p in range(npc * k, npc * k + npc):
            if ptr[p + 1] - ptr[p] > Tmax: Tmax = ptr[p + 1] - ptr[p]
        moves = np.empty(Tmax + 1, dtype=np.int64); ys = np.zeros((Tmax + 1, dV, 4), dtype=np.int64)
        acc = np.zeros((dV, 4), dtype=np.int64); tmp = np.zeros((dV, 4), dtype=np.int64); tot = np.zeros((dV, 4), dtype=np.int64)
        tmp2 = np.zeros((dV, 4), dtype=np.int64); Z = np.zeros((d1, d1, 4), dtype=np.int64)
        for b in range(npc):
            p = npc * k + b
            for j in range(Tmax + 1):
                for a in range(dV):
                    for c in range(4): ys[j, a, c] = 0
            cur = np.int64(root); w = np.int64(0); L = 0
            for q in range(ptr[p], ptr[p + 1]):
                l = np.int64(letters[q])
                if l < G:
                    u = l * n + cur; pos = L; coef = w
                    w = SMUL[w, SE[l, cur]]; cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                else:
                    w = SMUL[w, SE[l, cur]]; cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                    u = (l - G) * n + cur; pos = L; coef = SMUL[w, NEG]
                cb = colpos[u]
                if cb < 0: continue
                Mz = MZ[coef]
                for a in range(dV): _zmul(Mz, W, cb + a, ys[pos], a, Q)
            if cur != root: bad[k] += 1
            for a in range(dV):
                for c in range(4): acc[a, c] = ys[L, a, c]
            for j in range(L - 1, -1, -1):
                mv = moves[j]
                _kmv(Ag[mv], Bg[mv], acc, Z, tmp, Q, d1)
                for a in range(dV):
                    for c in range(4): acc[a, c] = (ys[j, a, c] + tmp[a, c]) % Q
            _kmv(VaA[b], VaB[b], acc, Z, tmp, Q, d1)
            for a in range(dV):
                for c in range(4): tmp2[a, c] = 0
            Mw = MZ[wE[b]]
            for a in range(dV): _zmul(Mw, tmp, a, tmp2, a, Q)
            for a in range(dV):
                for c in range(4): tot[a, c] = (tot[a, c] + tmp2[a, c]) % Q
        _kmv(RiA[x0], RiB[x0], tot, Z, tmp, Q, d1)
        for a in range(dV):
            for c in range(4): tmp2[a, c] = 0
        Ml = MZ[laminvE[x0]]
        for a in range(dV): _zmul(Ml, tmp, a, tmp2, a, Q)
        for a in range(dV):
            for c in range(4): out[k * dV + a, c] = tmp2[a, c]
    return out, bad.sum()

@nb.njit(cache=True)
def _tree_scalars(order, parx, parg, SE, SMUL, n):
    lam = np.zeros(n, dtype=np.int64)
    for t in range(1, order.shape[0]):
        y = order[t]; x = parx[y]; g = parg[y]
        lam[y] = SMUL[lam[x], SE[g, x]]
    return lam

# ---------------------------------------------------------------- the level
class P2Level:
    """comps: bmf.Comp components of the level (prime to 2); EC: F16 tables of the order-5 part of the level character
    (as run_big.py) or None; bitfuns: per component, a function scalar -> 0/1 (the sign part) or None."""
    def __init__(self, k, S, comps, EC, bitfuns, name, verbose=True):
        t0 = time.time()
        self.k, self.S, self.Q = k, S, 1 << S
        self.m = m = k - 2; self.d1 = d1 = m + 1; self.dV = dV = d1 * d1; Q = self.Q
        self.SMUL, self.SINV, self.MZ, self.C16 = scalar_tables(Q)
        self.L = L = FastLevel(comps, EC, name=name)
        self.G, self.n, self.root = G, n, root = len(L.gens), L.n, int(L.root)
        self.tg, self.te = relator_arrays(L)
        self.bitfuns = bitfuns
        # step scalars: F16 part from the level tables, sign part from the bit functions
        jx = np.zeros(L.NXE.shape, dtype=np.int64)
        for c, j in LOG16.items(): jx[L.NXE == c] = j
        assert np.isin(L.NXE, POW16).all(), "nebentypus values outside mu_%d (set P2_ORD=15 for characters of order 3 or 15)" % ORD
        qb = quad_nxa(L, bitfuns).astype(np.int64) if bitfuns is not None and any(f is not None for f in bitfuns) else np.zeros_like(jx)
        self.SE = ORD * qb + jx
        assert (self.C16[self.SE] == L.NXE).all()
        self.rv = rv = two_adic_root(S); self.rb = rb = (1 - rv) % Q
        mats = [GEN[g] for g in L.gens] + [GINV[g] for g in L.gens]
        self.Ag = np.array([symmat(Mt, m, rv, Q) for Mt in mats], dtype=np.int64)
        self.Bg = np.array([symmat(Mt, m, rb, Q) for Mt in mats], dtype=np.int64)
        I = np.eye(d1, dtype=np.int64)
        for s in range(G):
            assert ((self.Ag[s] @ self.Ag[G + s]) % Q == I).all() and ((self.Bg[s] @ self.Bg[G + s]) % Q == I).all(), "V(g) V(g^-1) != 1"
        self.TREE = L.TREE; nt = np.nonzero(~L.TREE)[0]; self.NONTREE = nt.astype(np.int64); self.Nnt = len(nt)
        self.colpos = -np.ones(G * n, dtype=np.int64); self.colpos[nt] = np.arange(len(nt)) * dV
        self.colpos4 = -np.ones(G * n, dtype=np.int64); self.colpos4[nt] = np.arange(len(nt)) * 4
        self.ntidx = -np.ones(G * n, dtype=np.int64); self.ntidx[nt] = np.arange(len(nt))
        self.ncol = len(nt) * dV; self.ncol4 = len(nt) * 4
        # BFS order of the tree (children after parents), as in vdec
        order = np.empty(n, dtype=np.int64); order[0] = root; seen = np.zeros(n, dtype=bool); seen[root] = True; hd = 0; tl = 1
        while hd < tl:
            x = order[hd]; hd += 1
            for g in range(G):
                y = int(L.NXT[g, x])
                if not seen[y]:
                    seen[y] = True; order[tl] = y; tl += 1; assert L.PAR_X[y] == x and L.PAR_G[y] == g
        assert tl == n
        self.order = order
        self.lamE = _tree_scalars(order, L.PAR_X.astype(np.int64), L.PAR_G.astype(np.int64), self.SE, self.SMUL, n)
        self.laminvE = self.SINV[self.lamE]
        self.linv16 = self.C16[self.laminvE]
        RA = np.zeros((n, d1, d1), dtype=np.int64); RB = np.zeros((n, d1, d1), dtype=np.int64)
        RiA = np.zeros((n, d1, d1), dtype=np.int64); RiB = np.zeros((n, d1, d1), dtype=np.int64)
        RA[root] = I; RB[root] = I; RiA[root] = I; RiB[root] = I
        px = L.PAR_X; pg = L.PAR_G
        for y in order[1:]:
            x = int(px[y]); g = int(pg[y])
            RA[y] = (RA[x] @ self.Ag[g]) % Q; RB[y] = (RB[x] @ self.Bg[g]) % Q
            RiA[y] = (self.Ag[G + g] @ RiA[x]) % Q; RiB[y] = (self.Bg[G + g] @ RiB[x]) % Q
        self.RA, self.RB, self.RiA, self.RiB = RA, RB, RiA, RiB
        self.T = {}
        if verbose: print("  level %s (prime to 2), weight %d: dim V = %d, index %d, %d non-tree edges, %d unknowns; r_v = %d mod 2^%d; "
                          "sign part of the character on %d of %d steps (%.0fs)"
                          % (name, k, dV, n, len(nt), self.ncol, rv, S, int((self.SE >= ORD).sum()), self.SE.size, time.time() - t0), flush=True)

    def char_index(self, lams):
        """Index of the level character at the component scalars lams (F16 part from the tables, sign from bitfuns)."""
        L = self.L
        j = LOG16[int(L._eps_tuple(lams))] if L.eps_chars is not None else 0
        b = 0
        if self.bitfuns is not None:
            for kk, f in enumerate(self.bitfuns):
                if f is not None: b ^= int(f(lams[kk]))
        return ORD * b + j

    # ---------------------------------------------------------------- mod 2 decomposition (as vdec)
    def decompose(self):
        G, d1 = self.G, self.d1
        self.Sm, self.Sminv, self.a, self.b, self.btypes = sym_decomposition(self.m)
        DA = np.array([(self.Sminv @ (A % 2) @ self.Sm) % 2 for A in self.Ag]); DB = np.array([(self.Sminv @ (B % 2) @ self.Sm) % 2 for B in self.Bg])
        blkA = {}; blkB = {}
        for D, blk in ((DA, blkA), (DB, blkB)):
            for s in range(2 * G):
                for q in range(d1 // 2):
                    for q2 in range(d1 // 2):
                        B_ = D[s, 2 * q:2 * q + 2, 2 * q2:2 * q2 + 2]
                        if q != q2: assert not B_.any(), "V(g) mod 2 is not block diagonal in the adapted basis"
                        else:
                            t = self.btypes[q]
                            if (t, s) in blk: assert (blk[(t, s)] == B_).all(), "blocks of one type differ"
                            else: blk[(t, s)] = B_.copy()
        self.DA, self.DB = DA, DB
        h = d1 // 2
        self.types = [(t1, t2) for t1 in ("P", "S") for t2 in ("P", "S") if t1 in self.btypes and t2 in self.btypes]
        self.Dtype = {}; self.tpieces = {}
        for (t1, t2) in self.types:
            self.Dtype[(t1, t2)] = np.array([np.kron(blkA[(t1, s)], blkB[(t2, s)]) for s in range(2 * G)], dtype=np.int64)
            self.tpieces[(t1, t2)] = [(q1, q2) for q1 in range(h) for q2 in range(h) if self.btypes[q1] == t1 and self.btypes[q2] == t2]
        self.nzA = nzform(DA); self.nzB = nzform(DB)
        RiDA = np.array([(self.Sminv @ (M % 2) @ self.Sm) % 2 for M in self.RiA]); RiDB = np.array([(self.Sminv @ (M % 2) @ self.Sm) % 2 for M in self.RiB])
        self.nzRiA = nzform(RiDA); self.nzRiB = nzform(RiDB)
        return self

    def type_rows(self, tau):
        cols, vals, bad = rows_mod2_s(self.L.NXT, self.L.NXE, self.Dtype[tau], self.tg, self.te, self.G, self.n, self.colpos4, 4,
                                      self.tg.shape[1] * 4, MUL)
        assert bad == 0, "relators do not close mod 2"
        return cols, vals

    def type_coboundaries(self, tau):
        """The 4 coboundaries delta m_a (m_a(root) = e_a) of the type-tau piece system, F16 codes (4, ncol4)."""
        G, n, L = self.G, self.n, self.L; D = self.Dtype[tau]; NXE = L.NXE
        out = np.zeros((4, self.ncol4), dtype=np.uint8)
        def dmul(Dm, X):            # 0/1 matrix times F16-code vectors X (N, 4)
            Y = np.zeros_like(X)
            for a in range(4):
                for b in range(4):
                    if Dm[a, b] & 1: Y[:, a] ^= X[:, b]
            return Y
        for a in range(4):
            mm = np.zeros((n, 4), dtype=np.uint8); mm[self.root, a] = 1
            for y in self.order[1:]:
                x = int(L.PAR_X[y]); g = int(L.PAR_G[y])
                mm[y] = MUL[INV[NXE[g, x]], dmul(D[G + g], mm[x][None, :])[0]]
            for s in range(G):
                xs = np.arange(n); ys = L.NXT[s].astype(np.int64)
                val_ = MUL[NXE[s][:, None], dmul(D[s], mm[ys])] ^ mm
                u = s * n + xs; nt_ = ~self.TREE[u]
                assert not val_[~nt_].any(), "coboundary not zero on a tree edge"
                cp = self.colpos4[u[nt_]]
                for b in range(4): out[a, cp + b] = val_[nt_, b]
        return out

    def coboundary_data(self, Q):
        """m_a for the dV full coboundaries mod Q: arrays (dV, n, dV, 4) with m_a(root) = e_a (first GR coordinate) and
        delta m_a = 0 on the tree."""
        G, n, L, dV, d1 = self.G, self.n, self.L, self.dV, self.d1
        Ag, Bg, MZ = self.Ag % Q, self.Bg % Q, self.MZ % Q
        out = np.zeros((dV, n, dV, 4), dtype=np.int64)
        for a in range(dV):
            mm = out[a]; mm[self.root, a, 0] = 1
            for y in self.order[1:]:
                x = int(L.PAR_X[y]); g = int(L.PAR_G[y])
                Y = mm[x].reshape(d1, d1, 4)
                V_ = np.einsum("ik,klc,jl->ijc", Ag[G + g], Y, Bg[G + g]) % Q
                mm[y] = (V_.reshape(dV, 4) @ MZ[self.SINV[self.SE[g, x]]].T) % Q
        return out
    def coboundary_on(self, mdat, a, edges, Q):
        """delta m_a on the non-tree edges 'edges' (indices into NONTREE): (len(edges) dV, 4)."""
        G, n, d1, dV = self.G, self.n, self.d1, self.dV
        out = np.zeros((len(edges) * dV, 4), dtype=np.int64)
        for i, e in enumerate(edges):
            u = int(self.NONTREE[e]); s = u // n; x = u % n; y = int(self.L.NXT[s, x])
            Y = mdat[a, y].reshape(d1, d1, 4)
            V_ = np.einsum("ik,klc,jl->ijc", self.Ag[s] % Q, Y, self.Bg[s] % Q).reshape(dV, 4) % Q
            out[i * dV:(i + 1) * dV] = ((V_ @ (self.MZ[self.SE[s, x]] % Q).T) - mdat[a, x]) % Q
        return out

    # ---------------------------------------------------------------- adapted <-> standard coordinates (mod 2)
    def to_old(self, Yn): return f2_sandwich(Yn, self.Sm, self.Sm)
    def to_new(self, Yo): return f2_sandwich(Yo, self.Sminv, self.Sminv)

    # ---------------------------------------------------------------- relator walk mod Q
    def walk(self, W, Q):
        out, bad = vrel_eval_gr(self.L.NXT, self.SE, self.SMUL, self.MZ % Q, self.Ag % Q, self.Bg % Q, self.tg, self.te, self.G,
                                self.n, self.colpos, W, Q, self.d1, ORD)
        assert bad == 0, "a relator does not close"
        return out

    # ---------------------------------------------------------------- Hecke operators
    def _pieces(self, pi, h, reps):
        out = []
        for ai in reps:
            X0 = mmul(ai, h); found = None
            for aj in reps:
                X = mmul(X0, hecke.adj(aj))
                Y = tuple(hecke.odiv(e, pi) for e in X)
                if None in Y: continue
                if mdet(Y) not in ((1, 0), (-1, 0)) or not self.L.in_gamma0(Y): continue
                found = Y; break
            assert found is not None, "Hecke coset not found"
            out.append(found)
        return out
    def build_T(self, op, pi, edges=None):
        """Words of the N(pi) + 1 pieces for the non-tree edges 'edges' (indices into NONTREE; None = all)."""
        L, G, n, Q = self.L, self.G, self.n, self.Q
        reps = hecke.hecke_reps(pi); npc = len(reps)
        assert all(not c.iszero(c.red(pi)) for c in L.comps), "pi not prime to the level"
        ed = np.arange(self.Nnt, dtype=np.int64) if edges is None else np.asarray(edges, dtype=np.int64)
        lets = []; lens = []
        for e in ed:
            u = int(self.NONTREE[e]); g = L.gens[u // n]; x = u % n
            h = L.schreier(g, x)
            for hi_ in self._pieces(pi, h, reps):
                toks = decompose(hi_)
                lets.extend([L.gens.index(gg) if ex == 1 else G + L.gens.index(gg) for gg, ex in toks]); lens.append(len(toks))
        ptr = np.zeros(len(lens) + 1, dtype=np.int64); ptr[1:] = np.cumsum(lens)
        wE = np.array([self.SINV[self.char_index(L.d_scalar(ai))] for ai in reps], dtype=np.int64)
        VaA = np.array([symmat(hecke.adj(ai), self.m, self.rv, Q) for ai in reps], dtype=np.int64)
        VaB = np.array([symmat(hecke.adj(ai), self.m, self.rb, Q) for ai in reps], dtype=np.int64)
        rec = {"pi": pi, "npc": npc, "edges": ed, "ucols": self.NONTREE[ed].copy(), "lets": np.array(lets, dtype=np.int64), "ptr": ptr,
               "wE": wE, "wcode": self.C16[wE].copy(), "VaA": VaA, "VaB": VaB}
        if hasattr(self, "Sm"):
            rec["nzVaA"] = nzform(np.array([(self.Sminv @ (M % 2) @ self.Sm) % 2 for M in VaA]))
            rec["nzVaB"] = nzform(np.array([(self.Sminv @ (M % 2) @ self.Sm) % 2 for M in VaB]))
        self.T[op] = rec
        return rec
    def T2(self, op, Yn):
        """T mod 2 on the cochain Yn (Nnt, d1, d1) (adapted basis), on the edges the words were built for."""
        R = self.T[op]
        out, bad = t2_apply(R["ucols"], R["ptr"], R["lets"], R["npc"], self.L.NXT, self.L.NXE, self.nzA[0], self.nzA[1], self.nzB[0], self.nzB[1],
                            R["nzVaA"][0], R["nzVaA"][1], R["nzVaB"][0], R["nzVaB"][1], R["wcode"], self.ntidx,
                            self.nzRiA[0], self.nzRiA[1], self.nzRiB[0], self.nzRiB[1], self.linv16, self.root, self.G, self.n,
                            np.ascontiguousarray(Yn), self.d1, MUL)
        assert bad == 0, "a Hecke piece does not close"
        return out
    def TQ(self, op, W, Q):
        """T mod Q on a cochain W (ncol, 4) (standard basis), on the edges the words were built for: (len dV, 4)."""
        R = self.T[op]
        out, bad = tq_apply(R["ucols"], R["ptr"], R["lets"], R["npc"], self.L.NXT, self.SE, self.SMUL, self.MZ % Q, self.Ag % Q, self.Bg % Q,
                            R["VaA"] % Q, R["VaB"] % Q, R["wE"], self.colpos, self.laminvE, self.RiA % Q, self.RiB % Q, self.root,
                            self.G, self.n, W, Q, self.d1, ORD)
        assert bad == 0, "a Hecke piece does not close"
        return out
