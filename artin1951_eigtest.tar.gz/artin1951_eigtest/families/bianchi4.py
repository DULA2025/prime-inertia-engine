import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Bianchi cohomology over E = Q(sqrt-7) at level N*4*O_E with a wild nebentypus at 2, in characteristic 0 (over F_P).

New pieces on top of ../bianchi2 (FastLevel, closure_psi, ...) and ../twins/fp_hecke.py (FpHecke):
  * Comp4: the component O/4O = O/v^2 x O/vbar^2 = Z/4 x Z/4 (2 = v vbar, v = (w), w = (1 + sqrt-7)/2; t -> 2 mod 4 at v
    and t -> 3 mod 4 at vbar, the lifts of the project's conventions t -> 0 at v, t -> 1 at vbar);
  * quad_nxa: a quadratic character on several components at once (one bit per component, XOR), used as the psi of
    order 2 of FpHecke (psit[a] = (-1)^a);
  * U operators at v and vbar (right cosets (1 b; 0 pi), b mod pi; weight eps(a) = 1, the alpha^iota convention).
The Hecke operators T_pi at good primes are FpHecke's (weight eps(d)^-1, i.e. eps(N pi)^-1 times the alpha^iota
convention).  Author: Dula."""
import sys, time
sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
import numpy as np
from o7 import GEN, GINV, mmul, mdet, decompose, onorm, oconj
import hecke, gf
from bmf import Comp
from sparse_h1 import FastLevel, relator_arrays
from sparse_fp import dedup_fp
from sparse_fp_psi import closure_psi, rows_to_csr_psi
import fp_hecke
from fp_hecke import markowitz_rec, _backsub, _check_all, _bfs_P, solve_fp, powmod_vec, core_kernel, KERNEL_ENGINE

V_PI = (0, 1)            # w, generator of v (t -> 0 mod 2)
VB_PI = oconj(V_PI)      # 1 - w, generator of vbar (t -> 1 mod 2)

class Comp4:
    """O/4O = Z/4 x Z/4 (components at v^2 and vbar^2).  P^1(Z/4): index 0..3 = (1 : d), 4 = (2 : 1), 5 = (0 : 1);
    a point of P^1(O/4O) has index i_v + 6 i_vbar, the last one (0 : 1) x (0 : 1); scalars are pairs of units mod 4."""
    typ = "O4"
    def __init__(self):
        self.p = 2; self.r = (2, 3); self.size = 36
    def red(self, a):
        x, y = a
        return ((x + 2 * y) % 4, (x + 3 * y) % 4)
    def mul(self, a, b): return ((a[0] * b[0]) % 4, (a[1] * b[1]) % 4)
    def add(self, a, b): return ((a[0] + b[0]) % 4, (a[1] + b[1]) % 4)
    def iszero(self, a): return a == (0, 0)
    def inv(self, a):
        assert a[0] % 2 and a[1] % 2
        return (a[0] % 4, a[1] % 4)                 # units of Z/4 are their own inverses
    def zero(self): return (0, 0)
    def one(self): return (1, 1)
    @staticmethod
    def _norm1(c, d):
        c %= 4; d %= 4
        if c % 2: return (d * c) % 4, c             # (c : d) = c (1 : d/c), 1/c = c
        assert d % 2, "not a primitive row"
        q = (c * d) % 4                             # c/d in {0, 2}
        return (4 if q == 2 else 5), d
    def normalize(self, c, d):
        i1, l1 = self._norm1(c[0], d[0]); i2, l2 = self._norm1(c[1], d[1])
        return i1 + 6 * i2, (l1, l2)
    @staticmethod
    def _rep1(i):
        if i < 4: return (1, i)
        return (2, 1) if i == 4 else (0, 1)
    def rep(self, i):
        a = self._rep1(i % 6); b = self._rep1(i // 6)
        return ((a[0], b[0]), (a[1], b[1]))
    def units(self): return [(a, b) for a in (1, 3) for b in (1, 3)]

def chi4(u): return 1 if u % 4 == 3 else 0                          # bit of chi_-4

def quad_nxa(L, bitfuns):
    """NXA[s, x] (uint8, 0/1) = XOR over components k of bitfuns[k](scalar_k(step s from coset x)); bitfuns[k] None
    means no character on that component.  Recomputes the local actions and checks them against L.NXT."""
    n = L.n; G = len(L.gens)
    mats = [GEN[g] for g in L.gens] + [GINV[g] for g in L.gens]
    xs = np.arange(n, dtype=np.int64); nxa = np.zeros((2 * G, n), dtype=np.uint8)
    for s, M in enumerate(mats):
        idx = np.zeros(n, dtype=np.int64); acc = np.zeros(n, dtype=np.uint8)
        for k, c in enumerate(L.comps):
            a, b, cm, dm = tuple(c.red(e) for e in M)
            lj = np.zeros(c.size, dtype=np.int64); lb = np.zeros(c.size, dtype=np.uint8)
            for i in range(c.size):
                cc, dd = c.rep(i)
                nc = c.add(c.mul(cc, a), c.mul(dd, cm)); nd = c.add(c.mul(cc, b), c.mul(dd, dm))
                j, l = c.normalize(nc, nd); lj[i] = j
                lb[i] = 0 if bitfuns[k] is None else bitfuns[k](l)
            ik = (xs // L.strides[k]) % L.sizes[k]
            idx += lj[ik] * L.strides[k]; acc ^= lb[ik]
        assert (idx == L.NXT[s]).all(), "local action differs from the level tables"
        nxa[s] = acc
    return nxa

class FpHecke4(fp_hecke.FpHecke):
    """FpHecke with the order-2 psi given by quad_nxa (bitfuns per component) instead of a log table on component 0."""
    def __init__(self, L, P, chip, bitfuns, maxcost_stop=384, dense_max=8000, seed=1, verbose=True):
        t0 = time.time(); self.L, self.P = L, P; G = len(L.gens); n = L.n; ncol = G * n; self.G, self.n = G, n
        self.chip = chip; self.bitfuns = bitfuns
        self.nxa = quad_nxa(L, bitfuns)
        self.psit = np.array([1 if a % 2 == 0 else P - 1 for a in range(64)], dtype=np.int64); self.zeta = P - 1
        tg, te = relator_arrays(L); self.tg, self.te = tg, te
        FP = (chip[L.NXE.astype(np.int64)] * self.psit[self.nxa.astype(np.int64)]) % P; self.FP = FP
        self.nontrivial = bool((FP != 1).any())
        root, rfac, alive, passes, notclosed = closure_psi(L.NXT, L.NXE, self.nxa, chip, self.psit, tg, te, G, n, L.TREE, P)
        assert notclosed == 0
        root[L.TREE] = -1; rfac[L.TREE] = 0
        reps = np.unique(root[root >= 0]); ncls = len(reps)
        cls_of = -np.ones(ncol, dtype=np.int64); pos = -np.ones(ncol, dtype=np.int64); pos[reps] = np.arange(ncls)
        mk = root >= 0; cls_of[mk] = pos[root[mk]]
        self.cls_of, self.rfac, self.ncls = cls_of, rfac, ncls
        ptr, col, val, hs = rows_to_csr_psi(L.NXT, L.NXE, self.nxa, chip, self.psit, tg, te, G, n, L.TREE, P, alive, cls_of.astype(np.int32), rfac)
        ptr, col, val = dedup_fp(ptr, col, val, P, hs)
        if verbose: print("  closure: %d classes, %d equations after deduplication (%.0fs)" % (ncls, len(ptr) - 1, time.time() - t0), flush=True)
        ptr, col, val, elim, recs = markowitz_rec(ptr, col, val, ncls, P, maxcost_stop=maxcost_stop)
        cw = np.bincount(col, minlength=ncls)
        core_x = np.nonzero(cw > 0)[0]; free = np.nonzero((cw == 0) & ~elim)[0]; C = len(core_x)
        newid = -np.ones(ncls, dtype=np.int64); newid[core_x] = np.arange(C)
        if verbose: print("  Markowitz: %d pivots in %d rounds; core %d x %d; free classes %d (%.0fs)" % (int(elim.sum()), len(recs), len(ptr) - 1, C, len(free), time.time() - t0), flush=True)
        assert C <= dense_max, "core too large for the dense kernel (%d)" % C
        Mc = np.zeros((len(ptr) - 1, C), dtype=np.int64)
        for r in range(len(ptr) - 1): Mc[r, newid[col[ptr[r]:ptr[r + 1]]]] = val[ptr[r]:ptr[r + 1]]
        t2 = time.time(); Kc = core_kernel(Mc, P)
        d = Kc.shape[1] + len(free); self.dZ = d
        V = np.zeros((ncls, d), dtype=np.int64)
        V[core_x, :Kc.shape[1]] = Kc
        for i, fcl in enumerate(free): V[fcl, Kc.shape[1] + i] = 1
        del Mc
        if verbose: print("  dense core kernel %d (%s, %.0fs)" % (Kc.shape[1], KERNEL_ENGINE, time.time() - t2), flush=True)
        for pc, pptr, pcol, pval in reversed(recs): _backsub(V, pc, pptr, pcol, pval, P)
        Z = np.zeros((ncol, d), dtype=np.int64); ok = cls_of >= 0
        Z[ok] = (rfac[ok][:, None] * V[cls_of[ok]]) % P
        self.Z = Z
        bad, nc = _check_all(L.NXT, L.NXE, self.nxa, chip, self.psit, tg, te, G, n, L.TREE, P, Z)
        assert nc == 0 and bad == 0, (bad, nc)
        if verbose: print("  dim Z = %d; all %d relator equations hold on every vector (%.0fs)" % (d, tg.shape[0] * n, time.time() - t0), flush=True)
        lam, px, pg = _bfs_P(L.NXT, FP, G, n, L.root, P)
        assert (px == L.PAR_X).all() and (pg == L.PAR_G).all(), "BFS tree differs"
        self.lamP = lam; m = powmod_vec(lam, P - 2, P)
        dm = np.zeros(ncol, dtype=np.int64)
        for s in range(G): dm[s * n:(s + 1) * n] = (FP[s] * m[L.NXT[s]] - m) % P
        assert not dm[L.TREE].any()
        self.dm = dm if dm.any() else None
        rng = np.random.default_rng(seed)
        nt = np.nonzero(~L.TREE)[0]
        mm = min(len(nt), max(4 * d, 64))
        while True:
            sub = np.sort(rng.choice(nt, size=mm, replace=False))
            A = np.ascontiguousarray(Z[sub].T % P); pv = list(gf.rrefp(A, P))
            if len(pv) == d: break
            assert mm < len(nt), "dependent kernel vectors"
            mm = min(len(nt), 2 * mm)
        self.pivots = [int(sub[p]) for p in pv]
        if self.dm is not None:
            a = solve_fp(Z[self.pivots], self.dm[self.pivots][:, None], P)
            assert a is not None
            assert (((Z @ a[:, 0]) - self.dm) % P == 0).all(), "delta m_par not the combination found"
            self.drop = int(np.nonzero(a[:, 0])[0][0])
        else:
            self.drop = None
        self.keep = np.array([k for k in range(d) if k != self.drop], dtype=np.int64); self.D = len(self.keep)
        if verbose: print("  dim H^1 = %d (delta m_par %s) (%.0fs)" % (self.D, "in the span, dropped" if self.drop is not None else "zero", time.time() - t0), flush=True)
        self.rng = rng

    def epsP(self, lams):
        L = self.L; code = L._eps_tuple(lams) if L.eps_chars is not None else 1
        bit = 0
        for k, f in enumerate(self.bitfuns):
            if f is not None: bit ^= f(lams[k])
        return int(self.chip[code]) * (1 if bit == 0 else self.P - 1) % self.P

    def pieces_U(self, pi, h):
        """U at a prime pi dividing the level: right cosets (1 b; 0 pi), b mod pi (norm 2: b = 0, 1); weight 1."""
        L = self.L; Np = onorm(pi); assert Np == 2
        reps = [((1, 0), (b, 0), (0, 0), pi) for b in range(Np)]; out = []
        for ai in reps:
            X0 = mmul(ai, h); found = None
            for aj in reps:
                X = mmul(X0, hecke.adj(aj))
                Y = tuple(hecke.odiv(e, pi) for e in X)
                if None in Y: continue
                if mdet(Y) not in ((1, 0), (-1, 0)) or not L.in_gamma0(Y): continue
                found = Y; break
            assert found is not None, "U coset not found"
            out.append((found, 1))
        return out

    def hecke(self, pi, extra=8, U=False):
        L, P, n, Z = self.L, self.P, self.n, self.Z
        nt = np.nonzero(~L.TREE)[0]; pset = set(self.pivots)
        ex = [int(u) for u in self.rng.choice(nt, size=extra, replace=False) if int(u) not in pset]
        cols = self.pivots + ex
        vals = np.zeros((len(cols), self.D), dtype=np.int64)
        for r, u in enumerate(cols):
            g = L.gens[u // n]; x = u % n
            h = L.schreier(g, x); acc = np.zeros(self.dZ, dtype=np.int64)
            for hi, w in (self.pieces_U(pi, h) if U else self.pieces(pi, h)):
                dct, cur = self.walkP(decompose(hi))
                assert cur == L.root
                for v, c in dct.items():
                    if c: acc = (acc + (w * c % P) * Z[v]) % P
            il = pow(int(self.lamP[x]), P - 2, P)
            vals[r] = (acc[self.keep] * il) % P
        Bc = Z[cols][:, self.keep]
        if self.drop is not None: Bc = np.concatenate([Bc, self.dm[cols][:, None]], axis=1)
        X = solve_fp(Bc, vals, P)
        if X is None: return None
        return X[:self.D]
