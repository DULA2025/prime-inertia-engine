import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Lean linear algebra for the prime-to-2 tower at large levels (p2_mod8.py): the augmented solve R x + B t = 0 for given
mod-2 rows, with the kernel kept in class form (closure classes, bitsliced), as bockstein.AugSolve does for weight 2.
RowsAug (vbock.py) stores every kernel vector on every column (ncol x d bytes), which does not fit at level 633 in
weight 3 (5.4 million columns).  Here a vector is expanded to all columns only when asked for, and the checks walk the
relators again (rows_check16) instead of keeping the rows.  Author: Dula."""
import sys, time
sys.path.insert(0, _ROOT + "/families"); sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
import numpy as np, numba as nb
from sparse_h1 import MUL, INV
from sparse_big import lift, _relabel
from bockstein import (Conditions, closure2_affine, rows_to_csr_affine, dedup_aug, markowitz_aug, _records_with_rhs,
                       _core_with_rhs, AugSolve)
import lanczos16
from lanczos16 import MASKS, to_bits, from_bits
import gf
from p2lift import _mm2

@nb.njit(cache=True)
def rows_width(nxt, nxe, Vg2, tg, te, G, n, colpos, dV, mul):
    """Largest number of non-zero entries in a row of rows_mod2_s (same walk, nothing stored)."""
    nr, T = tg.shape; wmax = 0
    eu = np.empty(T, dtype=np.int64); EB = np.zeros((T, dV, dV), dtype=np.uint8)
    for r in range(nr):
        for x in range(n):
            cur = x; w = np.uint8(1); m = 0
            M = np.zeros((dV, dV), dtype=np.int64)
            for i in range(dV): M[i, i] = 1
            for j in range(T):
                g = tg[r, j]
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; coef = w; blk = M.copy()
                    w = mul[w, nxe[g, cur]]; M = _mm2(M, Vg2[g]); cur = nxt[g, cur]
                else:
                    s = G + g; w = mul[w, nxe[s, cur]]; M = _mm2(M, Vg2[s]); cur = nxt[s, cur]
                    u = g * n + cur; coef = w; blk = M.copy()
                if colpos[u] < 0: continue
                t = -1
                for q in range(m):
                    if eu[q] == u: t = q
                if t < 0:
                    t = m; eu[m] = u; m += 1
                    for a in range(dV):
                        for b in range(dV): EB[t, a, b] = 0
                for a in range(dV):
                    for b in range(dV):
                        if blk[a, b] & 1: EB[t, a, b] ^= coef
            for a in range(dV):
                kk = 0
                for t in range(m):
                    for b in range(dV):
                        if EB[t, a, b] != 0: kk += 1
                if kk > wmax: wmax = kk
    return wmax

@nb.njit(cache=True)
def rows_mod2_w(nxt, nxe, Vg2, tg, te, G, n, colpos, dV, Tw, mul):
    """rows_mod2_s with a given width Tw (from rows_width)."""
    nr, T = tg.shape; R = nr * n * dV
    cols = -np.ones((R, Tw), dtype=np.int32); vals = np.zeros((R, Tw), dtype=np.uint8)
    eu = np.empty(T, dtype=np.int64); EB = np.zeros((T, dV, dV), dtype=np.uint8)
    bad = 0
    for r in range(nr):
        for x in range(n):
            cur = x; w = np.uint8(1); m = 0
            M = np.zeros((dV, dV), dtype=np.int64)
            for i in range(dV): M[i, i] = 1
            for j in range(T):
                g = tg[r, j]
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; coef = w; blk = M.copy()
                    w = mul[w, nxe[g, cur]]; M = _mm2(M, Vg2[g]); cur = nxt[g, cur]
                else:
                    s = G + g; w = mul[w, nxe[s, cur]]; M = _mm2(M, Vg2[s]); cur = nxt[s, cur]
                    u = g * n + cur; coef = w; blk = M.copy()
                if colpos[u] < 0: continue
                t = -1
                for q in range(m):
                    if eu[q] == u: t = q
                if t < 0:
                    t = m; eu[m] = u; m += 1
                    for a in range(dV):
                        for b in range(dV): EB[t, a, b] = 0
                for a in range(dV):
                    for b in range(dV):
                        if blk[a, b] & 1: EB[t, a, b] ^= coef
            closed = cur == x and w == 1
            for a in range(dV):
                for b in range(dV):
                    if M[a, b] != (1 if a == b else 0): closed = False
            if not closed: bad += 1
            for a in range(dV):
                row = (r * n + x) * dV + a; kk = 0
                for t in range(m):
                    cb = colpos[eu[t]]
                    for b in range(dV):
                        if EB[t, a, b] != 0:
                            cols[row, kk] = cb + b; vals[row, kk] = EB[t, a, b]; kk += 1
    return cols, vals, bad

@nb.njit(cache=True, parallel=True)
def rows_check16(nxt, nxe, Vg2, tg, te, G, n, colpos, dV, X, B, tvec, mul):
    """Number of rows (r n + x) dV + a where R X + B t does not vanish (B: RHS (R, m) or empty, tvec: (m,))."""
    nr, T = tg.shape; bad = np.zeros(n, dtype=np.int64); m_ = B.shape[1]
    for x in nb.prange(n):
        acc = np.zeros(dV, dtype=np.uint8)
        for r in range(nr):
            for a in range(dV): acc[a] = 0
            cur = np.int64(x); w = np.uint8(1)
            M = np.zeros((dV, dV), dtype=np.int64)
            for i in range(dV): M[i, i] = 1
            for j in range(T):
                g = np.int64(tg[r, j])
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; coef = w; blk = M.copy()
                    w = mul[w, nxe[g, cur]]; M = _mm2(M, Vg2[g]); cur = np.int64(nxt[g, cur])
                else:
                    s = G + g; w = mul[w, nxe[s, cur]]; M = _mm2(M, Vg2[s]); cur = np.int64(nxt[s, cur])
                    u = g * n + cur; coef = w; blk = M.copy()
                cb = colpos[u]
                if cb < 0: continue
                for a in range(dV):
                    for b in range(dV):
                        if blk[a, b] & 1: acc[a] ^= mul[coef, X[cb + b]]
            for a in range(dV):
                row = (r * n + x) * dV + a
                v = acc[a]
                for j in range(m_): v ^= mul[B[row, j], tvec[j]]
                if v != 0: bad[x] += 1
    return bad.sum()

class AugRows(AugSolve):
    """Kernel of R x + B t = 0 for the given fixed-width rows (cols, vals) with ncol columns, kernel in class form.
    After the run: Tm (m x d) t-parts of the kernel vectors, Kt (combinations with t = 0: ker R), Lech (echelon basis of
    L = {t : B t in im R}) with Qc (kernel combinations realising its rows); expand(q) gives the column vector of a
    combination q.  check: callable (X, t) -> number of failing rows, applied to every vector with t != 0 and to a
    sample of ker R."""
    def __init__(self, cols, vals, ncol, B, check, fill=8.0, seed=1, lanczos_w=4, dense_max=6000, verbose=True, nsample=6):
        t0 = time.time(); self.m = m = B.shape[1]; self.t = {}; self.ncol = ncol
        self.conds = Conditions(m)
        root, rfac, off, alive, passes, ncond = closure2_affine(cols, vals, ncol, B, self.conds.Cb, self.conds.piv, MUL, INV)
        self.conds.n = ncond
        reps = np.unique(root[root >= 0]); ncls = len(reps)
        cls_of = -np.ones(ncol, dtype=np.int32); pos = -np.ones(ncol, dtype=np.int64); pos[reps] = np.arange(ncls)
        mk = root >= 0; cls_of[mk] = pos[root[mk]].astype(np.int32); del pos, mk, root, reps
        self.cls_of, self.rfac, self.off, self.ncls = cls_of, rfac, off, ncls
        if verbose: print("    affine closure (%d passes): %d classes, %d equations left, conditions on t: %d (%.0fs)" % (passes, ncls, int(alive.sum()), self.conds.n, time.time() - t0), flush=True)
        ptr, col, val, hs, RHS, EMP = rows_to_csr_affine(cols, vals, alive, cls_of, rfac, off, B, MUL, INV)
        del alive
        self.conds.add(EMP); del EMP
        ptr, col, val, RHS = dedup_aug(ptr, col, val, RHS, self.conds, hs); del hs
        if verbose: print("    deduplicated: %d equations, nnz %d, conditions %d (%.0fs)" % (len(ptr) - 1, len(col), self.conds.n, time.time() - t0), flush=True)
        ptr, col, val, RHS, records = markowitz_aug(ptr, col, val, RHS, ncls, self.conds, fill=fill, verbose=False)
        rec_c = np.concatenate([r[0] for r in records]) if records else np.zeros(0, np.int32)
        if records:
            offs = np.cumsum([0] + [len(r[2]) for r in records])
            rp = np.concatenate([[0]] + [r[1][1:] + o for r, o in zip(records, offs[:-1])]).astype(np.int64)
            rcol = np.concatenate([r[2] for r in records]); rval = np.concatenate([r[3] for r in records]); rrhs = np.concatenate([r[4] for r in records])
        else:
            rp = np.zeros(1, np.int64); rcol = np.zeros(0, np.int32); rval = np.zeros(0, np.uint8); rrhs = np.zeros((0, m), np.uint8)
        del records
        rec_ptr, rec_col, rec_val = _records_with_rhs(rp, rcol, rval, rrhs, ncls); del rp, rcol, rval, rrhs
        cw = np.bincount(col, minlength=ncls); elim = np.zeros(ncls, dtype=np.bool_); elim[rec_c] = True
        core_x = np.nonzero(cw > 0)[0]; free_x = np.nonzero((cw == 0) & ~elim)[0]; Cx = len(core_x)
        newid = -np.ones(ncls, dtype=np.int64); newid[core_x] = np.arange(Cx)
        cp, cc, cv = _core_with_rhs(ptr, _relabel(col, newid), val, RHS, self.conds.rows(), Cx); del ptr, col, val, RHS
        C = Cx + m; self.core_shape = (len(cp) - 1, C, len(cc))
        core_cls = np.concatenate([core_x, ncls + np.arange(m)]).astype(np.int64)
        if verbose: print("    Markowitz: %d classes eliminated; core %d x (%d + %d RHS), nnz %d; free classes %d (%.0fs)"
                          % (len(rec_c), len(cp) - 1, Cx, m, len(cc), len(free_x), time.time() - t0), flush=True)
        Kc = self._core(cp, cc, cv, C, seed, lanczos_w, dense_max, verbose, None); del cp, cc, cv
        dcore = Kc.shape[0]; d = dcore + len(free_x); self.d = d
        wd = max(1, (d + 63) // 64)
        Kcb = to_bits(Kc.T.copy(), wd) if dcore else np.zeros((C, 4, wd), dtype=np.uint64); del Kc
        V = lift(ncls + m, core_cls, Kcb, free_x.astype(np.int64), d, rec_c, rec_ptr, rec_col, rec_val, MASKS, INV, wd)
        del Kcb, rec_c, rec_ptr, rec_col, rec_val
        self.Tm = from_bits(V[ncls:ncls + m].copy(), d); self.V = V[:ncls].copy(); del V
        A_ = self.Tm.copy(); piv = list(gf.rref16(A_, MUL, INV)); self.rank_t = len(piv)
        self.Kt = gf.kernel16(self.Tm) if d else np.zeros((0, 0), dtype=np.uint8); self.dim_t0 = self.Kt.shape[0]
        if self.rank_t:
            M2 = np.concatenate([self.Tm.T, np.eye(d, dtype=np.uint8)], axis=1).copy(); pv = list(gf.rref16(M2, MUL, INV))
            sel = [i for i, p in enumerate(pv) if p < m]; self.Qc = M2[sel, m:].copy(); self.Lech = M2[sel, :m].copy()
        else:
            self.Qc = np.zeros((0, d), dtype=np.uint8); self.Lech = np.zeros((0, m), dtype=np.uint8)
        if verbose: print("    kernel %d (complete: %s); dim L = %d; dim ker R = %d (%.0fs)" % (d, self.complete, self.rank_t, self.dim_t0, time.time() - t0), flush=True)
        t1 = time.time(); rng = np.random.default_rng(seed + 11); nb_ = 0
        for i in range(self.Qc.shape[0]):
            X, tt = self.expand(self.Qc[i]); assert check(X, tt) == 0, "a kernel vector with t != 0 fails the rows"; nb_ += 1
        for _ in range(min(nsample, self.dim_t0)):
            q = gf.matmul16(rng.integers(0, 16, size=(1, self.dim_t0)).astype(np.uint8), self.Kt)[0]
            X, tt = self.expand(q); assert not tt.any() and check(X, tt) == 0, "a vector of ker R fails the rows"; nb_ += 1
        self.t["check"] = time.time() - t1
        if verbose: print("    checks: %d expanded vectors satisfy every row (%.0fs)" % (nb_, time.time() - t1), flush=True)

    def expand(self, q):
        """Column vector (ncol,) of F16 codes and t-part (m,) of the kernel combination q (length d)."""
        q = np.asarray(q, dtype=np.uint8)
        Xc = from_bits(lanczos16.mulmat(self.V, q[:, None].copy()), 1)[:, 0]
        t = gf.matmul16(self.Tm, q[:, None].copy())[:, 0] if self.m else np.zeros(0, dtype=np.uint8)
        X = np.zeros(self.ncol, dtype=np.uint8); ok = self.cls_of >= 0
        X[ok] = MUL[self.rfac[ok], Xc[self.cls_of[ok]]]
        for j in range(self.m):
            if t[j]: X ^= MUL[self.off[:, j], t[j]]
        return X, t
    def values_on(self, colsel, Qrows):
        """Values (len(colsel), k) on the columns colsel of the kernel combinations Qrows (k x d) with t = 0."""
        Qrows = np.asarray(Qrows, dtype=np.uint8); k = Qrows.shape[0]
        cl = self.cls_of[colsel]; ok = cl >= 0; out = np.zeros((len(colsel), k), dtype=np.uint8)
        if ok.any():
            Vs = self.V[cl[ok].astype(np.int64)]
            vals = from_bits(lanczos16.mulmat(Vs, Qrows.T.copy()), k)
            out[ok] = MUL[self.rfac[colsel][ok][:, None], vals]
        return out
    def x_for(self, t):
        """A solution x of R x + B t = 0 for t in L."""
        r = self.Lech.shape[0]
        A_ = np.concatenate([self.Lech.T, np.asarray(t, dtype=np.uint8)[:, None]], axis=1).copy(); piv = list(gf.rref16(A_, MUL, INV))
        assert not any(p >= r for p in piv), "t is not in L"
        a = np.zeros(r, dtype=np.uint8)
        for rr, p in enumerate(piv): a[p] = A_[rr, r]
        q = gf.matmul16(a[None, :], self.Qc)[0]
        X, tt = self.expand(q); assert (tt == np.asarray(t, dtype=np.uint8)).all()
        return X
