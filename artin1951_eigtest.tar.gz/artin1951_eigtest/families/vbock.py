import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Route (b): Bockstein lifts with vector coefficients V_{k-2,k-2} at Iwahori level 23*2*O_E.

C_Art (x)^L O/2^(m+2) is the ordinary weight-k complex at Iwahori level mod 2^(m+2) when 2^m | k - 1 (kappa_Art = kappa_k
mod 2^(m+2), trivial character at 2): weight 3 is C_Art mod 8, weight 5 mod 16, weight 9 mod 32, weight 17 mod 64.  Here
the coefficients are V = Sym^(k-2) (x) Sym^(k-2) through the two 2-adic embeddings of O_E (t -> r_v = 6 mod 16 and
t -> r_vbar = 1 - r_v), over GR(2^S, 4) = W(F16)/2^S; the level is P^1(O/2O) x P^1(F_23) x P^1(F_23) (index 5184) with the
nebentypus (./23) o N.  Conventions as in vbianchi.py: cochains on the non-tree edges with values in V, relator block
equations sum_j s_j w_j V(prefix_j) z(u_j) = 0, coboundaries delta m(g, x) = FP V(g) m(xg) - m(x), Hecke operators
(T phi)(h) = sum_b V(adj alpha_b) phi(h_b) read back through z = lam_x^-1 V(r_x)^-1 phi(h_{x,g}).
This module: the level, the V matrices mod 2^S, the mod-2 rows, the relator walk mod 2^S (Horner), U on whole cochains
mod 2^S, the coboundaries, and a generic version of bockstein.AugSolve for given rows.  Author: Dula."""
import sys, os, time
sys.path.insert(0, _ROOT + "/families"); sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
import numpy as np, numba as nb
from t6lib import CompPow2, leg23
from bmf import Comp
from sparse_h1 import FastLevel, MUL, INV, relator_arrays
from sparse_big import lift, _relabel
from bockstein import (Conditions, closure2_affine, rows_to_csr_affine, dedup_aug, markowitz_aug, _records_with_rhs,
                       _core_with_rhs, AugSolve)
import lanczos16
from lanczos16 import MASKS, to_bits, from_bits
from mod2_refine import root as sroot
from o7 import GEN, GINV, mmul, mdet, onorm, decompose
from bianchi4 import V_PI, VB_PI
import hecke, gf

def two_adic_root(S):
    """r mod 2^S with r^2 - r + 2 = 0 and r = 0 mod 2 (Hensel: the derivative 2r - 1 is a unit)."""
    r = 0
    for e in range(2, S + 1):
        Q = 1 << e
        cands = [t for t in (r, r + (Q >> 1)) if (t * t - t + 2) % Q == 0]
        assert len(cands) == 1; r = cands[0]
    return r
def sympow_mod(a, b, c, d, m, Q):
    """Sym^m of [[a, b], [c, d]] as in vbianchi.sympow (column j = coefficients of (a X + c Y)^(m-j) (b X + d Y)^j)."""
    if m == 0: return np.ones((1, 1), dtype=np.int64)
    S = np.zeros((m + 1, m + 1), dtype=np.int64)
    for j in range(m + 1):
        poly = [1] + [0] * m
        for _ in range(m - j): poly = [(poly[i] * a + (poly[i - 1] * c if i else 0)) for i in range(m + 1)]
        for _ in range(j): poly = [(poly[i] * b + (poly[i - 1] * d if i else 0)) for i in range(m + 1)]
        S[:, j] = [v % Q for v in poly]
    return S
def emb(a, r, Q): return (int(a[0]) + int(a[1]) * r) % Q
def vmat(Mt, k, rv, Q):
    m = k - 2; rb = (1 - rv) % Q
    A = sympow_mod(emb(Mt[0], rv, Q), emb(Mt[1], rv, Q), emb(Mt[2], rv, Q), emb(Mt[3], rv, Q), m, Q)
    B = sympow_mod(emb(Mt[0], rb, Q), emb(Mt[1], rb, Q), emb(Mt[2], rb, Q), emb(Mt[3], rb, Q), m, Q)
    return np.kron(A, B) % Q

# ---------------------------------------------------------------- numba kernels
@nb.njit(cache=True)
def _matmul_mod(A, B, Q):
    d = A.shape[0]; C = np.zeros((d, d), dtype=np.int64)
    for i in range(d):
        for k in range(d):
            a = A[i, k]
            if a == 0: continue
            for j in range(d): C[i, j] = (C[i, j] + a * B[k, j]) % Q
    return C
@nb.njit(cache=True)
def rows_mod2(nxt, Vg2, tg, te, G, n, colpos, dV, Tw):
    """Fixed-width rows (cols int32, vals uint8, -1 padded) of the mod-2 block equations, row (r n + x) dV + a; columns
    colpos[u] + b (colpos = -1 on tree edges).  Returns cols, vals, number of relators that do not close mod 2."""
    nr, T = tg.shape; R = nr * n * dV
    cols = -np.ones((R, Tw), dtype=np.int32); vals = np.zeros((R, Tw), dtype=np.uint8)
    I = np.zeros((dV, dV), dtype=np.int64)
    for i in range(dV): I[i, i] = 1
    eu = np.empty(T, dtype=np.int64); EB = np.zeros((T, dV, dV), dtype=np.int64)
    bad = 0
    for r in range(nr):
        for x in range(n):
            cur = x; M = I.copy(); m = 0
            for j in range(T):
                g = tg[r, j]
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; blk = M.copy(); M = _matmul_mod(M, Vg2[g], 2); cur = nxt[g, cur]
                else:
                    s = G + g; M = _matmul_mod(M, Vg2[s], 2); cur = nxt[s, cur]; u = g * n + cur; blk = M.copy()
                if colpos[u] < 0: continue
                t = -1
                for q in range(m):
                    if eu[q] == u: t = q
                if t < 0:
                    t = m; eu[m] = u; m += 1
                    for a in range(dV):
                        for b in range(dV): EB[t, a, b] = 0
                for a in range(dV):
                    for b in range(dV): EB[t, a, b] ^= blk[a, b]
            closed = cur == x
            for a in range(dV):
                for b in range(dV):
                    if M[a, b] != I[a, b]: closed = False
            if not closed: bad += 1
            for a in range(dV):
                row = (r * n + x) * dV + a; k = 0
                for t in range(m):
                    cb = colpos[eu[t]]
                    for b in range(dV):
                        if EB[t, a, b] & 1:
                            cols[row, k] = cb + b; vals[row, k] = 1; k += 1
    return cols, vals, bad
@nb.njit(cache=True, parallel=True)
def vrel_eval(nxt, FP, Vg, tg, te, G, n, colpos, W, Q, dV):
    """R_Q W for a cochain W (ncolV, 4) (values mod Q in the GR(Q,4) coordinates): out (nr n dV, 4), rows (r n + x) dV + a,
    by Horner along each relator (one matrix-vector product per letter).  Also the number of relators that do not close."""
    nr, T = tg.shape
    out = np.zeros((nr * n * dV, 4), dtype=np.int64); bad = np.zeros(n, dtype=np.int64)
    for x in nb.prange(n):
        moves = np.empty(T, dtype=np.int64); ys = np.zeros((T + 1, dV, 4), dtype=np.int64)
        acc = np.zeros((dV, 4), dtype=np.int64); tmp = np.zeros((dV, 4), dtype=np.int64)
        for r in range(nr):
            for j in range(T + 1):
                for a in range(dV):
                    for c in range(4): ys[j, a, c] = 0
            cur = np.int64(x); w = np.int64(1); L = 0
            for j in range(T):
                g = np.int64(tg[r, j])
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; pos = L; coef = w
                    w = (w * FP[g, cur]) % Q; cur = np.int64(nxt[g, cur]); moves[L] = g; L += 1
                else:
                    s = G + g; w = (w * FP[s, cur]) % Q; cur = np.int64(nxt[s, cur]); moves[L] = s; L += 1
                    u = g * n + cur; pos = L; coef = (Q - w) % Q
                cb = colpos[u]
                if cb < 0: continue
                for a in range(dV):
                    for c in range(4): ys[pos, a, c] = (ys[pos, a, c] + coef * W[cb + a, c]) % Q
            if cur != x or w != 1: bad[x] += 1
            for a in range(dV):
                for c in range(4): acc[a, c] = ys[L, a, c]
            for j in range(L - 1, -1, -1):
                Vm = Vg[moves[j]]
                for a in range(dV):
                    for c in range(4):
                        s_ = ys[j, a, c]
                        for b in range(dV): s_ += Vm[a, b] * acc[b, c]
                        tmp[a, c] = s_ % Q
                for a in range(dV):
                    for c in range(4): acc[a, c] = tmp[a, c]
            base = (r * n + x) * dV
            for a in range(dV):
                for c in range(4): out[base + a, c] = acc[a, c]
    return out, bad.sum()
@nb.njit(cache=True, parallel=True)
def vapply_U(ucols, ptr, letters, nxt, FP, Vg, Va, colpos, laminv, Vri, root, G, n, W, Q, dV):
    """U on a whole cochain: for each non-tree edge u = (g, x), sum_b Va[b] phi(h_b) (phi by Horner along the word of the
    b-th piece read from the root), then lam_x^-1 V(r_x)^-1."""
    out = np.zeros_like(W); bad = np.zeros(ucols.shape[0], dtype=np.int64)
    for k in nb.prange(ucols.shape[0]):
        u0 = ucols[k]; x0 = u0 % n
        Tmax = 0
        for p in range(2 * k, 2 * k + 2):
            if ptr[p + 1] - ptr[p] > Tmax: Tmax = ptr[p + 1] - ptr[p]
        moves = np.empty(Tmax + 1, dtype=np.int64); ys = np.zeros((Tmax + 1, dV, 4), dtype=np.int64)
        acc = np.zeros((dV, 4), dtype=np.int64); tmp = np.zeros((dV, 4), dtype=np.int64); tot = np.zeros((dV, 4), dtype=np.int64)
        for b in range(2):
            p = 2 * k + b
            for j in range(Tmax + 1):
                for a in range(dV):
                    for c in range(4): ys[j, a, c] = 0
            cur = np.int64(root); w = np.int64(1); L = 0
            for q in range(ptr[p], ptr[p + 1]):
                l = np.int64(letters[q])
                if l < G:
                    u = l * n + cur; pos = L; coef = w
                    w = (w * FP[l, cur]) % Q; cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                else:
                    w = (w * FP[l, cur]) % Q; cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                    u = (l - G) * n + cur; pos = L; coef = (Q - w) % Q
                cb = colpos[u]
                if cb < 0: continue
                for a in range(dV):
                    for c in range(4): ys[pos, a, c] = (ys[pos, a, c] + coef * W[cb + a, c]) % Q
            if cur != root: bad[k] += 1
            for a in range(dV):
                for c in range(4): acc[a, c] = ys[L, a, c]
            for j in range(L - 1, -1, -1):
                Vm = Vg[moves[j]]
                for a in range(dV):
                    for c in range(4):
                        s_ = ys[j, a, c]
                        for bb in range(dV): s_ += Vm[a, bb] * acc[bb, c]
                        tmp[a, c] = s_ % Q
                for a in range(dV):
                    for c in range(4): acc[a, c] = tmp[a, c]
            for a in range(dV):
                for c in range(4):
                    s_ = 0
                    for bb in range(dV): s_ += Va[b, a, bb] * acc[bb, c]
                    tot[a, c] = (tot[a, c] + s_) % Q
        li = laminv[x0]; cb0 = colpos[u0]
        for a in range(dV):
            for c in range(4):
                s_ = 0
                for bb in range(dV): s_ += Vri[x0, a, bb] * tot[bb, c]
                out[cb0 + a, c] = (li * (s_ % Q)) % Q
    return out, bad.sum()
@nb.njit(cache=True, parallel=True)
def rows_apply(cols, vals, X, mul):
    """R X over F16 for fixed-width rows and a vector X (ncol,) of F16 codes."""
    R, Tw = cols.shape; out = np.zeros(R, dtype=np.uint8)
    for row in nb.prange(R):
        s = np.uint8(0)
        for t in range(Tw):
            c = cols[row, t]
            if c < 0: break
            s ^= mul[vals[row, t], X[c]]
        out[row] = s
    return out

# ---------------------------------------------------------------- the level
class VLevel:
    def __init__(self, k, S, verbose=True):
        t0 = time.time()
        self.k, self.S, self.Q, self.dV = k, S, 1 << S, (k - 1) ** 2
        Q, dV = self.Q, self.dV
        r1, r2 = sroot(23, 0), sroot(23, 1)
        self.L = L = FastLevel([CompPow2(1), Comp("Fp", 23, r1), Comp("Fp", 23, r2)], None, name="w23_2")
        self.G, self.n, self.root = G, n, root = len(L.gens), L.n, int(L.root)
        self.tg, self.te = relator_arrays(L)
        self.rv = two_adic_root(S)
        mats = [GEN[g] for g in L.gens] + [GINV[g] for g in L.gens]
        self.Vg = np.array([vmat(Mt, k, self.rv, Q) for Mt in mats], dtype=np.int64)
        I = np.eye(dV, dtype=np.int64)
        for s in range(G): assert ((self.Vg[s] @ self.Vg[G + s]) % Q == I).all(), "V(g) V(g^-1) != 1"
        self.Vg2 = (self.Vg % 2).astype(np.int64)
        # step signs: Legendre parity at the two components above 23 (no character at 2 at Iwahori level)
        xs = np.arange(n, dtype=np.int64); sg = np.zeros((2 * G, n), dtype=np.uint8)
        for s, Mt in enumerate(mats):
            for kk in (1, 2):
                c = L.comps[kk]; a, b, cm, dm = tuple(c.red(e) for e in Mt); lv = np.zeros(c.size, dtype=np.uint8)
                for i in range(c.size):
                    cc, dd = c.rep(i); nc = c.add(c.mul(cc, a), c.mul(dd, cm)); nd = c.add(c.mul(cc, b), c.mul(dd, dm))
                    j, l = c.normalize(nc, nd); lv[i] = leg23(l)
                sg[s] ^= lv[(xs // L.strides[kk]) % L.sizes[kk]]
        self.FP = np.where(sg == 1, Q - 1, 1).astype(np.int64)
        # columns: non-tree edges x dV
        self.TREE = L.TREE; nt = np.nonzero(~L.TREE)[0]; self.NONTREE = nt.astype(np.int64)
        self.colpos = -np.ones(G * n, dtype=np.int64); self.colpos[nt] = np.arange(len(nt)) * dV
        self.ncol = len(nt) * dV
        # tree transport lam_x (scalar) and V(r_x), V(r_x)^-1
        order = [root]; seen = np.zeros(n, dtype=bool); seen[root] = True; h = 0
        while h < len(order):
            x = order[h]; h += 1
            for g in range(G):
                y = int(L.NXT[g, x])
                if not seen[y]:
                    seen[y] = True; order.append(y); assert L.PAR_X[y] == x and L.PAR_G[y] == g
        self.order = order
        lam = np.ones(n, dtype=np.int64); Vr = np.zeros((n, dV, dV), dtype=np.int64); Vri = np.zeros((n, dV, dV), dtype=np.int64)
        Vr[root] = I; Vri[root] = I
        for y in order[1:]:
            x = int(L.PAR_X[y]); g = int(L.PAR_G[y])
            lam[y] = (lam[x] * self.FP[g, x]) % Q
            Vr[y] = (Vr[x] @ self.Vg[g]) % Q; Vri[y] = (self.Vg[G + g] @ Vri[x]) % Q
        self.lam = lam; self.laminv = np.array([pow(int(v), -1, Q) for v in lam], dtype=np.int64); self.Vr, self.Vri = Vr, Vri
        self.Tw = self.tg.shape[1] * dV
        if verbose: print("  level 23*2*O_E (Iwahori), weight %d: dim V = %d, index %d, %d non-tree edges, %d unknowns, %d block rows; r_v = %d mod 2^%d (%.0fs)"
                          % (k, dV, n, len(nt), self.ncol, self.tg.shape[0] * n * dV, self.rv, S, time.time() - t0), flush=True)

    def mod2_rows(self):
        cols, vals, bad = rows_mod2(self.L.NXT, self.Vg2, self.tg, self.te, self.G, self.n, self.colpos, self.dV, self.Tw)
        assert bad == 0, "relators do not close mod 2"
        return cols, vals

    def walk(self, W, Q):
        out, bad = vrel_eval(self.L.NXT, self.FP % Q, self.Vg % Q, self.tg, self.te, self.G, self.n, self.colpos, W, Q, self.dV)
        assert bad == 0
        return out

    def coboundaries(self, Q):
        """The dV coboundaries delta m_a (m_a(root) = e_a, propagated so that delta m_a = 0 on the tree), as cochains
        (ncol, 4) with values mod Q in the first GR coordinate."""
        G, n, dV, L = self.G, self.n, self.dV, self.L
        FPi = np.array([[pow(int(v), -1, Q) for v in row] for row in (self.FP % Q)], dtype=np.int64)
        out = []
        for a in range(dV):
            m = np.zeros((n, dV), dtype=np.int64); m[self.root, a] = 1
            for y in self.order[1:]:
                x = int(L.PAR_X[y]); g = int(L.PAR_G[y])
                m[y] = (FPi[g, x] * (self.Vg[G + g] @ m[x])) % Q
            W = np.zeros((self.ncol, 4), dtype=np.int64)
            for s in range(G):
                xs = np.arange(n); ys = L.NXT[s].astype(np.int64)
                val_ = ((self.FP[s] % Q)[:, None] * ((m[ys] @ self.Vg[s].T) % Q) - m) % Q
                u = s * n + xs; nt_ = ~self.TREE[u]
                assert not val_[~nt_].any(), "coboundary not zero on a tree edge"
                cp = self.colpos[u[nt_]]
                for b in range(dV): W[cp + b, 0] = val_[nt_, b]
            out.append(W)
        return out

    # ---------------------------------------------------------------- U
    def pieces_U(self, pi, h):
        reps = [((1, 0), (b, 0), (0, 0), pi) for b in range(onorm(pi))]; out = []
        for ai in reps:
            X0 = mmul(ai, h); found = None
            for aj in reps:
                X = mmul(X0, hecke.adj(aj))
                Y = tuple(hecke.odiv(e, pi) for e in X)
                if None in Y: continue
                if mdet(Y) not in ((1, 0), (-1, 0)) or not self.L.in_gamma0(Y): continue
                found = Y; break
            assert found is not None, "U coset not found"
            out.append(found)
        return out
    def build_U(self):
        L, G, n = self.L, self.G, self.n
        self.UW = {}; self.Va = {}
        for op, pi in (("Uv", V_PI), ("Uvbar", VB_PI)):
            lets = []; lens = []
            for u in self.NONTREE:
                g = L.gens[int(u) // n]; x = int(u) % n
                h = L.schreier(g, x)
                for hi_ in self.pieces_U(pi, h):
                    toks = decompose(hi_)
                    lets.extend([L.gens.index(gg) if e == 1 else G + L.gens.index(gg) for gg, e in toks]); lens.append(len(toks))
            ptr = np.zeros(len(lens) + 1, dtype=np.int64); ptr[1:] = np.cumsum(lens)
            self.UW[op] = (np.array(lets, dtype=np.int64), ptr)
            reps = [((1, 0), (b, 0), (0, 0), pi) for b in range(onorm(pi))]
            # the nebentypus of d = pi at the components above 23: (N pi / 23) = (2/23) = 1
            assert leg23(onorm(pi)) == 0
            self.Va[op] = np.array([vmat(hecke.adj(ai), self.k, self.rv, self.Q) for ai in reps], dtype=np.int64)
    def U(self, op, W, Q):
        lets, ptr = self.UW[op]
        out, bad = vapply_U(self.NONTREE, ptr, lets, self.L.NXT, self.FP % Q, self.Vg % Q, self.Va[op] % Q, self.colpos,
                            self.laminv % Q, self.Vri % Q, self.root, self.G, self.n, W, Q, self.dV)
        assert bad == 0
        return out

# ---------------------------------------------------------------- generic augmented solve on given rows
class RowsAug:
    """bockstein.AugSolve for given fixed-width rows (cols, vals) over F16 with ncol columns and RHS B (R, m): the kernel
    of R x + B t = 0 (complete, by block Lanczos with its certificate), L = projection on t, and the kernel lifted to all
    classes (kept in self.X, self.T for later use).  Checks: every kernel vector satisfies every row."""
    def __init__(self, cols, vals, ncol, B, verbose=False, seed=1):
        t0 = time.time(); m = B.shape[1]; self.m = m
        conds = Conditions(m)
        root, rfac, off, alive, passes, ncond = closure2_affine(cols, vals, ncol, B, conds.Cb, conds.piv, MUL, INV)
        conds.n = ncond
        reps = np.unique(root[root >= 0]); ncls = len(reps)
        cls_of = -np.ones(ncol, dtype=np.int32); pos = -np.ones(ncol, dtype=np.int64); pos[reps] = np.arange(ncls)
        mk = root >= 0; cls_of[mk] = pos[root[mk]].astype(np.int32)
        ptr, col, val, hs, RHS, EMP = rows_to_csr_affine(cols, vals, alive, cls_of, rfac, off, B, MUL, INV)
        conds.add(EMP)
        ptr, col, val, RHS = dedup_aug(ptr, col, val, RHS, conds, hs)
        ptr, col, val, RHS, records = markowitz_aug(ptr, col, val, RHS, ncls, conds, fill=8.0, verbose=False)
        rec_c = np.concatenate([r[0] for r in records]) if records else np.zeros(0, np.int32)
        if records:
            offs = np.cumsum([0] + [len(r[2]) for r in records])
            rp = np.concatenate([[0]] + [r[1][1:] + o for r, o in zip(records, offs[:-1])]).astype(np.int64)
            rcol = np.concatenate([r[2] for r in records]); rval = np.concatenate([r[3] for r in records]); rrhs = np.concatenate([r[4] for r in records])
        else:
            rp = np.zeros(1, np.int64); rcol = np.zeros(0, np.int32); rval = np.zeros(0, np.uint8); rrhs = np.zeros((0, m), np.uint8)
        rec_ptr, rec_col, rec_val = _records_with_rhs(rp, rcol, rval, rrhs, ncls)
        cw = np.bincount(col, minlength=ncls); elim = np.zeros(ncls, dtype=np.bool_); elim[rec_c] = True
        core_x = np.nonzero(cw > 0)[0]; free_x = np.nonzero((cw == 0) & ~elim)[0]; Cx = len(core_x)
        newid = -np.ones(ncls, dtype=np.int64); newid[core_x] = np.arange(Cx)
        cp, cc, cv = _core_with_rhs(ptr, _relabel(col, newid), val, RHS, conds.rows(), Cx)
        C = Cx + m
        core_cls = np.concatenate([core_x, ncls + np.arange(m)]).astype(np.int64)
        A = AugSolve.__new__(AugSolve); A.t = {}
        Kc = A._core(cp, cc, cv, C, seed, int(os.environ.get("ROWSAUG_LW", "4")), 6000, verbose, None)   # Lanczos block / 64 (must exceed the kernel)
        self.complete = A.complete
        dcore = Kc.shape[0]; d = dcore + len(free_x); self.d = d
        wd = max(1, (d + 63) // 64)
        Kcb = to_bits(Kc.T.copy(), wd) if dcore else np.zeros((C, 4, wd), dtype=np.uint64)
        V = lift(ncls + m, core_cls, Kcb, free_x.astype(np.int64), d, rec_c, rec_ptr, rec_col, rec_val, MASKS, INV, wd)
        Xc = from_bits(V[:ncls], d); self.T = from_bits(V[ncls:ncls + m], d); del V
        # kernel vectors on all columns: x_u = rfac[u] X[cls_of[u]] + off[u] . t
        X = np.zeros((ncol, d), dtype=np.uint8); ok = cls_of >= 0
        X[ok] = MUL[rfac[ok][:, None], Xc[cls_of[ok]]]
        for j in range(m):
            X ^= MUL[off[:, j][:, None], self.T[j][None, :]]
        self.X = X
        # check every kernel vector against every row: R x + B t = 0
        Bt = np.zeros((cols.shape[0], d), dtype=np.uint8)
        for j in range(m): Bt ^= MUL[B[:, j][:, None], self.T[j][None, :]]
        bad = 0
        for i in range(d):
            if (rows_apply(cols, vals, np.ascontiguousarray(X[:, i]), MUL) ^ Bt[:, i]).any(): bad += 1
        assert bad == 0, "%d kernel vectors fail the rows" % bad
        A_ = self.T.T.copy(); pv = list(gf.rref16(A_, MUL, INV)); self.Lech = A_[:len(pv)].copy(); self.rank_t = len(pv)
        self.dim_t0 = d - self.rank_t; self.seconds = time.time() - t0
    def t_with(self, testcols, i):
        if self.Lech.shape[0] == 0: return None
        P = self.Lech[:, testcols]; e = np.zeros(len(testcols), dtype=np.uint8); e[i] = 1
        A_ = np.concatenate([P.T, e[:, None]], axis=1).astype(np.uint8); piv = list(gf.rref16(A_, MUL, INV))
        r = P.shape[0]
        if any(p >= r for p in piv): return None
        a = np.zeros(r, dtype=np.uint8)
        for rr, p in enumerate(piv): a[p] = A_[rr, r]
        return gf.matmul16(a[None, :], self.Lech)[0]
    def x_for(self, t):
        """A solution x (ncol,) of R x + B t = 0 for t in L (a combination of the kernel vectors)."""
        A_ = np.concatenate([self.T, t[:, None]], axis=1).astype(np.uint8); piv = list(gf.rref16(A_, MUL, INV))
        dd = self.T.shape[1]
        assert not any(p >= dd for p in piv)
        c = np.zeros(dd, dtype=np.uint8)
        for rr, p in enumerate(piv): c[p] = A_[rr, dd]
        return gf.matmul16(self.X, c[:, None])[:, 0]
