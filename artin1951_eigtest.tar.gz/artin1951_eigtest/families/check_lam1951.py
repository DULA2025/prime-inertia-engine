import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
import sys, json
sys.path.insert(0, _ROOT + "/families"); sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
from t6lib import gr_mul
from p2_cases import case_1951
from sparse_h1 import MUL
QT = 16
C = case_1951(); AP = C["AP"]
TRf = json.load(open(_ROOT + "/data/galois_traces_1951.json"))
dl3 = {}; t_ = 1
for kk in range(1950): dl3[t_] = kk; t_ = t_ * 3 % 1951
def zpoly(e):
    e %= 5; v = [0, 0, 0, 0]
    if e < 4: v[e] = 1
    else: v = [QT - 1] * 4
    return v
def gadd(*gs): return [sum(int(g[i]) for g in gs) % QT for i in range(4)]
def gsc(n, g): return [(n * int(t)) % QT for t in g]
def code_of(g): return int((g[0] & 1) | ((g[1] & 1) << 1) | ((g[2] & 1) << 2) | ((g[3] & 1) << 3))
phm1 = gadd(zpoly(1), zpoly(4)); one = [1, 0, 0, 0]
def tval(t):
    for val, g in ((0.0, [0, 0, 0, 0]), (1.0, one), (-1.0, gsc(-1, one)), (2.0, gsc(2, one)), (-2.0, gsc(-2, one)),
                   (0.6180339887498949, phm1), (-0.6180339887498949, gsc(-1, phm1)), (1.618033988749895, gadd(one, phm1)), (-1.618033988749895, gsc(-1, gadd(one, phm1)))):
        if abs(t - val) < 1e-9: return g
    raise ValueError(t)
def conj(g, j):
    out = [0, 0, 0, 0]
    for i in range(4):
        if g[i]: out = gadd(out, gsc(int(g[i]), zpoly(i * j)))
    return out
for j in (1, 2, 3, 4):
    ok = 0; bad = []
    for p in [q for q in range(3, 2000) if all(q % d for d in range(2, int(q ** 0.5) + 1)) and q != 1951]:
        a = conj(gr_mul(zpoly(dl3[p % 1951]), tval(TRf["t"][str(p)]), QT), j)
        if code_of(a) == AP[p] if p in AP else True: ok += 1
        elif p in AP: bad.append(p)
    print("conjugate %d: mod-2 reduction of chi(p)^3 t_p equals the residual trace of case_1951 at %d primes, differs at %d (first: %s)" % (j, ok, len(bad), bad[:5]))
# exact check of the characteristic-0 values: |a_p|^2 numerically vs the float traces
import cmath
z = cmath.exp(2j * cmath.pi / 5)
def ev(g): return sum(int(t if t < QT // 2 else t - QT) * z ** i for i, t in enumerate(g))
mx = 0
for p in (3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43):
    a_float = z ** ((6 * dl3[p % 1951]) % 5) * TRf["t"][str(p)]          # chi(p)^3 t_p with chi = zeta^(2 dl)
    mx = max(mx, abs(ev(conj(gr_mul(zpoly(dl3[p % 1951]), tval(TRf["t"][str(p)]), QT), 1)) - a_float))
print("max |GR value (read in C) - chi(p)^3 t_p| at 13 primes, conjugate 1: %.2e" % mx)
