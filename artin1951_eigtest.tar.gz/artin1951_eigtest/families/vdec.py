import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Route (b) at odd weights up to 17: Kronecker kernels and the mod-2 decomposition into 4-dimensional pieces.

At weight k the coefficients V = Sym^m (x) Sym^m (m = k - 2, d1 = m + 1) have dimension (k - 1)^2: 64 at k = 9, 256 at
k = 17.  vbock.py stores full dV x dV matrices (V(r_x) for all 5184 cosets: 2.7 GB at k = 17) and fixed-width mod-2
rows of width T dV (123 GB at k = 17).  Here:
  1. V(g) = A(g) (x) B(g) acts on Y (a d1 x d1 array) as A Y B^T: 2 d1^3 products instead of d1^4.  A, B and the tree
     transports are stored as factors (vrel_eval_k, vapply_U_k give the same numbers as vbock's kernels; checked at
     k = 3 and 5 by vdec_check.py).
  2. Mod 2, Sym^m(F_2^2) with m odd is a projective GL_2(F_2)-module (t = [[0,1],[1,0]] swaps X^(m-j) Y^j and
     X^j Y^(m-j) and fixes no monomial, so the restriction to the Sylow subgroup <t> is free), P(1)^a + St^b with
     (a, b) = (0,1), (1,1), (1,2), (1,3), (2,3), (2,4), (2,5), (3,5) for m = 1, 3, ..., 15.  With s = [[0,1],[1,1]], t = [[0,1],[1,0]]: the image of e0 = 1 + s + s^2 (the
     C_3-invariants) is free over F_2[C_2], with basis pairs [w, t w]; the image of e1 = s + s^2 is St^b, with basis
     pairs [f, s f] for f fixed by t.  In this basis (Sm) every element of GL_2(F_2) is block diagonal with 2 x 2 blocks
     that depend only on the block type, so V(g) mod 2 = A (x) B is block diagonal with 4 x 4 blocks of four types
     (P or St at v) x (P or St at vbar), multiplicities a^2, ab, ba, b^2: the mod-2 complex splits into pieces, and each
     type has its own rows of width 4 T (vbock.rows_mod2 with dV = 4).
  3. U mod 2 in the adapted basis: block-diagonal walks and the U-matrices V(adj alpha_b) mod 2 as dense factors, all
     as XORs of F16 codes.
Conventions as in vbock.py.  Author: Dula."""
import sys, os, time
sys.path.insert(0, _ROOT + "/families"); sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
import numpy as np, numba as nb
from t6lib import CompPow2, leg23
from bmf import Comp
from sparse_h1 import FastLevel, MUL, INV, relator_arrays
from mod2_refine import root as sroot
from o7 import GEN, GINV, mmul, mdet, onorm, decompose
from bianchi4 import V_PI, VB_PI
import hecke, gf
from vbock import two_adic_root, sympow_mod, emb, rows_mod2

def symmat(Mt, m, r, Q):
    return sympow_mod(emb(Mt[0], r, Q), emb(Mt[1], r, Q), emb(Mt[2], r, Q), emb(Mt[3], r, Q), m, Q)

# ---------------------------------------------------------------- F2 helpers (0/1 matrices through the F16 routines)
def f2_rank(M): return gf.rank16(np.asarray(M, dtype=np.uint8) & 1)
def f2_inv(M):
    d = M.shape[0]; A = np.concatenate([np.asarray(M, dtype=np.uint8) & 1, np.eye(d, dtype=np.uint8)], axis=1)
    piv = list(gf.rref16(A, MUL, INV)); assert piv == list(range(d)), "not invertible over F2"
    return A[:, d:].astype(np.int64)
def f2_rowspace(M):
    A = np.asarray(M, dtype=np.uint8).copy() & 1; piv = list(gf.rref16(A, MUL, INV)); return A[:len(piv)].astype(np.int64)

def sym_decomposition(m):
    """Sm (columns: the adapted basis of Sym^m(F_2^2)), its inverse, a, b, and the block types ('P' * a + 'S' * b)."""
    d = m + 1; I = np.eye(d, dtype=np.int64)
    sig = sympow_mod(0, 1, 1, 1, m, 2) % 2; tau = sympow_mod(0, 1, 1, 0, m, 2) % 2
    s2 = (sig @ sig) % 2
    assert ((s2 @ sig) % 2 == I).all() and ((tau @ tau) % 2 == I).all(), "s^3 or t^2 is not 1 on Sym^m"
    e0 = (I + sig + s2) % 2; e1 = (sig + s2) % 2
    r0 = f2_rank(e0); r1 = f2_rank(e1); assert r0 + r1 == d and r0 % 2 == 0 and r1 % 2 == 0
    cur = np.zeros((0, d), dtype=np.int64); W = []
    for j in range(d):
        w = e0[:, j]
        if not w.any(): continue
        cand = np.vstack([cur, w[None, :], ((tau @ w) % 2)[None, :]])
        if f2_rank(cand) == cur.shape[0] + 2: cur = cand; W.append(w)
    assert cur.shape[0] == r0, "the C_3-invariants are not free over F_2[C_2]"
    E1 = f2_rowspace(e1.T)                                         # rows: a basis of im e1
    Kc = gf.kernel16((((tau + I) % 2) @ E1.T % 2).astype(np.uint8))  # c with (t + 1) E1^T c = 0
    F = (Kc.astype(np.int64) @ E1) % 2
    assert F.shape[0] * 2 == r1, "t-fixed part of St^b has the wrong dimension"
    colsS = []
    for w in W: colsS += [w, (tau @ w) % 2]
    for f in F: colsS += [f, (sig @ f) % 2]
    Sm = np.stack(colsS, axis=1) % 2; Sminv = f2_inv(Sm)
    a, b = len(W), F.shape[0]; types = ["P"] * a + ["S"] * b
    blk = {"P": {"s": np.eye(2, dtype=np.int64), "t": np.array([[0, 1], [1, 0]])},
           "S": {"s": np.array([[0, 1], [1, 1]]), "t": np.array([[1, 1], [0, 1]])}}
    for nm, g in (("s", sig), ("t", tau)):
        D = (Sminv @ g @ Sm) % 2
        for q in range(d // 2):
            for q2 in range(d // 2):
                B_ = D[2 * q:2 * q + 2, 2 * q2:2 * q2 + 2]
                if q == q2: assert (B_ == blk[types[q]][nm]).all(), "unexpected diagonal block"
                else: assert not B_.any(), "not block diagonal"
    return Sm, Sminv, a, b, types

# ---------------------------------------------------------------- numba kernels
@nb.njit(cache=True)
def _kmv(A, B, Y, Z, out, Q, d1):
    """out = (A (x) B) Y mod Q for Y (d1 d1, 4) (index i d1 + j), via A Y B^T; Z is scratch (d1, d1, 4)."""
    for k in range(d1):
        for j in range(d1):
            s0 = 0; s1 = 0; s2 = 0; s3 = 0
            for l in range(d1):
                b = B[j, l]
                if b == 0: continue
                p = k * d1 + l
                s0 += b * Y[p, 0]; s1 += b * Y[p, 1]; s2 += b * Y[p, 2]; s3 += b * Y[p, 3]
            Z[k, j, 0] = s0 % Q; Z[k, j, 1] = s1 % Q; Z[k, j, 2] = s2 % Q; Z[k, j, 3] = s3 % Q
    for i in range(d1):
        for j in range(d1):
            s0 = 0; s1 = 0; s2 = 0; s3 = 0
            for kk in range(d1):
                a = A[i, kk]
                if a == 0: continue
                s0 += a * Z[kk, j, 0]; s1 += a * Z[kk, j, 1]; s2 += a * Z[kk, j, 2]; s3 += a * Z[kk, j, 3]
            p = i * d1 + j
            out[p, 0] = s0 % Q; out[p, 1] = s1 % Q; out[p, 2] = s2 % Q; out[p, 3] = s3 % Q

@nb.njit(cache=True, parallel=True)
def vrel_eval_k(nxt, FP, Ag, Bg, tg, te, G, n, colpos, W, Q, d1):
    """As vbock.vrel_eval, with V(g) = A(g) (x) B(g)."""
    nr, T = tg.shape; dV = d1 * d1
    out = np.zeros((nr * n * dV, 4), dtype=np.int64); bad = np.zeros(n, dtype=np.int64)
    for x in nb.prange(n):
        moves = np.empty(T, dtype=np.int64); ys = np.zeros((T + 1, dV, 4), dtype=np.int64)
        acc = np.zeros((dV, 4), dtype=np.int64); tmp = np.zeros((dV, 4), dtype=np.int64); Z = np.zeros((d1, d1, 4), dtype=np.int64)
        for r in range(nr):
            for j in range(T + 1):
                for a in range(dV):
                    for c in range(4): ys[j, a, c] = 0
            cur = np.int64(x); w = np.int64(1); L = 0
            for j in range(T):
                g = np.int64(tg[r, j])
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; pos = L; coef = w
                    w = (w * FP[g, cur]) % Q; cur = np.int64(nxt[g, cur]); moves[L] = g; L += 1
                else:
                    s = G + g; w = (w * FP[s, cur]) % Q; cur = np.int64(nxt[s, cur]); moves[L] = s; L += 1
                    u = g * n + cur; pos = L; coef = (Q - w) % Q
                cb = colpos[u]
                if cb < 0: continue
                for a in range(dV):
                    for c in range(4): ys[pos, a, c] = (ys[pos, a, c] + coef * W[cb + a, c]) % Q
            if cur != x or w != 1: bad[x] += 1
            for a in range(dV):
                for c in range(4): acc[a, c] = ys[L, a, c]
            for j in range(L - 1, -1, -1):
                mv = moves[j]
                _kmv(Ag[mv], Bg[mv], acc, Z, tmp, Q, d1)
                for a in range(dV):
                    for c in range(4): acc[a, c] = (ys[j, a, c] + tmp[a, c]) % Q
            base = (r * n + x) * dV
            for a in range(dV):
                for c in range(4): out[base + a, c] = acc[a, c]
    return out, bad.sum()

@nb.njit(cache=True, parallel=True)
def vapply_U_k(ucols, ptr, letters, nxt, FP, Ag, Bg, VaA, VaB, colpos, laminv, RiA, RiB, root, G, n, W, Q, d1):
    """As vbock.vapply_U, with V = A (x) B throughout (V(adj alpha_b) = VaA[b] (x) VaB[b], V(r_x)^-1 = RiA[x] (x) RiB[x])."""
    dV = d1 * d1
    out = np.zeros_like(W); bad = np.zeros(ucols.shape[0], dtype=np.int64)
    for k in nb.prange(ucols.shape[0]):
        u0 = ucols[k]; x0 = u0 % n
        Tmax = 0
        for p in range(2 * k, 2 * k + 2):
            if ptr[p + 1] - ptr[p] > Tmax: Tmax = ptr[p + 1] - ptr[p]
        moves = np.empty(Tmax + 1, dtype=np.int64); ys = np.zeros((Tmax + 1, dV, 4), dtype=np.int64)
        acc = np.zeros((dV, 4), dtype=np.int64); tmp = np.zeros((dV, 4), dtype=np.int64); tot = np.zeros((dV, 4), dtype=np.int64)
        Z = np.zeros((d1, d1, 4), dtype=np.int64)
        for b in range(2):
            p = 2 * k + b
            for j in range(Tmax + 1):
                for a in range(dV):
                    for c in range(4): ys[j, a, c] = 0
            cur = np.int64(root); w = np.int64(1); L = 0
            for q in range(ptr[p], ptr[p + 1]):
                l = np.int64(letters[q])
                if l < G:
                    u = l * n + cur; pos = L; coef = w
                    w = (w * FP[l, cur]) % Q; cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                else:
                    w = (w * FP[l, cur]) % Q; cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                    u = (l - G) * n + cur; pos = L; coef = (Q - w) % Q
                cb = colpos[u]
                if cb < 0: continue
                for a in range(dV):
                    for c in range(4): ys[pos, a, c] = (ys[pos, a, c] + coef * W[cb + a, c]) % Q
            if cur != root: bad[k] += 1
            for a in range(dV):
                for c in range(4): acc[a, c] = ys[L, a, c]
            for j in range(L - 1, -1, -1):
                mv = moves[j]
                _kmv(Ag[mv], Bg[mv], acc, Z, tmp, Q, d1)
                for a in range(dV):
                    for c in range(4): acc[a, c] = (ys[j, a, c] + tmp[a, c]) % Q
            _kmv(VaA[b], VaB[b], acc, Z, tmp, Q, d1)
            for a in range(dV):
                for c in range(4): tot[a, c] = (tot[a, c] + tmp[a, c]) % Q
        _kmv(RiA[x0], RiB[x0], tot, Z, tmp, Q, d1)
        li = laminv[x0]; cb0 = colpos[u0]
        for a in range(dV):
            for c in range(4): out[cb0 + a, c] = (li * tmp[a, c]) % Q
    return out, bad.sum()

@nb.njit(cache=True)
def _smv2(cA, iA, cB, iB, Y, Z, out, d1):
    """out = A Y B^T over F_2 acting on F16 codes (XOR); A, B given by their non-zero positions per row."""
    for k in range(d1):
        for j in range(d1):
            s = np.uint8(0)
            for t in range(cB[j]): s ^= Y[k, iB[j, t]]
            Z[k, j] = s
    for i in range(d1):
        for j in range(d1):
            s = np.uint8(0)
            for t in range(cA[i]): s ^= Z[iA[i, t], j]
            out[i, j] = s

@nb.njit(cache=True, parallel=True)
def u2_apply(ucols, ptr, letters, nxt, cA, iA, cB, iB, vcA, viA, vcB, viB, ntidx, rcA, riA, rcB, riB, root, G, n, Y, d1):
    """U mod 2 on a cochain Y (Nnt, d1, d1) of F16 codes in the adapted basis (rows of Y: non-tree edges in order).
    Signs and lam are 1 mod 2."""
    N = ucols.shape[0]; out = np.zeros_like(Y); bad = np.zeros(N, dtype=np.int64)
    for k in nb.prange(N):
        u0 = ucols[k]; x0 = u0 % n
        Tmax = 0
        for p in range(2 * k, 2 * k + 2):
            if ptr[p + 1] - ptr[p] > Tmax: Tmax = ptr[p + 1] - ptr[p]
        moves = np.empty(Tmax + 1, dtype=np.int64); ys = np.zeros((Tmax + 1, d1, d1), dtype=np.uint8)
        acc = np.zeros((d1, d1), dtype=np.uint8); tmp = np.zeros((d1, d1), dtype=np.uint8); tot = np.zeros((d1, d1), dtype=np.uint8)
        Z = np.zeros((d1, d1), dtype=np.uint8)
        for b in range(2):
            p = 2 * k + b
            for j in range(Tmax + 1):
                for i in range(d1):
                    for jj in range(d1): ys[j, i, jj] = 0
            cur = np.int64(root); L = 0
            for q in range(ptr[p], ptr[p + 1]):
                l = np.int64(letters[q])
                if l < G:
                    u = l * n + cur; pos = L
                    cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                else:
                    cur = np.int64(nxt[l, cur]); moves[L] = l; L += 1
                    u = (l - G) * n + cur; pos = L
                e = ntidx[u]
                if e < 0: continue
                for i in range(d1):
                    for jj in range(d1): ys[pos, i, jj] ^= Y[e, i, jj]
            if cur != root: bad[k] += 1
            for i in range(d1):
                for jj in range(d1): acc[i, jj] = ys[L, i, jj]
            for j in range(L - 1, -1, -1):
                mv = moves[j]
                _smv2(cA[mv], iA[mv], cB[mv], iB[mv], acc, Z, tmp, d1)
                for i in range(d1):
                    for jj in range(d1): acc[i, jj] = ys[j, i, jj] ^ tmp[i, jj]
            _smv2(vcA[b], viA[b], vcB[b], viB[b], acc, Z, tmp, d1)
            for i in range(d1):
                for jj in range(d1): tot[i, jj] ^= tmp[i, jj]
        _smv2(rcA[x0], riA[x0], rcB[x0], riB[x0], tot, Z, tmp, d1)
        for i in range(d1):
            for jj in range(d1): out[k, i, jj] = tmp[i, jj]
    return out, bad.sum()

def nzform(Ms):
    """(count, index) arrays of the non-zero positions per row of 0/1 matrices Ms (..., d1, d1)."""
    Ms = np.asarray(Ms) % 2; sh = Ms.shape; d1 = sh[-1]; F = Ms.reshape(-1, d1, d1)
    cnt = np.zeros((F.shape[0], d1), dtype=np.int64); idx = np.zeros((F.shape[0], d1, d1), dtype=np.int64)
    for t in range(F.shape[0]):
        for i in range(d1):
            nz = np.nonzero(F[t, i])[0]; cnt[t, i] = len(nz); idx[t, i, :len(nz)] = nz
    return cnt.reshape(sh[:-1]), idx.reshape(sh)

def f2_sandwich(X, Lm, Rm):
    """Lm X Rm^T over F_2 on each bit plane of the F16 codes X (N, d1, d1)."""
    Lf = (np.asarray(Lm) % 2).astype(np.float32); Rf = (np.asarray(Rm) % 2).T.astype(np.float32)
    out = np.zeros(X.shape, dtype=np.uint8)
    for b in range(4):
        P = ((X >> b) & 1).astype(np.float32)
        Yb = np.matmul(np.matmul(Lf, P), Rf)
        out |= ((np.rint(Yb).astype(np.int64) & 1).astype(np.uint8) << b)
    return out
def pieces(Y):
    N, d1, _ = Y.shape; h = d1 // 2
    return Y.reshape(N, h, 2, h, 2).transpose(0, 1, 3, 2, 4).reshape(N, h, h, 4)
def unpieces(P):
    N, h, _, _ = P.shape
    return P.reshape(N, h, h, 2, 2).transpose(0, 1, 3, 2, 4).reshape(N, 2 * h, 2 * h)

# ---------------------------------------------------------------- the level
class VDLevel:
    def __init__(self, k, S, verbose=True):
        t0 = time.time()
        self.k, self.S, self.Q = k, S, 1 << S
        self.m = m = k - 2; self.d1 = d1 = m + 1; self.dV = dV = d1 * d1; Q = self.Q
        r1, r2 = sroot(23, 0), sroot(23, 1)
        self.L = L = FastLevel([CompPow2(1), Comp("Fp", 23, r1), Comp("Fp", 23, r2)], None, name="w23_2")
        self.G, self.n, self.root = G, n, root = len(L.gens), L.n, int(L.root)
        self.tg, self.te = relator_arrays(L)
        self.rv = rv = two_adic_root(S); self.rb = rb = (1 - rv) % Q
        mats = [GEN[g] for g in L.gens] + [GINV[g] for g in L.gens]
        self.Ag = np.array([symmat(Mt, m, rv, Q) for Mt in mats], dtype=np.int64)
        self.Bg = np.array([symmat(Mt, m, rb, Q) for Mt in mats], dtype=np.int64)
        I = np.eye(d1, dtype=np.int64)
        for s in range(G):
            assert ((self.Ag[s] @ self.Ag[G + s]) % Q == I).all() and ((self.Bg[s] @ self.Bg[G + s]) % Q == I).all(), "V(g) V(g^-1) != 1"
        xs = np.arange(n, dtype=np.int64); sg = np.zeros((2 * G, n), dtype=np.uint8)
        for s, Mt in enumerate(mats):
            for kk in (1, 2):
                c = L.comps[kk]; a, b, cm, dm = tuple(c.red(e) for e in Mt); lv = np.zeros(c.size, dtype=np.uint8)
                for i in range(c.size):
                    cc, dd = c.rep(i); nc = c.add(c.mul(cc, a), c.mul(dd, cm)); nd = c.add(c.mul(cc, b), c.mul(dd, dm))
                    j, l = c.normalize(nc, nd); lv[i] = leg23(l)
                sg[s] ^= lv[(xs // L.strides[kk]) % L.sizes[kk]]
        self.FP = np.where(sg == 1, Q - 1, 1).astype(np.int64)
        self.TREE = L.TREE; nt = np.nonzero(~L.TREE)[0]; self.NONTREE = nt.astype(np.int64); self.Nnt = len(nt)
        self.colpos = -np.ones(G * n, dtype=np.int64); self.colpos[nt] = np.arange(len(nt)) * dV
        self.colpos4 = -np.ones(G * n, dtype=np.int64); self.colpos4[nt] = np.arange(len(nt)) * 4
        self.ntidx = -np.ones(G * n, dtype=np.int64); self.ntidx[nt] = np.arange(len(nt))
        self.ncol = len(nt) * dV; self.ncol4 = len(nt) * 4
        order = [root]; seen = np.zeros(n, dtype=bool); seen[root] = True; h = 0
        while h < len(order):
            x = order[h]; h += 1
            for g in range(G):
                y = int(L.NXT[g, x])
                if not seen[y]:
                    seen[y] = True; order.append(y); assert L.PAR_X[y] == x and L.PAR_G[y] == g
        self.order = order
        lam = np.ones(n, dtype=np.int64)
        RA = np.zeros((n, d1, d1), dtype=np.int64); RB = np.zeros((n, d1, d1), dtype=np.int64)
        RiA = np.zeros((n, d1, d1), dtype=np.int64); RiB = np.zeros((n, d1, d1), dtype=np.int64)
        RA[root] = I; RB[root] = I; RiA[root] = I; RiB[root] = I
        for y in order[1:]:
            x = int(L.PAR_X[y]); g = int(L.PAR_G[y])
            lam[y] = (lam[x] * self.FP[g, x]) % Q
            RA[y] = (RA[x] @ self.Ag[g]) % Q; RB[y] = (RB[x] @ self.Bg[g]) % Q
            RiA[y] = (self.Ag[G + g] @ RiA[x]) % Q; RiB[y] = (self.Bg[G + g] @ RiB[x]) % Q
        self.lam = lam; self.laminv = np.array([pow(int(v), -1, Q) for v in lam], dtype=np.int64)
        self.RA, self.RB, self.RiA, self.RiB = RA, RB, RiA, RiB
        if verbose: print("  level 23*2*O_E (Iwahori), weight %d: dim V = %d = %d^2, index %d, %d non-tree edges, %d unknowns; r_v = %d mod 2^%d (%.0fs)"
                          % (k, dV, d1, n, len(nt), self.ncol, rv, S, time.time() - t0), flush=True)

    # ---------------------------------------------------------------- mod 2 decomposition
    def decompose(self):
        G, d1 = self.G, self.d1
        self.Sm, self.Sminv, self.a, self.b, self.btypes = sym_decomposition(self.m)
        DA = np.array([(self.Sminv @ (A % 2) @ self.Sm) % 2 for A in self.Ag]); DB = np.array([(self.Sminv @ (B % 2) @ self.Sm) % 2 for B in self.Bg])
        blkA = {}; blkB = {}
        for D, blk in ((DA, blkA), (DB, blkB)):
            for s in range(2 * G):
                for q in range(d1 // 2):
                    for q2 in range(d1 // 2):
                        B_ = D[s, 2 * q:2 * q + 2, 2 * q2:2 * q2 + 2]
                        if q != q2: assert not B_.any(), "V(g) mod 2 is not block diagonal in the adapted basis"
                        else:
                            t = self.btypes[q]
                            if (t, s) in blk: assert (blk[(t, s)] == B_).all(), "blocks of one type differ"
                            else: blk[(t, s)] = B_.copy()
        self.DA, self.DB = DA, DB
        h = d1 // 2
        self.types = [(t1, t2) for t1 in ("P", "S") for t2 in ("P", "S") if t1 in self.btypes and t2 in self.btypes]
        self.Dtype = {}; self.tpieces = {}
        for (t1, t2) in self.types:
            self.Dtype[(t1, t2)] = np.array([np.kron(blkA[(t1, s)], blkB[(t2, s)]) for s in range(2 * G)], dtype=np.int64)
            self.tpieces[(t1, t2)] = [(q1, q2) for q1 in range(h) for q2 in range(h) if self.btypes[q1] == t1 and self.btypes[q2] == t2]
        # mod-2 factors in the adapted basis, in non-zero-position form
        self.nzA = nzform(DA); self.nzB = nzform(DB)
        RiDA = np.array([(self.Sminv @ (M % 2) @ self.Sm) % 2 for M in self.RiA]); RiDB = np.array([(self.Sminv @ (M % 2) @ self.Sm) % 2 for M in self.RiB])
        self.nzRiA = nzform(RiDA); self.nzRiB = nzform(RiDB)
        return self

    def type_rows(self, tau):
        cols, vals, bad = rows_mod2(self.L.NXT, self.Dtype[tau], self.tg, self.te, self.G, self.n, self.colpos4, 4, self.tg.shape[1] * 4)
        assert bad == 0, "relators do not close mod 2"
        return cols, vals

    def type_coboundaries(self, tau):
        """The 4 coboundaries delta m_a (m_a(root) = e_a) of the type-tau piece system, as F16 codes (4, ncol4)."""
        G, n, L = self.G, self.n, self.L; D = self.Dtype[tau]
        out = np.zeros((4, self.ncol4), dtype=np.uint8)
        for a in range(4):
            mm = np.zeros((n, 4), dtype=np.int64); mm[self.root, a] = 1
            for y in self.order[1:]:
                x = int(L.PAR_X[y]); g = int(L.PAR_G[y])
                mm[y] = (D[G + g] @ mm[x]) % 2
            for s in range(G):
                xs = np.arange(n); ys = L.NXT[s].astype(np.int64)
                val_ = ((mm[ys] @ D[s].T) % 2 - mm) % 2
                u = s * n + xs; nt_ = ~self.TREE[u]
                assert not val_[~nt_].any(), "coboundary not zero on a tree edge"
                cp = self.colpos4[u[nt_]]
                for b in range(4): out[a, cp + b] = val_[nt_, b]
        return out

    # ---------------------------------------------------------------- old <-> adapted coordinates (mod 2)
    def to_old(self, Yn):          # (N, d1, d1) adapted -> (N, d1, d1) standard
        return f2_sandwich(Yn, self.Sm, self.Sm)
    def to_new(self, Yo):          # (N, d1, d1) standard -> adapted
        return f2_sandwich(Yo, self.Sminv, self.Sminv)

    # ---------------------------------------------------------------- relator walk and U
    def walk(self, W, Q):
        out, bad = vrel_eval_k(self.L.NXT, self.FP % Q, self.Ag % Q, self.Bg % Q, self.tg, self.te, self.G, self.n, self.colpos, W, Q, self.d1)
        assert bad == 0
        return out
    def pieces_U(self, pi, h):
        reps = [((1, 0), (b, 0), (0, 0), pi) for b in range(onorm(pi))]; out = []
        for ai in reps:
            X0 = mmul(ai, h); found = None
            for aj in reps:
                X = mmul(X0, hecke.adj(aj))
                Y = tuple(hecke.odiv(e, pi) for e in X)
                if None in Y: continue
                if mdet(Y) not in ((1, 0), (-1, 0)) or not self.L.in_gamma0(Y): continue
                found = Y; break
            assert found is not None, "U coset not found"
            out.append(found)
        return out
    def build_U(self):
        L, G, n = self.L, self.G, self.n
        self.UW = {}; self.VaA = {}; self.VaB = {}; self.nzVaA = {}; self.nzVaB = {}
        for op, pi in (("Uv", V_PI), ("Uvbar", VB_PI)):
            lets = []; lens = []
            for u in self.NONTREE:
                g = L.gens[int(u) // n]; x = int(u) % n
                h = L.schreier(g, x)
                for hi_ in self.pieces_U(pi, h):
                    toks = decompose(hi_)
                    lets.extend([L.gens.index(gg) if e == 1 else G + L.gens.index(gg) for gg, e in toks]); lens.append(len(toks))
            ptr = np.zeros(len(lens) + 1, dtype=np.int64); ptr[1:] = np.cumsum(lens)
            self.UW[op] = (np.array(lets, dtype=np.int64), ptr)
            reps = [((1, 0), (b, 0), (0, 0), pi) for b in range(onorm(pi))]
            assert leg23(onorm(pi)) == 0
            self.VaA[op] = np.array([symmat(hecke.adj(ai), self.m, self.rv, self.Q) for ai in reps], dtype=np.int64)
            self.VaB[op] = np.array([symmat(hecke.adj(ai), self.m, self.rb, self.Q) for ai in reps], dtype=np.int64)
            if hasattr(self, "Sm"):
                self.nzVaA[op] = nzform(np.array([(self.Sminv @ (M % 2) @ self.Sm) % 2 for M in self.VaA[op]]))
                self.nzVaB[op] = nzform(np.array([(self.Sminv @ (M % 2) @ self.Sm) % 2 for M in self.VaB[op]]))
    def U(self, op, W, Q):
        lets, ptr = self.UW[op]
        out, bad = vapply_U_k(self.NONTREE, ptr, lets, self.L.NXT, self.FP % Q, self.Ag % Q, self.Bg % Q, self.VaA[op] % Q, self.VaB[op] % Q,
                              self.colpos, self.laminv % Q, self.RiA % Q, self.RiB % Q, self.root, self.G, self.n, W, Q, self.d1)
        assert bad == 0
        return out
    def U2(self, op, Yn):
        """U mod 2 on a cochain in the adapted basis, Yn (Nnt, d1, d1) F16 codes."""
        lets, ptr = self.UW[op]
        out, bad = u2_apply(self.NONTREE, ptr, lets, self.L.NXT, self.nzA[0], self.nzA[1], self.nzB[0], self.nzB[1],
                            self.nzVaA[op][0], self.nzVaA[op][1], self.nzVaB[op][0], self.nzVaB[op][1], self.ntidx,
                            self.nzRiA[0], self.nzRiA[1], self.nzRiB[0], self.nzRiB[1], self.root, self.G, self.n,
                            np.ascontiguousarray(Yn), self.d1)
        assert bad == 0
        return out
