import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Case data for the prime-to-2 tower: level components, the F16 tables of the order-5 part of the level character, the
bit functions of its sign part, the Frobenius eigenvalues (x, y) at 2 and the rbar eigenvalues of further Hecke
operators.  633: the weight-one newform 633.1.m.b (projective image A5), found and reduced exactly as in
bianchi2/run_big.py (same PARI steps, same prime above 2, same F16 encoding); the sign part is new: the level carries
eps^-1 o N, whose quadratic part is eps_2 o N with eps_2 = eps^5, read from chareval.  Author: Dula."""
import sys
sys.path.insert(0, _ROOT + "/families"); sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
import numpy as np, cypari2
from sparse_h1 import MUL, INV
from bmf import Comp
from mod2_refine import root as sroot
from o7 import onorm, oconj
from t6lib import leg23
import gf

def case_23():
    w_, w2_ = sorted(a for a in range(16) if gf.MUL16[a, a] ^ a ^ 1 == 0)
    return {"name": "23", "comps": [Comp("Fp", 23, sroot(23, 0)), Comp("Fp", 23, sroot(23, 1))], "EC": None,
            "bitfuns": [leg23, leg23], "x": w_, "y": w2_, "loc": []}

def find_pi(p):
    for yy in range(1, 60):
        for xx in range(-120, 120):
            if onorm((xx, yy)) == p: return (xx, yy)

def case_form(N, k=1, o=10, par="odd", sel="A5", nloc=6):
    pari = cypari2.Pari(); pari.allocatemem(2 * 10**9, silent=True)
    def ev16(cs, th):
        r = 0; pw = 1
        for c in cs:
            if c: r ^= pw
            pw = int(MUL[pw, th])
        return r
    PRS = [int(q) for q in pari("primes([3, 200])")]
    NB = 400
    pari("G = znstar(%d, 1); L = chargalois(G); IX = select(i -> charorder(G, L[i]) == %d && zncharisodd(G, L[i]) == %d, [1..#L]);" % (N, o, 1 if par == "odd" else 0))
    found = None
    for ii in range(1, int(pari("#IX")) + 1):
        pari("mf = mfinit([%d, %d, [G, L[IX[%d]]]], 0);" % (N, k, ii))
        if int(pari("mfdim(mf)")) == 0: continue
        pari("B = mfeigenbasis(mf);")
        pari("ty = mfgaloistype(mf);")
        for j in range(1, int(pari("#B")) + 1):
            if int(pari("ty[%d]" % j)) == -60: found = (ii, j); break
        if found: break
    assert found, "no form found"
    ii, j = found
    pari("f = B[%d]; co = mfcoefs(f, %d); cm = mfparams(mf)[3]; Gm = znstar(cm.mod, 1); chm = znconreychar(Gm, cm); "
         "cyc = mfparams(mf)[5]; om = charorder(Gm, chm); P = mffields(mf)[%d];" % (j, NB, j))
    pari("R = rnfequation(cyc, P, 1); Pabs = R[1]; A = lift(R[2]); kk = R[3];")
    pari("toabs(c) = Mod(subst(subst(liftall(c), 'y, 'y - kk * A), 't, A), Pabs);")
    pari("epsv(p) = Mod(t^(chareval(Gm, chm, p) * om), cyc);")
    pari("nf = nfinit([Pabs, [2]]); dec = idealprimedec(nf, 2);")
    cands = [kk_ for kk_ in range(1, int(pari("#dec")) + 1) if 4 % int(pari("dec[%d].f" % kk_)) == 0 and int(pari("dec[%d].f" % kk_)) > 1]
    pari("modP = nfmodprinit(nf, dec[%d]);" % cands[0])
    pari("rdx(x) = nfmodpr(nf, toabs(x), modP);")
    pari("g0 = rdx(co[3]); gen = ffgen(g0); m = gen.mod;")
    mc = [int(c) % 2 for c in pari("Vecrev(lift(m))")]
    th = [xx for xx in range(16) if ev16(mc, xx) == 0][0]
    def to16(expr):
        if int(pari("type(%s) == \"t_FFELT\"" % expr)):
            return ev16([int(c) % 2 for c in pari("my(z = %s); Vecrev(lift(z.pol))" % expr)], th)
        return ev16([int(pari("lift(%s)" % expr)) % 2], th)
    AP = {p: to16("rdx(co[%d + 1])" % p) for p in PRS if N % p}
    EP2 = to16("rdx(epsv(2))"); a2 = to16("rdx(co[3])")
    xy = [xx for xx in range(1, 16) if MUL[xx, xx] ^ MUL[a2, xx] ^ EP2 == 0]
    x, y = (xy[0], xy[1]) if len(xy) == 2 else (xy[0], xy[0])
    order = int(pari("om"))
    def tables(q):
        """F16 table of eps^-1 on (Z/q)^x (as run_big.eps_inv_table) and the parity bit table of eps on (Z/q)^x."""
        gq0 = int(pari("znprimroot(%d)" % q).lift())
        gq = int(pari("lift(chinese(Mod(%d, %d), Mod(1, %d)))" % (gq0, q, N // q)))
        eg = int(INV[to16("rdx(epsv(%d))" % gq)])
        kq = int(pari("chareval(Gm, chm, %d) * om" % gq)) % order     # eps(gq) = zeta_om^kq
        tabq = {}; bitq = {}; cur = 1; acc = 1
        for i in range(q - 1):
            tabq[cur] = acc; bitq[cur] = (i * kq) % 2 if order % 2 == 0 else 0
            cur = cur * gq0 % q; acc = int(MUL[acc, eg])
        return tabq, bitq
    comps = []; EC = []; bitfuns = []; bit_info = {}
    for q in [int(q) for q in pari("factor(%d)[,1]~" % N)]:
        kr = int(pari("kronecker(-7, %d)" % q)); tq, bq = tables(q)
        bit_info[q] = sum(bq.values())
        if q == 7:
            comps.append(Comp("Fp", 7, 4)); EC.append(tq); bitfuns.append(lambda l, bq=bq: bq[int(l) % 7])
        elif kr == 1:
            for w_ in (0, 1):
                comps.append(Comp("Fp", q, sroot(q, w_))); EC.append(tq); bitfuns.append(lambda l, bq=bq, q=q: bq[int(l) % q])
        else:
            comps.append(Comp("Fp2", q))
            EC.append({(u, v): tq[(u * u + u * v + 2 * v * v) % q] for u in range(q) for v in range(q) if (u, v) != (0, 0)})
            bitfuns.append(lambda l, bq=bq, q=q: bq[(l[0] * l[0] + l[0] * l[1] + 2 * l[1] * l[1]) % q])
    # check: eps^5 is the quadratic character with these bits (values at primes up to 200)
    for p in PRS:
        if N % p == 0: continue
        kp = int(pari("chareval(Gm, chm, %d) * om" % p)) % order
        b = 0
        for q in [int(q) for q in pari("factor(%d)[,1]~" % N)]:
            gq0 = int(pari("znprimroot(%d)" % q).lift())
            b ^= tables_bit(q, p, gq0, pari, N, order)
        assert b == kp % 2, "sign part of eps differs at %d" % p
    ops = []
    for q in (3, 5, 13):
        if N % q and int(pari("kronecker(-7, %d)" % q)) == -1: ops.append(("(%d)" % q, (q, 0), int(MUL[AP[q], AP[q]])))
    if N % 7: ops.append(("(sqrt-7)", (-1, 2), AP[7]))
    for q in (11, 23, 29, 37, 43, 53):
        if N % q:
            pi = find_pi(q); ops += [("q%d" % q, pi, AP[q]), ("q%dbar" % q, oconj(pi), AP[q])]
    label = "N%d_k%d_o%d_%s" % (N, k, o, sel)
    return {"name": label, "comps": comps, "EC": EC, "bitfuns": bitfuns, "x": x, "y": y, "loc": ops[:nloc], "AP": AP,
            "eps_order": order, "sign_bits": bit_info}

def tables_bit(q, p, gq0, pari, N, order):
    """Parity of the exponent of the q-component of eps at p: eps_q(p) = eps(gq)^i with p = gq0^i mod q."""
    gq = int(pari("lift(chinese(Mod(%d, %d), Mod(1, %d)))" % (gq0, q, N // q)))
    kq = int(pari("chareval(Gm, chm, %d) * om" % gq)) % order
    i = int(pari("znlog(%d, Mod(%d, %d))" % (p % q, gq0, q)))
    return (i * kq) % 2

def case_1951(nloc=4):
    """rho-bar_2 of the even icosahedral rho of conductor 1951, from the Galois side exactly as bianchi2/run_big.py:
    abar_l = psibar(l) tbar(class of Frob_l), level character chibar^-1 o N on (O/1951)^x = F_{1951^2}^x (no sign part:
    det rho has order 5), (x, y) = (z + z^2, 1 + z^3) = (6, 9)."""
    import json
    pari = cypari2.Pari(); N = 1951
    C = {int(k): v for k, v in json.load(open(_ROOT + "/data/classes_1951.json"))["codes"].items()}
    g = int(pari("znstar(1951, 1).gen[1]")); dl = {}; t = 1
    for kk in range(N - 1): dl[t] = kk; t = t * g % N
    Z = 2; POW = [1]
    for _ in range(10): POW.append(int(MUL[POW[-1], Z]))
    PHI1 = Z ^ POW[4]; PHI0 = 1 ^ Z ^ POW[4]
    def tbar(code):
        if code in ("1", "2A"): return 0
        if code == "3A": return 1
        return PHI1 if code == "5A" else PHI0
    PRS = [int(q) for q in pari("primes([3, 200])")]
    AP = {l: int(MUL[POW[dl[l] % 5], tbar(C[l])]) for l in PRS if l != N}
    a2 = int(MUL[POW[dl[2] % 5], tbar(C[2])]); c2 = POW[(2 * dl[2]) % 5]
    xy = [r for r in range(16) if (int(MUL[r, r]) ^ int(MUL[a2, r]) ^ c2) == 0]
    assert sorted(xy) == [6, 9], xy
    epsinv = np.zeros(N, dtype=np.uint8)
    for a in range(1, N): epsinv[a] = POW[(-2 * dl[a]) % 5]
    uu, vv = np.meshgrid(np.arange(N, dtype=np.int64), np.arange(N, dtype=np.int64), indexing="ij")
    tab = epsinv[(uu * uu + uu * vv + 2 * vv * vv) % N]; tab[0, 0] = 0
    ops = []
    for q in (3, 5, 13):
        if int(pari("kronecker(-7, %d)" % q)) == -1: ops.append(("(%d)" % q, (q, 0), int(MUL[AP[q], AP[q]])))
    ops.append(("(sqrt-7)", (-1, 2), AP[7]))
    for q in (11, 23, 29):
        pi = find_pi(q); ops += [("q%d" % q, pi, AP[q]), ("q%dbar" % q, oconj(pi), AP[q])]
    ops = [o for o in ops if o[0] not in ("(5)", "(13)")]
    return {"name": "N1951", "comps": [Comp("Fp2", N)], "EC": [tab], "bitfuns": [None], "x": 6, "y": 9, "loc": ops[:nloc], "AP": AP}

def case_t163(nloc=4):
    """The even tetrahedral rho_t = rho_0 (x) psi of conductor 163 (README section 4), as in p2_bss.py: level 163 O_E,
    level character psi o N (psi cubic, Conrey 58), traces from t163_traces.json.  Needs P2_ORD=15."""
    import json
    from p2lift import ORD
    assert ORD == 15, "run with P2_ORD=15: the nebentypus has order 3"
    pari = cypari2.Pari(); N = 163
    w_, w2_ = sorted(a for a in range(16) if gf.MUL16[a, a] ^ a ^ 1 == 0); assert int(MUL[w_, w_]) == w2_
    pari("G163 = znstar(163, 1); CHI = znconreychar(G163, 58);")
    W3 = [1, w_, w2_]
    tab = {a: W3[int(pari("round(chareval(G163, CHI, %d) * 3)" % a)) % 3] for a in range(1, N)}
    TR = json.load(open(_ROOT + "/families/t163_traces.json"))["traces"]
    def a_rbar(q): return int(MUL[W3[TR[str(q)]["psi_k"] % 3], TR[str(q)]["tr0"] % 2])
    c2 = W3[(2 * TR["2"]["psi_k"]) % 3]
    xy = [r for r in range(1, 16) if (int(MUL[r, r]) ^ int(MUL[a_rbar(2), r]) ^ c2) == 0]; assert len(xy) == 2, xy
    pi11 = find_pi(11); pi23 = find_pi(23)
    ops = [("(3)", (3, 0), int(MUL[a_rbar(3), a_rbar(3)])), ("(sqrt-7)", (-1, 2), a_rbar(7)), ("q11", pi11, a_rbar(11)),
           ("q11bar", oconj(pi11), a_rbar(11)), ("q23", pi23, a_rbar(23)), ("q23bar", oconj(pi23), a_rbar(23))]
    return {"name": "t163", "comps": [Comp("Fp", N, sroot(N, 0)), Comp("Fp", N, sroot(N, 1))], "EC": [tab, tab],
            "bitfuns": [None, None], "x": xy[0], "y": xy[1], "loc": ops[:nloc], "omega": w_}

if __name__ == "__main__":
    import time; t0 = time.time()
    c = case_form(633)
    print(c["name"], "x, y =", c["x"], c["y"], "eps order", c["eps_order"], "sign bits per prime (count of -1 values):", c["sign_bits"],
          "loc:", [(nm, pi, ev) for nm, pi, ev in c["loc"]], "(%.0fs)" % (time.time() - t0))
