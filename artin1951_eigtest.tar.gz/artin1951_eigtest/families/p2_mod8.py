import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Weight 3 at a level prime to 2, modulo 4 and 8: the H1 test of the referee note at a level where the small-level
tower (p2_tower.py) does not fit in memory.  Weight 3 agrees with the Artin weight mod 8 (t_3 = 24), so C2 (with Artin
for the form) predicts that the mod-2 class of each refinement u = (T_v, T_vbar) in {x, y}^2 lifts mod 8.

  1. mod 2: the rows of the (single, weight 3) piece system SS; AugRows (p2big.py, kernel in class form) gives Z^1; the
     4 coboundaries; pivot columns on whole edges; H^1 coordinates read on the pivot columns, checked on extra edges;
  2. Hecke matrices mod 2 on H^1 (T on each basis class, words built only for the pivot and check edges); joint
     generalized eigenspaces of (T_v, T_vbar) in {x, y}^2, localized at the rbar-system by further operators T_q; joint
     eigenvectors c_u;
  3. mod 4: c_u lifts iff beta(c_u) = (R c~_u / 2 mod 2) lies in im R (one augmented solve for the four u);
  4. projection of the mod-4 lift W_u to the joint (x, y)-part of H^1(V/4) with two Hecke applications (T_v, then
     T_vbar) on the pivot edges: D = (T W - lambda~ W - delta m~) / 2 mod 2 has class n + (T - lambda) y with n in the
     lambda-part and 2 y the part of W outside it; y_rest = (T - lambda)^-1 (component of D outside the lambda-part), and
     W - 2 y~_rest lies in the lambda-part.  Checked: D recomputed afterwards has no component outside;
  5. mod 8: the obstruction b3 = bit 2 of R W mod 8, with freedom beta(basis of the joint (x, y)-part of H^1(V/2)),
     tested against im R (one augmented solve).  Every explicit lift is checked on every relator (mod 4, mod 8).
Usage: python3 -I p2_mod8.py CASE   (23: rho_23 at level 23 O_E, a check against p2_tower.py; 633: 633.1.m.b;
1951: the even icosahedral rho, level 1951 O_E, about 8.5 times the size of 633).
Author: Dula."""
import sys, os, json, time, resource, gc
sys.path.insert(0, _ROOT + "/families"); sys.path.insert(0, _ROOT + "/bianchi2"); sys.path.insert(0, _ROOT + "/twins")
import numpy as np, numba as nb
from p2lift import P2Level
from p2big import AugRows, rows_width, rows_mod2_w, rows_check16
from p2_cases import case_23, case_form, case_1951, case_t163, find_pi
from t6lib import naive, scal, to_code, bits_at, rank16
from sparse_h1 import MUL, INV
from bianchi4 import V_PI, VB_PI
import gf, lanczos16
from lanczos16 import from_bits
t0 = time.time()
OUT = _os.environ.get("ARTIN_OUT", _ROOT + "/families")
def log(*a): print(*a, flush=True)
def rss(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
CASE = sys.argv[1]
C = case_23() if CASE == "23" else (case_1951() if CASE == "1951" else (case_t163() if CASE == "t163" else case_form(int(CASE))))
NLOC = int(os.environ.get("P2_NLOC", "4"))
LOC = [op for op in C["loc"] if op[0] != "(13)"][:NLOC]
x, y = C["x"], C["y"]
SPREC = int(os.environ.get("P2_S", "3"))                       # precision 2^SPREC of the GR arithmetic
VD = P2Level(3, SPREC, C["comps"], C["EC"], C["bitfuns"], C["name"]).decompose()
tau = ("S", "S"); assert VD.types == [tau]
Nnt, n, G = VD.Nnt, VD.n, VD.G; ncol4 = VD.ncol4; D4 = VD.Dtype[tau]
log("## case %s: (x, y) = (%d, %d); localization by %s (%.0fs, %d MB)" % (C["name"], x, y, [(nm, ev) for nm, _, ev in LOC], time.time() - t0, rss()))

@nb.njit(cache=True, parallel=True)
def mm16(A, B, mul):
    M, K = A.shape; N = B.shape[1]; Cm = np.zeros((M, N), dtype=np.uint8)
    for i in nb.prange(M):
        for kk in range(K):
            a = A[i, kk]
            if a == 0: continue
            for j in range(N): Cm[i, j] ^= mul[a, B[kk, j]]
    return Cm

# ---------------------------------------------------------------- 1. mod 2
Tw = rows_width(VD.L.NXT, VD.L.NXE, D4, VD.tg, VD.te, G, n, VD.colpos4, 4, MUL)
cols, vals, bad = rows_mod2_w(VD.L.NXT, VD.L.NXE, D4, VD.tg, VD.te, G, n, VD.colpos4, 4, Tw, MUL)
assert bad == 0, "relators do not close mod 2"
R4 = cols.shape[0]
log("## rows: %d x %d (width %d), %d columns (%.0fs, %d MB)" % (R4, Tw, Tw, ncol4, time.time() - t0, rss()))
def checker(B):
    def chk(X, t): return rows_check16(VD.L.NXT, VD.L.NXE, D4, VD.tg, VD.te, G, n, VD.colpos4, 4, X, B, t, MUL)
    return chk
B0 = np.zeros((R4, 1), dtype=np.uint8)
LW = int(os.environ.get("P2_LW", "4"))                              # Lanczos block / 64 for the first solve
CD = os.path.join(OUT, "cache_p2", C["name"]); os.makedirs(CD, exist_ok=True)
fA1 = os.path.join(CD, "A1.npz")
class KernelState:
    """The class-form kernel of a finished AugRows run, saved to / loaded from disk."""
    expand = AugRows.expand; values_on = AugRows.values_on
    def __init__(self, path):
        z = np.load(path)
        for kk in ("V", "Tm", "cls_of", "rfac", "off", "Kt"): setattr(self, kk, z[kk])
        self.m = int(z["m"]); self.ncol = int(z["ncol"]); self.complete = bool(z["complete"])
if os.path.exists(fA1):
    A1 = KernelState(fA1); log("## first solve loaded from %s (%.0fs)" % (fA1, time.time() - t0))
else:
    A1 = AugRows(cols, vals, ncol4, B0, checker(B0), seed=1, lanczos_w=LW)
    np.savez(fA1, V=A1.V, Tm=A1.Tm, cls_of=A1.cls_of, rfac=A1.rfac, off=A1.off, Kt=A1.Kt, m=A1.m, ncol=A1.ncol, complete=A1.complete)
assert A1.complete, "kernel not certified complete"
Kt = A1.Kt; dZ = Kt.shape[0]
log("## Z^1(V/2): dimension %d (%.0fs, %d MB)" % (dZ, time.time() - t0, rss()))
cob = VD.type_coboundaries(tau)
for a in range(4): assert checker(np.zeros((R4, 0), dtype=np.uint8))(cob[a], np.zeros(0, dtype=np.uint8)) == 0, "a coboundary fails the rows"
# pivot columns on whole edges
rng = np.random.default_rng(7)
def zvals(edges):
    cs = (np.asarray(edges, dtype=np.int64)[:, None] * 4 + np.arange(4)[None, :]).reshape(-1)
    return cs, A1.values_on(cs, Kt)                               # (len(cs), dZ)
ne = min(Nnt, max(dZ + 64, 3 * dZ // 2))
while True:
    ed = np.sort(rng.choice(Nnt, size=ne, replace=False)); cs, Zs = zvals(ed)
    A_ = Zs.T.copy(); pv = list(gf.rref16(A_, MUL, INV))
    if len(pv) == dZ: break
    assert ne < Nnt, "Z^1 not determined on all edges?"
    ne = min(Nnt, 2 * ne)
pcols = cs[pv]; pedges = np.unique(pcols // 4)
rest = np.setdiff1d(np.arange(Nnt), pedges); xedges = np.sort(rng.choice(rest, size=min(len(rest), 24), replace=False))
EDG = np.concatenate([pedges, xedges]); pos_of = {int(e): i for i, e in enumerate(EDG)}
ecs, Ze = zvals(EDG)                                               # Z on all columns of the evaluation edges
Zp = Ze[[pos_of[int(c) // 4] * 4 + int(c) % 4 for c in pcols]]     # (dZ, dZ): row j = values at pcols[j]
Aug = np.concatenate([Zp.T.copy(), np.eye(dZ, dtype=np.uint8)], axis=1).copy(); pv = list(gf.rref16(Aug, MUL, INV)); assert pv == list(range(dZ))
Zpinv = Aug[:, dZ:].copy()                                         # (Zp^T)^-1: coordinates (row) c = Y[pcols] Zpinv
log("## pivot columns: %d on %d edges; %d extra check edges (%.0fs)" % (dZ, len(pedges), len(xedges), time.time() - t0))
def coords_edges(Yedges):
    """Z^1-coordinates of a cocycle given on the evaluation edges EDG as codes (len(EDG), 4); checked on all of them."""
    Yc = Yedges.reshape(-1)
    yp = Yc[[pos_of[int(c) // 4] * 4 + int(c) % 4 for c in pcols]]
    c = gf.matmul16(yp[None, :].copy(), Zpinv)[0]
    assert (gf.matmul16(c[None, :].copy(), Ze.T.copy())[0] == Yc).all(), "not a cocycle on the evaluation edges"
    return c
cobc = np.stack([coords_edges(cob[a].reshape(Nnt, 4)[EDG]) for a in range(4)])
Bb = cobc.copy(); pB = list(gf.rref16(Bb, MUL, INV)); Bb = Bb[:len(pB)].copy(); dB = Bb.shape[0]
Hc = np.eye(dZ, dtype=np.uint8)[[i for i in range(dZ) if i not in set(pB)]]      # Bb is in rref with pivot columns pB
dH = Hc.shape[0]; Zf = np.vstack([Bb, Hc])
Aug = np.concatenate([Zf.T.copy(), np.eye(dZ, dtype=np.uint8)], axis=1).copy(); pv = list(gf.rref16(Aug, MUL, INV)); assert pv == list(range(dZ))
Zfinv_T = Aug[:, dZ:].copy()                                       # coefficients a with c = a Zf: a = c (Zf^T)^-1 ...
def classvec_edges(Yedges):
    c = coords_edges(Yedges)
    a = gf.matmul16(Zfinv_T, c[:, None].copy())[:, 0]
    assert (gf.matmul16(a[None, :].copy(), Zf)[0] == c).all()
    return a[dB:]
def cochain_of(h):
    """Full cochain (Nnt, 2, 2) of codes (adapted basis) of the H^1 class h, representatives from Hc."""
    c = gf.matmul16(np.asarray(h, dtype=np.uint8)[None, :].copy(), Hc)[0]
    q = gf.matmul16(c[None, :].copy(), Kt)[0]
    X, t = A1.expand(q); assert not t.any()
    return X.reshape(Nnt, 2, 2)
log("## H^1(V/2): dimension %d (coboundaries %d) (%.0fs, %d MB)" % (dH, dB, time.time() - t0, rss()))

# ---------------------------------------------------------------- 2. Hecke matrices mod 2 on H^1
OPS = [("v", V_PI, None), ("vbar", VB_PI, None)] + LOC
for nm, pi, _ in OPS:
    VD.build_T(nm, pi, edges=EDG)
log("## Hecke words for %s on the %d evaluation edges (%.0fs)" % ([o[0] for o in OPS], len(EDG), time.time() - t0))
fTM = os.path.join(CD, "TM.npz")
def cochains_of(Hrows):
    """Full cochains (k, Nnt, 2, 2) of the H^1 classes Hrows (k x dH), one class-form product for all of them."""
    Q = gf.matmul16(gf.matmul16(np.ascontiguousarray(Hrows, dtype=np.uint8), Hc), Kt)
    Xc = from_bits(lanczos16.mulmat(A1.V, Q.T.copy()), Q.shape[0])               # (ncls, k)
    ok = A1.cls_of >= 0; out = np.zeros((Q.shape[0], ncol4), dtype=np.uint8)
    for i in range(Q.shape[0]):
        out[i, ok] = MUL[A1.rfac[ok], Xc[A1.cls_of[ok], i]]
    return out.reshape(Q.shape[0], Nnt, 2, 2)
if os.path.exists(fTM) and int(np.load(fTM)["dH"]) == dH:
    zt = np.load(fTM); TM = {nm: zt[nm] for nm, _, _ in OPS}; log("## Hecke matrices loaded from %s" % fTM)
else:
    TM = {nm: np.zeros((dH, dH), dtype=np.uint8) for nm, _, _ in OPS}
    for i0 in range(0, dH, 64):
        I_ = np.eye(dH, dtype=np.uint8)[i0:min(dH, i0 + 64)]
        Ys = cochains_of(I_)
        for j in range(Ys.shape[0]):
            for nm, _, _ in OPS:
                TM[nm][:, i0 + j] = classvec_edges(VD.T2(nm, Ys[j]).reshape(len(EDG), 4))
        del Ys
    np.savez(fTM, dH=dH, **TM)
# cross-check of the batched expansion against the single one
e0 = np.zeros(dH, dtype=np.uint8); e0[dH // 2] = 1
assert (cochains_of(e0[None, :])[0] == cochain_of(e0)).all(), "batched expansion differs"
comm = all((mm16(TM[a], TM[b], MUL) == mm16(TM[b], TM[a], MUL)).all() for a in TM for b in TM if a < b)
log("## Hecke matrices on H^1 (dim %d): %s; commute: %s (%.0fs, %d MB)" % (dH, list(TM), comm, time.time() - t0, rss()))
assert comm
def gen_eig(Ms, lams, Dm):
    V = np.eye(Dm, dtype=np.uint8)
    for M, lam in zip(Ms, lams):
        S = M ^ (MUL[lam, 1] * np.eye(Dm, dtype=np.uint8)); P = S.copy(); kk = 1
        while kk < Dm: P = mm16(P, P, MUL); kk *= 2
        Kk = gf.kernel16(P)
        if V.shape[0] == 0 or Kk.shape[0] == 0: return np.zeros((0, Dm), dtype=np.uint8)
        Kz = gf.kernel16(np.concatenate([V, Kk], axis=0).T.copy())
        W_ = gf.matmul16(np.ascontiguousarray(Kz[:, :V.shape[0]]), V); A_ = W_.copy(); pv = list(gf.rref16(A_, MUL, INV)); V = A_[:len(pv)].copy()
    return V
def joint_eig(rows, ops):
    if rows.shape[0] == 0: return rows
    blocks = [mm16(np.ascontiguousarray(rows), np.ascontiguousarray((TM[nm] ^ (MUL[lam, 1] * np.eye(dH, dtype=np.uint8))).T), MUL) for nm, lam in ops]
    Ce = gf.kernel16(np.concatenate(blocks, axis=1).T.copy())
    return gf.matmul16(Ce, rows) if Ce.shape[0] else np.zeros((0, dH), dtype=np.uint8)
summ = {}
for (a, b) in [(x, y), (y, x), (x, x), (y, y)]:
    G2 = gen_eig([TM["v"], TM["vbar"]], [a, b], dH)                              # freedom space (T_v, T_vbar only)
    Gl = gen_eig([TM["v"], TM["vbar"]] + [TM[nm] for nm, _, _ in LOC], [a, b] + [ev for _, _, ev in LOC], dH)
    E = joint_eig(Gl, [("v", a), ("vbar", b)] + [(nm, ev) for nm, _, ev in LOC])
    summ[(a, b)] = {"G2": G2, "Gl": Gl, "E": E}
log("## (T_v, T_vbar)-generalized eigenspaces / rbar-localized / joint rbar eigenvectors: %s (%.0fs)"
    % ({"%d,%d" % kk: (v["G2"].shape[0], v["Gl"].shape[0], v["E"].shape[0]) for kk, v in summ.items()}, time.time() - t0))

# ---------------------------------------------------------------- E. the eigenvalue test (P2_EIGTEST=1; ends the run)
# Does the eigensystem lambda = tr rho(Frob) (at the operators away from 2) occur mod 2^s on a class whose reduction is
# the rbar-eigenvector of a given refinement?  Exact Bockstein spectral sequence of the lambda-eigen module:
#   K   = joint kernel of (T_q - lambda_q mod 2) on H^1(V/2), q away from 2 (all refinements);
#   F_s = {k in K : k lifts to W mod 2^s with W a cocycle and (T_q - lambda~_q) W = coboundary mod 2^s for all q};
# level s holds a basis of F_s with explicit lifts.  A combination of the level-s lifts and of 2^(s - s') (lifts of
# level s') can be corrected by 2^s X (X a cochain) to a cocycle mod 2^(s+1) iff its cocycle obstruction lies in im R
# (one augmented solve); then 2^s z~ (z in H^1(V/2)) is added and the eigen condition at digit s is linear:
#   sum c_l D_q(Y_l) + (T_q - lambda_q) z = 0 for all q      (D_q = class of digit s of (T_q - lambda~_q) Y - coboundary).
# Lifts of a class differ by 2 (lifts of lower levels) and by 2^s (cocycles), which is exactly the freedom used, so
# F_(s+1) is exact.  depth(u) = the largest s such that F_s contains a non-zero rbar-eigenvector of refinement u.
if os.environ.get("P2_EIGTEST", "0") == "1":
    sys.path.insert(0, _ROOT + "/twins")
    from t6lib import gr_mul
    SMAX = SPREC; QT = 1 << SMAX
    def grmat(g, Q):
        """Integer 4 x 4 matrix of multiplication by the GR element g (coordinates in 1, X, X^2, X^3) modulo Q."""
        return np.array([gr_mul(g, [1 if k == j else 0 for k in range(4)], Q) for j in range(4)], dtype=np.int64).T
    def grmul(g, W, Q): return (np.asarray(W, dtype=np.int64) @ grmat(g, Q).T) % Q
    def zpoly(e, Q):
        """zeta_5^e as GR coordinates (X = zeta_5 exactly: X^4 = -1 - X - X^2 - X^3)."""
        e %= 5; v = [0, 0, 0, 0]
        if e < 4: v[e] = 1
        else: v = [Q - 1] * 4
        return [t % Q for t in v]
    def gadd(*gs):
        Q = QT; return [sum(int(g[i]) for g in gs) % Q for i in range(4)]
    def gsc(n, g): return [(n * int(t)) % QT for t in g]
    def code_of(g): return int((g[0] & 1) | ((g[1] & 1) << 1) | ((g[2] & 1) << 2) | ((g[3] & 1) << 3))
    # ---- the operators of the eigensystem (away from 2)
    names = os.environ.get("P2_EOPS", "(3),(5),(sqrt-7),q11,q11bar,q23,q23bar,q29,q29bar,q37,q37bar,q43,q43bar").split(",")
    LEV = {"23": 23, "633": 633, "1951": 1951, "t163": 163}[CASE]
    def op_pi(nm):
        if nm == "(sqrt-7)": return (-1, 2)
        if nm.startswith("("): return (int(nm[1:-1]), 0)
        q = int(nm[1:].replace("bar", "")); pi = find_pi(q)
        return oconj(pi) if nm.endswith("bar") else pi
    def rat(nm):
        return 7 if nm == "(sqrt-7)" else (int(nm[1:-1]) if nm.startswith("(") else int(nm[1:].replace("bar", "")))
    names = [nm for nm in names if LEV % rat(nm)]
    from o7 import oconj
    # ---- the Artin eigensystem in characteristic 0, as GR elements modulo QT
    if CASE == "1951":
        TRf = json.load(open(_ROOT + "/data/galois_traces_1951.json"))
        dl3 = {}; t_ = 1
        for kk in range(1950): dl3[t_] = kk; t_ = t_ * 3 % 1951
        def tval(t):
            """t_p in {0, +-1, +-2, +-phi, +-(phi - 1)} as an element of Z[zeta_5]: phi - 1 = zeta + zeta^4."""
            phm1 = gadd(zpoly(1, QT), zpoly(4, QT)); one = [1, 0, 0, 0]
            for val, g in ((0.0, [0, 0, 0, 0]), (1.0, one), (-1.0, gsc(-1, one)), (2.0, gsc(2, one)), (-2.0, gsc(-2, one)),
                           (0.6180339887498949, phm1), (-0.6180339887498949, gsc(-1, phm1)),
                           (1.618033988749895, gadd(one, phm1)), (-1.618033988749895, gsc(-1, gadd(one, phm1)))):
                if abs(t - val) < 1e-9: return g
            raise ValueError(t)
        def conj(g, j):
            """The automorphism zeta -> zeta^j of Z[zeta_5], on GR coordinates."""
            out = [0, 0, 0, 0]
            for i in range(4):
                if g[i]: out = gadd(out, gsc(int(g[i]), zpoly(i * j, QT)))
            return out
        def a_p(p, j): return conj(gr_mul(zpoly(dl3[p % 1951], QT), tval(TRf["t"][str(p)]), QT), j)     # chi(p)^3 t_p
        def det_p(p, j): return conj(zpoly(2 * dl3[p % 1951], QT), j)                                    # chi(p)
        def lam0(nm, j):
            l = rat(nm)
            if nm.startswith("(") and nm != "(sqrt-7)":
                a = a_p(l, j); return gadd(gr_mul(a, a, QT), gsc(-2, det_p(l, j)))          # tr rho(Frob_l^2)
            return a_p(l, j)
        conjs = [1, 2, 3, 4]
    elif CASE == "t163":
        TRt = json.load(open(_ROOT + "/families/t163_traces.json"))["traces"]
        w = [0, 0, 1, 1]
        for _ in range(4 * (QT.bit_length() + 2)): w = gr_mul(w, w, QT)
        assert gr_mul(gr_mul(w, w, QT), w, QT) == [1, 0, 0, 0] and code_of(w) == C["omega"]
        OM = [[1, 0, 0, 0], w, gr_mul(w, w, QT)]
        def lam0(nm, j):
            P = OM if j == 1 else [OM[0], OM[2], OM[1]]; l = rat(nm); t = TRt[str(l)]
            if nm.startswith("(") and nm != "(sqrt-7)": return gsc(t["tr0"] ** 2 - 2, P[(2 * t["psi_k"]) % 3])
            return gsc(t["tr0"], P[t["psi_k"] % 3])
        conjs = [1, 2]
    else:
        raise SystemExit("no characteristic-0 eigensystem for this case")
    # ---- Hecke words and matrices mod 2 for the operators that are not yet there
    newops = [nm for nm in names if nm not in TM]
    for nm in newops: VD.build_T(nm, op_pi(nm), edges=EDG)
    if newops:
        fTE = os.path.join(CD, "TE.npz")
        zt = np.load(fTE) if os.path.exists(fTE) else None
        if zt is not None and all(nm in zt.files for nm in newops) and int(zt["dH"]) == dH:
            for nm in newops: TM[nm] = zt[nm]
        else:
            for nm in newops: TM[nm] = np.zeros((dH, dH), dtype=np.uint8)
            for i0 in range(0, dH, 64):
                Ys = cochains_of(np.eye(dH, dtype=np.uint8)[i0:min(dH, i0 + 64)])
                for jj in range(Ys.shape[0]):
                    for nm in newops: TM[nm][:, i0 + jj] = classvec_edges(VD.T2(nm, Ys[jj]).reshape(len(EDG), 4))
                del Ys
            np.savez(fTE, dH=dH, **{nm: TM[nm] for nm in newops})
        assert all((mm16(TM[a], TM[b], MUL) == mm16(TM[b], TM[a], MUL)).all() for a in TM for b in TM if a < b), "Hecke matrices do not commute"
    log("## eigenvalue test, modulus up to %d; operators %s (%.0fs, %d MB)" % (QT, names, time.time() - t0, rss()))
    # ---- which conjugate: the one whose reduction is the rbar-system seen in the cohomology
    E_xy = summ[(x, y)]["E"]
    assert E_xy.shape[0] >= 1, "no rbar-eigenvector in the mixed refinement"
    def red_ok(j):
        for nm in names:
            lb = code_of(lam0(nm, j))
            if (mm16(np.ascontiguousarray(E_xy), np.ascontiguousarray((TM[nm] ^ (MUL[lb, 1] * np.eye(dH, dtype=np.uint8))).T), MUL)).any(): return False
        return True
    good = [j for j in conjs if red_ok(j)]
    log("## conjugates of rho whose reduction is the eigensystem of the mixed rbar-eigenvector: %s" % good)
    assert len(good) == 1, "the reduction does not single out one conjugate"
    J = int(os.environ.get("P2_ECONJ", good[0]))
    LAM = {nm: lam0(nm, J) for nm in names}
    for spec in [t_ for t_ in os.environ.get("P2_ESHIFT", "").split(",") if t_]:       # controls: nm:amount
        nm, amt = spec.split(":"); LAM[nm] = gadd(LAM[nm], [int(amt), 0, 0, 0])
        log("## CONTROL: eigenvalue at %s shifted by %s" % (nm, amt))
    if J != good[0]: log("## CONTROL: conjugate %d instead of %d" % (J, good[0]))
    LB = {nm: code_of(LAM[nm]) for nm in names}
    Kr = joint_eig(np.eye(dH, dtype=np.uint8), [(nm, LB[nm]) for nm in names])
    dK = Kr.shape[0]
    log("## K = joint kernel of (T_q - lambda_q) mod 2: dimension %d" % dK)
    targets = {kk: summ[kk]["E"] for kk in [(x, y), (y, x), (x, x), (y, y)] if summ[kk]["E"].shape[0]}
    def in_span(rows, v):
        if rows.shape[0] == 0 or not v.any(): return False
        return rank16(np.vstack([rows, v[None, :]])) == rank16(rows)
    for kk, Ev in targets.items():
        log("   u = %d,%d: rbar-eigenvectors %d, in K: %s" % (kk[0], kk[1], Ev.shape[0], [in_span(Kr, e) for e in Ev]))
    # ---- coboundaries on the evaluation edges, mod QT, and digit extraction
    mdatE = VD.coboundary_data(QT)
    cobT = np.stack([VD.coboundary_on(mdatE, b, EDG, QT) for b in range(VD.dV)]); del mdatE
    Mc2 = np.stack([to_code(cobT[b] % 2) for b in range(VD.dV)], axis=1)
    def W_on_edges(W): return W.reshape(Nnt, VD.dV, 4)[EDG].reshape(-1, 4)
    def digit_class(nm, W, s):
        """W: cocycle mod 2^(s+1) with (T - lambda~) W = coboundary mod 2^s.  The class of digit s of (T - lambda~) W
        minus a coboundary, as H^1 coordinates; asserts that the digits below s are coboundaries."""
        Q = 1 << (s + 1)
        E_ = (VD.TQ(nm, W % Q, Q) - grmul(LAM[nm], W_on_edges(W), Q)) % Q
        for i in range(s):
            e2 = to_code((E_ >> i) & 1)
            A_ = np.concatenate([Mc2, e2[:, None]], axis=1).copy(); pv = list(gf.rref16(A_, MUL, INV))
            assert all(p < VD.dV for p in pv), "digit %d of (T - lambda) W is not a coboundary (operator %s)" % (i, nm)
            for rr, p in enumerate(pv):
                kap = int(A_[rr, VD.dV])
                if kap: E_ = (E_ - (1 << i) * scal(kap, cobT[p] % Q, Q)) % Q
            assert not ((E_ >> i) & 1).any()
        Dc = to_code((E_ >> s) & 1).reshape(len(EDG), 2, 2)
        return classvec_edges(VD.to_new(Dc).reshape(len(EDG), 4))
    def is_cocycle(W, Q): return not (VD.walk(W, Q) % Q).any()
    def old_codes(Yn): return np.ascontiguousarray(VD.to_old(Yn).reshape(-1))
    def std_lift(Yn): return naive(old_codes(Yn))
    def piece_col(codes): return np.ascontiguousarray(VD.to_new(codes.reshape(-1, 2, 2)).reshape(-1))
    def obstruction(W, s): return piece_col(bits_at(VD.walk(W, 1 << (s + 1)), s))
    WD = np.uint8 if SMAX <= 8 else np.uint16
    # level 1
    ST = {1: {"red": [Kr[i].copy() for i in range(dK)], "W": [], "obs": []}}
    for i in range(dK):
        W = std_lift(cochain_of(Kr[i])); assert is_cocycle(W, 2)
        ST[1]["W"].append(W.astype(WD)); ST[1]["obs"].append(obstruction(W, 1) if SMAX > 1 else None)
    def meets(Rr, Ev):
        """span(Rr) and span(Ev) have a non-zero vector in common."""
        if Rr.shape[0] == 0: return False
        return rank16(Rr) + rank16(Ev) - rank16(np.vstack([Rr, Ev])) >= 1
    dims = {1: dK}; depth = {kk: (1 if meets(Kr, Ev) else 0) for kk, Ev in targets.items()}
    res = {"case": CASE, "modulus": QT, "ops": names, "conjugate": J, "shifts": os.environ.get("P2_ESHIFT", ""), "dimK": dK,
           "dimH1": int(dH), "dims": {}, "contains": {}, "kernels_complete": []}
    for s in range(1, SMAX):
        t1 = time.time(); Q2 = 1 << (s + 1)
        if dims[s] == 0: break
        desc = [(s, i) for i in range(dims[s])] + [(sp, i) for sp in range(s - 1, 0, -1) for i in range(dims[sp])]
        Bc = np.stack([ST[sp]["obs"][i] for sp, i in desc], axis=1)
        A1 = None; gc.collect()
        Aa = AugRows(cols, vals, ncol4, Bc, checker(Bc), seed=10 + s, lanczos_w=max(LW, (dZ + Bc.shape[1]) // 64 + 2))
        A1 = KernelState(fA1); res["kernels_complete"].append(bool(Aa.complete)); assert Aa.complete, "kernel not certified complete"
        Lb = Aa.Lech.copy(); r = Lb.shape[0]
        Ys = []
        for l in range(r):
            X = Aa.x_for(Lb[l])
            Y = (1 << s) * std_lift(X.reshape(Nnt, 2, 2))
            for c, (sp, i) in zip(Lb[l], desc):
                if c: Y = Y + (1 << (s - sp)) * scal(int(c), ST[sp]["W"][i].astype(np.int64), Q2)
            Y %= Q2; assert is_cocycle(Y, Q2), "combination is not a cocycle mod %d" % Q2
            Ys.append(Y.astype(WD))
        del Aa; gc.collect()
        # eigen condition at digit s: unknowns (c in F16^r, z in F16^dH)
        rowsM = []
        for nm in names:
            Dm = np.stack([digit_class(nm, Ys[l].astype(np.int64), s) for l in range(r)], axis=1) if r else np.zeros((dH, 0), dtype=np.uint8)
            rowsM.append(np.concatenate([Dm, TM[nm] ^ (MUL[LB[nm], 1] * np.eye(dH, dtype=np.uint8))], axis=1))
        Mbig = np.concatenate(rowsM, axis=0)
        Sol = gf.kernel16(Mbig)                                      # rows (c, z)
        # project to the coefficients of the level-s lifts (the new reductions); keep solutions with independent t-parts
        tpart = gf.matmul16(np.ascontiguousarray(Sol[:, :r]), np.ascontiguousarray(Lb[:, :dims[s]])) if Sol.shape[0] and r else np.zeros((0, dims[s]), dtype=np.uint8)
        keep = []; cur = np.zeros((0, dims[s]), dtype=np.uint8)
        for i in range(tpart.shape[0]):
            if tpart[i].any() and rank16(np.vstack([cur, tpart[i][None, :]])) > cur.shape[0]:
                keep.append(i); cur = np.vstack([cur, tpart[i][None, :]])
        ST[s + 1] = {"red": [], "W": [], "obs": []}
        for i in keep:
            cvec = Sol[i, :r]; z = Sol[i, r:]
            W = (1 << s) * std_lift(cochain_of(z)) if z.any() else np.zeros_like(Ys[0], dtype=np.int64)
            for l in range(r):
                if cvec[l]: W = W + scal(int(cvec[l]), Ys[l].astype(np.int64), Q2)
            W %= Q2; assert is_cocycle(W, Q2), "new lift is not a cocycle"
            for nm in names: assert not digit_class(nm, W, s).any(), "new lift is not an eigenvector mod %d" % Q2
            red = gf.matmul16(tpart[i][None, :].copy(), np.stack(ST[s]["red"]))[0]
            ST[s + 1]["red"].append(red); ST[s + 1]["W"].append(W.astype(WD))
            ST[s + 1]["obs"].append(obstruction(W, s + 1) if s + 1 < SMAX else None)
        dims[s + 1] = len(keep)
        Rr = np.stack(ST[s + 1]["red"]) if keep else np.zeros((0, dH), dtype=np.uint8)
        for kk, Ev in targets.items():
            if meets(Rr, Ev) and depth[kk] == s: depth[kk] = s + 1
        res["dims"][str(Q2)] = dims[s + 1]
        log("## mod %d: %d combinations are cocycles after correction; solutions of the eigen condition %d; classes of K that are "
            "eigen-lifts mod %d: %d; contains the rbar-eigenvector of %s (%.0fs, %d MB)"
            % (Q2, r, Sol.shape[0], Q2, dims[s + 1], ["%d,%d" % kk for kk in targets if depth[kk] == s + 1], time.time() - t1, rss()))
        del Ys
    res["depth"] = {"%d,%d" % kk: int(v) for kk, v in depth.items()}
    log("## depth (largest s with the rbar-eigenvector of u among the eigen-lifts mod 2^s): %s" % res["depth"])
    tag = ("_shift_" + os.environ["P2_ESHIFT"].replace(":", "").replace(",", "_").replace("(", "").replace(")", "")) if os.environ.get("P2_ESHIFT") else ""
    tag += ("_conj%d" % J) if J != good[0] else ""
    json.dump(res, open(os.path.join(OUT, "p2_eigtest_%s_mod%d%s.json" % (C["name"], QT, tag)), "w"), indent=1)
    log("## done (%.0fs, peak %d MB)" % (time.time() - t0, rss()))
    sys.exit(0)

# ---------------------------------------------------------------- 3. mod 4
def is_cocycle(W, Q): return not (VD.walk(W, Q) % Q).any()
def old_codes(Yn): return np.ascontiguousarray(VD.to_old(Yn).reshape(-1))
def std_lift(Yn): return naive(old_codes(Yn))                                    # (ncol, 4) mod anything
def piece_col(codes):                                                            # standard rows -> adapted piece rows
    return np.ascontiguousarray(VD.to_new(codes.reshape(-1, 2, 2)).reshape(-1))
fW4 = os.path.join(CD, "W4.npz"); fR4 = os.path.join(CD, "res4.json")
if os.path.exists(fW4) and os.path.exists(fR4):
    res = json.load(open(fR4)); zw = np.load(fW4)
    W4 = {tuple(int(c) for c in kk.split("_")): zw[kk].astype(np.int64) for kk in zw.files}
    log("## mod-4 stage loaded from %s: %s" % (fW4, res["lifts"]))
else:
    targets = [kk for kk in [(x, y), (y, x), (x, x), (y, y)] if summ[kk]["E"].shape[0] >= 1]
    # every vector of each joint eigenspace E_u: columns beta(e_i) for a basis e_i, the lift asked for some non-zero combination
    etil = {kk: [std_lift(cochain_of(e)).astype(np.uint8) for e in summ[kk]["E"]] for kk in targets}
    for kk in targets:
        for et in etil[kk]: assert is_cocycle(et.astype(np.int64), 2), "eigenvector is not a cocycle mod 2"
    colsB = []; blk2 = {}
    for kk in targets:
        blk2[kk] = (len(colsB), len(etil[kk]))
        colsB += [piece_col(bits_at(VD.walk(et.astype(np.int64), 4), 1)) for et in etil[kk]]
    B2 = np.stack(colsB, axis=1)
    log("## mod 4: %d obstruction columns (joint eigenspace bases of %s) (%.0fs)" % (B2.shape[1], {"%d,%d" % kk: v[1] for kk, v in blk2.items()}, time.time() - t0))
    A1 = None; gc.collect()                                           # memory: reloaded after the solve
    A2 = AugRows(cols, vals, ncol4, B2, checker(B2), seed=2, lanczos_w=max(LW, (dZ + B2.shape[1]) // 64 + 2))
    A1 = KernelState(fA1)
    res = {"case": C["name"], "dimZ1": int(dZ), "dimH1": int(dH), "rows": int(R4), "width": int(Tw),
           "spaces": {"%d,%d" % kk: [int(v["G2"].shape[0]), int(v["Gl"].shape[0]), int(v["E"].shape[0])] for kk, v in summ.items()},
           "localization": [(nm, int(ev)) for nm, _, ev in LOC], "kernel_complete": [bool(A1.complete), bool(A2.complete)], "lifts": {}}
    def in_block(Lb, o0, w0, m_):
        """Rows (rref) of {t in L : t = 0 outside [o0, o0 + w0)}, restricted to the block."""
        if Lb.shape[0] == 0: return np.zeros((0, w0), dtype=np.uint8)
        out = [j for j in range(m_) if j < o0 or j >= o0 + w0]
        Kz = gf.kernel16(Lb[:, out].T.copy()) if out else np.eye(Lb.shape[0], dtype=np.uint8)
        if Kz.shape[0] == 0: return np.zeros((0, w0), dtype=np.uint8)
        A_ = gf.matmul16(Kz, Lb[:, o0:o0 + w0]); pv = list(gf.rref16(A_, MUL, INV)); return A_[:len(pv)].copy()
    W4 = {}; CU = {}
    for kk in targets:
        o0, w0 = blk2[kk]; sub = in_block(A2.Lech, o0, w0, B2.shape[1]); r = sub.shape[0]
        res["lifts"]["%d,%d" % kk] = {"4": bool(r > 0), "dim_eigenspace": int(w0), "dim_lifting_mod4": int(r)}
        if r:
            tb = sub[0]; t = np.zeros(B2.shape[1], dtype=np.uint8); t[o0:o0 + w0] = tb
            xs = A2.x_for(t)
            W = 2 * std_lift(xs.reshape(Nnt, 2, 2))
            for i in range(w0):
                if tb[i]: W = W + scal(tb[i], etil[kk][i].astype(np.int64), 4)
            W %= 4; assert is_cocycle(W, 4), "explicit mod-4 lift is not a cocycle"
            W4[kk] = W; CU[kk] = gf.matmul16(tb[None, :].copy(), summ[kk]["E"])[0]
        log("   u = %d,%d: joint eigenspace of dimension %d; the classes lifting mod 4 form a subspace of dimension %d%s"
            % (kk[0], kk[1], w0, r, "; explicit lift of one of them checked on every relator mod 4" if r else ""))
    del A2

    # ---------------------------------------------------------------- 4. projection to the joint (x, y)-part mod 4
    mdat4 = VD.coboundary_data(4)
    log("## coboundary data mod 4 (%.0fs, %d MB)" % (time.time() - t0, rss()))
    cobE = np.stack([VD.coboundary_on(mdat4, b, EDG, 4) for b in range(VD.dV)])   # (dV, len(EDG) dV, 4)
    def W_on_edges(W): return W.reshape(Nnt, VD.dV, 4)[EDG].reshape(-1, 4)
    def D_class(nm, lam, W):
        """Class of (T W - lam~ W - delta m~) / 2 mod 2 on the evaluation edges, H^1 coordinates."""
        E_ = (VD.TQ(nm, W, 4) - scal(lam, W_on_edges(W), 4)) % 4
        e2 = to_code(E_ % 2)                                                          # codes, standard basis
        Mc = np.stack([to_code(cobE[b] % 2) for b in range(VD.dV)], axis=1)          # (len, dV)
        A_ = np.concatenate([Mc, e2[:, None]], axis=1).copy(); pv = list(gf.rref16(A_, MUL, INV))
        assert all(p < VD.dV for p in pv), "T W - lambda W is not a coboundary mod 2 on the evaluation edges"
        kap = np.zeros(VD.dV, dtype=np.uint8)
        for rr, p in enumerate(pv): kap[p] = A_[rr, VD.dV]
        corr = np.zeros_like(E_)
        for b in range(VD.dV):
            if kap[b]: corr = (corr + scal(kap[b], cobE[b], 4)) % 4
        F = (E_ - corr) % 4; assert not (F % 2).any(), "not divisible by 2"
        Dc = to_code(F // 2).reshape(len(EDG), 2, 2)
        return classvec_edges(VD.to_new(Dc).reshape(len(EDG), 4))
    def split(nm, lam):
        S = TM[nm] ^ (MUL[lam, 1] * np.eye(dH, dtype=np.uint8)); P = S.copy(); kk = 1
        while kk < dH: P = mm16(P, P, MUL); kk *= 2
        Kg = gf.kernel16(P)                                                           # lambda-part (rows)
        A_ = P.T.copy(); pv = list(gf.rref16(A_, MUL, INV)); Im = A_[:len(pv)].copy() # image of S^dH: the rest (rows)
        assert Kg.shape[0] + Im.shape[0] == dH
        return S, Kg, Im
    def remove_rest(nm, lam, W):
        d = D_class(nm, lam, W); S, Kg, Im = split(nm, lam)
        Bm = np.vstack([Kg, Im]); A_ = np.concatenate([Bm.T.copy(), d[:, None]], axis=1).copy(); pv = list(gf.rref16(A_, MUL, INV))
        coef = np.zeros(Bm.shape[0], dtype=np.uint8)
        for rr, p in enumerate(pv): coef[p] = A_[rr, Bm.shape[0]]
        d_rest = gf.matmul16(coef[None, Kg.shape[0]:].copy(), Im)[0] if Im.shape[0] else np.zeros(dH, dtype=np.uint8)
        if not d_rest.any(): return W, 0
        # solve S y = d_rest with y in the rest: y = a Im, a Im S^T = d_rest
        SI = gf.matmul16(Im, S.T.copy()); A_ = np.concatenate([SI.T.copy(), d_rest[:, None]], axis=1).copy(); pv = list(gf.rref16(A_, MUL, INV))
        assert all(p < Im.shape[0] for p in pv), "(T - lambda) not invertible on the rest"
        a = np.zeros(Im.shape[0], dtype=np.uint8)
        for rr, p in enumerate(pv): a[p] = A_[rr, Im.shape[0]]
        yv = gf.matmul16(a[None, :].copy(), Im)[0]
        Wn = (W + 2 * std_lift(cochain_of(yv))) % 4                                   # -2 y = 2 y mod 4
        return Wn, int((yv != 0).sum())
    for kk, W in list(W4.items()):
        a, b = kk
        W, nz1 = remove_rest("v", a, W); W, nz2 = remove_rest("vbar", b, W)
        assert is_cocycle(W, 4), "projected mod-4 lift is not a cocycle"
        for nm, lam in (("v", a), ("vbar", b)):
            d = D_class(nm, lam, W); S, Kg, Im = split(nm, lam)
            assert rank16(np.vstack([Kg, d[None, :]])) == Kg.shape[0], "projection left a component outside the %s-part" % nm
        W4[kk] = W
        log("   u = %d,%d: mod-4 lift moved into the joint (x, y)-part (corrections with %d and %d non-zero H^1 coordinates); checked: cocycle mod 4, "
            "no component outside for T_v and T_vbar" % (a, b, nz1, nz2))
    del mdat4
    np.savez(fW4, **{"%d_%d" % kk: W.astype(np.uint8) for kk, W in W4.items()}); json.dump(res, open(fR4, "w"))

# ---------------------------------------------------------------- 5. mod 8
for nm_ in ("etil", "colsB", "B2", "cobE"): globals().pop(nm_, None)          # memory: not needed any more
W4 = {kk: W.astype(np.uint8) for kk, W in W4.items()}; gc.collect()            # values mod 4; int64 only inside the walks
blocks = {}; m3 = 0
for kk in W4:
    blocks[kk] = (m3, 1 + summ[kk]["G2"].shape[0]); m3 += 1 + summ[kk]["G2"].shape[0]
if m3:
    B3 = np.zeros((R4, m3), dtype=np.uint8)
    for kk, (o0, w0) in blocks.items():
        B3[:, o0] = piece_col(bits_at(VD.walk(W4[kk].astype(np.int64), 8), 2))
        for j, z in enumerate(summ[kk]["G2"]):
            B3[:, o0 + 1 + j] = piece_col(bits_at(VD.walk(std_lift(cochain_of(z)), 4), 1))
    log("## mod 8: %d columns (obstructions and freedom) (%.0fs)" % (B3.shape[1], time.time() - t0))
    A1 = None; gc.collect()
    A3 = AugRows(cols, vals, ncol4, B3, checker(B3), seed=3, lanczos_w=max(LW, (dZ + B3.shape[1]) // 64 + 2))
    res["kernel_complete"].append(bool(A3.complete))
    del B3; cols = vals = None; gc.collect()                                    # memory: the rows are not needed after the last solve
    choice = {}
    for kk, (o0, w0) in blocks.items():
        # is there t in L with support in this block and t[o0] = 1?
        out = [j for j in range(m3) if j < o0 or j >= o0 + w0]
        Lb = A3.Lech
        Kz = gf.kernel16(Lb[:, out].T.copy()) if (Lb.shape[0] and out) else (np.eye(Lb.shape[0], dtype=np.uint8) if Lb.shape[0] else np.zeros((0, 0), dtype=np.uint8))
        sub = gf.matmul16(Kz, Lb[:, o0:o0 + w0]) if Kz.shape[0] else np.zeros((0, w0), dtype=np.uint8)
        ok = False
        if sub.shape[0]:
            A_ = sub.copy(); pv = list(gf.rref16(A_, MUL, INV)); ok = 0 in pv
            if ok: r0 = A_[pv.index(0)]; choice[kk] = MUL[INV[r0[0]], r0]
        res["lifts"]["%d,%d" % kk]["8"] = bool(ok); res["lifts"]["%d,%d" % kk]["freedom_mod8"] = int(w0 - 1)
        log("   u = %d,%d: %s mod 8 (freedom: %d classes; solve complete: %s)" % (kk[0], kk[1], "LIFTS" if ok else "does NOT lift", w0 - 1, A3.complete))
    res["seconds"] = round(time.time() - t0); res["peak_rss_MB"] = rss(); res["explicit_mod8"] = {}
    json.dump(res, open(os.path.join(OUT, "p2_mod8_%s.json" % C["name"]), "w"), indent=1)
    A1 = KernelState(fA1)
    for kk, r0 in choice.items():
        o0, w0 = blocks[kk]
        t = np.zeros(m3, dtype=np.uint8); t[o0:o0 + w0] = r0
        xs = A3.x_for(t)
        Wn = (W4[kk].astype(np.int64) + 4 * std_lift(xs.reshape(Nnt, 2, 2))) % 8; del xs
        for j in range(1, w0):
            if r0[j]: Wn = (Wn + 2 * scal(r0[j], std_lift(cochain_of(summ[kk]["G2"][j - 1])), 8)) % 8
        assert is_cocycle(Wn, 8), "explicit mod-8 lift is not a cocycle"
        assert (to_code(Wn % 2) == to_code(W4[kk] % 2)).all(), "the mod-8 lift does not reduce to the class mod 2"
        res["explicit_mod8"]["%d,%d" % kk] = True; del Wn; gc.collect()
        log("   u = %d,%d: explicit lift mod 8 checked on every relator; it reduces mod 2 to the same cocycle" % kk)
res["seconds"] = round(time.time() - t0); res["peak_rss_MB"] = rss()
json.dump(res, open(os.path.join(OUT, "p2_mod8_%s.json" % C["name"]), "w"), indent=1)
log("## result: %s" % res["lifts"])
log("## done (%.0fs, peak %d MB)" % (time.time() - t0, rss()))
