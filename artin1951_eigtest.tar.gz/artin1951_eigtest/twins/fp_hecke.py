import os as _os; _ROOT = _os.environ.get("ARTIN_ROOT") or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
"""Hecke eigenvalues in characteristic 0 (computed over F_P, P ~ 2^20) on H^1(Gamma_0(n), F_P(chi psi)) for PGL_2(O_E),
E = Q(sqrt-7): chi is the Teichmueller lift of the F16 character of the level tables, psi a character of 2-power order
on component 0 (the conventions of ../bianchi2/sparse_fp_psi.py, whose FpH1Psi gives only the dimension).

  1. The reduction of sparse_fp_psi: closure under 1- and 2-term equations, deduplication, Markowitz rounds; here every
     Markowitz pivot row is recorded (the row _mk_round_fp uses: the shortest row containing the column, first in row
     order; pivot rows of one round are untouched in that round).
  2. Kernel of the dense core, free classes, eliminated classes by back-substitution in reverse order, values on all
     edges (rfac * value of the class).
  3. Check: every relator equation at every coset vanishes on every kernel vector.
  4. Path scalars and delta m_par over F_P (same BFS tree as the level tables); H^1 = kernel / <delta m_par>.
  5. T_pi as sparse_big.BigH1.hecke: (T c)(h) = sum_i w_i c(h_i), alpha_i h = h_i alpha_s(i), w_i = (chi psi)(d_alpha_i)^-1,
     read on the Schreier generators of pivot edges (divided by the path scalar), solved on the pivot edges and checked
     on extra edges.
Author: Dula."""
import sys, time, collections
sys.path.insert(0, _ROOT + "/bianchi2")
import numpy as np, numba as nb
from o7 import mmul, mdet, decompose
import hecke, gf
from sparse_h1 import relator_arrays
from sparse_big import SCHEDULE
from sparse_fp import dedup_fp, _mk_round_fp, _inv
from sparse_fp_psi import closure_psi, rows_to_csr_psi, _walk_psi, log_table, log_step_tables, psi_table

# ------------------------------------------------------------------ dense kernel: FLINT (nmod_mat.nullspace) if available
try:
    import flint
    KERNEL_ENGINE = "FLINT nmod_mat"
except ImportError:
    flint = None; KERNEL_ENGINE = "gf.rrefp"

def core_kernel(Mc, P):
    """Columns spanning {x : Mc x = 0} over F_P, checked."""
    R, C = Mc.shape
    if C == 0: return np.zeros((0, 0), dtype=np.int64)
    if flint is not None and R > 0:
        X, nul = flint.nmod_mat(Mc.tolist(), P).nullspace()
        K = np.array([[int(X[i, j]) for j in range(nul)] for i in range(C)], dtype=np.int64).reshape(C, nul)
    else:
        A = Mc.copy(); piv = list(gf.rrefp(A, P)) if R else []; ps = set(piv); fc_ = [c for c in range(C) if c not in ps]
        K = np.zeros((C, len(fc_)), dtype=np.int64)
        for k, fc in enumerate(fc_):
            K[fc, k] = 1
            for r, pc in enumerate(piv): K[pc, k] = (-A[r, fc]) % P
    if K.shape[1]:
        # exact check in blocks (products < 2^40, sums of C terms < 2^53 for C < 8192)
        for j0 in range(0, K.shape[1], 64):
            Y = (Mc.astype(np.float64) @ K[:, j0:j0 + 64].astype(np.float64)) % P
            assert not Y.any(), "kernel check failed"
    return K

# ------------------------------------------------------------------ Markowitz with records
@nb.njit(cache=True)
def _pivot_records(ptr, col, val, elim_round, ncls):
    R = ptr.shape[0] - 1
    best = np.full(ncls, -1, dtype=np.int64); bl = np.full(ncls, 1 << 62, dtype=np.int64)
    for r in range(R):
        l = ptr[r + 1] - ptr[r]
        for t in range(ptr[r], ptr[r + 1]):
            c = col[t]
            if elim_round[c] and l < bl[c]:
                bl[c] = l; best[c] = r
    m = 0; nn = 0
    for c in range(ncls):
        if elim_round[c]:
            m += 1; nn += bl[c]
    pc = np.empty(m, dtype=np.int64); pptr = np.zeros(m + 1, dtype=np.int64)
    pcol = np.empty(nn, dtype=np.int64); pval = np.empty(nn, dtype=np.int64)
    i = 0; k = 0
    for c in range(ncls):
        if not elim_round[c]: continue
        r = best[c]; pc[i] = c
        for t in range(ptr[r], ptr[r + 1]):
            pcol[k] = col[t]; pval[k] = val[t]; k += 1
        i += 1; pptr[i] = k
    return pc, pptr, pcol, pval

def markowitz_rec(ptr, col, val, ncls, P, maxcost_stop=384, min_frac=0.002):
    elim = np.zeros(ncls, dtype=np.bool_); recs = []; nrounds = 0
    for maxcost in SCHEDULE:
        if maxcost > maxcost_stop: break
        while True:
            out = _mk_round_fp(ptr, col, val, ncls, maxcost, P)
            nsel = out[3]
            if nsel == 0: break
            recs.append(_pivot_records(ptr, col, val, out[4], ncls))
            ptr, col, val = out[0], out[1], out[2]; elim |= out[4]; nrounds += 1
            live = int(np.count_nonzero(np.bincount(col, minlength=ncls))) if nrounds % 4 == 0 else None
            if live is not None and nsel < min_frac * live: break
        ptr, col, val = dedup_fp(ptr, col, val, P)
    return ptr, col, val, elim, recs

@nb.njit(cache=True)
def _backsub(V, pc, pptr, pcol, pval, P):
    d = V.shape[1]; acc = np.zeros(d, dtype=np.int64)
    for i in range(pc.shape[0] - 1, -1, -1):
        c = pc[i]; ac = 0
        for k in range(d): acc[k] = 0
        for t in range(pptr[i], pptr[i + 1]):
            j = pcol[t]
            if j == c:
                ac = pval[t]
            else:
                a = pval[t]
                for k in range(d): acc[k] = (acc[k] + a * V[j, k]) % P
        f = (P - _inv(ac, P)) % P
        for k in range(d): V[c, k] = (acc[k] * f) % P

@nb.njit(cache=True)
def _check_all(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, Z):
    nr, T = tg.shape; eu = np.empty(T, dtype=np.int64); ev = np.empty(T, dtype=np.int64)
    d = Z.shape[1]; acc = np.zeros(d, dtype=np.int64); bad = 0; notclosed = 0
    for r in range(nr):
        for x in range(n):
            k, ok = _walk_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, r, x, eu, ev)
            if not ok: notclosed += 1
            for j in range(d): acc[j] = 0
            for t in range(k):
                u = eu[t]; c = ev[t]
                for j in range(d): acc[j] = (acc[j] + c * Z[u, j]) % P
            for j in range(d):
                if acc[j] != 0:
                    bad += 1; break
    return bad, notclosed

@nb.njit(cache=True)
def _bfs_P(nxt, FP, G, n, root, P):
    lam = np.zeros(n, dtype=np.int64); par_x = -np.ones(n, dtype=np.int64); par_g = -np.ones(n, dtype=np.int64)
    seen = np.zeros(n, dtype=np.bool_); q = np.empty(n, dtype=np.int64); head = 0; tail = 0
    lam[root] = 1; seen[root] = True; q[tail] = root; tail += 1
    while head < tail:
        x = q[head]; head += 1
        for g in range(G):
            y = nxt[g, x]
            if not seen[y]:
                seen[y] = True; lam[y] = (lam[x] * FP[g, x]) % P; par_x[y] = x; par_g[y] = g
                q[tail] = y; tail += 1
    return lam, par_x, par_g

def solve_fp(A, B, P):
    """X with A X = B over F_P (A: m x D, B: m x k, m >= D); None if inconsistent or A not of full column rank."""
    D = A.shape[1]
    Aug = np.concatenate([A % P, B % P], axis=1).astype(np.int64)
    piv = list(gf.rrefp(Aug, P))
    if any(p >= D for p in piv) or len(piv) < D: return None
    X = np.zeros((D, B.shape[1]), dtype=np.int64)
    for r, p in enumerate(piv): X[p] = Aug[r, D:]
    return X

def powmod_vec(a, e, P):
    r = np.ones_like(a); b = a % P
    while e:
        if e & 1: r = (r * b) % P
        b = (b * b) % P; e >>= 1
    return r

# ------------------------------------------------------------------ the space and its Hecke operators
class FpHecke:
    def __init__(self, L, P, chip, psi_order, maxcost_stop=384, dense_max=8000, seed=1, verbose=True):
        t0 = time.time(); self.L, self.P = L, P; G = len(L.gens); n = L.n; ncol = G * n; self.G, self.n = G, n
        self.chip = chip
        self.nxa, self.lg_gen, _ = log_step_tables(L, 0, 64)
        self.psit, self.zeta = psi_table(P, psi_order)
        self.logtab = log_table(L.comps[0], 64)[0]
        tg, te = relator_arrays(L); self.tg, self.te = tg, te
        FP = (chip[L.NXE.astype(np.int64)] * self.psit[self.nxa.astype(np.int64)]) % P; self.FP = FP
        self.nontrivial = bool((FP != 1).any())
        root, rfac, alive, passes, notclosed = closure_psi(L.NXT, L.NXE, self.nxa, chip, self.psit, tg, te, G, n, L.TREE, P)
        assert notclosed == 0
        root[L.TREE] = -1; rfac[L.TREE] = 0
        reps = np.unique(root[root >= 0]); ncls = len(reps)
        cls_of = -np.ones(ncol, dtype=np.int64); pos = -np.ones(ncol, dtype=np.int64); pos[reps] = np.arange(ncls)
        mk = root >= 0; cls_of[mk] = pos[root[mk]]
        self.cls_of, self.rfac, self.ncls = cls_of, rfac, ncls
        ptr, col, val, hs = rows_to_csr_psi(L.NXT, L.NXE, self.nxa, chip, self.psit, tg, te, G, n, L.TREE, P, alive, cls_of.astype(np.int32), rfac)
        ptr, col, val = dedup_fp(ptr, col, val, P, hs)
        if verbose: print("  closure: %d classes, %d equations after deduplication (%.0fs)" % (ncls, len(ptr) - 1, time.time() - t0), flush=True)
        ptr, col, val, elim, recs = markowitz_rec(ptr, col, val, ncls, P, maxcost_stop=maxcost_stop)
        cw = np.bincount(col, minlength=ncls)
        core_x = np.nonzero(cw > 0)[0]; free = np.nonzero((cw == 0) & ~elim)[0]; C = len(core_x)
        newid = -np.ones(ncls, dtype=np.int64); newid[core_x] = np.arange(C)
        if verbose: print("  Markowitz: %d pivots recorded in %d rounds; core %d x %d; free classes %d (%.0fs)" % (int(elim.sum()), len(recs), len(ptr) - 1, C, len(free), time.time() - t0), flush=True)
        assert C <= dense_max, "core too large for the dense kernel"
        Mc = np.zeros((len(ptr) - 1, C), dtype=np.int64)
        for r in range(len(ptr) - 1): Mc[r, newid[col[ptr[r]:ptr[r + 1]]]] = val[ptr[r]:ptr[r + 1]]
        t2 = time.time(); Kc = core_kernel(Mc, P)                     # (C, kc): kernel vectors as columns
        d = Kc.shape[1] + len(free); self.dZ = d; fcols = range(Kc.shape[1])
        V = np.zeros((ncls, d), dtype=np.int64)
        V[core_x, :Kc.shape[1]] = Kc
        for i, fcl in enumerate(free): V[fcl, Kc.shape[1] + i] = 1
        del Mc
        if verbose: print("  dense core kernel %d (%s, %.0fs)" % (Kc.shape[1], KERNEL_ENGINE, time.time() - t2), flush=True)
        for pc, pptr, pcol, pval in reversed(recs): _backsub(V, pc, pptr, pcol, pval, P)
        Z = np.zeros((ncol, d), dtype=np.int64); ok = cls_of >= 0
        Z[ok] = (rfac[ok][:, None] * V[cls_of[ok]]) % P
        self.Z = Z
        bad, nc = _check_all(L.NXT, L.NXE, self.nxa, chip, self.psit, tg, te, G, n, L.TREE, P, Z)
        assert nc == 0 and bad == 0, (bad, nc)
        # independence of the kernel vectors (on a random set of edges)
        if verbose: print("  kernel dim Z = %d (core kernel %d + free %d); all %d relator equations hold on every vector (%.0fs)" % (d, len(fcols), len(free), tg.shape[0] * n, time.time() - t0), flush=True)
        lam, px, pg = _bfs_P(L.NXT, FP, G, n, L.root, P)
        assert (px == L.PAR_X).all() and (pg == L.PAR_G).all(), "BFS tree differs"
        self.lamP = lam; m = powmod_vec(lam, P - 2, P)
        dm = np.zeros(ncol, dtype=np.int64)
        for s in range(G): dm[s * n:(s + 1) * n] = (FP[s] * m[L.NXT[s]] - m) % P
        assert not dm[L.TREE].any()
        self.dm = dm if dm.any() else None
        rng = np.random.default_rng(seed)
        nt = np.nonzero(~L.TREE)[0]
        # pivots: d edges on which Z is invertible
        mm = min(len(nt), max(4 * d, 64))
        while True:
            sub = np.sort(rng.choice(nt, size=mm, replace=False))
            A = np.ascontiguousarray(Z[sub].T % P); pv = list(gf.rrefp(A, P))
            if len(pv) == d: break
            assert mm < len(nt), "dependent kernel vectors"
            mm = min(len(nt), 2 * mm)
        self.pivots = [int(sub[p]) for p in pv]
        if self.dm is not None:
            a = solve_fp(Z[self.pivots], self.dm[self.pivots][:, None], P)
            assert a is not None
            assert (((Z @ a[:, 0]) - self.dm) % P == 0).all(), "delta m_par not the combination found"
            self.drop = int(np.nonzero(a[:, 0])[0][0])
        else:
            self.drop = None
        self.keep = np.array([k for k in range(d) if k != self.drop], dtype=np.int64); self.D = len(self.keep)
        if verbose: print("  dim H^1 = %d (delta m_par %s) (%.0fs)" % (self.D, "in the span, one vector dropped" if self.drop is not None else "zero", time.time() - t0), flush=True)
        self.rng = rng

    # ---- characters and walks over F_P
    def epsP(self, lams):
        L = self.L; code = L._eps_tuple(lams) if L.eps_chars is not None else 1
        c0 = L.comps[0]; s = lams[0]
        ind = int(self.logtab[s[0], s[1]]) if c0.typ == "Fp2" else int(self.logtab[s])
        return int(self.chip[code]) * int(self.psit[ind % 64]) % self.P

    def walkP(self, toks):
        L, P, n, G = self.L, self.P, self.n, self.G
        cur = L.root; w = 1; out = collections.defaultdict(int)
        for g, e in toks:
            gi = L.gens.index(g)
            if e == 1:
                u = gi * n + cur; out[u] = (out[u] + w) % P
                w = w * int(self.FP[gi, cur]) % P; cur = int(L.NXT[gi, cur])
            else:
                s = G + gi; w = w * int(self.FP[s, cur]) % P; cur = int(L.NXT[s, cur])
                u = gi * n + cur; out[u] = (out[u] - w) % P
        return out, cur

    def pieces(self, pi, h):
        L, P = self.L, self.P
        reps = hecke.hecke_reps(pi); out = []
        for ai in reps:
            X0 = mmul(ai, h); found = None
            for aj in reps:
                X = mmul(X0, hecke.adj(aj))
                Y = tuple(hecke.odiv(e, pi) for e in X)
                if None in Y: continue
                if mdet(Y) not in ((1, 0), (-1, 0)) or not L.in_gamma0(Y): continue
                found = Y; break
            assert found is not None
            out.append((found, pow(self.epsP(L.d_scalar(ai)), P - 2, P)))
        return out

    def hecke(self, pi, extra=8):
        """Matrix (D x D) of T_pi on H^1: column k = coordinates of T(basis_k)."""
        L, P, n, Z = self.L, self.P, self.n, self.Z
        nt = np.nonzero(~L.TREE)[0]; pset = set(self.pivots)
        ex = [int(u) for u in self.rng.choice(nt, size=extra, replace=False) if int(u) not in pset]
        cols = self.pivots + ex
        vals = np.zeros((len(cols), self.D), dtype=np.int64)
        for r, u in enumerate(cols):
            g = L.gens[u // n]; x = u % n
            h = L.schreier(g, x); acc = np.zeros(self.dZ, dtype=np.int64)
            for hi, w in self.pieces(pi, h):
                dct, cur = self.walkP(decompose(hi))
                assert cur == L.root
                for v, c in dct.items():
                    if c: acc = (acc + (w * c % P) * Z[v]) % P
            il = pow(int(self.lamP[x]), P - 2, P)
            vals[r] = (acc[self.keep] * il) % P
        Bc = Z[cols][:, self.keep]
        if self.drop is not None: Bc = np.concatenate([Bc, self.dm[cols][:, None]], axis=1)
        X = solve_fp(Bc, vals, P)
        if X is None: return None
        return X[:self.D]
