"""H^1(Gamma_0(n), F_P(chi psi)) for PGL_2(O_E), E = Q(sqrt-7), with psi of 2-power order on one component of (O/n)^x.

sparse_fp.py handles chi (the Teichmueller lift of the F16 character of the level tables) times a quadratic psi.  Here
psi(x) = zeta^{ind_g x} on the units of one component k0 of O/n (g the first generator of that component's unit group in
the order used by char0_psi.py, zeta a primitive 2^k-th root of unity in F_P, P = 1 mod 2^k).  The nebentypus factor of a
step is chi(scalar) psi(scalar), the scalar being the one of Comp.normalize (sparse_h1._local_action_vec), as for chi
and for the quadratic characters of bockstein.quad_step_tables.  Everything after the equations (deduplication,
Markowitz, dense core or block Lanczos with the Krylov certificate) is sparse_fp.py unchanged.

Checks built in: the local actions must reproduce the level tables; ind mod 2 must equal the quadratic-character bit of
bockstein.quad_step_tables on that component; psi(-1) = 1 (otherwise psi is not a nebentypus for PGL_2).
Validation against the dense engine: fp_check_psi.py.  Author: Dula."""
import os, time
import numpy as np, numba as nb
from o7 import GEN, GINV
from sparse_h1 import relator_arrays, _local_action_vec
from sparse_big import _row_hash, _relabel
from sparse_fp import _inv, _find, dedup_fp, markowitz_fp, lanczos_bound

# ------------------------------------------------------------------ discrete logarithms on one component
def _fp2_mul(x, y, p):
    return ((x[0] * y[0] - 2 * x[1] * y[1]) % p, (x[0] * y[1] + x[1] * y[0] + x[1] * y[1]) % p)

def _fp2_pow(x, e, p):
    r = (1, 0)
    while e:
        if e & 1: r = _fp2_mul(r, x, p)
        x = _fp2_mul(x, x, p); e >>= 1
    return r

def _prime_factors(m):
    out = []; d = 2
    while d * d <= m:
        if m % d == 0:
            out.append(d)
            while m % d == 0: m //= d
        d += 1
    if m > 1: out.append(m)
    return out

def first_generator(c):
    """first generator of the unit group of the component, in the order of char0_psi.py: 1, 2, ... for F_p;
    (u, v) lexicographic, (0, 0) left out, for F_p2 = F_p[t]/(t^2 - t + 2)."""
    p = c.p
    if c.typ == "Fp":
        q = p; fs = _prime_factors(q - 1)
        for g in range(1, p):
            if all(pow(g, (q - 1) // r, p) != 1 for r in fs): return g, q
    q = p * p; fs = _prime_factors(q - 1)
    for u in range(p):
        for v in range(p):
            if (u, v) == (0, 0): continue
            if all(_fp2_pow((u, v), (q - 1) // r, p) != (1, 0) for r in fs): return (u, v), q
    raise ValueError("no generator")

@nb.njit(cache=True)
def _log_table_fp2(p, gu, gv, mod):
    tab = np.zeros((p, p), dtype=np.uint8); seen = np.zeros((p, p), dtype=np.bool_)
    u = np.int64(1); v = np.int64(0); q = p * p
    for e in range(q - 1):
        if seen[u, v]: return tab, False
        seen[u, v] = True; tab[u, v] = e % mod
        nu = (u * gu - 2 * v * gv) % p; nv = (u * gv + v * gu + v * gv) % p
        u = nu; v = nv
    return tab, (u == 1 and v == 0)

def log_table(c, mod=64):
    """table of ind_g(x) mod `mod` on the units of the component (index x for F_p, (u, v) for F_p2), and g."""
    g, q = first_generator(c)
    p = c.p
    if c.typ == "Fp":
        tab = np.zeros(p, dtype=np.uint8); x = 1
        for e in range(q - 1):
            tab[x] = e % mod; x = x * g % p
        assert x == 1
        return tab, g, q
    tab, ok = _log_table_fp2(p, g[0], g[1], mod)
    assert ok, "generator check failed"
    return tab, g, q

def log_step_tables(L, k0=0, mod=64):
    """NXA[s, x] (uint8) = ind_g(scalar of component k0 for step s from coset x) mod `mod`; s < G generators, s >= G
    inverses.  Also returns the quadratic-character bits of that component (ind mod 2) for the comparison with
    bockstein.quad_step_tables, and (g, q)."""
    n = L.n; G = len(L.gens)
    mats = [GEN[g] for g in L.gens] + [GINV[g] for g in L.gens]
    xs = np.arange(n, dtype=np.int64)
    c = L.comps[k0]
    tab, g, q = log_table(c, mod)
    nxa = np.zeros((2 * G, n), dtype=np.uint8)
    for s, M in enumerate(mats):
        idx = np.zeros(n, dtype=np.int64); val = None
        for k, ck in enumerate(L.comps):
            Mr = tuple(ck.red(e) for e in M)
            j, loc = _local_action_vec(ck, Mr, tab if k == k0 else None)
            ik = (xs // L.strides[k]) % L.sizes[k]
            idx += j[ik] * L.strides[k]
            if k == k0: val = loc[ik].astype(np.uint8)
        assert (idx == L.NXT[s]).all(), "local action differs from the level tables"
        nxa[s] = val
    return nxa, g, q

def psi_table(P, order, mod=64):
    """psit[a] = zeta^a in F_P for a = 0..mod-1, zeta = gP^((P-1)/order) a primitive order-th root of unity."""
    import cypari2
    pari = cypari2.Pari()
    assert (P - 1) % order == 0 and mod % order == 0
    gP = int(pari("lift(znprimroot(%d))" % P)); z = pow(gP, (P - 1) // order, P)
    assert order == 1 or pow(z, order // 2, P) == P - 1
    t = np.ones(mod, dtype=np.int64); x = 1
    for a in range(mod):
        t[a] = x; x = x * z % P
    return t, z

# ------------------------------------------------------------------ equations with the factor chi * psi
@nb.njit(cache=True)
def _walk_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, r, x, eu, ev):
    T = tg.shape[1]; cur = np.int64(x); w = np.int64(1); m = 0
    for j in range(T):
        g = np.int64(tg[r, j])
        if g < 0: break
        if te[r, j] == 1:
            u = g * n + cur; c = w
            f = (chip[nxe[g, cur]] * psit[nxa[g, cur]]) % P
            w = (w * f) % P; cur = np.int64(nxt[g, cur])
        else:
            s = G + g
            f = (chip[nxe[s, cur]] * psit[nxa[s, cur]]) % P
            w = (w * f) % P; cur = np.int64(nxt[s, cur])
            u = g * n + cur; c = (P - w) % P
        if tree[u]: continue
        found = False
        for t in range(m):
            if eu[t] == u:
                ev[t] = (ev[t] + c) % P; found = True; break
        if not found:
            eu[m] = u; ev[m] = c; m += 1
    k = 0
    for t in range(m):
        if ev[t] != 0:
            eu[k] = eu[t]; ev[k] = ev[t]; k += 1
    return k, cur == x

@nb.njit(cache=True)
def closure_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P):
    nr, T = tg.shape; ncol = G * n; R = nr * n
    par = np.arange(ncol, dtype=np.int64); fac = np.ones(ncol, dtype=np.int64); zero = np.zeros(ncol, dtype=np.bool_)
    stack = np.empty(ncol, dtype=np.int64); alive = np.ones(R, dtype=np.bool_)
    eu = np.empty(T, dtype=np.int64); ev = np.empty(T, dtype=np.int64)
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.int64)
    changed = True; passes = 0; notclosed = 0
    while changed:
        changed = False; passes += 1
        for row in range(R):
            if not alive[row]: continue
            r = row // n; x = row - r * n
            k0, ok = _walk_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, r, x, eu, ev)
            if not ok: notclosed += 1
            mm_ = 0
            for t in range(k0):
                u = eu[t]
                v = _find(u, par, fac, P, stack)
                if zero[v]: continue
                f = fac[u] if u != v else np.int64(1)
                c = (ev[t] * f) % P
                found = False
                for s in range(mm_):
                    if rc[s] == v:
                        rv[s] = (rv[s] + c) % P; found = True; break
                if not found:
                    rc[mm_] = v; rv[mm_] = c; mm_ += 1
            k = 0
            for s in range(mm_):
                if rv[s] != 0:
                    rc[k] = rc[s]; rv[k] = rv[s]; k += 1
            if k == 0:
                alive[row] = False
            elif k == 1:
                zero[rc[0]] = True; alive[row] = False; changed = True
            elif k == 2:
                a = rc[0]; b = rc[1]
                par[a] = b; fac[a] = ((P - rv[1]) * _inv(rv[0], P)) % P
                alive[row] = False; changed = True
    root = np.empty(ncol, dtype=np.int64); rfac = np.zeros(ncol, dtype=np.int64)
    for u in range(ncol):
        v = _find(u, par, fac, P, stack)
        if zero[v]:
            root[u] = -1; rfac[u] = 0
        else:
            root[u] = v; rfac[u] = fac[u] if u != v else 1
    return root, rfac, alive, passes, notclosed

@nb.njit(cache=True)
def _row_terms_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, row, cls_of, rfac, eu, ev, rc, rv):
    r = row // n; x = row - r * n
    k0, ok = _walk_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, r, x, eu, ev)
    mm_ = 0
    for t in range(k0):
        u = eu[t]; v = cls_of[u]
        if v < 0: continue
        c = (ev[t] * rfac[u]) % P
        found = False
        for s in range(mm_):
            if rc[s] == v:
                rv[s] = (rv[s] + c) % P; found = True; break
        if not found:
            rc[mm_] = v; rv[mm_] = c; mm_ += 1
    k = 0
    for s in range(mm_):
        if rv[s] != 0:
            rc[k] = rc[s]; rv[k] = rv[s]; k += 1
    return k

@nb.njit(cache=True)
def rows_to_csr_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, alive, cls_of, rfac):
    nr, T = tg.shape; R = nr * n
    eu = np.empty(T, dtype=np.int64); ev = np.empty(T, dtype=np.int64)
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.int64)
    lens = np.zeros(R, dtype=np.int64); total = 0; nrows = 0
    for row in range(R):
        if not alive[row]: continue
        k = _row_terms_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, row, cls_of, rfac, eu, ev, rc, rv)
        lens[row] = k; total += k
        if k: nrows += 1
    ptr = np.zeros(nrows + 1, dtype=np.int64); col = np.empty(total, dtype=np.int32); val = np.empty(total, dtype=np.int64)
    hs = np.empty(nrows, dtype=np.uint64); ri = 0; p = 0
    for row in range(R):
        if not alive[row] or lens[row] == 0: continue
        k = _row_terms_psi(nxt, nxe, nxa, chip, psit, tg, te, G, n, tree, P, row, cls_of, rfac, eu, ev, rc, rv)
        for i in range(1, k):
            a = rc[i]; b = rv[i]; j = i - 1
            while j >= 0 and rc[j] > a:
                rc[j + 1] = rc[j]; rv[j + 1] = rv[j]; j -= 1
            rc[j + 1] = a; rv[j + 1] = b
        s0 = _inv(rv[0], P)
        for i in range(k):
            col[p + i] = rc[i]; val[p + i] = (rv[i] * s0) % P
        hs[ri] = _row_hash(col[p:p + k], val[p:p + k], k)
        p += k; ri += 1; ptr[ri] = p
    return ptr, col, val, hs

# ------------------------------------------------------------------ the whole computation
class FpH1Psi:
    """dim H^1(Gamma_0(n), F_P(chi psi)), psi = zeta^ind on component k0 (exact for small cores, otherwise an upper bound
    with the Lanczos certificate).  `tag` names the cache files."""
    def __init__(self, L, P, chip, nxa, psit, tag, maxcost_stop=384, dense_max=4000, b=16, seed=1, verbose=True, cache=None,
                 check_every=0):
        t0 = time.time(); G = len(L.gens); n = L.n; ncol = G * n; self.t = {}
        tg, te = relator_arrays(L)
        self.nontrivial = bool((psit[nxa] != 1).any()) or bool((chip[L.NXE] != 1).any())
        red = None if cache is None else os.path.join(cache, "fp_reduction_P%d_%s.npz" % (P, tag))
        if red is not None and os.path.exists(red):
            z = np.load(red); ptr, col, val = z["ptr"], z["col"], z["val"]; self.ncls = int(z["ncls"]); self.nfree = int(z["nfree"]); C = int(z["C"]); del z
            if verbose: print("  F_P reduction loaded from %s" % red, flush=True)
        else:
            root, rfac, alive, passes, notclosed = closure_psi(L.NXT, L.NXE, nxa, chip, psit, tg, te, G, n, L.TREE, P)
            assert notclosed == 0
            root[L.TREE] = -1; rfac[L.TREE] = 0
            reps = np.unique(root[root >= 0]); ncls = len(reps)
            cls_of = -np.ones(ncol, dtype=np.int32); pos = -np.ones(ncol, dtype=np.int64); pos[reps] = np.arange(ncls)
            mk = root >= 0; cls_of[mk] = pos[root[mk]].astype(np.int32); del pos, mk, root
            if verbose: print("  F_P closure (%d passes): %d classes, %d equations left (%.0fs)" % (passes, ncls, int(alive.sum()), time.time() - t0), flush=True)
            ptr, col, val, hs = rows_to_csr_psi(L.NXT, L.NXE, nxa, chip, psit, tg, te, G, n, L.TREE, P, alive, cls_of, rfac)
            del alive, cls_of, rfac
            ptr, col, val = dedup_fp(ptr, col, val, P, hs); del hs
            inrows = np.bincount(col, minlength=ncls) > 0
            if verbose: print("  deduplicated: %d equations, nnz %d, classes in equations %d of %d (%.0fs)" % (len(ptr) - 1, len(col), int(inrows.sum()), ncls, time.time() - t0), flush=True)
            ptr, col, val, elim = markowitz_fp(ptr, col, val, ncls, P, maxcost_stop=maxcost_stop, verbose=verbose)
            cw = np.bincount(col, minlength=ncls)
            core_x = np.nonzero(cw > 0)[0]; free = np.nonzero((cw == 0) & ~elim)[0]
            C = len(core_x); newid = -np.ones(ncls, dtype=np.int64); newid[core_x] = np.arange(C)
            col = _relabel(col, newid); self.ncls = ncls; self.nfree = len(free)
            if red is not None:
                os.makedirs(cache, exist_ok=True); np.savez(red, ptr=ptr, col=col, val=val, ncls=ncls, nfree=self.nfree, C=C)
        self.core_shape = (len(ptr) - 1, C, len(col)); self.t["reduction"] = time.time() - t0
        if verbose: print("  core %d x %d, nnz %d; free classes %d (%.0fs)" % (*self.core_shape, self.nfree, time.time() - t0), flush=True)
        t1 = time.time()
        if C <= dense_max:
            import gf
            Mc = np.zeros((len(ptr) - 1, C), dtype=np.int64)
            for r in range(len(ptr) - 1): Mc[r, col[ptr[r]:ptr[r + 1]]] = val[ptr[r]:ptr[r + 1]]
            rk = len(gf.rrefp(Mc, P)) if C else 0
            self.kercore = C - rk; self.exact = True; self.lanczos = None
        else:
            ck = None if cache is None else os.path.join(cache, "fp_lanczos_P%d_%s_b%d_s%d.npz" % (P, tag, b, seed))
            info = lanczos_bound(ptr, col, val, C, P, b=b, seed=seed, verbose=verbose, ckpt=ck, check_every=check_every)
            self.kercore = info["gap"]; self.exact = False; self.lanczos = info
        self.t["core"] = time.time() - t1
        self.dimZ = self.kercore + self.nfree
        self.dimH1 = self.dimZ - (1 if self.nontrivial else 0)
        if verbose: print("  dim Z_gauge %s %d; dim H^1(F_%d) %s %d (%.0fs)" % ("=" if self.exact else "<=", self.dimZ, P, "=" if self.exact else "<=", self.dimH1, time.time() - t0), flush=True)
