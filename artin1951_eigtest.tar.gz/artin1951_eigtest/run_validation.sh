#!/usr/bin/env bash
# Validation on the even tetrahedral representation of conductor 163 (automorphic, so the answer is known).
# About 2-5 minutes and under 2 GB.  Every line printed under "EXPECTED" must match what the run reports.
# Usage:  bash run_validation.sh            (uses `python3`; for Sage: PY="sage -python" bash run_validation.sh)
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="${PY:-python3}"
export ARTIN_ROOT="$HERE"
export ARTIN_OUT="${ARTIN_OUT:-$HERE/out_validation}"
mkdir -p "$ARTIN_OUT"
cd "$ARTIN_OUT"                                   # run outside the code folder
run () {  # name, env...
  local name="$1"; shift
  echo "== $name"
  env "$@" P2_ORD=15 P2_S=5 P2_EIGTEST=1 $PY -I "$HERE/families/p2_mod8.py" t163 > "$ARTIN_OUT/$name.log" 2>&1 || { echo "FAILED, see $ARTIN_OUT/$name.log"; tail -20 "$ARTIN_OUT/$name.log"; exit 1; }
  grep -E "^## (depth|CONTROL)" "$ARTIN_OUT/$name.log"
}
run t163_main
run t163_shift2 P2_ESHIFT=q11:2
run t163_shift4 "P2_ESHIFT=(3):4"
run t163_conj  P2_ECONJ=2
cat <<'EOF'

EXPECTED (computed on 11 November 2026):
  t163_main   : depth {'1,12': 3, '12,1': 3, '1,1': 3, '12,12': 3}
  t163_shift2 : depth 1 at all four
  t163_shift4 : depth 2 at all four
  t163_conj   : depth 0 at all four
If these match, the installation computes what the paper describes.  Then run run_1951.sh.
EOF
echo "== 1951 eigenvalue convention check"
$PY -I "$HERE/families/check_lam1951.py"
echo "EXPECTED: conjugate 1 differs at 0 primes; conjugates 2, 3, 4 differ at many; max difference ~1e-16."
