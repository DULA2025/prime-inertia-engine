import Mathlib

/-!
# The transition window (Lemma 8.2)

Section 8 of the paper transports an endpoint partition, valid at the half-level `θ = 1/2`,
to nearby moduli. The mechanism is elementary: the bin capacities are affine functions of
`θ = log_x q` with absolute slope at most `L_leaf`, and each of them has reserve at least `η`
at `θ = 1/2`; hence they all stay positive as long as `|θ - 1/2| < η / L_leaf`.

`SmallGaps.Transition.capacity_pos_of_abs_sub_lt` is this statement, and
`SmallGaps.Transition.window_radius_min` records that taking the minimum of the radii over
finitely many leaves gives one uniform window.
-/

open scoped BigOperators

set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace SmallGaps

namespace Transition

/-- **Lemma 8.2.** Affine bin capacities with absolute slope at most `Lleaf` and reserve at
least `η` at the endpoint `θ = 1/2` remain (strictly) positive on the window
`|θ - 1/2| < η / Lleaf`. -/
theorem capacity_pos_of_abs_sub_lt {ι : Type*} (cap : ι → ℝ → ℝ) (a b : ι → ℝ)
    (Lleaf eta theta : ℝ) (hL : 0 < Lleaf)
    (haffine : ∀ i θ, cap i θ = a i + b i * θ)
    (hslope : ∀ i, |b i| ≤ Lleaf)
    (hreserve : ∀ i, eta ≤ cap i (1 / 2))
    (hwin : |theta - 1 / 2| < eta / Lleaf) :
    ∀ i, 0 < cap i theta := by
  intro i
  have hdiff : cap i theta - cap i (1 / 2) = b i * (theta - 1 / 2) := by
    rw [haffine, haffine]; ring
  have hbound : |cap i theta - cap i (1 / 2)| ≤ Lleaf * |theta - 1 / 2| := by
    rw [hdiff, abs_mul]
    exact mul_le_mul_of_nonneg_right (hslope i) (abs_nonneg _)
  have hlt : Lleaf * |theta - 1 / 2| < eta := by
    have := (mul_lt_mul_iff_of_pos_left hL).2 hwin
    rwa [mul_div_cancel₀ _ hL.ne'] at this
  have h1 : cap i (1 / 2) - cap i theta ≤ |cap i theta - cap i (1 / 2)| := by
    rw [abs_sub_comm]
    exact le_abs_self _
  have h2 := hreserve i
  linarith

/-- Taking the minimum of the individual window radii over a nonempty finite family of leaves
gives a single window on which every leaf stays positive. -/
theorem window_radius_min {ι : Type*} (s : Finset ι) (radius : ι → ℝ) (theta : ℝ)
    (hs : s.Nonempty) (hwin : |theta - 1 / 2| < s.inf' hs radius) :
    ∀ i ∈ s, |theta - 1 / 2| < radius i :=
  fun _ hi => lt_of_lt_of_le hwin (Finset.inf'_le _ hi)

end Transition

end SmallGaps
