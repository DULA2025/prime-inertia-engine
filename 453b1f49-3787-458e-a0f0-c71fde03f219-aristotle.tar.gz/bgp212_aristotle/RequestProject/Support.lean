import RequestProject.Parameters

/-!
# The support, its dilation, and the moving marginal endpoint

This file formalizes the geometry of Section 9.4 of the paper:

* `SmallGaps.Support.support` is the region cut out by a total-mass bound `L`, a rough
  threshold `g` and a cap sequence `C` applied to the number of rough coordinates;
* `SmallGaps.Support.image_smul_support` is the general dilation statement behind Lemma 9.1,
  and `SmallGaps.Support.rescaled_support` is Lemma 9.1 itself for the parameter datum of
  Table 3;
* `SmallGaps.Support.marginal_fiber` is Lemma 9.2, the exact description of the fiber of the
  last coordinate, with moving endpoint `U(x̂) = min {L - S, max {g, C(s+1) - ρ₁}}`.
-/

open scoped BigOperators
open scoped Classical

set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace SmallGaps

namespace Support

variable {n : ℕ}

/-- The number of rough coordinates, i.e. of coordinates exceeding the threshold `g`. -/
noncomputable def roughCount (g : ℝ) (x : Fin n → ℝ) : ℕ := ∑ i, if g < x i then 1 else 0

/-- The total mass carried by the rough coordinates. -/
noncomputable def roughMass (g : ℝ) (x : Fin n → ℝ) : ℝ := ∑ i, if g < x i then x i else 0

/-- The total mass `P₁(x) = ∑ xᵢ`. -/
def totalMass (x : Fin n → ℝ) : ℝ := ∑ i, x i

theorem roughCount_eq_card (g : ℝ) (x : Fin n → ℝ) :
    roughCount g x = (Finset.univ.filter (fun i => g < x i)).card := by
  rw [roughCount, Finset.card_filter]

theorem roughMass_eq_sum (g : ℝ) (x : Fin n → ℝ) :
    roughMass g x = ∑ i ∈ Finset.univ.filter (fun i => g < x i), x i := by
  rw [roughMass, Finset.sum_filter]

/-- The support determined by a rough threshold `g`, a total-mass bound `L` and a cap
sequence `C`: the set of nonnegative points of total mass at most `L` whose rough mass is at
most the cap attached to the number of rough coordinates. -/
def support (g L : ℝ) (C : ℕ → ℝ) (n : ℕ) : Set (Fin n → ℝ) :=
  {x | (∀ i, 0 ≤ x i) ∧ totalMass x ≤ L ∧ roughMass g x ≤ C (roughCount g x)}

theorem mem_support_iff {g L : ℝ} {C : ℕ → ℝ} {x : Fin n → ℝ} :
    x ∈ support g L C n ↔
      (∀ i, 0 ≤ x i) ∧ totalMass x ≤ L ∧ roughMass g x ≤ C (roughCount g x) := Iff.rfl

/-! ## Behaviour under dilation -/

theorem totalMass_smul (c : ℝ) (x : Fin n → ℝ) : totalMass (c • x) = c * totalMass x := by
  simp [totalMass, Finset.mul_sum]

theorem roughCount_smul {c : ℝ} (hc : 0 < c) (g : ℝ) (x : Fin n → ℝ) :
    roughCount (c * g) (c • x) = roughCount g x := by
  refine Finset.sum_congr rfl (fun i _ => ?_)
  have h : c * g < c * x i ↔ g < x i := mul_lt_mul_iff_of_pos_left hc
  simp only [Pi.smul_apply, smul_eq_mul]
  by_cases hx : g < x i <;> simp [h, hx]

theorem roughMass_smul {c : ℝ} (hc : 0 < c) (g : ℝ) (x : Fin n → ℝ) :
    roughMass (c * g) (c • x) = c * roughMass g x := by
  rw [roughMass, roughMass, Finset.mul_sum]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  have h : c * g < c * x i ↔ g < x i := mul_lt_mul_iff_of_pos_left hc
  simp only [Pi.smul_apply, smul_eq_mul]
  by_cases hx : g < x i <;> simp [h, hx]

/-- **Dilation of the support.** Scaling all coordinates by `c > 0` scales the threshold, the
total-mass bound and the caps by `c`. This is the content of Lemma 9.1. -/
theorem image_smul_support {c : ℝ} (hc : 0 < c) (g L : ℝ) (C : ℕ → ℝ) :
    (fun t : Fin n → ℝ => c • t) '' support g L C n
      = support (c * g) (c * L) (fun m => c * C m) n := by
  ext x
  constructor
  · rintro ⟨t, ⟨hnn, hmass, hrough⟩, rfl⟩
    refine ⟨fun i => ?_, ?_, ?_⟩
    · simpa [Pi.smul_apply, smul_eq_mul] using mul_nonneg hc.le (hnn i)
    · rw [totalMass_smul]
      exact mul_le_mul_of_nonneg_left hmass hc.le
    · rw [roughMass_smul hc, roughCount_smul hc]
      exact mul_le_mul_of_nonneg_left hrough hc.le
  · rintro ⟨hnn, hmass, hrough⟩
    have hxt : c • (c⁻¹ • x) = x := by
      rw [smul_smul, mul_inv_cancel₀ hc.ne', one_smul]
    have hcount := roughCount_smul hc g (c⁻¹ • x)
    have hmassr := roughMass_smul hc g (c⁻¹ • x)
    rw [hxt] at hcount hmassr
    refine ⟨c⁻¹ • x, ⟨fun i => ?_, ?_, ?_⟩, hxt⟩
    · have hc' : (0 : ℝ) ≤ c⁻¹ := by positivity
      simpa [Pi.smul_apply, smul_eq_mul] using mul_nonneg hc' (hnn i)
    · rw [totalMass_smul]
      have h1 : c⁻¹ * totalMass x ≤ c⁻¹ * (c * L) :=
        mul_le_mul_of_nonneg_left hmass (by positivity)
      have h2 : c⁻¹ * (c * L) = L := by field_simp
      linarith
    · have hgoal : c * roughMass g (c⁻¹ • x) ≤ c * C (roughCount g (c⁻¹ • x)) := by
        rw [← hcount, ← hmassr]
        exact hrough
      exact (mul_le_mul_iff_of_pos_left hc).1 hgoal

/-! ## The marginal fiber (Lemma 9.2) -/

theorem totalMass_snoc (x : Fin n → ℝ) (u : ℝ) :
    totalMass (Fin.snoc x u : Fin (n + 1) → ℝ) = totalMass x + u := by
  rw [totalMass, totalMass, Fin.sum_univ_castSucc]
  simp

theorem roughCount_snoc_of_le {g : ℝ} (x : Fin n → ℝ) {u : ℝ} (hu : u ≤ g) :
    roughCount g (Fin.snoc x u : Fin (n + 1) → ℝ) = roughCount g x := by
  rw [roughCount, roughCount, Fin.sum_univ_castSucc]
  simp [Fin.snoc_castSucc, Fin.snoc_last, not_lt.2 hu]

theorem roughCount_snoc_of_lt {g : ℝ} (x : Fin n → ℝ) {u : ℝ} (hu : g < u) :
    roughCount g (Fin.snoc x u : Fin (n + 1) → ℝ) = roughCount g x + 1 := by
  rw [roughCount, roughCount, Fin.sum_univ_castSucc]
  simp [Fin.snoc_castSucc, Fin.snoc_last, hu]

theorem roughMass_snoc_of_le {g : ℝ} (x : Fin n → ℝ) {u : ℝ} (hu : u ≤ g) :
    roughMass g (Fin.snoc x u : Fin (n + 1) → ℝ) = roughMass g x := by
  rw [roughMass, roughMass, Fin.sum_univ_castSucc]
  simp [Fin.snoc_castSucc, Fin.snoc_last, not_lt.2 hu]

theorem roughMass_snoc_of_lt {g : ℝ} (x : Fin n → ℝ) {u : ℝ} (hu : g < u) :
    roughMass g (Fin.snoc x u : Fin (n + 1) → ℝ) = roughMass g x + u := by
  rw [roughMass, roughMass, Fin.sum_univ_castSucc]
  simp [Fin.snoc_castSucc, Fin.snoc_last, hu]

/-- **Lemma 9.2 (moving marginal endpoint).** Fix the first `n` coordinates `x̂`, nonnegative
and satisfying the rough cap. Then the last coordinate ranges exactly over the interval
`[0, U(x̂)]`, where `U(x̂) = min {L - S, max {g, C(s+1) - ρ₁}}` with `S` the total mass of `x̂`,
`s` its number of rough coordinates and `ρ₁` its rough mass. -/
theorem marginal_fiber (g L : ℝ) (C : ℕ → ℝ) (x : Fin n → ℝ)
    (hnn : ∀ i, 0 ≤ x i) (hcap : roughMass g x ≤ C (roughCount g x)) :
    {u : ℝ | 0 ≤ u ∧ (Fin.snoc x u : Fin (n + 1) → ℝ) ∈ support g L C (n + 1)}
      = Set.Icc 0 (min (L - totalMass x)
          (max g (C (roughCount g x + 1) - roughMass g x))) := by
  ext u
  simp only [Set.mem_setOf_eq, Set.mem_Icc, mem_support_iff]
  constructor
  · rintro ⟨hu0, -, hmass, hrough⟩
    rw [totalMass_snoc] at hmass
    refine ⟨hu0, le_min (by linarith) ?_⟩
    rcases le_or_gt u g with hug | hug
    · exact le_max_of_le_left hug
    · rw [roughCount_snoc_of_lt x hug, roughMass_snoc_of_lt x hug] at hrough
      exact le_max_of_le_right (by linarith)
  · rintro ⟨hu0, hu⟩
    have hu1 : u ≤ L - totalMass x := le_trans hu (min_le_left _ _)
    have hu2 : u ≤ max g (C (roughCount g x + 1) - roughMass g x) :=
      le_trans hu (min_le_right _ _)
    refine ⟨hu0, ?_, ?_, ?_⟩
    · intro i
      refine Fin.lastCases ?_ ?_ i
      · simpa using hu0
      · intro j; simpa using hnn j
    · rw [totalMass_snoc]; linarith
    · rcases le_or_gt u g with hug | hug
      · rw [roughCount_snoc_of_le x hug, roughMass_snoc_of_le x hug]
        exact hcap
      · rw [roughCount_snoc_of_lt x hug, roughMass_snoc_of_lt x hug]
        have : u ≤ C (roughCount g x + 1) - roughMass g x := by
          rcases max_cases g (C (roughCount g x + 1) - roughMass g x) with ⟨h, -⟩ | ⟨h, -⟩
          · rw [h] at hu2; linarith
          · rw [h] at hu2; exact hu2
        linarith

/-! ## Lemma 9.1 for the parameter datum of Table 3 -/

/-- The physical support `T` of Section 9.1, in the normalization of Table 3. -/
noncomputable def physicalSupport : Set (Fin 45 → ℝ) :=
  support (Params.delta : ℝ) ((Params.A1 + Params.epsS : ℚ) : ℝ)
    (fun m => ((Params.B m : ℚ) : ℝ)) 45

/-- The rescaled support `T̃` of Lemma 9.1. -/
noncomputable def rescaledSupport : Set (Fin 45 → ℝ) :=
  support (Params.g : ℝ) ((Params.L : ℚ) : ℝ) (fun m => ((Params.C m : ℚ) : ℝ)) 45

/-- **Lemma 9.1.** The dilation `x = 4t` maps the physical support `T` onto `T̃`. -/
theorem rescaled_support :
    (fun t : Fin 45 → ℝ => (4 : ℝ) • t) '' physicalSupport = rescaledSupport := by
  have h4 : (0 : ℝ) < 4 := by norm_num
  rw [physicalSupport, image_smul_support h4, rescaledSupport]
  have hg : (4 : ℝ) * ((Params.delta : ℚ) : ℝ) = ((Params.g : ℚ) : ℝ) := by
    rw [Params.g_eq]; push_cast; ring
  have hL : (4 : ℝ) * (((Params.A1 + Params.epsS : ℚ)) : ℝ) = ((Params.L : ℚ) : ℝ) := by
    rw [Params.L_eq]; push_cast; ring
  have hC : (fun m => (4 : ℝ) * ((Params.B m : ℚ) : ℝ)) = fun m => ((Params.C m : ℚ) : ℝ) := by
    funext m
    rw [Params.C]; push_cast; ring
  rw [hg, hL, hC]

end Support

end SmallGaps
