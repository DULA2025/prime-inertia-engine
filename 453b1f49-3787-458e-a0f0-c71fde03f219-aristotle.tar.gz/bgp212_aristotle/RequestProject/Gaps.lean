import RequestProject.Admissible

/-!
# From `DHL[k, 2]` to bounded gaps between primes

This file formalizes the deduction, carried out in Section 12 of the paper, of the bound
`H₁ ≤ 212` for `H₁ = liminf (p_{n+1} - p_n)`, from the statement `DHL[45, 2]` together with the
admissible 45-tuple `H45` of diameter 212 (Lemma 12.1).

The deduction is carried out for an arbitrary admissible `k`-tuple `H`: `DHL[k, 2]` implies
`H₁ ≤ diameter H`. Specializing to `H45` gives `H₁ ≤ 212`.
-/

open scoped BigOperators
open scoped Classical
open Filter

set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace SmallGaps

/-- `DHL k m` asserts: for every admissible `k`-tuple `H` there are infinitely many `n`
such that at least `m` of the shifted values `n + h`, `h ∈ H`, are prime. -/
def DHL (k m : ℕ) : Prop :=
  ∀ H : Finset ℕ, H.card = k → Admissible H →
    ∀ N : ℕ, ∃ n > N, m ≤ (H.filter (fun h => Nat.Prime (n + h))).card

/-- The `n`-th prime, indexed from `0`, i.e. `prime 0 = 2`. -/
noncomputable def prime (n : ℕ) : ℕ := Nat.nth Nat.Prime n

/-- The `n`-th prime gap `p_{n+1} - p_n`. -/
noncomputable def primeGap (n : ℕ) : ℕ := prime (n + 1) - prime n

theorem prime_prime (n : ℕ) : Nat.Prime (prime n) :=
  Nat.nth_mem_of_infinite Nat.infinite_setOf_prime n

theorem prime_lt_prime_iff {m n : ℕ} : prime m < prime n ↔ m < n :=
  Nat.nth_lt_nth Nat.infinite_setOf_prime

theorem prime_strictMono : StrictMono prime := fun _ _ h => prime_lt_prime_iff.2 h

theorem le_prime (n : ℕ) : n ≤ prime n := prime_strictMono.le_apply

/-- If `p < q` are primes, then the prime following `p` is at most `q`. -/
theorem exists_gap_le {p q : ℕ} (hp : Nat.Prime p) (hq : Nat.Prime q) (hpq : p < q) :
    ∃ i : ℕ, prime i = p ∧ prime (i + 1) ≤ q := by
  classical
  refine ⟨Nat.count Nat.Prime p, Nat.nth_count hp, ?_⟩
  have hcount : Nat.count Nat.Prime p + 1 ≤ Nat.count Nat.Prime q := by
    have h1 : Nat.count Nat.Prime (p + 1) = Nat.count Nat.Prime p + 1 := by
      rw [Nat.count_succ]
      simp [hp]
    have h2 : Nat.count Nat.Prime (p + 1) ≤ Nat.count Nat.Prime q :=
      Nat.count_monotone Nat.Prime hpq
    omega
  calc prime (Nat.count Nat.Prime p + 1)
      ≤ prime (Nat.count Nat.Prime q) :=
        (Nat.nth_le_nth Nat.infinite_setOf_prime).2 hcount
    _ = q := Nat.nth_count hq

/-- Two shifts of `H` at which `n` produces primes give a prime gap of at most
`diameter H`, occurring at an index at least `N`. -/
theorem primeGap_le_of_two_primes {H : Finset ℕ} (hH : H.Nonempty) {N n h₁ h₂ : ℕ}
    (hn : prime N < n) (hm₁ : h₁ ∈ H) (hm₂ : h₂ ∈ H)
    (hp₁ : Nat.Prime (n + h₁)) (hp₂ : Nat.Prime (n + h₂)) (hlt : h₁ < h₂) :
    ∃ i ≥ N, primeGap i ≤ diameter H hH := by
  have hmax : h₂ ≤ H.max' hH := Finset.le_max' H h₂ hm₂
  have hmin : H.min' hH ≤ h₁ := Finset.min'_le H h₁ hm₁
  have hdiam : h₂ - h₁ ≤ diameter H hH := by
    have hle : H.min' hH ≤ H.max' hH := Finset.min'_le_max' H hH
    rw [diameter]
    omega
  obtain ⟨i, hi, hi'⟩ := exists_gap_le hp₁ hp₂ (by omega)
  refine ⟨i, ?_, ?_⟩
  · have hlt' : prime N < prime i := by omega
    exact le_of_lt (prime_lt_prime_iff.1 hlt')
  · have hgap : primeGap i = prime (i + 1) - prime i := rfl
    omega

/-- Under `DHL[k, 2]` and for an admissible `k`-tuple `H`, for every `N` there is an index
`i ≥ N` with `p_{i+1} - p_i ≤ diameter H`. -/
theorem exists_index_ge_primeGap_le {k : ℕ} (h : DHL k 2) {H : Finset ℕ} (hH : H.Nonempty)
    (hcard : H.card = k) (hadm : Admissible H) (N : ℕ) :
    ∃ i ≥ N, primeGap i ≤ diameter H hH := by
  classical
  obtain ⟨n, hn, hcnt⟩ := h H hcard hadm (prime N)
  obtain ⟨h₁, hh₁, h₂, hh₂, hne⟩ := Finset.one_lt_card.1 hcnt
  simp only [Finset.mem_filter] at hh₁ hh₂
  obtain ⟨hm₁, hp₁⟩ := hh₁
  obtain ⟨hm₂, hp₂⟩ := hh₂
  rcases lt_trichotomy h₁ h₂ with hlt | heq | hgt
  · exact primeGap_le_of_two_primes hH hn hm₁ hm₂ hp₁ hp₂ hlt
  · exact absurd heq hne
  · exact primeGap_le_of_two_primes hH hn hm₂ hm₁ hp₂ hp₁ hgt

/-- Under `DHL[k, 2]`, gaps of size at most `diameter H` occur infinitely often. -/
theorem frequently_primeGap_le {k : ℕ} (h : DHL k 2) {H : Finset ℕ} (hH : H.Nonempty)
    (hcard : H.card = k) (hadm : Admissible H) :
    ∃ᶠ i in atTop, primeGap i ≤ diameter H hH := by
  rw [frequently_atTop]
  intro N
  exact exists_index_ge_primeGap_le h hH hcard hadm N

/-- Under `DHL[k, 2]`, `H₁ ≤ diameter H` for every admissible `k`-tuple `H`. -/
theorem liminf_primeGap_le_diameter {k : ℕ} (h : DHL k 2) {H : Finset ℕ} (hH : H.Nonempty)
    (hcard : H.card = k) (hadm : Admissible H) :
    liminf (fun i => (primeGap i : ℕ∞)) atTop ≤ (diameter H hH : ℕ∞) := by
  refine Filter.liminf_le_of_frequently_le' (((frequently_primeGap_le h hH hcard hadm)).mono ?_)
  intro i hi
  exact_mod_cast (Nat.cast_le (α := ℕ∞)).2 hi

/-! ## Specialization to `H45` -/

/-- **Theorem 1.1** (conditional on `DHL[45, 2]`): the prime gaps are at most `212`
infinitely often. -/
theorem frequently_primeGap_le_212 (h : DHL 45 2) :
    ∃ᶠ i in atTop, primeGap i ≤ 212 := by
  have := frequently_primeGap_le h H45_nonempty H45_card H45_admissible
  rwa [H45_diameter] at this

/-- **Theorem 1.1** (conditional on `DHL[45, 2]`), in `ℕ∞`:
`liminf (p_{n+1} - p_n) ≤ 212`. -/
theorem liminf_primeGap_le_212 (h : DHL 45 2) :
    liminf (fun i => (primeGap i : ℕ∞)) atTop ≤ 212 := by
  refine Filter.liminf_le_of_frequently_le' ((frequently_primeGap_le_212 h).mono ?_)
  intro i hi
  exact_mod_cast (Nat.cast_le (α := ℕ∞)).2 hi

/-- **Theorem 1.1** (conditional on `DHL[45, 2]`), in the form of pairs of primes: beyond every
bound there are two primes differing by at most `212`. -/
theorem exists_close_primes (h : DHL 45 2) (N : ℕ) :
    ∃ p q : ℕ, Nat.Prime p ∧ Nat.Prime q ∧ N < p ∧ p < q ∧ q ≤ p + 212 := by
  obtain ⟨i, hi, hgap⟩ := exists_index_ge_primeGap_le h H45_nonempty H45_card H45_admissible
    (N + 1)
  rw [H45_diameter] at hgap
  refine ⟨prime i, prime (i + 1), prime_prime i, prime_prime (i + 1), ?_, ?_, ?_⟩
  · have h1 : N + 1 ≤ prime i := le_trans hi (le_prime i)
    omega
  · exact prime_strictMono (Nat.lt_succ_self i)
  · have h2 : prime i < prime (i + 1) := prime_strictMono (Nat.lt_succ_self i)
    have h3 : primeGap i = prime (i + 1) - prime i := rfl
    omega

/-- **Theorem 1.1** (conditional on `DHL[45, 2]`), over the reals:
`liminf (p_{n+1} - p_n) ≤ 212`. -/
theorem liminf_primeGap_le_212_real (h : DHL 45 2) :
    liminf (fun i => (primeGap i : ℝ)) atTop ≤ 212 := by
  refine Filter.liminf_le_of_frequently_le ((frequently_primeGap_le_212 h).mono ?_) ?_
  · intro i hi
    exact_mod_cast hi
  · exact ⟨0, Filter.eventually_map.2
      (Filter.Eventually.of_forall (fun i => Nat.cast_nonneg (primeGap i)))⟩

end SmallGaps
