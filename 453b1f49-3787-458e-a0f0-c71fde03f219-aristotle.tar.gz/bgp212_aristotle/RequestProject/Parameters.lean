import Mathlib

/-!
# The exact parameter datum and the slack ledger

This file records the rational parameter datum `P` of Table 3 of the paper, and verifies, in
exact rational arithmetic, the inequalities of Table 4 ("the six principal exact reserves") and
of Table 6 in Appendix B ("exact analytic and combinatorial slack ledger").

Each inequality is stated in the orientation `left ≤ right` used in the paper, and, wherever the
entry of the table is an instance of a general condition on the parameters (monotonicity and
heredity of the cap sequence, the range conditions on `ξ₁, ξ₂, ξ₃`, the dominant Type II wall),
the general statement is proved rather than the single numerical instance.
-/

set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace SmallGaps

namespace Params

/-! ## Table 3: the exact parameter datum -/

/-- The number of shifts. -/
def k : ℕ := 45

/-- The parameter `ω`. -/
def omegaP : ℚ := 7 / 1000

/-- The parameter `A₀`. -/
def A0 : ℚ := -1 / 125

/-- The parameter `A₁`. -/
def A1 : ℚ := 257 / 1000

/-- The parameter `ε_s`. -/
def epsS : ℚ := 1 / 125

/-- The rough threshold `δ` in physical coordinates. -/
def delta : ℚ := 41 / 2500

/-- The parameter `ε_a`. -/
def epsA : ℚ := 1 / 10 ^ 10

/-- The parameters `ξ₁, ξ₂, ξ₃`. -/
def xi1 : ℚ := 19 / 50
def xi2 : ℚ := 2 / 5
def xi3 : ℚ := 2 / 5

/-- The cap sequence `B_{1,m}` of Table 3, with `B_{1,0} = 0` and `B_{1,m} = 1081/5000`
for `m ≥ 10`. -/
def B : ℕ → ℚ
  | 0 => 0
  | 1 => 777 / 5000
  | 2 => 794 / 5000
  | 3 => 875 / 5000
  | 4 => 917 / 5000
  | 5 => 953 / 5000
  | 6 => 983 / 5000
  | 7 => 1016 / 5000
  | 8 => 1042 / 5000
  | 9 => 1063 / 5000
  | _ => 1081 / 5000

/-- The rescaled cap function `C(m) = 4 B_{1,m}`. -/
def C (m : ℕ) : ℚ := 4 * B m

/-- The rescaled rough threshold `g = 4δ`. -/
def g : ℚ := 41 / 625

/-- The rescaled total-mass bound `L = 4(A₁ + ε_s)`. -/
def L : ℚ := 53 / 50

/-- The rescaled marginal cutoff `τ = 4(A₁ - ε_s)`. -/
def tau : ℚ := 249 / 250

/-! ## The rescaling dictionary of Section 9.3 -/

theorem g_eq : g = 4 * delta := by norm_num [g, delta]

theorem L_eq : L = 4 * (A1 + epsS) := by norm_num [L, A1, epsS]

theorem tau_eq : tau = 4 * (A1 - epsS) := by norm_num [tau, A1, epsS]

theorem physical_total_mass : A1 + epsS = 53 / 200 := by norm_num [A1, epsS]

theorem physical_marginal_cutoff : A1 - epsS = 249 / 1000 := by norm_num [A1, epsS]

/-- The first rescaled cap. (Note: the parenthetical values `C(1) = C(2) = 31/50` and
`C(s) = 17/25` quoted inside the proof of Lemma 9.1 belong to the two-cap support of
[Sta26]; for the cap sequence of Table 3 used here the rescaled caps are the ones computed
here and in `C_stable` below.) -/
theorem C_one : C 1 = 777 / 1250 := by norm_num [C, B]

theorem C_two : C 2 = 397 / 625 := by norm_num [C, B]

/-- The rescaled cap is eventually constant equal to `1081/1250`, as recorded in Table 3. -/
theorem C_stable (m : ℕ) (hm : 10 ≤ m) : C m = 1081 / 1250 := by
  have hB : B m = 1081 / 5000 := by
    match m, hm with
    | (n + 10), _ => rfl
  rw [C, hB]; norm_num

/-! ## Table 6: support conditions -/

/-- Support: `δ > 0`. -/
theorem delta_pos : (0 : ℚ) < delta := by norm_num [delta]

/-- Support: `B₁ > δ`, with slack `139/1000`. -/
theorem B_one_gt_delta : B 1 - delta = 139 / 1000 := by norm_num [B, delta]

/-- Support: the cap sequence is nondecreasing. -/
theorem B_mono : Monotone B := by
  refine monotone_nat_of_le_succ ?_
  intro n
  match n with
  | 0 => norm_num [B]
  | 1 => norm_num [B]
  | 2 => norm_num [B]
  | 3 => norm_num [B]
  | 4 => norm_num [B]
  | 5 => norm_num [B]
  | 6 => norm_num [B]
  | 7 => norm_num [B]
  | 8 => norm_num [B]
  | (n + 9) => cases n with
    | zero => norm_num [B]
    | succ m => show B (m + 10) ≤ B (m + 11); rfl

/-- Support (heredity): `B_{m+1} ≤ B_m + δ` for every `m ≥ 1`; the extreme case is
`B₃ - B₂ = 81/5000 ≤ 82/5000 = δ`. -/
theorem B_heredity (m : ℕ) (hm : 1 ≤ m) : B (m + 1) ≤ B m + delta := by
  match m, hm with
  | 1, _ => norm_num [B, delta]
  | 2, _ => norm_num [B, delta]
  | 3, _ => norm_num [B, delta]
  | 4, _ => norm_num [B, delta]
  | 5, _ => norm_num [B, delta]
  | 6, _ => norm_num [B, delta]
  | 7, _ => norm_num [B, delta]
  | 8, _ => norm_num [B, delta]
  | 9, _ => norm_num [B, delta]
  | (n + 10), _ =>
      have h : B (n + 11) = B (n + 10) := rfl
      rw [h]
      have : (0 : ℚ) ≤ delta := le_of_lt delta_pos
      linarith

/-- Table 4, "Definition 1": `B₃ ≤ B₂ + δ`, i.e. `7/40 ≤ 438/2500`, with slack `1/5000`. -/
theorem table4_B3_le_B2_add_delta : B 3 + 1 / 5000 = B 2 + delta := by
  norm_num [B, delta]

/-- First-rung cap wall: `777/5000 ≤ 778/5000`, with slack `1/5000`. -/
theorem first_rung_cap_wall : B 1 + 1 / 5000 = 778 / 5000 := by norm_num [B]

/-! ## Table 6: the direct-prime decomposition -/

/-- Prime decomposition: `ξ₂ ≤ 2/5` (equality). -/
theorem xi2_le : xi2 ≤ 2 / 5 := by norm_num [xi2]

/-- Prime decomposition: `ξ₃ ≥ ξ₂` (equality). -/
theorem xi3_ge_xi2 : xi2 ≤ xi3 := by norm_num [xi2, xi3]

/-- Harman decomposition: `2ξ₁ + 3ξ₂ < 2`, with slack `1/25`. -/
theorem harman_1 : 2 * xi1 + 3 * xi2 + 1 / 25 = 2 := by norm_num [xi1, xi2]

/-- Harman decomposition: `ξ₁ + 9ξ₂ < 4`, with slack `1/50`. -/
theorem harman_2 : xi1 + 9 * xi2 + 1 / 50 = 4 := by norm_num [xi1, xi2]

/-- Harman decomposition: `2ξ₁ + ξ₂ > 1`, with slack `4/25`. -/
theorem harman_3 : 1 + 4 / 25 = 2 * xi1 + xi2 := by norm_num [xi1, xi2]

/-- Harman decomposition: `17ξ₂ < 7`, with slack `1/5`. -/
theorem harman_4 : 17 * xi2 + 1 / 5 = 7 := by norm_num [xi2]

/-- The zero-loss window for `ξ₁`, `2833/7500 < ξ₁ < 2/5`, is respected. -/
theorem xi1_window : 2833 / 7500 < xi1 ∧ xi1 < 2 / 5 := by
  constructor <;> norm_num [xi1]

/-! ## Table 6: analytic range conditions -/

/-- Type I admissibility, first wall: `δ ≤ 279999997/15000000000`,
with slack `33999997/15000000000`. -/
theorem typeI_first_wall : delta + 33999997 / 15000000000 = 279999997 / 15000000000 := by
  norm_num [delta]

/-- Type I admissibility, second wall: `δ ≤ 1309999993/35000000000`,
with slack `735999993/35000000000`. -/
theorem typeI_second_wall : delta + 735999993 / 35000000000 = 1309999993 / 35000000000 := by
  norm_num [delta]

/-- Type II admissibility, first wall: `0 ≤ 69599997/2000000000`. -/
theorem typeII_first_wall : (0 : ℚ) < 69599997 / 2000000000 := by norm_num

/-- Type II admissibility, first cap wall: `δ ≤ 87999999/5000000000`,
with slack `5999999/5000000000`. -/
theorem typeII_first_cap_wall : delta + 5999999 / 5000000000 = 87999999 / 5000000000 := by
  norm_num [delta]

/-- Type II admissibility, second cap wall: `δ ≤ 82499999/5000000000`,
with slack `499999/5000000000`. -/
theorem typeII_second_cap_wall : delta + 499999 / 5000000000 = 82499999 / 5000000000 := by
  norm_num [delta]

/-- Type III admissibility: `δ ≤ 127499999/5000000000`, with slack `45499999/5000000000`. -/
theorem typeIII_wall : delta + 45499999 / 5000000000 = 127499999 / 5000000000 := by
  norm_num [delta]

/-- The dominant Type II wall of Section 9.2: `δ < ξ₂/4 + 11/16 - 3A₁ - 2ε_a`, in the
orientation `3A₁ + δ + 2ε_a ≤ ξ₂/4 + 11/16`, with slack `499999/5000000000`. -/
theorem dominant_typeII_wall :
    3 * A1 + delta + 2 * epsA + 499999 / 5000000000 = xi2 / 4 + 11 / 16 := by
  norm_num [A1, delta, epsA, xi2]

/-- The dominant Type II wall in the numerical form of Table 4:
`3937000001/5000000000 ≤ 63/80`. -/
theorem dominant_typeII_wall_numeric :
    3 * A1 + delta + 2 * epsA = 3937000001 / 5000000000 ∧ xi2 / 4 + 11 / 16 = 63 / 80 := by
  constructor <;> norm_num [A1, delta, epsA, xi2]

/-- Section 9.2: the chosen point lies `10⁻⁴` inside the zero-loss frontier. -/
theorem inside_zero_loss_frontier : 3 * A1 + delta = 63 / 80 - 1 / 10000 := by
  norm_num [A1, delta]

/-! ## Table 6: the transition through `x^{1/2}` -/

/-- Half-level transition, third bin: `11/400000000000 ≤ 109/1000000000000`,
with slack `163/2000000000000`. -/
theorem transition_third_bin :
    (11 : ℚ) / 400000000000 + 163 / 2000000000000 = 109 / 1000000000000 := by
  norm_num

/-- Half-level transition, fourth bin: equality `11/200000000000 = 11/200000000000`. -/
theorem transition_fourth_bin :
    (11 : ℚ) / 200000000000 = 11 / 200000000000 := rfl

/-- Exact packing roots A–E: `455 = 455`. -/
theorem packing_roots : (455 : ℚ) = 455 := rfl

end Params

end SmallGaps
