import Mathlib

/-!
# Admissible tuples and the tuple `H45`

This file formalizes the notion of an *admissible* tuple of shifts (Section 2 of the paper)
and Lemma 12.1: the explicit set `H45` is an admissible 45-tuple of diameter 212.
-/

open scoped BigOperators
open scoped Classical

set_option autoImplicit false
set_option relaxedAutoImplicit false
set_option maxRecDepth 100000

namespace SmallGaps

/-- A finite set `H` of natural numbers is *admissible* if, for every prime `p`,
the elements of `H` omit at least one residue class modulo `p`. -/
def Admissible (H : Finset ℕ) : Prop :=
  ∀ p : ℕ, p.Prime → ∃ a : ℕ, ∀ h ∈ H, h % p ≠ a % p

/-- The diameter of a nonempty finite set of shifts: largest element minus smallest element. -/
def diameter (H : Finset ℕ) (hH : H.Nonempty) : ℕ := H.max' hH - H.min' hH

/-- If `H` has fewer elements than the prime `p`, then some residue class mod `p` is omitted. -/
theorem admissible_of_card_lt {H : Finset ℕ} {p : ℕ} (hp : 0 < p) (hcard : H.card < p) :
    ∃ a : ℕ, ∀ h ∈ H, h % p ≠ a % p := by
  classical
  set S : Finset ℕ := H.image (fun h => h % p) with hS
  have hSsub : S ⊆ Finset.range p := by
    intro x hx
    simp only [hS, Finset.mem_image] at hx
    obtain ⟨h, _, rfl⟩ := hx
    exact Finset.mem_range.2 (Nat.mod_lt _ hp)
  have hScard : S.card < (Finset.range p).card := by
    have : S.card ≤ H.card := Finset.card_image_le
    simpa using lt_of_le_of_lt this hcard
  have hex : ∃ a ∈ Finset.range p, a ∉ S := by
    by_contra hcon
    push_neg at hcon
    exact absurd (Finset.card_le_card hcon) (not_le.2 hScard)
  obtain ⟨a, ha, haS⟩ := hex
  refine ⟨a, ?_⟩
  intro h hh hEq
  apply haS
  have hmod : a % p = a := Nat.mod_eq_of_lt (Finset.mem_range.1 ha)
  rw [hmod] at hEq
  simp only [hS, Finset.mem_image]
  exact ⟨h, hh, hEq⟩

/-- The list of shifts of the 45-tuple `H45` used in Section 12. -/
def H45list : List ℕ :=
  [0, 2, 12, 14, 24, 26, 30, 36, 44, 50, 54, 56, 60, 66, 72, 74, 80, 84, 92, 96, 102, 110, 114,
   116, 122, 126, 134, 140, 144, 150, 156, 162, 164, 170, 176, 180, 182, 186, 192, 194,
   200, 204, 206, 210, 212]

/-- The 45-tuple `H45` of Section 12 of the paper. -/
def H45 : Finset ℕ := H45list.toFinset

theorem H45_nonempty : H45.Nonempty := by decide

theorem H45_card : H45.card = 45 := by rfl

theorem H45_min : H45.min' H45_nonempty = 0 := by decide

theorem H45_max : H45.max' H45_nonempty = 212 := by decide

theorem H45_diameter : diameter H45 H45_nonempty = 212 := by
  rw [diameter, H45_min, H45_max]

/-- For each prime `p ≤ 43`, the residue class that `H45` omits (Lemma 12.1). -/
def omittedResidue : ℕ → ℕ
  | 2 => 1
  | 3 => 1
  | 5 => 3
  | 7 => 6
  | 11 => 9
  | 13 => 3
  | 17 => 1
  | 19 => 13
  | 23 => 17
  | 29 => 4
  | 31 => 11
  | 37 => 4
  | 41 => 4
  | 43 => 3
  | _ => 0

theorem H45_omits_small (p : ℕ) (hp : p.Prime) (hle : p ≤ 43) :
    ∀ h ∈ H45, h % p ≠ omittedResidue p % p := by
  revert hp
  interval_cases p <;> decide

/-- **Lemma 12.1.** `H45` is admissible. -/
theorem H45_admissible : Admissible H45 := by
  intro p hp
  by_cases hle : p ≤ 43
  · exact ⟨omittedResidue p, H45_omits_small p hp hle⟩
  · refine admissible_of_card_lt hp.pos ?_
    rw [H45_card]
    have h44 : 44 ≤ p := by omega
    rcases Nat.lt_or_ge 45 p with h | h
    · exact h
    · revert hp
      interval_cases p <;> decide

end SmallGaps
