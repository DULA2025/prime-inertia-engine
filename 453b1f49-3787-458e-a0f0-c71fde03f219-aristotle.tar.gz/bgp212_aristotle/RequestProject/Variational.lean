import Mathlib

/-!
# The variational threshold

Two elementary steps of the variational half of the argument are recorded here.

* `rescaling_threshold` is the computation of Section 9.3: after the dilation by `4`, which
  multiplies `I` by `4^{-k}` and each marginal `J` by `4^{-(k+1)}`, the physical sieve
  criterion `k J(F) > I(F)` becomes the rescaled criterion `k J(F̃) > 4 I(F̃)`; equivalently
  the Rayleigh quotient is divided by `4`, so the physical threshold `1` is the rescaled
  threshold `4`.
* `rayleigh_gt_four` is the final step of the proof of Theorem 11.1: from `I > 0` and
  `J - 4I > 0` one gets `J / I > 4`.

The exact rational coefficient vector of the certificate polynomial `P⋆` is not reproduced in
the paper, so the numerical inequality `J(F⋆) - 4 I(F⋆) > 0` itself is not verified here.
-/

set_option autoImplicit false
set_option relaxedAutoImplicit false

namespace SmallGaps

namespace Variational

/-- **Section 9.3.** If `I(F) = 4^{-k} I(F̃)` and `J(F) = 4^{-(k+1)} J(F̃)`, then the Rayleigh
quotient in physical coordinates is a quarter of the rescaled one. -/
theorem rescaling_quotient {k : ℕ} {IF IFt JF JFt : ℝ} (hIt : IFt ≠ 0)
    (hI : IF = IFt / 4 ^ k) (hJ : JF = JFt / 4 ^ (k + 1)) :
    k * JF / IF = (k * JFt / IFt) / 4 := by
  have h4 : ((4 : ℝ) ^ k) ≠ 0 := by positivity
  subst hI hJ
  field_simp
  ring

/-- **Section 9.3.** With the same dilation dictionary, the physical sieve criterion
`k J(F) > I(F)` is exactly the rescaled criterion `k J(F̃) > 4 I(F̃)`. -/
theorem rescaling_threshold {k : ℕ} {IF IFt JF JFt : ℝ}
    (hI : IF = IFt / 4 ^ k) (hJ : JF = JFt / 4 ^ (k + 1)) :
    (IF < k * JF) ↔ (4 * IFt < k * JFt) := by
  have h4 : (0 : ℝ) < 4 ^ k := by positivity
  subst hI hJ
  have key : (k : ℝ) * (JFt / 4 ^ (k + 1)) = ((k : ℝ) * JFt) / (4 ^ k * 4) := by
    rw [pow_succ]; ring
  rw [key, div_lt_div_iff₀ h4 (by positivity)]
  constructor <;> intro h <;> nlinarith [h4]

/-- **Theorem 11.1, final step.** If `I > 0` and `J - 4I > 0`, then `J / I > 4`. -/
theorem rayleigh_gt_four {I J : ℝ} (hI : 0 < I) (h : 0 < J - 4 * I) : 4 < J / I := by
  rw [lt_div_iff₀ hI]
  linarith

end Variational

end SmallGaps
