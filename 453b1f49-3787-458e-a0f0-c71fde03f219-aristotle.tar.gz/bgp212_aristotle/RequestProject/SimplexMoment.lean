import Mathlib

/-!
# The simplex moment identity

This file proves the identity (10.1) of the paper, the elementary evaluation on which the
exact rational evaluation of the variational integrals rests:
`∫_{z ≥ 0, ∑ zᵢ ≤ R} ∏ zᵢ^{eᵢ} dz = R^{m + ∑ eᵢ} ∏ (eᵢ)! / (m + ∑ eᵢ)!`.
-/

open scoped BigOperators
open MeasureTheory

set_option autoImplicit false
set_option relaxedAutoImplicit false
set_option maxHeartbeats 1000000

namespace SmallGaps

/-- The simplex `{z : 0 ≤ zᵢ, ∑ zᵢ ≤ R}` in `ℝ^m`. -/
def simplexSet (m : ℕ) (R : ℝ) : Set (Fin m → ℝ) := {z | (∀ i, 0 ≤ z i) ∧ ∑ i, z i ≤ R}

theorem isClosed_simplexSet (m : ℕ) (R : ℝ) : IsClosed (simplexSet m R) := by
  have h1 : IsClosed {z : Fin m → ℝ | ∀ i, 0 ≤ z i} := by
    simpa only [Set.setOf_forall] using
      isClosed_iInter (fun i : Fin m =>
        isClosed_le continuous_const (continuous_apply (A := fun _ : Fin m => ℝ) i))
  have h2 : IsClosed {z : Fin m → ℝ | ∑ i, z i ≤ R} :=
    isClosed_le (continuous_finset_sum _ (fun i _ => continuous_apply i)) continuous_const
  exact h1.inter h2

theorem measurableSet_simplexSet (m : ℕ) (R : ℝ) : MeasurableSet (simplexSet m R) :=
  (isClosed_simplexSet m R).measurableSet

theorem simplexSet_subset_box {m : ℕ} {R : ℝ} :
    simplexSet m R ⊆ Set.Icc (fun _ => (0 : ℝ)) (fun _ => R) := by
  rintro z ⟨hnn, hsum⟩
  refine ⟨fun i => hnn i, fun i => ?_⟩
  have hle : z i ≤ ∑ j, z j :=
    Finset.single_le_sum (f := z) (fun j _ => hnn j) (Finset.mem_univ i)
  linarith

theorem isCompact_simplexSet (m : ℕ) (R : ℝ) : IsCompact (simplexSet m R) :=
  (isCompact_Icc (a := fun _ => (0 : ℝ)) (b := fun _ => R)).of_isClosed_subset
    (isClosed_simplexSet m R) simplexSet_subset_box

theorem simplexSet_of_neg {m : ℕ} {R : ℝ} (hR : R < 0) : simplexSet (m + 1) R = ∅ := by
  ext z
  simp only [simplexSet, Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false, not_and]
  intro hnn
  have : (0 : ℝ) ≤ ∑ i, z i := Finset.sum_nonneg (fun i _ => hnn i)
  linarith

/-- The one-dimensional Beta-type integral `∫₀^R u^a (R-u)^b du`. -/
theorem integral_pow_mul_sub_pow : ∀ (b a : ℕ) {R : ℝ}, 0 ≤ R →
    (∫ u in (0 : ℝ)..R, u ^ a * (R - u) ^ b)
      = R ^ (a + b + 1) * (a.factorial * b.factorial : ℝ) / (a + b + 1).factorial := by
  intro b
  induction b with
  | zero =>
    intro a R _
    simp only [pow_zero, mul_one, Nat.factorial_zero, Nat.cast_one]
    rw [integral_pow]
    simp only [Nat.add_zero]
    rw [Nat.factorial_succ]
    push_cast
    field_simp
    ring
  | succ b ih =>
    intro a R hR
    have hu : ∀ x ∈ Set.uIcc (0:ℝ) R, HasDerivAt (fun x : ℝ => (R - x) ^ (b+1))
        (-((b+1 : ℕ) * (R - x) ^ b)) x := by
      intro x _
      have h1 : HasDerivAt (fun x : ℝ => R - x) (-1) x := by
        simpa using (hasDerivAt_id x).const_sub R
      have h2 := h1.pow (b+1)
      simpa [mul_comm, mul_assoc, mul_left_comm] using h2
    have hv : ∀ x ∈ Set.uIcc (0:ℝ) R, HasDerivAt (fun x : ℝ => x ^ (a+1) / (a+1))
        (x ^ a) x := by
      intro x _
      have h2 : HasDerivAt (fun x : ℝ => x ^ (a+1) / ((a:ℝ)+1))
          (((a+1 : ℕ) * x ^ a) / ((a:ℝ)+1)) x := (hasDerivAt_pow (a+1) x).div_const _
      have hne : ((a:ℝ)+1) ≠ 0 := by positivity
      convert h2 using 1
      push_cast
      field_simp
    have hint1 : IntervalIntegrable (fun x : ℝ => -((b+1 : ℕ) * (R - x) ^ b)) volume 0 R := by
      apply Continuous.intervalIntegrable; fun_prop
    have hint2 : IntervalIntegrable (fun x : ℝ => x ^ a) volume 0 R := by
      apply Continuous.intervalIntegrable; fun_prop
    have key := intervalIntegral.integral_mul_deriv_eq_deriv_mul hu hv hint1 hint2
    have h0 : (0:ℝ) ^ (a+1) = 0 := zero_pow (Nat.succ_ne_zero a)
    simp only [sub_self, zero_pow (Nat.succ_ne_zero b), zero_mul, zero_sub, sub_zero, h0,
      zero_div, mul_zero] at key
    have hne : ((a:ℝ)+1) ≠ 0 := by positivity
    have step : (∫ x in (0:ℝ)..R, -(((b:ℕ)+1 : ℕ) * (R - x) ^ b) * (x ^ (a + 1) / ((a:ℝ) + 1)))
        = -((((b:ℝ)+1))/((a:ℝ)+1)) * ∫ x in (0:ℝ)..R, x ^ (a+1) * (R - x) ^ b := by
      rw [← intervalIntegral.integral_const_mul]
      apply intervalIntegral.integral_congr
      intro x _
      push_cast
      field_simp
    have hcomm : (∫ u in (0:ℝ)..R, u ^ a * (R - u) ^ (b+1))
        = ∫ x in (0:ℝ)..R, (R - x) ^ (b+1) * x ^ a := by
      apply intervalIntegral.integral_congr
      intro x _
      ring
    rw [hcomm, key, step, ih (a+1) hR]
    have hfa : (a.factorial : ℝ) ≠ 0 := Nat.cast_ne_zero.2 (Nat.factorial_ne_zero a)
    have hfb : (b.factorial : ℝ) ≠ 0 := Nat.cast_ne_zero.2 (Nat.factorial_ne_zero b)
    have hf1 : ((a + 1 + b + 1).factorial : ℝ) ≠ 0 :=
      Nat.cast_ne_zero.2 (Nat.factorial_ne_zero _)
    have e1 : a + (b+1) + 1 = a + 1 + b + 1 := by ring
    rw [e1, Nat.factorial_succ a, Nat.factorial_succ b]
    push_cast
    field_simp

theorem continuous_monomial (m : ℕ) (e : Fin m → ℕ) :
    Continuous (fun z : Fin m → ℝ => ∏ i, z i ^ e i) := by
  fun_prop

theorem integrableOn_simplexSet (m : ℕ) (e : Fin m → ℕ) (R : ℝ) :
    IntegrableOn (fun z : Fin m → ℝ => ∏ i, z i ^ e i) (simplexSet m R) volume :=
  ContinuousOn.integrableOn_compact (isCompact_simplexSet m R)
    (continuous_monomial m e).continuousOn

theorem integrable_indicator_simplexSet (m : ℕ) (e : Fin m → ℕ) (R : ℝ) :
    Integrable ((simplexSet m R).indicator (fun z : Fin m → ℝ => ∏ i, z i ^ e i)) volume :=
  (integrableOn_simplexSet m e R).integrable_indicator (measurableSet_simplexSet m R)

/-- Membership of `Fin.cons u z` in the `(m+1)`-dimensional simplex. -/
theorem cons_mem_simplexSet_iff {m : ℕ} {R u : ℝ} {z : Fin m → ℝ} :
    (Fin.cons u z : Fin (m + 1) → ℝ) ∈ simplexSet (m + 1) R ↔
      0 ≤ u ∧ z ∈ simplexSet m (R - u) := by
  simp only [simplexSet, Set.mem_setOf_eq, Fin.sum_univ_succ, Fin.cons_zero, Fin.cons_succ]
  constructor
  · rintro ⟨hnn, hsum⟩
    refine ⟨by simpa using hnn 0, fun j => by simpa using hnn j.succ, by linarith⟩
  · rintro ⟨hu, hnn, hsum⟩
    refine ⟨fun i => ?_, by linarith⟩
    refine Fin.cases ?_ ?_ i
    · simpa using hu
    · intro j; simpa using hnn j

/-- **The simplex moment identity (10.1).** -/
theorem simplex_moment : ∀ (m : ℕ) (e : Fin m → ℕ) {R : ℝ}, 0 ≤ R →
    (∫ z in simplexSet m R, ∏ i, z i ^ e i)
      = R ^ (m + ∑ i, e i) * (∏ i, (e i).factorial : ℝ) / (m + ∑ i, e i).factorial := by
  intro m
  induction m with
  | zero =>
    intro e R hR
    have hset : simplexSet 0 R = Set.univ := by
      ext z
      simp [simplexSet, hR, Subsingleton.elim z 0]
    simp only [hset, Measure.restrict_univ, Finset.univ_eq_empty, Finset.prod_empty,
      Finset.sum_empty, integral_const, smul_eq_mul, mul_one, Nat.add_zero, pow_zero,
      Nat.factorial_zero, Nat.cast_one, div_one]
    simp [Measure.real, volume_pi]
  | succ m ih =>
    intro e R hR
    classical
    set f : (Fin (m + 1) → ℝ) → ℝ := fun x => ∏ i, x i ^ e i with hf
    set S : Set (Fin (m + 1) → ℝ) := simplexSet (m + 1) R with hS
    have hmeas : MeasurableSet S := measurableSet_simplexSet _ _
    have hFint : Integrable (S.indicator f) volume := integrable_indicator_simplexSet _ _ _
    have hsymm : ⇑(MeasurableEquiv.piFinSuccAbove (fun _ : Fin (m + 1) => ℝ) 0).symm
        = fun p : ℝ × (Fin m → ℝ) => (Fin.cons p.1 p.2 : Fin (m + 1) → ℝ) := by
      funext p
      simp [MeasurableEquiv.piFinSuccAbove, Fin.consEquiv]
    have hMP : MeasurePreserving
        (fun p : ℝ × (Fin m → ℝ) => (Fin.cons p.1 p.2 : Fin (m + 1) → ℝ)) volume volume := by
      have h := (volume_preserving_piFinSuccAbove (fun _ : Fin (m + 1) => ℝ) 0).symm
        (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (m + 1) => ℝ) 0)
      rwa [hsymm] at h
    have hemb : MeasurableEmbedding
        (fun p : ℝ × (Fin m → ℝ) => (Fin.cons p.1 p.2 : Fin (m + 1) → ℝ)) := by
      have h := (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (m + 1) => ℝ) 0).symm.measurableEmbedding
      rwa [hsymm] at h
    have h1 : (∫ z in S, f z) = ∫ p : ℝ × (Fin m → ℝ), S.indicator f (Fin.cons p.1 p.2) := by
      rw [← integral_indicator hmeas]
      exact (hMP.integral_comp hemb _).symm
    have hGint : Integrable
        (fun p : ℝ × (Fin m → ℝ) => S.indicator f (Fin.cons p.1 p.2)) volume :=
      (hMP.integrable_comp_emb hemb).2 hFint
    have h2 : (∫ p : ℝ × (Fin m → ℝ), S.indicator f (Fin.cons p.1 p.2))
        = ∫ u : ℝ, ∫ z : Fin m → ℝ, S.indicator f (Fin.cons u z) := by
      rw [Measure.volume_eq_prod]
      exact integral_prod _ (by rwa [← Measure.volume_eq_prod])
    -- the inner integral
    have hinner : ∀ u : ℝ, (∫ z : Fin m → ℝ, S.indicator f (Fin.cons u z))
        = Set.indicator (Set.Icc (0 : ℝ) R)
            (fun u => u ^ e 0 * ((R - u) ^ (m + ∑ j : Fin m, e j.succ)
              * (∏ j : Fin m, ((e j.succ).factorial : ℝ)) / ((m + ∑ j : Fin m, e j.succ).factorial))) u := by
      intro u
      by_cases hu0 : 0 ≤ u
      · by_cases huR : u ≤ R
        · have hz : ∀ z : Fin m → ℝ, S.indicator f (Fin.cons u z)
              = (simplexSet m (R - u)).indicator
                  (fun z : Fin m → ℝ => u ^ e 0 * ∏ j : Fin m, z j ^ e j.succ) z := by
            intro z
            by_cases hmem : z ∈ simplexSet m (R - u)
            · rw [Set.indicator_of_mem (cons_mem_simplexSet_iff.2 ⟨hu0, hmem⟩),
                Set.indicator_of_mem hmem, hf]
              simp [Fin.prod_univ_succ]
            · rw [Set.indicator_of_notMem, Set.indicator_of_notMem hmem]
              intro hcon
              exact hmem (cons_mem_simplexSet_iff.1 hcon).2
          simp_rw [hz]
          rw [integral_indicator (measurableSet_simplexSet _ _), integral_const_mul,
            ih (fun j => e j.succ) (by linarith : (0:ℝ) ≤ R - u),
            Set.indicator_of_mem (Set.mem_Icc.2 ⟨hu0, huR⟩)]
        · have hzero : ∀ z : Fin m → ℝ, S.indicator f (Fin.cons u z) = 0 := by
            intro z
            refine Set.indicator_of_notMem ?_ _
            intro hcon
            obtain ⟨-, hmem⟩ := cons_mem_simplexSet_iff.1 hcon
            have hnn : (0:ℝ) ≤ ∑ j, z j := Finset.sum_nonneg (fun j _ => hmem.1 j)
            have := hmem.2
            linarith [not_le.1 huR]
          simp_rw [hzero]
          rw [integral_zero, Set.indicator_of_notMem]
          simp only [Set.mem_Icc, not_and, not_le]
          intro _
          exact not_le.1 huR
      · have hzero : ∀ z : Fin m → ℝ, S.indicator f (Fin.cons u z) = 0 := by
          intro z
          refine Set.indicator_of_notMem ?_ _
          intro hcon
          exact hu0 (cons_mem_simplexSet_iff.1 hcon).1
        simp_rw [hzero]
        rw [integral_zero, Set.indicator_of_notMem]
        simp only [Set.mem_Icc, not_and, not_le]
        intro h
        exact absurd h hu0
    rw [h1, h2]
    simp_rw [hinner]
    rw [integral_indicator measurableSet_Icc, MeasureTheory.integral_Icc_eq_integral_Ioc,
      ← intervalIntegral.integral_of_le hR]
    have hconst : (∫ u in (0:ℝ)..R, u ^ e 0 * ((R - u) ^ (m + ∑ j : Fin m, e j.succ)
          * (∏ j : Fin m, ((e j.succ).factorial : ℝ)) / ((m + ∑ j : Fin m, e j.succ).factorial)))
        = (∫ u in (0:ℝ)..R, u ^ e 0 * (R - u) ^ (m + ∑ j : Fin m, e j.succ))
          * ((∏ j : Fin m, ((e j.succ).factorial : ℝ)) / ((m + ∑ j : Fin m, e j.succ).factorial)) := by
      rw [← intervalIntegral.integral_mul_const]
      apply intervalIntegral.integral_congr
      intro x _
      ring
    rw [hconst, integral_pow_mul_sub_pow _ _ hR]
    have hsum : ∑ i, e i = e 0 + ∑ j : Fin m, e j.succ := Fin.sum_univ_succ e
    have hprod : (∏ i, ((e i).factorial : ℝ)) = (e 0).factorial * ∏ j : Fin m, ((e j.succ).factorial : ℝ) :=
      Fin.prod_univ_succ (fun i => ((e i).factorial : ℝ))
    have hfac1 : (((m + ∑ j : Fin m, e j.succ).factorial : ℝ)) ≠ 0 :=
      Nat.cast_ne_zero.2 (Nat.factorial_ne_zero _)
    have hfac2 : (((e 0 + (m + ∑ j : Fin m, e j.succ) + 1).factorial : ℝ)) ≠ 0 :=
      Nat.cast_ne_zero.2 (Nat.factorial_ne_zero _)
    have hexp : m + 1 + ∑ i, e i = e 0 + (m + ∑ j : Fin m, e j.succ) + 1 := by
      rw [hsum]; ring
    rw [hexp, hprod]
    field_simp

/-- The volume of the simplex `{z ≥ 0, ∑ zᵢ ≤ R}` is `R^m / m!`. -/
theorem volume_simplexSet (m : ℕ) {R : ℝ} (hR : 0 ≤ R) :
    (volume (simplexSet m R)).toReal = R ^ m / m.factorial := by
  have h := simplex_moment m (fun _ => 0) hR
  simp only [pow_zero, Finset.prod_const_one, Finset.sum_const, smul_eq_mul, mul_zero,
    Nat.add_zero, Nat.factorial_zero, Nat.cast_one, integral_const, smul_eq_mul, mul_one,
    ] at h
  simpa [Measure.real] using h

/-- Moments of an arbitrary polynomial (written as a finite combination of monomials) over the
simplex. -/
theorem simplex_polynomial_moment {ι : Type*} (m : ℕ) (s : Finset ι) (c : ι → ℝ)
    (E : ι → Fin m → ℕ) {R : ℝ} (hR : 0 ≤ R) :
    (∫ z in simplexSet m R, ∑ k ∈ s, c k * ∏ i, z i ^ E k i)
      = ∑ k ∈ s, c k * (R ^ (m + ∑ i, E k i) * (∏ i, ((E k i).factorial : ℝ))
          / ((m + ∑ i, E k i).factorial)) := by
  rw [integral_finset_sum]
  · refine Finset.sum_congr rfl (fun k _ => ?_)
    rw [integral_const_mul, simplex_moment m (E k) hR]
  · intro k _
    exact (integrableOn_simplexSet m (E k) R).const_mul _

/-- Every polynomial moment over a simplex of rational radius is rational: the case of
Lemma 10.1 that Section 10 applies. -/
theorem simplex_polynomial_moment_rat {ι : Type*} (m : ℕ) (s : Finset ι) (c : ι → ℚ)
    (E : ι → Fin m → ℕ) {r : ℚ} (hr : 0 ≤ r) :
    ∃ q : ℚ, (∫ z in simplexSet m (r : ℝ), ∑ k ∈ s, (c k : ℝ) * ∏ i, z i ^ E k i) = (q : ℝ) := by
  refine ⟨∑ k ∈ s, c k * (r ^ (m + ∑ i, E k i) * (∏ i, ((E k i).factorial : ℚ))
      / ((m + ∑ i, E k i).factorial)), ?_⟩
  rw [simplex_polynomial_moment m s (fun k => (c k : ℝ)) E
    (by exact_mod_cast hr : (0:ℝ) ≤ (r : ℝ))]
  push_cast
  ring

/-- **Lemma 10.1 for a simplex.** If the radius is rational, the moment is rational: this is
the rationality statement that Section 10 uses to reduce the variational integrals to exact
rational arithmetic. -/
theorem simplex_moment_rat (m : ℕ) (e : Fin m → ℕ) {r : ℚ} (hr : 0 ≤ r) :
    (∫ z in simplexSet m (r : ℝ), ∏ i, z i ^ e i)
      = ((r ^ (m + ∑ i, e i) * (∏ i, (e i).factorial : ℚ) / (m + ∑ i, e i).factorial : ℚ) : ℝ) := by
  rw [simplex_moment m e (by exact_mod_cast hr : (0:ℝ) ≤ (r : ℝ))]
  push_cast
  ring

end SmallGaps
