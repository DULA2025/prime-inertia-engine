import Mathlib
import RequestProject.Admissible
import RequestProject.Gaps
import RequestProject.Parameters
import RequestProject.Support
import RequestProject.SimplexMoment
import RequestProject.Transition
import RequestProject.Variational

/-!
# A new bound for small gaps between primes: formalized components

This project formalizes several self-contained components of the paper
*A new bound for small gaps between primes* (`bgp212.pdf`).

* `RequestProject/Admissible.lean` — admissible tuples, the explicit 45-tuple `H45`,
  and Lemma 12.1 (`H45` is admissible, has 45 elements and diameter 212).
* `RequestProject/Gaps.lean` — the statement `DHL[k, m]`, and the deduction of
  `H₁ = liminf (p_{n+1} - p_n) ≤ diameter H` from `DHL[k, 2]` and an admissible `k`-tuple `H`;
  specializing to `H45` gives Theorem 1.1, `H₁ ≤ 212`, conditional on `DHL[45, 2]`.
* `RequestProject/Parameters.lean` — the exact rational parameter datum of Table 3 and the
  verification, in exact rational arithmetic, of the slack ledger of Tables 4 and 6.
* `RequestProject/Support.lean` — the support of Section 9, Lemma 9.1 (dilation by 4) and
  Lemma 9.2 (the moving marginal endpoint).
* `RequestProject/SimplexMoment.lean` — the simplex moment identity (10.1), which underlies
  the exact rational evaluation of the variational integrals, together with the volume of a
  simplex and the rationality of its moments at a rational radius.
* `RequestProject/Transition.lean` — the transition window of Lemma 8.2.
* `RequestProject/Variational.lean` — the rescaling of the sieve threshold (Section 9.3) and
  the final step of Theorem 11.1.

The analytic inputs of Sections 5–8 and the variational certificate of Section 11 are not
formalized here; the gap bound is proved conditionally on `DHL[45, 2]`.
-/

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 20000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

namespace SmallGaps

/-- **Theorem 1.1** (conditional on the sieve statement `DHL[45, 2]`):
`H₁ = liminf (p_{n+1} - p_n) ≤ 212`. -/
theorem H1_le_212 (h : DHL 45 2) :
    Filter.liminf (fun i => (primeGap i : ℕ∞)) Filter.atTop ≤ 212 :=
  liminf_primeGap_le_212 h

end SmallGaps
