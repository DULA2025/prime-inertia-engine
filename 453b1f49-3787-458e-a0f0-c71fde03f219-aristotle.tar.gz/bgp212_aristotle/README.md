This project was edited by [Aristotle](https://aristotle.harmonic.fun).

To cite Aristotle:
- Tag @Aristotle-Harmonic on GitHub PRs/issues
- Add as co-author to commits:
```
Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
```

# Formalized components of *A new bound for small gaps between primes*

This Lean 4 / Mathlib project formalizes several self-contained components of the paper
`bgp212.pdf`, which proves `H₁ = liminf (p_{n+1} - p_n) ≤ 212`.

Everything in `RequestProject/` compiles with no `sorry` and uses only the standard axioms
(`propext`, `Classical.choice`, `Quot.sound`).

## Contents

| File | Content |
| --- | --- |
| `RequestProject/Admissible.lean` | Admissible tuples; the explicit 45-tuple `H45`; Lemma 12.1 (`H45` is admissible, has 45 elements, and has diameter 212). |
| `RequestProject/Gaps.lean` | The statement `DHL[k, m]`; the deduction `DHL[k,2]` + admissible `k`-tuple `H` ⟹ `H₁ ≤ diameter H`; Theorem 1.1 in the conditional form `DHL[45,2] ⟹ H₁ ≤ 212` (in `ℕ∞` and over `ℝ`). |
| `RequestProject/Parameters.lean` | The exact rational parameter datum of Table 3, the rescaling dictionary of Section 9.3, and exact rational verification of the slack ledger of Table 4 and Appendix B (Table 6). |
| `RequestProject/Support.lean` | The support of Section 9; the general dilation lemma and Lemma 9.1; Lemma 9.2 (the moving marginal endpoint `U(x̂) = min{L - S, max{g, C(s+1) - ρ₁}}`). |
| `RequestProject/SimplexMoment.lean` | The simplex moment identity (10.1), proved from a one-dimensional Beta-type integral by induction on the dimension; the volume of a simplex; rationality of monomial and polynomial moments at a rational radius (the case of Lemma 10.1 used in Section 10). |
| `RequestProject/Transition.lean` | Lemma 8.2: the transition window `|θ - 1/2| < η / L_leaf`. |
| `RequestProject/Variational.lean` | Section 9.3: the dilation turns the physical threshold `1` into the rescaled threshold `4`; the final step of Theorem 11.1. |
| `RequestProject/Main.lean` | Imports everything and states `H1_le_212`. |

## What is assumed

The analytic inputs of Sections 5–8 (the Type I/II/III equidistribution estimates,
Bombieri–Vinogradov, the Harman decomposition) and the numerical variational certificate of
Section 11 are **not** formalized. The prime-gap bound is therefore proved conditionally on the
sieve statement `DHL[45, 2]`; the admissibility and diameter of the 45-tuple, on which the
passage from `DHL[45,2]` to `H₁ ≤ 212` rests, are proved unconditionally, as are the
support geometry, the parameter ledger and the moment identity listed above.
