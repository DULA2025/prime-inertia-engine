/-
Copyright (c) 2026 Dula. All rights reserved.
Released under Apache 2.0 license.
-/
import Artin1951.SignLemma
import Artin1951.Statement

/-!
# Theorem A″ of the note, with its external inputs as hypotheses

Theorem A″: if `H1` holds for a quadratic field `E` and for a cyclic field `C` of odd prime degree
`ℓ`, then `ρ` is modular and `L(ρ, s)` is entire.

The proof in the note has three kinds of steps.
1. Automorphic inputs: Langlands' cyclic base change and its fibres, strong multiplicity one, the
   Rankin–Selberg pole (Jacquet–Shalika), and the local Langlands correspondence at unramified
   places.  With `H1` for `E` and `C` they give a cuspidal `π` on `GL₂(𝔸_ℚ)` and a finite set `S`
   of primes such that, for `p ∉ S`, with `{a, b}` the eigenvalues of `ρ(Frob_p)`:
   * (Lemma 3.2(b) and Step 1) the Satake parameter of `π_p` is `{a, b}` or `{-a, -b}`;
   * (Lemma 3.6(b)) it is `{a, b}` if `p` splits in `C`, and otherwise its `ℓ`-th powers are
     `{a^ℓ, b^ℓ}`.
2. Group theory: `b/a` is a root of unity whose order divides `2`, `3` or `5` (the projective
   image is `A₅`, `Artin1951.alternatingGroup_five_orders`).
3. Step 2: these force the Satake parameter of `π_p` to be `{a, b}` for every `p ∉ S`.  This is
   `Artin1951.stepTwo` below, proved with no `sorry`.
Finally (proof of Theorem A, last step) a cuspidal `π` corresponding to `ρ` makes `L(ρ, s)` entire.

Here the inputs of kinds 1 and 2 and the final analytic step are hypotheses of
`Artin1951.thmA2`; none is an axiom.  The theorem checks that they combine as the note says.
-/

namespace Artin1951

/-- Step 2 of the proof of Theorem A″, at the level of Satake parameters: if at every `p ∉ S`
the parameter `sat p` is `±(eig p)`, equals `eig p` when `p` splits in `C`, and otherwise has
the same `ℓ`-th powers as `eig p`, and the eigenvalue ratio has order dividing `2`, `3` or `5`,
then `sat p = eig p` for every `p ∉ S`. -/
theorem stepTwo {ℓ : ℕ} (hℓ : Odd ℓ) (S : Set ℕ) (splitsInC : ℕ → Prop)
    (sat eig : ℕ → Multiset ℂ)
    (hsign : ∀ p ∉ S, sat p = eig p ∨ sat p = (eig p).map Neg.neg)
    (hsplit : ∀ p ∉ S, splitsInC p → sat p = eig p)
    (hinert : ∀ p ∉ S, ¬ splitsInC p → (sat p).map (· ^ ℓ) = (eig p).map (· ^ ℓ))
    (heig : ∀ p ∉ S, ∃ a b : ℂ, eig p = {a, b} ∧ a ≠ 0 ∧
      (b / a = 1 ∨ (b / a) ^ 2 = 1 ∨ (b / a) ^ 3 = 1 ∨ (b / a) ^ 5 = 1)) :
    ∀ p ∉ S, sat p = eig p := by
  intro p hp
  by_cases hs : splitsInC p
  · exact hsplit p hp hs
  rcases hsign p hp with h | h
  · exact h
  obtain ⟨a, b, he, ha, hord⟩ := heig p hp
  have hpow := hinert p hp hs
  rw [h, he] at hpow
  -- `{(-a)^ℓ, (-b)^ℓ} = {a^ℓ, b^ℓ}`, and `(-x)^ℓ = -(x^ℓ)` as `ℓ` is odd
  have hms : ({-(a ^ ℓ), -(b ^ ℓ)} : Multiset ℂ) = {a ^ ℓ, b ^ ℓ} := by
    simpa [Multiset.insert_eq_cons, Multiset.map_cons, Multiset.map_singleton, hℓ.neg_pow] using hpow
  have hab : a + b = 0 := sign_core hℓ ha hord hms
  have hb : b = -a := by linear_combination hab
  rw [h, he, hb]
  simp [Multiset.insert_eq_cons, Multiset.map_cons, Multiset.map_singleton]
  exact Multiset.cons_swap (-a) a 0

/-- The eigenvalues of `ρ(Frob_p)` (for the chosen prime above `p` and the chosen Frobenius). -/
noncomputable def ArtinRep2.eig (A : ArtinRep2) (p : ℕ) : Multiset ℂ :=
  (Matrix.charpoly (A.mat (A.frob (A.chosenPrime p)))).roots

/-- **Theorem A″ (conditional form).** Let `A` be a two-dimensional Artin representation.
Suppose that (from `H1` for a quadratic field and for a cyclic field `C` of odd prime degree `ℓ`,
through the automorphic inputs listed in the module docstring) there are a type of cuspidal
representations, one of them `π`, and a finite set `S` of primes with the local properties
`hsign`, `hsplit`, `hinert`; that the projective image has elements of order dividing `2`, `3`
or `5` only (`heig`); and that a cuspidal representation whose Satake parameters agree with the
eigenvalues of `ρ(Frob_p)` outside a finite set makes `L(ρ, s)` entire (`hentire`).  Then
`L(ρ, s)` is entire. -/
theorem thmA2 (A : ArtinRep2) {ℓ : ℕ} (hℓ : Odd ℓ)
    {Cusp : Type} (sat : Cusp → ℕ → Multiset ℂ) (π : Cusp) (S : Set ℕ) (hS : S.Finite)
    (splitsInC : ℕ → Prop)
    (hsign : ∀ p ∉ S, sat π p = A.eig p ∨ sat π p = (A.eig p).map Neg.neg)
    (hsplit : ∀ p ∉ S, splitsInC p → sat π p = A.eig p)
    (hinert : ∀ p ∉ S, ¬ splitsInC p → (sat π p).map (· ^ ℓ) = (A.eig p).map (· ^ ℓ))
    (heig : ∀ p ∉ S, ∃ a b : ℂ, A.eig p = {a, b} ∧ a ≠ 0 ∧
      (b / a = 1 ∨ (b / a) ^ 2 = 1 ∨ (b / a) ^ 3 = 1 ∨ (b / a) ^ 5 = 1))
    (hentire : ∀ σ : Cusp, (∃ T : Set ℕ, T.Finite ∧ ∀ p ∉ T, sat σ p = A.eig p) → A.ArtinHolds) :
    A.ArtinHolds :=
  hentire π ⟨S, hS, stepTwo hℓ S splitsInC (sat π) A.eig hsign hsplit hinert heig⟩

end Artin1951
