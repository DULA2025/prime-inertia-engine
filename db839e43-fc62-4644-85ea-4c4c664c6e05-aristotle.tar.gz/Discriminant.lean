/-
Copyright (c) 2026 Dula. All rights reserved.
Released under Apache 2.0 license.
-/
import Mathlib.RingTheory.Polynomial.Resultant.Basic
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Vandermonde
import Artin1951.Quintic

/-!
# The discriminant of the Doud–Moore quintic

This file proves, with no `sorry`:

* `Artin1951.resultant_f5Q`: `Res(f₅, f₅') = 2²·7²·71²·137²·1951⁴ = 268684727248076769842884`,
  by an exact `LU` factorisation of the `9 × 9` Sylvester matrix (Mathlib's convention);
* `Artin1951.discr_f5Q`: `Polynomial.discr f₅ = 268684727248076769842884`, the square of
  `518348075378 = 2·7·71·137·1951²`;
* `Artin1951.det_vandermonde_sq`: for any field `K ⊇ ℚ` and any enumeration `α` of the five
  roots of `f₅` in `K`, `det(αᵢʲ)² = 268684727248076769842884`.

The last statement is what the Galois-group computation uses: the discriminant is a square, so
every element of the Galois group of `f₅` permutes the roots evenly.
-/

namespace Artin1951

open Polynomial

/-! ### Coefficients -/

theorem f5Q_eq : f5Q = X ^ 5 - X ^ 4 - C 780 * X ^ 3 - C 1795 * X ^ 2 + C 3106 * X + C 344 := by
  simp [f5Q, f5, map_ofNat]

@[simp] theorem f5Q_coeff_zero : f5Q.coeff 0 = 344 := by
  rw [f5Q_eq]; simp [coeff_C]
@[simp] theorem f5Q_coeff_one : f5Q.coeff 1 = 3106 := by
  rw [f5Q_eq]; simp
@[simp] theorem f5Q_coeff_two : f5Q.coeff 2 = -1795 := by
  rw [f5Q_eq]; simp
@[simp] theorem f5Q_coeff_three : f5Q.coeff 3 = -780 := by
  rw [f5Q_eq]; simp
@[simp] theorem f5Q_coeff_four : f5Q.coeff 4 = -1 := by
  rw [f5Q_eq]; simp
@[simp] theorem f5Q_coeff_five : f5Q.coeff 5 = 1 := by
  rw [f5Q_eq]; simp

/-! ### The Sylvester matrix and an exact `LU` factorisation -/

/-- The Sylvester matrix `sylvester f₅ f₅' 5 4` (Mathlib's convention), entries in `ℚ`. -/
def sylF5 : Matrix (Fin 9) (Fin 9) ℚ :=
  !![
    3106, 0, 0, 0, 0, 344, 0, 0, 0;
    -3590, 3106, 0, 0, 0, 3106, 344, 0, 0;
    -2340, -3590, 3106, 0, 0, -1795, 3106, 344, 0;
    -4, -2340, -3590, 3106, 0, -780, -1795, 3106, 344;
    5, -4, -2340, -3590, 3106, -1, -780, -1795, 3106;
    0, 5, -4, -2340, -3590, 1, -1, -780, -1795;
    0, 0, 5, -4, -2340, 0, 1, -1, -780;
    0, 0, 0, 5, -4, 0, 0, 1, -1;
    0, 0, 0, 0, 5, 0, 0, 0, 1]

/-- A unit lower-triangular matrix with `sylF5 = lowF5 * uppF5` (Gaussian elimination). -/
def lowF5 : Matrix (Fin 9) (Fin 9) ℚ :=
  !![
    1, 0, 0, 0, 0, 0, 0, 0, 0;
    -1795/1553, 1, 0, 0, 0, 0, 0, 0, 0;
    -1170/1553, -1795/1553, 1, 0, 0, 0, 0, 0, 0;
    -2/1553, -1170/1553, -1795/1553, 1, 0, 0, 0, 0, 0;
    5/3106, -2/1553, -1170/1553, -1795/1553, 1, 0, 0, 0, 0;
    0, 5/3106, -2/1553, -1170/1553, -1795/1553, 1, 0, 0, 0;
    0, 0, 5/3106, -2/1553, -1170/1553, 51679455511683539/112489808234144336, 1, 0, 0;
    0, 0, 0, 5/3106, -2/1553, 17268335010957/112489808234144336, 6874113617216/1347176926294223, 1, 0;
    0, 0, 0, 0, 5/3106, -13798102754455/14061226029268042, -2919810776295/1347176926294223, 48437944775/7087985705057, 1]

/-- The upper-triangular result of the elimination. -/
def uppF5 : Matrix (Fin 9) (Fin 9) ℚ :=
  !![
    3106, 0, 0, 0, 0, 344, 0, 0, 0;
    0, 3106, 0, 0, 0, 5441098/1553, 344, 0, 0;
    0, 0, 3106, 0, 0, 6062625195/2411809, 5441098/1553, 344, 0;
    0, 0, 0, 3106, 0, 17849080312537/3745539377, 6062625195/2411809, 5441098/1553, 344;
    0, 0, 0, 0, 3106, 43072157558306728/5816822652481, 17849080312537/3745539377, 6062625195/2411809, 5441098/1553;
    0, 0, 0, 0, 0, 109733807932407799768/9033525579302993, 43072157558306728/5816822652481, 17849080312537/3745539377, 6062625195/2411809;
    0, 0, 0, 0, 0, 0, 2628342183200029073/14061226029268042, -32909432837288895931/112489808234144336, 79322035028238026671/112489808234144336;
    0, 0, 0, 0, 0, 0, 0, -13828660110566207/21554830820707568, -22108750991632957/21554830820707568;
    0, 0, 0, 0, 0, 0, 0, 0, -9045054357871/14175971410114]

/-- The Sylvester matrix of `f₅` and `f₅'` (with `m = 5`, `n = 4`) is `sylF5`. -/
theorem sylvester_f5Q :
    (sylvester f5Q (derivative f5Q) 5 4).reindex (finCongr rfl) (finCongr rfl) = sylF5 := by
  ext ⟨i, hi⟩ ⟨j, hj⟩
  simp only [sylvester, Matrix.reindex_apply, Matrix.submatrix_apply, finCongr_symm,
    finCongr_apply, Fin.cast_mk, Matrix.of_apply, Fin.addCases, Set.mem_Icc, coeff_derivative,
    eq_rec_constant, dite_eq_ite, Fin.val_castLT, Fin.val_subNat, Fin.val_cast]
  interval_cases i <;> interval_cases j <;> norm_num [sylF5]

theorem sylF5_eq : sylF5 = lowF5 * uppF5 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [sylF5, lowF5, uppF5, Matrix.mul_apply, Fin.sum_univ_succ]

theorem lowF5_isLowerTriangular : lowF5.IsLowerTriangular := by
  intro i j hij
  rw [OrderDual.toDual_lt_toDual] at hij
  fin_cases i <;> fin_cases j <;> simp_all [lowF5]

theorem uppF5_isUpperTriangular : uppF5.IsUpperTriangular := by
  intro i j hij
  fin_cases i <;> fin_cases j <;> simp_all [uppF5]

theorem det_lowF5 : lowF5.det = 1 := by
  rw [Matrix.det_of_isLowerTriangular lowF5 lowF5_isLowerTriangular]
  norm_num [lowF5, Fin.prod_univ_succ]

theorem det_uppF5 : uppF5.det = 268684727248076769842884 := by
  rw [Matrix.det_of_isUpperTriangular uppF5_isUpperTriangular]
  norm_num [uppF5, Fin.prod_univ_succ]

/-- `Res(f₅, f₅') = 2²·7²·71²·137²·1951⁴`. -/
theorem resultant_f5Q : resultant f5Q (derivative f5Q) 5 4 = 268684727248076769842884 := by
  rw [resultant, ← Matrix.det_reindex_self (finCongr (rfl : 5 + 4 = 9)), sylvester_f5Q, sylF5_eq,
    Matrix.det_mul, det_lowF5, det_uppF5, one_mul]

/-- **The discriminant of `f₅`** is `2²·7²·71²·137²·1951⁴`. -/
theorem discr_f5Q : discr f5Q = 268684727248076769842884 := by
  have h := resultant_deriv (f := f5Q)
    (natDegree_pos_iff_degree_pos.mp (by rw [f5Q_natDegree]; norm_num))
  rw [f5Q_natDegree, f5Q_monic.leadingCoeff, show (5 : ℕ) - 1 = 4 from rfl, resultant_f5Q] at h
  norm_num at h
  exact h.symm

/-- The discriminant is a square: `2·7·71·137·1951² = 518348075378`. -/
theorem discr_f5Q_eq_sq : discr f5Q = 518348075378 ^ 2 := by
  rw [discr_f5Q]; norm_num

theorem discr_value_factor :
    (268684727248076769842884 : ℤ) = 2 ^ 2 * 7 ^ 2 * 71 ^ 2 * 137 ^ 2 * 1951 ^ 4 := by
  norm_num

/-! ### The Vandermonde determinant of the roots -/

/-- For five elements, `(∏_{i<j} (xⱼ - xᵢ))² = ∏_i ∏_{j ≠ i} (xᵢ - xⱼ)`: each pair `i < j` gives
`(xᵢ - xⱼ)(xⱼ - xᵢ) = -(xⱼ - xᵢ)²` on the right, and there are ten pairs. -/
theorem prod_sub_sq_eq {K : Type*} [CommRing K] (x : Fin 5 → K) :
    (∏ i : Fin 5, ∏ j ∈ Finset.Ioi i, (x j - x i)) ^ 2 =
      ∏ i : Fin 5, ∏ j ∈ Finset.univ.erase i, (x i - x j) := by
  have hI0 : Finset.Ioi (0 : Fin 5) = {1, 2, 3, 4} := by decide
  have hI1 : Finset.Ioi (1 : Fin 5) = {2, 3, 4} := by decide
  have hI2 : Finset.Ioi (2 : Fin 5) = {3, 4} := by decide
  have hI3 : Finset.Ioi (3 : Fin 5) = {4} := by decide
  have hI4 : Finset.Ioi (4 : Fin 5) = ∅ := by decide
  have hE0 : Finset.univ.erase (0 : Fin 5) = {1, 2, 3, 4} := by decide
  have hE1 : Finset.univ.erase (1 : Fin 5) = {0, 2, 3, 4} := by decide
  have hE2 : Finset.univ.erase (2 : Fin 5) = {0, 1, 3, 4} := by decide
  have hE3 : Finset.univ.erase (3 : Fin 5) = {0, 1, 2, 4} := by decide
  have hE4 : Finset.univ.erase (4 : Fin 5) = {0, 1, 2, 3} := by decide
  simp only [Fin.prod_univ_five, hI0, hI1, hI2, hI3, hI4, hE0, hE1, hE2, hE3, hE4]
  simp [Finset.prod_insert, Finset.prod_singleton]
  rw [← neg_sub (x 1) (x 0), ← neg_sub (x 2) (x 0), ← neg_sub (x 3) (x 0), ← neg_sub (x 4) (x 0),
    ← neg_sub (x 2) (x 1), ← neg_sub (x 3) (x 1), ← neg_sub (x 4) (x 1), ← neg_sub (x 3) (x 2),
    ← neg_sub (x 4) (x 2), ← neg_sub (x 4) (x 3)]
  generalize x 1 - x 0 = a, x 2 - x 0 = b, x 3 - x 0 = c, x 4 - x 0 = d, x 2 - x 1 = e,
    x 3 - x 1 = f, x 4 - x 1 = g, x 3 - x 2 = h, x 4 - x 2 = k, x 4 - x 3 = l
  ring

/-- **The Vandermonde determinant of the roots squares to the discriminant.**  If `α` enumerates
the five roots of `f₅` in a field `K ⊇ ℚ`, then `det(αᵢʲ)² = 268684727248076769842884`. -/
theorem det_vandermonde_sq {K : Type*} [Field K] [Algebra ℚ K] (α : Fin 5 → K)
    (hα : Function.Injective α)
    (hroots : (f5Q.map (algebraMap ℚ K)).roots = Finset.univ.val.map α) :
    (Matrix.vandermonde α).det ^ 2 = algebraMap ℚ K 268684727248076769842884 := by
  classical
  have hmon : (f5Q.map (algebraMap ℚ K)).Monic := f5Q_monic.map _
  have hdeg : (f5Q.map (algebraMap ℚ K)).natDegree = 5 := by
    rw [natDegree_map, f5Q_natDegree]
  have hsplit : (f5Q.map (algebraMap ℚ K)).Splits := by
    rw [splits_iff_card_roots, hroots, hdeg, Multiset.card_map, Finset.card_val, Finset.card_univ,
      Fintype.card_fin]
  have hres : resultant (f5Q.map (algebraMap ℚ K)) (derivative (f5Q.map (algebraMap ℚ K))) 5 4 =
      algebraMap ℚ K 268684727248076769842884 := by
    rw [derivative_map, resultant_map_map, resultant_f5Q]
  have hprod := resultant_eq_prod_eval (f5Q.map (algebraMap ℚ K))
    (derivative (f5Q.map (algebraMap ℚ K))) 4
    ((natDegree_derivative_le _).trans (by simp [hdeg])) hsplit
  rw [hdeg, hmon.leadingCoeff, one_pow, one_mul, hres, hroots, Multiset.map_map] at hprod
  rw [Matrix.det_vandermonde, prod_sub_sq_eq, hprod, ← Finset.prod_eq_multiset_prod]
  refine Finset.prod_congr rfl fun i _ => ?_
  have hmem : α i ∈ (f5Q.map (algebraMap ℚ K)).roots := by
    rw [hroots]; exact Multiset.mem_map_of_mem α (Finset.mem_univ_val i)
  simp only [Function.comp_apply]
  rw [hsplit.eval_root_derivative hmon hmem, hroots, ← Multiset.map_erase α hα, Multiset.map_map,
    Finset.prod_eq_multiset_prod, Finset.erase_val]
  rfl

end Artin1951
