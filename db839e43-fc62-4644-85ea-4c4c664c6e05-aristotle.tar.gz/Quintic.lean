/-
Copyright (c) 2026 Dula. All rights reserved.
Released under Apache 2.0 license.
-/
import Mathlib.Algebra.Polynomial.Splits
import Mathlib.Analysis.Polynomial.Basic
import Mathlib.FieldTheory.Separable
import Mathlib.RingTheory.Polynomial.Eisenstein.Basic
import Mathlib.RingTheory.Polynomial.GaussLemma
import Mathlib.RingTheory.Int.Basic
import Mathlib.Topology.Algebra.Polynomial
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic.ComputeDegree
import Mathlib.Tactic.NormNum.Prime

/-!
# The Doud–Moore quintic

`f₅ = X⁵ − X⁴ − 780X³ − 1795X² + 3106X + 344`, whose splitting field `M` has Galois group `A₅`
(`Artin1951.galF5MulEquivA5`) and whose stem field `L₅` has discriminant `1951⁴` (Doud–Moore).
This file proves, with no `sorry`:

* `Artin1951.f5_monic`, `Artin1951.f5_natDegree`: `f₅` is monic of degree `5`;
* `Artin1951.f5_real_splits`: `f₅` has five real roots, one in each of the intervals
  `(-30,-20)`, `(-20,-3)`, `(-1,0)`, `(1,2)`, `(2,30)`; so `L₅` is totally real;
* `Artin1951.f5_comp_eq`: `f₅(X + 1561) = X⁵ + 7804X⁴ + 24360186X³ + 38018939949X² +
  29667123745257X + 9259699129851395`, and `Artin1951.g5_isEisensteinAt`: this polynomial is
  Eisenstein at `1951` (each lower coefficient is divisible by `1951` exactly once).  So `f₅` is
  irreducible over `ℤ` and over `ℚ` (`Artin1951.f5_irreducible`, `Artin1951.f5Q_irreducible`),
  and `1951` is totally ramified in `L₅`.
-/

namespace Artin1951

open Polynomial

/-- The Doud–Moore quintic. -/
noncomputable def f5 : ℤ[X] := X ^ 5 - X ^ 4 - 780 * X ^ 3 - 1795 * X ^ 2 + 3106 * X + 344

/-- `f₅` over `ℝ`. -/
noncomputable def f5R : ℝ[X] := f5.map (Int.castRingHom ℝ)

/-- `f₅` over `ℚ`. -/
noncomputable def f5Q : ℚ[X] := f5.map (Int.castRingHom ℚ)

theorem f5_natDegree : f5.natDegree = 5 := by
  unfold f5; compute_degree!

theorem f5_monic : f5.Monic := by
  unfold f5; monicity!

theorem f5R_natDegree : f5R.natDegree = 5 := by
  rw [f5R, natDegree_map_eq_of_injective (RingHom.injective_int _), f5_natDegree]

theorem f5R_eval (x : ℝ) :
    f5R.eval x = x ^ 5 - x ^ 4 - 780 * x ^ 3 - 1795 * x ^ 2 + 3106 * x + 344 := by
  simp [f5R, f5]

/-- A sign change gives a root in the open interval. -/
theorem exists_root_of_mul_neg (p : ℝ[X]) {a b : ℝ} (hab : a ≤ b)
    (h : p.eval a * p.eval b < 0) : ∃ x ∈ Set.Ioo a b, p.eval x = 0 := by
  have hc : ContinuousOn (fun x => p.eval x) (Set.Icc a b) := p.continuous.continuousOn
  have hza : p.eval a ≠ 0 := fun h0 => by simp [h0] at h
  have hzb : p.eval b ≠ 0 := fun h0 => by simp [h0] at h
  have hmem : (0 : ℝ) ∈ (fun x => p.eval x) '' Set.Icc a b := by
    rcases lt_or_gt_of_ne hza with ha | ha
    · have hb : 0 < p.eval b := by nlinarith
      exact intermediate_value_Icc hab hc ⟨ha.le, hb.le⟩
    · have hb : p.eval b < 0 := by nlinarith
      exact intermediate_value_Icc' hab hc ⟨hb.le, ha.le⟩
  obtain ⟨x, ⟨hxa, hxb⟩, hx⟩ := hmem
  refine ⟨x, ⟨lt_of_le_of_ne hxa ?_, lt_of_le_of_ne hxb ?_⟩, hx⟩
  · rintro rfl; exact hza hx
  · rintro rfl; exact hzb hx

/-- `f₅` has five distinct real roots, one in each of five disjoint intervals. -/
theorem f5_five_real_roots :
    ∃ r : Fin 5 → ℝ, StrictMono r ∧ ∀ i, f5R.eval (r i) = 0 := by
  obtain ⟨r1, ⟨h1a, h1b⟩, e1⟩ := exists_root_of_mul_neg f5R (a := -30) (b := -20) (by norm_num)
    (by rw [f5R_eval, f5R_eval]; norm_num)
  obtain ⟨r2, ⟨h2a, h2b⟩, e2⟩ := exists_root_of_mul_neg f5R (a := -20) (b := -3) (by norm_num)
    (by rw [f5R_eval, f5R_eval]; norm_num)
  obtain ⟨r3, ⟨h3a, h3b⟩, e3⟩ := exists_root_of_mul_neg f5R (a := -1) (b := 0) (by norm_num)
    (by rw [f5R_eval, f5R_eval]; norm_num)
  obtain ⟨r4, ⟨h4a, h4b⟩, e4⟩ := exists_root_of_mul_neg f5R (a := 1) (b := 2) (by norm_num)
    (by rw [f5R_eval, f5R_eval]; norm_num)
  obtain ⟨r5, ⟨h5a, h5b⟩, e5⟩ := exists_root_of_mul_neg f5R (a := 2) (b := 30) (by norm_num)
    (by rw [f5R_eval, f5R_eval]; norm_num)
  refine ⟨![r1, r2, r3, r4, r5], ?_, ?_⟩
  · refine Fin.strictMono_iff_lt_succ.mpr ?_
    intro i
    fin_cases i <;> simp <;> linarith
  · intro i
    fin_cases i <;> simp [e1, e2, e3, e4, e5]

/-- `f₅` splits over `ℝ`: the stem field `L₅` is totally real. -/
theorem f5_real_splits : f5R.Splits := by
  obtain ⟨r, hr, h0⟩ := f5_five_real_roots
  have hne : f5R ≠ 0 := by
    intro h
    have := f5R_natDegree
    rw [h, natDegree_zero] at this
    exact absurd this (by norm_num)
  rw [splits_iff_card_roots, f5R_natDegree]
  apply le_antisymm (f5R_natDegree ▸ card_roots' f5R)
  have hsub : (Finset.univ.image r) ⊆ f5R.roots.toFinset := by
    intro x hx
    obtain ⟨i, -, rfl⟩ := Finset.mem_image.mp hx
    rw [Multiset.mem_toFinset, mem_roots hne]
    exact h0 i
  calc 5 = (Finset.univ.image r).card := by
        rw [Finset.card_image_of_injective _ hr.injective, Finset.card_univ, Fintype.card_fin]
    _ ≤ f5R.roots.toFinset.card := Finset.card_le_card hsub
    _ ≤ Multiset.card f5R.roots := Multiset.toFinset_card_le _

/-! ### Irreducibility: `f₅(X + 1561)` is Eisenstein at `1951` -/

/-- `f₅(X + 1561)`. -/
noncomputable def g5 : ℤ[X] :=
  X ^ 5 + C 7804 * X ^ 4 + C 24360186 * X ^ 3 + C 38018939949 * X ^ 2 +
    C 29667123745257 * X + C 9259699129851395

theorem f5_comp_eq : f5.comp (X + C 1561) = g5 := by
  simp only [f5, g5, sub_comp, add_comp, mul_comp, pow_comp, X_comp, ofNat_comp, map_ofNat]
  ring

theorem g5_natDegree : g5.natDegree = 5 := by
  unfold g5; compute_degree!

theorem g5_monic : g5.Monic := by
  unfold g5; monicity!

theorem g5_coeff_dvd (n : ℕ) (hn : n < 5) : (1951 : ℤ) ∣ g5.coeff n := by
  interval_cases n <;> simp [g5, coeff_X, coeff_X_pow]

theorem g5_coeff_zero : g5.coeff 0 = 9259699129851395 := by
  simp [g5, coeff_X, coeff_X_pow]

/-- `f₅(X + 1561)` is Eisenstein at `1951`. -/
theorem g5_isEisensteinAt : g5.IsEisensteinAt (Ideal.span {(1951 : ℤ)}) := by
  refine g5_monic.isEisensteinAt_of_mem_of_notMem ?_ ?_ ?_
  · rw [Ne, Ideal.span_singleton_eq_top, Int.isUnit_iff]
    norm_num
  · intro n hn
    rw [g5_natDegree] at hn
    exact Ideal.mem_span_singleton.mpr (g5_coeff_dvd n hn)
  · rw [Ideal.span_singleton_pow, Ideal.mem_span_singleton, g5_coeff_zero]
    norm_num

theorem prime_1951 : Prime (1951 : ℤ) :=
  Int.prime_iff_natAbs_prime.mpr (by norm_num)

theorem g5_irreducible : Irreducible g5 :=
  g5_isEisensteinAt.irreducible ((Ideal.span_singleton_prime (by norm_num)).mpr prime_1951)
    g5_monic.isPrimitive (by rw [g5_natDegree]; norm_num)

/-- `f₅` is irreducible over `ℤ`. -/
theorem f5_irreducible : Irreducible f5 := by
  have h : algEquivAevalXAddC (1561 : ℤ) f5 = g5 := by
    rw [algEquivAevalXAddC_apply, ← comp_eq_aeval, f5_comp_eq]
  rw [← MulEquiv.irreducible_iff (algEquivAevalXAddC (1561 : ℤ)), h]
  exact g5_irreducible

/-- `f₅` is irreducible over `ℚ`. -/
theorem f5Q_irreducible : Irreducible f5Q :=
  (IsPrimitive.Int.irreducible_iff_irreducible_map_cast f5_monic.isPrimitive).mp f5_irreducible

theorem f5Q_monic : f5Q.Monic := f5_monic.map _

theorem f5Q_natDegree : f5Q.natDegree = 5 := by
  rw [f5Q, natDegree_map_eq_of_injective (RingHom.injective_int _), f5_natDegree]

theorem f5Q_ne_zero : f5Q ≠ 0 := f5Q_monic.ne_zero

theorem f5Q_separable : f5Q.Separable := f5Q_irreducible.separable

end Artin1951
