/-
Copyright (c) 2026 Dula. All rights reserved.
Released under Apache 2.0 license.
-/
import Mathlib.Algebra.Polynomial.SpecificDegree
import Mathlib.Data.ZMod.QuotientRing
import Mathlib.FieldTheory.PolynomialGaloisGroup
import Mathlib.GroupTheory.IndexNormal
import Mathlib.GroupTheory.SpecificGroups.Alternating.Simple
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.NumberTheory.RamificationInertia.Galois
import Mathlib.RingTheory.Ideal.Int
import Artin1951.Discriminant

/-!
# The Galois group of the Doud–Moore quintic is `A₅`

This file proves, with no `sorry`, that the Galois group of
`f₅ = X⁵ − X⁴ − 780X³ − 1795X² + 3106X + 344` over `ℚ` is isomorphic to `A₅`
(`Artin1951.galF5MulEquivA5`), and has order `60` (`Artin1951.card_galF5`).

The proof:
1. `5 ∣ |G|`: `f₅` is irreducible (Eisenstein at `1951` after `X ↦ X + 1561`, in
   `Artin1951.Quintic`), so a root generates a subfield of degree `5`.
2. `3 ∣ |G|` (`Artin1951.natDegree_dvd_finrank_of_dvd_mod`): modulo `13`,
   `f₅ ≡ (X³ + 6X² + 4X − 6)(X² + 6X − 1)` with the cubic irreducible over `𝔽₁₃`.  In a Galois
   number field `K` where `f₅` splits, the residue field of a prime above `13` contains the
   reductions of the roots of `f₅`, hence a root of the cubic; so `3` divides the residue degree,
   which divides `[K : ℚ]` by the fundamental identity `efg = [K : ℚ]`.
3. `G ⊆ A₅` (`Artin1951.sign_galPerm`): the Vandermonde determinant `δ` of the roots satisfies
   `δ² = disc(f₅) = 518348075378²` (`Artin1951.det_vandermonde_sq`), so `δ ∈ ℚ` is fixed by `G`;
   but `σ(δ) = sign(σ) δ` and `δ ≠ 0`.
4. A subgroup of `A₅` of order divisible by `15` has index at most `4`, and `A₅` is simple, so it
   is `A₅` (`Artin1951.eq_top_of_index_le_four`).
-/

namespace Artin1951

open Polynomial NumberField

/-! ### Degrees of irreducible factors modulo `p` divide `[K : ℚ]` -/

/-- If `f₅` splits in a number field `K`, Galois over `ℚ`, and modulo a prime `p` the reduction of
`f₅` is divisible by the reduction of a monic `c` that is irreducible over `𝔽_p`, then `deg c`
divides `[K : ℚ]`. -/
theorem natDegree_dvd_finrank_of_dvd_mod {K : Type*} [Field K] [NumberField K] [IsGalois ℚ K]
    (hK : (f5Q.map (algebraMap ℚ K)).Splits) (p : ℕ) [Fact p.Prime] (c : ℤ[X]) (hc : c.Monic)
    (hirr : Irreducible (c.map (Int.castRingHom (ZMod p))))
    (hdvd : c.map (Int.castRingHom (ZMod p)) ∣ f5.map (Int.castRingHom (ZMod p))) :
    c.natDegree ∣ Module.finrank ℚ K := by
  classical
  have : IsGaloisGroup Gal(K/ℚ) ℤ (𝓞 K) :=
    IsGaloisGroup.of_isFractionRing Gal(K/ℚ) ℤ (𝓞 K) ℚ K
  obtain ⟨Q, hQmax, hQover⟩ :=
    Ideal.exists_maximal_ideal_liesOver_of_isIntegral (S := 𝓞 K) (Ideal.span {(p : ℤ)})
  have hfund := Ideal.ncard_primesOver_mul_ramificationIdxIn_mul_inertiaDegIn
    (Ideal.span {(p : ℤ)}) (𝓞 K) Gal(K/ℚ)
  rw [IsGalois.card_aut_eq_finrank,
    Ideal.inertiaDegIn_eq_inertiaDeg (Ideal.span {(p : ℤ)}) Q Gal(K/ℚ),
    Ideal.inertiaDeg_eq_of_isMaximal (Ideal.span {(p : ℤ)}) Q] at hfund
  refine dvd_trans ?_ (Dvd.intro_left _ ((mul_assoc _ _ _).trans hfund))
  let : Field (ℤ ⧸ Ideal.span {(p : ℤ)}) := Ideal.Quotient.field _
  let : Field (𝓞 K ⧸ Q) := Ideal.Quotient.field Q
  -- `c` stays irreducible over `ℤ ⧸ (p) ≅ 𝔽_p`
  have hirrF : Irreducible (c.map (algebraMap ℤ (ℤ ⧸ Ideal.span {(p : ℤ)}))) := by
    let e := Int.quotientSpanNatEquivZMod p
    have h1 : (c.map (algebraMap ℤ (ℤ ⧸ Ideal.span {(p : ℤ)}))).map
        (e : (ℤ ⧸ Ideal.span {(p : ℤ)}) →+* ZMod p) = c.map (Int.castRingHom (ZMod p)) := by
      rw [Polynomial.map_map]
      congr 1
    rw [← MulEquiv.irreducible_iff (Polynomial.mapEquiv e), Polynomial.mapEquiv_apply, h1]
    exact hirr
  rw [← hc.natDegree_map (algebraMap ℤ (ℤ ⧸ Ideal.span {(p : ℤ)}))]
  refine Polynomial.Irreducible.natDegree_dvd_finrank hirrF ?_
  rw [Polynomial.map_map, RingHom.ext_int ((algebraMap (ℤ ⧸ Ideal.span {(p : ℤ)}) (𝓞 K ⧸ Q)).comp
    (algebraMap ℤ (ℤ ⧸ Ideal.span {(p : ℤ)}))) (algebraMap ℤ (𝓞 K ⧸ Q))]
  -- `f₅` splits over `𝓞 K`, since its roots in `K` are integral
  have hO : (f5.map (algebraMap ℤ (𝓞 K))).Splits := by
    have hZK : (f5.map (algebraMap ℤ (𝓞 K))).map (algebraMap (𝓞 K) K) =
        f5.map (algebraMap ℤ K) := by
      rw [Polynomial.map_map]
      congr 1
    have hQK : f5.map (algebraMap ℤ K) = f5Q.map (algebraMap ℚ K) := by
      rw [f5Q, Polynomial.map_map]
      congr 1
      try exact RingHom.ext_int _ _
    refine Splits.of_splits_map_of_injective (i := algebraMap (𝓞 K) K)
      RingOfIntegers.coe_injective ?_ ?_
    · rw [hZK, hQK]; exact hK
    · intro a ha
      rw [hZK, mem_roots (f5_monic.map (algebraMap ℤ K)).ne_zero, IsRoot.def, eval_map] at ha
      have hint : IsIntegral ℤ a := ⟨f5, f5_monic, ha⟩
      exact RingHom.mem_range.mpr ⟨⟨a, hint⟩, rfl⟩
  -- hence over the residue field
  have hk : (f5.map (algebraMap ℤ (𝓞 K ⧸ Q))).Splits := by
    have := hO.map (algebraMap (𝓞 K) (𝓞 K ⧸ Q))
    rwa [Polynomial.map_map, RingHom.ext_int ((algebraMap (𝓞 K) (𝓞 K ⧸ Q)).comp
      (algebraMap ℤ (𝓞 K))) (algebraMap ℤ (𝓞 K ⧸ Q))] at this
  -- and `c` divides `f₅` over the residue field
  have hdvdk : c.map (algebraMap ℤ (𝓞 K ⧸ Q)) ∣ f5.map (algebraMap ℤ (𝓞 K ⧸ Q)) := by
    let ψ : ZMod p →+* (𝓞 K ⧸ Q) := (algebraMap (ℤ ⧸ Ideal.span {(p : ℤ)}) (𝓞 K ⧸ Q)).comp
      (Int.quotientSpanNatEquivZMod p).symm.toRingHom
    have h := Polynomial.map_dvd ψ hdvd
    rwa [Polynomial.map_map, Polynomial.map_map,
      RingHom.ext_int (ψ.comp (Int.castRingHom (ZMod p))) (algebraMap ℤ (𝓞 K ⧸ Q))] at h
  exact hk.of_dvd (f5_monic.map _).ne_zero hdvdk

/-! ### The factor of degree `3` modulo `13` -/

/-- The cubic factor of `f₅` modulo `13`. -/
noncomputable def c13 : ℤ[X] := X ^ 3 + 6 * X ^ 2 + 4 * X - 6

/-- The complementary quadratic factor modulo `13` (it is `(X + 9)(X + 10)` modulo `13`). -/
noncomputable def q13 : ℤ[X] := X ^ 2 + 6 * X - 1

/-- `(f₅ - c₁₃ q₁₃) / 13`. -/
noncomputable def h13 : ℤ[X] := -X ^ 4 - 63 * X ^ 3 - 139 * X ^ 2 + 242 * X + 26

theorem f5_eq_mod13 : f5 = c13 * q13 + 13 * h13 := by
  simp only [f5, c13, q13, h13]
  ring

theorem c13_monic : c13.Monic := by
  unfold c13; monicity!

theorem c13_natDegree : c13.natDegree = 3 := by
  unfold c13; compute_degree!

instance fact_prime_13 : Fact (Nat.Prime 13) := ⟨by norm_num⟩

theorem c13_irreducible_mod : Irreducible (c13.map (Int.castRingHom (ZMod 13))) := by
  have hdeg : (c13.map (Int.castRingHom (ZMod 13))).natDegree = 3 := by
    rw [c13_monic.natDegree_map, c13_natDegree]
  apply irreducible_of_degree_le_three_of_not_isRoot
  · rw [hdeg]; decide
  intro x
  simp only [c13, IsRoot.def, Polynomial.map_sub, Polynomial.map_add, Polynomial.map_mul,
    Polynomial.map_pow, Polynomial.map_X, Polynomial.map_ofNat, eval_sub, eval_add, eval_mul,
    eval_pow, eval_X, eval_ofNat]
  revert x
  decide

theorem c13_dvd_mod : c13.map (Int.castRingHom (ZMod 13)) ∣ f5.map (Int.castRingHom (ZMod 13)) := by
  refine ⟨q13.map (Int.castRingHom (ZMod 13)), ?_⟩
  have h13 : (13 : (ZMod 13)[X]) = 0 := by
    have : (13 : ZMod 13) = 0 := by decide
    rw [← map_ofNat C 13, this, map_zero]
  rw [f5_eq_mod13, Polynomial.map_add, Polynomial.map_mul, Polynomial.map_mul, Polynomial.map_ofNat,
    h13, zero_mul, add_zero]

/-- If `f₅` splits in a Galois number field `K`, then `15 ∣ [K : ℚ]`. -/
theorem fifteen_dvd_finrank (K : Type*) [Field K] [NumberField K] [IsGalois ℚ K]
    (hK : (f5Q.map (algebraMap ℚ K)).Splits) : 15 ∣ Module.finrank ℚ K := by
  have h3 : 3 ∣ Module.finrank ℚ K := by
    have := natDegree_dvd_finrank_of_dvd_mod hK 13 c13 c13_monic c13_irreducible_mod c13_dvd_mod
    rwa [c13_natDegree] at this
  have h5 : 5 ∣ Module.finrank ℚ K := by
    have := Polynomial.Irreducible.natDegree_dvd_finrank f5Q_irreducible hK
    rwa [f5Q_natDegree] at this
  exact Nat.Coprime.mul_dvd_of_dvd_of_dvd (by decide) h3 h5

/-! ### The splitting field and the action on the roots -/

instance : NumberField f5Q.SplittingField := ⟨⟩

instance : IsGalois ℚ f5Q.SplittingField :=
  IsGalois.of_separable_splitting_field f5Q_separable

theorem fifteen_dvd_card_galF5 : 15 ∣ Nat.card f5Q.Gal := by
  rw [Gal.card_of_separable f5Q_separable]
  exact fifteen_dvd_finrank f5Q.SplittingField (SplittingField.splits f5Q)

theorem card_rootSet_f5Q : Fintype.card (f5Q.rootSet f5Q.SplittingField) = 5 := by
  rw [card_rootSet_eq_natDegree f5Q_separable (SplittingField.splits f5Q), f5Q_natDegree]

/-- An enumeration of the roots of `f₅` in its splitting field. -/
noncomputable def rootEquiv : Fin 5 ≃ f5Q.rootSet f5Q.SplittingField :=
  (Fintype.equivFinOfCardEq card_rootSet_f5Q).symm

/-- The `i`-th root of `f₅`. -/
noncomputable def root (i : Fin 5) : f5Q.SplittingField := (rootEquiv i : f5Q.SplittingField)

theorem root_injective : Function.Injective root :=
  fun _ _ h => rootEquiv.injective (Subtype.ext h)

theorem mem_roots_iff_mem_rootSet (a : f5Q.SplittingField) :
    a ∈ (f5Q.map (algebraMap ℚ f5Q.SplittingField)).roots ↔ a ∈ f5Q.rootSet f5Q.SplittingField := by
  classical
  rw [rootSet_def, Finset.mem_coe, Multiset.mem_toFinset, aroots_def]

theorem roots_eq_map_root :
    (f5Q.map (algebraMap ℚ f5Q.SplittingField)).roots = Finset.univ.val.map root := by
  classical
  rw [Multiset.Nodup.ext (nodup_roots f5Q_separable.map)
    (Multiset.Nodup.map root_injective Finset.univ.nodup)]
  intro a
  rw [mem_roots_iff_mem_rootSet, Multiset.mem_map]
  constructor
  · intro ha
    exact ⟨rootEquiv.symm ⟨a, ha⟩, Finset.mem_univ_val _, by simp [root]⟩
  · rintro ⟨i, -, rfl⟩
    exact (rootEquiv i).2

theorem mem_rootSet_iff_apply (σ : f5Q.Gal) (x : f5Q.SplittingField) :
    x ∈ f5Q.rootSet f5Q.SplittingField ↔ σ x ∈ f5Q.rootSet f5Q.SplittingField := by
  rw [mem_rootSet, mem_rootSet]
  have h : aeval (σ x) f5Q = σ (aeval x f5Q) :=
    Polynomial.aeval_algHom_apply (AlgEquiv.toAlgHom σ) x f5Q
  rw [h]
  constructor
  · rintro ⟨h0, h1⟩
    exact ⟨h0, by rw [h1]; exact map_zero σ⟩
  · rintro ⟨h0, h1⟩
    exact ⟨h0, (AlgEquiv.injective σ) (h1.trans (map_zero σ).symm)⟩

/-- The permutation of the roots induced by an element of the Galois group. -/
noncomputable def rootPerm : f5Q.Gal →* Equiv.Perm (f5Q.rootSet f5Q.SplittingField) where
  toFun σ := Equiv.Perm.subtypePerm (AlgEquiv.toEquiv σ) (fun x => (mem_rootSet_iff_apply σ x).symm)
  map_one' := by ext x; rfl
  map_mul' σ τ := by ext x; rfl

theorem rootPerm_apply (σ : f5Q.Gal) (x : f5Q.rootSet f5Q.SplittingField) :
    (rootPerm σ x : f5Q.SplittingField) = σ x := rfl

theorem rootPerm_injective : Function.Injective rootPerm := by
  rw [injective_iff_map_eq_one]
  intro σ hσ
  ext x hx
  have h := congrArg (fun π : Equiv.Perm (f5Q.rootSet f5Q.SplittingField) =>
    ((π ⟨x, hx⟩ : f5Q.rootSet f5Q.SplittingField) : f5Q.SplittingField)) hσ
  simp only [rootPerm_apply, Equiv.Perm.one_apply] at h
  exact h

/-- The Galois group of `f₅` acting on the indices of the enumerated roots. -/
noncomputable def galPerm : f5Q.Gal →* Equiv.Perm (Fin 5) :=
  (rootEquiv.symm.permCongrHom).toMonoidHom.comp rootPerm

theorem galPerm_injective : Function.Injective galPerm :=
  (rootEquiv.symm.permCongrHom).injective.comp rootPerm_injective

theorem root_galPerm (σ : f5Q.Gal) (i : Fin 5) : root (galPerm σ i) = σ (root i) := by
  simp [galPerm, root, Equiv.permCongrHom, Equiv.permCongr_apply, rootPerm_apply]

/-! ### Every element of the Galois group is even -/

theorem det_vandermonde_root_sq :
    (Matrix.vandermonde root).det ^ 2 =
      algebraMap ℚ f5Q.SplittingField 268684727248076769842884 :=
  det_vandermonde_sq root root_injective roots_eq_map_root

theorem det_vandermonde_root_mem :
    (Matrix.vandermonde root).det = algebraMap ℚ f5Q.SplittingField 518348075378 ∨
      (Matrix.vandermonde root).det = -algebraMap ℚ f5Q.SplittingField 518348075378 := by
  have h := det_vandermonde_root_sq
  have e : algebraMap ℚ f5Q.SplittingField 268684727248076769842884 =
      (algebraMap ℚ f5Q.SplittingField 518348075378) ^ 2 := by
    rw [← map_pow]; norm_num
  rw [e] at h
  exact sq_eq_sq_iff_eq_or_eq_neg.mp h

/-- **Every element of the Galois group of `f₅` permutes the roots evenly.** -/
theorem sign_galPerm (σ : f5Q.Gal) : Equiv.Perm.sign (galPerm σ) = 1 := by
  have hδ0 : (Matrix.vandermonde root).det ≠ 0 :=
    Matrix.det_vandermonde_ne_zero_iff.mpr root_injective
  have hfix : σ (Matrix.vandermonde root).det = (Matrix.vandermonde root).det := by
    have hc : σ (algebraMap ℚ f5Q.SplittingField 518348075378) =
        algebraMap ℚ f5Q.SplittingField 518348075378 := AlgEquiv.commutes σ _
    rcases det_vandermonde_root_mem with h | h
    · rw [h]; exact hc
    · rw [h, map_neg, hc]
  have h1 : σ (Matrix.vandermonde root).det = (Matrix.vandermonde fun i => σ (root i)).det := by
    refine (RingHom.map_det (AlgEquiv.toAlgHom σ).toRingHom (Matrix.vandermonde root)).trans ?_
    congr 1
    ext i j
    simp only [RingHom.mapMatrix_apply, Matrix.map_apply, Matrix.vandermonde_apply, map_pow]
    all_goals rfl
  have h2 : (Matrix.vandermonde fun i => σ (root i)) =
      (Matrix.vandermonde root).submatrix (galPerm σ) id := by
    ext i j
    simp [Matrix.vandermonde_apply, root_galPerm]
  have hperm : (Matrix.vandermonde root).det =
      ((Equiv.Perm.sign (galPerm σ) : ℤ) : f5Q.SplittingField) * (Matrix.vandermonde root).det := by
    rw [← Matrix.det_permute, ← h2, ← h1, hfix]
  have hs : ((Equiv.Perm.sign (galPerm σ) : ℤ) : f5Q.SplittingField) = 1 :=
    (mul_right_cancel₀ hδ0 ((one_mul _).trans hperm)).symm
  rcases Int.units_eq_one_or (Equiv.Perm.sign (galPerm σ)) with h | h
  · exact h
  · rw [h] at hs
    norm_num at hs

theorem galPerm_mem_alternatingGroup (σ : f5Q.Gal) :
    galPerm σ ∈ alternatingGroup (Fin 5) :=
  Equiv.Perm.mem_alternatingGroup.mpr (sign_galPerm σ)

/-! ### Subgroups of `A₅` of order divisible by `15` -/

theorem card_alternatingGroup_five : Nat.card (alternatingGroup (Fin 5)) = 60 := by
  rw [nat_card_alternatingGroup, Nat.card_eq_fintype_card, Fintype.card_fin]
  rfl

/-- A subgroup of `A₅` of index at most `4` is `A₅` (as `A₅` is simple of order `60 > 4!`). -/
theorem eq_top_of_index_le_four (H : Subgroup (alternatingGroup (Fin 5))) (hH : H.index ≤ 4) :
    H = ⊤ := by
  by_contra hne
  rcases Subgroup.Normal.eq_bot_or_eq_top H.normalCore with h | h
  · have hd : H.normalCore.index ∣ H.index.factorial :=
      Subgroup.index_normalCore_dvd_factorial_index (H := H)
    rw [h, Subgroup.index_bot, card_alternatingGroup_five] at hd
    have h24 : H.index.factorial ∣ 24 := (Nat.factorial_dvd_factorial hH).trans (by decide)
    have := Nat.le_of_dvd (by norm_num) (dvd_trans hd h24)
    norm_num at this
  · exact hne (eq_top_iff.mpr (h ▸ H.normalCore_le))

/-- A subgroup of `S₅` inside `A₅` whose order is divisible by `15` is `A₅`. -/
theorem eq_alternatingGroup_of_fifteen_dvd (H : Subgroup (Equiv.Perm (Fin 5)))
    (hle : H ≤ alternatingGroup (Fin 5)) (h15 : 15 ∣ Nat.card H) :
    H = alternatingGroup (Fin 5) := by
  have hcard : Nat.card (H.subgroupOf (alternatingGroup (Fin 5))) = Nat.card H :=
    Nat.card_congr (Subgroup.subgroupOfEquivOfLe hle).toEquiv
  have hlag := Subgroup.card_mul_index (H.subgroupOf (alternatingGroup (Fin 5)))
  rw [hcard, card_alternatingGroup_five] at hlag
  obtain ⟨k, hk⟩ := h15
  rw [hk] at hlag
  have h4 : k * (H.subgroupOf (alternatingGroup (Fin 5))).index = 4 := by
    apply Nat.eq_of_mul_eq_mul_left (show 0 < 15 by norm_num)
    rw [← mul_assoc, hlag]
  have hidx : (H.subgroupOf (alternatingGroup (Fin 5))).index ∣ 4 := Dvd.intro_left k h4
  have htop := eq_top_of_index_le_four _ (Nat.le_of_dvd (by norm_num) hidx)
  exact le_antisymm hle (Subgroup.subgroupOf_eq_top.mp htop)

/-! ### The Galois group is `A₅` -/

theorem range_galPerm : galPerm.range = alternatingGroup (Fin 5) := by
  apply eq_alternatingGroup_of_fifteen_dvd
  · rintro _ ⟨σ, rfl⟩
    exact galPerm_mem_alternatingGroup σ
  · rw [← Nat.card_congr (MonoidHom.ofInjective galPerm_injective).toEquiv]
    exact fifteen_dvd_card_galF5

/-- **The Galois group of `f₅` over `ℚ` is isomorphic to `A₅`.** -/
noncomputable def galF5MulEquivA5 : f5Q.Gal ≃* alternatingGroup (Fin 5) :=
  (MonoidHom.ofInjective galPerm_injective).trans (MulEquiv.subgroupCongr range_galPerm)

/-- The Galois group of `f₅` has order `60`. -/
theorem card_galF5 : Nat.card f5Q.Gal = 60 := by
  rw [Nat.card_congr galF5MulEquivA5.toEquiv, card_alternatingGroup_five]

/-- The splitting field of `f₅` has degree `60` over `ℚ`. -/
theorem finrank_splittingField_f5Q : Module.finrank ℚ f5Q.SplittingField = 60 := by
  rw [← Gal.card_of_separable f5Q_separable, card_galF5]

end Artin1951
