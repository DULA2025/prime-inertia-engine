/-
Copyright (c) 2026 Dula. All rights reserved.
Released under Apache 2.0 license.
-/
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.FieldTheory.IsAlgClosed.Spectrum
import Mathlib.LinearAlgebra.Matrix.Charpoly.Eigs
import Mathlib.LinearAlgebra.Matrix.GeneralLinearGroup.Basic
import Artin1951.Conditional
import Artin1951.ProjectiveImage

/-!
# The eigenvalue ratios of `ρ(σ)`

For every `A` with `A.IsRho1951` and every `σ ∈ Gal(N/ℚ)`, the eigenvalues `a, b` of `ρ(σ)`
satisfy `(b/a)^n = 1` for some `n ∈ {2, 3, 5}` (`Artin1951.ArtinRep2.eig_ratio`).  The image of
`σ` in the projective image, which is `A₅` (`Artin1951.ArtinRep2.projImageEquivA5`), has order
dividing `2`, `3` or `5`; so `ρ(σ)^n` is a scalar matrix `c`, and `a^n = b^n = c ≠ 0`.

This discharges the hypothesis `heig` of `Artin1951.thmA2`: `Artin1951.thmA2_of_isRho1951` is
Theorem A″ for every `A` with `A.IsRho1951`, with only the automorphic inputs (from H1 for a
quadratic and a cyclic field) and the final analytic step as hypotheses.  No `sorry`.
-/

namespace Artin1951

open Polynomial

/-- If `M ^ k` is the scalar matrix `c`, every root `t` of the characteristic polynomial of `M`
satisfies `t ^ k = c`. -/
theorem root_pow_eq_of_pow_eq_scalar {M : Matrix (Fin 2) (Fin 2) ℂ} {k : ℕ} {c : ℂ}
    (hM : M ^ k = Matrix.scalar (Fin 2) c) {t : ℂ} (ht : t ∈ M.charpoly.roots) : t ^ k = c := by
  have hspec : t ∈ spectrum ℂ M := Matrix.mem_spectrum_of_isRoot_charpoly (isRoot_of_mem_roots ht)
  have hpow : t ^ k ∈ spectrum ℂ (M ^ k) := spectrum.pow_mem_pow M k hspec
  have hsc : Matrix.scalar (Fin 2) c = algebraMap ℂ (Matrix (Fin 2) (Fin 2) ℂ) c := rfl
  rw [hM, hsc, spectrum.scalar_eq] at hpow
  exact Set.mem_singleton_iff.mp hpow

/-- Every complex number is a square (`exp (log d / 2)`; no fundamental theorem of algebra). -/
theorem exists_sq_eq (d : ℂ) : ∃ s : ℂ, s ^ 2 = d := by
  by_cases hd : d = 0
  · exact ⟨0, by simp [hd]⟩
  · refine ⟨Complex.exp (Complex.log d / 2), ?_⟩
    rw [← Complex.exp_nat_mul, show ((2 : ℕ) : ℂ) * (Complex.log d / 2) = Complex.log d by
      push_cast; ring, Complex.exp_log hd]

/-- The characteristic polynomial of a `2 × 2` complex matrix has two roots (by the quadratic
formula). -/
theorem charpoly_roots_eq_pair (M : Matrix (Fin 2) (Fin 2) ℂ) :
    ∃ a b : ℂ, M.charpoly.roots = {a, b} := by
  obtain ⟨s, hs⟩ := exists_sq_eq (M.trace ^ 2 - 4 * M.det)
  have hsum : (M.trace + s) / 2 + (M.trace - s) / 2 = M.trace := by ring
  have hprod : (M.trace + s) / 2 * ((M.trace - s) / 2) = M.det := by
    linear_combination (-1 / 4 : ℂ) * hs
  refine ⟨(M.trace + s) / 2, (M.trace - s) / 2, ?_⟩
  have key : ∀ t d a b : ℂ, a + b = t → a * b = d →
      (X ^ 2 - C t * X + C d : ℂ[X]) = (X - C a) * (X - C b) := by
    intro t d a b h1 h2
    rw [← h1, ← h2, map_add, map_mul]
    ring
  have h : M.charpoly = (X - C ((M.trace + s) / 2)) * (X - C ((M.trace - s) / 2)) := by
    rw [Matrix.charpoly_fin_two]
    exact key _ _ _ _ hsum hprod
  rw [h, roots_mul (mul_ne_zero (X_sub_C_ne_zero _) (X_sub_C_ne_zero _)), roots_X_sub_C,
    roots_X_sub_C]
  simp

namespace ArtinRep2

variable (A : ArtinRep2)

/-- The image of every `σ` in the projective image `A₅` has order dividing `2`, `3` or `5`. -/
theorem pow_mem_projKer (hA : A.IsRho1951) (σ : A.G) :
    σ ^ 2 ∈ A.projKer ∨ σ ^ 3 ∈ A.projKer ∨ σ ^ 5 ∈ A.projKer := by
  have key : ∀ n : ℕ,
      (A.projImageEquivA5 hA (QuotientGroup.mk σ : A.G ⧸ A.projKer)) ^ n = 1 →
        σ ^ n ∈ A.projKer := by
    intro n hn
    rw [← map_pow, MulEquiv.map_eq_one_iff, ← QuotientGroup.mk_pow,
      QuotientGroup.eq_one_iff] at hn
    exact hn
  rcases alternatingGroup_five_orders
      (A.projImageEquivA5 hA (QuotientGroup.mk σ : A.G ⧸ A.projKer)) with h | h | h
  · exact Or.inl (key 2 h)
  · exact Or.inr (Or.inl (key 3 h))
  · exact Or.inr (Or.inr (key 5 h))

/-- If `σ ^ k` acts by scalars, then `ρ(σ) ^ k` is a non-zero scalar matrix. -/
theorem mat_pow_eq_scalar {σ : A.G} {k : ℕ} (h : σ ^ k ∈ A.projKer) :
    ∃ c : ℂ, c ≠ 0 ∧ A.mat σ ^ k = Matrix.scalar (Fin 2) c := by
  have hcen : A.ρ (σ ^ k) ∈ Subgroup.center (GL (Fin 2) ℂ) := h
  obtain ⟨c, hc⟩ := Matrix.GeneralLinearGroup.mem_center_iff_val_mem_range_scalar.mp hcen
  refine ⟨c, ?_, ?_⟩
  · intro h0
    apply Units.ne_zero (A.ρ (σ ^ k))
    rw [← hc, h0, map_zero]
  · rw [hc, map_pow, Units.val_pow_eq_pow_val]

/-- **The eigenvalue ratio of `ρ(σ)` has order dividing `2`, `3` or `5`.** -/
theorem eig_ratio (hA : A.IsRho1951) (σ : A.G) :
    ∃ a b : ℂ, (Matrix.charpoly (A.mat σ)).roots = {a, b} ∧ a ≠ 0 ∧
      (b / a = 1 ∨ (b / a) ^ 2 = 1 ∨ (b / a) ^ 3 = 1 ∨ (b / a) ^ 5 = 1) := by
  obtain ⟨a, b, hab⟩ := charpoly_roots_eq_pair (A.mat σ)
  have ha : a ∈ (Matrix.charpoly (A.mat σ)).roots := by rw [hab]; simp
  have hb : b ∈ (Matrix.charpoly (A.mat σ)).roots := by rw [hab]; simp
  have key : ∀ k : ℕ, 0 < k → σ ^ k ∈ A.projKer → a ≠ 0 ∧ (b / a) ^ k = 1 := by
    intro k hk hσ
    obtain ⟨c, hc0, hc⟩ := A.mat_pow_eq_scalar hσ
    have hak := root_pow_eq_of_pow_eq_scalar hc ha
    have hbk := root_pow_eq_of_pow_eq_scalar hc hb
    have ha0 : a ≠ 0 := by
      rintro rfl
      rw [zero_pow hk.ne'] at hak
      exact hc0 hak.symm
    exact ⟨ha0, by rw [div_pow, hak, hbk, div_self hc0]⟩
  refine ⟨a, b, hab, ?_⟩
  rcases A.pow_mem_projKer hA σ with h | h | h
  · obtain ⟨h0, h1⟩ := key 2 (by norm_num) h
    exact ⟨h0, Or.inr (Or.inl h1)⟩
  · obtain ⟨h0, h1⟩ := key 3 (by norm_num) h
    exact ⟨h0, Or.inr (Or.inr (Or.inl h1))⟩
  · obtain ⟨h0, h1⟩ := key 5 (by norm_num) h
    exact ⟨h0, Or.inr (Or.inr (Or.inr h1))⟩

end ArtinRep2

/-- **Theorem A″ for every `A` with `A.IsRho1951`.**  The group-theoretic input of Step 2 is now
proved (`Artin1951.ArtinRep2.eig_ratio`); what remains as hypotheses are the automorphic inputs
from `H1` for a quadratic field and for a cyclic field `C` of odd prime degree `ℓ` (`hsign`,
`hsplit`, `hinert`) and the final analytic step (`hentire`). -/
theorem thmA2_of_isRho1951 (A : ArtinRep2) (hA : A.IsRho1951) {ℓ : ℕ} (hℓ : Odd ℓ)
    {Cusp : Type} (sat : Cusp → ℕ → Multiset ℂ) (π : Cusp) (S : Set ℕ) (hS : S.Finite)
    (splitsInC : ℕ → Prop)
    (hsign : ∀ p ∉ S, sat π p = A.eig p ∨ sat π p = (A.eig p).map Neg.neg)
    (hsplit : ∀ p ∉ S, splitsInC p → sat π p = A.eig p)
    (hinert : ∀ p ∉ S, ¬ splitsInC p → (sat π p).map (· ^ ℓ) = (A.eig p).map (· ^ ℓ))
    (hentire : ∀ σ : Cusp, (∃ T : Set ℕ, T.Finite ∧ ∀ p ∉ T, sat σ p = A.eig p) → A.ArtinHolds) :
    A.ArtinHolds :=
  thmA2 A hℓ sat π S hS splitsInC hsign hsplit hinert
    (fun p _ => A.eig_ratio hA (A.frob (A.chosenPrime p))) hentire

end Artin1951
