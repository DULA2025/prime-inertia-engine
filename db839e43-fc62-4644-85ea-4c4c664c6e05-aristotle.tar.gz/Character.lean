/-
Copyright (c) 2026 Dula. All rights reserved.
Released under Apache 2.0 license.
-/
import Mathlib.GroupTheory.SpecificGroups.Cyclic.Subgroup
import Mathlib.Data.ZMod.QuotientGroup
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.NumberTheory.MulChar.Lemmas
import Mathlib.RingTheory.RootsOfUnity.Complex
import Mathlib.Tactic.NormNum.Prime

/-!
# The character `χ` of conductor 1951

Section 2 of the note: `χ : (ℤ/1951)ˣ → μ₅` is the character with `χ(3) = ζ₅²`, where `3` is a
primitive root modulo `1951` (Conrey label `1951.908`).  This file proves, with no `sorry`:

* `Artin1951.orderOf_three`: `3` has order `1950` in `ZMod 1951`, i.e. it is a primitive root;
* `Artin1951.three_pow_780`, `two_eq_three_pow`, `neg_one_eq_three_pow`: `3 ^ 780 = 908`,
  `2 = 3 ^ 604`, `-1 = 3 ^ 975` in `ZMod 1951`;
* for every multiplicative character `ψ` of `ZMod 1951` with `ψ 3 = ζ ^ 2`, where `ζ ^ 5 = 1`:
  `ψ 2 = ζ ^ 3` and `ψ (-1) = 1` (`Artin1951.char_two`, `Artin1951.char_neg_one`);
* `Artin1951.chi`: such a character with values in `ℂ`, for `ζ = exp (2πi/5)`
  (`Artin1951.chi_three`), built with `MulChar.ofRootOfUnity`.
-/

namespace Artin1951

instance fact_prime_1951 : Fact (Nat.Prime 1951) := ⟨by norm_num⟩

theorem three_pow_1950 : (3 : ZMod 1951) ^ 1950 = 1 := by decide +kernel

theorem three_pow_975 : (3 : ZMod 1951) ^ 975 = -1 := by decide +kernel

theorem three_pow_650 : (3 : ZMod 1951) ^ 650 ≠ 1 := by decide +kernel

theorem three_pow_390 : (3 : ZMod 1951) ^ 390 ≠ 1 := by decide +kernel

theorem three_pow_150 : (3 : ZMod 1951) ^ 150 ≠ 1 := by decide +kernel

theorem three_pow_780 : (3 : ZMod 1951) ^ 780 = 908 := by decide +kernel

theorem two_eq_three_pow : (2 : ZMod 1951) = 3 ^ 604 := by decide +kernel

theorem neg_one_eq_three_pow : (-1 : ZMod 1951) = 3 ^ 975 := three_pow_975.symm

/-- The prime divisors of `1950 = 2 · 3 · 5² · 13`. -/
theorem prime_dvd_1950 {p : ℕ} (hp : p.Prime) (h : p ∣ 1950) :
    p = 2 ∨ p = 3 ∨ p = 5 ∨ p = 13 := by
  have h' : p ∣ 2 * (3 * (5 * (5 * 13))) := by norm_num [h]
  rcases (Nat.Prime.dvd_mul hp).mp h' with h2 | h'
  · exact Or.inl ((Nat.prime_dvd_prime_iff_eq hp Nat.prime_two).mp h2)
  rcases (Nat.Prime.dvd_mul hp).mp h' with h3 | h'
  · exact Or.inr (Or.inl ((Nat.prime_dvd_prime_iff_eq hp Nat.prime_three).mp h3))
  rcases (Nat.Prime.dvd_mul hp).mp h' with h5 | h'
  · exact Or.inr (Or.inr (Or.inl ((Nat.prime_dvd_prime_iff_eq hp Nat.prime_five).mp h5)))
  rcases (Nat.Prime.dvd_mul hp).mp h' with h5 | h13
  · exact Or.inr (Or.inr (Or.inl ((Nat.prime_dvd_prime_iff_eq hp Nat.prime_five).mp h5)))
  · exact Or.inr (Or.inr (Or.inr ((Nat.prime_dvd_prime_iff_eq hp (by norm_num)).mp h13)))

/-- `3` is a primitive root modulo `1951`. -/
theorem orderOf_three : orderOf (3 : ZMod 1951) = 1950 := by
  refine orderOf_eq_of_pow_and_pow_div_prime (by norm_num) three_pow_1950 ?_
  intro p hp hdvd
  rcases prime_dvd_1950 hp hdvd with rfl | rfl | rfl | rfl
  · rw [show 1950 / 2 = 975 by norm_num, three_pow_975]; decide
  · simpa using three_pow_650
  · simpa using three_pow_390
  · simpa using three_pow_150

/-- Every character `ψ` with `ψ 3 = ζ ^ 2`, `ζ ^ 5 = 1`, has `ψ 2 = ζ ^ 3`. -/
theorem char_two {R : Type*} [CommMonoidWithZero R] (ψ : MulChar (ZMod 1951) R) {ζ : R}
    (hζ : ζ ^ 5 = 1) (h3 : ψ 3 = ζ ^ 2) : ψ 2 = ζ ^ 3 := by
  rw [two_eq_three_pow, map_pow, h3, ← pow_mul,
    show 2 * 604 = 5 * 241 + 3 by norm_num, pow_add, pow_mul, hζ, one_pow, one_mul]

/-- Every such character is even: `ψ (-1) = 1`. -/
theorem char_neg_one {R : Type*} [CommMonoidWithZero R] (ψ : MulChar (ZMod 1951) R) {ζ : R}
    (hζ : ζ ^ 5 = 1) (h3 : ψ 3 = ζ ^ 2) : ψ (-1) = 1 := by
  rw [neg_one_eq_three_pow, map_pow, h3, ← pow_mul,
    show 2 * 975 = 5 * 390 by norm_num, pow_mul, hζ, one_pow]

/-- Every such character satisfies `ψ ^ 5 = 1` on units: `ψ (3 ^ k) = ζ ^ (2k)`. -/
theorem char_three_pow {R : Type*} [CommMonoidWithZero R] (ψ : MulChar (ZMod 1951) R) {ζ : R}
    (h3 : ψ 3 = ζ ^ 2) (k : ℕ) : ψ (3 ^ k) = ζ ^ (2 * k) := by
  rw [map_pow, h3, ← pow_mul]

/-! ### Existence: the character `χ` with values in `ℂ` -/

/-- `3` as a unit of `ZMod 1951`. -/
def three : (ZMod 1951)ˣ := ZMod.unitOfCoprime 3 (by norm_num)

theorem three_coe : ((three : (ZMod 1951)ˣ) : ZMod 1951) = 3 := rfl

theorem orderOf_three_unit : orderOf three = 1950 := by
  rw [← orderOf_units, three_coe, orderOf_three]

theorem card_units_1951 : Nat.card (ZMod 1951)ˣ = 1950 := by
  rw [Nat.card_eq_fintype_card, ZMod.card_units]

theorem three_generates (x : (ZMod 1951)ˣ) : x ∈ Subgroup.zpowers three := by
  have htop : Subgroup.zpowers three = ⊤ := by
    rw [← Subgroup.card_eq_iff_eq_top, Nat.card_zpowers, orderOf_three_unit, card_units_1951]
  rw [htop]
  exact Subgroup.mem_top x

/-- `ζ₅ = exp(2πi/5)`. -/
noncomputable def zeta5 : ℂ := Complex.exp (2 * Real.pi * Complex.I / (5 : ℕ))

theorem zeta5_isPrimitiveRoot : IsPrimitiveRoot zeta5 5 :=
  Complex.isPrimitiveRoot_exp 5 (by norm_num)

theorem zeta5_pow_five : zeta5 ^ 5 = 1 := zeta5_isPrimitiveRoot.pow_eq_one

/-- `ζ₅²` as a unit of `ℂ`. -/
noncomputable def zeta5sqUnit : ℂˣ :=
  Units.mk0 (zeta5 ^ 2) (pow_ne_zero 2 (zeta5_isPrimitiveRoot.ne_zero (by norm_num)))

theorem zeta5sqUnit_mem : zeta5sqUnit ∈ rootsOfUnity (Fintype.card (ZMod 1951)ˣ) ℂ := by
  rw [mem_rootsOfUnity, ZMod.card_units, Units.ext_iff]
  simp only [zeta5sqUnit, Units.val_pow_eq_pow_val, Units.val_mk0, Units.val_one]
  rw [← pow_mul, show 2 * (1951 - 1) = 5 * 780 by norm_num, pow_mul, zeta5_pow_five, one_pow]

/-- The character `χ` of the note: `χ(3) = ζ₅²` (Conrey `1951.908`). -/
noncomputable def chi : MulChar (ZMod 1951) ℂ :=
  MulChar.ofRootOfUnity zeta5sqUnit_mem three_generates

theorem chi_three_unit : chi three = (zeta5sqUnit : ℂ) :=
  MulChar.ofRootOfUnity_spec zeta5sqUnit_mem three_generates

theorem chi_three : chi 3 = zeta5 ^ 2 := by
  have h := chi_three_unit
  rw [three_coe] at h
  exact h

theorem chi_two : chi 2 = zeta5 ^ 3 := char_two chi zeta5_pow_five chi_three

theorem chi_neg_one : chi (-1) = 1 := char_neg_one chi zeta5_pow_five chi_three

end Artin1951
