/-
Copyright (c) 2026 Dula. All rights reserved.
Released under Apache 2.0 license.
-/
import Mathlib.Analysis.Complex.Basic
import Mathlib.Data.Multiset.Basic
import Mathlib.GroupTheory.SpecificGroups.Alternating

/-!
# The arithmetic core of Step 2 in the proof of Theorem A″

In the proof of Theorem A″ (one quadratic and one cyclic field of odd prime degree `ℓ`), Step 2
shows that the sign `s_p` is `1`.  At a prime `p` inert in `C`, with eigenvalues `{a, b}` of
`ρ(Frob_p)`, Lemma 3.6(b) gives `{s a^ℓ, s b^ℓ} = {a^ℓ, b^ℓ}` (as `ℓ` is odd).  If `s = -1`, then
`b/a` would be a root of unity of order `2ℓ ≥ 6`; but `b/a` has the order of the image of
`Frob_p` in the projective image `A₅`, whose elements have order `1, 2, 3` or `5`.

This file proves, with no `sorry`:
* `Artin1951.alternatingGroup_five_orders`: every element `g` of `A₅` satisfies `g ^ 2 = 1`,
  `g ^ 3 = 1` or `g ^ 5 = 1`;
* `Artin1951.sign_core`: if `a ≠ 0`, `(b/a)^n = 1` for some `n ∈ {1, 2, 3, 5}`, `ℓ` is odd and
  `{-a^ℓ, -b^ℓ} = {a^ℓ, b^ℓ}` as multisets, then `a + b = 0`, i.e. `ρ_p ≅ ρ_p ⊗ unr(-1)` and the
  sign does not matter at `p`.
-/

namespace Artin1951

/-- Element orders in `A₅` divide `2`, `3` or `5`. -/
theorem alternatingGroup_five_orders (g : alternatingGroup (Fin 5)) :
    g ^ 2 = 1 ∨ g ^ 3 = 1 ∨ g ^ 5 = 1 := by
  revert g
  decide +kernel

/-- The arithmetic core of Step 2 of the proof of Theorem A″. -/
theorem sign_core {ℓ : ℕ} (hℓ : Odd ℓ) {a b : ℂ} (ha : a ≠ 0)
    (hord : b / a = 1 ∨ (b / a) ^ 2 = 1 ∨ (b / a) ^ 3 = 1 ∨ (b / a) ^ 5 = 1)
    (hms : ({-(a ^ ℓ), -(b ^ ℓ)} : Multiset ℂ) = {a ^ ℓ, b ^ ℓ}) : a + b = 0 := by
  have hmem : -(a ^ ℓ) ∈ ({a ^ ℓ, b ^ ℓ} : Multiset ℂ) := by
    rw [← hms]; exact Multiset.mem_cons_self _ _
  simp only [Multiset.insert_eq_cons, Multiset.mem_cons, Multiset.mem_singleton] at hmem
  have haℓ : a ^ ℓ ≠ 0 := pow_ne_zero ℓ ha
  rcases hmem with h | h
  · -- `-(a^ℓ) = a^ℓ` forces `a^ℓ = 0`
    exact absurd (by linear_combination (-1 / 2 : ℂ) * h : a ^ ℓ = 0) haℓ
  · -- `b^ℓ = -(a^ℓ)`, so `u = b/a` has `u^ℓ = -1`
    set u := b / a with hu
    have hb : b = u * a := by rw [hu]; field_simp
    have huℓ : u ^ ℓ = -1 := by
      have : u ^ ℓ * a ^ ℓ = -1 * a ^ ℓ := by rw [← mul_pow, ← hb, ← h]; ring
      exact mul_right_cancel₀ haℓ this
    obtain ⟨k, rfl⟩ := hℓ
    rcases hord with h1 | h2 | h3 | h5
    · rw [h1, one_pow] at huℓ; norm_num at huℓ
    · -- `u² = 1` and `u^(2k+1) = -1` give `u = -1`
      have : u = -1 := by rw [pow_succ, pow_mul, h2, one_pow, one_mul] at huℓ; exact huℓ
      rw [hb, this]; ring
    · have : (u ^ (2 * k + 1)) ^ 3 = (u ^ 3) ^ (2 * k + 1) := by rw [← pow_mul, ← pow_mul, mul_comm]
      rw [huℓ, h3, one_pow] at this; norm_num at this
    · have : (u ^ (2 * k + 1)) ^ 5 = (u ^ 5) ^ (2 * k + 1) := by rw [← pow_mul, ← pow_mul, mul_comm]
      rw [huℓ, h5, one_pow] at this; norm_num at this

end Artin1951
