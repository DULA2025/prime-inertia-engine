/-
Copyright (c) 2026 Dula. All rights reserved.
Released under Apache 2.0 license.
-/
import Mathlib.FieldTheory.Galois.Basic
import Mathlib.FieldTheory.Fixed
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.RingTheory.Frobenius
import Mathlib.RingTheory.Ideal.Over
import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff
import Mathlib.LinearAlgebra.Matrix.GeneralLinearGroup.Defs
import Mathlib.NumberTheory.ArithmeticFunction.LFunction
import Mathlib.NumberTheory.LSeries.Basic
import Mathlib.RingTheory.PowerSeries.Inverse
import Mathlib.Analysis.Calculus.FDeriv.Basic
import Artin1951.Character
import Artin1951.Quintic

/-!
# Artin's conjecture for the even icosahedral representation of conductor 1951: the statement

This file states, as a `Prop`, Artin's holomorphy conjecture for the two-dimensional complex
representation `ρ` of `Gal(ℚ̄/ℚ)` of conductor `1951` with projective image `A₅` (Doud–Moore).
It proves nothing about it; `README.md` lists what the other files of the project prove and
what they do not.

## Representations and their L-functions

An Artin representation of dimension two is given here through a finite Galois extension `N/ℚ`
through which it factors: `ρ : Gal(N/ℚ) →* GL₂(ℂ)` (`Artin1951.ArtinRep2`).  Its L-function is
the Euler product, over the primes `p`, of `det(1 - ρ(Frob_Q) p^{-s} | V^{I_Q})⁻¹`, where `Q` is a
prime of `𝓞 N` above `p`, `I_Q` its inertia group and `Frob_Q` an arithmetic Frobenius at `Q`
(Mathlib's `IsArithFrobAt`).  The factor on the inertia invariants `V^{I_Q}` is written with the
averaging projector `e_Q = |I_Q|⁻¹ ∑_{τ ∈ I_Q} ρ(τ)`, which commutes with `ρ(Frob_Q)`:
`det(1 - ρ(Frob_Q) T | V^{I_Q}) = det(1 - ρ(Frob_Q) e_Q T)`, Mathlib's `Matrix.charpolyRev`.
The Euler product is a formal Dirichlet series (`ArithmeticFunction.eulerProduct`, as for the
L-function of an elliptic curve in Mathlib), and `L(ρ, s)` is its `LSeries`, which converges for
`Re s > 1`.

`ArtinRep2.ArtinHolds`: there is an entire function equal to `L(ρ, s)` on `Re s > 1`.

## Which `ρ`

`ArtinRep2.IsRho1951` lists properties that determine `ρ` up to isomorphism (§2 of the note):
* the field cut out by the projective representation is the splitting field of
  `f₅ = X⁵ − X⁴ − 780X³ − 1795X² + 3106X + 344` (Galois group `A₅`);
* `det ρ = χ`, written as `det ρ(Frob_Q) = χ(p)` at every prime `Q` above `p ≠ 1951`;
* `ρ` is unramified outside `1951`, and at a prime above `1951` the inertia invariants have
  dimension `1` (trace of `e_Q` equal to `1`).
The lifts of the projective representation with determinant `χ` are `ρ`, `ρ''⊗χ³` (the
`√5`-conjugate) and their quadratic twists; the last two conditions leave only `ρ`.

`Artin1951.ArtinConjecture1951 : Prop` says that every `A` with these properties satisfies
`ArtinHolds`.  `Artin1951.Rho1951Exists : Prop` says that such an `A` exists (Doud–Moore;
not formalized here).
-/

namespace Artin1951

open Polynomial NumberField

/-- A two-dimensional complex Artin representation of `Gal(ℚ̄/ℚ)`, through a finite Galois
extension `N/ℚ` through which it factors. -/
structure ArtinRep2 where
  /-- A finite Galois extension of `ℚ` through which the representation factors. -/
  N : Type
  [instField : Field N]
  [instNumberField : NumberField N]
  [instGalois : IsGalois ℚ N]
  /-- The representation of `Gal(N/ℚ)`. -/
  ρ : (N ≃ₐ[ℚ] N) →* GL (Fin 2) ℂ

attribute [instance] ArtinRep2.instField ArtinRep2.instNumberField ArtinRep2.instGalois

namespace ArtinRep2

variable (A : ArtinRep2)

/-- `Gal(N/ℚ)`. -/
abbrev G : Type := A.N ≃ₐ[ℚ] A.N

/-- The matrix `ρ(g)`. -/
abbrev mat (g : A.G) : Matrix (Fin 2) (Fin 2) ℂ := ((A.ρ g : GL (Fin 2) ℂ) : Matrix (Fin 2) (Fin 2) ℂ)

/-- The primes of `𝓞 N` above the rational prime `p`. -/
abbrev primesAbove (p : ℕ) : Set (Ideal (𝓞 A.N)) :=
  Ideal.primesOver (Ideal.span {(p : ℤ)}) (𝓞 A.N)

/-- A chosen prime of `𝓞 N` above `p`. -/
noncomputable def chosenPrime (p : ℕ) : Ideal (𝓞 A.N) :=
  Classical.epsilon fun Q => Q ∈ A.primesAbove p

/-- A chosen arithmetic Frobenius at `Q`: `σ x ≡ x ^ #(ℤ/(Q ∩ ℤ)) (mod Q)` for all `x ∈ 𝓞 N`. -/
noncomputable def frob (Q : Ideal (𝓞 A.N)) : A.G :=
  Classical.epsilon fun σ : A.G => IsArithFrobAt ℤ σ Q

/-- The inertia group `I_Q = {g | ∀ x, g x - x ∈ Q}`. -/
abbrev inertia (Q : Ideal (𝓞 A.N)) : Subgroup A.G := Q.inertia A.G

open Classical in
/-- The averaging projector `e_Q = |I_Q|⁻¹ ∑_{τ ∈ I_Q} ρ(τ)` onto the inertia invariants. -/
noncomputable def invProj (Q : Ideal (𝓞 A.N)) : Matrix (Fin 2) (Fin 2) ℂ :=
  ((Finset.univ.filter (· ∈ A.inertia Q)).card : ℂ)⁻¹ •
    ∑ τ ∈ Finset.univ.filter (· ∈ A.inertia Q), A.mat τ

/-- The local polynomial `det(1 - ρ(Frob_Q) T | V^{I_Q})` at the rational prime `p`. -/
noncomputable def localPoly (p : ℕ) : ℂ[X] :=
  Matrix.charpolyRev (A.mat (A.frob (A.chosenPrime p)) * A.invProj (A.chosenPrime p))

/-- The Artin L-function of `ρ` as a formal Dirichlet series:
`∏_p (1 / det(1 - ρ(Frob_p) p^{-s} | V^{I_p}))`. -/
noncomputable def LFunction : ArithmeticFunction ℂ :=
  ArithmeticFunction.eulerProduct fun p : Nat.Primes =>
    ArithmeticFunction.ofPowerSeries (p : ℕ)
      (PowerSeries.invOfUnit ((A.localPoly p : ℂ[X]) : PowerSeries ℂ) 1)

/-- `L(ρ, s)`, the sum of the Dirichlet series (meaningful for `Re s > 1`). -/
noncomputable def LSeries (s : ℂ) : ℂ := _root_.LSeries (fun n => A.LFunction n) s

/-- Artin's holomorphy conjecture for `ρ`: `L(ρ, s)` extends to an entire function. -/
def ArtinHolds : Prop :=
  ∃ F : ℂ → ℂ, Differentiable ℂ F ∧ ∀ s : ℂ, 1 < s.re → F s = A.LSeries s

/-- The kernel of the projective representation: elements acting by scalars. -/
def projKer : Subgroup A.G := (Subgroup.center (GL (Fin 2) ℂ)).comap A.ρ

/-- The field cut out by the projective representation. -/
def projField : IntermediateField ℚ A.N := IntermediateField.fixedField A.projKer

/-- The field generated over `ℚ` by the roots of `f₅` in `N`. -/
noncomputable def f5Field : IntermediateField ℚ A.N := IntermediateField.adjoin ℚ (f5Q.rootSet A.N)

/-- Properties that determine the even icosahedral representation of conductor `1951` up to
isomorphism. -/
structure IsRho1951 : Prop where
  /-- `f₅` splits in `N`. -/
  splits : (f5Q.map (algebraMap ℚ A.N)).Splits
  /-- The projective representation cuts out the splitting field of `f₅`. -/
  projField_eq : A.projField = A.f5Field
  /-- `ρ` is unramified outside `1951`. -/
  unramified : ∀ p : ℕ, p.Prime → p ≠ 1951 → ∀ Q ∈ A.primesAbove p, A.inertia Q ≤ A.ρ.ker
  /-- `det ρ = χ`: `det ρ(Frob_Q) = χ(p)` for every prime `Q` above `p ≠ 1951`. -/
  det_frob : ∀ p : ℕ, p.Prime → p ≠ 1951 → ∀ Q ∈ A.primesAbove p, ∀ σ : A.G,
    IsArithFrobAt ℤ σ Q → (A.mat σ).det = chi (p : ZMod 1951)
  /-- At the primes above `1951` the inertia invariants are one-dimensional: the trace of the
  idempotent `e_Q` is the dimension of its image.  (For `ρ` the image has order `600`, prime to
  `1951`, so the ramification is tame and the conductor exponent is `1`.) -/
  tame_1951 : ∀ Q ∈ A.primesAbove 1951, (A.invProj Q).trace = 1

end ArtinRep2

/-- **Artin's conjecture for the even icosahedral representation of conductor 1951.**
Every two-dimensional Artin representation with the properties of `ρ` has an entire L-function.
This is a statement only; it is not proved here. -/
def ArtinConjecture1951 : Prop :=
  ∀ A : ArtinRep2, A.IsRho1951 → A.ArtinHolds

/-- Such a representation exists (Doud–Moore). A statement only; not formalized here. -/
def Rho1951Exists : Prop :=
  ∃ A : ArtinRep2, A.IsRho1951

end Artin1951
