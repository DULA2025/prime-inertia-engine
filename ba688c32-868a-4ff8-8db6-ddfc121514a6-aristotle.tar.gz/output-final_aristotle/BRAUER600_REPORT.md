# An effective identity for `G = SL(2,5) × C₅` (order 600)

Artin's conjecture is **not** attempted. The even icosahedral case stays **OPEN**: nothing
here shows that `L(s, ρ)` is entire.

All files are under `RequestProject/Brauer600/`. They contain no `sorry` and add no axioms;
`#print axioms` reports only `propext`, `Classical.choice`, `Quot.sound`. The finite checks
use `decide +kernel` (no `native_decide`). The cited analytic theorems are hypotheses
(the structure `CitedTask2`), not axioms.

## Input (explicit, finite)

* `Cyc.lean`: exact arithmetic in `ℤ[ζ₅]`, as 4 integer coordinates in the basis
  `1, ζ, ζ², ζ³`, with `φ = -(ζ²+ζ³)`. `Cyc.toComplex` (`ζ ↦ e^{2πi/5}`) is proved additive,
  multiplicative, and compatible with complex conjugation. So identities checked in `Cyc`
  are identities of complex numbers.
* `Table.lean`: the character table of `SL(2,5)`:
  * classes `1a, 2a, 4a, 3a, 6a, 5a, 5b, 10a, 10b`, of sizes `1, 1, 30, 20, 20, 12, 12, 12, 12`;
  * irreducibles `1, 2, 2', 3, 3', 4, 4', 5, 6`, with values in `ℤ[φ]`.

  The characters of `G` are `χ_j ⊠ ψ^m`, and `ρ = chi (1,3) = 2 ⊠ ψ³`.
  **Labelling:** `4 = Sym³ 2` is the *faithful* 4-dimensional character and
  `4' = 2 ⊗ 2'` is trivial on `-I`. The faithful one is the one that occurs in the `H₁₀` term
  and in the witness; you call it `4'`.
* `Orthonormality.lean`: `chi_orthonormal` checks all `45 × 45` relations
  `⟨χ, χ'⟩ = δ` by exact arithmetic. So the table really is orthonormal, and multiplicity
  vectors are unique.
* `Induction.lean`: induced class functions are defined by the standard formula
  `Ind_H^G f(K) = |G|/(|H||K|) · Σ_{h∈H∩K} f(h)`. Here `|H|` and the class sums are input
  (the fusion of `H`).
  * Class sums for cyclic subgroups are *computed* from the table's power maps.
  * `timesC5_ind_eq_toCF` proves, for every `H`, every `f` and every `m`, that
    `Ind_{H×C₅}^G(f⊠ψ^m) = (Ind_H^{SL(2,5)} f) ⊠ ψ^m`.
  * **Frobenius reciprocity is not used** (neither proved nor cited). Multiplicities are
    certified by checking `Ind = Σ m(π) π` exactly as class functions.

## Task 1: `Identity.lean`

The choices are `λ(s) = e^{2πi/10}` on `H₁₀ = ⟨s⟩` with `s ∈ 10a`, and `λ' = 1`, so that
`σ = 2|_{H₂₄}` with `H₂₄ ≅ SL(2,3)`. `h24_sigma_irreducible` checks
`Σ_{h ∈ H₂₄} |σ(h)|² = 24`.

`effective_identity` (exact identity of class functions on `G`):

```
reg_G + 4ρ = Σ_{j∈{0,1,2,4}} Ind_{1×C₅}(1⊠ψ^j) + Ind_{Z×C₅}(1⊠ψ³)
           + 4·Ind_{H₁₀×C₅}(λ⊠ψ³) + 2·Ind_{H₂₄×C₅}(σ⊠ψ³)
```

All coefficients are nonnegative. The multiplicities are as follows (in this labelling):

* `ind_h10_eq`: the `H₁₀` term is `ρ + 4⊠ψ³ + 6⊠ψ³`.
* `ind_h24_eq`: the `H₂₄` term is `ρ + ρ' + 6⊠ψ³`.
* `ind_z_eq`: the `Z` term is `(1 + 3·3 + 3·3' + 4·4' + 5·5)⊠ψ³`, i.e. each irreducible of
  `SL(2,5)/{±I} ≅ A₅` with multiplicity equal to its degree.

The same identity is also proved over `ℂ` (`effective_identity_complex`) and in the
representation ring (`effective_identity_mult`).

## Task 2: `LFunction.lean` (conditional on cited hypotheses)

`CitedTask2 L ζ_N` packages the cited inputs:

* Artin additivity;
* `ζ_N = L(reg_G)`;
* inductivity + Hecke: `(s−1)·ζ_{N^{1×C₅}}` is entire, and the Hecke L-functions of the
  nontrivial linear characters `ψ^j` (`j ≠ 0`), `1⊠ψ³` and `λ⊠ψ³` are entire;
* inductivity + Langlands–Tunnell over `N^{H₂₄×C₅}` for `σ⊠ψ³`.

From these:

* `entire_mul_zetaN`: `(s−1)·ζ_N(s)·L(s,ρ)⁴` agrees on `Re s > 1` with an entire function.
* `zetaN_zero_order_ge`: assume `ζ_N` and `L(s,ρ)` have meromorphic continuations. If
  `L(s,ρ)` has a pole of order `m` at `s₀ ≠ 1`, then `ord_{s₀} ζ_N ≥ 4m`.

**OPEN:** excluding such compensated poles. Entirety of `L(s,ρ)` is not concluded.

## Task 3: `Witness.lean`

The witness is `n = −(2 + 2' + 4)⊠ψ³ + 2·(6⊠ψ³)`.

* `witness_dim`: `Σ dim(π) n(π) = 4`.
* `witness_rho`: `n(ρ) = −1`.
* `witness_nonneg`: for every entry of `linearData` (47 entries: all linear characters of all
  subgroups of `SL(2,5)` up to conjugacy) and of `ltData` (10 entries: all 2-dimensional
  irreducibles of the proper subgroups `Q₈, Dic₃, Dic₅, SL(2,3)`), and for every `j ∈ ℤ/5`,
  `Φ = Ind_{H×C₅}(f⊠ψ^j)` satisfies `Σ_π ⟨π,Φ⟩ n(π) ≥ 0`.
* `optimality`: whenever `c·reg_G + k·ρ = Σ a_t Φ_t` with `a_t ≥ 0` and the `Φ_t` taken from
  these lists, `k ≤ 4c`. So no identity of this form forces a zero of `ζ_N` of order `> 4m`
  at a pole of order `m`.

**Cited, not verified in Lean:**

* the list of subgroups of `SL(2,5)` up to conjugacy, and their linear and 2-dimensional
  irreducible characters (class sums written out in `Witness.lean`, with derivations in the
  docstring);
* irreducibility of the 2-dimensional characters that are not restrictions of `2`.

Completeness of the lists is likewise not proved in Lean.

## Why it stops

The identity is effective, but it contains `reg_G`. All it gives is that a pole of `L(s,ρ)`
off `s = 1` must be cancelled by a zero of `ζ_N` of four times its order. The cited
theorems say nothing that excludes zeros of `ζ_N` at poles of `L(s,ρ)`. `optimality` shows
that the factor 4 cannot be improved by any nonnegative combination of these induced
characters. Excluding the compensated poles is the OPEN step.
