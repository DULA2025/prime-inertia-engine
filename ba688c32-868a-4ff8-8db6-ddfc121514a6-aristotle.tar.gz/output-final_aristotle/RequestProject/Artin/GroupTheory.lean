module

public import Mathlib

/-!
# Finite group theory behind the case division

The five isomorphism types of finite subgroups of `PGL₂(ℂ)` (Klein):
cyclic, dihedral `D_n` (`n ≥ 2`), `A₄`, `S₄`, `A₅`.

We prove here, completely:
* the five classes are pairwise disjoint (`disjoint_*`);
* `S₄` and `A₄` are solvable (`perm_fin4_isSolvable`, `alternating_fin4_isSolvable`);
* `A₅` is **not** solvable (`alternating_fin5_not_isSolvable`) — this is exactly
  the step at which the Langlands–Tunnell input fails;
* `A₅` has no subgroup of index `2` (`alternating_fin5_no_index_two`) — so an
  icosahedral projective representation is not induced from a quadratic field.
-/

@[expose] public section

open Equiv

namespace ArtinHolomorphy

/-! ## The five Klein types, as predicates on an abstract group -/

/-- `H` is isomorphic to a dihedral group `D_n` of order `2n`, `n ≥ 2`
(`D_2` is the Klein four-group; `D_1 ≅ C_2` is counted as cyclic). -/
def IsDihedralType (H : Type*) [Group H] : Prop :=
  ∃ n : ℕ, 2 ≤ n ∧ Nonempty (H ≃* DihedralGroup n)

/-- `H ≅ A₄` (tetrahedral). -/
def IsTetrahedralType (H : Type*) [Group H] : Prop :=
  Nonempty (H ≃* alternatingGroup (Fin 4))

/-- `H ≅ S₄` (octahedral). -/
def IsOctahedralType (H : Type*) [Group H] : Prop :=
  Nonempty (H ≃* Perm (Fin 4))

/-- `H ≅ A₅` (icosahedral). -/
def IsIcosahedralType (H : Type*) [Group H] : Prop :=
  Nonempty (H ≃* alternatingGroup (Fin 5))

/-! ## Element-order facts, checked by finite enumeration in the kernel -/

lemma perm4_pow : ∀ g : Perm (Fin 4), g ^ 4 = 1 ∨ g ^ 6 = 1 := by
  decide +kernel

lemma perm4_even_pow : ∀ g : Perm (Fin 4), Perm.sign g = 1 → g ^ 2 = 1 ∨ g ^ 3 = 1 := by
  decide +kernel

lemma perm5_even_pow :
    ∀ g : Perm (Fin 5), Perm.sign g = 1 → g ^ 6 = 1 ∨ g ^ 10 = 1 ∨ g ^ 15 = 1 := by
  decide +kernel

lemma alt4_pow (g : alternatingGroup (Fin 4)) : g ^ 2 = 1 ∨ g ^ 3 = 1 := by
  rcases perm4_even_pow g.1 g.2 with h | h
  · exact Or.inl (Subtype.ext (by simpa using h))
  · exact Or.inr (Subtype.ext (by simpa using h))

lemma alt5_pow (g : alternatingGroup (Fin 5)) : g ^ 6 = 1 ∨ g ^ 10 = 1 ∨ g ^ 15 = 1 := by
  rcases perm5_even_pow g.1 g.2 with h | h | h
  · exact Or.inl (Subtype.ext (by simpa using h))
  · exact Or.inr (Or.inl (Subtype.ext (by simpa using h)))
  · exact Or.inr (Or.inr (Subtype.ext (by simpa using h)))

lemma dihedral2_pow : ∀ g : DihedralGroup 2, g ^ 2 = 1 := by decide

lemma card_alt4 : Nat.card (alternatingGroup (Fin 4)) = 12 := by
  rw [nat_card_alternatingGroup]; simp [Nat.factorial]

lemma card_perm4 : Nat.card (Perm (Fin 4)) = 24 := by
  rw [Nat.card_perm]; simp [Nat.factorial]

lemma card_alt5 : Nat.card (alternatingGroup (Fin 5)) = 60 := by
  rw [nat_card_alternatingGroup]; simp [Nat.factorial]

/-- If every element of `G` satisfies `g^a = 1 ∨ g^b = 1 ∨ g^c = 1`, then `G` has
no element of order `m` when `m` divides none of `a, b, c`. -/
lemma no_elem_of_order {G : Type*} [Group G] {a b c m : ℕ}
    (hG : ∀ g : G, g ^ a = 1 ∨ g ^ b = 1 ∨ g ^ c = 1)
    (ha : ¬ m ∣ a) (hb : ¬ m ∣ b) (hc : ¬ m ∣ c) (g : G) : orderOf g ≠ m := by
  rintro rfl
  rcases hG g with h | h | h
  · exact ha (orderOf_dvd_of_pow_eq_one h)
  · exact hb (orderOf_dvd_of_pow_eq_one h)
  · exact hc (orderOf_dvd_of_pow_eq_one h)

lemma alt4_no_order {m : ℕ} (h2 : ¬ m ∣ 2) (h3 : ¬ m ∣ 3) (g : alternatingGroup (Fin 4)) :
    orderOf g ≠ m :=
  no_elem_of_order (a := 2) (b := 3) (c := 3)
    (fun g => (alt4_pow g).elim Or.inl (fun h => Or.inr (Or.inl h))) h2 h3 h3 g

lemma perm4_no_order {m : ℕ} (h4 : ¬ m ∣ 4) (h6 : ¬ m ∣ 6) (g : Perm (Fin 4)) :
    orderOf g ≠ m :=
  no_elem_of_order (a := 4) (b := 6) (c := 6)
    (fun g => (perm4_pow g).elim Or.inl (fun h => Or.inr (Or.inl h))) h4 h6 h6 g

lemma alt5_no_order {m : ℕ} (h6 : ¬ m ∣ 6) (h10 : ¬ m ∣ 10) (h15 : ¬ m ∣ 15)
    (g : alternatingGroup (Fin 5)) : orderOf g ≠ m :=
  no_elem_of_order alt5_pow h6 h10 h15 g

/-! ## Pairwise disjointness of the five classes -/

lemma card_eq_of_iso {G H : Type*} [Group G] [Group H] (e : G ≃* H) :
    Nat.card G = Nat.card H := Nat.card_congr e.toEquiv

/-- A cyclic group of order `N` has an element of order `N`, which we transport. -/
lemma cyclic_exists_order {G H : Type*} [Group G] [Group H] [IsCyclic G] (e : G ≃* H) :
    ∃ h : H, orderOf h = Nat.card H := by
  obtain ⟨g, hg⟩ := IsCyclic.exists_ofOrder_eq_natCard (α := G)
  exact ⟨e g, by rw [MulEquiv.orderOf_eq, hg, card_eq_of_iso e]⟩

theorem disjoint_cyclic_dihedral (H : Type*) [Group H] (hc : IsCyclic H)
    (hd : IsDihedralType H) : False := by
  obtain ⟨n, hn, ⟨e⟩⟩ := hd
  haveI : IsCyclic (DihedralGroup n) := isCyclic_of_surjective e.toMonoidHom e.surjective
  rcases Nat.lt_or_ge n 3 with h | h
  · obtain rfl : n = 2 := by omega
    obtain ⟨g, hg⟩ := IsCyclic.exists_ofOrder_eq_natCard (α := DihedralGroup 2)
    rw [DihedralGroup.nat_card] at hg
    have := orderOf_dvd_of_pow_eq_one (dihedral2_pow g)
    rw [hg] at this; norm_num at this
  · apply DihedralGroup.not_commutative (n := n) (by omega) (by omega)
    exact ⟨fun a b => (IsCyclic.commGroup (α := DihedralGroup n)).mul_comm a b⟩

theorem disjoint_cyclic_tetrahedral (H : Type*) [Group H] (hc : IsCyclic H)
    (ht : IsTetrahedralType H) : False := by
  obtain ⟨e⟩ := ht
  obtain ⟨g, hg⟩ := cyclic_exists_order e
  rw [card_alt4] at hg
  exact alt4_no_order (by norm_num) (by norm_num) g hg

theorem disjoint_cyclic_octahedral (H : Type*) [Group H] (hc : IsCyclic H)
    (ho : IsOctahedralType H) : False := by
  obtain ⟨e⟩ := ho
  obtain ⟨g, hg⟩ := cyclic_exists_order e
  rw [card_perm4] at hg
  exact perm4_no_order (by norm_num) (by norm_num) g hg

theorem disjoint_cyclic_icosahedral (H : Type*) [Group H] (hc : IsCyclic H)
    (hi : IsIcosahedralType H) : False := by
  obtain ⟨e⟩ := hi
  obtain ⟨g, hg⟩ := cyclic_exists_order e
  rw [card_alt5] at hg
  exact alt5_no_order (by norm_num) (by norm_num) (by norm_num) g hg

/-- Dihedral vs. a group `X` of order `2k` with no element of order `k`. -/
lemma dihedral_order_aux {H X : Type*} [Group H] [Group X] (hd : IsDihedralType H)
    (e' : H ≃* X) {k : ℕ} (hk : Nat.card X = 2 * k)
    (hX : ∀ g : X, orderOf g ≠ k) : False := by
  obtain ⟨n, -, ⟨e⟩⟩ := hd
  have hc : 2 * n = 2 * k := by
    rw [← DihedralGroup.nat_card, ← hk, ← card_eq_of_iso e, card_eq_of_iso e']
  obtain rfl : n = k := by omega
  apply hX ((e.symm.trans e') (DihedralGroup.r 1))
  rw [MulEquiv.orderOf_eq, DihedralGroup.orderOf_r_one]

theorem disjoint_dihedral_tetrahedral (H : Type*) [Group H] (hd : IsDihedralType H)
    (ht : IsTetrahedralType H) : False := by
  obtain ⟨e⟩ := ht
  exact dihedral_order_aux hd e (k := 6) (by rw [card_alt4])
    (alt4_no_order (by norm_num) (by norm_num))

theorem disjoint_dihedral_octahedral (H : Type*) [Group H] (hd : IsDihedralType H)
    (ho : IsOctahedralType H) : False := by
  obtain ⟨e⟩ := ho
  exact dihedral_order_aux hd e (k := 12) (by rw [card_perm4])
    (perm4_no_order (by norm_num) (by norm_num))

theorem disjoint_dihedral_icosahedral (H : Type*) [Group H] (hd : IsDihedralType H)
    (hi : IsIcosahedralType H) : False := by
  obtain ⟨e⟩ := hi
  exact dihedral_order_aux hd e (k := 30) (by rw [card_alt5])
    (alt5_no_order (by norm_num) (by norm_num) (by norm_num))

theorem disjoint_tetrahedral_octahedral (H : Type*) [Group H] (ht : IsTetrahedralType H)
    (ho : IsOctahedralType H) : False := by
  obtain ⟨e⟩ := ht; obtain ⟨f⟩ := ho
  have := (card_eq_of_iso e).symm.trans (card_eq_of_iso f)
  rw [card_alt4, card_perm4] at this; norm_num at this

theorem disjoint_tetrahedral_icosahedral (H : Type*) [Group H] (ht : IsTetrahedralType H)
    (hi : IsIcosahedralType H) : False := by
  obtain ⟨e⟩ := ht; obtain ⟨f⟩ := hi
  have := (card_eq_of_iso e).symm.trans (card_eq_of_iso f)
  rw [card_alt4, card_alt5] at this; norm_num at this

theorem disjoint_octahedral_icosahedral (H : Type*) [Group H] (ho : IsOctahedralType H)
    (hi : IsIcosahedralType H) : False := by
  obtain ⟨e⟩ := ho; obtain ⟨f⟩ := hi
  have := (card_eq_of_iso e).symm.trans (card_eq_of_iso f)
  rw [card_perm4, card_alt5] at this; norm_num at this

/-! ## Solvability: `S₄`, `A₄` solvable; `A₅` not -/

/-- The Klein four-group `V₄ ⊴ S₄`, as a finite set of permutations. -/
def V4set : Finset (Perm (Fin 4)) :=
  {1, swap 0 1 * swap 2 3, swap 0 2 * swap 1 3, swap 0 3 * swap 1 2}

/-- `V₄` as a subgroup of `S₄`. -/
def V4 : Subgroup (Perm (Fin 4)) where
  carrier := {g | g ∈ V4set}
  one_mem' := by decide
  mul_mem' := by
    have : ∀ a ∈ V4set, ∀ b ∈ V4set, a * b ∈ V4set := by decide
    exact fun {a b} ha hb => this a ha b hb
  inv_mem' := by
    have : ∀ a ∈ V4set, a⁻¹ ∈ V4set := by decide
    exact fun {a} ha => this a ha

lemma commutator_even_mem_V4 :
    ∀ a b : Perm (Fin 4), Perm.sign a = 1 → Perm.sign b = 1 → a * b * a⁻¹ * b⁻¹ ∈ V4set := by
  decide +kernel

lemma V4set_comm : ∀ a ∈ V4set, ∀ b ∈ V4set, a * b * a⁻¹ * b⁻¹ = 1 := by decide +kernel

/-- `S₄` is solvable: `S₄ ⊵ A₄ ⊵ V₄ ⊵ 1` with abelian quotients. -/
theorem perm_fin4_isSolvable : IsSolvable (Perm (Fin 4)) := by
  rw [isSolvable_def]
  refine ⟨3, ?_⟩
  have h1 : derivedSeries (Perm (Fin 4)) 1 ≤ alternatingGroup (Fin 4) := by
    rw [derivedSeries_succ, derivedSeries_zero, Subgroup.commutator_le]
    intro a _ b _
    have key : ∀ u v : ℤˣ, u * v * u * v = 1 := by decide
    simp [Equiv.Perm.mem_alternatingGroup, commutatorElement_def, key]
  have h2 : derivedSeries (Perm (Fin 4)) 2 ≤ V4 := by
    rw [derivedSeries_succ]
    refine (Subgroup.commutator_mono h1 h1).trans ?_
    rw [Subgroup.commutator_le]
    intro a ha b hb
    rw [commutatorElement_def]
    exact commutator_even_mem_V4 a b ha hb
  have h3 : derivedSeries (Perm (Fin 4)) 3 ≤ ⊥ := by
    rw [derivedSeries_succ]
    refine (Subgroup.commutator_mono h2 h2).trans ?_
    rw [Subgroup.commutator_le]
    intro a ha b hb
    rw [commutatorElement_def, Subgroup.mem_bot]
    exact V4set_comm a ha b hb
  exact le_bot_iff.mp h3

theorem alternating_fin4_isSolvable : IsSolvable (alternatingGroup (Fin 4)) := by
  haveI := perm_fin4_isSolvable
  infer_instance

/-- `A₅` is not solvable (it is simple and non-abelian). **This is the precise point at
which any argument through solvable base change (Langlands–Tunnell) breaks down.** -/
theorem alternating_fin5_not_isSolvable : ¬ IsSolvable (alternatingGroup (Fin 5)) := by
  intro h
  apply Equiv.Perm.fin_5_not_solvable
  refine solvable_of_ker_le_range (alternatingGroup (Fin 5)).subtype
    (Perm.sign : Perm (Fin 5) →* ℤˣ) ?_
  intro g hg
  exact ⟨⟨g, by simpa [Equiv.Perm.mem_alternatingGroup] using hg⟩, rfl⟩

/-- `A₅` has no subgroup of index `2`. Consequently an icosahedral representation is
not induced from a character of an index-two subgroup (not monomial from a quadratic
field), so the dihedral (Hecke) argument is unavailable. -/
theorem alternating_fin5_no_index_two (H : Subgroup (alternatingGroup (Fin 5))) :
    H.index ≠ 2 := by
  intro h2
  haveI := Subgroup.normal_of_index_eq_two h2
  rcases alternatingGroup.isSimpleGroup_five.eq_bot_or_eq_top_of_normal H ‹_› with h | h
  · subst h
    rw [Subgroup.index_bot, card_alt5] at h2; norm_num at h2
  · subst h
    rw [Subgroup.index_top] at h2; norm_num at h2

/-- Solvability is invariant under isomorphism. -/
lemma isSolvable_of_iso {G H : Type*} [Group G] [Group H] (e : G ≃* H) [IsSolvable H] :
    IsSolvable G :=
  solvable_of_surjective (f := e.symm.toMonoidHom) e.symm.surjective

lemma IsTetrahedralType.isSolvable {H : Type*} [Group H] (h : IsTetrahedralType H) :
    IsSolvable H := by
  obtain ⟨e⟩ := h
  haveI := alternating_fin4_isSolvable
  exact isSolvable_of_iso e

lemma IsOctahedralType.isSolvable {H : Type*} [Group H] (h : IsOctahedralType H) :
    IsSolvable H := by
  obtain ⟨e⟩ := h
  haveI := perm_fin4_isSolvable
  exact isSolvable_of_iso e

lemma IsIcosahedralType.not_isSolvable {H : Type*} [Group H] (h : IsIcosahedralType H) :
    ¬ IsSolvable H := by
  obtain ⟨e⟩ := h
  intro hs
  exact alternating_fin5_not_isSolvable (isSolvable_of_iso e.symm)

end ArtinHolomorphy
