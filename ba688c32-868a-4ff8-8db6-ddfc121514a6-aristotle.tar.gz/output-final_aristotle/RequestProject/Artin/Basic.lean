module

public import RequestProject.Artin.GroupTheory

/-!
# Artin representations, projective image, parity, and the conjecture

* `ArtinRep K n` : continuous `ρ : G_K → GL_n(ℂ)` for the **discrete** topology on
  `GL_n(ℂ)`, where `G_K = Gal(K̄/K)` carries its Krull (profinite) topology.
* `ArtinRep.IsIrreducible` : no proper nonzero `ρ(G_K)`-stable subspace of `ℂⁿ`.
* `projImage ρ` : the image of `ρ` in `PGL₂(ℂ) = GL₂(ℂ)/center`.
* `complexConj` : a complex conjugation in `G_ℚ`, constructed from the embedding
  `ℚ̄ ≅ (algebraic closure of ℚ in ℂ) ⊆ ℂ`; `complexConj_spec` proves it is conjugation.
* `ArtinRep.IsEven`, `ArtinRep.IsOdd` : `det ρ(c) = +1` resp. `-1`.
* `ArtinHolomorphyConjecture` : the conjecture, for a given assignment `L` of
  (Euler-product) L-functions to Artin representations.

**About `L`.** Mathlib does not (yet) contain Artin L-functions (Frobenius classes
in `G_K`, inertia invariants, Artin's ramified local factors). We therefore keep the
L-function as an explicit parameter `L : ArtinRep K n → ℂ → ℂ`, meaning
"`L ρ s` is the Artin L-function `L(s, ρ)` (Artin / Neukirch ANT VII.10) for `Re s > 1`".
Every cited theorem in `RequestProject.Artin.Reduction` is likewise a hypothesis about
this same `L`; so every conditional result applies verbatim to the genuine Artin
L-function once it is supplied.
-/

@[expose] public section

open Matrix

namespace ArtinHolomorphy

/-- A continuous representation `G_K → GL_n(ℂ)`, continuity being for the discrete
topology on `GL_n(ℂ)` (equivalently: open kernel, equivalently finite image). -/
structure ArtinRep (K : Type*) [Field K] (n : ℕ) where
  /-- the underlying homomorphism `G_K → GL_n(ℂ)` -/
  toHom : Field.absoluteGaloisGroup K →* GL (Fin n) ℂ
  /-- continuity for the discrete topology `⊥` on `GL_n(ℂ)` -/
  continuous_discrete : @Continuous _ _ _ ⊥ toHom

namespace ArtinRep

variable {K : Type*} [Field K] {n : ℕ}

/-- Irreducibility: the only `ρ(G_K)`-stable subspaces of `ℂⁿ` are `0` and `ℂⁿ`. -/
def IsIrreducible (ρ : ArtinRep K n) : Prop :=
  ∀ W : Submodule ℂ (Fin n → ℂ),
    (∀ g, ∀ v ∈ W, ((ρ.toHom g : GL (Fin n) ℂ) : Matrix (Fin n) (Fin n) ℂ) *ᵥ v ∈ W) →
      W = ⊥ ∨ W = ⊤

/-- The kernel of an Artin representation is open. -/
lemma isOpen_ker (ρ : ArtinRep K n) : IsOpen (ρ.toHom.ker : Set (Field.absoluteGaloisGroup K)) := by
  have h := ρ.continuous_discrete
  have : (ρ.toHom.ker : Set (Field.absoluteGaloisGroup K)) = ρ.toHom ⁻¹' {1} := by
    ext g; simp
  rw [this]
  exact @Continuous.isOpen_preimage _ _ _ ⊥ _ h _ (@isOpen_discrete _ ⊥ (@DiscreteTopology.mk _ ⊥ rfl) _)

end ArtinRep

/-- `G_K` is compact (profinite), for `K` of characteristic zero. -/
instance (K : Type*) [Field K] [CharZero K] : CompactSpace (Field.absoluteGaloisGroup K) := by
  unfold Field.absoluteGaloisGroup; infer_instance

namespace ArtinRep

variable {K : Type*} [Field K] [CharZero K] {n : ℕ}

/-- An Artin representation has finite image. -/
lemma finite_range (ρ : ArtinRep K n) : Finite ρ.toHom.range := by
  haveI : Finite (Field.absoluteGaloisGroup K ⧸ ρ.toHom.ker) :=
    Subgroup.quotient_finite_of_isOpen _ ρ.isOpen_ker
  exact Finite.of_equiv _ (QuotientGroup.quotientKerEquivRange ρ.toHom).toEquiv

end ArtinRep

/-- `PGL₂(ℂ) = GL₂(ℂ) / Z(GL₂(ℂ))`. -/
abbrev PGL2 : Type := GL (Fin 2) ℂ ⧸ Subgroup.center (GL (Fin 2) ℂ)

/-- The projective image of a two-dimensional representation: its image in `PGL₂(ℂ)`. -/
noncomputable def projImage {K : Type*} [Field K] (ρ : ArtinRep K 2) : Subgroup PGL2 :=
  ρ.toHom.range.map (QuotientGroup.mk' (Subgroup.center (GL (Fin 2) ℂ)))

lemma projImage_finite {K : Type*} [Field K] [CharZero K] (ρ : ArtinRep K 2) : Finite (projImage ρ) := by
  haveI := ρ.finite_range
  refine Finite.of_surjective
    (fun x : ρ.toHom.range => (⟨QuotientGroup.mk' _ x.1, ⟨x.1, x.2, rfl⟩⟩ : projImage ρ)) ?_
  rintro ⟨y, x, hx, rfl⟩
  exact ⟨⟨x, hx⟩, rfl⟩

/-! ## The five projective types -/

/-- Klein's list of isomorphism types of finite subgroups of `PGL₂(ℂ)`. -/
inductive ProjType
  | cyclic | dihedral | tetrahedral | octahedral | icosahedral
  deriving DecidableEq

/-- `t.Holds H` : the group `H` is of type `t`. -/
def ProjType.Holds : ProjType → (H : Type) → [Group H] → Prop
  | .cyclic, H, _ => IsCyclic H
  | .dihedral, H, _ => IsDihedralType H
  | .tetrahedral, H, _ => IsTetrahedralType H
  | .octahedral, H, _ => IsOctahedralType H
  | .icosahedral, H, _ => IsIcosahedralType H

/-- **Klein's classification** (F. Klein, *Vorlesungen über das Ikosaeder*, 1884;
see also Serre, *Modular forms of weight one and Galois representations*, 1977, §4):
every finite subgroup of `PGL₂(ℂ)` is cyclic, dihedral, or isomorphic to `A₄`, `S₄`, `A₅`.
This is a theorem; it is *not formalized here* and enters only as a hypothesis. -/
def KleinClassification : Prop :=
  ∀ H : Subgroup PGL2, Finite H →
    IsCyclic H ∨ IsDihedralType H ∨ IsTetrahedralType H ∨ IsOctahedralType H ∨
      IsIcosahedralType H

/-! ## Complex conjugation and parity -/

/-- `ℚ̄ ≅ ` the algebraic closure of `ℚ` inside `ℂ`. -/
noncomputable def algClosureEquiv : AlgebraicClosure ℚ ≃ₐ[ℚ] algebraicClosure ℚ ℂ :=
  IsAlgClosure.equiv ℚ _ _

/-- The embedding `ι : ℚ̄ ↪ ℂ` used to define complex conjugation. -/
noncomputable def iota (x : AlgebraicClosure ℚ) : ℂ := ((algClosureEquiv x : algebraicClosure ℚ ℂ) : ℂ)

/-- Complex conjugation as a `ℚ`-automorphism of `ℂ`. -/
noncomputable def conjQ : ℂ ≃ₐ[ℚ] ℂ := Complex.conjAe.restrictScalars ℚ

/-- Complex conjugation restricted to the algebraic numbers in `ℂ`. -/
noncomputable def conjRes : Gal(algebraicClosure ℚ ℂ/ℚ) :=
  AlgEquiv.restrictNormalHom (algebraicClosure ℚ ℂ) conjQ

lemma conjRes_spec (y : algebraicClosure ℚ ℂ) :
    ((conjRes y : algebraicClosure ℚ ℂ) : ℂ) = (starRingEnd ℂ) (y : ℂ) := by
  unfold conjRes
  rw [AlgEquiv.restrictNormalHom_apply]
  rfl

/-- The underlying automorphism of `ℚ̄`. -/
noncomputable def complexConjAut : AlgebraicClosure ℚ ≃ₐ[ℚ] AlgebraicClosure ℚ :=
  (algClosureEquiv.trans conjRes).trans algClosureEquiv.symm

/-- Complex conjugation `c ∈ G_ℚ` (with respect to the embedding `iota`). -/
noncomputable def complexConj : Field.absoluteGaloisGroup ℚ := complexConjAut

/-- `c` really is complex conjugation: `ι(c x) = conj(ι x)`. -/
theorem complexConj_spec (x : AlgebraicClosure ℚ) :
    iota (complexConjAut x) = (starRingEnd ℂ) (iota x) := by
  unfold iota complexConjAut
  simp only [AlgEquiv.trans_apply, AlgEquiv.apply_symm_apply]
  exact conjRes_spec _

/-- `c² = 1`. -/
theorem complexConj_sq : complexConj * complexConj = 1 := by
  change complexConjAut * complexConjAut = 1
  ext x
  have h : conjRes * conjRes = 1 := by
    unfold conjRes; rw [← map_mul]
    have : conjQ * conjQ = 1 := by ext z; simp [conjQ]
    rw [this, map_one]
  change algClosureEquiv.symm (conjRes (algClosureEquiv (algClosureEquiv.symm
    (conjRes (algClosureEquiv x))))) = x
  simp only [AlgEquiv.apply_symm_apply]
  have := congrArg (fun f => f (algClosureEquiv x)) h
  simp only [AlgEquiv.mul_apply, AlgEquiv.one_apply] at this
  rw [this]; simp

namespace ArtinRep

/-- `det ρ(c) ∈ ℂ`. -/
noncomputable def detConj {n : ℕ} (ρ : ArtinRep ℚ n) : ℂ :=
  ((Matrix.GeneralLinearGroup.det (ρ.toHom complexConj) : ℂˣ) : ℂ)

/-- `ρ` is even: `det ρ(c) = +1`. -/
def IsEven {n : ℕ} (ρ : ArtinRep ℚ n) : Prop := ρ.detConj = 1

/-- `ρ` is odd: `det ρ(c) = -1`. -/
def IsOdd {n : ℕ} (ρ : ArtinRep ℚ n) : Prop := ρ.detConj = -1

end ArtinRep

/-! ## Entire / meromorphic continuation and the conjecture -/

/-- `f` (given on `Re s > 1`) extends to an entire function. -/
def HasEntireContinuation (f : ℂ → ℂ) : Prop :=
  ∃ F : ℂ → ℂ, Differentiable ℂ F ∧ ∀ s : ℂ, 1 < s.re → F s = f s

/-- `f` (given on `Re s > 1`) extends to a meromorphic function on `ℂ`. -/
def HasMeromorphicContinuation (f : ℂ → ℂ) : Prop :=
  ∃ F : ℂ → ℂ, MeromorphicOn F Set.univ ∧ ∀ s : ℂ, 1 < s.re → F s = f s

/-- `f` extends meromorphically to `ℂ` with only finitely many singularities (poles). -/
def HasFinitelyManyPoles (f : ℂ → ℂ) : Prop :=
  ∃ F : ℂ → ℂ, MeromorphicOn F Set.univ ∧ (∀ s : ℂ, 1 < s.re → F s = f s) ∧
    {s : ℂ | ¬ DifferentiableAt ℂ F s}.Finite

/-- **Artin's holomorphy conjecture** (Artin 1923) over a number field `K`, for the
L-function assignment `L`: for every `n` and every *nontrivial* irreducible Artin
representation `ρ : G_K → GL_n(ℂ)`, `L(s, ρ)` extends to an entire function.
(Nontriviality is needed: for the trivial character `L(s, 1) = ζ_K(s)` has a pole
at `s = 1`. For `n ≥ 2`, irreducible already implies nontrivial.) -/
def ArtinHolomorphyConjecture (K : Type*) [Field K] [NumberField K]
    (L : ∀ n : ℕ, ArtinRep K n → ℂ → ℂ) : Prop :=
  ∀ (n : ℕ) (ρ : ArtinRep K n), ρ.IsIrreducible → ρ.toHom ≠ 1 →
    HasEntireContinuation (L n ρ)

/-- The specialization to `K = ℚ`, `n = 2`. -/
def ArtinTwoDimQ (L : ArtinRep ℚ 2 → ℂ → ℂ) : Prop :=
  ∀ ρ : ArtinRep ℚ 2, ρ.IsIrreducible → HasEntireContinuation (L ρ)

/-- The open case: `K = ℚ`, `n = 2`, projective image `A₅`, `det ρ(c) = +1`. -/
def ArtinEvenIcosahedral (L : ArtinRep ℚ 2 → ℂ → ℂ) : Prop :=
  ∀ ρ : ArtinRep ℚ 2, ρ.IsIrreducible → IsIcosahedralType (projImage ρ) → ρ.IsEven →
    HasEntireContinuation (L ρ)

/-- The general conjecture specializes to the two-dimensional case over `ℚ`. -/
theorem ArtinHolomorphyConjecture.twoDim {L : ∀ n : ℕ, ArtinRep ℚ n → ℂ → ℂ}
    (h : ArtinHolomorphyConjecture ℚ L) : ArtinTwoDimQ (L 2) := by
  intro ρ hρ
  refine h 2 ρ hρ ?_
  intro h1
  -- if `ρ` were trivial, the line `ℂ • e₀` would be stable, contradicting irreducibility
  have hstab := hρ (Submodule.span ℂ {Pi.single 0 1}) (by
    intro g v hv
    rw [h1]; simpa using hv)
  rcases hstab with h0 | htop
  · have : (Pi.single 0 1 : Fin 2 → ℂ) ∈ Submodule.span ℂ {Pi.single 0 1} :=
      Submodule.subset_span rfl
    rw [h0, Submodule.mem_bot] at this
    have := congrFun this 0; simp at this
  · have : (Pi.single 1 1 : Fin 2 → ℂ) ∈ Submodule.span ℂ {Pi.single 0 1} := by
      rw [htop]; trivial
    rw [Submodule.mem_span_singleton] at this
    obtain ⟨a, ha⟩ := this
    have := congrFun ha 1; simp at this

end ArtinHolomorphy
