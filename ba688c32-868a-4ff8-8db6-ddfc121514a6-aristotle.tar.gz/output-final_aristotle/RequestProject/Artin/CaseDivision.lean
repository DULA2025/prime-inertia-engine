module

public import RequestProject.Artin.Basic

/-!
# §3 — The case division for irreducible `ρ : G_ℚ → GL₂(ℂ)`

`case_division` : given Klein's classification, the projective image of an irreducible
two-dimensional Artin representation over `ℚ` is of **exactly one** of the five types,
**never cyclic** (proved here: `not_isCyclic_projImage`), and `det ρ(c)` is **exactly one**
of `±1` (proved here: `detConj_sq`).
-/

@[expose] public section

open Matrix

namespace ArtinHolomorphy

/-- If the projective image is cyclic, `ρ` is reducible: every `ρ(g)` is a scalar times
a power of one matrix `A`, so an eigenvector of `A` spans a stable line. -/
theorem not_isCyclic_projImage (ρ : ArtinRep ℚ 2) (hρ : ρ.IsIrreducible) :
    ¬ IsCyclic (projImage ρ) := by
  intro hcyc
  haveI := projImage_finite ρ
  obtain ⟨x, hx⟩ := IsCyclic.exists_generator (α := projImage ρ)
  obtain ⟨a, ha, hxa⟩ := Subgroup.mem_map.mp x.2
  obtain ⟨g0, rfl⟩ := ha
  set A : Matrix (Fin 2) (Fin 2) ℂ := ((ρ.toHom g0 : GL (Fin 2) ℂ) : Matrix (Fin 2) (Fin 2) ℂ)
    with hA
  obtain ⟨c, hc⟩ := Module.End.exists_eigenvalue (Matrix.toLin' A)
  obtain ⟨v, hv⟩ := hc.exists_hasEigenvector
  have hAv : A *ᵥ v = c • v := by
    have := hv.apply_eq_smul
    simpa [Matrix.toLin'_apply] using this
  have hv0 : v ≠ 0 := hv.2
  have hpow : ∀ k : ℕ, (A ^ k) *ᵥ v = c ^ k • v := by
    intro k
    induction k with
    | zero => simp
    | succ k ih =>
      rw [pow_succ, ← Matrix.mulVec_mulVec, hAv, Matrix.mulVec_smul, ih, smul_smul, pow_succ,
        mul_comm]
  have hstable : ∀ g, ∀ w ∈ Submodule.span ℂ {v},
      ((ρ.toHom g : GL (Fin 2) ℂ) : Matrix (Fin 2) (Fin 2) ℂ) *ᵥ w ∈ Submodule.span ℂ {v} := by
    intro g w hw
    obtain ⟨t, rfl⟩ := Submodule.mem_span_singleton.mp hw
    let y : projImage ρ := ⟨QuotientGroup.mk' _ (ρ.toHom g),
      Subgroup.mem_map_of_mem _ (MonoidHom.mem_range.mpr ⟨g, rfl⟩)⟩
    have hy := hx y
    rw [← mem_powers_iff_mem_zpowers] at hy
    obtain ⟨k, hk⟩ := hy
    have hk' : (QuotientGroup.mk' (Subgroup.center (GL (Fin 2) ℂ)) ((ρ.toHom g0) ^ k)) =
        QuotientGroup.mk' _ (ρ.toHom g) := by
      have := congrArg Subtype.val hk
      simp only [SubgroupClass.coe_pow] at this
      rw [map_pow, hxa]
      exact this
    have hmem := QuotientGroup.eq.mp hk'
    rw [Matrix.GeneralLinearGroup.center_eq_range_scalar] at hmem
    obtain ⟨u, hu⟩ := hmem
    have hg : ρ.toHom g = (ρ.toHom g0) ^ k * Matrix.GeneralLinearGroup.scalar (Fin 2) u := by
      rw [hu]; group
    have hs : ∀ w : Fin 2 → ℂ, ((Matrix.GeneralLinearGroup.scalar (Fin 2) u : GL (Fin 2) ℂ) :
        Matrix (Fin 2) (Fin 2) ℂ) *ᵥ w = (u : ℂ) • w := by
      intro w; ext i; simp [Matrix.mulVec_diagonal]
    rw [hg]
    simp only [Units.val_mul, Units.val_pow_eq_pow_val]
    rw [← Matrix.mulVec_mulVec, hs, Matrix.mulVec_smul, Matrix.mulVec_smul, ← hA, hpow]
    exact Submodule.smul_mem _ _ (Submodule.smul_mem _ _
      (Submodule.smul_mem _ _ (Submodule.mem_span_singleton_self v)))
  rcases hρ _ hstable with h | h
  · have : v ∈ Submodule.span ℂ {v} := Submodule.mem_span_singleton_self v
    rw [h, Submodule.mem_bot] at this
    exact hv0 this
  · have h1 := finrank_span_singleton (K := ℂ) hv0
    rw [h, finrank_top] at h1
    simp at h1

/-- `det ρ(c)² = 1`, since `c² = 1`. -/
theorem ArtinRep.detConj_sq {n : ℕ} (ρ : ArtinRep ℚ n) : ρ.detConj ^ 2 = 1 := by
  unfold ArtinRep.detConj
  rw [sq, ← Units.val_mul, ← map_mul, ← map_mul, complexConj_sq, map_one, map_one,
    Units.val_one]

/-- Every Artin representation over `ℚ` is even or odd, and not both. -/
theorem ArtinRep.even_or_odd {n : ℕ} (ρ : ArtinRep ℚ n) :
    (ρ.IsEven ∨ ρ.IsOdd) ∧ ¬ (ρ.IsEven ∧ ρ.IsOdd) := by
  refine ⟨?_, ?_⟩
  · have h := ρ.detConj_sq
    have : (ρ.detConj - 1) * (ρ.detConj + 1) = 0 := by ring_nf; rw [h]; ring
    rcases mul_eq_zero.mp this with h1 | h1
    · exact Or.inl (sub_eq_zero.mp h1)
    · exact Or.inr (eq_neg_of_add_eq_zero_left h1)
  · rintro ⟨h1, h2⟩
    unfold ArtinRep.IsEven at h1; unfold ArtinRep.IsOdd at h2
    rw [h1] at h2; norm_num at h2

/-- Pairwise disjointness of the five projective types. -/
theorem ProjType.unique (H : Type) [Group H] {t t' : ProjType} (ht : t.Holds H)
    (ht' : t'.Holds H) : t = t' := by
  cases t <;> cases t' <;> simp only [ProjType.Holds] at ht ht' <;> first
    | rfl
    | exact (disjoint_cyclic_dihedral H ht ht').elim
    | exact (disjoint_cyclic_dihedral H ht' ht).elim
    | exact (disjoint_cyclic_tetrahedral H ht ht').elim
    | exact (disjoint_cyclic_tetrahedral H ht' ht).elim
    | exact (disjoint_cyclic_octahedral H ht ht').elim
    | exact (disjoint_cyclic_octahedral H ht' ht).elim
    | exact (disjoint_cyclic_icosahedral H ht ht').elim
    | exact (disjoint_cyclic_icosahedral H ht' ht).elim
    | exact (disjoint_dihedral_tetrahedral H ht ht').elim
    | exact (disjoint_dihedral_tetrahedral H ht' ht).elim
    | exact (disjoint_dihedral_octahedral H ht ht').elim
    | exact (disjoint_dihedral_octahedral H ht' ht).elim
    | exact (disjoint_dihedral_icosahedral H ht ht').elim
    | exact (disjoint_dihedral_icosahedral H ht' ht).elim
    | exact (disjoint_tetrahedral_octahedral H ht ht').elim
    | exact (disjoint_tetrahedral_octahedral H ht' ht).elim
    | exact (disjoint_tetrahedral_icosahedral H ht ht').elim
    | exact (disjoint_tetrahedral_icosahedral H ht' ht).elim
    | exact (disjoint_octahedral_icosahedral H ht ht').elim
    | exact (disjoint_octahedral_icosahedral H ht' ht).elim

/-- **Case division (§3).** Assume Klein's classification. For an irreducible Artin
representation `ρ : G_ℚ → GL₂(ℂ)`:
1. its projective image has exactly one of the five Klein types;
2. that type is not `cyclic` (so it is dihedral, tetrahedral, octahedral or icosahedral);
3. `det ρ(c)` equals exactly one `ε ∈ {±1} = ℤˣ`.
Hence the irreducible `ρ` are partitioned into the 4 × 2 classes (type, parity). -/
theorem case_division (hK : KleinClassification) (ρ : ArtinRep ℚ 2) (hρ : ρ.IsIrreducible) :
    (∃! t : ProjType, t.Holds (projImage ρ)) ∧
    ¬ ProjType.cyclic.Holds (projImage ρ) ∧
    (∃! ε : ℤˣ, ρ.detConj = ((ε : ℤ) : ℂ)) := by
  refine ⟨?_, not_isCyclic_projImage ρ hρ, ?_⟩
  · have hfin := projImage_finite ρ
    have hex : ∃ t : ProjType, t.Holds (projImage ρ) := by
      rcases hK _ hfin with h | h | h | h | h
      · exact ⟨.cyclic, h⟩
      · exact ⟨.dihedral, h⟩
      · exact ⟨.tetrahedral, h⟩
      · exact ⟨.octahedral, h⟩
      · exact ⟨.icosahedral, h⟩
    obtain ⟨t, ht⟩ := hex
    exact ⟨t, ht, fun t' ht' => ProjType.unique _ ht' ht⟩
  · rcases ρ.even_or_odd.1 with h | h
    · refine ⟨1, by simpa using h, fun ε hε => ?_⟩
      rcases Int.units_eq_one_or ε with rfl | rfl
      · rfl
      · unfold ArtinRep.IsEven at h; rw [h] at hε; norm_num at hε
    · refine ⟨-1, by simpa using h, fun ε hε => ?_⟩
      rcases Int.units_eq_one_or ε with rfl | rfl
      · unfold ArtinRep.IsOdd at h; rw [h] at hε; norm_num at hε
      · rfl

end ArtinHolomorphy
