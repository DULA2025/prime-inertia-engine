module

public import RequestProject.Artin.CaseDivision

/-!
# Reduction of two-dimensional Artin over `ℚ` to the even icosahedral case (Target B)

The cited theorems of §2 are recorded as the fields of `CitedTheorems L`; none of them
is proved here (they are deep published theorems) and none is an axiom: they are
explicit hypotheses of every result below.

* `entire_of_not_even_icosahedral` : every irreducible `ρ` that is **not** even
  icosahedral has entire `L(s, ρ)`.
* `OpenH` : the named open statement for **Target B** (finitely many poles for even
  icosahedral `ρ`).
* `artin_of_openH` : `OPEN(H) ⇒ Artin for all irreducible 2-dim ρ over ℚ`.
* `openH_iff_artinEvenIcosahedral` : given Booker's theorem, `OPEN(H)` is *equivalent*
  to the even icosahedral Artin conjecture — i.e. Target B is a reformulation, and the
  reduction makes no unconditional progress on the open case.
* `even_icosahedral_obstructions` : for an even icosahedral `ρ`, each of the three
  available inputs (Khare–Wintenberger, Langlands–Tunnell, Hecke) is inapplicable.
* `twist_detConj`, `twist_projImage` : twisting by a character changes neither the
  parity nor the projective image.
-/

@[expose] public section

open Matrix

namespace ArtinHolomorphy

/-- The theorems of §2 that the reduction uses, as hypotheses about the L-function
assignment `L` (with `L ρ s = L(s, ρ)` for `Re s > 1`). -/
structure CitedTheorems (L : ArtinRep ℚ 2 → ℂ → ℂ) : Prop where
  /-- Klein (1884): finite subgroups of `PGL₂(ℂ)` are cyclic, dihedral, `A₄`, `S₄`, `A₅`. -/
  klein : KleinClassification
  /-- Artin (1930) + Brauer (1947): `L(s, ρ)` is a ratio of products of Hecke
  L-functions, hence meromorphic on `ℂ`. -/
  brauer_artin : ∀ ρ : ArtinRep ℚ 2, HasMeromorphicContinuation (L ρ)
  /-- Khare–Wintenberger (Invent. Math. 178, 2009, together with Kisin and the
  weight-one deduction there): an odd irreducible `ρ` comes from a holomorphic weight-one
  newform, so `L(s, ρ)` is entire. -/
  khare_wintenberger : ∀ ρ : ArtinRep ℚ 2, ρ.IsIrreducible → ρ.IsOdd →
    HasEntireContinuation (L ρ)
  /-- Langlands (1980) / Tunnell (1981): an irreducible `ρ` with **solvable** projective
  image is automorphic (cuspidal on `GL₂(𝔸_ℚ)`), so by Jacquet–Langlands `L(s, ρ)` is
  entire. Solvability is used through cyclic base change. -/
  langlands_tunnell : ∀ ρ : ArtinRep ℚ 2, ρ.IsIrreducible → IsSolvable (projImage ρ) →
    HasEntireContinuation (L ρ)
  /-- Hecke + class field theory + inductivity of Artin L-functions: dihedral irreducible
  `ρ ≅ Ind_{G_F}^{G_ℚ} χ` with `F` quadratic and `χ ≠ χ^σ`, so `L(s, ρ) = L(s, χ)` is a
  Hecke L-function of a nontrivial Grössencharacter, hence entire. -/
  hecke_dihedral : ∀ ρ : ArtinRep ℚ 2, ρ.IsIrreducible → IsDihedralType (projImage ρ) →
    HasEntireContinuation (L ρ)
  /-- Booker (Ann. of Math. 158, 2003): for irreducible two-dimensional `ρ` over `ℚ`,
  if `L(s, ρ)` has only finitely many poles then it is entire. -/
  booker : ∀ ρ : ArtinRep ℚ 2, ρ.IsIrreducible → HasFinitelyManyPoles (L ρ) →
    HasEntireContinuation (L ρ)

variable {L : ArtinRep ℚ 2 → ℂ → ℂ}

/-- **All classes except even icosahedral.** Each non-open class is reduced, in one step,
to a cited theorem:
* odd (any type) — Khare–Wintenberger;
* cyclic — impossible (`not_isCyclic_projImage`, proved);
* even dihedral — Hecke;
* even tetrahedral / octahedral — Langlands–Tunnell, via solvability of `A₄`, `S₄`
  (proved: `IsTetrahedralType.isSolvable`, `IsOctahedralType.isSolvable`). -/
theorem entire_of_not_even_icosahedral (h : CitedTheorems L) (ρ : ArtinRep ℚ 2)
    (hρ : ρ.IsIrreducible) (hne : ¬ (IsIcosahedralType (projImage ρ) ∧ ρ.IsEven)) :
    HasEntireContinuation (L ρ) := by
  rcases ρ.even_or_odd.1 with heven | hodd
  · rcases h.klein _ (projImage_finite ρ) with hc | hd | ht | ho | hi
    · exact (not_isCyclic_projImage ρ hρ hc).elim
    · exact h.hecke_dihedral ρ hρ hd
    · exact h.langlands_tunnell ρ hρ ht.isSolvable
    · exact h.langlands_tunnell ρ hρ ho.isSolvable
    · exact (hne ⟨hi, heven⟩).elim
  · exact h.khare_wintenberger ρ hρ hodd

/-- **OPEN(H)** (Target B): for every even icosahedral `ρ : G_ℚ → GL₂(ℂ)`, `L(s, ρ)` has
only finitely many poles. This is an open problem; it is *not* assumed anywhere except
as the explicit hypothesis of `artin_of_openH`. -/
def OpenH (L : ArtinRep ℚ 2 → ℂ → ℂ) : Prop :=
  ∀ ρ : ArtinRep ℚ 2, ρ.IsIrreducible → IsIcosahedralType (projImage ρ) → ρ.IsEven →
    HasFinitelyManyPoles (L ρ)

/-- **OPEN(H) ⇒ Artin for even icosahedral ρ** (via Booker 2003). -/
theorem artinEvenIcosahedral_of_openH (h : CitedTheorems L) (hH : OpenH L) :
    ArtinEvenIcosahedral L :=
  fun ρ hρ hi he => h.booker ρ hρ (hH ρ hρ hi he)

/-- **OPEN(H) ⇒ Artin for every irreducible two-dimensional ρ over ℚ.** -/
theorem artin_of_openH (h : CitedTheorems L) (hH : OpenH L) : ArtinTwoDimQ L := by
  intro ρ hρ
  by_cases hc : IsIcosahedralType (projImage ρ) ∧ ρ.IsEven
  · exact artinEvenIcosahedral_of_openH h hH ρ hρ hc.1 hc.2
  · exact entire_of_not_even_icosahedral h ρ hρ hc

/-- An entire continuation has finitely many (indeed no) poles. -/
lemma HasEntireContinuation.hasFinitelyManyPoles {f : ℂ → ℂ} (hf : HasEntireContinuation f) :
    HasFinitelyManyPoles f := by
  obtain ⟨F, hF, hFf⟩ := hf
  refine ⟨F, fun z _ => (hF.analyticAt z).meromorphicAt, hFf, ?_⟩
  have : {s : ℂ | ¬ DifferentiableAt ℂ F s} = ∅ := by
    ext s; simp [hF s]
  rw [this]; exact Set.finite_empty

/-- Given the cited theorems, `OPEN(H)` is **equivalent** to Artin's conjecture for even
icosahedral `ρ`: Target B is a reformulation, not a weakening that is easier to prove. -/
theorem openH_iff_artinEvenIcosahedral (h : CitedTheorems L) :
    OpenH L ↔ ArtinEvenIcosahedral L :=
  ⟨artinEvenIcosahedral_of_openH h,
    fun hA ρ hρ hi he => (hA ρ hρ hi he).hasFinitelyManyPoles⟩

/-- Given the cited theorems, the full two-dimensional conjecture over `ℚ` is equivalent to
its even icosahedral case: the even icosahedral class is the **only** open class. -/
theorem artinTwoDimQ_iff_evenIcosahedral (h : CitedTheorems L) :
    ArtinTwoDimQ L ↔ ArtinEvenIcosahedral L :=
  ⟨fun hA ρ hρ _ _ => hA ρ hρ,
    fun hE => artin_of_openH h ((openH_iff_artinEvenIcosahedral h).mpr hE)⟩

/-! ## Why the available inputs fail for even icosahedral `ρ` -/

/-- For an even icosahedral `ρ`:
1. `ρ` is not odd — Khare–Wintenberger does not apply;
2. the projective image is not solvable — Langlands–Tunnell does not apply
   (**this is the step where `A₅`, simple and non-abelian, breaks the argument**);
3. the projective image is not dihedral — Hecke does not apply;
4. the projective image has no index-two subgroup — `ρ` is not induced from a
   quadratic field. -/
theorem even_icosahedral_obstructions (ρ : ArtinRep ℚ 2)
    (hi : IsIcosahedralType (projImage ρ)) (he : ρ.IsEven) :
    ¬ ρ.IsOdd ∧ ¬ IsSolvable (projImage ρ) ∧ ¬ IsDihedralType (projImage ρ) ∧
      ∀ H : Subgroup (projImage ρ), H.index ≠ 2 := by
  refine ⟨fun ho => ρ.even_or_odd.2 ⟨he, ho⟩, hi.not_isSolvable,
    fun hd => disjoint_dihedral_icosahedral _ hd hi, fun H hH => ?_⟩
  obtain ⟨e⟩ := hi
  apply alternating_fin5_no_index_two (H.map e.toMonoidHom)
  rw [Subgroup.index_map_of_bijective e.bijective]
  exact hH

/-! ## Twisting preserves parity and projective image (§5) -/

/-- Scalar matrices are central in `GL₂(ℂ)`. -/
lemma scalar_comm (x : GL (Fin 2) ℂ) (u : ℂˣ) :
    Matrix.GeneralLinearGroup.scalar (Fin 2) u * x =
      x * Matrix.GeneralLinearGroup.scalar (Fin 2) u := by
  have : Matrix.GeneralLinearGroup.scalar (Fin 2) u ∈ Subgroup.center (GL (Fin 2) ℂ) := by
    rw [Matrix.GeneralLinearGroup.center_eq_range_scalar]; exact ⟨u, rfl⟩
  exact (Subgroup.mem_center_iff.mp this x).symm

/-- The twist `g ↦ χ(g) ρ(g)` of a homomorphism `ρ : G → GL₂(ℂ)` by a character
`χ : G → ℂˣ`. -/
noncomputable def twistHom {G : Type*} [Group G] (ρ : G →* GL (Fin 2) ℂ) (χ : G →* ℂˣ) :
    G →* GL (Fin 2) ℂ where
  toFun g := Matrix.GeneralLinearGroup.scalar (Fin 2) (χ g) * ρ g
  map_one' := by simp
  map_mul' a b := by
    simp only [map_mul]
    rw [mul_assoc, mul_assoc, ← mul_assoc (ρ a), ← scalar_comm (ρ a) (χ b)]
    simp only [mul_assoc]

/-- **Parity is a twist invariant**: `det(χ ⊗ ρ)(c) = χ(c)² det ρ(c) = det ρ(c)`, since
`χ(c)² = χ(c²) = 1`. So no twist turns an even `ρ` into an odd one. -/
theorem twist_detConj (ρ : Field.absoluteGaloisGroup ℚ →* GL (Fin 2) ℂ)
    (χ : Field.absoluteGaloisGroup ℚ →* ℂˣ) :
    Matrix.GeneralLinearGroup.det (twistHom ρ χ complexConj) =
      Matrix.GeneralLinearGroup.det (ρ complexConj) := by
  have hχ : χ complexConj * χ complexConj = 1 := by rw [← map_mul, complexConj_sq, map_one]
  change Matrix.GeneralLinearGroup.det
      (Matrix.GeneralLinearGroup.scalar (Fin 2) (χ complexConj) * ρ complexConj) = _
  rw [map_mul]
  have : Matrix.GeneralLinearGroup.det (Matrix.GeneralLinearGroup.scalar (Fin 2)
      (χ complexConj)) = 1 := by
    have h' : ((χ complexConj : ℂˣ) : ℂ) * (χ complexConj) = 1 := by
      rw [← Units.val_mul, hχ, Units.val_one]
    ext
    simp only [Matrix.GeneralLinearGroup.val_det_apply, Units.val_one]
    simp
    rcases mul_self_eq_one_iff.mp h' with h1 | h1
    · exact Or.inl (Units.ext h1)
    · exact Or.inr (Units.ext (by simpa using h1))
  rw [this, one_mul]

/-- Twisting does not change the image in `PGL₂(ℂ)`: an icosahedral `ρ` stays icosahedral. -/
theorem twist_projImage {G : Type*} [Group G] (ρ : G →* GL (Fin 2) ℂ) (χ : G →* ℂˣ) :
    (twistHom ρ χ).range.map (QuotientGroup.mk' (Subgroup.center (GL (Fin 2) ℂ))) =
      ρ.range.map (QuotientGroup.mk' (Subgroup.center (GL (Fin 2) ℂ))) := by
  rw [MonoidHom.map_range, MonoidHom.map_range]
  congr 1
  ext g
  simp only [MonoidHom.comp_apply, QuotientGroup.mk'_apply]
  change ((Matrix.GeneralLinearGroup.scalar (Fin 2) (χ g) * ρ g :
    GL (Fin 2) ℂ) : GL (Fin 2) ℂ ⧸ Subgroup.center (GL (Fin 2) ℂ)) = (ρ g : _)
  rw [QuotientGroup.eq, Matrix.GeneralLinearGroup.center_eq_range_scalar]
  refine ⟨(χ g)⁻¹, ?_⟩
  rw [_root_.mul_inv_rev, ← map_inv (Matrix.GeneralLinearGroup.scalar (Fin 2) (R := ℂ)), mul_assoc,
    scalar_comm, ← mul_assoc, inv_mul_cancel, one_mul]

end ArtinHolomorphy
