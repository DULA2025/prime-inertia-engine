module

public import Mathlib

/-!
# Exact arithmetic in `ℤ[ζ₅]`

All character values of `G = SL(2,5) × C₅` lie in `ℤ[ζ₅]` (`φ = (1+√5)/2 = -(ζ² + ζ³)`).
We represent `a + bζ + cζ² + dζ³` by four integers; this is a faithful representation
since `1, ζ, ζ², ζ³` is a `ℤ`-basis of `ℤ[ζ₅]` (`ζ⁴ = -1 - ζ - ζ² - ζ³`).  Equality is
decidable, so every identity below is checked by exact integer arithmetic.

`Cyc.toComplex` evaluates at `ζ = exp(2πi/5)`; it is additive, multiplicative and
commutes with complex conjugation (`Cyc.toComplex_add`, `Cyc.toComplex_mul`,
`Cyc.toComplex_conj`), so identities in `Cyc` give identities of complex numbers.
-/

@[expose] public section

namespace Brauer600

/-- `a + b ζ + c ζ² + d ζ³ ∈ ℤ[ζ₅]`. -/
@[ext] structure Cyc where
  a : ℤ
  b : ℤ
  c : ℤ
  d : ℤ
deriving DecidableEq, Repr

namespace Cyc

instance : Zero Cyc := ⟨⟨0, 0, 0, 0⟩⟩
instance : One Cyc := ⟨⟨1, 0, 0, 0⟩⟩
instance : Add Cyc := ⟨fun x y => ⟨x.a + y.a, x.b + y.b, x.c + y.c, x.d + y.d⟩⟩
instance : Neg Cyc := ⟨fun x => ⟨-x.a, -x.b, -x.c, -x.d⟩⟩
instance : Sub Cyc := ⟨fun x y => ⟨x.a - y.a, x.b - y.b, x.c - y.c, x.d - y.d⟩⟩
instance : SMul ℤ Cyc := ⟨fun n x => ⟨n * x.a, n * x.b, n * x.c, n * x.d⟩⟩

/-- Multiplication, reducing with `ζ⁵ = 1` and `ζ⁴ = -1 - ζ - ζ² - ζ³`. -/
instance : Mul Cyc := ⟨fun x y =>
  ⟨x.a * y.a + (x.c * y.d + x.d * y.c) - (x.b * y.d + x.c * y.c + x.d * y.b),
   (x.a * y.b + x.b * y.a) + x.d * y.d - (x.b * y.d + x.c * y.c + x.d * y.b),
   (x.a * y.c + x.b * y.b + x.c * y.a) - (x.b * y.d + x.c * y.c + x.d * y.b),
   (x.a * y.d + x.b * y.c + x.c * y.b + x.d * y.a) - (x.b * y.d + x.c * y.c + x.d * y.b)⟩⟩

/-- Complex conjugation `ζ ↦ ζ⁴ = ζ⁻¹`. -/
def conj (x : Cyc) : Cyc := ⟨x.a - x.b, -x.b, x.d - x.b, x.c - x.b⟩

/-- `ζ^n`. -/
def zeta (n : ℕ) : Cyc :=
  match n % 5 with
  | 0 => ⟨1, 0, 0, 0⟩
  | 1 => ⟨0, 1, 0, 0⟩
  | 2 => ⟨0, 0, 1, 0⟩
  | 3 => ⟨0, 0, 0, 1⟩
  | _ => ⟨-1, -1, -1, -1⟩

/-- The element `a + b φ` of `ℤ[φ] ⊂ ℤ[ζ₅]`, where `φ = (1+√5)/2 = -(ζ² + ζ³)`. -/
def ofZPhi (a b : ℤ) : Cyc := ⟨a, 0, -b, -b⟩

/-- Coordinatewise integer division (used only where exactness is checked). -/
def divInt (x : Cyc) (n : ℤ) : Cyc := ⟨x.a / n, x.b / n, x.c / n, x.d / n⟩


/-! ### Component lemmas and the ring structure -/

@[simp] lemma zero_a : (0 : Cyc).a = 0 := rfl
@[simp] lemma zero_b : (0 : Cyc).b = 0 := rfl
@[simp] lemma zero_c : (0 : Cyc).c = 0 := rfl
@[simp] lemma zero_d : (0 : Cyc).d = 0 := rfl
@[simp] lemma one_a : (1 : Cyc).a = 1 := rfl
@[simp] lemma one_b : (1 : Cyc).b = 0 := rfl
@[simp] lemma one_c : (1 : Cyc).c = 0 := rfl
@[simp] lemma one_d : (1 : Cyc).d = 0 := rfl
@[simp] lemma add_a (x y : Cyc) : (x + y).a = x.a + y.a := rfl
@[simp] lemma add_b (x y : Cyc) : (x + y).b = x.b + y.b := rfl
@[simp] lemma add_c (x y : Cyc) : (x + y).c = x.c + y.c := rfl
@[simp] lemma add_d (x y : Cyc) : (x + y).d = x.d + y.d := rfl
@[simp] lemma neg_a (x : Cyc) : (-x).a = -x.a := rfl
@[simp] lemma neg_b (x : Cyc) : (-x).b = -x.b := rfl
@[simp] lemma neg_c (x : Cyc) : (-x).c = -x.c := rfl
@[simp] lemma neg_d (x : Cyc) : (-x).d = -x.d := rfl
@[simp] lemma sub_a (x y : Cyc) : (x - y).a = x.a - y.a := rfl
@[simp] lemma sub_b (x y : Cyc) : (x - y).b = x.b - y.b := rfl
@[simp] lemma sub_c (x y : Cyc) : (x - y).c = x.c - y.c := rfl
@[simp] lemma sub_d (x y : Cyc) : (x - y).d = x.d - y.d := rfl
@[simp] lemma smul_a (n : ℤ) (x : Cyc) : (n • x).a = n * x.a := rfl
@[simp] lemma smul_b (n : ℤ) (x : Cyc) : (n • x).b = n * x.b := rfl
@[simp] lemma smul_c (n : ℤ) (x : Cyc) : (n • x).c = n * x.c := rfl
@[simp] lemma smul_d (n : ℤ) (x : Cyc) : (n • x).d = n * x.d := rfl
@[simp] lemma mul_a (x y : Cyc) : (x * y).a =
    x.a * y.a + (x.c * y.d + x.d * y.c) - (x.b * y.d + x.c * y.c + x.d * y.b) := rfl
@[simp] lemma mul_b (x y : Cyc) : (x * y).b =
    (x.a * y.b + x.b * y.a) + x.d * y.d - (x.b * y.d + x.c * y.c + x.d * y.b) := rfl
@[simp] lemma mul_c (x y : Cyc) : (x * y).c =
    (x.a * y.c + x.b * y.b + x.c * y.a) - (x.b * y.d + x.c * y.c + x.d * y.b) := rfl
@[simp] lemma mul_d (x y : Cyc) : (x * y).d =
    (x.a * y.d + x.b * y.c + x.c * y.b + x.d * y.a) - (x.b * y.d + x.c * y.c + x.d * y.b) := rfl

/-- `ℤ[ζ₅]` is a commutative ring (used only to reason about sums; all computations use
the explicit operations above). -/
instance instCommRing : CommRing Cyc where
  add_assoc := by intros; ext <;> simp <;> ring
  zero_add := by intros; ext <;> simp
  add_zero := by intros; ext <;> simp
  add_comm := by intros; ext <;> simp <;> ring
  mul_assoc := by intros; ext <;> simp <;> ring
  one_mul := by intros; ext <;> simp
  mul_one := by intros; ext <;> simp
  zero_mul := by intros; ext <;> simp
  mul_zero := by intros; ext <;> simp
  left_distrib := by intros; ext <;> simp <;> ring
  right_distrib := by intros; ext <;> simp <;> ring
  mul_comm := by intros; ext <;> simp <;> ring
  neg_add_cancel := by intros; ext <;> simp
  sub_eq_add_neg := by intros; ext <;> simp <;> ring
  nsmul := fun n x => (n : ℤ) • x
  nsmul_zero := by intros; ext <;> simp
  nsmul_succ := by intros; ext <;> simp <;> ring
  zsmul := fun n x => n • x
  zsmul_zero' := by intros; ext <;> simp
  zsmul_succ' := by intros; ext <;> simp <;> ring
  zsmul_neg' := by intros; ext <;> simp [Int.negSucc_eq] <;> ring

lemma divInt_smul_cancel (m : ℤ) (hm : m ≠ 0) (y : Cyc) : divInt (m • y) m = y := by
  ext <;> simp only [divInt, smul_a, smul_b, smul_c, smul_d] <;>
    exact Int.mul_ediv_cancel_left _ hm

/-! ### Evaluation at `ζ = exp(2πi/5)` -/

/-- The primitive fifth root of unity `exp(2πi/5)`. -/
noncomputable def ζc : ℂ := Complex.exp (2 * Real.pi * Complex.I / 5)

lemma ζc_prim : IsPrimitiveRoot ζc 5 := Complex.isPrimitiveRoot_exp 5 (by norm_num)

lemma ζc_pow_five : ζc ^ 5 = 1 := ζc_prim.pow_eq_one

lemma ζc_geom : ζc ^ 4 + ζc ^ 3 + ζc ^ 2 + ζc + 1 = 0 := by
  have h := ζc_prim.geom_sum_eq_zero (by norm_num)
  simp [Finset.sum_range_succ] at h
  linear_combination h

/-- Evaluation `ℤ[ζ₅] → ℂ`, `ζ ↦ exp(2πi/5)`. -/
noncomputable def toComplex (x : Cyc) : ℂ :=
  x.a + x.b * ζc + x.c * ζc ^ 2 + x.d * ζc ^ 3

lemma toComplex_add (x y : Cyc) : toComplex (x + y) = toComplex x + toComplex y := by
  simp only [toComplex, show x + y = ⟨x.a + y.a, x.b + y.b, x.c + y.c, x.d + y.d⟩ from rfl]
  push_cast; ring

lemma toComplex_smul (n : ℤ) (x : Cyc) : toComplex (n • x) = n * toComplex x := by
  simp only [toComplex, show n • x = ⟨n * x.a, n * x.b, n * x.c, n * x.d⟩ from rfl]
  push_cast; ring

lemma toComplex_mul (x y : Cyc) : toComplex (x * y) = toComplex x * toComplex y := by
  obtain ⟨a, b, c, d⟩ := x
  obtain ⟨a', b', c', d'⟩ := y
  have e : (⟨a, b, c, d⟩ : Cyc) * ⟨a', b', c', d'⟩ =
      ⟨a * a' + (c * d' + d * c') - (b * d' + c * c' + d * b'),
       (a * b' + b * a') + d * d' - (b * d' + c * c' + d * b'),
       (a * c' + b * b' + c * a') - (b * d' + c * c' + d * b'),
       (a * d' + b * c' + c * b' + d * a') - (b * d' + c * c' + d * b')⟩ := rfl
  rw [e]
  simp only [toComplex]
  push_cast
  linear_combination
    -((c : ℂ) * d' + (d : ℂ) * c' + (d : ℂ) * d' * ζc) * ζc_pow_five -
      ((b : ℂ) * d' + (c : ℂ) * c' + (d : ℂ) * b') * ζc_geom

lemma conj_ζc : (starRingEnd ℂ) ζc = ζc ^ 4 := by
  have h1 : ‖ζc‖ = 1 := ζc_prim.norm'_eq_one (by norm_num)
  have hne : ζc ≠ 0 := ζc_prim.ne_zero (by norm_num)
  have h2 : (starRingEnd ℂ) ζc * ζc = 1 := by
    rw [mul_comm, Complex.mul_conj, Complex.normSq_eq_norm_sq, h1]; simp
  have h3 : ζc ^ 4 * ζc = 1 := by rw [← pow_succ]; exact ζc_pow_five
  exact mul_right_cancel₀ hne (h2.trans h3.symm)

lemma toComplex_conj (x : Cyc) : toComplex (conj x) = (starRingEnd ℂ) (toComplex x) := by
  obtain ⟨a, b, c, d⟩ := x
  simp only [toComplex, conj, map_add, map_mul, map_pow, map_intCast, conj_ζc]
  push_cast
  linear_combination (-(b : ℂ)) * ζc_geom +
    (-(c : ℂ) * ζc ^ 3 - (d : ℂ) * ζc ^ 2 * (ζc ^ 5 + 1)) * ζc_pow_five

end Cyc

end Brauer600
