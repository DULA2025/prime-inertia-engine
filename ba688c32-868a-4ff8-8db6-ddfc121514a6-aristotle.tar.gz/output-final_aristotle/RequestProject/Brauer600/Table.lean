module

public import RequestProject.Brauer600.Cyc

/-!
# The character table of `G = SL(2,5) × C₅` (order 600) as explicit finite input

**`SL(2,5)` (order 120).**  Conjugacy classes, in this order, with sizes:

| index | 0  | 1  | 2  | 3  | 4  | 5  | 6  | 7   | 8   |
|-------|----|----|----|----|----|----|----|-----|-----|
| class | 1a | 2a | 4a | 3a | 6a | 5a | 5b | 10a | 10b |
| size  | 1  | 1  | 30 | 20 | 20 | 12 | 12 | 12  | 12  |

(`2a = {-I}`; in the natural 2-dimensional representation an element of class
`5a, 5b, 10a, 10b` has eigenvalues `e^{±2πiθ}` with `θ = 1/5, 2/5, 1/10, 3/10`.)
Irreducible characters, in this order: `1, 2, 2', 3, 3', 4, 4', 5, 6`, where `2` is the
natural (faithful) 2-dimensional character, `2'` its Galois conjugate (`√5 ↦ -√5`),
`3 = Sym² 2`, `4 = Sym³ 2` (faithful), `4' = 2 ⊗ 2'`, `5 = Sym⁴ 2`, `6 = 2 ⊗ 3'`.
Values lie in `ℤ[φ]`, `φ = (1+√5)/2`, written `ofZPhi a b = a + bφ`.

**`C₅ = ⟨c⟩`.**  Characters `ψ^m : c^k ↦ ζ^{mk}`, `ζ = e^{2πi/5}`.

**`G`.**  Classes `(i, k) ↔ C_i × {c^k}`, irreducible characters `(j, m) ↔ χ_j ⊠ ψ^m`.
The character `ρ` of the request is `2 ⊠ ψ³ = chi (1, 3)`; the trivial character is
`chi (0, 0)`.

The table is input data, not an axiom.  As a check that it *is* a character table, the
row orthonormality relations `⟨χ, χ'⟩ = δ` for all `45 × 45` pairs of irreducible
characters of `G` are verified by exact arithmetic (`chi_orthonormal`, in
`RequestProject.Brauer600.Orthonormality`).
-/

@[expose] public section

namespace Brauer600

open Cyc

/-- Class sizes in `SL(2,5)`. -/
def sizeS : Fin 9 → ℤ := ![1, 1, 30, 20, 20, 12, 12, 12, 12]

/-- The character table of `SL(2,5)`: `tblS j i = χ_j(C_i)`. -/
def tblS : Fin 9 → Fin 9 → Cyc := ![
    ![ofZPhi (1) (0), ofZPhi (1) (0), ofZPhi (1) (0), ofZPhi (1) (0), ofZPhi (1) (0),
      ofZPhi (1) (0), ofZPhi (1) (0), ofZPhi (1) (0), ofZPhi (1) (0)],
    ![ofZPhi (2) (0), ofZPhi (-2) (0), ofZPhi (0) (0), ofZPhi (-1) (0), ofZPhi (1) (0),
      ofZPhi (-1) (1), ofZPhi (0) (-1), ofZPhi (0) (1), ofZPhi (1) (-1)],
    ![ofZPhi (2) (0), ofZPhi (-2) (0), ofZPhi (0) (0), ofZPhi (-1) (0), ofZPhi (1) (0),
      ofZPhi (0) (-1), ofZPhi (-1) (1), ofZPhi (1) (-1), ofZPhi (0) (1)],
    ![ofZPhi (3) (0), ofZPhi (3) (0), ofZPhi (-1) (0), ofZPhi (0) (0), ofZPhi (0) (0),
      ofZPhi (1) (-1), ofZPhi (0) (1), ofZPhi (0) (1), ofZPhi (1) (-1)],
    ![ofZPhi (3) (0), ofZPhi (3) (0), ofZPhi (-1) (0), ofZPhi (0) (0), ofZPhi (0) (0),
      ofZPhi (0) (1), ofZPhi (1) (-1), ofZPhi (1) (-1), ofZPhi (0) (1)],
    ![ofZPhi (4) (0), ofZPhi (-4) (0), ofZPhi (0) (0), ofZPhi (1) (0), ofZPhi (-1) (0),
      ofZPhi (-1) (0), ofZPhi (-1) (0), ofZPhi (1) (0), ofZPhi (1) (0)],
    ![ofZPhi (4) (0), ofZPhi (4) (0), ofZPhi (0) (0), ofZPhi (1) (0), ofZPhi (1) (0),
      ofZPhi (-1) (0), ofZPhi (-1) (0), ofZPhi (-1) (0), ofZPhi (-1) (0)],
    ![ofZPhi (5) (0), ofZPhi (5) (0), ofZPhi (1) (0), ofZPhi (-1) (0), ofZPhi (-1) (0),
      ofZPhi (0) (0), ofZPhi (0) (0), ofZPhi (0) (0), ofZPhi (0) (0)],
    ![ofZPhi (6) (0), ofZPhi (-6) (0), ofZPhi (0) (0), ofZPhi (0) (0), ofZPhi (0) (0),
      ofZPhi (1) (0), ofZPhi (1) (0), ofZPhi (-1) (0), ofZPhi (-1) (0)]]

/-- Degrees of the irreducible characters of `SL(2,5)`. -/
def degS : Fin 9 → ℤ := ![1, 2, 2, 3, 3, 4, 4, 5, 6]

/-- Conjugacy classes of `G = SL(2,5) × C₅`: `(i, k) ↔ C_i × {c^k}`. -/
abbrev ClG := Fin 9 × Fin 5

/-- Irreducible characters of `G`: `(j, m) ↔ χ_j ⊠ ψ^m`. -/
abbrev IrrG := Fin 9 × Fin 5

/-- Class functions on `G` with values in `ℤ[ζ₅]`. -/
abbrev CF := ClG → Cyc

/-- Size of a conjugacy class of `G`. -/
def sizeG (K : ClG) : ℤ := sizeS K.1

/-- The character table of `G`: `chi (j, m) (i, k) = χ_j(C_i) · ζ^{mk}`. -/
def chi (χ : IrrG) : CF := fun K => tblS χ.1 K.1 * zeta (χ.2.val * K.2.val)

/-- The trivial character `1` of `G`. -/
def triv : CF := chi (0, 0)

/-- The character `ρ = 2 ⊠ ψ³` of `G`. -/
def rho : CF := chi (1, 3)

/-- Degree of an irreducible character of `G`. -/
def degG (χ : IrrG) : ℤ := degS χ.1

/-- Sum of a `ℤ[ζ₅]`-valued function over the 45 classes of `G`. -/
def sumCl (f : ClG → Cyc) : Cyc :=
  (List.finRange 9).foldr (fun i acc => (List.finRange 5).foldr (fun k acc' => f (i, k) + acc')
    acc) 0

/-- `|G| · ⟨f, g⟩ = Σ_K |K| f(K) \overline{g(K)}`. -/
def ip600 (f g : CF) : Cyc := sumCl (fun K => sizeG K • (f K * conj (g K)))

/-- Virtual characters of `G`, as integer multiplicity vectors on the irreducibles. -/
abbrev VChar := IrrG → ℤ

/-- The class function `Σ_χ m(χ) χ` of a virtual character. -/
def VChar.toCF (m : VChar) : CF := fun K =>
  (List.finRange 9).foldr (fun j acc => (List.finRange 5).foldr
    (fun n acc' => m (j, n) • chi (j, n) K + acc') acc) 0

/-- Degree `Σ_χ m(χ) χ(1)` of a virtual character. -/
def VChar.deg (m : VChar) : ℤ := ∑ χ, m χ * degG χ

/-- The class function `Σ_l v(l) χ_l` on `SL(2,5)` of a multiplicity vector. -/
def sumS (v : Fin 9 → ℤ) (i : Fin 9) : Cyc := ∑ l, v l • tblS l i

lemma foldr_add_eq_sum {α : Type*} (l : List α) (g : α → Cyc) (a : Cyc) :
    l.foldr (fun x acc => g x + acc) a = (l.map g).sum + a := by
  induction l with
  | nil => simp
  | cons x l ih => simp [ih, add_assoc]

/-- `toCF` as a double finite sum. -/
lemma VChar.toCF_eq_sum (m : VChar) (K : ClG) :
    m.toCF K = ∑ j : Fin 9, ∑ n : Fin 5, m (j, n) • chi (j, n) K := by
  simp only [VChar.toCF, foldr_add_eq_sum, add_zero, Fin.sum_univ_def]

end Brauer600
