module

public import RequestProject.Brauer600.Identity
public import RequestProject.Artin.Basic

/-!
# Task 2: consequences of the effective identity, from cited hypotheses only

Let `N/ℚ` be a Galois extension with group `G = SL(2,5) × C₅` (the conductor-1951
representation `ρ = 2 ⊠ ψ³` is the motivating example).  Mathlib has no Artin
L-functions, so `L : VChar → ℂ → ℂ` is a parameter: `L m s` stands for the Artin
L-function `L(s, Σ m(π) π)` of `N/ℚ` on `Re s > 1`.  The cited theorems enter as the fields
of `CitedTask2 L` — hypotheses, not axioms, and none of them is proved here.

The identity of `Identity.lean` reads, in the representation ring,
`reg_G + 4ρ = Σ_{j∈{0,1,2,4}} T_j + T_Z + 4 T₁₀ + 2 T₂₄`.
By inductivity each term is an L-function over a subfield `N^{H×C₅}`:
* `T_j = Ind_{1×C₅}(1⊠ψ^j)`: the Hecke L-function of the linear character `ψ^j` of
  `Gal(N/N^{1×C₅}) ≅ C₅`; for `j = 0` this is the Dedekind zeta function of `N^{1×C₅}`.
* `T_Z = Ind_{Z×C₅}(1⊠ψ³)`, `T₁₀ = Ind_{H₁₀×C₅}(λ⊠ψ³)`: Hecke L-functions of nontrivial
  linear characters (nontrivial because `ψ³ ≠ 1` on the `C₅` factor).
* `T₂₄ = Ind_{H₂₄×C₅}(σ⊠ψ³)`: the Artin L-function of the 2-dimensional irreducible
  representation `σ⊠ψ³` of `Gal(N/N^{H₂₄×C₅}) ≅ SL(2,3) × C₅`, whose image is solvable
  (Langlands–Tunnell over the number field `N^{H₂₄×C₅}`).

Results:
* `entire_mul_zetaN` : `(s-1)·ζ_N(s)·L(s,ρ)⁴` agrees on `Re s > 1` with an entire function.
* `zetaN_zero_order_ge` : if `ζ_N` and `L(s,ρ)` continue meromorphically to `ℂ`, then at
  every `s₀ ≠ 1` where `L(s,ρ)` has a pole of order `m`, `ζ_N` has a zero of order `≥ 4m`
  (as orders of meromorphic functions: `ord_{s₀} ζ_N ≥ 4m`).

**Not concluded:** that `L(s,ρ)` is entire.  The argument leaves open that a pole of
`L(s,ρ)` at `s₀` is compensated by a zero of `ζ_N` of order `≥ 4m`; ruling this out is
**OPEN** (and by `Witness.optimality` no identity built from these inputs gives more than
the factor `4`).
-/

@[expose] public section

namespace Brauer600

open ArtinHolomorphy Filter Topology

/-- The cited theorems used in Task 2, as hypotheses about the L-function assignment `L`
(on `Re s > 1`) and the Dedekind zeta function `ζ_N`. -/
structure CitedTask2 (L : VChar → ℂ → ℂ) (zetaN : ℂ → ℂ) : Prop where
  /-- Artin formalism, additivity: `L(s, χ + χ') = L(s, χ) L(s, χ')`. -/
  additive : ∀ a b : VChar, ∀ s : ℂ, 1 < s.re → L (a + b) s = L a s * L b s
  /-- Artin formalism: `ζ_N(s) = L(s, reg_G)`. -/
  zetaN_eq : ∀ s : ℂ, 1 < s.re → zetaN s = L regMult s
  /-- Inductivity + Hecke: `L(s, T₀)` is the Dedekind zeta function of `N^{1×C₅}`, which
  has only a simple pole at `s = 1`; so `(s-1) L(s, T₀)` is entire. -/
  hecke_dedekind : HasEntireContinuation (fun s => (s - 1) * L (prodMult vReg 0) s)
  /-- Inductivity + Hecke: `L(s, T_j)`, `j ≠ 0`, is the Hecke L-function of the nontrivial
  linear character `ψ^j`, hence entire. -/
  hecke_triv_twist : ∀ j : Fin 5, j ≠ 0 → HasEntireContinuation (L (prodMult vReg j))
  /-- Inductivity + Hecke: `L(s, T_Z)` is the Hecke L-function of the nontrivial linear
  character `1 ⊠ ψ³` of `Z × C₅`, hence entire. -/
  hecke_z : HasEntireContinuation (L (prodMult vZ 3))
  /-- Inductivity + Hecke: `L(s, T₁₀)` is the Hecke L-function of the nontrivial linear
  character `λ ⊠ ψ³` of `H₁₀ × C₅`, hence entire. -/
  hecke_h10 : HasEntireContinuation (L (prodMult vH10 3))
  /-- Inductivity + Langlands–Tunnell over the number field `N^{H₂₄×C₅}`: `σ ⊠ ψ³` is
  2-dimensional irreducible with solvable image, so `L(s, T₂₄)` is entire. -/
  langlands_tunnell_h24 : HasEntireContinuation (L (prodMult vH24 3))

/-- The identity of `Identity.lean` as an equality of multiplicity vectors. -/
lemma effective_identity_vchar :
    regMult + (rhoMult + rhoMult + rhoMult + rhoMult) =
      prodMult vReg 0 + prodMult vReg 1 + prodMult vReg 2 + prodMult vReg 4 + prodMult vZ 3 +
        (prodMult vH10 3 + prodMult vH10 3 + prodMult vH10 3 + prodMult vH10 3) +
        (prodMult vH24 3 + prodMult vH24 3) := by
  funext χ
  have := effective_identity_mult χ
  simp only [Pi.add_apply]
  linarith

/-- On `Re s > 1`: `ζ_N(s) L(s,ρ)⁴ = Π (L-functions of the terms)`. -/
lemma zetaN_mul_L_rho_pow {L : VChar → ℂ → ℂ} {zetaN : ℂ → ℂ} (h : CitedTask2 L zetaN)
    (s : ℂ) (hs : 1 < s.re) :
    zetaN s * L rhoMult s ^ 4 =
      L (prodMult vReg 0) s * L (prodMult vReg 1) s * L (prodMult vReg 2) s *
        L (prodMult vReg 4) s * L (prodMult vZ 3) s * L (prodMult vH10 3) s ^ 4 *
        L (prodMult vH24 3) s ^ 2 := by
  have e := congrArg (fun m => L m s) effective_identity_vchar
  simp only [h.additive _ _ s hs] at e
  rw [h.zetaN_eq s hs]
  linear_combination e

/-- **Task 2 (first part).**  `(s - 1) ζ_N(s) L(s, ρ)⁴` extends to an entire function. -/
theorem entire_mul_zetaN {L : VChar → ℂ → ℂ} {zetaN : ℂ → ℂ} (h : CitedTask2 L zetaN) :
    HasEntireContinuation (fun s => (s - 1) * zetaN s * L rhoMult s ^ 4) := by
  obtain ⟨E0, hE0, e0⟩ := h.hecke_dedekind
  obtain ⟨E1, hE1, e1⟩ := h.hecke_triv_twist 1 (by decide)
  obtain ⟨E2, hE2, e2⟩ := h.hecke_triv_twist 2 (by decide)
  obtain ⟨E4, hE4, e4⟩ := h.hecke_triv_twist 4 (by decide)
  obtain ⟨EZ, hEZ, eZ⟩ := h.hecke_z
  obtain ⟨E10, hE10, e10⟩ := h.hecke_h10
  obtain ⟨E24, hE24, e24⟩ := h.langlands_tunnell_h24
  refine ⟨fun s => E0 s * E1 s * E2 s * E4 s * EZ s * E10 s ^ 4 * E24 s ^ 2,
    by fun_prop, fun s hs => ?_⟩
  simp only
  rw [e0 s hs, e1 s hs, e2 s hs, e4 s hs, eZ s hs, e10 s hs, e24 s hs,
    show (s - 1) * zetaN s * L rhoMult s ^ 4 = (s - 1) * (zetaN s * L rhoMult s ^ 4) by ring,
    zetaN_mul_L_rho_pow h s hs]
  ring

/-- **Task 2 (second part).**  Suppose `ζ_N` and `L(s, ρ)` have meromorphic continuations
`Z` and `F` to `ℂ` (Artin–Brauer).  If `F` has a pole of order `m` at `s₀ ≠ 1`, i.e.
`ord_{s₀} F = -m`, then `ord_{s₀} Z ≥ 4m`: a pole of `L(s,ρ)` of order `m` at `s₀ ≠ 1`
is a zero of `ζ_N` of order at least `4m`. -/
theorem zetaN_zero_order_ge {L : VChar → ℂ → ℂ} {zetaN : ℂ → ℂ} (h : CitedTask2 L zetaN)
    {Z F : ℂ → ℂ} (hZ : MeromorphicOn Z Set.univ) (hZe : ∀ s : ℂ, 1 < s.re → Z s = zetaN s)
    (hF : MeromorphicOn F Set.univ) (hFe : ∀ s : ℂ, 1 < s.re → F s = L rhoMult s)
    {s₀ : ℂ} (hs₀ : s₀ ≠ 1) {m : ℕ} (hpole : meromorphicOrderAt F s₀ = ((-(m : ℤ) : ℤ) : WithTop ℤ)) :
    (((4 * m : ℕ) : ℤ) : WithTop ℤ) ≤ meromorphicOrderAt Z s₀ := by
  obtain ⟨E, hE, hEe⟩ := entire_mul_zetaN h
  set g : ℂ → ℂ := fun s => (s - 1) * (Z s * F s ^ 4) with hg_def
  have hgm : MeromorphicOn g Set.univ := by
    intro x hx
    exact (MeromorphicAt.id x |>.sub (MeromorphicAt.const 1 x)).mul
      ((hZ x hx).mul ((hF x hx).pow 4))
  have hEa : ∀ x, AnalyticAt ℂ E x := fun x => hE.analyticAt x
  -- `g - E` vanishes on the open half-plane `Re s > 1`
  have hdiff : MeromorphicOn (g - E) Set.univ := fun x hx =>
    (hgm x hx).sub (hEa x).meromorphicAt
  have htop2 : meromorphicOrderAt (g - E) 2 = ⊤ := by
    rw [meromorphicOrderAt_eq_top_iff]
    have hopen : IsOpen {s : ℂ | 1 < s.re} := isOpen_lt continuous_const Complex.continuous_re
    have hmem : {s : ℂ | 1 < s.re} ∈ 𝓝 (2 : ℂ) := hopen.mem_nhds (by norm_num)
    filter_upwards [nhdsWithin_le_nhds hmem] with s hs
    simp only [Pi.sub_apply, hg_def, hEe s hs, hZe s hs, hFe s hs]
    ring
  have htop : meromorphicOrderAt (g - E) s₀ = ⊤ := by
    by_contra hne
    exact (hdiff.meromorphicOrderAt_ne_top_of_isPreconnected isPreconnected_univ
      (Set.mem_univ s₀) (Set.mem_univ 2) hne) htop2
  have hgE : g =ᶠ[𝓝[≠] s₀] E := by
    rw [meromorphicOrderAt_eq_top_iff] at htop
    filter_upwards [htop] with s hs
    simpa [sub_eq_zero] using hs
  have hord_g : meromorphicOrderAt g s₀ = meromorphicOrderAt Z s₀ + 4 * meromorphicOrderAt F s₀ := by
    have h1 : meromorphicOrderAt g s₀ = meromorphicOrderAt (fun s => Z s * F s ^ 4) s₀ :=
      meromorphicOrderAt_mul_of_ne_zero (f := fun s => Z s * F s ^ 4) (g := fun s => s - 1)
        (by fun_prop) (sub_ne_zero.mpr hs₀)
    rw [h1, show (fun s => Z s * F s ^ 4) = Z * F ^ 4 from rfl,
      meromorphicOrderAt_mul (hZ s₀ trivial) ((hF s₀ trivial).pow 4),
      meromorphicOrderAt_pow (hF s₀ trivial)]
    norm_num
  have hnonneg : 0 ≤ meromorphicOrderAt g s₀ := by
    rw [meromorphicOrderAt_congr hgE]; exact (hEa s₀).meromorphicOrderAt_nonneg
  rw [hord_g, hpole] at hnonneg
  cases hZo : meromorphicOrderAt Z s₀ with
  | top => exact le_top
  | coe z =>
    rw [hZo] at hnonneg
    rw [show (4 : WithTop ℤ) = ((4 : ℤ) : WithTop ℤ) from rfl, ← WithTop.coe_mul,
      ← WithTop.coe_add, show (0 : WithTop ℤ) = ((0 : ℤ) : WithTop ℤ) from rfl] at hnonneg
    have hz : 0 ≤ z + 4 * (-(m : ℤ)) := WithTop.coe_le_coe.mp hnonneg
    exact_mod_cast (by push_cast; linarith : ((4 * m : ℕ) : ℤ) ≤ z)

end Brauer600
