module

public import RequestProject.Brauer600.Table

/-!
# Orthonormality of the character table of `G = SL(2,5) × C₅`

A consistency check on the explicit table: all `45 × 45` inner products
`|G|·⟨χ, χ'⟩ = Σ_K |K| χ(K) \overline{χ'(K)}` are computed exactly in `ℤ[ζ₅]`.
In particular the 45 irreducible characters are linearly independent, so the
multiplicity vector of a class function in their span is unique.
-/

@[expose] public section

namespace Brauer600

open Cyc

/-- **Orthonormality** of the 45 irreducible characters of `G` (exact check). -/
theorem chi_orthonormal :
    ∀ χ ψ : IrrG, ip600 (chi χ) (chi ψ) = if χ = ψ then ⟨600, 0, 0, 0⟩ else 0 := by
  decide +kernel

end Brauer600
