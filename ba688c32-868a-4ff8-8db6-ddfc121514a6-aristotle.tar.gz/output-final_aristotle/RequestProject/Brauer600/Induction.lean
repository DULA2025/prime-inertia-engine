module

public import RequestProject.Brauer600.Table

/-!
# Induced class functions computed from the character table

For a subgroup `H ≤ G` and a class function `f` of `H` (a linear character, or the
restriction of a character of `G`), the induced class function is given by the standard
formula (e.g. Serre, *Linear representations of finite groups*, §7.2; Isaacs,
*Character theory*, (5.1))
`Ind_H^G f (K) = |G| / (|H| |K|) · Σ_{h ∈ H ∩ K} f(h)`.
We take this formula as the *definition* of `Ind`; so `Ind_H^G f` is determined by `|H|`
and the *class sums* `σ(K) = Σ_{h ∈ H ∩ K} f(h)` (the fusion of `H` into `G`), which are
explicit finite input.  Frobenius reciprocity is **not** used anywhere: multiplicities of
irreducible characters in an induced class function are certified by exhibiting the
decomposition and checking it as an identity of class functions (unique by the verified
orthonormality of the table).

All subgroups used have the form `H × C₅` with `H ≤ SL(2,5)` and character `f ⊠ ψ^m`; then
`σ_G(i, k) = σ_H(i) ζ^{mk}`, `|H × C₅| = 5|H|`, and `timesC5_ind_eq_toCF` shows (once and
for all, for every `H`, `f`, `m`) that `Ind_{H × C₅}^G (f ⊠ ψ^m) = (Ind_H^{SL(2,5)} f) ⊠ ψ^m`,
so its multiplicity vector is that of `Ind_H^{SL(2,5)} f` placed in the `ψ^m`-slot.

## Class sums of cyclic subgroups from the table

`SL(2,5)` embeds in `SU(2)` (binary icosahedral group), and its conjugacy classes are
determined by the eigenvalues `e^{±2πiθ}`.  For `s` with eigenvalues `e^{±2πi/n}`
(`n ∈ {1,2,3,4,5,6,10}`), `s^e` lies in the class `angleClass n e` of angle `e/n`
(the power maps of the table).  For the linear character `λ_j(s) = e^{2πij/n}` of `⟨s⟩`,
since every class is closed under inversion,
`2 σ(i) = Σ_{e : s^e ∈ C_i} (λ_j(s^e) + λ_j(s^{-e})) = Σ_{e : s^e ∈ C_i} χ₂(s^{je})`,
where `χ₂ = 2cos(2π·angle)` is the natural character.  `cycSub n j` computes `σ` this way.
-/

@[expose] public section

namespace Brauer600

open Cyc

/-- A subgroup `H ≤ G` with a class function `f`, recorded by `|H|` and the class
sums `σ(K) = Σ_{h ∈ H ∩ K} f(h)`. -/
structure SubG where
  ord : ℤ
  sigma : ClG → Cyc

/-- `Ind_H^G f (K) = |G| σ(K) / (|H| |K|)`. -/
def SubG.ind (H : SubG) : CF := fun K => divInt ((600 : ℤ) • H.sigma K) (H.ord * sizeG K)

/-- A subgroup `H ≤ SL(2,5)` with a class function, recorded by `|H|` and class sums. -/
structure SubS where
  ord : ℤ
  sigma : Fin 9 → Cyc

/-- `Ind_H^{SL(2,5)} f (C_i) = |SL(2,5)| σ(i) / (|H| |C_i|)`. -/
def SubS.ind (H : SubS) (i : Fin 9) : Cyc := divInt ((120 : ℤ) • H.sigma i) (H.ord * sizeS i)

/-- The subgroup `H × C₅ ≤ G` with the character `f ⊠ ψ^m`. -/
def SubS.timesC5 (H : SubS) (m : Fin 5) : SubG :=
  ⟨5 * H.ord, fun K => H.sigma K.1 * zeta (m.val * K.2.val)⟩

/-- `H` with the restriction of a class function `χ` of `SL(2,5)`, given the numbers
`|H ∩ C_i|`. -/
def SubS.ofRestrict (ord : ℤ) (count : Fin 9 → ℤ) (χ : Fin 9 → Cyc) : SubS :=
  ⟨ord, fun i => count i • χ i⟩

/-- The class (of `SL(2,5)`) of an element with eigenvalues `e^{±2πia/n}`. -/
def angleClass (n a : ℕ) : Fin 9 :=
  let r := a % n
  let b := min r (n - r)
  let g := Nat.gcd b n
  match b / g, n / g with
  | 1, 2 => 1
  | 1, 4 => 2
  | 1, 3 => 3
  | 1, 6 => 4
  | 1, 5 => 5
  | 2, 5 => 6
  | 1, 10 => 7
  | 3, 10 => 8
  | _, _ => 0

/-- `C_n = ⟨s⟩ ≤ SL(2,5)` (`s` with eigenvalues `e^{±2πi/n}`) with the linear character
`λ_j(s) = e^{2πij/n}`; class sums computed from the power map and the table. -/
def cycSub (n j : ℕ) : SubS :=
  ⟨n, fun i => divInt ((List.range n).foldr
    (fun e acc => (if angleClass n e = i then tblS 1 (angleClass n (j * e)) else 0) + acc) 0)
    2⟩

/-- Multiplicity vector of `χ ⊠ ψ^m` from a multiplicity vector on `SL(2,5)`. -/
def prodMult (v : Fin 9 → ℤ) (m : Fin 5) : VChar := fun χ => if χ.2 = m then v χ.1 else 0

/-- Exactness of the induction formula and decomposition of `Ind_H^{SL(2,5)} f`
as `Σ v(l) χ_l`, as a decidable predicate. -/
def SubS.Decomposes (H : SubS) (v : Fin 9 → ℤ) : Prop :=
  H.ord ≠ 0 ∧ (∀ i, (H.ord * sizeS i) • H.ind i = (120 : ℤ) • H.sigma i) ∧
    ∀ i, H.ind i = sumS v i

instance (H : SubS) (v : Fin 9 → ℤ) : Decidable (H.Decomposes v) := by
  unfold SubS.Decomposes; infer_instance

/-- **Induction from `H × C₅`.** If `Ind_H^{SL(2,5)} f = Σ v(l) χ_l` (checked exactly), then
`Ind_{H × C₅}^G (f ⊠ ψ^m) = Σ_l v(l) χ_l ⊠ ψ^m` as class functions on `G`, for every `m`. -/
theorem timesC5_ind_eq_toCF (H : SubS) (v : Fin 9 → ℤ) (h : H.Decomposes v) (m : Fin 5)
    (K : ClG) : (H.timesC5 m).ind K = (prodMult v m).toCF K := by
  obtain ⟨hord, hex, hdec⟩ := h
  obtain ⟨i, k⟩ := K
  have hsz : sizeS i ≠ 0 := by revert i; decide
  have key : (600 : ℤ) • (H.sigma i * zeta (m.val * k.val)) =
      (5 * H.ord * sizeS i) • (H.ind i * zeta (m.val * k.val)) := by
    have := hex i
    simp only [zsmul_eq_mul] at this ⊢
    push_cast at this ⊢
    linear_combination (-(5 : Cyc) * zeta (m.val * k.val)) * this
  simp only [SubG.ind, SubS.timesC5, sizeG]
  rw [key, show 5 * H.ord * sizeS i = (5 * H.ord) * sizeS i by ring,
    divInt_smul_cancel _ (by simp [hord, hsz])]
  rw [VChar.toCF_eq_sum, hdec i, sumS, Finset.sum_mul]
  refine Finset.sum_congr rfl fun l _ => ?_
  simp only [prodMult, chi, ite_smul, zero_smul, Finset.sum_ite_eq', Finset.mem_univ,
    if_true, smul_mul_assoc]

end Brauer600
