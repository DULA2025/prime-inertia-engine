module

public import RequestProject.Brauer600.Induction

/-!
# Task 1: the effective identity `reg_G + 4ρ = Σ (induced characters)`

`G = SL(2,5) × C₅`, `ρ = 2 ⊠ ψ³`, `reg_G` the regular character (`600` at the identity,
`0` elsewhere).  The subgroups and characters (all exhibited explicitly):

* `1 × C₅` with `1 ⊠ ψ^j`, `j ∈ {0, 1, 2, 4}` (`trivS`);
* `Z × C₅`, `Z = {±I}`, with `1 ⊠ ψ³` (`zS`);
* `H₁₀ × C₅`, `H₁₀ = ⟨s⟩`, `s ∈ 10a` (eigenvalues `e^{±2πi/10}`), with `λ ⊠ ψ³`,
  `λ(s) = e^{2πi/10}` (`h10`, class sums computed from the table);
* `H₂₄ × C₅`, `H₂₄ ≅ SL(2,3)` (the preimage of `A₄ ⊂ A₅`), with `σ ⊠ ψ³`,
  `σ = 2|_{H₂₄} · λ'` and `λ' = 1` (`h24`).  `H₂₄` meets the classes
  `1a, 2a, 4a, 3a, 6a` in `1, 1, 6, 8, 8` elements; `σ` is irreducible
  (`h24_sigma_irreducible`: `Σ_{h ∈ H₂₄} |σ(h)|² = |H₂₄|`).

Main results:

* `effective_identity` : as class functions on `G` (exact arithmetic in `ℤ[ζ₅]`)
  `reg_G + 4ρ = Σ_{j∈{0,1,2,4}} Ind_{1×C₅}(1⊠ψ^j) + Ind_{Z×C₅}(1⊠ψ³)`
  `           + 4·Ind_{H₁₀×C₅}(λ⊠ψ³) + 2·Ind_{H₂₄×C₅}(σ⊠ψ³)`;
  all coefficients are nonnegative.
* `effective_identity_complex` : the same identity of complex class functions.
* `ind_h10_eq`, `ind_h24_eq`, `ind_z_eq` : the multiplicities.  In the labelling of this
  development (`1, 2, 2', 3, 3', 4, 4', 5, 6` with `4 = Sym³ 2` faithful and
  `4' = 2 ⊗ 2'` trivial on `-I`):
  `Ind_{H₁₀×C₅}(λ⊠ψ³) = (2 + 4 + 6) ⊠ ψ³`,
  `Ind_{H₂₄×C₅}(σ⊠ψ³) = (2 + 2' + 6) ⊠ ψ³ = ρ + ρ' + 6 ⊠ ψ³`,
  `Ind_{Z×C₅}(1⊠ψ³) = (1 + 3·3 + 3·3' + 4·4' + 5·5) ⊠ ψ³`.
  (The faithful 4-dimensional character, called `4'` in the request, is `4` here.)
* `effective_identity_mult` : the identity in the representation ring.
-/

@[expose] public section

namespace Brauer600

open Cyc

/-- The regular character of `G`. -/
def regG : CF := fun K => if K = (0, 0) then ⟨600, 0, 0, 0⟩ else 0

/-- The character `ρ' = 2' ⊠ ψ³`. -/
def rho' : CF := chi (2, 3)

/-- The trivial subgroup of `SL(2,5)` with its trivial character. -/
def trivS : SubS := SubS.ofRestrict 1 ![1, 0, 0, 0, 0, 0, 0, 0, 0] (fun _ => 1)

/-- `Z = {±I}` with its trivial character. -/
def zS : SubS := SubS.ofRestrict 2 ![1, 1, 0, 0, 0, 0, 0, 0, 0] (fun _ => 1)

/-- `H₁₀ = ⟨s⟩`, `s ∈ 10a`, with `λ(s) = e^{2πi/10}`. -/
def h10 : SubS := cycSub 10 1

/-- Numbers `|H₂₄ ∩ C_i|` for `H₂₄ ≅ SL(2,3)`. -/
def h24count : Fin 9 → ℤ := ![1, 1, 6, 8, 8, 0, 0, 0, 0]

/-- `H₂₄ ≅ SL(2,3)` with `σ = 2|_{H₂₄}` (i.e. `λ' = 1`). -/
def h24 : SubS := SubS.ofRestrict 24 h24count (tblS 1)

/-- Sanity checks on the fusion data of `H₂₄`: it has `24` elements, `|H₂₄ ∩ C_i| ≤ |C_i|`,
and `σ = 2|_{H₂₄}` is irreducible: `Σ_{h ∈ H₂₄} σ(h) \overline{σ(h)} = 24`. -/
theorem h24_sigma_irreducible :
    ∑ i, h24count i = 24 ∧ (∀ i, 0 ≤ h24count i ∧ h24count i ≤ sizeS i) ∧
      ∑ i, h24count i • (tblS 1 i * conj (tblS 1 i)) = ⟨24, 0, 0, 0⟩ := by
  decide +kernel

/-- `H₁₀` has `10` elements (class sums of its trivial character). -/
theorem h10_card : ∑ i, (cycSub 10 0).sigma i = ⟨10, 0, 0, 0⟩ := by decide +kernel

/-- Multiplicity vectors (on `SL(2,5)`) of the four induced characters. -/
def vReg : Fin 9 → ℤ := degS
def vZ : Fin 9 → ℤ := ![1, 0, 0, 3, 3, 0, 4, 5, 0]
def vH10 : Fin 9 → ℤ := ![0, 1, 0, 0, 0, 1, 0, 0, 1]
def vH24 : Fin 9 → ℤ := ![0, 1, 1, 0, 0, 0, 0, 0, 1]

theorem trivS_dec : trivS.Decomposes vReg := by decide +kernel
theorem zS_dec : zS.Decomposes vZ := by decide +kernel
theorem h10_dec : h10.Decomposes vH10 := by decide +kernel
theorem h24_dec : h24.Decomposes vH24 := by decide +kernel

/-- `Ind_{1×C₅}^G(1⊠ψ^j) = reg_{SL(2,5)} ⊠ ψ^j`. -/
theorem ind_triv_eq (j : Fin 5) (K : ClG) :
    (trivS.timesC5 j).ind K = (prodMult vReg j).toCF K :=
  timesC5_ind_eq_toCF _ _ trivS_dec j K

/-- `Ind_{Z×C₅}^G(1⊠ψ³) = (1 + 3·3 + 3·3' + 4·4' + 5·5) ⊠ ψ³`. -/
theorem ind_z_eq (K : ClG) : (zS.timesC5 3).ind K = (prodMult vZ 3).toCF K :=
  timesC5_ind_eq_toCF _ _ zS_dec 3 K

/-- `Ind_{H₁₀×C₅}^G(λ⊠ψ³) = ρ + 4 ⊠ ψ³ + 6 ⊠ ψ³`. -/
theorem ind_h10_eq (K : ClG) : (h10.timesC5 3).ind K = (prodMult vH10 3).toCF K :=
  timesC5_ind_eq_toCF _ _ h10_dec 3 K

/-- `Ind_{H₂₄×C₅}^G(σ⊠ψ³) = ρ + ρ' + 6 ⊠ ψ³`. -/
theorem ind_h24_eq (K : ClG) : (h24.timesC5 3).ind K = (prodMult vH24 3).toCF K :=
  timesC5_ind_eq_toCF _ _ h24_dec 3 K

/-- The subgroups are proper and the indices are as expected:
`|1×C₅| = 5`, `|Z×C₅| = 10`, `|H₁₀×C₅| = 50`, `|H₂₄×C₅| = 120`. -/
theorem orders :
    (trivS.timesC5 0).ord = 5 ∧ (zS.timesC5 0).ord = 10 ∧ (h10.timesC5 0).ord = 50 ∧
      (h24.timesC5 0).ord = 120 := by decide +kernel

/-- **Task 1: the effective identity**, as class functions on `G` (exact arithmetic). -/
theorem effective_identity (K : ClG) :
    regG K + (4 : ℤ) • rho K =
      (trivS.timesC5 0).ind K + (trivS.timesC5 1).ind K + (trivS.timesC5 2).ind K +
        (trivS.timesC5 4).ind K + (zS.timesC5 3).ind K + (4 : ℤ) • (h10.timesC5 3).ind K +
        (2 : ℤ) • (h24.timesC5 3).ind K := by
  revert K; decide +kernel

/-- The identity for complex-valued class functions (`ζ = e^{2πi/5}`). -/
theorem effective_identity_complex (K : ClG) :
    toComplex (regG K) + 4 * toComplex (rho K) =
      toComplex ((trivS.timesC5 0).ind K) + toComplex ((trivS.timesC5 1).ind K) +
        toComplex ((trivS.timesC5 2).ind K) + toComplex ((trivS.timesC5 4).ind K) +
        toComplex ((zS.timesC5 3).ind K) + 4 * toComplex ((h10.timesC5 3).ind K) +
        2 * toComplex ((h24.timesC5 3).ind K) := by
  have h := congrArg toComplex (effective_identity K)
  simp only [toComplex_add, toComplex_smul] at h
  push_cast at h
  exact h

/-- Multiplicity vector of `reg_G` (`π ↦ dim π`). -/
def regMult : VChar := degG

/-- Multiplicity vector of `ρ`. -/
def rhoMult : VChar := fun χ => if χ = (1, 3) then 1 else 0

/-- `regMult` and `rhoMult` represent `reg_G` and `ρ`. -/
theorem regMult_toCF (K : ClG) : regMult.toCF K = regG K ∧ rhoMult.toCF K = rho K := by
  revert K; decide +kernel

/-- **Task 1 in the representation ring** (all coefficients nonnegative). -/
theorem effective_identity_mult (χ : IrrG) :
    regMult χ + 4 * rhoMult χ =
      prodMult vReg 0 χ + prodMult vReg 1 χ + prodMult vReg 2 χ + prodMult vReg 4 χ +
        prodMult vZ 3 χ + 4 * prodMult vH10 3 χ + 2 * prodMult vH24 3 χ := by
  revert χ; decide +kernel

end Brauer600
