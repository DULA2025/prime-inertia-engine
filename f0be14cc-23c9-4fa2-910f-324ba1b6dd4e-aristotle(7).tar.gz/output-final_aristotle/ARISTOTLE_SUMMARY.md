# Summary of changes for run 0555095f-a8da-45d4-baa7-5d3b7c6338c8
Everything requested is in place, sorry-free and building.

**Builds (both exit 0).** `lake build ArtinA5Even.HolomorphyInterface ArtinA5Even.AxiomAudit` and `lake build ArtinA5Even`. All work stayed in `ArtinA5Even/` and `docs/`; nothing from the other libraries was touched or imported; no `sorry`, no `admit`, no `axiom`, no `native_decide`. The axiom audit prints only `propext`, `Classical.choice`, `Quot.sound` for every audited declaration.

**Task 1 — the χ₂ table and conjugacy** (`ArtinA5Even/HolomorphyInterface.lean`, namespace `Icosa`). The five classes of A₅ (`1, 2A, 3A, 5A, 5B`, sizes `1, 15, 20, 12, 12`) carry `χ₂ = (2, 0, −1, (1+s)/2, (1−s)/2)` with `s` standing for √5, and `χ₂′ = χ₂(−s)`, i.e. φ and φ′ exchanged. Proved:
- `chi2_neg` / `chi2'_eq_chi2_swap5`: `√5 ↦ −√5` acts on the values by exactly the transposition of `5A` and `5B` — the two characters are Galois conjugates; their sum `(4, 0, −2, 1, 1)` is rational.
- `pairing_chi2_self` (`⟨χ₂,χ₂⟩ = 1`) and `pairing_chi2_chi2'` (`⟨χ₂,χ₂′⟩ = 0`) for the class-size weighted pairing, assuming `s² = 5`.
- `cycleType_fiveCycle_pow` and `cycleType_inv_eq`: a 5-cycle, its inverse and its square all have cycle type `{5}` in S₅, so quintic factorisation cannot separate `5A` from `5B`; correspondingly `chi2_not_factors_through_cycleType` shows χ₂ does not factor through cycle type.
- `chi2_realised_by_sl2`: the five values are traces of the SL₂ matrices already in the library (`X = a`, `Y = (√5)⁻¹·b`) at `1, Y, (XY)², −X, −X²`, which fixes the sign convention.
- Honesty is enforced in Lean: `pairing_chi2_trivial` computes the pairing with the trivial character of A₅ to be `−1/10 ≠ 0`, so χ₂ is a projective character of A₅ (a character of the binary cover), not a character of A₅. Nothing is called an `a_p`; no Frobenius, L-function or automorphic object appears.

**Task 2 — the product warning as a theorem** (same file, namespace `Holo`). `exists_ratFunc_factorisation`: in `RatFunc ℚ`, `F = 1/(X−a)` and `G = X−a` have `F·G = 1` with `G` a polynomial and `F` not one (`inv_sub_C_not_polynomial`). Analytic twin `exists_entire_prod`: `F(z) = z⁻¹`, `G(z) = z²` give `F·G = id` entire with `G` entire while `F` is not continuous at 0; `exists_pole_cancelled_by_zero` is the pole/zero form at an arbitrary point. In the shape of the 1951 problem, `factorisation_does_not_force_holomorphy` produces `L₃·L₃′ = L_M` with `L_M`, `L₃′` entire and `L₃` not holomorphic at a point of `(0,1)`. Docstrings state that the same logic applies to `L(ρ₃)L(ρ₃′) = L_M(ψ)` versus each factor.

**Task 3 — no tautology.** Following the preferred option, there is no `ProductHolomorphyReduction` structure and no interface Props: the missing inputs (entirety of the product; absence of pole/zero cancellation) live only in the docs ledger. No stand-in `Prop` for a missing Mathlib theory remains anywhere in the library, and the entirety of the two-dimensional even Artin L-function of conductor 1951 is not even stated in Lean — it remains unproved, as required.

**Task 4 — docs.** `docs/ARTIN_A5_EVEN_1951.md` gains §8 with the character summary, the cancellation warning, a single paragraph explaining that without a Tate lift there is no two-dimensional linear Artin L-function to state in Lean and that the Booker–Lee–Strömbergsson classification assumes Artin and so cannot close the gap, and the four-column ledger (proved / classical external / open) exactly as specified.


# Summary of changes for run d45ee77b-5422-4021-b883-1ab9fd411c58
All work stayed inside `ArtinA5Even/` and `docs/`; `ArtinS5`, `Zeta5`, `RequestProject` were neither touched nor imported, no `native_decide`, no `axiom`, no `sorry`, and `ExistsMaass1951` is unchanged (still only a name, never inhabited or assumed).

**Builds.** `lake build ArtinA5Even.KleinSigns ArtinA5Even.AxiomAudit` and `lake build ArtinA5Even` both succeed (the new module elaborates in ~15 s). Every audited declaration, new ones included, depends only on `propext`, `Classical.choice`, `Quot.sound`.

**Task 1 — the three signs (new file `ArtinA5Even/KleinSigns.lean`).** For any field `K` with a primitive fifth root of unity `z`, Klein's matrices satisfy, in `GL₂(K)`,
`a⁵ = 1·I`, `b² = (−5)·I`, `(ab)³ = 5(z − z⁴)(z² − z³)·I = (−5√5)·I`,
with `√5 = 2(z + z⁴) + 1 ∈ K` and the proved identity `(z − z⁴)(z² − z³) = −√5`. It is stated explicitly that these matrices are **not** both in `SL₂`: `det a = 1` but `det b = 5`. Rescaling the involution by `√5` gives `X = a` and `Y = (√5)⁻¹·b`, both of determinant 1, i.e. genuine elements of `SL₂(K)`, and the normalised scalars are the binary icosahedral signs
`X⁵ = I`, `Y² = −I`, `(XY)³ = −I` (`KleinSigns.klein_sl2_signs`).
It is also proved that `X` and `Y` project to Klein's `a` and `b` in `PGL₂(K)`.

**Task 2 — the `SL₂` obstruction, proved.** The core lemma `KleinSigns.no_involution_lift` shows that if a homomorphism into `SL₂(K)` projectivises to Klein's involution at an element `β` with `β² = 1`, then `False` (whenever `−1 ≠ 1` in `K`): every `SL₂`-lift of the class of `b` is `c⁻¹·b` with `c² = 5`, hence squares to `−I`. This needs no extra hypothesis or identification, and yields two unconditional theorems:
- `no_sl2_section_kleinEmb` — the icosahedral embedding `A₅ ↪ PGL₂(ℚ(ζ₅))` has no section through `SL₂(ℚ(ζ₅))`;
- `not_linearLiftOfRhoBar1951` — **`¬ LinearLiftOfRhoBar1951`**: the previously named-only linear lift of `ρ̄ : Gal(f₁₉₅₁) → PGL₂(ℚ(ζ₅))` does not exist.

Supporting general facts proved along the way: two elements of `GL₂` have the same class in `PGL₂` exactly when they differ by a nonzero scalar (both directions).

**Task 3 — docs.** `docs/ARTIN_A5_EVEN_1951.md` has a new section 6g giving the scalar table, the rescaling to `SL₂`, the obstruction argument, and a status table: *`SL₂`-section of `ρ̄` ⇔ split `2.A₅ → A₅` ⇔ false* (proved here); *`GL₂(ℂ)` lift ⇔ Tate's `H²(G_ℚ, ℂ^×) = 0`* (external, not in Mathlib, deliberately not encoded as a theorem or an assumption); *`ExistsMaass1951` unchanged*. It says plainly that this is **not** a statement that no Artin representation exists, since Artin's object is a map to `GL₂(ℂ)` where the centre is all of `ℂ^×`. The now-outdated "not proved, not disproved" wording in `ArtinA5Even/RhoBar1951.lean`, `ArtinA5Even/AxiomAudit.lean` and the docs was corrected, and the audit file prints the axiom dependencies of every new declaration.

All changes are committed and pushed.

# Summary of changes for run 84047835-4adc-48af-b72b-48ab58676cda
Both tracks are done; the `ArtinA5Even` library stays green and sorry-free.

**Track A — the composite ρ̄.** `ArtinA5Even/RhoBar1951.lean` already carried the composite

`rhoBar1951 : poly1951Q.Gal →* PGL₂(ℚ(ζ₅))` = `Gal(f₁₉₅₁) ≃* A₅ ≃* ⟨a,b⟩ ↪ PGL₂(ℚ(ζ₅))`,

a bundled homomorphism, proved injective (`rhoBar1951_injective`, `ker_rhoBar1951 = ⊥`), with image exactly Klein's icosahedral subgroup (`range_rhoBar1951`) of cardinality 60 (`card_range_rhoBar1951`), plus the mandatory docstring. This run added the optional pieces:

- `rhoBar1951_orderOf`: ρ̄ preserves element orders (injective homomorphism);
- `exists_preimage_of_mem_kleinSubgroup` and the conjugacy-class dictionary at the level of orders — `rhoBar1951_dictionary_two` (order 2 ↦ `b`), `_three` (order 3 ↦ `a·b`), `_fiveA` (order 5 ↦ `a`), `_fiveB` (order 5 ↦ `a²`), with the supporting order facts `orderOf_kleinWordA/B/AB/A_sq`. It is stated explicitly, in the module docstring and in the docs, that the classes 5A and 5B are **not** separated, and that the cycle type of `f₁₉₅₁ mod p` cannot separate them (it only gives the order of Frobenius);
- `sl2ToPGL2` and `LinearLiftOfRhoBar1951`: the pullback/linear-lift statement is *named only* — not proved, not disproved, not assumed — with the explicit remark that nonsplitness of `2.A₅ → A₅` is not claimed to forbid a lift of this Galois map, since the relevant extension is by the field's scalars.

`ExistsProjectiveEvenRep1951` and `ExistsMaass1951` remain uninhabited; no evenness, conductor, modularity, Artin or Maass claim is made anywhere.

**Track B — reconnaissance.** New `docs/ARTIN_1951_RHO3_PRODUCT.md` records, as mathematics for later use and explicitly *not* as Lean theorems: the identification `ρ₃ ⊕ ρ₃′ ≅ Ind_{D₁₀}^{A₅} ψ` and hence `L(ρ₃)L(ρ₃′) = L_M(ψ)`, an abelian Hecke L-function over the sextic field fixed by a `D₁₀`, entire by class field theory/Hecke — so entirety of the product is not the theorem to certify; why non-vanishing of the product on (0,1) does not give holomorphy of either factor (a pole cancelled by a zero leaves the product finite) and what a later certificate would have to address (Galois conjugation √5 ↦ −√5, reality on the real line, Artin holomorphy on the line Re s = 1 plus continuation); and the integer Euler data `χ₃+χ₃′ = (6,−2,0,1)` with the four local factors `(1−T)⁶`, `(1−T)²(1+T)⁴`, `(1−T)²(1+T+T²)²`, `(1−T)(1−T⁵)`. No dyadic-enclosure or Abel-sum certificate is started.

**Docs and audit.** `docs/ARTIN_A5_EVEN_1951.md` section 6f gained subsections 6f.1 (the dictionary and its limits) and 6f.2 (the named pullback extension), and points at the new file. `ArtinA5Even/AxiomAudit.lean` now prints every new public name.

**Verification.** `lake build ArtinA5Even` and `lake build ArtinA5Even.RhoBar1951 ArtinA5Even.AxiomAudit` both succeed; `rg -n "sorry|admit|axiom|native_decide" ArtinA5Even` matches only prose in comments; every audited declaration, new ones included, depends only on `propext`, `Classical.choice`, `Quot.sound`. `ArtinS5`, `Zeta5`, `RequestProject` were neither touched nor imported. All work is committed and pushed.

# Summary of changes for run f04fbf03-b33f-47ca-ad08-e703d303afbb
Added `ArtinA5Even/RhoBar1951.lean`, a new sorry-free module inside the isolated `ArtinA5Even/` library (imports only `ArtinA5Even.GalA5` and `ArtinA5Even.KleinFinField`; `ArtinS5`, `Zeta5`, `RequestProject` untouched and unimported).

**The map.** `ArtinA5Even.rhoBar1951 : poly1951Q.Gal →* PGL₂(ℚ(ζ₅))` is defined as the composite

`Gal(f₁₉₅₁) ≃* A₅ ≃* ⟨a, b⟩ ↪ PGL₂(ℚ(ζ₅))`,

using the library's existing `gal1951_equiv_alternating` and `Klein.closureEquivAlternating_cyclotomic` (Klein's explicit generators over the cyclotomic field, not over ℂ). The type used is the library's `PGL2 K = GL₂(K) ⧸ centre`; Mathlib at this version has no separate projective-general-linear-group abbreviation.

**Proved (all sorry-free):**
- it is a bundled group homomorphism (`rhoBar1951`, `rhoBar1951_mul`, `rhoBar1951_one`);
- `rhoBar1951_injective` and `ker_rhoBar1951 = ⊥`;
- `range_rhoBar1951 : rhoBar1951.range = kleinSubgroup` — the image is exactly the Klein subgroup;
- `card_range_rhoBar1951 : Nat.card rhoBar1951.range = 60`;
- `galEquivRangeRhoBar1951 : Gal ≃* im ρ̄`, and the summary `rhoBar1951_embedding_icosahedral`;
- `rhoBar1951_abstract : RhoBar1951Abstract` — the honest abstract statement (an injective hom into PGL₂(ℚ(ζ₅)) with image of order 60), kept deliberately separate from `ExistsProjectiveEvenRep1951`, which is **not** inhabited.

**Disclaimer, in the module docstring and in new section 6f of `docs/ARTIN_A5_EVEN_1951.md`:** this is an embedding of `Gal(f₁₉₅₁)` into `PGL₂(ℚ(ζ₅))` with image `A₅`, and is *not* automatically the Doud–Moore even icosahedral Artin representation — `Aut(A₅) ≅ S₅` so an outer twist may change the conjugacy class of the embedding; evenness of `ρ̄(c)` at complex conjugation is not proved; Artin conductor 1951 is not proved for this composite; no `SL₂` lift is constructed. Two now-outdated sentences ("no Galois group is mapped into PGL₂", "neither result is composed with `gal1951_equiv_alternating`") were corrected in `ArtinA5Even/KleinPGL.lean`, `ArtinA5Even/AxiomAudit.lean` and the docs; the non-claims list was extended.

**Builds.** `lake build ArtinA5Even.RhoBar1951 ArtinA5Even.AxiomAudit` and `lake build ArtinA5Even` both succeed (each named module well under ten minutes). `AxiomAudit.lean` now prints all new results; every printed declaration depends only on `propext`, `Classical.choice`, `Quot.sound`. No `sorry`, no `axiom`, no `native_decide`, no Tate vanishing, no linear lift, no Maass form, no Artin/holomorphy/L-function claim. All work is committed and pushed.

# Summary of changes for run 3cf23ffe-b9e3-4fdc-8eab-d19ece75d3f5
## Task 0 — the library target is green again

`lake build ArtinA5Even` initially **failed**, and only on `ArtinA5Even.VonDyck235`: four `by group` steps inside the coset-table calc blocks left unsolved goals of the shape `a * b * a ^ 2 * b = a * b * a * a * b` (the `group` normaliser did not expand the numeral power). The file was **repaired in place** (not moved out of the glob) by replacing exactly those four steps with explicit `simp only [sq, pow_succ, pow_zero, one_mul, mul_assoc]` normalisations — no global string replacement, no tactic macro, no self-referential rewrite. The `a⁴` helper identities the instructions asked for were already present (`a4_a1 : a⁴·a = 1`, `a4_a4 : a⁴·a⁴ = a³`, `a4_a3 : a⁴·a³ = a²`), and `tbl4a` was the first table identity re-checked; it and the other five now build.

Final required check: `lake build ArtinA5Even` **succeeds** (whole library, ~1 min), as does
`lake build ArtinA5Even.VonDyck235 ArtinA5Even.PSL2F5 ArtinA5Even.KleinPGL ArtinA5Even.KleinFinField ArtinA5Even.AxiomAudit`.
`rg -n "sorry|admit|axiom|native_decide" ArtinA5Even` matches only prose inside comments. Every new public theorem is printed in `ArtinA5Even/AxiomAudit.lean` and depends only on `propext`, `Classical.choice`, `Quot.sound`.

## |Δ(2,3,5)| = 60, finished

`ArtinA5Even/VonDyck235.lean` now contains the complete argument:

- **Upper bound** (`VonDyck.card_closure_le`): in *any* group, `a⁵ = b² = (ab)³ = 1` implies `|⟨a,b⟩| ≤ 60`. Twelve coset representatives `w₀ = 1, …, w₁₁ = b a² b a³ b` are written down and all 24 entries `a·wⱼ`, `b·wⱼ` are derived from the three relations as standalone theorems (six nontrivial ones); the set `{wⱼaⁱ}` is then shown stable under left multiplication by `a`, `b`, `a⁻¹`, `b⁻¹`, so it contains `⟨a,b⟩`, which is in particular finite.
- **Lower bound** (`VonDyck.closure_permA_permB`): the five-cycle `(0 1 2 3 4)` and the double transposition `(1 2)(3 4)` satisfy the same relations and generate a subgroup of order divisible by 15, hence exactly `A₅`.
- **Glue**: `VonDyck.card_delta : Nat.card Δ(2,3,5) = 60` and `VonDyck.deltaEquivAlternating : Δ(2,3,5) ≃* A₅`, for the presented group `⟨x, y | x⁵, y², (xy)³⟩`. The identification is through this explicit isomorphism, not a slogan. Since `A₅` is simple, `VonDyck.closureEquivAlternating` then gives `⟨a,b⟩ ≃* A₅` — hence `VonDyck.card_closure_eq_sixty : Nat.card ⟨a,b⟩ = 60` — for any group elements with the three relations and `a ≠ 1`.

## Task 1 — 𝔽₁₁, and a note on the route

New file `ArtinA5Even/KleinFinField.lean` (`lake build ArtinA5Even.KleinFinField` ≈ 10 s). `3` is a primitive fifth root of unity in `𝔽₁₁`, so Klein's generators reduce to the classes of `diag(9,5)` and `!![1,4;4,10]` in `PGL₂(𝔽₁₁)` (both matrices checked by `decide`, never `native_decide`), with orders 5, 2, 3. Then `KleinF11.card_closure_eq_sixty : Nat.card ⟨a,b⟩ = 60` and `KleinF11.closureEquivAlternating : ⟨a,b⟩ ≃* A₅`; `KleinF11.sixty_le_card_closure` records the lower bound separately. The same two lines give the statement over `ℚ(ζ₅)` (`Klein.card_closure_eq_sixty_cyclotomic`).

**Deviation, stated plainly as the instructions allow:** the 60 projective classes are *not* enumerated as a `Finset`. Equality in `PGL₂ = GL₂/centre` is a quotient, so a `decide`-based closure check would first need a decidable normal form for projective classes. Finishing the coset upper bound and getting the lower bound from the surjection `Δ(2,3,5) ↠ ⟨a,b⟩` plus simplicity of `A₅` turned out to be both cheaper and stronger — it yields `= 60` rather than `≥ 60`, uniformly in the ambient group, and applies verbatim over `ℚ(ζ₅)`. Task 2's six nontrivial identities exist as standalone theorems, with no macros.

## Non-claims (unchanged)

No `ExistsProjectiveEvenRep1951`, no composite of any Galois group with `PGL₂`, no linear lift, no Maass form, no Artin or modularity claim. `ArtinS5`, `Zeta5`, `RequestProject` are neither touched nor imported, and no `axiom` is declared. `docs/ARTIN_A5_EVEN_1951.md` gained a section 6e describing the two bounds, the 𝔽₁₁ reduction and these limits, and the now-outdated sentence "it is not proved that Klein's a, b generate A₅" was corrected there and in the audit file.


# Summary of changes for run 417a24dd-7947-476b-a5fe-1457a7559224
Work stayed inside `ArtinA5Even/` and `docs/`; `ArtinS5`, `Zeta5`, `RequestProject` and the S₅ certificate files were not touched or imported.

**Build.** `lake build ArtinA5Even.PSL2F5 ArtinA5Even.KleinPGL ArtinA5Even.AxiomAudit` succeeds from a clean library build in under four minutes total (each named module well under 15 minutes). Zero `sorry`, zero `axiom` declarations; every printed result depends only on `propext`, `Classical.choice`, `Quot.sound`.

**Part 1 — `PSL₂(𝔽₅) ≅ A₅` (`ArtinA5Even/PSL2F5.lean`).** `ArtinA5Even.psl2F5_equiv_alternating : PSL₂(𝔽₅) ≃* A₅` is proved (with `nonempty_psl2F5_equiv_alternating` as its `Nonempty` form). The binary tetrahedral subgroup `2.A₄ ≅ SL₂(𝔽₃) ⊂ SL₂(𝔽₅)` is written down as an explicit list of 24 matrices and checked to be a subgroup by exhaustive evaluation; its order is 24 and its index 5; two explicit conjugations cut its normal core down to the centre `{±1}` (`normalCore_binTet`). The action on the five cosets therefore gives an injection with image of order 60 in `S₅`, and that image is exactly `A₅` (`range_permRepFin5`), using the already-proved fact that a subgroup of `S₅` of order divisible by 15 contains `A₅`.

**Part 2 — Klein's generators in `PGL₂` (`ArtinA5Even/KleinPGL.lean`).** Over any field containing a primitive fifth root of unity `z` (so also over ℚ(ζ₅)), `a = diag(z², z³)` and `b = !![-(z − z⁴), z² − z³; z² − z³, z − z⁴]` are built as elements of `GL₂` (Klein's `1/√5` is dropped, being invisible in `PGL₂`). In `GL₂` one has `a⁵ = 1`, `b² = −5·I`, `(ab)³ = 5(z − z⁴)(z² − z³)·I` — all scalar — so in `PGL₂`: `a⁵ = b² = (ab)³ = 1`, with exact orders 5, 2, 3 (`Klein.klein_icosahedral_relations`). `Klein.sqrtFive_sq` proves `(2(z + z⁴) + 1)² = 5`, i.e. ℚ(√5, ζ₅) = ℚ(ζ₅), and `Klein.klein_icosahedral_relations_cyclotomic` specialises everything to ℚ(ζ₅). It is *not* claimed that the subgroup generated by `a` and `b` is A₅, and neither Part 1 nor Part 2 is composed with the Galois group of the quintic.

**Part 0 — reconnaissance.** `docs/ARTIN_1951_ROUTES.md` contains the six-route table (A–F) with the "would prove / obstruction / circular? / Lean now" columns, the last column filled after checking the library (no Maass forms, no hyperbolic Laplacian or Selberg trace formula, no Artin L-functions, no automorphic representations, no modular curves, no class-field-theoretic local invariants; group cohomology `H2` exists only abstractly and the Brauer group only as a set-level definition). The ranking A > C > D > B > E > F is recorded, with C flagged as logically sufficient but analytically as hard as Artin, and Booker's implication kept as an external citation. Citations to Doud–Moore, Booker (Annals 158), Booker–Lee–Strömbergsson, Seymour-Howell, Calegari §12, Uttenthal (even solvable, not A₅), and the MathOverflow thread (numerical, not a proof) are included. `docs/ARTIN_A5_EVEN_1951.md` gained a section 6d describing the two new constructions and pointing at the routes file.

**Non-claims, unchanged.** `ExistsMaass1951` is neither proved, inhabited, nor assumed; no `R = 0` certificate, no eigenvalue search, no Fourier data imported as a theorem, no Tate vanishing, no Artin/modularity/L-function claim, and no composite `Gal(f₁₉₅₁) → PGL₂`. `ArtinA5Even/AxiomAudit.lean` prints the axiom dependencies of all new results and records these absences.

# Summary of changes for run 868a139e-af96-4c85-bff2-ceba09c0d0e6
Added `ArtinA5Even/LiftObstruction.lean`, a new sorry-free module inside the isolated `ArtinA5Even/` library (imports only `ArtinA5Even.Field1951`, `ArtinA5Even.GalA5`, `ArtinA5Even.GroupA5`; no `ArtinS5`, `Zeta5`, `RequestProject`). The target build

```
lake build ArtinA5Even.Field1951 ArtinA5Even.GalA5 ArtinA5Even.LiftObstruction ArtinA5Even.AxiomAudit
```

succeeds; every result in the library depends only on `propext`, `Classical.choice`, `Quot.sound`, and no `axiom` is declared.

**Task 1 — types.** `PSL2C = SL₂(ℂ)/centre` and the projection `projSL2C : SL₂(ℂ) →* PSL₂(ℂ)`, together with `sl2ToPgl2C : SL₂(ℂ) →* PGL₂(ℂ)`; the embedding problem is written as an explicit `Exists`, `LiftExists (rhobar : poly1951Q.Gal →* PGL2C) : Prop`, since Mathlib has no `H²(A₅,{±1})`. No homomorphism `poly1951Q.Gal →* PGL₂(ℂ)` is constructed, and no term of `ProjectiveEvenIcosahedral` or `SL2Lift` exists anywhere.

**Task 2 — group theory actually proved.**
- `mem_center_SL2_iff` / `coe_center_SL2` / `card_center_SL2`: over any field the centre of SL₂ is exactly `{±1}`.
- `projSL2C_surjective`, `ker_projSL2C`, `mem_ker_projSL2C_iff`, `card_center_SL2C`: exactness of `1 → {±1} → SL₂(ℂ) → PSL₂(ℂ) → 1`.
- `card_SL2F5 = 120`, `card_center_SL2F5 = 2`, `card_PSL2F5 = 60`, `card_PSL2F5_eq_card_alternating`: SL₂(𝔽₅) is a double cover of a group of the order of A₅.
- `SL2F5_unique_involution`: `-1` is the only element of order 2 of SL₂(𝔽₅) (exhaustive kernel-checked evaluation over the 120 elements); `neg_one_mem_of_two_dvd_card` (via Cauchy); and hence `SL2F5_extension_nonsplit`: **the double cover SL₂(𝔽₅) → PSL₂(𝔽₅) admits no homomorphic section**, so SL₂(𝔽₅) is the nonsplit cover 2.A₅ (binary icosahedral group). Mathlib contains no `PSL₂(𝔽₅) ≅ A₅` and no computation of `H²(A₅,{±1})`; both are recorded as standard citations in the module docstring, not as unproved theorems.

**Task 3 — three layers, none proved.** `ExistsProjectiveEvenRep1951`, `ExistsLinearLift1951`, and `ExistsMaass1951` are named Props; none is proved, assumed, or axiomatised. The only implications are the trivial `ExistsLinearLift1951 → ExistsProjectiveEvenRep1951` and the definitional `entireL_of_existsMaass1951`, which merely unfolds an assumption of the explicitly hypothetical `MaassInterface` (a type of forms with a level, an L-function, and assumed entirety) — no analysis, no modularity, no automorphy, no eigenvalue search, no matrix in SL₂(ℂ).

**Task 4 — docs.** `docs/ARTIN_A5_EVEN_1951.md` has a new section “6c. Embedding problem” with a status table (Gal ≅ A₅ proved; projective representation, SL₂(ℂ) lift, and Maass form all open in Lean), a list of exactly what the module proves and what it deliberately does not, and the summary sentence that this module names the missing objects and does not solve them. The non-claims section was extended to the three new Props.

`ArtinA5Even/AxiomAudit.lean` now also imports the new module and prints the axiom dependencies of all its results, and records in prose that no lift and no Maass form is inhabited. All work is committed and pushed.

# Summary of changes for run 8c2a82de-5211-476d-ba53-ab36cb7c9f5e
## Result: `Gal(f₁₉₅₁) ≅ A₅` is proved — unconditionally

Working only inside `ArtinA5Even/` (no import of `ArtinS5`, `Zeta5` or `RequestProject`), the target build

```
lake build ArtinA5Even.Field1951 ArtinA5Even.GalA5 ArtinA5Even.AxiomAudit
```

succeeds (~4 min from the pre-built Mathlib), with **zero `sorry`** anywhere in the library and every result depending only on `propext`, `Classical.choice`, `Quot.sound`.

### Main theorems (new)

- `ArtinA5Even.gal1951_equiv_alternating` — `Nonempty (poly1951Q.Gal ≃* alternatingGroup (Fin 5))`: the Galois group of the splitting field of the Doud–Moore quintic over ℚ is isomorphic to A₅. **No hypothesis is assumed.**
- `ArtinA5Even.gal_eq_A5_of_disc (hdisc : poly1951.discr = disc1951)` — the conditional form requested, in exactly that shape; the hypothesis is then discharged.
- `ArtinA5Even.poly1951_discr : poly1951.discr = disc1951` — the recorded integer `268684727248076769842884` is *proved* to be Mathlib's `Polynomial.discr` of the quintic. The 9×9 Sylvester determinant is never expanded: a four-step pseudo-remainder sequence on `f` and `f'` is run, each step an explicit integer-polynomial identity checked by `ring`, combined with Mathlib's resultant lemmas. No computer-algebra system is used as an oracle; the arithmetic is kernel-checked.
- `ArtinA5Even.evenIcosahedral1951` — the bundling structure `EvenIcosahedral1951` is now **inhabited**: all four fields (irreducibility, square discriminant, total reality, `Gal ≅ A₅`) are theorems.
- `ArtinA5Even.alternating_le_range_permRep1951` — a weaker statement proved with *no* discriminant input at all: the image of the Galois group in S₅ contains A₅ (so it is A₅ or S₅).

### How the exclusion of the other transitive subgroups is done

- `f₁₉₅₁` stays irreducible mod 3 ⇒ `5 ∣ |Gal|`; `f₁₉₅₁ ≡ (X²+6X+12)(X³+6X²+4X+7) (mod 13)` with the cubic irreducible over 𝔽₁₃ ⇒ `3 ∣ |Gal|`. Both come from the "easy half" of Dedekind's theorem, proved from scratch in `ArtinA5Even/Reduction.lean` via residue degrees of primes of the splitting field.
- The square discriminant forces even permutations: `ArtinA5Even/Discriminant.lean` identifies `discr` of a split monic quintic with the square of the Vandermonde product `δ = ∏_{i<j}(rⱼ − rᵢ)` and shows `σ δ = sign(σ)·δ`.
- `ArtinA5Even/GroupA5.lean`: a subgroup of A₅ of order divisible by 15 is all of A₅ (simplicity of A₅), and a subgroup of S₅ of order divisible by 15 contains A₅.

### Files

New: `ArtinA5Even/GalA5.lean`, `ArtinA5Even/Discriminant.lean`, `ArtinA5Even/Discr1951.lean` (plus `GroupA5.lean`, `Reduction.lean` from the earlier stage). Extended: `ArtinA5Even/AxiomAudit.lean` (isolated audit for this library only) now prints axioms for all new results. Docs `docs/ARTIN_A5_EVEN_1951.md` gained sections 6a/6b describing the discriminant computation and the Galois argument; the outdated "Gal ≅ A₅ is not proved / structure uninhabited" wording was corrected in the docs and in the `Field1951.lean` docstrings.

### Explicit non-claims (unchanged and restated in code and docs)

No 2.A₅-cover, no representation `Gal → SL₂(ℂ)`, no matrices in SL₂(ℂ), no residual images, no Maass form, no Artin/modularity/L-function claim. `ProjectiveEvenIcosahedral` and `SL2Lift` remain types with no term constructed. `ArtinS5`, `Zeta5`, `RequestProject` are not imported, and no `axiom` is declared.


# Summary of changes for run 30eb3f35-a676-4e79-83e5-2f3dbadf051c
Added a new, fully isolated Lean library `ArtinA5Even/` (its own `lean_lib` in `lakefile.toml`, importing only Mathlib — no `ArtinS5`, `Zeta5`, or `RequestProject`; no existing file was edited apart from adding the library entry to `lakefile.toml`).

**Build:** `lake build ArtinA5Even.Field1951 ArtinA5Even.AxiomAudit` succeeds in about 40 seconds. Zero `sorry`, zero `axiom` declarations; `#print axioms` for every result reports only `propext`, `Classical.choice`, `Quot.sound`.

**Task 0 — `docs/ARTIN_A5_EVEN_1951.md`.** States that this is not the disc-264544 S₅ field (with a comparison table); that η-positivity and Calegari 1.1/1.2 are odd-case statements and do not apply; that the predicted automorphic object is a Maass form of level 1951, not a holomorphic weight-1 form; that the obstruction to a Lean Artin theorem is (a) a lift ρ̃ : Gal → SL₂(ℂ) = 2.A₅ and (b) modularity of that lift, neither of which is in Mathlib; and that odd icosahedral is Khare–Wintenberger/BDST while even is open. It closes with an explicit list of non-claims.

**Task 1 — `ArtinA5Even/Field1951.lean`.**
- `poly1951 : ℤ[X]` is the Doud–Moore quintic; proved monic (`poly1951_monic`) and of degree 5 (`poly1951_degree`, `poly1951_natDegree`).
- `condPrime = 1951` with `condPrime_prime : Nat.Prime 1951`.
- `disc1951` records the discriminant as data (documented as computed outside Lean via the Sylvester resultant, since Mathlib has no polynomial discriminant); `disc1951_isSquare` proves the recorded value is (2·7·71·137·1951²)².
- Irreducibility is proved honestly rather than assumed: `poly1951_map_three` computes the reduction mod 3 as X⁵+2X⁴+2X²+X+2 over 𝔽₃; `poly1951Mod3_no_root` and `poly1951Mod3_no_quadratic_factor` rule out linear and all nine monic quadratic factors by explicit nonzero remainders; a general criterion `quintic_irreducible_criterion` then gives `poly1951Mod3_irreducible`, and Gauss's lemma gives `poly1951_irreducible_int` and `poly1951_irreducible_rat`.
- Total reality is also proved: `poly1951R_five_roots` locates five real roots by sign changes on (-27,-26), (-4,-3), (-1,0), (1,2), (29,30) via the intermediate value theorem, and `poly1951_totally_real` concludes that the quintic splits over ℝ.
- `structure EvenIcosahedral1951` bundles the four Props `irreducible`, `disc_sq`, `totally_real`, `gal_eq_A5`. The first three are discharged by the theorems above; `Gal ≅ A₅` is **not** proved and the structure is left uninhabited — no term of it is constructed anywhere.

**Task 2 — types only.** `ProjectiveEvenIcosahedral` (a projective representation of the absolute Galois group of ℚ into PGL₂(ℂ), even at a complex conjugation, factoring through the splitting field of the quintic, with image A₅) and `SL2Lift` (a lift to SL₂(ℂ)) are declared as structures with no terms constructed. The accompanying paragraph explains that H²(A₅,{±1}) ≅ C₂ makes 2.A₅ the unique nonsplit central extension, so some projective representations lift to GL₂(ℂ) with determinant a Dirichlet character only after a quadratic twist / passage to the central extension; no cocycle is computed.

**Task audit — `ArtinA5Even/AxiomAudit.lean`** prints the axiom dependencies of every result and documents the absences (no 2.A₅ lift, no matrices in SL₂(ℂ), no Maass eigenvalue search, no Euler tables, no L-function or modularity claim, no Weil-positivity import).