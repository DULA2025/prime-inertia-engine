# The product `L(ρ₃) · L(ρ₃′)` for the 1951 `A₅`-field — reconnaissance only

**Status: reconnaissance.** Nothing in this file is a Lean theorem, nothing here is claimed to
be proved in this library, and **no certificate is started**. It records mathematics that a
later run might use, together with the places where the naive version of the argument breaks.
No dyadic-enclosure or Abel-summation certificate is begun in this run, by instruction and in
fact.

Throughout, `K` is the Galois closure of `ℚ[x]/(f₁₉₅₁)`, `G = Gal(K/ℚ) ≅ A₅`
(`ArtinA5Even.gal1951_equiv_alternating`), and `ρ₃`, `ρ₃′` are the two three-dimensional
irreducible complex representations of `A₅`, interchanged by the outer automorphism of `A₅`
and, on characters, by `√5 ↦ −√5`.

## 1. The product is an abelian Hecke `L`-function

Let `H ≤ G` be a Sylow-normaliser `D₁₀` (order 10, index 6) and let `M = K^H` be the
corresponding **sextic** field, so `[M : ℚ] = 6` and `Gal(K/M) = H ≅ D₁₀`. Let `ψ` be the
nontrivial linear character of `D₁₀` (its abelianisation is `C₂`, so `ψ` is quadratic, with
kernel the cyclic `C₅`).

The classical identification is

```
ρ₃ ⊕ ρ₃′  ≅  Ind_{D₁₀}^{A₅} ψ .
```

Both sides have degree `6`, and the characters agree class by class (see §3). By the standard
inductivity of Artin `L`-functions in degree,

```
L(s, ρ₃) · L(s, ρ₃′)  =  L(s, Ind_{D₁₀}^{A₅} ψ, ℚ)  =  L_M(s, ψ) ,
```

an Artin `L`-function over `M` of a **one-dimensional** character of `Gal(K/M)`. Being
abelian and nontrivial, `ψ` corresponds under class field theory to a (quadratic) ray-class
character of `M`, and `L_M(s, ψ)` is a Hecke `L`-function of that character. Hecke's theory
gives it meromorphic continuation and a functional equation, and — because the character is
nontrivial — **entirety**.

**Therefore: entirety of the product is not the theorem to certify.** It is classical, and it
is *strictly weaker* than what one wants, which is holomorphy of each factor separately (that
is Artin's conjecture for `ρ₃`, open in the even icosahedral case; it would follow from the
automorphy of a two-dimensional lift, i.e. from the Maass form of level 1951 that this project
does not construct).

## 2. Why non-vanishing of the product proves nothing about a single factor

Suppose a later run produced a rigorous certificate that `L(s, ρ₃) L(s, ρ₃′) ≠ 0` (or is
finite, or is positive) at every `s ∈ (0, 1)`. **This does not imply that either factor is
holomorphic there.** A pole of `L(s, ρ₃)` at `s₀` cancelled by a zero of `L(s, ρ₃′)` at the
same point leaves the product finite and possibly nonzero-limiting; both statements about the
product are blind to the cancellation.

Any later certificate must therefore address the cancellation explicitly. The candidate
ingredients, none of them carried out here:

* **Galois conjugation `√5 ↦ −√5`.** The two characters `χ₃`, `χ₃′` are conjugate over
  `ℚ(√5)`, so the two `L`-functions are Galois conjugates of each other. Any argument using
  this must be careful: conjugation exchanges the factors, so it constrains the *pair* of
  divisors symmetrically rather than pinning down one factor.
* **Reality on the real line.** On `(0, 1)` both `L(s, ρ₃)` and `L(s, ρ₃′)` take values in
  `ℝ(√5)`-conjugate positions; sign/reality arguments can sometimes exclude a pole–zero pair,
  but only with a growth or positivity input.
* **Artin holomorphy on `Re s ≥ 1`.** For a nontrivial irreducible representation, `L(s, ρ)`
  is known to be holomorphic and nonvanishing on the line `Re s = 1` (this is the classical
  statement behind Chebotarev), and by Brauer induction it is meromorphic on `ℂ`. That is
  genuinely known, but it is a statement on `Re s = 1`, not on the critical strip, so it must
  be combined with continuation and a zero-counting/functional-equation input before it says
  anything at, say, `s = 1/2`.

None of the above is formalised in this library, and no partial certificate towards any of it
exists here.

## 3. Integer Euler data (numerics used, not theorems)

The character sum is, on the four classes of element order `1, 2, 3, 5` of `A₅` (i.e. cycle
types `1⁵`, `2².1`, `3.1²`, `5`):

```
χ₃ + χ₃′  =  ( 6, −2, 0, 1 ) .
```

(The value `1` is the same on both classes `5A`, `5B`; the individual characters `χ₃`, `χ₃′`
take the two values `(1 ± √5)/2` there and are *not* rational.)

Hence for an unramified prime `p` (in particular `p ≠ 1951`) the local factor of the product,
i.e. `det(1 − T · (ρ₃ ⊕ ρ₃′)(Frob_p))`, depends only on the order of `Frob_p`:

| order of `Frob_p` | cycle type | local factor of the product |
| --- | --- | --- |
| `1` | `1⁵` | `(1 − T)⁶` |
| `2` | `2².1` | `(1 − T)²(1 + T)⁴` |
| `3` | `3.1²` | `(1 − T)²(1 + T + T²)²` |
| `5` | `5` | `(1 − T)(1 − T⁵)` |

(Traces check: `2 − 4 = −2`; `2 + 2(ω + ω²) = 0`; `(1 − T)(1 − T⁵) = (1 − T)²(1 + T + T² + T³ + T⁴)`
has trace `2 − 1 = 1`.) These are **rational integer** Euler factors — a reflection of the
fact that the product is the induced, `ℚ`-rational, six-dimensional representation.

These tables are recorded as data for a possible later computation. They are **not** entered as
Lean theorems here: they would be one-liners only if the library carried the character table of
`A₅` and a Frobenius–cycle-type dictionary, and it carries neither. In particular no Euler
table is imported from, or shared with, any other library in this repository.

## 4. What is deliberately *not* done

* no dyadic enclosure, no Abel-summation certificate, no numerical evaluation of any
  `L`-function;
* no claim that `L(s, ρ₃)` is entire, holomorphic, or nonvanishing anywhere;
* no Maass form, no modularity, no Artin claim of any kind;
* no term of `ArtinA5Even.ExistsMaass1951` or `ArtinA5Even.ExistsProjectiveEvenRep1951`;
* no `axiom`, no `native_decide`.
