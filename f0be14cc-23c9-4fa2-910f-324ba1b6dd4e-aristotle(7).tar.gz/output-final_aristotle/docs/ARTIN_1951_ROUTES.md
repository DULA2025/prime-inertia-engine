# Routes to the even icosahedral object of conductor 1951 — reconnaissance

**Status of this document: literature map, not mathematics.**  Nothing in the table below is
proved, assumed, or encoded as a Lean theorem.  The Lean library `ArtinA5Even/` contains **no**
Maass form, **no** inhabitant of `ExistsMaass1951`, **no** `R = 0` eigenvalue certificate, and
**no** numerical Fourier data promoted to a theorem.

## The binding constraint

* Calegari, *Reciprocity in the Langlands program since Fermat's Last Theorem*
  (arXiv:2109.14145), §12: there is not a single known **even icosahedral** Artin representation
  for which the corresponding Maass form has been *proved* to exist.  The odd case is settled
  (Khare–Wintenberger, plus Buzzard–Dickinson–Shepherd-Barron–Taylor for the icosahedral
  residual cases); the even case is open.
* Booker, *Artin's conjecture, Turing's method, and the Riemann hypothesis* (Experiment. Math.,
  and the rigorous converse-theorem side in Math. Z. 2019): the converse direction — from a
  Maass form of icosahedral type back to a Galois representation — requires automorphy of
  `Sym⁶`, which is not known in this setting.

Consequently the six routes below are *directions in the literature*, ranked by how much of
them could conceivably be formalised, not a proof strategy that terminates in a theorem.

## The table

The last column records what Mathlib (v4.28.0 toolchain, Mathlib pinned in
`lake-manifest.json`) actually contains, checked by searching the library.

| Route | Would prove | Main obstruction | Circular? | Lean now |
|---|---|---|---|---|
| **A.** Selberg trace formula / Seymour–Howell rigorous eigenvalue computation at level `N = 1951`, spectral parameter `R = 0` | existence of an exact `λ = 1/4` (i.e. `R = 0`) Maass eigenform of level 1951 | Mathlib has no hyperbolic Laplacian, no Maass forms, no Selberg trace formula, no spectral theory on `Γ₀(N)\ℍ`; and the published numerics give `R ≈ 0` to high precision, which is not `R = 0` | no | **none** — searching Mathlib for `Maass`, Selberg, or an automorphic Laplacian returns nothing; `Mathlib/NumberTheory/ModularForms/` is entirely holomorphic |
| **B.** Fourier series plus a uniqueness theorem | that an explicitly given `K`-Bessel (`K₀`) expansion is automorphic | there is no uniqueness/rigidity lemma available (no "a function with these Fourier coefficients and this growth is a Maass form"), and the coefficient data in circulation is numerical | no | **none** — no Maass Fourier expansion, no `K`-Bessel automorphy criterion; `Mathlib` has `Complex.Gamma`, Hurwitz/Dirichlet `L`-series, but no Whittaker theory |
| **C.** Booker, *Poles of Artin L-functions and the strong Artin conjecture* (Ann. of Math. 158 (2003)): entirety of the Artin `L`-function implies strong Artin | the Maass form, from holomorphy of `L(s, ρ)` | for this two-dimensional `ρ` holomorphy of `L(s, ρ)` **is** the Artin conjecture: analytically exactly as hard as the target | **yes**, if used as the main goal (it is logically sufficient, not a reduction to something easier) | **citation only** — Mathlib has no Artin `L`-function at all (`Mathlib/NumberTheory/LSeries/` covers Riemann, Hurwitz, Dirichlet); Booker's implication is external and is deliberately *not* encoded as a Lean theorem |
| **D.** Pullback along `H²(G_ℚ, {±1})`: solve the embedding problem for `1 → {±1} → SL₂(ℂ) → PGL₂(ℂ)` | a linear lift `ρ̃ : G_ℚ → SL₂(ℂ)` of the projective representation | needs the local Brauer/Hasse invariants of this specific field, hence local–global class field theory; Tate's vanishing `H²(G_ℚ, ℂ^×) = 0` is likewise unavailable | no | **types only** — abstract `groupCohomology.H2` exists, and `Mathlib/Algebra/BrauerGroup/Defs.lean` defines the Brauer *set* of a field, but there are no local invariants, no class field theory, and no `H²(A₅, {±1})` computation.  In this repository the embedding problem is written as an explicit `Exists` in `ArtinA5Even/LiftObstruction.lean`, with no term constructed |
| **E.** `Ad⁰ρ` on `GL₃`, then descend | automorphy of the 3-dimensional adjoint, then of `ρ` itself | the descent step (recovering `π` from `Sym²π`, i.e. inverting the Gelbart–Jacquet lift in the even icosahedral case) is open | **risk** of circularity: the descent input is close to the desired automorphy | **none** — no automorphic representations, no `GL₃`, no functorial lifts in Mathlib |
| **F.** Modular curves / a geometric model of `PSL₂(𝔽₅)` | a geometric handle on the residual/projective picture `ρ̄` | a geometric model does not produce a Maass form; it says nothing about the archimedean (even) place | no | **partly available now** — the group-theoretic core `PSL₂(𝔽₅) ≅ A₅` is *proved* in this repository (`ArtinA5Even.psl2F5_equiv_alternating`), and Klein's `(2,3,5)` generators in `PGL₂(ℚ(ζ₅))` are constructed (`ArtinA5Even.Klein.klein_icosahedral_relations`).  Mathlib has no modular curves (`ModularCurve` does not exist) |

## Ranking

**A > C > D > B > E > F**, with two annotations:

* **C is logically sufficient** — Booker's theorem really does deliver the automorphic object
  from entirety — but it is *analytically as hard as Artin's conjecture itself* for this `ρ`,
  so it converts the problem into an equivalent one rather than an easier one.  It is cited,
  never used as a Lean hypothesis or conclusion.
* **F is last for the automorphic goal**, but it is the only row where anything is currently
  provable in Lean; that is exactly why the two finite constructions of this run live there.

## What this run actually proved (and what it did not)

Proved, sorry-free, in the isolated library `ArtinA5Even/`:

* `ArtinA5Even.psl2F5_equiv_alternating : PSL₂(𝔽₅) ≃* A₅` — the exceptional isomorphism, via
  the action of `SL₂(𝔽₅)` on the five cosets of an explicit binary tetrahedral subgroup of
  order 24, whose normal core is shown to be the centre `{±1}`.
* `ArtinA5Even.Klein.klein_icosahedral_relations` — Klein's generators `a = diag(z², z³)` and
  the involution `b`, over any field containing a primitive fifth root of unity `z` (Klein's
  `1/√5` is dropped, being invisible in `PGL₂`), satisfy `a⁵ = b² = (ab)³ = 1` in `PGL₂` and
  have exact orders `5`, `2`, `3`.  Specialised to `ℚ(ζ₅) = ℚ(√5, ζ₅)`, since
  `(2(z + z⁴) + 1)² = 5`.

Not proved, and deliberately not stated as anything but a named `Prop`:

* the existence of a Maass form of level 1951 (`ExistsMaass1951` is neither proved nor
  inhabited nor assumed anywhere);
* the existence of a linear lift `ρ̃ : G_ℚ → SL₂(ℂ)`;
* that the subgroup of `PGL₂` generated by Klein's `a` and `b` is `A₅`;
* any composite of `gal1951_equiv_alternating` with `psl2F5_equiv_alternating` or with the
  Klein generators.  Such a composite would *not* be the arithmetic representation attached to
  `f₁₉₅₁`: matching Frobenius conjugacy classes is a separate problem, left for later.

## References

* D. Doud, M. Moore, *Even icosahedral Galois representations of prime conductor*,
  arXiv:math/0405534.  Source of the quintic
  `f₁₉₅₁ = x⁵ − x⁴ − 780x³ − 1795x² + 3106x + 344` and of the conductor 1951.
* A. Booker, *Poles of Artin L-functions and the strong Artin conjecture*, Ann. of Math. (2)
  158 (2003).
* A. Booker, M. Lee, A. Strömbergsson, *Twist-minimal trace formulas and the Selberg
  eigenvalue conjecture*, arXiv:1803.06016.
* A. Booker, work on the converse theorem for Maass forms of icosahedral type (Math. Z. 2019);
  the reverse implication requires `Sym⁶` automorphy.
* A. Seymour-Howell, *Rigorous computation of Maass cusp forms of squarefree level*,
  arXiv:2201.08760.
* F. Calegari, *Reciprocity in the Langlands program since Fermat's Last Theorem*,
  arXiv:2109.14145, §12 (even icosahedral: no example is known to be modular).
* P. Uttenthal (2025/26), even **solvable** cases — not `A₅`; does not cover the icosahedral
  situation treated here.
* MathOverflow question 98262 on even icosahedral Maass forms: numerical, explicitly not a
  proof, and not imported into Lean in any form.
