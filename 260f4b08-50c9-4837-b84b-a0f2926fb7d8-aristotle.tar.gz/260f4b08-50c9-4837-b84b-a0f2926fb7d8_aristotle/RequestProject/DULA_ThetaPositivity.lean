/-
  DULA_ThetaPositivity.lean

  WEIL POSITIVITY OF THE TWISTED COEFFICIENTS FOR θ_A₂
  ===================================================

  This file formalizes the positivity of the twisted Fourier coefficients
  f(n) = χ₃(n) · σ_χ₃(n) for the weight-1 Eisenstein series θ_A₂.

  Here χ₃ is the Legendre symbol mod 3 (the unique primitive quadratic
  character of conductor 3), and σ_χ₃(n) = ∑_{d|n} χ₃(d).

  This positivity is a standard arithmetic fact. It does NOT prove GRH
  or directly apply Viazovska's sphere-packing method. The connection
  to GRH remains an open heuristic in the DULA framework.
-/

import Mathlib

open Nat Finset BigOperators

namespace DULA.ThetaPositivity

/-! ## Part 1: χ₃ as a ℤ-valued function -/

/-- The Legendre symbol mod 3, as a ℤ-valued function on ℕ.
    χ₃(n) = 1 if n ≡ 1 (mod 3), -1 if n ≡ 2 (mod 3), 0 if 3 ∣ n. -/
def chi3 (n : ℕ) : ℤ :=
  if n % 3 = 1 then 1
  else if n % 3 = 2 then -1
  else 0

/-- σ_χ₃(n) = ∑_{d|n} χ₃(d). -/
def sigma_chi3 (n : ℕ) : ℤ :=
  ∑ d ∈ n.divisors, chi3 d

/-- Twisted coefficient f(n) = χ₃(n) · σ_χ₃(n). -/
def f (n : ℕ) : ℤ :=
  chi3 n * sigma_chi3 n

/-! ## Part 2: Basic properties of χ₃ -/

@[simp] theorem chi3_zero : chi3 0 = 0 := by simp [chi3]

theorem chi3_mod (n : ℕ) : chi3 n = chi3 (n % 3) := by
  simp [chi3, Nat.mod_mod_of_dvd]

theorem chi3_one : chi3 1 = 1 := by simp [chi3]
theorem chi3_two : chi3 2 = -1 := by simp [chi3]
theorem chi3_three : chi3 3 = 0 := by simp [chi3]

theorem chi3_values (n : ℕ) : chi3 n = 0 ∨ chi3 n = 1 ∨ chi3 n = -1 := by
  simp [chi3]
  omega

theorem chi3_mul (a b : ℕ) : chi3 (a * b) = chi3 a * chi3 b := by
  unfold chi3; norm_num [ Nat.mul_mod ] ; have := Nat.mod_lt a zero_lt_three; have := Nat.mod_lt b zero_lt_three; interval_cases a % 3 <;> interval_cases b % 3 <;> norm_num;

/-! ## Part 3: Multiplicativity of σ_χ₃ and f -/

theorem sigma_chi3_mul {a b : ℕ} (ha : a > 0) (hb : b > 0) (h : Nat.Coprime a b) :
    sigma_chi3 (a * b) = sigma_chi3 a * sigma_chi3 b := by
  -- By definition of divisors, we can rewrite the sum over the divisors of $ab$ as a product of sums over divisors of $a$ and $b$.
  have h_divisors : (a * b).divisors = Finset.image (fun (p : ℕ × ℕ) => p.1 * p.2) (a.divisors ×ˢ b.divisors) := by
    exact Nat.divisors_mul _ _;
  simp_all +decide [ Finset.sum_product, sigma_chi3 ];
  rw [ Finset.sum_image, Finset.sum_product ];
  · rw [ Finset.sum_mul ];
    simp +decide only [chi3_mul, Finset.mul_sum _ _ _];
  · intros p hp q hq h_eq;
    have h_eq_parts : p.1 ∣ q.1 ∧ q.1 ∣ p.1 := by
      norm_num +zetaDelta at *;
      exact ⟨ Nat.Coprime.dvd_of_dvd_mul_right ( Nat.Coprime.coprime_dvd_left hp.1.1 <| Nat.Coprime.coprime_dvd_right hq.2.1 h ) <| h_eq ▸ dvd_mul_right _ _, Nat.Coprime.dvd_of_dvd_mul_right ( Nat.Coprime.coprime_dvd_left hq.1.1 <| Nat.Coprime.coprime_dvd_right hp.2.1 h ) <| h_eq.symm ▸ dvd_mul_right _ _ ⟩;
    have := Nat.dvd_antisymm h_eq_parts.1 h_eq_parts.2; aesop;

theorem f_mul {a b : ℕ} (ha : a > 0) (hb : b > 0) (h : Nat.Coprime a b) :
    f (a * b) = f a * f b := by
  unfold f
  rw [chi3_mul, sigma_chi3_mul ha hb h]
  ring

/-! ## Part 4: Prime Power Evaluations -/

theorem chi3_pow_mod3_eq0 {p : ℕ} (hp : p % 3 = 0) (k : ℕ) (hk : k > 0) :
    chi3 (p ^ k) = 0 := by
  unfold chi3;
  norm_num [ Nat.pow_mod, hp, hk.ne' ]

theorem chi3_pow_mod3_eq1 {p : ℕ} (hp : p % 3 = 1) (k : ℕ) :
    chi3 (p ^ k) = 1 := by
  unfold chi3;
  norm_num [ Nat.pow_mod, hp ]

theorem chi3_pow_mod3_eq2 {p : ℕ} (hp : p % 3 = 2) (k : ℕ) :
    chi3 (p ^ k) = (-1) ^ k := by
  induction k <;> simp_all +decide [ pow_succ', chi3_mul ];
  unfold chi3; simp +decide [ *, pow_succ ] ;

theorem sigma_chi3_pow_mod3_eq0 {p : ℕ} (hp_prime : p.Prime) (hp : p % 3 = 0) (k : ℕ) :
    sigma_chi3 (p ^ k) = 1 := by
  -- Since $p$ is prime and $p \equiv 0 \pmod{3}$, we have $p = 3$.
  have hp_eq_3 : p = 3 := by
    have := Nat.dvd_of_mod_eq_zero hp; rw [ hp_prime.dvd_iff_eq ] at this <;> aesop;
  rcases k with ( _ | k ) <;> simp_all +decide [ Nat.divisors_prime_pow ];
  unfold sigma_chi3; rw [ Nat.divisors_prime_pow ( by norm_num ) ] ; simp +decide [ Finset.sum_range_succ', pow_succ ] ;
  norm_num [ chi3 ]

theorem sigma_chi3_pow_mod3_eq1 {p : ℕ} (hp : p.Prime) (hp1 : p % 3 = 1) (k : ℕ) :
    sigma_chi3 (p ^ k) = (k : ℤ) + 1 := by
  -- Use the formula for sigma_chi3 to rewrite the left-hand side.
  unfold sigma_chi3
  simp [Nat.divisors_prime_pow hp];
  rw [ Finset.sum_congr rfl fun x hx => chi3_pow_mod3_eq1 hp1 x ] ; norm_num

theorem sigma_chi3_pow_mod3_eq2 {p : ℕ} (hp : p.Prime) (hp2 : p % 3 = 2) (k : ℕ) :
    sigma_chi3 (p ^ k) = (1 + (-1 : ℤ) ^ k) / 2 := by
  -- The divisors of $p^k$ are $p^0, p^1, \ldots, p^k$, so we can write
  have hdivisors : (p^k).divisors = Finset.image (fun i => p^i) (Finset.range (k+1)) := by
    norm_num [ Nat.divisors_prime_pow hp, Finset.ext_iff ];
  -- Substitute the divisors into the sum
  have hsum : sigma_chi3 (p^k) = ∑ x ∈ Finset.range (k+1), (-1 : ℤ)^x := by
    rw [sigma_chi3, hdivisors, Finset.sum_image];
    · exact Finset.sum_congr rfl fun i hi => chi3_pow_mod3_eq2 hp2 i;
    · exact fun i hi j hj hij => Nat.pow_right_injective hp.one_lt hij
  simp_all +decide [ Nat.pow_mod ] ; ring_nf; (
  rcases Nat.even_or_odd' k with ⟨ c, rfl | rfl ⟩ <;> norm_num [ Nat.even_add ] at *;)

/-! ## Part 5: f at prime powers is non-negative -/

theorem f_prime_power_mod3_eq0 {p : ℕ} (hp : p % 3 = 0) (k : ℕ) (hk : k > 0) :
    f (p ^ k) = 0 := by
  unfold f
  rw [chi3_pow_mod3_eq0 hp k hk]
  ring

theorem f_prime_power_mod3_eq1 {p : ℕ} (hp : p.Prime) (hp1 : p % 3 = 1) (k : ℕ) :
    f (p ^ k) = (k : ℤ) + 1 := by
  unfold f
  rw [chi3_pow_mod3_eq1 hp1 k, sigma_chi3_pow_mod3_eq1 hp hp1 k]
  ring

theorem f_prime_power_mod3_eq2 {p : ℕ} (hp : p.Prime) (hp2 : p % 3 = 2) (k : ℕ) :
    f (p ^ k) ≥ 0 := by
  unfold f;
  rw [ chi3_pow_mod3_eq2 hp2, sigma_chi3_pow_mod3_eq2 hp hp2 ];
  by_cases h : Even k <;> norm_num [ h ];
  aesop

theorem f_prime_power_nonneg (p k : ℕ) (hp : p.Prime) : f (p ^ k) ≥ 0 := by
  have hp3 : p % 3 = 0 ∨ p % 3 = 1 ∨ p % 3 = 2 := by omega
  rcases hp3 with h0 | h1 | h2
  · by_cases hk : k = 0
    · subst hk; simp [f, sigma_chi3, chi3_one, Nat.divisors]; decide
    · rw [f_prime_power_mod3_eq0 h0 k (by omega)]
  · rw [f_prime_power_mod3_eq1 hp h1 k]; positivity
  · exact f_prime_power_mod3_eq2 hp h2 k

/-! ## Part 6: The Main Positivity Theorem -/

theorem f_zero : f 0 = 0 := by simp [f, sigma_chi3, chi3_zero]
theorem f_one : f 1 = 1 := by simp [f, sigma_chi3, chi3_one]

theorem twisted_coefficients_nonneg (n : ℕ) : f n ≥ 0 := by
  induction' n using Nat.strongRecOn with n ih;
  by_cases hn : n = 0 ∨ n = 1;
  · rcases hn with ( rfl | rfl ) <;> native_decide;
  · -- Since $n$ is not 0 or 1, it must have a prime factor $p$.
    obtain ⟨p, hp_prime, hp_div⟩ : ∃ p, Nat.Prime p ∧ p ∣ n := by
      exact Nat.exists_prime_and_dvd ( by tauto );
    -- Let $k$ be such that $n = p^k * m$ where $m$ is not divisible by $p$.
    obtain ⟨k, m, rfl, hm_not_div⟩ : ∃ k m, n = p^k * m ∧ ¬p ∣ m := by
      exact ⟨ Nat.factorization n p, n / p ^ Nat.factorization n p, by rw [ Nat.mul_div_cancel' ( Nat.ordProj_dvd _ _ ) ], Nat.not_dvd_ordCompl ( by aesop ) ( by aesop ) ⟩;
    rw [ f_mul ];
    · exact mul_nonneg ( f_prime_power_nonneg p k hp_prime ) ( ih m ( lt_mul_of_one_lt_left ( Nat.pos_of_ne_zero ( by aesop ) ) ( one_lt_pow₀ hp_prime.one_lt ( by aesop ) ) ) );
    · exact pow_pos hp_prime.pos _;
    · exact Nat.pos_of_ne_zero ( by aesop );
    · exact Nat.Coprime.pow_left _ ( hp_prime.coprime_iff_not_dvd.mpr hm_not_div )

/-! ## Verification Checks -/

#check twisted_coefficients_nonneg
#print axioms twisted_coefficients_nonneg

end DULA.ThetaPositivity