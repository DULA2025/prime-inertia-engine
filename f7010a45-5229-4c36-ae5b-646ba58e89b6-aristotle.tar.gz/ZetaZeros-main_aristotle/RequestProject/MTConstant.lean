/-
Sharp numerical bounds for the Montgomery–Taylor constant.
-/
import Mathlib

/-!
# The Montgomery–Taylor constant, to twelve decimal places

The two headline proportions for the zeros of the Riemann zeta function,

* `simpleProportion = 3/2 - (1/√2) cot(1/√2)` (zeros that are simple and on the critical line),
* `distinctProportion = 5/4 - (1/(2√2)) cot(1/√2)` (distinct zeros),

are governed by the Montgomery–Taylor constant `C_MT = 1/2 + (1/√2) cot(1/√2)`.

Here we pin `C_MT` down to twelve decimal places, which sharpens the customary numerical
statements `0.6725` and `0.83625` to

* `0.672500703679 < simpleProportion`,
* `0.836250351839 < distinctProportion`.

The method is the classical one: `(1/√2)² = 1/2`, so both `cos(1/√2)` and `√2 sin(1/√2)` are
alternating series with *rational* terms.  Eight terms of each bracket the two values to sixteen
decimal places.
-/

namespace MontgomeryTaylor

open Finset
open scoped Nat

/-- The Montgomery–Taylor constant `1/2 + (1/√2) cot(1/√2) = 1.327499296320588…`. -/
noncomputable def mtConst : ℝ := 1 / 2 + (1 / Real.sqrt 2) * Real.cot (1 / Real.sqrt 2)

/-- The proportion of zeros shown to be simple and on the critical line,
`3/2 - (1/√2) cot(1/√2) = 0.672500703679411…`. -/
noncomputable def simpleProportion : ℝ :=
  3 / 2 - (1 / Real.sqrt 2) * Real.cot (1 / Real.sqrt 2)

/-- The proportion of zeros shown to be distinct,
`5/4 - (1/(2√2)) cot(1/√2) = 0.836250351839705…`. -/
noncomputable def distinctProportion : ℝ :=
  5 / 4 - (1 / (2 * Real.sqrt 2)) * Real.cot (1 / Real.sqrt 2)

section Elementary

private lemma sqrt_two_pos : 0 < Real.sqrt 2 := Real.sqrt_pos.mpr (by norm_num)

/-- `(1/√2)² = 1/2`: this is what makes the two series below rational. -/
private lemma inv_sqrt_two_sq : (1 / Real.sqrt 2) ^ 2 = 1 / 2 := by
  rw [div_pow, one_pow, Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 2)]

private lemma inv_sqrt_two_lt_one : 1 / Real.sqrt 2 < 1 := by
  rw [div_lt_one sqrt_two_pos, ← Real.sqrt_one]
  exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)

end Elementary

/-- `sin(1/√2) > 0`. -/
theorem sin_inv_sqrt_two_pos : 0 < Real.sin (1 / Real.sqrt 2) :=
  Real.sin_pos_of_pos_of_le_one (by positivity) inv_sqrt_two_lt_one.le

/-- The `k`-th term of the rational series for `cos(1/√2)`. -/
noncomputable def cosTerm (k : ℕ) : ℝ := 1 / (2 ^ k * ((2 * k)! : ℝ))

/-- The `k`-th term of the rational series for `√2 sin(1/√2)`. -/
noncomputable def sinTerm (k : ℕ) : ℝ := 1 / (2 ^ k * ((2 * k + 1)! : ℝ))

/-- `cos(1/√2)` is the alternating sum of `1 / (2ᵏ (2k)!)`. -/
theorem hasSum_cosTerm :
    HasSum (fun k : ℕ => (-1 : ℝ) ^ k * cosTerm k) (Real.cos (1 / Real.sqrt 2)) := by
  have h := Real.hasSum_cos (1 / Real.sqrt 2)
  have hfun : (fun n : ℕ => (-1 : ℝ) ^ n * (1 / Real.sqrt 2) ^ (2 * n) / ((2 * n)! : ℝ))
      = fun k : ℕ => (-1 : ℝ) ^ k * cosTerm k := by
    funext k
    rw [cosTerm, pow_mul, inv_sqrt_two_sq, div_pow, one_pow]
    have : ((2 * k)! : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero _)
    field_simp
  rwa [hfun] at h

/-- `√2 sin(1/√2)` is the alternating sum of `1 / (2ᵏ (2k+1)!)`. -/
theorem hasSum_sinTerm :
    HasSum (fun k : ℕ => (-1 : ℝ) ^ k * sinTerm k)
      (Real.sqrt 2 * Real.sin (1 / Real.sqrt 2)) := by
  have h := (Real.hasSum_sin (1 / Real.sqrt 2)).mul_left (Real.sqrt 2)
  have hfun : (fun n : ℕ => Real.sqrt 2 *
        ((-1 : ℝ) ^ n * (1 / Real.sqrt 2) ^ (2 * n + 1) / ((2 * n + 1)! : ℝ)))
      = fun k : ℕ => (-1 : ℝ) ^ k * sinTerm k := by
    funext k
    rw [sinTerm, pow_succ, pow_mul, inv_sqrt_two_sq, div_pow, one_pow]
    have hf : ((2 * k + 1)! : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero _)
    have hs : Real.sqrt 2 ≠ 0 := ne_of_gt sqrt_two_pos
    field_simp
  rwa [hfun] at h

private lemma cosTerm_antitone : Antitone cosTerm := by
  refine antitone_nat_of_succ_le fun n => ?_
  have hpos : (0:ℝ) < 2 ^ n * ((2 * n)! : ℝ) := by
    have : (0:ℝ) < ((2 * n)! : ℝ) := Nat.cast_pos.mpr (Nat.factorial_pos _)
    positivity
  have hle : (2:ℝ) ^ n * ((2 * n)! : ℝ) ≤ 2 ^ (n + 1) * ((2 * (n + 1))! : ℝ) := by
    have hf : ((2 * n)! : ℝ) ≤ ((2 * (n + 1))! : ℝ) :=
      Nat.cast_le.mpr (Nat.factorial_le (by omega))
    have hp : (2:ℝ) ^ n ≤ 2 ^ (n + 1) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h1 : (0:ℝ) < (2:ℝ) ^ n := by positivity
    have h2 : (0:ℝ) < ((2 * n)! : ℝ) := Nat.cast_pos.mpr (Nat.factorial_pos _)
    nlinarith
  simpa [cosTerm] using one_div_le_one_div_of_le hpos hle

private lemma sinTerm_antitone : Antitone sinTerm := by
  refine antitone_nat_of_succ_le fun n => ?_
  have hpos : (0:ℝ) < 2 ^ n * ((2 * n + 1)! : ℝ) := by
    have : (0:ℝ) < ((2 * n + 1)! : ℝ) := Nat.cast_pos.mpr (Nat.factorial_pos _)
    positivity
  have hle : (2:ℝ) ^ n * ((2 * n + 1)! : ℝ) ≤ 2 ^ (n + 1) * ((2 * (n + 1) + 1)! : ℝ) := by
    have hf : ((2 * n + 1)! : ℝ) ≤ ((2 * (n + 1) + 1)! : ℝ) :=
      Nat.cast_le.mpr (Nat.factorial_le (by omega))
    have hp : (2:ℝ) ^ n ≤ 2 ^ (n + 1) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h1 : (0:ℝ) < (2:ℝ) ^ n := by positivity
    have h2 : (0:ℝ) < ((2 * n + 1)! : ℝ) := Nat.cast_pos.mpr (Nat.factorial_pos _)
    nlinarith
  simpa [sinTerm] using one_div_le_one_div_of_le hpos hle

/-- Nine terms bound `cos(1/√2)` from above. -/
theorem cos_inv_sqrt_two_lt : Real.cos (1 / Real.sqrt 2) < 0.760244597075631 := by
  have h := Antitone.tendsto_le_alternating_series
    hasSum_cosTerm.tendsto_sum_nat cosTerm_antitone 4
  have hsum : ∑ i ∈ Finset.range (2 * 4 + 1), (-1 : ℝ) ^ i * cosTerm i < 0.760244597075631 := by
    norm_num [Finset.sum_range_succ, cosTerm, Nat.factorial]
  linarith

/-- Eight terms bound `cos(1/√2)` from below. -/
theorem cos_inv_sqrt_two_gt : 0.760244597075629 < Real.cos (1 / Real.sqrt 2) := by
  have h := Antitone.alternating_series_le_tendsto
    hasSum_cosTerm.tendsto_sum_nat cosTerm_antitone 4
  have hsum : (0.760244597075629 : ℝ) < ∑ i ∈ Finset.range (2 * 4), (-1 : ℝ) ^ i * cosTerm i := by
    norm_num [Finset.sum_range_succ, cosTerm, Nat.factorial]
  linarith

/-- Eight terms bound `√2 sin(1/√2)` from below. -/
theorem sqrt_two_mul_sin_inv_sqrt_two_gt :
    0.918725369865568 < Real.sqrt 2 * Real.sin (1 / Real.sqrt 2) := by
  have h := Antitone.alternating_series_le_tendsto
    hasSum_sinTerm.tendsto_sum_nat sinTerm_antitone 4
  have hsum : (0.918725369865568 : ℝ) < ∑ i ∈ Finset.range (2 * 4), (-1 : ℝ) ^ i * sinTerm i := by
    norm_num [Finset.sum_range_succ, sinTerm, Nat.factorial]
  linarith

/-- Nine terms bound `√2 sin(1/√2)` from above. -/
theorem sqrt_two_mul_sin_inv_sqrt_two_lt :
    Real.sqrt 2 * Real.sin (1 / Real.sqrt 2) < 0.918725369865569 := by
  have h := Antitone.tendsto_le_alternating_series
    hasSum_sinTerm.tendsto_sum_nat sinTerm_antitone 4
  have hsum : ∑ i ∈ Finset.range (2 * 4 + 1), (-1 : ℝ) ^ i * sinTerm i < 0.918725369865569 := by
    norm_num [Finset.sum_range_succ, sinTerm, Nat.factorial]
  linarith

private lemma cot_eq :
    (1 / Real.sqrt 2) * Real.cot (1 / Real.sqrt 2)
      = Real.cos (1 / Real.sqrt 2) / (Real.sqrt 2 * Real.sin (1 / Real.sqrt 2)) := by
  rw [Real.cot_eq_cos_div_sin]
  have hs : Real.sin (1 / Real.sqrt 2) ≠ 0 := ne_of_gt sin_inv_sqrt_two_pos
  have h2 : Real.sqrt 2 ≠ 0 := ne_of_gt sqrt_two_pos
  field_simp

/-- `(1/√2) cot(1/√2) < 0.827499296321`. -/
theorem inv_sqrt_two_mul_cot_lt :
    (1 / Real.sqrt 2) * Real.cot (1 / Real.sqrt 2) < 0.827499296321 := by
  have hden : 0 < Real.sqrt 2 * Real.sin (1 / Real.sqrt 2) :=
    mul_pos sqrt_two_pos sin_inv_sqrt_two_pos
  rw [cot_eq, div_lt_iff₀ hden]
  nlinarith [cos_inv_sqrt_two_lt, sqrt_two_mul_sin_inv_sqrt_two_gt]

/-- `0.827499296320 < (1/√2) cot(1/√2)`. -/
theorem inv_sqrt_two_mul_cot_gt :
    0.827499296320 < (1 / Real.sqrt 2) * Real.cot (1 / Real.sqrt 2) := by
  have hden : 0 < Real.sqrt 2 * Real.sin (1 / Real.sqrt 2) :=
    mul_pos sqrt_two_pos sin_inv_sqrt_two_pos
  rw [cot_eq, lt_div_iff₀ hden]
  nlinarith [cos_inv_sqrt_two_gt, sqrt_two_mul_sin_inv_sqrt_two_lt]

/-- The Montgomery–Taylor constant, to twelve decimal places:
`1.327499296320 < C_MT < 1.327499296321`. -/
theorem mtConst_lt : mtConst < 1.327499296321 := by
  have := inv_sqrt_two_mul_cot_lt
  rw [mtConst]; linarith

theorem mtConst_gt : 1.327499296320 < mtConst := by
  have := inv_sqrt_two_mul_cot_gt
  rw [mtConst]; linarith

/-- `simpleProportion = 2 - C_MT`. -/
theorem simpleProportion_eq : simpleProportion = 2 - mtConst := by
  rw [simpleProportion, mtConst]; ring

/-- `distinctProportion = 3/2 - C_MT/2`. -/
theorem distinctProportion_eq : distinctProportion = 3 / 2 - mtConst / 2 := by
  rw [distinctProportion, mtConst]
  have hs : Real.sqrt 2 ≠ 0 := ne_of_gt sqrt_two_pos
  field_simp
  ring

/-- **Sharpened numerical bound.** `0.672500703679 < 3/2 - (1/√2) cot(1/√2)`, improving the
usual `0.6725`. -/
theorem simpleProportion_gt : 0.672500703679 < simpleProportion := by
  rw [simpleProportion_eq]; linarith [mtConst_lt]

/-- The matching upper bound: `3/2 - (1/√2) cot(1/√2) < 0.672500703680`, so the constant above
is best possible to twelve decimal places. -/
theorem simpleProportion_lt : simpleProportion < 0.672500703680 := by
  rw [simpleProportion_eq]; linarith [mtConst_gt]

/-- **Sharpened numerical bound.** `0.836250351839 < 5/4 - (1/(2√2)) cot(1/√2)`, improving the
usual `0.83625`. -/
theorem distinctProportion_gt : 0.836250351839 < distinctProportion := by
  rw [distinctProportion_eq]; linarith [mtConst_lt]

/-- The matching upper bound: `5/4 - (1/(2√2)) cot(1/√2) < 0.836250351840`. -/
theorem distinctProportion_lt : distinctProportion < 0.836250351840 := by
  rw [distinctProportion_eq]; linarith [mtConst_gt]

end MontgomeryTaylor
