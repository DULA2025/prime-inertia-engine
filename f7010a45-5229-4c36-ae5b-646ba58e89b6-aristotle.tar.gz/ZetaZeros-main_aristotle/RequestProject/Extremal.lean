/-
Optimality of the Montgomery–Taylor test function.
-/
import Mathlib
import RequestProject.MTConstant

/-!
# The Montgomery–Taylor constant is optimal

In the pair-correlation approach to simple zeros of the Riemann zeta function one picks a test
function `q` (in the applications `q = η²` for an admissible `η`), supported in `[-1/2, 1/2]` and
normalised by `∫ q = 1`, and the resulting proportion of zeros shown to be simple and on the
critical line is `2 - A(q)`, where

`A(q) = ∫ q² + ∫∫ q(x) q(y) |x - y| dx dy`

is the pair-correlation main term `f(0) + 2 ∫₀¹ α f(α) dα` evaluated at the self-convolution
`f = q ⋆ q`.  Similarly the proportion of distinct zeros obtained is `3/2 - A(q)/2`.  Both are
*decreasing* in `A(q)`, so the constants obtained are best possible exactly when `A(q)` is as
small as possible.

The main result here, `mtEnergy_ge`, is that

`A(q) ≥ C_MT = 1/2 + (1/√2) cot(1/√2)`

for every continuous `q` with `∫_{-1/2}^{1/2} q = 1`, with equality for the Montgomery–Taylor
function `q₀(x) = cos(√2 x) / (√2 sin(1/√2))` (`mtEnergy_extremalTest`).  Consequently the
proportions `0.672500703679…` and `0.836250351839…` cannot be improved by any other choice of
test function: they are the exact limit of this method.

The proof turns the two-dimensional problem into a one-dimensional variational problem.  Writing
`Φ(x) = ∫_{-1/2}^x q`, two integrations by parts give

`A(q) = ∫_{-1/2}^{1/2} (Φ'² + 2Φ - 2Φ²)`,

a classical Euler–Lagrange problem with boundary conditions `Φ(-1/2) = 0`, `Φ(1/2) = 1`.  Its
solution is `Φ₀ = 1/2 + sin(√2 x)/(2 sin(1/√2))`, and for a perturbation `h = Φ - Φ₀` (vanishing
at both endpoints) the excess is exactly `∫ h'² - 2 ∫ h²`, which is nonnegative by the Poincaré
inequality `∫ h² ≤ (1/4) ∫ h'²` (the constant `1/4` beats the required `1/2`).
-/

namespace MontgomeryTaylor

open intervalIntegral MeasureTheory

/-- The pair-correlation functional at the self-convolution of `q`:
`A(q) = ∫ q² + ∫∫ q(x) q(y) |x - y|`, both integrals over `[-1/2, 1/2]`. -/
noncomputable def mtEnergy (q : ℝ → ℝ) : ℝ :=
  (∫ x in (-(1:ℝ)/2)..(1/2), q x ^ 2) +
    ∫ x in (-(1:ℝ)/2)..(1/2), ∫ y in (-(1:ℝ)/2)..(1/2), q x * q y * |x - y|

/-- The primitive `Φ(x) = ∫_{-1/2}^x q` of a test function. -/
noncomputable def primitive (q : ℝ → ℝ) (x : ℝ) : ℝ := ∫ y in (-(1:ℝ)/2)..x, q y

/-- The Montgomery–Taylor extremal test function `q₀(x) = cos(√2 x) / (√2 sin(1/√2))`. -/
noncomputable def extremalTest (x : ℝ) : ℝ :=
  Real.cos (Real.sqrt 2 * x) / (Real.sqrt 2 * Real.sin (1 / Real.sqrt 2))

/-- The primitive of the Montgomery–Taylor function,
`Φ₀(x) = 1/2 + sin(√2 x) / (2 sin(1/√2))`. -/
noncomputable def extremalPrimitive (x : ℝ) : ℝ :=
  1 / 2 + Real.sin (Real.sqrt 2 * x) / (2 * Real.sin (1 / Real.sqrt 2))

section Basic

private lemma sqrt_two_pos : 0 < Real.sqrt 2 := Real.sqrt_pos.mpr (by norm_num)

private lemma sqrt_two_ne : Real.sqrt 2 ≠ 0 := ne_of_gt sqrt_two_pos

private lemma sqrt_two_sq : Real.sqrt 2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)

private lemma sin_ne : Real.sin (1 / Real.sqrt 2) ≠ 0 := ne_of_gt sin_inv_sqrt_two_pos

private lemma hasDerivAt_mul_id (x : ℝ) :
    HasDerivAt (fun y : ℝ => Real.sqrt 2 * y) (Real.sqrt 2) x := by
  simpa using (hasDerivAt_id x).const_mul (Real.sqrt 2)

@[fun_prop]
lemma continuous_extremalTest : Continuous extremalTest := by
  unfold extremalTest; fun_prop

@[fun_prop]
lemma continuous_extremalPrimitive : Continuous extremalPrimitive := by
  unfold extremalPrimitive; fun_prop

/-- `Φ₀' = q₀`. -/
lemma hasDerivAt_extremalPrimitive (x : ℝ) :
    HasDerivAt extremalPrimitive (extremalTest x) x := by
  have h1 : HasDerivAt (fun x : ℝ => Real.sin (Real.sqrt 2 * x))
      (Real.cos (Real.sqrt 2 * x) * Real.sqrt 2) x :=
    (Real.hasDerivAt_sin _).comp x (hasDerivAt_mul_id x)
  have h3 := (h1.div_const (2 * Real.sin (1 / Real.sqrt 2))).const_add (1/2 : ℝ)
  convert h3 using 1
  rw [extremalTest]
  field_simp [sin_ne, sqrt_two_ne]
  rw [sqrt_two_sq]
  ring

/-- `q₀' = 1 - 2 Φ₀`: the Euler–Lagrange equation. -/
lemma hasDerivAt_extremalTest (x : ℝ) :
    HasDerivAt extremalTest (1 - 2 * extremalPrimitive x) x := by
  have h1 : HasDerivAt (fun x : ℝ => Real.cos (Real.sqrt 2 * x))
      (-Real.sin (Real.sqrt 2 * x) * Real.sqrt 2) x :=
    (Real.hasDerivAt_cos _).comp x (hasDerivAt_mul_id x)
  have h3 := h1.div_const (Real.sqrt 2 * Real.sin (1 / Real.sqrt 2))
  convert h3 using 1
  rw [extremalPrimitive]
  field_simp [sin_ne, sqrt_two_ne]
  ring

lemma extremalPrimitive_neg_half : extremalPrimitive (-(1:ℝ)/2) = 0 := by
  have hx : Real.sqrt 2 * (-(1:ℝ)/2) = -(1 / Real.sqrt 2) := by
    field_simp
    nlinarith [Real.mul_self_sqrt (by norm_num : (0:ℝ) ≤ 2)]
  have hs' : Real.sin (Real.sqrt 2)⁻¹ ≠ 0 := by rw [← one_div]; exact sin_ne
  rw [extremalPrimitive, hx, Real.sin_neg]
  field_simp [sin_ne]
  rw [div_self sin_ne]
  ring

lemma extremalPrimitive_half : extremalPrimitive (1/2 : ℝ) = 1 := by
  have hx : Real.sqrt 2 * (1/2 : ℝ) = 1 / Real.sqrt 2 := by
    field_simp
    nlinarith [Real.mul_self_sqrt (by norm_num : (0:ℝ) ≤ 2)]
  have hs' : Real.sin (Real.sqrt 2)⁻¹ ≠ 0 := by rw [← one_div]; exact sin_ne
  rw [extremalPrimitive, hx]
  field_simp [sin_ne]
  rw [div_self sin_ne]
  ring

end Basic

section Primitive

variable {q : ℝ → ℝ}

lemma primitive_neg_half (q : ℝ → ℝ) : primitive q (-(1:ℝ)/2) = 0 := by
  simp [primitive]

lemma hasDerivAt_primitive (hq : Continuous q) (x : ℝ) :
    HasDerivAt (primitive q) (q x) x :=
  intervalIntegral.integral_hasDerivAt_right (hq.intervalIntegrable _ _)
    (hq.stronglyMeasurableAtFilter _ _) hq.continuousAt

lemma continuous_primitive (hq : Continuous q) : Continuous (primitive q) :=
  continuous_iff_continuousAt.2 fun x => (hasDerivAt_primitive hq x).continuousAt

/-- The primitive of the Montgomery–Taylor function is `Φ₀`. -/
lemma primitive_extremalTest : primitive extremalTest = extremalPrimitive := by
  funext x
  rw [primitive, intervalIntegral.integral_eq_sub_of_hasDerivAt
      (fun y _ => hasDerivAt_extremalPrimitive y)
      (continuous_extremalTest.intervalIntegrable _ _), extremalPrimitive_neg_half, sub_zero]

end Primitive

section Reduction

variable {q : ℝ → ℝ}

/-- First integration by parts: `∫_{-1/2}^b q(y) (b - y) dy = ∫_{-1/2}^b Φ`. -/
lemma integral_mul_sub_left (hq : Continuous q) (b : ℝ) :
    (∫ y in (-(1:ℝ)/2)..b, q y * (b - y)) = ∫ t in (-(1:ℝ)/2)..b, primitive q t := by
  have key := intervalIntegral.integral_mul_deriv_eq_deriv_mul
    (a := -(1:ℝ)/2) (b := b) (u := fun y : ℝ => b - y) (u' := fun _ : ℝ => (-1 : ℝ))
    (v := primitive q) (v' := q) (fun y _ => (hasDerivAt_id y).const_sub b)
    (fun y _ => hasDerivAt_primitive hq y) (continuous_const.intervalIntegrable _ _)
    (hq.intervalIntegrable _ _)
  rw [primitive_neg_half] at key
  have h1 : (∫ y in (-(1:ℝ)/2)..b, q y * (b - y)) = ∫ y in (-(1:ℝ)/2)..b, (b - y) * q y :=
    intervalIntegral.integral_congr fun y _ => by ring
  rw [h1, key]
  simp

/-- Second integration by parts:
`∫_a^{1/2} q(y) (y - a) dy = (1/2 - a) Φ(1/2) - ∫_a^{1/2} Φ`. -/
lemma integral_mul_sub_right (hq : Continuous q) (a : ℝ) :
    (∫ y in a..(1/2 : ℝ), q y * (y - a))
      = (1/2 - a) * primitive q (1/2) - ∫ t in a..(1/2 : ℝ), primitive q t := by
  have key := intervalIntegral.integral_mul_deriv_eq_deriv_mul
    (a := a) (b := (1/2 : ℝ)) (u := fun y : ℝ => y - a) (u' := fun _ : ℝ => (1 : ℝ))
    (v := primitive q) (v' := q) (fun y _ => (hasDerivAt_id y).sub_const a)
    (fun y _ => hasDerivAt_primitive hq y) (continuous_const.intervalIntegrable _ _)
    (hq.intervalIntegrable _ _)
  have h1 : (∫ y in a..(1/2:ℝ), q y * (y - a)) = ∫ y in a..(1/2:ℝ), (y - a) * q y :=
    intervalIntegral.integral_congr fun y _ => by ring
  rw [h1, key]
  simp

/-- The inner integral `∫ q(y) |x - y| dy`, expressed through the iterated primitive. -/
lemma inner_integral (hq : Continuous q) {x : ℝ} (hx : x ∈ Set.Icc (-(1:ℝ)/2) (1/2)) :
    (∫ y in (-(1:ℝ)/2)..(1/2), q y * |x - y|)
      = 2 * primitive (primitive q) x - primitive (primitive q) (1/2)
        + (1/2 - x) * primitive q (1/2) := by
  obtain ⟨hx1, hx2⟩ := hx
  have hcont : Continuous fun y : ℝ => q y * |x - y| := by fun_prop
  have hsplit : (∫ y in (-(1:ℝ)/2)..x, q y * |x - y|) + (∫ y in x..(1/2:ℝ), q y * |x - y|)
      = ∫ y in (-(1:ℝ)/2)..(1/2), q y * |x - y| :=
    intervalIntegral.integral_add_adjacent_intervals
      (hcont.intervalIntegrable _ _) (hcont.intervalIntegrable _ _)
  have hleft : (∫ y in (-(1:ℝ)/2)..x, q y * |x - y|) = ∫ y in (-(1:ℝ)/2)..x, q y * (x - y) := by
    refine intervalIntegral.integral_congr fun y hy => ?_
    rw [Set.uIcc_of_le hx1, Set.mem_Icc] at hy
    rw [abs_of_nonneg (by linarith [hy.2])]
  have hright : (∫ y in x..(1/2:ℝ), q y * |x - y|) = ∫ y in x..(1/2:ℝ), q y * (y - x) := by
    refine intervalIntegral.integral_congr fun y hy => ?_
    rw [Set.uIcc_of_le hx2, Set.mem_Icc] at hy
    rw [abs_of_nonpos (by linarith [hy.1]), neg_sub]
  rw [← hsplit, hleft, hright, integral_mul_sub_left hq, integral_mul_sub_right hq]
  have hPsi : (∫ t in x..(1/2:ℝ), primitive q t)
      = primitive (primitive q) (1/2) - primitive (primitive q) x := by
    have hadj := intervalIntegral.integral_add_adjacent_intervals
      (μ := volume) (a := -(1:ℝ)/2) (b := x) (c := (1/2:ℝ)) (f := primitive q)
      ((continuous_primitive hq).intervalIntegrable _ _)
      ((continuous_primitive hq).intervalIntegrable _ _)
    simp only [primitive] at hadj ⊢
    linarith [hadj]
  rw [hPsi]
  simp only [primitive]
  ring

/-- **The reduction to a one-dimensional variational problem:**
`A(q) = ∫ (q² + 2Φ - 2Φ²)` where `Φ` is the primitive of `q`. -/
lemma mtEnergy_eq_variational (hq : Continuous q) (hmass : primitive q (1/2 : ℝ) = 1) :
    mtEnergy q
      = ∫ x in (-(1:ℝ)/2)..(1/2),
          (q x ^ 2 + 2 * primitive q x - 2 * primitive q x ^ 2) := by
  have hcΦ : Continuous (primitive q) := continuous_primitive hq
  have hcΨ : Continuous (primitive (primitive q)) := continuous_primitive hcΦ
  set Φ := primitive q with hΦ
  set Ψ := primitive (primitive q) with hΨ
  have step : ∀ x ∈ Set.uIcc (-(1:ℝ)/2) (1/2 : ℝ),
      (∫ y in (-(1:ℝ)/2)..(1/2), q x * q y * |x - y|)
        = 2 * (q x * Ψ x) - Ψ (1/2) * q x + q x * (1/2 - x) := by
    intro x hx
    rw [Set.uIcc_of_le (by norm_num : (-(1:ℝ)/2) ≤ 1/2)] at hx
    have h1 : (∫ y in (-(1:ℝ)/2)..(1/2), q x * q y * |x - y|)
        = q x * ∫ y in (-(1:ℝ)/2)..(1/2), q y * |x - y| := by
      rw [← intervalIntegral.integral_const_mul]
      exact intervalIntegral.integral_congr fun y _ => by ring
    rw [h1, inner_integral hq hx]
    simp only [← hΦ, hmass]
    ring
  rw [mtEnergy, intervalIntegral.integral_congr step]
  have hsum : (∫ x in (-(1:ℝ)/2)..(1/2), (2 * (q x * Ψ x) - Ψ (1/2) * q x + q x * (1/2 - x)))
      = 2 * (∫ x in (-(1:ℝ)/2)..(1/2), q x * Ψ x) - Ψ (1/2) * (∫ x in (-(1:ℝ)/2)..(1/2), q x)
        + ∫ x in (-(1:ℝ)/2)..(1/2), q x * (1/2 - x) := by
    rw [intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul]
  rw [hsum]
  have hq1 : (∫ x in (-(1:ℝ)/2)..(1/2), q x) = 1 := hmass
  have hlin : (∫ x in (-(1:ℝ)/2)..(1/2), q x * (1/2 - x)) = Ψ (1/2) :=
    integral_mul_sub_left hq (1/2)
  have hIBP : (∫ x in (-(1:ℝ)/2)..(1/2), q x * Ψ x)
      = Ψ (1/2) * Φ (1/2) - ∫ x in (-(1:ℝ)/2)..(1/2), Φ x * Φ x := by
    have key := intervalIntegral.integral_mul_deriv_eq_deriv_mul
      (a := -(1:ℝ)/2) (b := (1/2:ℝ)) (u := Ψ) (u' := Φ) (v := Φ) (v' := q)
      (fun y _ => hasDerivAt_primitive hcΦ y) (fun y _ => hasDerivAt_primitive hq y)
      (hcΦ.intervalIntegrable _ _) (hq.intervalIntegrable _ _)
    rw [hΨ, hΦ, primitive_neg_half] at key
    have hcomm : (∫ x in (-(1:ℝ)/2)..(1/2), q x * Ψ x) = ∫ x in (-(1:ℝ)/2)..(1/2), Ψ x * q x :=
      intervalIntegral.integral_congr fun y _ => by ring
    rw [hcomm, key]
    ring
  rw [hIBP, hlin, hq1, hmass]
  have hexpand : (∫ x in (-(1:ℝ)/2)..(1/2), (q x ^ 2 + 2 * Φ x - 2 * Φ x ^ 2))
      = (∫ x in (-(1:ℝ)/2)..(1/2), q x ^ 2) + 2 * (∫ x in (-(1:ℝ)/2)..(1/2), Φ x)
        - 2 * ∫ x in (-(1:ℝ)/2)..(1/2), Φ x ^ 2 := by
    rw [intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul]
  rw [hexpand]
  have hsq : (∫ x in (-(1:ℝ)/2)..(1/2), Φ x * Φ x) = ∫ x in (-(1:ℝ)/2)..(1/2), Φ x ^ 2 :=
    intervalIntegral.integral_congr fun y _ => by ring
  have hPsi_half : Ψ (1/2 : ℝ) = ∫ x in (-(1:ℝ)/2)..(1/2), Φ x := rfl
  rw [hsq, hPsi_half]
  ring

end Reduction

section Poincare

/-- Cauchy–Schwarz on an interval: `(∫_a^b f)² ≤ (b - a) ∫_a^b f²`. -/
lemma sq_integral_le (f : ℝ → ℝ) (hf : Continuous f) {a b : ℝ} (hab : a ≤ b) :
    (∫ x in a..b, f x) ^ 2 ≤ (b - a) * ∫ x in a..b, f x ^ 2 := by
  rcases eq_or_lt_of_le hab with rfl | hlt
  · simp
  set c : ℝ := (∫ x in a..b, f x) / (b - a) with hc
  have hba : 0 < b - a := sub_pos.mpr hlt
  have h0 : 0 ≤ ∫ x in a..b, (f x - c) ^ 2 :=
    intervalIntegral.integral_nonneg hab fun x _ => sq_nonneg _
  have hexp : (∫ x in a..b, (f x - c) ^ 2)
      = (∫ x in a..b, f x ^ 2) - 2 * c * (∫ x in a..b, f x) + c ^ 2 * (b - a) := by
    have hrw : (∫ x in a..b, (f x - c) ^ 2)
        = ∫ x in a..b, (f x ^ 2 - 2 * c * f x + c ^ 2) :=
      intervalIntegral.integral_congr fun x _ => by ring
    rw [hrw, intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_const_mul, intervalIntegral.integral_const, smul_eq_mul]
    ring
  rw [hexp] at h0
  have hceq : c * (b - a) = ∫ x in a..b, f x := by
    rw [hc, div_mul_cancel₀ _ (ne_of_gt hba)]
  nlinarith [h0, hceq, sq_nonneg c]

/-- The Poincaré inequality on `[-1/2, 1/2]` for a function vanishing at both endpoints:
`∫ h² ≤ (1/4) ∫ h'²`. -/
lemma poincare {h h' : ℝ → ℝ} (hd : ∀ x, HasDerivAt h (h' x) x) (hc : Continuous h')
    (h0 : h (-(1:ℝ)/2) = 0) (h1 : h (1/2 : ℝ) = 0) :
    (∫ x in (-(1:ℝ)/2)..(1/2), h x ^ 2) ≤ (1/4) * ∫ x in (-(1:ℝ)/2)..(1/2), h' x ^ 2 := by
  have hch : Continuous h := continuous_iff_continuousAt.2 fun x => (hd x).continuousAt
  set S : ℝ := ∫ x in (-(1:ℝ)/2)..(1/2), h' x ^ 2 with hS
  have hSnonneg : 0 ≤ S :=
    intervalIntegral.integral_nonneg (by norm_num) fun x _ => sq_nonneg _
  -- values of `h` as integrals of `h'`
  have hval : ∀ u v : ℝ, (∫ x in u..v, h' x) = h v - h u := fun u v =>
    intervalIntegral.integral_eq_sub_of_hasDerivAt (fun x _ => hd x) (hc.intervalIntegrable _ _)
  -- monotonicity of the energy on subintervals
  have hsub : ∀ u v : ℝ, -(1:ℝ)/2 ≤ u → u ≤ v → v ≤ 1/2 →
      (∫ x in u..v, h' x ^ 2) ≤ S := by
    intro u v hu huv hv
    have h1' : (∫ x in (-(1:ℝ)/2)..u, h' x ^ 2) + (∫ x in u..v, h' x ^ 2)
        + (∫ x in v..(1/2:ℝ), h' x ^ 2) = S := by
      have e1 := intervalIntegral.integral_add_adjacent_intervals
        (μ := volume) (a := -(1:ℝ)/2) (b := u) (c := v) (f := fun x => h' x ^ 2)
        (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop)
      have e2 := intervalIntegral.integral_add_adjacent_intervals
        (μ := volume) (a := -(1:ℝ)/2) (b := v) (c := (1/2:ℝ)) (f := fun x => h' x ^ 2)
        (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop)
      rw [hS]; linarith
    have hA : 0 ≤ ∫ x in (-(1:ℝ)/2)..u, h' x ^ 2 :=
      intervalIntegral.integral_nonneg hu fun x _ => sq_nonneg _
    have hB : 0 ≤ ∫ x in v..(1/2:ℝ), h' x ^ 2 :=
      intervalIntegral.integral_nonneg hv fun x _ => sq_nonneg _
    linarith
  -- pointwise bounds on `h²`
  have hleft : ∀ x ∈ Set.Icc (-(1:ℝ)/2) 0, h x ^ 2 ≤ (x + 1/2) * S := by
    intro x hx
    obtain ⟨hx1, hx2⟩ := hx
    have hCS := sq_integral_le h' hc hx1
    rw [hval] at hCS
    have : (h x - h (-(1:ℝ)/2)) ^ 2 ≤ (x - (-(1:ℝ)/2)) * ∫ t in (-(1:ℝ)/2)..x, h' t ^ 2 := hCS
    rw [h0, sub_zero] at this
    have hmono := hsub (-(1:ℝ)/2) x le_rfl hx1 (by linarith)
    nlinarith [this, hmono, sq_nonneg (h x)]
  have hright : ∀ x ∈ Set.Icc (0:ℝ) (1/2), h x ^ 2 ≤ (1/2 - x) * S := by
    intro x hx
    obtain ⟨hx1, hx2⟩ := hx
    have hCS := sq_integral_le h' hc hx2
    rw [hval] at hCS
    have hkey : (h (1/2:ℝ) - h x) ^ 2 ≤ ((1/2:ℝ) - x) * ∫ t in x..(1/2:ℝ), h' t ^ 2 := hCS
    rw [h1] at hkey
    have hmono := hsub x (1/2 : ℝ) (by linarith) hx2 le_rfl
    nlinarith [hkey, hmono, sq_nonneg (h x)]
  -- integrate the pointwise bounds
  have hsplit : (∫ x in (-(1:ℝ)/2)..0, h x ^ 2) + (∫ x in (0:ℝ)..(1/2), h x ^ 2)
      = ∫ x in (-(1:ℝ)/2)..(1/2), h x ^ 2 :=
    intervalIntegral.integral_add_adjacent_intervals
      (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop)
  have hIleft : (∫ x in (-(1:ℝ)/2)..0, h x ^ 2) ≤ S / 8 := by
    have hbound : (∫ x in (-(1:ℝ)/2)..0, h x ^ 2) ≤ ∫ x in (-(1:ℝ)/2)..0, (x + 1/2) * S := by
      apply intervalIntegral.integral_mono_on (by norm_num)
        (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop)
      intro x hx
      exact hleft x (by simpa using hx)
    have hcomp : (∫ x in (-(1:ℝ)/2)..0, (x + 1/2) * S) = S / 8 := by
      rw [intervalIntegral.integral_mul_const]
      have : (∫ x in (-(1:ℝ)/2)..(0:ℝ), (x + 1/2)) = 1/8 := by
        rw [intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
            (by apply Continuous.intervalIntegrable; fun_prop), integral_id,
          intervalIntegral.integral_const]
        norm_num
      rw [this]; ring
    linarith [hbound, hcomp.le, hcomp.ge]
  have hIright : (∫ x in (0:ℝ)..(1/2), h x ^ 2) ≤ S / 8 := by
    have hbound : (∫ x in (0:ℝ)..(1/2), h x ^ 2) ≤ ∫ x in (0:ℝ)..(1/2), (1/2 - x) * S := by
      apply intervalIntegral.integral_mono_on (by norm_num)
        (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop)
      intro x hx
      exact hright x (by simpa using hx)
    have hcomp : (∫ x in (0:ℝ)..(1/2), (1/2 - x) * S) = S / 8 := by
      rw [intervalIntegral.integral_mul_const]
      have : (∫ x in (0:ℝ)..(1/2:ℝ), (1/2 - x)) = 1/8 := by
        rw [intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
            (by apply Continuous.intervalIntegrable; fun_prop), integral_id,
          intervalIntegral.integral_const]
        norm_num
      rw [this]; ring
    linarith [hbound, hcomp.le, hcomp.ge]
  linarith [hsplit, hIleft, hIright]

end Poincare

section Main

/-- The value of the variational functional at the extremal function is the Montgomery–Taylor
constant. -/
lemma variational_extremal :
    (∫ x in (-(1:ℝ)/2)..(1/2),
      (extremalTest x ^ 2 + 2 * extremalPrimitive x - 2 * extremalPrimitive x ^ 2))
      = mtConst := by
  have hs : Real.sin (1 / Real.sqrt 2) ≠ 0 := sin_ne
  have h2 : Real.sqrt 2 ≠ 0 := sqrt_two_ne
  -- the integrand collapses to `cos(2√2 x) / (2 sin²(1/√2)) + 1/2`
  have hpt : ∀ x ∈ Set.uIcc (-(1:ℝ)/2) (1/2 : ℝ),
      extremalTest x ^ 2 + 2 * extremalPrimitive x - 2 * extremalPrimitive x ^ 2
        = Real.cos (2 * (Real.sqrt 2 * x)) / (2 * Real.sin (1 / Real.sqrt 2) ^ 2) + 1/2 := by
    intro x _
    rw [Real.cos_two_mul', extremalTest, extremalPrimitive]
    field_simp
    rw [sqrt_two_sq]
    ring
  rw [intervalIntegral.integral_congr hpt]
  have hsplit : (∫ x in (-(1:ℝ)/2)..(1/2),
        (Real.cos (2 * (Real.sqrt 2 * x)) / (2 * Real.sin (1 / Real.sqrt 2) ^ 2) + 1/2))
      = (∫ x in (-(1:ℝ)/2)..(1/2), Real.cos (2 * (Real.sqrt 2 * x)))
          / (2 * Real.sin (1 / Real.sqrt 2) ^ 2) + 1/2 := by
    rw [intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_div]
    norm_num
  rw [hsplit]
  -- the cosine integral
  have hcos : (∫ x in (-(1:ℝ)/2)..(1/2), Real.cos (2 * (Real.sqrt 2 * x)))
      = Real.sin (Real.sqrt 2) / Real.sqrt 2 := by
    have hderiv : ∀ x : ℝ, HasDerivAt (fun y : ℝ => Real.sin (2 * (Real.sqrt 2 * y))
        / (2 * Real.sqrt 2)) (Real.cos (2 * (Real.sqrt 2 * x))) x := by
      intro x
      have hin : HasDerivAt (fun y : ℝ => 2 * (Real.sqrt 2 * y)) (2 * Real.sqrt 2) x := by
        simpa [mul_assoc] using (hasDerivAt_id x).const_mul (2 * Real.sqrt 2)
      have := ((Real.hasDerivAt_sin _).comp x hin).div_const (2 * Real.sqrt 2)
      convert this using 1
      field_simp
    rw [intervalIntegral.integral_eq_sub_of_hasDerivAt (fun x _ => hderiv x)
      (by apply Continuous.intervalIntegrable; fun_prop)]
    have e1 : 2 * (Real.sqrt 2 * (1/2 : ℝ)) = Real.sqrt 2 := by ring
    have e2 : 2 * (Real.sqrt 2 * (-(1:ℝ)/2)) = -Real.sqrt 2 := by ring
    rw [e1, e2, Real.sin_neg]
    field_simp
    ring
  rw [hcos]
  -- and the double-angle identity `sin √2 = 2 sin(1/√2) cos(1/√2)`
  have hdouble : Real.sin (Real.sqrt 2)
      = 2 * Real.sin (1 / Real.sqrt 2) * Real.cos (1 / Real.sqrt 2) := by
    have harg : (2 : ℝ) * (1 / Real.sqrt 2) = Real.sqrt 2 := by
      field_simp
      nlinarith [Real.mul_self_sqrt (by norm_num : (0:ℝ) ≤ 2)]
    have h2m := Real.sin_two_mul (1 / Real.sqrt 2)
    rwa [harg] at h2m
  rw [hdouble, mtConst, Real.cot_eq_cos_div_sin]
  field_simp
  ring

/-- The Montgomery–Taylor function is normalised: `∫_{-1/2}^{1/2} q₀ = 1`. -/
theorem extremalTest_mass : (∫ x in (-(1:ℝ)/2)..(1/2), extremalTest x) = 1 := by
  have : primitive extremalTest (1/2 : ℝ) = 1 := by
    rw [primitive_extremalTest, extremalPrimitive_half]
  exact this

/-- **The extremal value.** `A(q₀) = C_MT`. -/
theorem mtEnergy_extremalTest : mtEnergy extremalTest = mtConst := by
  rw [mtEnergy_eq_variational continuous_extremalTest extremalTest_mass, primitive_extremalTest]
  exact variational_extremal

/-- The cross term in the expansion around the extremal function vanishes: this is the
Euler–Lagrange equation `q₀' = 1 - 2 Φ₀` together with the vanishing of `h` at the endpoints. -/
lemma cross_term_zero {h h' : ℝ → ℝ} (hd : ∀ x, HasDerivAt h (h' x) x) (hc : Continuous h')
    (h0 : h (-(1:ℝ)/2) = 0) (h1 : h (1/2 : ℝ) = 0) :
    (∫ x in (-(1:ℝ)/2)..(1/2),
      (2 * (extremalTest x * h' x) + 2 * h x - 4 * extremalPrimitive x * h x)) = 0 := by
  have hch : Continuous h := continuous_iff_continuousAt.2 fun x => (hd x).continuousAt
  have hIBP : (∫ x in (-(1:ℝ)/2)..(1/2), extremalTest x * h' x)
      = -∫ x in (-(1:ℝ)/2)..(1/2), (1 - 2 * extremalPrimitive x) * h x := by
    have key := intervalIntegral.integral_mul_deriv_eq_deriv_mul
      (a := -(1:ℝ)/2) (b := (1/2:ℝ)) (u := extremalTest)
      (u' := fun x => 1 - 2 * extremalPrimitive x) (v := h) (v' := h')
      (fun y _ => hasDerivAt_extremalTest y) (fun y _ => hd y)
      (by apply Continuous.intervalIntegrable
          exact continuous_const.sub (continuous_const.mul continuous_extremalPrimitive))
      (hc.intervalIntegrable _ _)
    rw [h0, h1] at key
    simpa using key
  have hexp1 : (∫ x in (-(1:ℝ)/2)..(1/2), (1 - 2 * extremalPrimitive x) * h x)
      = (∫ x in (-(1:ℝ)/2)..(1/2), h x)
        - 2 * ∫ x in (-(1:ℝ)/2)..(1/2), extremalPrimitive x * h x := by
    have hrw : (∫ x in (-(1:ℝ)/2)..(1/2), (1 - 2 * extremalPrimitive x) * h x)
        = ∫ x in (-(1:ℝ)/2)..(1/2), (h x - 2 * (extremalPrimitive x * h x)) :=
      intervalIntegral.integral_congr fun x _ => by ring
    rw [hrw, intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_const_mul]
  have hexp2 : (∫ x in (-(1:ℝ)/2)..(1/2),
        (2 * (extremalTest x * h' x) + 2 * h x - 4 * extremalPrimitive x * h x))
      = 2 * (∫ x in (-(1:ℝ)/2)..(1/2), extremalTest x * h' x)
        + 2 * (∫ x in (-(1:ℝ)/2)..(1/2), h x)
        - 4 * ∫ x in (-(1:ℝ)/2)..(1/2), extremalPrimitive x * h x := by
    have hrw : (∫ x in (-(1:ℝ)/2)..(1/2),
          (2 * (extremalTest x * h' x) + 2 * h x - 4 * extremalPrimitive x * h x))
        = ∫ x in (-(1:ℝ)/2)..(1/2),
          (2 * (extremalTest x * h' x) + 2 * h x - 4 * (extremalPrimitive x * h x)) :=
      intervalIntegral.integral_congr fun x _ => by ring
    rw [hrw, intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul,
      intervalIntegral.integral_const_mul]
  rw [hexp2, hIBP, hexp1]
  ring

/-- A sanity check on the functional: for the flat test function `q ≡ 1` (whose self-convolution
is the Fejér kernel `f(α) = (1 - |α|)⁺`) the functional equals `4/3`, in agreement with
`f(0) + 2 ∫₀¹ α f(α) dα = 1 + 1/3`.  Note `4/3 > C_MT`, as `mtEnergy_ge` requires. -/
lemma mtEnergy_one : mtEnergy (fun _ => 1) = 4 / 3 := by
  have hprim : ∀ x : ℝ, primitive (fun _ => (1:ℝ)) x = x + 1/2 := by
    intro x
    simp [primitive]
    ring
  have hmass : primitive (fun _ => (1:ℝ)) (1/2 : ℝ) = 1 := by rw [hprim]; norm_num
  rw [mtEnergy_eq_variational continuous_const hmass]
  have hpt : ∀ x ∈ Set.uIcc (-(1:ℝ)/2) (1/2 : ℝ),
      ((fun _ => (1:ℝ)) x ^ 2 + 2 * primitive (fun _ => (1:ℝ)) x
        - 2 * primitive (fun _ => (1:ℝ)) x ^ 2) = 3/2 - 2 * x ^ 2 := by
    intro x _
    rw [hprim]
    ring
  rw [intervalIntegral.integral_congr hpt,
    intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop),
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const, integral_pow]
  norm_num

/-- **The Montgomery–Taylor constant is optimal.** For every continuous test function `q` on
`[-1/2, 1/2]` normalised by `∫ q = 1`, the pair-correlation functional
`A(q) = ∫ q² + ∫∫ q(x) q(y) |x - y|` is at least `C_MT = 1/2 + (1/√2) cot(1/√2)`. -/
theorem mtEnergy_ge {q : ℝ → ℝ} (hq : Continuous q)
    (hmass : (∫ x in (-(1:ℝ)/2)..(1/2), q x) = 1) :
    mtConst ≤ mtEnergy q := by
  have hmass' : primitive q (1/2 : ℝ) = 1 := hmass
  rw [mtEnergy_eq_variational hq hmass']
  have hcΦ : Continuous (primitive q) := continuous_primitive hq
  set h : ℝ → ℝ := fun x => primitive q x - extremalPrimitive x with hhdef
  set h' : ℝ → ℝ := fun x => q x - extremalTest x with hh'def
  have hd : ∀ x, HasDerivAt h (h' x) x := fun x =>
    (hasDerivAt_primitive hq x).sub (hasDerivAt_extremalPrimitive x)
  have hc : Continuous h' := hq.sub continuous_extremalTest
  have hch : Continuous h := hcΦ.sub continuous_extremalPrimitive
  have h0 : h (-(1:ℝ)/2) = 0 := by
    simp [hhdef, primitive_neg_half, extremalPrimitive_neg_half]
  have h1 : h (1/2 : ℝ) = 0 := by
    simp only [hhdef, hmass', extremalPrimitive_half, sub_self]
  have hpt : ∀ x ∈ Set.uIcc (-(1:ℝ)/2) (1/2 : ℝ),
      q x ^ 2 + 2 * primitive q x - 2 * primitive q x ^ 2
        = (extremalTest x ^ 2 + 2 * extremalPrimitive x - 2 * extremalPrimitive x ^ 2)
          + (2 * (extremalTest x * h' x) + 2 * h x - 4 * extremalPrimitive x * h x)
          + (h' x ^ 2 - 2 * h x ^ 2) := by
    intro x _
    simp only [hhdef, hh'def]
    ring
  rw [intervalIntegral.integral_congr hpt]
  have hsplit : (∫ x in (-(1:ℝ)/2)..(1/2),
        ((extremalTest x ^ 2 + 2 * extremalPrimitive x - 2 * extremalPrimitive x ^ 2)
          + (2 * (extremalTest x * h' x) + 2 * h x - 4 * extremalPrimitive x * h x)
          + (h' x ^ 2 - 2 * h x ^ 2)))
      = (∫ x in (-(1:ℝ)/2)..(1/2),
          (extremalTest x ^ 2 + 2 * extremalPrimitive x - 2 * extremalPrimitive x ^ 2))
        + (∫ x in (-(1:ℝ)/2)..(1/2),
          (2 * (extremalTest x * h' x) + 2 * h x - 4 * extremalPrimitive x * h x))
        + ∫ x in (-(1:ℝ)/2)..(1/2), (h' x ^ 2 - 2 * h x ^ 2) := by
    rw [intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop),
      intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
        (by apply Continuous.intervalIntegrable; fun_prop)]
  rw [hsplit, variational_extremal, cross_term_zero hd hc h0 h1, add_zero]
  have hrest : 0 ≤ ∫ x in (-(1:ℝ)/2)..(1/2), (h' x ^ 2 - 2 * h x ^ 2) := by
    have hexp : (∫ x in (-(1:ℝ)/2)..(1/2), (h' x ^ 2 - 2 * h x ^ 2))
        = (∫ x in (-(1:ℝ)/2)..(1/2), h' x ^ 2) - 2 * ∫ x in (-(1:ℝ)/2)..(1/2), h x ^ 2 := by
      rw [intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
          (by apply Continuous.intervalIntegrable; fun_prop),
        intervalIntegral.integral_const_mul]
    rw [hexp]
    have hP := poincare hd hc h0 h1
    have hSnonneg : 0 ≤ ∫ x in (-(1:ℝ)/2)..(1/2), h' x ^ 2 :=
      intervalIntegral.integral_nonneg (by norm_num) fun x _ => sq_nonneg _
    linarith
  linarith

end Main

end MontgomeryTaylor
