/-
The counting step of the pair-correlation argument, and its sharpness.
-/
import Mathlib

/-!
# The counting step, and why it cannot be improved

The pair-correlation argument ends with a purely arithmetic step.  Writing `m i ≥ 1` for the
multiplicities of the zeros in a finite family, `N = ∑ m i` for the number of zeros with
multiplicity, and `Q = ∑ (m i)²` for the diagonal contribution to the kernel sum, one uses

* `m² ≥ 2m - [m = 1]`, giving `#{simple} ≥ 2N - Q`;
* `m² ≥ 3m - 2`, giving `#{distinct} ≥ (3N - Q)/2`.

Since the analytic input gives `Q ≤ C_MT · N (1 + o(1))`, these produce the proportions
`2 - C_MT` and `3/2 - C_MT/2`.

Both inequalities are attained as soon as every multiplicity is `1` or `2`
(`card_simple_lower_eq`, `card_distinct_lower_eq`), so no better linear consequence of
`N`, `Q` and integrality exists: the numbers `2 - C_MT = 0.672500703679…` and
`3/2 - C_MT/2 = 0.836250351839…` are exactly what this step can deliver.
-/

namespace ZetaCounting

variable {ι : Type*} {s : Finset ι} {m : ι → ℕ}

/-- Pointwise: `m² ≥ 2m - [m = 1]` for `m ≥ 1`. -/
lemma sq_ge_two_mul_sub_simple {k : ℕ} (hk : 1 ≤ k) :
    2 * (k : ℝ) - (if k = 1 then 1 else 0) ≤ (k : ℝ) ^ 2 := by
  rcases eq_or_lt_of_le hk with h | h
  · simp [← h]
    norm_num
  · have hk2 : (2 : ℝ) ≤ (k : ℝ) := by exact_mod_cast h
    have : k ≠ 1 := by omega
    simp only [this, if_false, sub_zero]
    nlinarith

/-- Pointwise: `m² ≥ 3m - 2` for `m ≥ 1`. -/
lemma sq_ge_three_mul_sub_two {k : ℕ} (hk : 1 ≤ k) :
    3 * (k : ℝ) - 2 ≤ (k : ℝ) ^ 2 := by
  rcases eq_or_lt_of_le hk with h | h
  · simp [← h]
    norm_num
  · have hk2 : (2 : ℝ) ≤ (k : ℝ) := by exact_mod_cast h
    nlinarith

/-- **The simple-point bound.** The number of points of multiplicity one is at least
`2N - Q`. -/
theorem card_simple_lower (hm : ∀ i ∈ s, 1 ≤ m i) :
    2 * (∑ i ∈ s, (m i : ℝ)) - (∑ i ∈ s, (m i : ℝ) ^ 2)
      ≤ ((s.filter fun i => m i = 1).card : ℝ) := by
  have hcard : ((s.filter fun i => m i = 1).card : ℝ)
      = ∑ i ∈ s, (if m i = 1 then (1 : ℝ) else 0) := by
    rw [Finset.card_filter]
    push_cast
    rfl
  have hkey : ∀ i ∈ s, 2 * (m i : ℝ) - (m i : ℝ) ^ 2 ≤ (if m i = 1 then (1 : ℝ) else 0) :=
    fun i hi => by linarith [sq_ge_two_mul_sub_simple (hm i hi)]
  calc 2 * (∑ i ∈ s, (m i : ℝ)) - (∑ i ∈ s, (m i : ℝ) ^ 2)
      = ∑ i ∈ s, (2 * (m i : ℝ) - (m i : ℝ) ^ 2) := by
        rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    _ ≤ ∑ i ∈ s, (if m i = 1 then (1 : ℝ) else 0) := Finset.sum_le_sum hkey
    _ = ((s.filter fun i => m i = 1).card : ℝ) := hcard.symm

/-- **The distinct-point bound.** The number of distinct points is at least `(3N - Q)/2`. -/
theorem card_distinct_lower (hm : ∀ i ∈ s, 1 ≤ m i) :
    (3 / 2 : ℝ) * (∑ i ∈ s, (m i : ℝ)) - (1 / 2 : ℝ) * (∑ i ∈ s, (m i : ℝ) ^ 2)
      ≤ (s.card : ℝ) := by
  have hkey : ∀ i ∈ s, (3 / 2 : ℝ) * (m i : ℝ) - (1 / 2 : ℝ) * (m i : ℝ) ^ 2 ≤ 1 :=
    fun i hi => by linarith [sq_ge_three_mul_sub_two (hm i hi)]
  calc (3 / 2 : ℝ) * (∑ i ∈ s, (m i : ℝ)) - (1 / 2 : ℝ) * (∑ i ∈ s, (m i : ℝ) ^ 2)
      = ∑ i ∈ s, ((3 / 2 : ℝ) * (m i : ℝ) - (1 / 2 : ℝ) * (m i : ℝ) ^ 2) := by
        rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_sub_distrib]
    _ ≤ ∑ _i ∈ s, (1 : ℝ) := Finset.sum_le_sum hkey
    _ = (s.card : ℝ) := by simp

/-- **Sharpness of the simple-point bound**: equality whenever every multiplicity is `1` or
`2`. -/
theorem card_simple_lower_eq (hm : ∀ i ∈ s, m i = 1 ∨ m i = 2) :
    2 * (∑ i ∈ s, (m i : ℝ)) - (∑ i ∈ s, (m i : ℝ) ^ 2)
      = ((s.filter fun i => m i = 1).card : ℝ) := by
  have hcard : ((s.filter fun i => m i = 1).card : ℝ)
      = ∑ i ∈ s, (if m i = 1 then (1 : ℝ) else 0) := by
    rw [Finset.card_filter]
    push_cast
    rfl
  have hkey : ∀ i ∈ s, 2 * (m i : ℝ) - (m i : ℝ) ^ 2 = (if m i = 1 then (1 : ℝ) else 0) := by
    intro i hi
    rcases hm i hi with h | h <;> simp [h] <;> norm_num
  rw [hcard, Finset.mul_sum, ← Finset.sum_sub_distrib]
  exact Finset.sum_congr rfl hkey

/-- **Sharpness of the distinct-point bound**: equality whenever every multiplicity is `1` or
`2`. -/
theorem card_distinct_lower_eq (hm : ∀ i ∈ s, m i = 1 ∨ m i = 2) :
    (3 / 2 : ℝ) * (∑ i ∈ s, (m i : ℝ)) - (1 / 2 : ℝ) * (∑ i ∈ s, (m i : ℝ) ^ 2)
      = (s.card : ℝ) := by
  have hkey : ∀ i ∈ s, (3 / 2 : ℝ) * (m i : ℝ) - (1 / 2 : ℝ) * (m i : ℝ) ^ 2 = 1 := by
    intro i hi
    rcases hm i hi with h | h <;> rw [h] <;> norm_num
  rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_sub_distrib, Finset.sum_congr rfl hkey]
  simp

end ZetaCounting
