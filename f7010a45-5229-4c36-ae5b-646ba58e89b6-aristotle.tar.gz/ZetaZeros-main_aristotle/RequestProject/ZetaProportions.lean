/-
Sharpened numerical proportions for the zeros of the Riemann zeta function.
-/
import Mathlib
import RequestProject.MTConstant

/-!
# Sharpened numerical proportions for the zeros of `ζ`

The pair-correlation method gives, for every `ε > 0` and all sufficiently large heights `T`,

* `simpleOnLineCount T / zeroCount T > 3/2 - (1/√2) cot(1/√2) - ε`,
* `distinctZeroCount T / zeroCount T > 5/4 - (1/(2√2)) cot(1/√2) - ε`.

These two `ε`-statements are the hypotheses `hsimple` and `hdistinct` below.  Feeding them the
twelve-digit bounds of `RequestProject.MTConstant` turns the customary numerical readings
`0.6725` and `0.83625` into

* `0.672500703679 < simpleOnLineCount T / zeroCount T`,
* `0.836250351839 < distinctZeroCount T / zeroCount T`,

which by `MontgomeryTaylor.simpleProportion_lt` and `MontgomeryTaylor.distinctProportion_lt` are
within `10⁻¹²` of the exact constants produced by the method.

The counting functions are the standard ones: `zeroCount T` counts the non-trivial zeros with
imaginary part in `(0, T]` with multiplicity, `simpleOnLineCount T` counts those that are simple
and lie on the critical line, and `distinctZeroCount T` counts them without multiplicity.
-/

namespace ZetaProportions

open MontgomeryTaylor

/-- The non-trivial zeros of the Riemann zeta function with imaginary part in `(0, T]`, as a set
(so without multiplicity). -/
def nontrivialZeros (T : ℝ) : Set ℂ :=
  {ρ | riemannZeta ρ = 0 ∧ 0 < ρ.re ∧ ρ.re < 1 ∧ 0 < ρ.im ∧ ρ.im ≤ T}

/-- The multiplicity of `ρ` as a zero of the Riemann zeta function. -/
noncomputable def zeroMultiplicity (ρ : ℂ) : ℕ := analyticOrderNatAt riemannZeta ρ

/-- `N T`: the number of non-trivial zeros with imaginary part in `(0, T]`, with multiplicity. -/
noncomputable def zeroCount (T : ℝ) : ℕ := ∑ᶠ ρ ∈ nontrivialZeros T, zeroMultiplicity ρ

/-- `N₀ˢ T`: the number of non-trivial zeros with imaginary part in `(0, T]` that are simple and
lie on the critical line. -/
noncomputable def simpleOnLineCount (T : ℝ) : ℕ :=
  {ρ ∈ nontrivialZeros T | ρ.re = 1 / 2 ∧ zeroMultiplicity ρ = 1}.ncard

/-- `N_d T`: the number of distinct non-trivial zeros with imaginary part in `(0, T]`. -/
noncomputable def distinctZeroCount (T : ℝ) : ℕ := (nontrivialZeros T).ncard

/-- **Sharpened simple-zero proportion.** Given the `ε`-form lower bound with the constant
`3/2 - (1/√2) cot(1/√2)`, beyond some height more than `67.2500703679 %` of the non-trivial zeros
are simple and lie on the critical line. -/
theorem simple_proportion_sharp
    (hsimple : ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀,
      3 / 2 - (1 / Real.sqrt 2) * Real.cot (1 / Real.sqrt 2) - ε <
        (simpleOnLineCount T : ℝ) / (zeroCount T : ℝ)) :
    ∃ T₀ : ℝ, ∀ T ≥ T₀,
      0.672500703679 < (simpleOnLineCount T : ℝ) / (zeroCount T : ℝ) := by
  obtain ⟨T₀, hT₀⟩ := hsimple (simpleProportion - 0.672500703679)
    (sub_pos.mpr simpleProportion_gt)
  refine ⟨T₀, fun T hT => ?_⟩
  have h := hT₀ T hT
  rw [show (3 / 2 - (1 / Real.sqrt 2) * Real.cot (1 / Real.sqrt 2)) = simpleProportion from rfl]
    at h
  linarith

/-- **Sharpened distinct-zero proportion.** Given the `ε`-form lower bound with the constant
`5/4 - (1/(2√2)) cot(1/√2)`, beyond some height more than `83.6250351839 %` of the non-trivial
zeros are distinct. -/
theorem distinct_proportion_sharp
    (hdistinct : ∀ ε > 0, ∃ T₀ : ℝ, ∀ T ≥ T₀,
      5 / 4 - (1 / (2 * Real.sqrt 2)) * Real.cot (1 / Real.sqrt 2) - ε <
        (distinctZeroCount T : ℝ) / (zeroCount T : ℝ)) :
    ∃ T₀ : ℝ, ∀ T ≥ T₀,
      0.836250351839 < (distinctZeroCount T : ℝ) / (zeroCount T : ℝ) := by
  obtain ⟨T₀, hT₀⟩ := hdistinct (distinctProportion - 0.836250351839)
    (sub_pos.mpr distinctProportion_gt)
  refine ⟨T₀, fun T hT => ?_⟩
  have h := hT₀ T hT
  rw [show (5 / 4 - (1 / (2 * Real.sqrt 2)) * Real.cot (1 / Real.sqrt 2))
      = distinctProportion from rfl] at h
  linarith

end ZetaProportions
