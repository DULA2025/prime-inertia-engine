# Pushing the constants: what improves, and where the method stops

This note records the outcome of trying to raise the two headline constants of the uploaded
development,

* `0.6725` — the proportion of non-trivial zeros of `ζ` shown to be simple and on the critical
  line,
* `0.83625` — the proportion shown to be distinct,

and it points to the Lean files in `RequestProject/` that carry the formal statements.  Everything
claimed below as *proved* is proved in Lean with no `sorry` and no extra axioms.

## 1. What was improved

The exact constants produced by the method are

```
C_MT               = 1/2 + (1/√2) cot(1/√2)   = 1.327499296320588…
simple proportion  = 3/2 - (1/√2) cot(1/√2)   = 0.672500703679411…
distinct proportion= 5/4 - (1/(2√2)) cot(1/√2)= 0.836250351839705…
```

`RequestProject/MTConstant.lean` pins these down to twelve decimal places:

```
1.327499296320 < C_MT               < 1.327499296321   (mtConst_gt, mtConst_lt)
0.672500703679 < simpleProportion   < 0.672500703680   (simpleProportion_gt/_lt)
0.836250351839 < distinctProportion < 0.836250351840   (distinctProportion_gt/_lt)
```

The method is the classical one used in the development: `(1/√2)² = 1/2`, so `cos(1/√2)` and
`√2 sin(1/√2)` are alternating series with rational terms; eight terms of each bracket the values
to sixteen decimals.

`RequestProject/ZetaProportions.lean` feeds these bounds into the `ε`-form conclusions of the
pair-correlation argument and obtains

```
0.672500703679 < N₀ˢ(T) / N(T)      (simple_proportion_sharp)
0.836250351839 < N_d(T) / N(T)      (distinct_proportion_sharp)
```

for all sufficiently large `T`, in place of `0.6725` and `0.83625`.  The `ε`-form statements are
carried as explicit hypotheses; they are exactly the theorems the uploaded development proves from
the Riemann–von Mangoldt formula and the unconditional pair-correlation formula.  The upper bounds
above show these readings are within `10⁻¹²` of the exact constants, so nothing further can be
squeezed out of the numerics.

## 2. Why the constants cannot be raised further within this method

The argument has three steps, and each is now shown to be sharp.

**Step 1 (analytic input).**  For a test function `q` supported in `[-1/2, 1/2]` with `∫ q = 1`
(in the application `q = η²`), the pair-correlation formula evaluates the kernel sum
`B = ∑∑ m_ρ m_ρ' K(ρ - ρ')²` asymptotically as `A(q) · N(T)`, where

```
A(q) = ∫ q² + ∫∫ q(x) q(y) |x - y| dx dy
```

is the main term `f(0) + 2∫₀¹ α f(α) dα` of the formula at the self-convolution `f = q ⋆ q`.

**Step 2 (dropping the off-diagonal terms).**  For real zeros the off-diagonal terms
`K(ρ-ρ')² ≥ 0` are discarded, leaving `Q = ∑ m_ρ² ≤ A(q) · N(T)(1+o(1))`.

**Step 3 (counting).**  `m² ≥ 2m - [m = 1]` and `m² ≥ 3m - 2` turn this into
`N₀ˢ ≥ 2N - Q` and `N_d ≥ (3N - Q)/2`, i.e. the proportions `2 - A(q)` and `3/2 - A(q)/2`.

*Step 3 is sharp.*  `RequestProject/Counting.lean` proves both inequalities and shows both become
equalities as soon as every multiplicity is `1` or `2`.  So with only `N`, `Q` and integrality
available, `2 - Q/N` and `3/2 - Q/(2N)` are the best possible linear conclusions.

*Step 1 is sharp.*  `RequestProject/Extremal.lean` proves

```
mtEnergy_ge : ∫ q = 1 → C_MT ≤ A(q)        (for every continuous q on [-1/2,1/2])
mtEnergy_extremalTest : A(q₀) = C_MT ,     q₀(x) = cos(√2 x)/(√2 sin(1/√2)).
```

So the Montgomery–Taylor function is the exact minimiser and no other test function lowers `A(q)`.
The proof reduces the double integral to a one-dimensional variational problem: with
`Φ(x) = ∫_{-1/2}^x q`, two integrations by parts give

```
A(q) = ∫_{-1/2}^{1/2} (Φ'² + 2Φ - 2Φ²),      Φ(-1/2) = 0,  Φ(1/2) = 1,
```

whose Euler–Lagrange solution is `Φ₀ = 1/2 + sin(√2 x)/(2 sin(1/√2))`.  For a perturbation
`h = Φ - Φ₀` (vanishing at both endpoints) the excess is exactly `∫ h'² - 2∫ h²`, and the Poincaré
inequality `∫ h² ≤ (1/4)∫ h'²` on an interval of length `1` makes it nonnegative — with room to
spare, since `2 < 4`.  (Consistency check, also formalised: the flat test function `q ≡ 1`, whose
self-convolution is the Fejér kernel, gives `A(1) = 4/3 = 1.333… > C_MT`.)

The formal statement quantifies over *continuous* test functions.  This is not a restriction on
the conclusion: `A` is continuous for the `L²` norm on the (bounded) interval and continuous
functions are dense there, so the infimum over square-integrable test functions is the same — the
density argument itself is not formalised here.

It is worth noting *why* enlarging the class of test functions does not help.  Discarding the
off-diagonal terms is legitimate exactly when the kernel is nonnegative, and a nonnegative kernel
whose inverse Fourier transform is supported in `[-1,1]` factors (Fejér–Riesz–Krein) as `|q̂|²`
with `q` supported in `[-1/2,1/2]` — the class treated above.  Equivalently: if one subtracts a
multiple of any admissible test function from `q₀ ⋆ q₀` and the result is still a nonnegative
kernel, `mtEnergy_ge` applies to it and the resulting constant is no better.

## 3. What a genuine improvement would require

The only slack left is Step 2: the discarded off-diagonal mass

```
OFF = (1/N) ∑_{ρ ≠ ρ'} m_ρ m_ρ' K(ρ-ρ')² = C_MT - Q/N ,
```

and any lower bound `OFF ≥ c > 0` improves the simple-zero proportion to `2 - C_MT + c` and the
distinct-zero proportion by `c/2`.  A lower bound on `OFF` amounts to a lower bound on the number
of pairs of zeros at small normalised spacing, of the form "at least `P·N` ordered pairs have
normalised spacing at most `β`".  Such a bound is available from the same pair-correlation input
(a test function that is nonpositive outside `[-β, β]`), but it is only useful once its threshold
exceeds `C_MT ≈ 1.3275`, which forces `β` close to — and past — the first zero of the
Montgomery–Taylor kernel `K`, near `u ≈ 1.05`.  Since the gain is proportional to
`min_{|u| ≤ β} K(u)²`, which is already about `3·10⁻³` at `β = 1` and vanishes near `β ≈ 1.055`,
this route yields at best a negligible improvement.  (These kernel values are numerical estimates
used to guide the search; unlike everything in §1–§2 they are not formally verified.)  Beating `0.6725007…` therefore needs input beyond
the pair-correlation formula on `|α| ≤ 1` — for example information about `F(α)` for `α > 1`
(Montgomery's conjecture gives far larger proportions, but conditionally), higher correlations, or
a mollifier-based argument combined with the present one.

## 4. Files

| File | Contents |
| --- | --- |
| `RequestProject/MTConstant.lean` | `C_MT` and the two proportions; twelve-decimal two-sided bounds. |
| `RequestProject/Extremal.lean` | The pair-correlation functional `A(q)`; the variational reduction; Poincaré inequality; `A(q) ≥ C_MT` with equality at the Montgomery–Taylor function. |
| `RequestProject/Counting.lean` | The counting inequalities and their sharpness. |
| `RequestProject/ZetaProportions.lean` | The sharpened numerical proportions for the zeros of `ζ`. |
