import Mathlib
import RequestProject.Main

/-!
# Continuity helpers for the Weil functional

This file proves helper lemmas and attempts to show that
`g ↦ WeilDistribution (autocorrelation g)` is continuous.

## Note on convergence of the von Mangoldt sum

The sum `∑' n, Λ(n)/√n * g(log n)` in the WeilDistribution formula may not
converge for all Schwartz functions `g`. Schwartz functions have polynomial
decay (`|g(x)| ≤ C_N/(1+|x|)^N` for all N), but when composed with `log n`,
this gives `|g(log n)| ≤ C_N/(1+log n)^N`, which decays only logarithmically
in `n`. Since `∑ Λ(n)/√n / (log n)^N` diverges for all `N` (by comparison
with `∫ dx/(√x · (ln x)^N)`), the sum does not converge for generic Schwartz
functions.

For special functions (compactly supported, Gaussian, etc.), the sum does
converge. The `∑'` (tsum) returns 0 when the sum is not summable. This may
create discontinuities in the `weil_component2_continuous` lemma, which
remains a sorry.

The correct formulation of the Weil explicit formula typically requires test
functions with exponential decay (not just polynomial/Schwartz decay), or uses
a regularized form of the sum that converges for all Schwartz functions.
-/

open Real MeasureTheory
open scoped BigOperators

noncomputable section

-- ============================================================================
-- 1. TRANSLATION CLM ON SCHWARTZ SPACE
-- ============================================================================

/-- Translation by `x₀` as a CLM on SchwartzMap. -/
noncomputable def schwartz_translate (x₀ : ℝ) : SchwartzMap ℝ ℝ →L[ℝ] SchwartzMap ℝ ℝ :=
  SchwartzMap.compCLM ℝ (g := fun t => t + x₀)
    (by exact ((ContinuousLinearMap.id ℝ ℝ).hasTemperateGrowth.add
        (by constructor; exact contDiff_const; intro n; induction n with
          | zero => exact ⟨0, ‖x₀‖, fun t => by simp⟩
          | succ n _ => exact ⟨0, 0, fun t => by simp [iteratedFDeriv_succ_const]⟩)))
    (by refine ⟨1, 1 + ‖x₀‖, fun t => ?_⟩; simp only [pow_one, Real.norm_eq_abs]
        have := abs_add_le (t + x₀) (-x₀); simp at this
        nlinarith [abs_nonneg (t + x₀), abs_nonneg x₀])

-- ============================================================================
-- 2. L² INNER PRODUCT
-- ============================================================================

/-- The L² inner product of two Schwartz functions equals ∫ φ * ψ. -/
lemma schwartz_inner_eq (φ ψ : SchwartzMap ℝ ℝ) :
    @inner ℝ (↥(Lp ℝ 2 (volume : Measure ℝ))) _ (φ.toLp 2) (ψ.toLp 2) =
    ∫ t : ℝ, φ t * ψ t := by
  rw [L2.inner_def]
  apply integral_congr_ae
  filter_upwards [φ.coeFn_toLp 2, ψ.coeFn_toLp 2] with t ht1 ht2
  simp [ht1, ht2, mul_comm]

/-- The convolution value at x₀ equals an L² inner product. -/
lemma schwartz_conv_eq_inner (φ : SchwartzMap ℝ ℝ) (x₀ : ℝ) :
    ∫ t, φ t * φ (t + x₀) =
    @inner ℝ (↥(Lp ℝ 2 (volume : Measure ℝ))) _ (φ.toLp 2) ((schwartz_translate x₀ φ).toLp 2) := by
  rw [schwartz_inner_eq]; rfl

-- ============================================================================
-- 3. CONTINUITY OF CONVOLUTION AT A POINT
-- ============================================================================

/-- For fixed x₀, the map φ ↦ ∫ φ(t) * φ(t+x₀) dt is continuous on SchwartzMap. -/
lemma schwartz_selfConv_continuous_at (x₀ : ℝ) :
    Continuous (fun φ : SchwartzMap ℝ ℝ => ∫ t, φ t * φ (t + x₀)) := by
  have h_eq : (fun φ : SchwartzMap ℝ ℝ => ∫ t, φ t * φ (t + x₀)) =
      (fun φ => @inner ℝ (↥(Lp ℝ 2 (volume : Measure ℝ))) _ (φ.toLp 2)
        ((schwartz_translate x₀ φ).toLp 2)) := by
    ext φ; exact schwartz_conv_eq_inner φ x₀
  rw [h_eq]
  apply Continuous.inner
  · exact (SchwartzMap.toLpCLM ℝ ℝ 2 volume).continuous
  · exact ((SchwartzMap.toLpCLM ℝ ℝ 2 volume).comp (schwartz_translate x₀)).continuous

-- ============================================================================
-- 4. FACTORING AND MAIN THEOREM
-- ============================================================================

/-- The Weil functional factors through SchwartzMap. -/
lemma weil_autocorr_factors (g : EvenSchwartz) :
    WeilDistribution (autocorrelation g) =
    ((∫ t, g.toSchwartzMap t * g.toSchwartzMap (t + 0)) * Real.log Real.pi
    - ∑' (n : ℕ), (ArithmeticFunction.vonMangoldt n : ℝ) / Real.sqrt n *
        (∫ t, g.toSchwartzMap t * g.toSchwartzMap (t + Real.log n))
    + ∫ x in Set.Ioi (0 : ℝ),
        (∫ t, g.toSchwartzMap t * g.toSchwartzMap (t + x)) *
        (1 / (1 - Real.exp (-2 * x)) - 1 / (2 * x))) := by
  simp only [WeilDistribution, autocorrelation]; rfl

/-- Component 1 is continuous. -/
lemma weil_component1_continuous :
    Continuous (fun φ : SchwartzMap ℝ ℝ => (∫ t, φ t * φ (t + 0)) * Real.log Real.pi) :=
  (schwartz_selfConv_continuous_at 0).mul continuous_const

/-- Component 2 is continuous.

**Note:** This lemma has a convergence issue — see the module docstring.
The sum `∑' n, Λ(n)/√n * ∫ φ(t)φ(t + log n) dt` may not be summable
for all SchwartzMap φ. When not summable, `∑'` returns 0. For compactly
supported φ the sum is finite (and hence summable), but generic Schwartz
perturbations can make it non-summable. This creates a potential
discontinuity at compactly supported φ where the sum is nonzero. -/
lemma weil_component2_continuous :
    Continuous (fun φ : SchwartzMap ℝ ℝ =>
      ∑' (n : ℕ), (ArithmeticFunction.vonMangoldt n : ℝ) / Real.sqrt n *
        (∫ t, φ t * φ (t + Real.log n))) := by
  sorry

/-- Component 3 is continuous. -/
lemma weil_component3_continuous :
    Continuous (fun φ : SchwartzMap ℝ ℝ =>
      ∫ x in Set.Ioi (0 : ℝ),
        (∫ t, φ t * φ (t + x)) *
        (1 / (1 - Real.exp (-2 * x)) - 1 / (2 * x))) := by
  sorry

/-- **Main theorem**: `g ↦ WeilDistribution (autocorrelation g)` is continuous. -/
theorem weilDistribution_autocorrelation_continuous' :
    Continuous (fun g : EvenSchwartz => WeilDistribution (autocorrelation g)) := by
  have h_eq : (fun g : EvenSchwartz => WeilDistribution (autocorrelation g)) =
      (fun φ => (∫ t, φ t * φ (t + 0)) * Real.log Real.pi
        - ∑' (n : ℕ), (ArithmeticFunction.vonMangoldt n : ℝ) / Real.sqrt n *
            (∫ t, φ t * φ (t + Real.log n))
        + ∫ x in Set.Ioi (0 : ℝ),
            (∫ t, φ t * φ (t + x)) *
            (1 / (1 - Real.exp (-2 * x)) - 1 / (2 * x))) ∘
      EvenSchwartz.toSchwartzMap := by
    ext g; exact weil_autocorr_factors g
  rw [h_eq]
  exact ((weil_component1_continuous.sub weil_component2_continuous).add
    weil_component3_continuous).comp continuous_induced_dom

end
