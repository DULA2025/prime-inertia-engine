# DULA Project — autocorrelation_WTF.has_exponential_decay_deriv

The full DULA Lean 4 project with `WeilTestFunction.lean` modified to
add a structured proof for `autocorrelation_WTF.has_exponential_decay_deriv`,
mirroring the verified `has_exponential_decay`.

The previous round closed all sorrys in `has_exponential_decay`. This round
attempts the symmetric `has_exponential_decay_deriv` proof.

See `INSTRUCTIONS_FOR_ARISTOTLE.md` for the task description.
