# Instructions for Aristotle — autocorrelation_WTF.has_exponential_decay_deriv

## Context

The DULA project is at 5 sorrys (verified in the previous round). The
non-derivative version `has_exponential_decay` is fully proved. This round
attempts the **derivative version** `has_exponential_decay_deriv`, which has
the same structure with `deriv h.toSchwartzMap` replacing the second factor.

## What's new in WeilTestFunction.lean

`has_exponential_decay_deriv` was rewritten as a full structured proof
mirroring the verified `has_exponential_decay`, with these additions:

1. **Two decay witnesses are extracted** (one from `has_exponential_decay`,
   one from `has_exponential_decay_deriv`). The smaller `b = min b₁ b₂` is
   chosen so both bounds hold with rate `b`.

2. **The derivative is identified** via `schwartz_conv_hasDerivAt` from
   `AutocorrSmooth.lean`:
   ```
   deriv (autocorrelation h.toEvenSchwartz).toSchwartzMap x
     = ∫ t, h.toEvenSchwartz t * deriv h.toEvenSchwartz.toSchwartzMap (t + x)
   ```

3. **The same calc chain** as in `has_exponential_decay`, but with
   `deriv h.toEvenSchwartz.toSchwartzMap` as the second factor and
   `C₁ * C₂` as the constant (instead of `C * C`).

The proof has **4 sub-sorrys**:

1. **`h_deriv_eq`** (line ~579): Convert `HasDerivAt` to a `deriv` equation.
   The verified one-liner is `exact hd.deriv` where
   `hd := schwartz_conv_hasDerivAt h.toSchwartzMap h.toSchwartzMap x`.
   May need `show` or `convert ... using N` to align function shapes via
   the `EvenSchwartz`/`SchwartzMap` coercion chain.

2. **`h_integrable_exp`** (line ~588): Integrability of
   `exp(-α|t|) * exp(-α|t+x|)`. **This is the SAME claim** that was already
   proved as `h_integrable_exp` inside `has_exponential_decay` (lines ~468-481
   of WeilTestFunction.lean). The proof can be copied verbatim, OR factored
   out into a separate `private lemma` and reused.

3. **`h_integrable_abs`** (line ~599): Integrability of
   `|h(t) * deriv h.toSchwartzMap (t+x)|`. Domination by
   `C₁*C₂ * (exp_product)` using `h_pointwise` (already in scope). Same
   shape as in the non-deriv version, with `C₁*C₂` instead of `C^2`.

4. **`h_integrable`** (line ~602): Integrability of
   `h(t) * deriv h.toSchwartzMap (t+x)`. From `h_integrable_abs` via
   `Integrable.mono'` (or `Integrable.abs_iff` if it exists).

## Sorry counts

**Before this round: 5.**
**After this round (target): 8** (4 in WeilTestFunction.lean = the new
sub-sorrys, replacing the 1 monolithic `has_exponential_decay_deriv` sorry).

If Aristotle closes all 4 sub-sorrys: total becomes **4** (net -1).
If Aristotle closes 3 of 4: total stays at 5 or rises slightly.

## Task

**Primary task:** verify the project builds cleanly. The 4 new sub-sorrys
are deliberate placeholders.

**Secondary task (recommended order):**

1. **`h_integrable_exp`**: this is the EASIEST because the proof already
   exists for the same claim in `has_exponential_decay` above. Copy that
   proof body verbatim (replacing variable names if needed: the previous
   version uses `α` from `set α := 1/2 + b`, same as here).

2. **`h_integrable_abs`** and **`h_integrable`**: similarly parallel to
   the non-deriv versions. The proof structures from
   `has_exponential_decay` (lines ~484-491) should transfer with minimal
   modification.

3. **`h_deriv_eq`**: this is the **new** content (no parallel in the
   non-deriv case). Try first:
   ```lean
   exact (schwartz_conv_hasDerivAt h.toEvenSchwartz.toSchwartzMap
            h.toEvenSchwartz.toSchwartzMap x).deriv
   ```
   If function shapes don't unify, try:
   ```lean
   have hd := schwartz_conv_hasDerivAt h.toEvenSchwartz.toSchwartzMap
                h.toEvenSchwartz.toSchwartzMap x
   convert hd.deriv using 2
   · simp only [autocorrelation, EvenSchwartz.coe_apply]; rfl
   ```

## Critical instructions

✗ **DO NOT modify any file other than `WeilTestFunction.lean`.**

✗ **DO NOT modify the verified proofs** of `vonMangoldt_sum_summable`,
  `exp_decay_pointwise_product`, `exp_decay_convolution_integral_bound`,
  `poly_exp_absorption`, or the verified `has_exponential_decay`. Their
  internal contents (including `‹...›` anonymous binders, `exact?`,
  `simp_all`, etc.) compile under the previous build and are correct.

✗ **DO NOT attempt the 2 sorrys in `Main.lean` or the 2 in `ContinuityHelpers.lean`.**

## Possible local issues

The new proof may have small issues:

1. **`set b := min b₁ b₂ with hb_def`** — if Lean's `set` doesn't introduce
   the `with` hypothesis cleanly, replace with explicit `have hb_def : ...`.

2. **`set α := 1/2 + b with hα_def`** then `simp [hα_def]; linarith` for
   `0 < α` — same pattern as the verified `has_exponential_decay`.

3. **`Real.exp_le_exp.mpr`** — the lemma name may be `Real.exp_le_exp_iff`
   in v4.28.0 or similar variant. Adjust locally if needed.

4. **`min_le_left _ _`** — should resolve.

If any of these fail to compile, fix locally without restructuring the
overall calc chain.

## Numerical verification

The math has been verified numerically (Python/scipy) to high precision:
- `exp_decay_convolution_integral_bound`: bound achieved with equality
  to machine precision (10⁻¹⁶) across 66 test cases.
- `poly_exp_absorption`: holds across all test cases with comfortable slack.
- End-to-end autocorrelation closure (non-deriv): 35 test cases all pass.

The deriv version uses the same lemmas, just with `h'` replacing the second
factor of `h`. The math is identical structure with identical witnesses.

## Expected response format

In `ARISTOTLE_SUMMARY.md`:
- Build status (success/failure).
- Final sorry count per file.
- Which (if any) of the 4 new sub-sorrys were closed.
- Any local fixes (line numbers + before/after).
