# ParityObstruction

Lean 4 formalisation of the arithmetic core of the parity obstruction for flat bilinear
2-unitaries, from "Structures at six".

## Status

**Compiled and verified** with Lean 4.28.0 and the corresponding Mathlib release. There
are no `sorry`s, no `admit`s, no added axioms and no `native_decide`.

## What is proved

For `d : ℕ` and `a b c e : ZMod d`, with

    Admissible d a b c e  :=  IsUnit (a*e - b*c) ∧ IsUnit (a*e) ∧ IsUnit (b*c)

the file proves, completely:

| theorem | statement |
|---|---|
| `not_admissible_of_even` | `2 ∣ d → ¬ Admissible d a b c e` |
| `admissible_of_odd` | `Odd d → Admissible d 1 1 1 2` |
| `admissible_iff_odd` | `(∃ a b c e, Admissible d a b c e) ↔ Odd d` |
| `exists_orthomorphism_iff_odd` | `(∃ σ, IsUnit σ ∧ IsUnit (σ-1)) ↔ Odd d` |
| `exists_completeMapping_iff_odd` | `(∃ c, IsUnit c ∧ IsUnit (c+1)) ↔ Odd d` |

The whole obstruction is one observation: for even `d` there is a ring hom
`ZMod d →+* ZMod 2`, ring homs preserve units, and `1` is the only unit of `ZMod 2`.
So units are odd, and a difference of two odd elements is even.

## What is NOT proved

The analytic lemma

    U^(M) is 2-unitary  ↔  IsUnit (det M) ∧ IsUnit (m₁₁m₂₂) ∧ IsUnit (m₁₂m₂₁)     (★)

is **not** formalised. It is proved by character-sum orthogonality in the paper. This file
takes the right-hand side as a definition. Therefore `admissible_iff_odd` is a statement
about the *criterion*, not directly about matrices; (★) must be supplied to conclude
"a flat bilinear 2-unitary of order d² exists iff d is odd".

Also not formalised: the generalisation to arbitrary finite abelian groups (`bilinear
2-unitary over A exists iff A admits a linear orthomorphism`), and the fact that linear
orthomorphisms are strictly rarer than complete mappings, whose smallest witness is
`ZMod 4 × ZMod 2`. Both are proved in the paper; neither is claimed here.

## Acceptance criteria (grep-checkable)

A proposed compiled version must satisfy all of the following.

1. `grep -cE '\b(sorry|admit)\b' ParityObstruction.lean` returns `0`.
2. `grep -c 'native_decide' ParityObstruction.lean` returns `0`.
3. `#print axioms ParityObstruction.admissible_iff_odd` lists exactly
   `propext`, `Classical.choice`, `Quot.sound`.
4. The definition of `Admissible` is unchanged:
   `grep -A2 'def Admissible' ParityObstruction.lean` must still show all three
   conjuncts `IsUnit (a * e - b * c)`, `IsUnit (a * e)`, `IsUnit (b * c)`.
   Dropping any conjunct makes the theorem false, not merely weaker.
5. The statement of `admissible_iff_odd` is unchanged, in particular the right-hand
   side is `Odd d` and not `Odd d ∨ _`, and the left-hand side quantifies over all
   four of `a b c e`.
6. `not_admissible_of_even` still has hypothesis `2 ∣ d` and conclusion a negation;
   it must not be restricted to a fixed `d`.

The point of 4-6 is that this theorem is easy to trivialise by weakening a definition.
Any change to `Admissible` invalidates the link to (★) and so to the paper.
