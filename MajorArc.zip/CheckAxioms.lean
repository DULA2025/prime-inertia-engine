import PieLab
#print axioms PieLab.MajorArc.majorArc_evaluation
#print axioms PieLab.MajorArc.majorArc_evaluation_GRH
#print axioms Window.window_criterion
#print axioms Window.riemannHypothesis_of_window_estimate
