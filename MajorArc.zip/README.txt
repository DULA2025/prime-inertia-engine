On your machine (Windows: inside WSL is easiest), in this folder:

  1.  lake exe cache get          # downloads prebuilt Mathlib for this commit (several GB)
  2.  lake build                  # should compile, with "declaration uses 'sorry'" warnings only
  3.  claude mcp add lean-lsp uvx lean-lsp-mcp
  4.  claude                      # start Claude Code here; it reads CLAUDE.md
  5.  paste:  Prove all the sorries in PieLab/MajorArc.lean and PieLab/WindowCriterion.lean following CLAUDE.md.
              Start with MajorArc. Report which declarations are proved and the output of CheckAxioms.lean.

Send back: the two .lean files, CHANGES.md and the CheckAxioms output.
