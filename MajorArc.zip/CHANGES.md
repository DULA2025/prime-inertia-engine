# CHANGES

Built and checked on 20 Nov 2026 with Lean 4.33.1 and Mathlib `0df444a3`. `lake build` succeeds;
the only warnings are the two remaining `sorry`s in `WindowCriterion.lean`.

## Status

| File | Declaration | Status |
|---|---|---|
| MajorArc | `gauss_expansion` | proved |
| MajorArc | `tau_one` | proved |
| MajorArc | `tau_parseval` | proved |
| MajorArc | `sum_norm_tau_le` | proved |
| MajorArc | `abel_bound` | proved |
| MajorArc | `noncoprime_part_le` | proved, after adding `[NeZero q]` (change 2) |
| MajorArc | `majorArc_evaluation` | proved |
| MajorArc | `majorArc_evaluation_GRH` | proved |
| WindowCriterion | `abs_G_le` | proved (with `C₀ = 4`) |
| WindowCriterion | `mellin_G` | **not proved** (`sorry`) |
| WindowCriterion | `one_sided` | proved |
| WindowCriterion | `gamma_tail_upper` | proved |
| WindowCriterion | `gamma_tail_lower` | proved |
| WindowCriterion | `zero_reflect` | proved |
| WindowCriterion | `window_criterion` | **not proved** (`sorry`) |
| WindowCriterion | `riemannHypothesis_of_window_estimate` | proved **from `window_criterion`** |

`lake env lean CheckAxioms.lean`:

```
'PieLab.MajorArc.majorArc_evaluation' depends on axioms: [propext, Classical.choice, Quot.sound]
'PieLab.MajorArc.majorArc_evaluation_GRH' depends on axioms: [propext, Classical.choice, Quot.sound]
'Window.window_criterion' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
'Window.riemannHypothesis_of_window_estimate' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
```

The `sorryAx` in `riemannHypothesis_of_window_estimate` comes only from `window_criterion`. The rest
of that proof is complete: it chooses ε, applies `window_criterion` with θ = 1/2 + Aε and λ = 3/2,
uses `zero_reflect` for 0 < Re s < 1/2, and uses the functional equation for Re s ≤ 0.

No `admit`, new `axiom`, `native_decide` or `implemented_by` anywhere.

## Changes beyond replacing `sorry`

### 1. `PieLab/MajorArc.lean`, the `open scoped` line (the file did not compile)

- Old: `open scoped ArithmeticFunction.Moebius ArithmeticFunction.vonMangoldt`
- New: `open scoped ArithmeticFunction.Moebius`
- Why: `open ArithmeticFunction` already opens the `Λ` notation. Opening the `vonMangoldt` scope as
  well made `Λ` ambiguous ("Ambiguous term Λ" in `S`, `psiChi` and `noncoprime_part_le`), and
  `lake build` failed. No statement changes meaning.

### 2. `noncoprime_part_le`: false as stated for `q = 0`

- Old: `theorem noncoprime_part_le (q N : ℕ) (hN : 1 ≤ N) (z : ℕ → ℂ) (hz : ∀ n, ‖z n‖ ≤ 1) :`
- New: `theorem noncoprime_part_le (q N : ℕ) [NeZero q] (hN : 1 ≤ N) (z : ℕ → ℂ) (hz : ∀ n, ‖z n‖ ≤ 1) :`
- Why: for `q = 0`, `Nat.Coprime n 0 ↔ n = 1`, so the filter keeps every `n ∈ [2, N]`, while
  `(0).primeFactors = ∅` makes the right side `0`. Counterexample: `q = 0`, `N = 2`, `z = 1`, where
  the left side is `Λ 2 = log 2 > 0`. Both callers already have `[NeZero q]`, so nothing downstream
  changes.

### 3. `lakefile.toml`: the root module was not built, so `CheckAxioms.lean` could not run

- Old: `globs = ["PieLab.+"]`
- New: `globs = ["PieLab", "PieLab.+"]`
- Why: `PieLab.+` matches only submodules, so `PieLab.olean` was never built. `CheckAxioms.lean`
  (`import PieLab`) failed with "object file … PieLab.olean does not exist".

### 4. STATUS comments in both file headers

Updated from "statements only, not compiled" to the current status. They are comments only.

## What is missing

### `mellin_G`
The identity is correct. I checked it by hand: `∫_n^∞ (x/n − 1) x^{−s−1} dx = n^{−s}/(s(s−1))`,
`∫_1^∞ x log x · x^{−s−1} dx = 1/(s−1)²` and `∫_1^∞ x · x^{−s−1} dx = 1/(s−1)`. What a formal proof
still needs:
1. Exchange `∫_1^∞ Σ_{n ≤ x}` with `Σ_n ∫_n^∞` (Tonelli on `Λ(n)(x/n − 1)₊ x^{−Re s−1}`, which is
   nonnegative, then dominated convergence for the complex weight).
2. The three explicit improper integrals above, as `integral_Ioi` facts with complex powers.
3. `Σ Λ(n) n^{−s} = −ζ'/ζ(s)` for `Re s > 1`. Mathlib has this as
   `LSeries_vonMangoldt_eq_deriv_riemannZeta_div`; it needs matching to `LSeries` conventions.
4. Integrability of `G(x) x^{−s−1}` on `(1, ∞)`. It follows from `abs_G_le`, now proved.

### `window_criterion`
This is the main analytic argument of the source paper (steps 2–5 of the header outline). It needs:
the meromorphic continuation of `−ζ'/ζ(s)/(s(s−1))` to `Re s > 0`, with principal parts at the zeros;
derivatives of the Laplace transform `A_k(z)`; the window estimate via the gamma tails (now proved);
and the Cauchy-estimate pole-isolation step. Several of these pieces are not in Mathlib. Nothing here
checks that the theorem is true: it was not machine-checked, and Aristotle cannot take Lean input yet.

## Helper lemmas added (new declarations, no statement changes)

MajorArc: `e_add_int`, `e_natCast_div`, `sum_zmod_eq_sum_range`, `e_nat_div_eq_pow`, `sum_range_e`,
`sum_filter_dvd_range`, `norm_e`, `e_mul_conj`, `sum_isUnit_eq_totient`, `tau_parseval_complex`,
`e_add`, `norm_e_sub_one_le`, `abel_identity`.

WindowCriterion: `gamma_tail_aux`, `exp_mul_pow_eq`.
