# Proving MajorArc.lean and WindowCriterion.lean

Project of Dula. Lean 4.33.1, Mathlib at commit 0df444a3 (the pin of the RH archive; known to build together).

## Task
Replace every `sorry` in `PieLab/MajorArc.lean` and `PieLab/WindowCriterion.lean` with a proof, using the
lean-lsp-mcp tools (goals, diagnostics, multi-attempt) after every step. Work lemma by lemma, in the order the
header comment of each file gives, and build with `lake build` after each lemma.

## Rules
- Do not change any theorem statement silently. If a statement does not compile, or is false as written, fix the
  smallest thing, and record the change and the reason in `CHANGES.md` (old line, new line, why).
- No `sorry`, no `admit`, no new `axiom`, no `native_decide`, no `implemented_by` in the final files.
- Prefer Mathlib lemmas (search with LeanSearch / Loogle / Lean Finder) over reproving them.
- When a lemma is done, run `lake env lean CheckAxioms.lean` once everything compiles: the only axioms allowed are
  `propext`, `Classical.choice`, `Quot.sound`.
- If a lemma resists for a long time, leave its `sorry`, write in `CHANGES.md` what is missing, and move on;
  report at the end which declarations are proved and which are not.

## Notes on the mathematics
- MajorArc: the proof is Gauss expansion + Parseval for Gauss sums (Σ_χ ‖τ χ‖² = φ(q)²) + Cauchy–Schwarz +
  Abel summation; `tau_one` is the Ramanujan sum c_q(1) = μ(q). Character orthogonality is in
  Mathlib.NumberTheory.DirichletCharacter.Orthogonality. `hB0 : 0 ≤ B` matters when q has no non-principal
  characters (q = 1, 2).
- WindowCriterion: Step 5 (pole isolation by Cauchy estimates) is the hardest; do the lemmas first. The Mellin
  identity was checked numerically (mellin_check.py in the outputs): it is right as stated.
