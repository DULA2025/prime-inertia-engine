/-
  MajorArc.lean — the major-arc evaluation of the von Mangoldt exponential sum, conditional on a
  bound for twisted Chebyshev sums (the input GRH supplies).  PIE Lab circle method, 20 Nov 2026 · Dula.

  STATUS (20 Nov 2026): fully proved, no `sorry`; builds with Lean 4.33.1 + Mathlib 0df444a3, and
  `CheckAxioms.lean` reports only propext, Classical.choice, Quot.sound.  See CHANGES.md for the two
  edits (the `open scoped` line, `[NeZero q]` on noncoprime_part_le).  Every inequality below was checked numerically (check_majorarc.py:
  lemmas exactly for q ≤ 60, the theorem for N = 200 000, q ≤ 30; worst case 0.965 of the bound).

  This corrects the target of April 2026:
      ‖vonMangoldtExpSum x (a/q + β) − (ramanujanSum q 1 / φ q) · vonMangoldtExpSum x β‖ ≤ x ^ (1/2 + ε)
  which had a free ε, no constant and no hypothesis, and is not provable as stated (the error
  must depend on q, and the x^{1/2} saving needs GRH).  The theorem below is unconditional, with
  the GRH input isolated as the hypothesis `TwistedPsiBound`.

  Proof outline (each step a lemma below):
   1. gauss_expansion: for gcd(m, q) = 1, e(m/q) = (1/φ(q)) Σ_χ χ⁻¹(m) τ(χ).
   2. split S(a/q + β): terms with gcd(n, q) > 1 (prime powers of primes dividing q, total weight
      ≤ ω(q) log N) and the rest, which by step 1 is (1/φ(q)) Σ_χ χ⁻¹(a) τ(χ) Σ_n Λ(n) χ⁻¹(n) e(nβ).
   3. gaussSum_one: τ(1) = μ(q) (Ramanujan sum c_q(1); PieLab has the full Möbius formula).
   4. gaussSum_parseval: Σ_χ ‖τ(χ)‖² = φ(q)², so Σ_χ ‖τ(χ)‖ ≤ φ(q)^{3/2} by Cauchy–Schwarz.
   5. abel_bound: if every partial sum of c is ≤ B in norm, ‖Σ_{n≤N} c_n e(nβ)‖ ≤ B (1 + 2π|β|N).
   6. combine: the non-principal characters contribute ≤ φ(q)^{-1} · φ(q)^{3/2} · B (1 + 2π|β|N),
      and replacing the coprime sum at β by S(β) costs another ω(q) log N.
-/
import Mathlib

open Complex Finset ArithmeticFunction
open scoped ArithmeticFunction.Moebius

noncomputable section

namespace PieLab.MajorArc

/-- `e t = exp(2πit)`. -/
def e (t : ℝ) : ℂ := Complex.exp (2 * Real.pi * Complex.I * t)

/-- `S N α = Σ_{n=1}^{N} Λ(n) e(nα)`. -/
def S (N : ℕ) (α : ℝ) : ℂ := ∑ n ∈ Icc 1 N, (Λ n : ℂ) * e (n * α)

/-- The twisted Chebyshev sum `ψ(M, χ) = Σ_{n=1}^{M} Λ(n) χ(n)`. -/
def psiChi {q : ℕ} (χ : DirichletCharacter ℂ q) (M : ℕ) : ℂ :=
  ∑ n ∈ Icc 1 M, (Λ n : ℂ) * χ (n : ZMod q)

/-- The Gauss sum `τ(χ) = Σ_{b mod q} χ(b) e(b/q)`, written out to avoid depending on an
additive-character API. -/
def tau {q : ℕ} [NeZero q] (χ : DirichletCharacter ℂ q) : ℂ :=
  ∑ b : ZMod q, χ b * e ((b.val : ℝ) / q)

/-- The input GRH supplies (Davenport, ch. 20: under GRH, `B = C √N log²(qN)`): every
non-principal character mod `q` has twisted Chebyshev sums of size at most `B` up to `N`. -/
def TwistedPsiBound (q N : ℕ) (B : ℝ) : Prop :=
  ∀ χ : DirichletCharacter ℂ q, χ ≠ 1 → ∀ M ≤ N, ‖psiChi χ M‖ ≤ B

/-! ### The lemmas -/

/-- `e` has period 1. -/
theorem e_add_int (t : ℝ) (k : ℤ) : e (t + k) = e t := by
  unfold e
  rw [show (2 * Real.pi * Complex.I * ((t + k : ℝ) : ℂ)) =
      2 * Real.pi * Complex.I * t + k * (2 * Real.pi * Complex.I) by push_cast; ring,
    Complex.exp_add, Complex.exp_int_mul_two_pi_mul_I, mul_one]

/-- Reducing the numerator mod `q` does not change `e (m / q)`. -/
theorem e_natCast_div {q : ℕ} [NeZero q] (m : ℕ) :
    e (((m : ZMod q).val : ℝ) / q) = e ((m : ℝ) / q) := by
  have hq : (q : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne q)
  rw [ZMod.val_natCast]
  have h : ((m : ℕ) : ℝ) = ((m % q : ℕ) : ℝ) + q * ((m / q : ℕ) : ℝ) := by
    exact_mod_cast (Nat.mod_add_div m q).symm
  have : (m : ℝ) / q = ((m % q : ℕ) : ℝ) / q + (((m / q : ℕ) : ℤ) : ℝ) := by
    rw [h, Int.cast_natCast]; field_simp
  rw [this, e_add_int]

/-- Step 1. -/
theorem gauss_expansion {q : ℕ} [NeZero q] (m : ℕ) (hm : Nat.Coprime m q) :
    e ((m : ℝ) / q) = (1 / (Nat.totient q : ℂ)) * ∑ χ : DirichletCharacter ℂ q, χ⁻¹ (m : ZMod q) * tau χ := by
  have hu : IsUnit (m : ZMod q) := (ZMod.isUnit_iff_coprime m q).mpr hm
  have hφ : (Nat.totient q : ℂ) ≠ 0 := by
    exact_mod_cast (Nat.totient_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne q))).ne'
  have hinv : ∀ χ : DirichletCharacter ℂ q, χ⁻¹ (m : ZMod q) = χ (m : ZMod q)⁻¹ := by
    intro χ
    obtain ⟨u, hu'⟩ := hu
    rw [MulChar.inv_apply, ← hu', Ring.inverse_unit, ZMod.inv_coe_unit]
  simp only [tau, hinv, Finset.mul_sum]
  rw [Finset.sum_comm]
  have key : ∀ y : ZMod q, ∑ x : DirichletCharacter ℂ q,
      1 / (q.totient : ℂ) * (x (m : ZMod q)⁻¹ * (x y * e ((y.val : ℝ) / q)))
        = if (m : ZMod q) = y then e ((y.val : ℝ) / q) else 0 := by
    intro y
    rw [← Finset.mul_sum]
    simp_rw [← mul_assoc]
    rw [← Finset.sum_mul, DirichletCharacter.sum_char_inv_mul_char_eq ℂ hu]
    split_ifs <;> simp [hφ]
  rw [Finset.sum_congr rfl (fun y _ => key y), Finset.sum_ite_eq, if_pos (Finset.mem_univ _),
    e_natCast_div]

/-! Helpers for `tau_one`: sums over `ZMod q`, roots of unity, multiples of `d`. -/

theorem sum_zmod_eq_sum_range {q : ℕ} [NeZero q] (g : ZMod q → ℂ) :
    ∑ b : ZMod q, g b = ∑ n ∈ range q, g n := by
  obtain ⟨k, rfl⟩ : ∃ k, q = k + 1 := Nat.exists_eq_succ_of_ne_zero (NeZero.ne q)
  rw [← Fin.sum_univ_eq_sum_range (fun n => g (n : ZMod (k + 1)))]
  exact Fintype.sum_congr _ _ (fun i => congrArg g (ZMod.natCast_zmod_val i).symm)

theorem e_nat_div_eq_pow (j n : ℕ) :
    e ((j : ℝ) / n) = Complex.exp (2 * Real.pi * Complex.I / n) ^ j := by
  unfold e; rw [← Complex.exp_nat_mul]; congr 1; push_cast; ring

theorem sum_range_e (n : ℕ) (hn : 0 < n) :
    ∑ j ∈ range n, e ((j : ℝ) / n) = if n = 1 then 1 else 0 := by
  simp_rw [e_nat_div_eq_pow]
  split_ifs with h
  · subst h; simp
  · exact (Complex.isPrimitiveRoot_exp n hn.ne').geom_sum_eq_zero (by omega)

theorem sum_filter_dvd_range {d k : ℕ} (hd0 : 0 < d) (f : ℕ → ℂ) :
    ∑ n ∈ (range (d * k)).filter (d ∣ ·), f n = ∑ j ∈ range k, f (d * j) := by
  symm
  refine Finset.sum_nbij' (fun j => d * j) (fun n => n / d) ?_ ?_ ?_ ?_ ?_
  · intro j hj
    simp only [Finset.mem_range, Finset.mem_filter] at hj ⊢
    exact ⟨Nat.mul_lt_mul_of_pos_left hj hd0, dvd_mul_right d j⟩
  · intro n hn
    simp only [Finset.mem_range, Finset.mem_filter] at hn ⊢
    exact (Nat.div_lt_iff_lt_mul hd0).mpr (by rw [mul_comm]; exact hn.1)
  · intro j _; simp [Nat.mul_div_cancel_left j hd0]
  · intro n hn
    simp only [Finset.mem_range, Finset.mem_filter] at hn
    exact Nat.mul_div_cancel' hn.2
  · intro j _; rfl

/-- Step 3: the Gauss sum of the principal character is the Ramanujan sum `c_q(1) = μ(q)`. -/
theorem tau_one {q : ℕ} [NeZero q] : tau (1 : DirichletCharacter ℂ q) = (μ q : ℂ) := by
  have hq : 0 < q := Nat.pos_of_ne_zero (NeZero.ne q)
  have h1 : tau (1 : DirichletCharacter ℂ q)
      = ∑ n ∈ range q, (if Nat.Coprime n q then (1 : ℂ) else 0) * e ((n : ℝ) / q) := by
    rw [tau, sum_zmod_eq_sum_range]
    refine Finset.sum_congr rfl (fun n _ => ?_)
    rw [e_natCast_div]
    congr 1
    split_ifs with h
    · exact MulChar.one_apply ((ZMod.isUnit_iff_coprime n q).mpr h)
    · exact MulChar.map_nonunit _ (fun hu => h ((ZMod.isUnit_iff_coprime n q).mp hu))
  have h2 : ∀ n, (if Nat.Coprime n q then (1 : ℂ) else 0)
      = ∑ d ∈ q.divisors.filter (· ∣ n), (μ d : ℂ) := by
    intro n
    have := congrArg (fun f : ArithmeticFunction ℤ => (f (Nat.gcd n q) : ℂ)) moebius_mul_coe_zeta
    simp only [coe_mul_zeta_apply, ArithmeticFunction.one_apply] at this
    have hdiv : (Nat.gcd n q).divisors = q.divisors.filter (· ∣ n) := by
      ext d
      simp only [Nat.mem_divisors, Finset.mem_filter, Nat.dvd_gcd_iff]
      constructor
      · rintro ⟨⟨h1, h2⟩, _⟩; exact ⟨⟨h2, hq.ne'⟩, h1⟩
      · rintro ⟨⟨h2, _⟩, h1⟩; exact ⟨⟨h1, h2⟩, (Nat.gcd_pos_of_pos_right n hq).ne'⟩
    rw [← hdiv]
    push_cast at this
    rw [this]
  rw [h1]
  simp_rw [h2, Finset.sum_mul]
  rw [Finset.sum_comm' (t' := q.divisors) (s' := fun d => (range q).filter (d ∣ ·))]
  swap
  · intro n d
    simp only [Finset.mem_range, Finset.mem_filter, Nat.mem_divisors]
    tauto
  have h3 : ∀ d ∈ q.divisors, ∑ n ∈ (range q).filter (d ∣ ·), (μ d : ℂ) * e ((n : ℝ) / q)
      = (μ d : ℂ) * (if q / d = 1 then 1 else 0) := by
    intro d hd
    have hd0 : 0 < d := Nat.pos_of_mem_divisors hd
    obtain ⟨k, hk⟩ := Nat.dvd_of_mem_divisors hd
    have hk0 : 0 < k := Nat.pos_of_ne_zero (by rintro rfl; simp at hk; omega)
    have hdR : (d : ℝ) ≠ 0 := by positivity
    have hkR : (k : ℝ) ≠ 0 := by positivity
    rw [← Finset.mul_sum, hk, sum_filter_dvd_range hd0, Nat.mul_div_cancel_left k hd0,
      ← sum_range_e k hk0]
    congr 1
    refine Finset.sum_congr rfl (fun j _ => ?_)
    congr 1
    push_cast
    field_simp
  rw [Finset.sum_congr rfl h3, Finset.sum_eq_single q]
  · simp [Nat.div_self hq]
  · intro d hd hdq
    rw [if_neg, mul_zero]
    intro h
    exact hdq (Nat.eq_of_dvd_of_div_eq_one (Nat.dvd_of_mem_divisors hd) h)
  · intro h
    exact absurd (Nat.mem_divisors_self q hq.ne') h

/-! Helpers for Parseval: `|e| = 1`, the number of units, the complex identity. -/

theorem norm_e (t : ℝ) : ‖e t‖ = 1 := by
  unfold e
  rw [show (2 * Real.pi * Complex.I * (t : ℂ)) = ((2 * Real.pi * t : ℝ) : ℂ) * Complex.I by
    push_cast; ring]
  exact Complex.norm_exp_ofReal_mul_I _

theorem e_mul_conj (t : ℝ) : e t * starRingEnd ℂ (e t) = 1 := by
  rw [Complex.mul_conj, Complex.normSq_eq_norm_sq, norm_e]; simp

theorem sum_isUnit_eq_totient {q : ℕ} [NeZero q] :
    ∑ b : ZMod q, (if IsUnit b then (1 : ℂ) else 0) = Nat.totient q := by
  rw [sum_zmod_eq_sum_range, Finset.sum_boole, Nat.totient_eq_card_coprime]
  congr 2
  ext n
  simp [ZMod.isUnit_iff_coprime, Nat.coprime_comm]

theorem tau_parseval_complex {q : ℕ} [NeZero q] :
    ∑ χ : DirichletCharacter ℂ q, tau χ * starRingEnd ℂ (tau χ) = (Nat.totient q : ℂ) ^ 2 := by
  have hconj : ∀ (χ : DirichletCharacter ℂ q) b, starRingEnd ℂ (χ b) = χ⁻¹ b :=
    fun χ b => MulChar.star_apply' χ b
  have horth : ∀ a b : ZMod q, ∑ χ : DirichletCharacter ℂ q, χ a * χ⁻¹ b
      = if IsUnit b ∧ b = a then (Nat.totient q : ℂ) else 0 := by
    intro a b
    by_cases hb : IsUnit b
    · obtain ⟨u, rfl⟩ := hb
      have h : ∀ χ : DirichletCharacter ℂ q, χ a * χ⁻¹ (u : ZMod q) = χ (u : ZMod q)⁻¹ * χ a := by
        intro χ; rw [MulChar.inv_apply, Ring.inverse_unit, ← ZMod.inv_coe_unit, mul_comm]
      simp_rw [h]
      rw [DirichletCharacter.sum_char_inv_mul_char_eq ℂ u.isUnit a]
      simp
    · simp [MulChar.map_nonunit _ hb, hb]
  simp only [tau, map_sum, map_mul, hconj, Finset.sum_mul, Finset.mul_sum]
  rw [Finset.sum_comm]
  refine (Finset.sum_congr rfl (fun x _ => Finset.sum_comm)).trans ?_
  have key : ∀ x : ZMod q, ∑ i : ZMod q, ∑ χ : DirichletCharacter ℂ q,
      χ i * e ((i.val : ℝ) / q) * (χ⁻¹ x * starRingEnd ℂ (e ((x.val : ℝ) / q)))
      = (Nat.totient q : ℂ) * (if IsUnit x then 1 else 0) := by
    intro x
    have hi : ∀ i : ZMod q, ∑ χ : DirichletCharacter ℂ q,
        χ i * e ((i.val : ℝ) / q) * (χ⁻¹ x * starRingEnd ℂ (e ((x.val : ℝ) / q)))
        = (if IsUnit x ∧ x = i then (Nat.totient q : ℂ) else 0)
            * (e ((i.val : ℝ) / q) * starRingEnd ℂ (e ((x.val : ℝ) / q))) := by
      intro i
      rw [← horth, Finset.sum_mul]
      exact Finset.sum_congr rfl (fun χ _ => by ring)
    simp_rw [hi]
    by_cases hx : IsUnit x
    · simp [hx, e_mul_conj]
    · simp [hx]
  rw [Finset.sum_congr rfl (fun x _ => key x), ← Finset.mul_sum, sum_isUnit_eq_totient]
  ring

/-- Step 4: Parseval for Gauss sums. -/
theorem tau_parseval {q : ℕ} [NeZero q] :
    ∑ χ : DirichletCharacter ℂ q, ‖tau χ‖ ^ 2 = (Nat.totient q : ℝ) ^ 2 := by
  have h := congrArg Complex.re (tau_parseval_complex (q := q))
  simp only [Complex.mul_conj, Complex.normSq_eq_norm_sq, Complex.re_sum] at h
  exact_mod_cast h

/-- Step 4, consequence used: `Σ_χ ‖τ(χ)‖ ≤ φ(q)^{3/2}`. -/
theorem sum_norm_tau_le {q : ℕ} [NeZero q] :
    ∑ χ : DirichletCharacter ℂ q, ‖tau χ‖ ≤ (Nat.totient q : ℝ) * Real.sqrt (Nat.totient q) := by
  have hcard : (Finset.univ : Finset (DirichletCharacter ℂ q)).card = Nat.totient q := by
    rw [Finset.card_univ, ← Nat.card_eq_fintype_card,
      DirichletCharacter.card_eq_totient_of_hasEnoughRootsOfUnity]
  have hcs := Finset.sum_mul_sq_le_sq_mul_sq Finset.univ (fun _ => (1 : ℝ))
    (fun χ : DirichletCharacter ℂ q => ‖tau χ‖)
  simp only [one_mul, one_pow, Finset.sum_const, nsmul_eq_mul, mul_one, hcard, tau_parseval] at hcs
  have h0 : 0 ≤ ∑ χ : DirichletCharacter ℂ q, ‖tau χ‖ :=
    Finset.sum_nonneg (fun _ _ => norm_nonneg _)
  have hφ : (0 : ℝ) ≤ q.totient := Nat.cast_nonneg _
  have hsq : ((q.totient : ℝ) * Real.sqrt q.totient) ^ 2 = q.totient * q.totient ^ 2 := by
    rw [mul_pow, Real.sq_sqrt hφ]; ring
  exact (pow_le_pow_iff_left₀ h0 (by positivity) two_ne_zero).mp (by rw [hsq]; exact hcs)

/-! Helpers for Abel summation. -/

theorem e_add (a b : ℝ) : e (a + b) = e a * e b := by
  unfold e; rw [← Complex.exp_add]; congr 1; push_cast; ring

theorem norm_e_sub_one_le (β : ℝ) : ‖e β - 1‖ ≤ 2 * Real.pi * |β| := by
  have h := Real.norm_exp_I_mul_ofReal_sub_one_le (x := 2 * Real.pi * β)
  unfold e
  rw [show (2 * Real.pi * Complex.I * (β : ℂ)) = Complex.I * ((2 * Real.pi * β : ℝ) : ℂ) by
    push_cast; ring]
  refine h.trans (le_of_eq ?_)
  rw [Real.norm_eq_abs, abs_mul, abs_of_pos (by positivity : (0:ℝ) < 2 * Real.pi)]

/-- Summation by parts with partial sums `A M = Σ_{n=1}^{M} c n`. -/
theorem abel_identity (N : ℕ) (c f : ℕ → ℂ) :
    ∑ n ∈ Icc 1 N, c n * f n = (∑ n ∈ Icc 1 N, c n) * f N
      + ∑ m ∈ range N, (∑ n ∈ Icc 1 m, c n) * (f m - f (m + 1)) := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [Finset.sum_Icc_succ_top (by omega), ih, Finset.sum_range_succ, Finset.sum_Icc_succ_top (by omega)]
    ring

/-- Step 5: Abel summation against `e(nβ)`. -/
theorem abel_bound (N : ℕ) (c : ℕ → ℂ) (B β : ℝ)
    (hc : ∀ M ≤ N, ‖∑ n ∈ Icc 1 M, c n‖ ≤ B) :
    ‖∑ n ∈ Icc 1 N, c n * e (n * β)‖ ≤ B * (1 + 2 * Real.pi * |β| * N) := by
  have hB : 0 ≤ B := by simpa using hc 0 (Nat.zero_le _)
  rw [abel_identity N c (fun n => e (n * β))]
  have hstep : ∀ m : ℕ, ‖e (m * β) - e ((m + 1 : ℕ) * β)‖ ≤ 2 * Real.pi * |β| := by
    intro m
    rw [show ((m + 1 : ℕ) : ℝ) * β = m * β + β by push_cast; ring, e_add,
      show e (m * β) - e (m * β) * e β = -(e (m * β) * (e β - 1)) by ring, norm_neg, norm_mul,
      norm_e, one_mul]
    exact norm_e_sub_one_le β
  calc _ ≤ ‖(∑ n ∈ Icc 1 N, c n) * e (N * β)‖
        + ‖∑ m ∈ range N, (∑ n ∈ Icc 1 m, c n) * (e (m * β) - e ((m + 1 : ℕ) * β))‖ :=
        norm_add_le _ _
    _ ≤ B + ∑ m ∈ range N, B * (2 * Real.pi * |β|) := by
        gcongr
        · rw [norm_mul, norm_e, mul_one]; exact hc N le_rfl
        · refine (norm_sum_le _ _).trans (Finset.sum_le_sum (fun m hm => ?_))
          rw [norm_mul]
          exact mul_le_mul (hc m (Finset.mem_range.mp hm).le) (hstep m) (norm_nonneg _) hB
    _ = B * (1 + 2 * Real.pi * |β| * N) := by
        rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]; ring

/-- Step 2, the non-coprime part: prime powers of primes dividing `q`. -/
theorem noncoprime_part_le (q N : ℕ) [NeZero q] (hN : 1 ≤ N) (z : ℕ → ℂ) (hz : ∀ n, ‖z n‖ ≤ 1) :
    ‖∑ n ∈ (Icc 1 N).filter (fun n => ¬ Nat.Coprime n q), (Λ n : ℂ) * z n‖
      ≤ (q.primeFactors.card : ℝ) * Real.log N := by
  set S := (Icc 1 N).filter (fun n => ¬ Nat.Coprime n q) with hS
  set T := S.filter (fun n => IsPrimePow n) with hT
  have h1 : ‖∑ n ∈ S, (Λ n : ℂ) * z n‖ ≤ ∑ n ∈ T, Λ n := by
    refine le_trans (norm_sum_le S _) ?_
    rw [hT, Finset.sum_filter (fun n => IsPrimePow n) (fun n => Λ n)]
    apply Finset.sum_le_sum
    intro n _
    rw [norm_mul, Complex.norm_real, Real.norm_of_nonneg vonMangoldt_nonneg]
    split_ifs with h
    · exact mul_le_of_le_one_right vonMangoldt_nonneg (hz n)
    · simp [vonMangoldt_apply, h]
  have hmem : ∀ n ∈ T, IsPrimePow n ∧ 1 ≤ n ∧ n ≤ N ∧ ¬ Nat.Coprime n q := by
    intro n hn
    simp only [hT, hS, Finset.mem_filter, Finset.mem_Icc] at hn
    exact ⟨hn.2, hn.1.1.1, hn.1.1.2, hn.1.2⟩
  have hexp : ∀ n : ℕ, IsPrimePow n → n.factorization n.minFac ≠ 0 := by
    intro n hpp h0
    have heq := hpp.minFac_pow_factorization_eq
    rw [h0, pow_zero] at heq
    exact hpp.ne_one heq.symm
  have hmaps : ∀ n ∈ T, n.minFac ∈ q.primeFactors := by
    intro n hn
    obtain ⟨hpp, -, -, hcop⟩ := hmem n hn
    have hp : n.minFac.Prime := Nat.minFac_prime hpp.ne_one
    have heq := hpp.minFac_pow_factorization_eq
    rw [Nat.mem_primeFactors]
    refine ⟨hp, ?_, NeZero.ne q⟩
    by_contra hdvd
    apply hcop
    rw [← heq]
    exact Nat.Coprime.pow_left _ ((Nat.Prime.coprime_iff_not_dvd hp).mpr hdvd)
  have hfib : ∀ p ∈ q.primeFactors,
      ∑ n ∈ T.filter (fun n => n.minFac = p), Λ n ≤ Real.log N := by
    intro p hp
    have hpp : p.Prime := Nat.prime_of_mem_primeFactors hp
    have hval : ∀ n ∈ T.filter (fun n => n.minFac = p), Λ n = Real.log p := by
      intro n hn
      rw [Finset.mem_filter] at hn
      rw [vonMangoldt_apply, if_pos (hmem n hn.1).1, hn.2]
    rw [Finset.sum_congr rfl hval, Finset.sum_const, nsmul_eq_mul]
    have hcard : (T.filter (fun n => n.minFac = p)).card ≤ Nat.log p N := by
      have := Finset.card_le_card_of_injOn (fun n : ℕ => n.factorization p)
        (s := T.filter (fun n => n.minFac = p)) (t := Icc 1 (Nat.log p N)) ?_ ?_
      · simpa using this
      · intro n hn
        simp only [Finset.mem_coe, Finset.mem_filter] at hn
        obtain ⟨hpp', -, hle, -⟩ := hmem n hn.1
        have heq := hpp'.minFac_pow_factorization_eq
        have hk := hexp n hpp'
        rw [hn.2] at heq hk
        simp only [Finset.coe_Icc, Set.mem_Icc]
        exact ⟨Nat.one_le_iff_ne_zero.mpr hk, Nat.le_log_of_pow_le hpp.one_lt (by rw [heq]; exact hle)⟩
      · intro a ha b hb hab
        simp only [Finset.mem_coe, Finset.mem_filter] at ha hb
        have ea := (hmem a ha.1).1.minFac_pow_factorization_eq
        have eb := (hmem b hb.1).1.minFac_pow_factorization_eq
        rw [ha.2] at ea
        rw [hb.2] at eb
        simp only at hab
        rw [← ea, ← eb, hab]
    have hlogp : 0 ≤ Real.log p := Real.log_nonneg (by exact_mod_cast hpp.one_lt.le)
    have hp0 : (0 : ℝ) < ((p ^ Nat.log p N : ℕ) : ℝ) := by
      exact_mod_cast pow_pos hpp.pos _
    calc ((T.filter (fun n => n.minFac = p)).card : ℝ) * Real.log p
        ≤ (Nat.log p N : ℝ) * Real.log p := by gcongr
      _ = Real.log ((p ^ Nat.log p N : ℕ) : ℝ) := by rw [Nat.cast_pow, Real.log_pow]
      _ ≤ Real.log N := Real.log_le_log hp0 (by exact_mod_cast Nat.pow_log_le_self p (by omega))
  calc _ ≤ ∑ n ∈ T, Λ n := h1
    _ = ∑ p ∈ q.primeFactors, ∑ n ∈ T.filter (fun n => n.minFac = p), Λ n :=
        (Finset.sum_fiberwise_of_maps_to hmaps _).symm
    _ ≤ ∑ p ∈ q.primeFactors, Real.log N := Finset.sum_le_sum hfib
    _ = _ := by rw [Finset.sum_const, nsmul_eq_mul]

/-! ### The theorem -/

/-- **Major-arc evaluation.**  Unconditional, with the GRH input as the hypothesis `hB`. -/
theorem majorArc_evaluation (q N a : ℕ) [NeZero q] (hN : 2 ≤ N) (ha : Nat.Coprime a q)
    (β B : ℝ) (hB0 : 0 ≤ B) (hB : TwistedPsiBound q N B) :
    ‖S N ((a : ℝ) / q + β) - ((μ q : ℂ) / (Nat.totient q : ℂ)) * S N β‖
      ≤ Real.sqrt (Nat.totient q) * B * (1 + 2 * Real.pi * |β| * N)
        + 2 * (q.primeFactors.card : ℝ) * Real.log N := by
  have hq0 : 0 < q := Nat.pos_of_ne_zero (NeZero.ne q)
  have hφpos : (0 : ℝ) < Nat.totient q := by exact_mod_cast Nat.totient_pos.mpr hq0
  have hφ : (Nat.totient q : ℂ) ≠ 0 := by exact_mod_cast hφpos.ne'
  have haU : IsUnit (a : ZMod q) := (ZMod.isUnit_iff_coprime a q).mpr ha
  set C := (Icc 1 N).filter (fun n => Nat.Coprime n q) with hC
  set D := (Icc 1 N).filter (fun n => ¬ Nat.Coprime n q) with hD
  set W : DirichletCharacter ℂ q → ℂ :=
    fun χ => ∑ n ∈ C, χ⁻¹ (n : ZMod q) * ((Λ n : ℂ) * e (n * β)) with hWdef
  set K : ℝ := 1 + 2 * Real.pi * |β| * N with hK
  have hsplit : ∀ x, S N x = ∑ n ∈ C, (Λ n : ℂ) * e (n * x) + ∑ n ∈ D, (Λ n : ℂ) * e (n * x) :=
    fun x => (Finset.sum_filter_add_sum_filter_not _ _ _).symm
  -- the coprime part, expanded in characters
  have hcop : ∑ n ∈ C, (Λ n : ℂ) * e (n * ((a : ℝ) / q + β))
      = (1 / (Nat.totient q : ℂ)) * ∑ χ : DirichletCharacter ℂ q, tau χ * χ⁻¹ (a : ZMod q) * W χ := by
    have hterm : ∀ n ∈ C, (Λ n : ℂ) * e (n * ((a : ℝ) / q + β))
        = (1 / (Nat.totient q : ℂ)) * ∑ χ : DirichletCharacter ℂ q,
            tau χ * χ⁻¹ (a : ZMod q) * (χ⁻¹ (n : ZMod q) * ((Λ n : ℂ) * e (n * β))) := by
      intro n hn
      have hnq : Nat.Coprime n q := (Finset.mem_filter.mp hn).2
      rw [show (n : ℝ) * ((a : ℝ) / q + β) = ((n * a : ℕ) : ℝ) / q + n * β by push_cast; ring,
        e_add, gauss_expansion (n * a) (Nat.Coprime.mul_left hnq ha)]
      simp only [Finset.mul_sum, Finset.sum_mul]
      refine Finset.sum_congr rfl (fun χ _ => ?_)
      rw [Nat.cast_mul, map_mul]
      ring
    rw [Finset.sum_congr rfl hterm, ← Finset.mul_sum, Finset.sum_comm]
    congr 1
    refine Finset.sum_congr rfl (fun χ _ => ?_)
    rw [hWdef, Finset.mul_sum]
  -- the principal character
  have hW1 : W 1 = ∑ n ∈ C, (Λ n : ℂ) * e (n * β) := by
    rw [hWdef]
    refine Finset.sum_congr rfl (fun n hn => ?_)
    have hnU : IsUnit (n : ZMod q) := (ZMod.isUnit_iff_coprime n q).mpr (Finset.mem_filter.mp hn).2
    rw [inv_one, MulChar.one_apply hnU, one_mul]
  -- the non-principal characters
  have hWχ : ∀ χ : DirichletCharacter ℂ q, χ ≠ 1 → ‖W χ‖ ≤ B * K := by
    intro χ hχ
    have hfull : W χ = ∑ n ∈ Icc 1 N, ((Λ n : ℂ) * χ⁻¹ (n : ZMod q)) * e (n * β) := by
      simp only [hWdef, hC, Finset.sum_filter]
      refine Finset.sum_congr rfl (fun n _ => ?_)
      split_ifs with h
      · ring
      · rw [MulChar.map_nonunit _ (fun hu => h ((ZMod.isUnit_iff_coprime n q).mp hu))]
        ring
    rw [hfull, hK]
    refine abel_bound N (fun n => (Λ n : ℂ) * χ⁻¹ (n : ZMod q)) B β (fun M hM => ?_)
    exact hB χ⁻¹ (inv_ne_one.mpr hχ) M hM
  -- assemble
  have hsum1 : ∑ χ : DirichletCharacter ℂ q, tau χ * χ⁻¹ (a : ZMod q) * W χ
      = tau (1 : DirichletCharacter ℂ q) * W 1 + ∑ χ ∈ (Finset.univ : Finset (DirichletCharacter ℂ q)).erase 1, tau χ * χ⁻¹ (a : ZMod q) * W χ := by
    rw [← Finset.add_sum_erase _ _ (Finset.mem_univ 1), inv_one, MulChar.one_apply haU, mul_one]
  set X := ∑ n ∈ D, (Λ n : ℂ) * e (n * ((a : ℝ) / q + β)) with hX
  set Y := ∑ n ∈ D, (Λ n : ℂ) * e (n * β) with hY
  set Z := ∑ χ ∈ (Finset.univ : Finset (DirichletCharacter ℂ q)).erase 1, tau χ * χ⁻¹ (a : ZMod q) * W χ with hZ
  have hid : S N ((a : ℝ) / q + β) - ((μ q : ℂ) / (Nat.totient q : ℂ)) * S N β
      = X - ((μ q : ℂ) / (Nat.totient q : ℂ)) * Y + (1 / (Nat.totient q : ℂ)) * Z := by
    rw [hsplit, hsplit β, hcop, hsum1, tau_one, hW1, ← hX, ← hY]
    ring
  have hXb : ‖X‖ ≤ (q.primeFactors.card : ℝ) * Real.log N :=
    noncoprime_part_le q N (by omega) _ (fun n => (norm_e _).le)
  have hYb : ‖Y‖ ≤ (q.primeFactors.card : ℝ) * Real.log N :=
    noncoprime_part_le q N (by omega) _ (fun n => (norm_e _).le)
  have hμφ : ‖(μ q : ℂ) / (Nat.totient q : ℂ)‖ ≤ 1 := by
    rw [norm_div, Complex.norm_natCast, div_le_one hφpos]
    have h1 : (1 : ℝ) ≤ Nat.totient q := by exact_mod_cast Nat.totient_pos.mpr hq0
    have h2 : ‖(μ q : ℂ)‖ ≤ 1 := by
      have := abs_moebius_le_one (n := q)
      rw [show ((μ q : ℤ) : ℂ) = (((μ q : ℤ) : ℝ) : ℂ) by push_cast; rfl, Complex.norm_real,
        Real.norm_eq_abs]
      exact_mod_cast this
    linarith
  have hKpos : 0 ≤ K := by rw [hK]; positivity
  have hZb : ‖Z‖ ≤ (Nat.totient q : ℝ) * Real.sqrt (Nat.totient q) * (B * K) := by
    refine (norm_sum_le _ _).trans ?_
    calc ∑ χ ∈ (Finset.univ : Finset (DirichletCharacter ℂ q)).erase 1, ‖tau χ * χ⁻¹ (a : ZMod q) * W χ‖
        ≤ ∑ χ ∈ (Finset.univ : Finset (DirichletCharacter ℂ q)).erase 1, ‖tau χ‖ * (B * K) := by
          refine Finset.sum_le_sum (fun χ hχ => ?_)
          rw [norm_mul, norm_mul]
          have h1 := DirichletCharacter.norm_le_one χ⁻¹ (a : ZMod q)
          have h2 := hWχ χ (Finset.ne_of_mem_erase hχ)
          calc ‖tau χ‖ * ‖χ⁻¹ (a : ZMod q)‖ * ‖W χ‖ ≤ ‖tau χ‖ * 1 * (B * K) := by gcongr
            _ = ‖tau χ‖ * (B * K) := by ring
      _ ≤ ∑ χ : DirichletCharacter ℂ q, ‖tau χ‖ * (B * K) :=
          Finset.sum_le_sum_of_subset_of_nonneg (Finset.erase_subset _ _)
            (fun χ _ _ => mul_nonneg (norm_nonneg _) (mul_nonneg hB0 hKpos))
      _ = (∑ χ : DirichletCharacter ℂ q, ‖tau χ‖) * (B * K) := by rw [Finset.sum_mul]
      _ ≤ _ := by gcongr; exact sum_norm_tau_le
  rw [hid]
  calc ‖X - ((μ q : ℂ) / (Nat.totient q : ℂ)) * Y + (1 / (Nat.totient q : ℂ)) * Z‖
      ≤ ‖X‖ + ‖(μ q : ℂ) / (Nat.totient q : ℂ)‖ * ‖Y‖ + (1 / (Nat.totient q : ℝ)) * ‖Z‖ := by
        refine (norm_add_le _ _).trans ?_
        gcongr
        · refine (norm_sub_le _ _).trans ?_
          rw [norm_mul]
        · rw [norm_mul, norm_div, norm_one, Complex.norm_natCast]
    _ ≤ (q.primeFactors.card : ℝ) * Real.log N + 1 * ((q.primeFactors.card : ℝ) * Real.log N)
        + (1 / (Nat.totient q : ℝ)) * ((Nat.totient q : ℝ) * Real.sqrt (Nat.totient q) * (B * K)) := by
        gcongr
    _ = Real.sqrt (Nat.totient q) * B * K + 2 * (q.primeFactors.card : ℝ) * Real.log N := by
        field_simp
        ring

/-- **The GRH form.**  If every non-principal twisted Chebyshev sum satisfies the GRH bound
`‖ψ(M, χ)‖ ≤ C √M log²(qM)`, then on the major arc `|β| ≤ 1/(qN)` the error is
`≪ √(φ(q) N) log²(qN)`. -/
theorem majorArc_evaluation_GRH (C : ℝ) (hC : 0 ≤ C)
    (hGRH : ∀ (q : ℕ) [NeZero q] (χ : DirichletCharacter ℂ q), χ ≠ 1 → ∀ M : ℕ,
      ‖psiChi χ M‖ ≤ C * Real.sqrt M * Real.log (q * M) ^ 2)
    (q N a : ℕ) [NeZero q] (hN : 2 ≤ N) (ha : Nat.Coprime a q) (β : ℝ) (hβ : |β| ≤ 1 / (q * N)) :
    ‖S N ((a : ℝ) / q + β) - ((μ q : ℂ) / (Nat.totient q : ℂ)) * S N β‖
      ≤ Real.sqrt (Nat.totient q) * (C * Real.sqrt N * Real.log (q * N) ^ 2) * (1 + 2 * Real.pi)
        + 2 * (q.primeFactors.card : ℝ) * Real.log N := by
  have hq0 : 0 < q := Nat.pos_of_ne_zero (NeZero.ne q)
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq0
  have hN1 : (1 : ℝ) ≤ N := by exact_mod_cast (by omega : 1 ≤ N)
  set B := C * Real.sqrt N * Real.log (q * N) ^ 2 with hBdef
  have hB0 : 0 ≤ B := by positivity
  have hlogN : 0 ≤ Real.log (q * N) := Real.log_nonneg (by nlinarith)
  have hB : TwistedPsiBound q N B := by
    intro χ hχ M hM
    refine (hGRH q χ hχ M).trans ?_
    have hMN : (M : ℝ) ≤ N := by exact_mod_cast hM
    have hlog : 0 ≤ Real.log (q * M) ∧ Real.log (q * M) ≤ Real.log (q * N) := by
      rcases Nat.eq_zero_or_pos M with h | h
      · simp [h, hlogN]
      · have hM1 : (1 : ℝ) ≤ M := by exact_mod_cast h
        exact ⟨Real.log_nonneg (by nlinarith),
          Real.log_le_log (by positivity) (by gcongr)⟩
    exact mul_le_mul (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hMN) hC)
      (pow_le_pow_left₀ hlog.1 hlog.2 2) (sq_nonneg _) (by positivity)
  have hβN : 2 * Real.pi * |β| * N ≤ 2 * Real.pi := by
    have : |β| * N ≤ 1 := by
      calc |β| * N ≤ 1 / (q * N) * N := by gcongr
        _ = 1 / q := by field_simp
        _ ≤ 1 := by rw [div_le_one (by positivity)]; exact hq1
    nlinarith [Real.pi_pos]
  refine (majorArc_evaluation q N a hN ha β B hB0 hB).trans ?_
  gcongr

end PieLab.MajorArc
