/-
  WindowCriterion.lean — a one-sided bound for a smoothed prime sum on sparse windows excludes zeros of ζ.
  20 November 2026 · Dula.

  Source: S. Allahyar, "From theta lifts to zeta zeros" (revision 2, 20 Nov 2026), Sections 2–4, the analytic
  half of L. Alpöge's announced argument.  The proof below was read line by line and is self-contained: it uses
  only the Mellin transform, a gamma-kernel tail bound, Cauchy estimates and the functional equation.
  Nothing here assumes RH or uses the arithmetic half of that argument.

  STATUS (20 Nov 2026): builds with Lean 4.33.1 + Mathlib 0df444a3.  Proved: abs_G_le, one_sided,
  gamma_tail_upper, gamma_tail_lower, zero_reflect, and riemannHypothesis_of_window_estimate *from*
  window_criterion.  Still `sorry`: mellin_G and window_criterion (see CHANGES.md).

  Proof outline (lemma names below):
   1. mellin_G: for Re s > 1, ∫_1^∞ G(x) x^{-s-1} dx = −ζ'/ζ(s)/(s(s−1)) − 1/(s−1)² + (1+γ)/(s−1).  The right side
      is meromorphic in Re s > 0, holomorphic at s = 1 (the principal parts cancel), with a simple pole of
      residue h/(ρ(1−ρ)) at a zero ρ of order h in the strip; at a real zero the residue is > 0.
   2. With u = log x and g(u) = G(eᵘ): A_k(z) = (−1)^k Φ^{(k)}(z)/k! = ∫ K_k(u) g(u) e^{−itu} du,
      K_k(u) = u^k e^{−σu}/k!, for Re z = σ > 2.
   3. one_sided: since |g| + g = 2 g⁺,  |A_k(σ+it)| + A_k(σ) ≤ 2 ∫ K_k g⁺.
   4. gamma_tail: the normalised kernel a^{k+1} u^k e^{−au}/k! puts mass ≤ 2 e^{−c(k+1)} outside [U, λU] when
      k + 1 ≈ a(1+λ)U/2; so the bound on the window gives |A_k(σ+it)| + A_k(σ) ≤ B E^{−k} with E = σ − θ.
   5. a pole within distance d < E of some σ + it forces |A_k| ≥ |b| d^{−k−1} − O(r^{−k}) (Cauchy), a
      contradiction; if the nearest pole is real, its positive residue gives the same at t = 0.
   6. reflection: the functional equation moves zeros with Re < 1/2 to Re > 1/2.
-/
import Mathlib

open Complex Real MeasureTheory Set Filter
open scoped ArithmeticFunction.vonMangoldt

noncomputable section

namespace Window

/-- `S(x) = Σ_{n ≤ x} Λ(n) (x/n − 1)`. -/
def S (x : ℝ) : ℝ := ∑ n ∈ Finset.Icc 1 ⌊x⌋₊, Λ n * (x / n - 1)

/-- `G(x) = S(x) − x log x + (1 + γ) x`. -/
def G (x : ℝ) : ℝ := S x - x * Real.log x + (1 + Real.eulerMascheroniConstant) * x

/-! ### The lemmas -/

/-- Size: `|G(x)| ≤ C₀ x (1 + log² x)` for `x ≥ 1`. -/
theorem abs_G_le : ∃ C₀ : ℝ, ∀ x ≥ (1 : ℝ), |G x| ≤ C₀ * x * (1 + Real.log x ^ 2) := by
  refine ⟨4, fun x hx => ?_⟩
  have hx0 : 0 < x := by linarith
  have hL : 0 ≤ Real.log x := Real.log_nonneg hx
  have hm1 : 1 ≤ ⌊x⌋₊ := (Nat.one_le_floor_iff x).mpr hx
  have hmx : (⌊x⌋₊ : ℝ) ≤ x := Nat.floor_le hx0.le
  have hH : ∑ n ∈ Finset.Icc 1 ⌊x⌋₊, (1 / (n : ℝ)) ≤ 1 + Real.log x := by
    have h := harmonic_le_one_add_log ⌊x⌋₊
    have hcast : ∑ n ∈ Finset.Icc 1 ⌊x⌋₊, (1 / (n : ℝ)) = (harmonic ⌊x⌋₊ : ℝ) := by
      rw [harmonic_eq_sum_Icc]; push_cast; simp [one_div]
    have hlog : Real.log (⌊x⌋₊ : ℝ) ≤ Real.log x :=
      Real.log_le_log (by exact_mod_cast hm1) hmx
    linarith
  have hterm : ∀ n ∈ Finset.Icc 1 ⌊x⌋₊, (1 : ℝ) ≤ n ∧ (n : ℝ) ≤ x := by
    intro n hn
    have := Finset.mem_Icc.mp hn
    exact ⟨by exact_mod_cast this.1, le_trans (by exact_mod_cast this.2) hmx⟩
  have hS0 : 0 ≤ S x := by
    refine Finset.sum_nonneg (fun n hn => mul_nonneg ArithmeticFunction.vonMangoldt_nonneg ?_)
    obtain ⟨hn1, hnx⟩ := hterm n hn
    rw [sub_nonneg, le_div_iff₀ (by linarith)]; linarith
  have hS : S x ≤ x * Real.log x * (1 + Real.log x) := by
    calc S x ≤ ∑ n ∈ Finset.Icc 1 ⌊x⌋₊, x * Real.log x * (1 / (n : ℝ)) := by
          refine Finset.sum_le_sum (fun n hn => ?_)
          obtain ⟨hn1, hnx⟩ := hterm n hn
          have hΛ : Λ n ≤ Real.log x :=
            ArithmeticFunction.vonMangoldt_le_log.trans (Real.log_le_log (by linarith) hnx)
          have h1 : x / n - 1 ≤ x * (1 / n) := by rw [mul_one_div]; linarith
          have h2 : 0 ≤ x / n - 1 := by rw [sub_nonneg, le_div_iff₀ (by linarith)]; linarith
          calc Λ n * (x / n - 1) ≤ Real.log x * (x * (1 / n)) := mul_le_mul hΛ h1 h2 hL
            _ = _ := by ring
      _ = x * Real.log x * ∑ n ∈ Finset.Icc 1 ⌊x⌋₊, (1 / (n : ℝ)) := by rw [Finset.mul_sum]
      _ ≤ x * Real.log x * (1 + Real.log x) := by gcongr
  have hγ : Real.eulerMascheroniConstant ≤ 1 :=
    Real.eulerMascheroniConstant_lt_two_thirds.le.trans (by norm_num)
  have hγ0 : 0 ≤ Real.eulerMascheroniConstant :=
    (Real.one_half_lt_eulerMascheroniConstant.trans' (by norm_num)).le
  have hxL : 0 ≤ x * Real.log x := mul_nonneg hx0.le hL
  have hsq : 0 ≤ x * (Real.log x - 1) ^ 2 := mul_nonneg hx0.le (sq_nonneg _)
  unfold G
  rw [abs_le]
  constructor
  · nlinarith [mul_nonneg hx0.le hγ0]
  · nlinarith [mul_le_mul_of_nonneg_left hγ hx0.le]

/-- Step 1: the Mellin transform of `G`. -/
theorem mellin_G (s : ℂ) (hs : 1 < s.re) :
    ∫ x in Ioi (1 : ℝ), (G x : ℂ) * (x : ℂ) ^ (-s - 1)
      = -(deriv riemannZeta s / riemannZeta s) / (s * (s - 1)) - 1 / (s - 1) ^ 2
          + (1 + Real.eulerMascheroniConstant) / (s - 1) := by
  sorry

/-- Step 3: the one-sided comparison (`K ≥ 0`, `g` real). -/
theorem one_sided (K g : ℝ → ℝ) (hK : ∀ u, 0 ≤ K u) (t : ℝ)
    (hint : Integrable (fun u => K u * g u) (volume.restrict (Ioi 0))) :
    ‖∫ u in Ioi (0 : ℝ), (K u * g u : ℂ) * Complex.exp (-(t * u) * Complex.I)‖
        + ∫ u in Ioi (0 : ℝ), K u * g u
      ≤ 2 * ∫ u in Ioi (0 : ℝ), K u * max (g u) 0 := by
  have h1 : ‖∫ u in Ioi (0 : ℝ), (K u * g u : ℂ) * Complex.exp (-(t * u) * Complex.I)‖
      ≤ ∫ u in Ioi (0 : ℝ), |K u * g u| := by
    refine (norm_integral_le_integral_norm _).trans (le_of_eq ?_)
    refine MeasureTheory.integral_congr_ae (Filter.Eventually.of_forall (fun u => ?_))
    simp only
    rw [norm_mul, show -((t : ℂ) * u) * Complex.I = ((-(t * u) : ℝ) : ℂ) * Complex.I by push_cast; ring,
      Complex.norm_exp_ofReal_mul_I, mul_one, ← Complex.ofReal_mul, Complex.norm_real,
      Real.norm_eq_abs]
  have h2 : (∫ u in Ioi (0 : ℝ), |K u * g u|) + ∫ u in Ioi (0 : ℝ), K u * g u
      = 2 * ∫ u in Ioi (0 : ℝ), K u * max (g u) 0 := by
    rw [← integral_add hint.abs hint, ← integral_const_mul]
    refine MeasureTheory.integral_congr_ae (Filter.Eventually.of_forall (fun u => ?_))
    simp only
    rw [abs_mul, abs_of_nonneg (hK u)]
    rcases le_total 0 (g u) with h | h
    · rw [abs_of_nonneg h, max_eq_left h]; ring
    · rw [abs_of_nonpos h, max_eq_right h]; ring
  linarith

/-- Chernoff-type comparison used by both gamma tails: if `exp(-v) ≤ exp(-b v) · c` on `A ⊆ (0, ∞)`,
the gamma(n, 1) density has mass `≤ c · (1/b)^n` on `A`. -/
theorem gamma_tail_aux (n : ℕ) (hn : 1 ≤ n) (b c : ℝ) (hb : 0 < b) (hc : 0 ≤ c) (A : Set ℝ)
    (hA : MeasurableSet A) (hA0 : A ⊆ Ioi 0)
    (h : ∀ v ∈ A, Real.exp (-v) ≤ Real.exp (-(b * v)) * c) :
    ∫ v in A, v ^ (n - 1) * Real.exp (-v) / (n - 1).factorial ≤ c * (1 / b) ^ n := by
  obtain ⟨k, rfl⟩ : ∃ k, n = k + 1 := ⟨n - 1, by omega⟩
  simp only [Nat.add_sub_cancel]
  have hfac : (0 : ℝ) < k.factorial := by exact_mod_cast Nat.factorial_pos k
  set g : ℝ → ℝ := fun v => v ^ (k : ℝ) * Real.exp (-(b * v)) * c / k.factorial with hg
  have hgint : IntegrableOn g (Ioi 0) := by
    have := integrableOn_rpow_mul_exp_neg_mul_rpow (p := 1) (s := (k : ℝ)) (b := b)
      (by linarith [(Nat.cast_nonneg k : (0 : ℝ) ≤ k)]) one_pos hb
    simp only [Real.rpow_one, neg_mul] at this
    exact (this.mul_const c).div_const _
  have hgval : ∫ v in Ioi (0 : ℝ), g v = c * (1 / b) ^ (k + 1) := by
    simp only [hg]
    rw [integral_div, integral_mul_const]
    have h1 := integral_rpow_mul_exp_neg_mul_Ioi (a := (k : ℝ) + 1) (r := b) (by positivity) hb
    simp only [add_sub_cancel_right] at h1
    rw [h1, Real.Gamma_nat_eq_factorial, ← Nat.cast_succ, Real.rpow_natCast]
    field_simp
  calc ∫ v in A, v ^ k * Real.exp (-v) / k.factorial ≤ ∫ v in A, g v := by
        apply integral_mono_of_nonneg
        · filter_upwards [ae_restrict_mem hA] with v hv
          have : 0 < v := hA0 hv
          positivity
        · exact hgint.mono_set hA0
        · filter_upwards [ae_restrict_mem hA] with v hv
          have hv0 : 0 < v := hA0 hv
          simp only [hg, Real.rpow_natCast]
          refine div_le_div_of_nonneg_right ?_ hfac.le
          calc v ^ k * Real.exp (-v) ≤ v ^ k * (Real.exp (-(b * v)) * c) := by
                gcongr; exact h v hv
            _ = v ^ k * Real.exp (-(b * v)) * c := by ring
    _ ≤ ∫ v in Ioi (0 : ℝ), g v := by
        refine setIntegral_mono_set hgint ?_ (Filter.Eventually.of_forall hA0)
        filter_upwards [ae_restrict_mem measurableSet_Ioi] with v hv
        have : 0 < v := hv
        simp only [hg]
        positivity
    _ = c * (1 / b) ^ (k + 1) := hgval

theorem exp_mul_pow_eq (n : ℕ) (r : ℝ) (hr : 0 < r) (u : ℝ) :
    Real.exp u * r ^ n = Real.exp (u + n * Real.log r) := by
  rw [Real.exp_add, ← Real.log_pow, Real.exp_log (pow_pos hr n)]

/-- Step 4: tails of the gamma kernel.  For `0 < r < 1` and the density of shape `n` and rate 1,
the mass below `n r` is at most `exp(−n (r − 1 − log r))`, and likewise above `n r` for `r > 1`. -/
theorem gamma_tail_upper (n : ℕ) (hn : 1 ≤ n) (r : ℝ) (hr : 1 < r) :
    ∫ v in Ioi ((n : ℝ) * r), v ^ (n - 1) * Real.exp (-v) / (n - 1).factorial
      ≤ Real.exp (-(n : ℝ) * (r - 1 - Real.log r)) := by
  have hr0 : 0 < r := by linarith
  have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  have key := gamma_tail_aux n hn (1 / r) (Real.exp (-((1 - 1 / r) * (n * r)))) (by positivity)
    (Real.exp_pos _).le (Ioi ((n : ℝ) * r)) measurableSet_Ioi
    (Ioi_subset_Ioi (by positivity)) (fun v hv => by
      rw [← Real.exp_add]
      apply Real.exp_le_exp.mpr
      have hv' : (n : ℝ) * r < v := hv
      have hb : 0 ≤ 1 - 1 / r := by rw [sub_nonneg, div_le_one hr0]; linarith
      nlinarith)
  refine key.trans (le_of_eq ?_)
  rw [one_div_one_div, exp_mul_pow_eq n r hr0]
  congr 1
  field_simp
  ring

theorem gamma_tail_lower (n : ℕ) (hn : 1 ≤ n) (r : ℝ) (hr0 : 0 < r) (hr : r < 1) :
    ∫ v in Ioc (0 : ℝ) ((n : ℝ) * r), v ^ (n - 1) * Real.exp (-v) / (n - 1).factorial
      ≤ Real.exp (-(n : ℝ) * (r - 1 - Real.log r)) := by
  have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  have key := gamma_tail_aux n hn (1 / r) (Real.exp ((1 / r - 1) * (n * r))) (by positivity)
    (Real.exp_pos _).le (Ioc 0 ((n : ℝ) * r)) measurableSet_Ioc
    Ioc_subset_Ioi_self (fun v hv => by
      rw [← Real.exp_add]
      apply Real.exp_le_exp.mpr
      have hv' : v ≤ (n : ℝ) * r := hv.2
      have hb : 0 ≤ 1 / r - 1 := by rw [sub_nonneg, le_div_iff₀ hr0]; linarith
      nlinarith)
  refine key.trans (le_of_eq ?_)
  rw [one_div_one_div, exp_mul_pow_eq n r hr0]
  congr 1
  field_simp
  ring

/-- Step 6: reflection of zeros in the strip. -/
theorem zero_reflect (s : ℂ) (h0 : 0 < s.re) (h1 : s.re < 1) (hz : riemannZeta s = 0) :
    riemannZeta (1 - s) = 0 := by
  have hs : ∀ n : ℕ, s ≠ -n := by
    intro n h
    have := congrArg Complex.re h
    simp at this
    linarith [(Nat.cast_nonneg n : (0 : ℝ) ≤ n)]
  have hs1 : s ≠ 1 := by
    intro h
    rw [h, Complex.one_re] at h1
    exact lt_irrefl _ h1
  rw [riemannZeta_one_sub hs hs1, hz, mul_zero]

/-! ### The theorems -/

/-- **Window criterion** (Allahyar, Theorem 3.1, for ζ).  A one-sided bound on arbitrarily distant windows
`[Y, Y^λ]` excludes zeros to the right of `θ`. -/
theorem window_criterion (θ lam C : ℝ) (hθ0 : 0 < θ) (hθ1 : θ < 1) (hlam : 1 < lam) (hC : 0 < C)
    (h : ∀ Y₀ : ℝ, ∃ Y ≥ Y₀, ∀ x ∈ Icc Y (Y ^ lam), G x ≤ C * x ^ θ) :
    ∀ s : ℂ, θ < s.re → riemannZeta s ≠ 0 := by
  sorry

/-- **The reduction of RH** (Allahyar, Theorem 1.2).  The arithmetic window estimate implies Mathlib's
`RiemannHypothesis`. -/
theorem riemannHypothesis_of_window_estimate
    (h : ∃ A ≥ (0 : ℝ), ∃ ε₀ > (0 : ℝ), ∀ ε : ℝ, 0 < ε → ε < ε₀ → ∀ Y₀ ≥ (2 : ℝ), ∃ Y ≥ Y₀,
      ∀ x ∈ Icc Y (Y ^ ((3 : ℝ) / 2)), G x ≤ x ^ ((1 : ℝ) / 2 + A * ε)) :
    RiemannHypothesis := by
  obtain ⟨A, hA, ε₀, hε₀, hwin⟩ := h
  -- no zeros to the right of `1/2`
  have hright : ∀ s : ℂ, 1 / 2 < s.re → riemannZeta s ≠ 0 := by
    intro s hs
    have hA1 : 0 < A + 1 := by linarith
    set m := min (ε₀ / 2) (min (s.re - 1 / 2) (1 / 4)) with hm
    have hm0 : 0 < m := lt_min (by linarith) (lt_min (by linarith) (by norm_num))
    have hmε : m ≤ ε₀ / 2 := min_le_left _ _
    have hmδ : m ≤ s.re - 1 / 2 := (min_le_right _ _).trans (min_le_left _ _)
    have hm4 : m ≤ 1 / 4 := (min_le_right _ _).trans (min_le_right _ _)
    set ε := m / (A + 1) with hε
    have hε0 : 0 < ε := div_pos hm0 hA1
    have hεm : ε ≤ m := div_le_self hm0.le (by linarith)
    have hAε : A * ε < m := by
      rw [hε, mul_div_assoc', div_lt_iff₀ hA1]; nlinarith
    have hAε0 : 0 ≤ A * ε := mul_nonneg hA hε0.le
    refine window_criterion (1 / 2 + A * ε) (3 / 2) 1 (by linarith) (by linarith) (by norm_num)
      one_pos ?_ s (by linarith)
    intro Y₀
    obtain ⟨Y, hY, hYwin⟩ := hwin ε hε0 (by linarith) (max Y₀ 2) (le_max_right _ _)
    exact ⟨Y, le_trans (le_max_left _ _) hY, fun x hx => by rw [one_mul]; exact hYwin x hx⟩
  intro s hz htriv hs1
  by_contra hne
  rcases lt_or_gt_of_ne hne with hlt | hgt
  · by_cases hpos : 0 < s.re
    · have h1s := zero_reflect s hpos (by linarith) hz
      exact hright (1 - s) (by simp; linarith) h1s
    · rw [not_lt] at hpos
      have hs0 : s ≠ 0 := by
        rintro rfl
        rw [riemannZeta_zero] at hz
        norm_num at hz
      set w := 1 - s with hw
      have hwre : 1 ≤ w.re := by simp [hw]; linarith
      have hw1 : w ≠ 1 := by
        intro h
        apply hs0
        linear_combination -h
      have hwn : ∀ n : ℕ, w ≠ -n := by
        intro n h
        have := congrArg Complex.re h
        simp at this
        linarith [(Nat.cast_nonneg n : (0 : ℝ) ≤ n)]
      have hfe := riemannZeta_one_sub hwn hw1
      rw [show 1 - w = s by rw [hw]; ring, hz] at hfe
      have hζw := riemannZeta_ne_zero_of_one_le_re hwre
      have hΓ := Complex.Gamma_ne_zero hwn
      have hπ : (Real.pi : ℂ) ≠ 0 := by exact_mod_cast Real.pi_ne_zero
      have h2π : (2 * (Real.pi : ℂ)) ^ (-w) ≠ 0 := by
        rw [Ne, Complex.cpow_eq_zero_iff]
        exact fun h => (mul_ne_zero two_ne_zero hπ) h.1
      have hcos : Complex.cos (Real.pi * w / 2) = 0 := by
        simpa [hζw, hΓ, h2π] using hfe.symm
      obtain ⟨k, hk⟩ := Complex.cos_eq_zero_iff.mp hcos
      have hwk : w = 2 * k + 1 := by
        apply mul_left_cancel₀ hπ
        linear_combination 2 * hk
      have hre : (w.re : ℝ) = 2 * k + 1 := by rw [hwk]; simp
      have hk0 : (0 : ℝ) ≤ k := by linarith
      have hk1 : 1 ≤ k := by
        have : 0 ≤ k := by exact_mod_cast hk0
        rcases this.lt_or_eq with h | h
        · omega
        · exfalso; apply hs0
          have : s = 1 - w := by rw [hw]; ring
          rw [this, hwk, ← h]; simp
      obtain ⟨n, rfl⟩ : ∃ n : ℕ, k = n + 1 := ⟨(k - 1).toNat, by omega⟩
      apply htriv
      refine ⟨n, ?_⟩
      have : s = 1 - w := by rw [hw]; ring
      rw [this, hwk]
      push_cast
      ring
  · exact hright s hgt hz

end Window
