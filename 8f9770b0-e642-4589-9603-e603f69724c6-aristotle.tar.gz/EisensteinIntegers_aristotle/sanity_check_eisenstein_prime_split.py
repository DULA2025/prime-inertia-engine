#!/usr/bin/env python3
"""
sanity_check_eisenstein_prime_split.py
======================================

Numerical verification of the claims in EisensteinPrimeSplit.lean:

  1. For all Eisenstein integers (a, b), (a² - ab + b²) mod 3 ∈ {0, 1}, never 2.
  2. For primes p ≡ 2 (mod 3) (inert primes), no z in Z[ω] has norm = p.
  3. For p = 3 (ramified), θ = 1 - ω = ⟨1, -1⟩ has norm 3.

Cross-check that this dichotomy is sharp: every prime ≡ 1 (mod 3) IS
represented (that's the split case, handled in a different file).
"""


def norm(z):
    a, b = z
    return a*a - a*b + b*b


def is_prime(n):
    if n < 2: return False
    if n < 4: return True
    if n % 2 == 0: return False
    for k in range(3, int(n**0.5)+1, 2):
        if n % k == 0: return False
    return True


def main():
    print("=" * 70)
    print(" Sanity check: EisensteinPrimeSplit.lean (easy direction)")
    print("=" * 70)

    # --- Check 1: norms mod 3 ---
    print("\nCheck 1: norm(z) mod 3 takes only values 0, 1 — never 2")
    print(f"\n  Enumerating all (a mod 3, b mod 3):")
    print(f"  {'a':>3} {'b':>3}  {'a²-ab+b²':>10} {'mod 3':>7}")
    attained = set()
    for a in range(3):
        for b in range(3):
            N = a*a - a*b + b*b
            attained.add(N % 3)
            print(f"  {a:>3} {b:>3}  {N:>10} {N % 3:>7}")
    print(f"\n  Values attained: {sorted(attained)}")
    print(f"  Value 2 NEVER attained: {'✓' if 2 not in attained else '✗'}")

    # --- Check 2: large-range verification ---
    print("\nCheck 2: large-range verification that norm mod 3 ∈ {0, 1}")
    fails = 0
    total = 0
    for a in range(-25, 26):
        for b in range(-25, 26):
            total += 1
            N = norm((a, b))
            if N % 3 == 2:
                fails += 1
                if fails <= 3:
                    print(f"  FAIL: norm({a}, {b}) = {N}, mod 3 = 2")
    print(f"  Tested {total} pairs in [-25, 25]², {fails} failures")
    print(f"  {'✓ All have norm mod 3 in {0, 1}' if fails == 0 else 'FAILURES'}")

    # --- Check 3: inert primes have no norm-p element ---
    print("\nCheck 3: primes p ≡ 2 mod 3 have NO norm-p Eisenstein element")
    inert_primes = [p for p in range(5, 100) if is_prime(p) and p % 3 == 2]
    print(f"  Inert primes < 100: {inert_primes}")
    for p in inert_primes:
        found = []
        # Search bound: |a|, |b| ≤ 2√(p/3) suffices
        bound = int(2 * (p/3)**0.5) + 2
        for a in range(-bound, bound + 1):
            for b in range(-bound, bound + 1):
                if norm((a, b)) == p:
                    found.append((a, b))
        ok = (len(found) == 0)
        print(f"  p = {p:>3}: norm-{p} elements found: {len(found):>2}  "
              f"{'✓' if ok else '✗'}")

    # --- Check 4: ramified prime 3 has θ ---
    print("\nCheck 4: ramified prime p = 3 has θ = (1, -1) with norm 3")
    theta = (1, -1)
    n_theta = norm(theta)
    print(f"  norm(θ) = norm(1, -1) = 1 - (1)(-1) + (-1)² = 1 + 1 + 1 = {n_theta}")
    print(f"  norm(θ) = 3: {'✓' if n_theta == 3 else '✗'}")

    # --- Check 5: split primes (≡ 1 mod 3) ALL have norm representations ---
    print("\nCheck 5: split primes p ≡ 1 mod 3 all DO have norm-p elements")
    print("         (this is the hard direction — not in this Lean file yet)")
    split_primes = [p for p in range(7, 100) if is_prime(p) and p % 3 == 1]
    print(f"  Split primes < 100: {split_primes}")
    for p in split_primes:
        found = None
        bound = int(2 * (p/3)**0.5) + 2
        for a in range(-bound, bound + 1):
            for b in range(-bound, bound + 1):
                if norm((a, b)) == p:
                    found = (a, b)
                    break
            if found: break
        ok = (found is not None)
        print(f"  p = {p:>3}: example norm-{p} element: "
              f"{str(found) if found else 'NOT FOUND':>10}  {'✓' if ok else '✗'}")

    print()
    print("=" * 70)
    print(" Sanity check complete — easy direction (inert + ramified) verified")
    print("=" * 70)


if __name__ == '__main__':
    main()
