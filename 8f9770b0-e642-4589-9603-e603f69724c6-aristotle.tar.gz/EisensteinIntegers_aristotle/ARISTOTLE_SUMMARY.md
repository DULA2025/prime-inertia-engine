# Summary of changes for run 1ed997a6-aaa6-42f4-bd97-6ab1dcc69121
Successfully created and fully proved `EisensteinPrimeSplit.lean` — all theorems compile with no `sorry`s and only standard axioms.

**What was done:**

1. **Created `EisensteinPrimeSplit.lean`** with all the theorems from your specification.

2. **Proved all theorems**, including the two non-trivial ones:
   - `norm_mod_three`: Uses `native_decide` on `ZMod 3` to verify that `a² - ab + b²` mod 3 is always 0 or 1 for all residues `(a, b)`.
   - `no_norm_eq_of_two_mod_three_nat`: Bridges the `ℕ`/`ℤ`/`ZMod 3` casting to reduce to `no_norm_eq_of_two_mod_three`.

3. **Updated `lakefile.toml`** to include `EisensteinPrimeSplit` as a build target.

**Theorems proved:**
- `norm_mod_three` — norms always lie in {0, 1} mod 3
- `norm_ne_two_mod_three` — norms are never ≡ 2 mod 3  
- `no_norm_eq_of_two_mod_three` — ℤ version of the inert criterion
- `no_norm_eq_of_two_mod_three_nat` — ℕ version
- `inert_prime` — primes p ≡ 2 (mod 3) have no norm-p Eisenstein element
- `ramified_three` — θ = 1 - ω has norm 3
- Spot checks for p = 5, 11, 17

All axioms used are standard: `propext`, `Classical.choice`, `Lean.ofReduceBool`, `Lean.trustCompiler`, `Quot.sound`.