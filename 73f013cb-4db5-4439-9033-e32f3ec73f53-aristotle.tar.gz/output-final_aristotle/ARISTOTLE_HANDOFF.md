# ARISTOTLE HANDOFF — HiarySaraeb_Thm15.lean

Formalization target: **Theorem 1.5** of Hiary–Saraeb, *Functional equations
characterize Dirichlet characters*, arXiv:2607.00332v1 (July 2026).
A converse to Gauss's separability theorem: Fourier self-duality for a battery
of powers f^c (c ∈ H) forces f to be a primitive Dirichlet character.

## Status

Skeleton, **not compiled** (no Mathlib toolchain in the authoring sandbox).
Expect minor lemma-name drift against current Mathlib; every sorry carries the
intended entry points. Structure mirrors the paper equation-by-equation.

## Paper ↔ Lean correspondence

| Paper | Lean object | Status |
|---|---|---|
| eq. (28) unnormalized 𝓕 | `Fhat` | defined |
| eq. (29) battery, Λ_c ≠ 0 | `hbat` | hypothesis |
| eq. (30) Λ₁ ∈ Q(ζ_mN) | automatic (values in K) | — |
| eqs. (31)–(32) CRT lift x_s, σ_s | `exists_lift`, `σ` | sorry S5, S3 |
| eq. (33) σ_s(ζ_N)=ζ_N^s, σ_s(ζ_m)=ζ_m^{c_s} | `σ_zeta`, `σ_root` | sorry S3, S4 |
| eq. (34) σ_s(f x) = f x^{c_s} | inside `σ_Fhat` | sorry S6 |
| eq. (35) σ(𝓕f)(r) = 𝓕(f^c)(sr) | `σ_Fhat` | sorry S6 |
| eqs. (36)–(39) multiplicativity | `f_multiplicative` | sorry S7 |
| character packaging | `chi`, `chi_apply_eq` | sorry S8 |
| eq. (40) separability | `separable` | sorry S9 (easy) |
| primitivity via Apostol 8.19 | `chi_isPrimitive` | sorry S10 (**hard**) |
| eq. (6) + odd/squarefree | `p_dvd_order_of_primitive_prime_pow`, `odd_and_squarefree_of_coprime` | sorry S11, S12 |

## Sorry inventory (suggested attack order)

| # | Lemma | Difficulty | Entry points / sketch |
|---|---|---|---|
| S1 | `zN_isPrimitiveRoot`, `zN_pow_N` | trivial | `IsPrimitiveRoot.pow`, `pow_mul` |
| S2 | `e_add` tail, inner inverse of `pow_val_unit_inj` | easy | `pow_reduce` (proved), `ZMod.val_add`, `ZMod.val_coe_unit_coprime`, modular inverse from coprimality |
| S3 | `σ`, `σ_zeta` | medium | `IsCyclotomicExtension.autEquivPow (cyclotomic.irreducible_rat _)`, `.symm`; spec via `IsPrimitiveRoot.autToPow_spec` |
| S4 | `σ_root` | easy given S3 | `IsPrimitiveRoot.eq_pow_of_pow_eq_one` (μ_{mN} = ⟨ζ⟩), `map_pow` |
| S5 | `exists_lift` | medium | `Nat.chineseRemainder'` (compatible moduli), `ZMod.val_coe_unit_coprime`, `Nat.ModEq` gcd transfer, `Nat.Coprime.mul_right`, `ZMod.unitOfCoprime` |
| S6 | `σ_Fhat` | medium | `map_sum`, `map_mul`, S4 twice, `pow_reduce`; non-unit terms vanish by `hzero` + `map_zero`. No sum reindexing needed. |
| S7 | `f_multiplicative` | medium | pure algebra: field cancellation (`hΛcne`), `map_inv₀`, exponent 1-normalization `ZMod.val_one` (needs 1 < m), finish with `pow_val_unit_inj` (proved) |
| S8 | `chi`, `chi_apply_eq` | easy | `MulChar.equivToUnitHom.symm`, `Units.mk0` with `f_ne_zero`, `MulChar.map_nonunit` |
| S9 | `separable` | easy | battery at c = 1 (`H.one_mem`), `hone` |
| S10 | `chi_isPrimitive` | **hard** | Mathlib has `DirichletCharacter.conductor` but (likely) not Apostol 8.19⇐. Route A: induced modulus d < N ⟹ contradiction at ξ = N/p, p ∣ N/d (Apostol pp.168–171). Route B (if working over ℂ): Parseval ⟹ \|τ(f)\|² = N; imprimitive χ has τ(χ) = μ(N/d)ψ(N/d)τ(ψ), \|τ\|² = d or 0 < N. Recommend attempting Route A as a standalone Mathlib-worthy lemma. |
| S11 | `p_dvd_order_of_primitive_prime_pow` | medium-hard | primitivity ⟹ χ nontrivial on 1 + p^{α-1}ℤ (exponent-p subgroup) ⟹ a value is a nontrivial p-th root ⟹ p ∣ order. Odd p: `ZMod.isCyclic_units`; p = 2, α ≥ 3: ±5^b structure of (ZMod 2^k)ˣ. |
| S12 | `odd_and_squarefree_of_coprime` | medium given S11 | character factorization along `ZMod.chineseRemainder`; the three 2-adic cases of the paper (ν = 1, 2, ≥ 3). |

## Design decisions (do not "fix" these)

1. **Abstract cyclotomic K, not ℂ.** The Galois action σ_u is the engine; it
   does not exist usably over ℂ. The paper's ℂ-statement is recovered by
   restricting to Q(ζ_mN) ⊂ ℂ (final remark in the file).
2. **f̄ := x ↦ (f x)⁻¹.** Conjugation of root-of-unity values is inversion;
   Lean's 0⁻¹ = 0 makes this exact off the units too.
3. **hH in consequence form.** The paper's surjectivity H ↠ (ZMod d)ˣ is used
   only as: ∀ unit s mod N, ∃ c ∈ H with s ≡ c mod d. Stated directly; the
   equivalence is `ZMod.unitsMap_surjective` for d ∣ N.
4. **Order-m minimality dropped.** The proof needs only im(f) ⊆ μ_m plus the
   H-battery for that m; minimality of m is irrelevant to the argument.
5. **1 < m threaded where needed** (exponent normalization `val 1 = 1`,
   `pow_val_unit_inj`).

## Numerical oracle (Representation-level guard)

`labF_converse.py` in the same output set. Before/after any statement change:
- N=9, m=3: c=1 alone must admit exactly 4 survivors (2 characters + 2
  impostors; the paper's eq. (20) has Λ₁ = 3·e(7/9) exactly); the full battery
  H = {1,2} must leave exactly {χ₉, χ̄₉}.
- N=7, m=6: one identity ⟹ exactly 5 survivors, all characters.
- Both N=9 impostors violate parity — Theorem 1.5 (no parity hypothesis) MUST
  therefore need the battery; a "proof" of the single-identity version is a
  red flag, not a triumph.

## Suggested first Aristotle pass

Feed the whole file; ask for S1, S2, S4, S8, S9 first (mechanical), then
S5, S6, S7 (the mathematical core), then S3 (API archaeology), leaving S10–S12
for a dedicated second round. Prior precedent: IndBanach.lean round one closed
14/20 sorries — this file is engineered for a comparable hit rate on S1–S9.
