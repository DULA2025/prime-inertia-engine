# Summary of changes for run 79a8270d-b0db-4303-b064-43356bd3ba12
Closed the last remaining `sorry` in `HiarySaraeb_Thm15.lean` — the primitivity theorem `separable_implies_primitive` (converse of Apostol's separability theorem). The whole file now builds cleanly with no `sorry`/`admit`, and `#print axioms HiarySaraeb.thm15` reports exactly `propext, Classical.choice, Quot.sound` (no `sorryAx`); `separable_implies_primitive` itself is likewise axiom-clean.

Route (as suggested in Round 2, kept fully algebraic and valid over the abstract field `K` — no absolute values, no Möbius casework): let `d = conductor χ`; since `d ∣ N`, either `d = N` (done) or `d < N`. In the latter case, factor `χ` through the primitive character `χ₀` mod `d` and evaluate the separability identity at the single non-unit frequency `ξ = -(N/d)`. The right side is `τ(χ)·(χ(-(N/d)))⁻¹ = 0` because `-(N/d)` is a non-unit; the left side is a positive-integer multiple of the level-`d` Gauss sum of `χ₀`, which is nonzero — contradiction.

New supporting lemmas added and proved (all sorry-free):
- `zN_pow_Ndivd_isPrimitiveRoot` — `ζ_N^{N/d}` is a primitive `d`-th root of unity.
- `e_mul_Ndivd` — the additive character at frequency `N/d` descends to `ζ_d` composed with reduction mod `d`.
- `sum_over_units_eq` — a sum over `ZMod d` of a function vanishing off the units equals the sum over units.
- `sum_units_comp_unitsMap` — the fibre-collapse: summing `G ∘ unitsMap` over `(ZMod N)ˣ` is a positive multiple of the sum of `G` over `(ZMod d)ˣ`.
- `Fhat_neg_Ndivd_eq` (Lemma A) — the Gauss sum `𝓕 χ (-(N/d))` collapses to the level-`d` units sum against `ζ_d`.
- `units_sum_eq_gaussSum` — identifies that units sum with the Mathlib `gaussSum` against the standard additive character.
- `gaussSum_inversion` — finite Fourier inversion for Gauss sums, valid over any integral domain.
- `sum_units_primitive_ne_zero` (Lemma B2) — the level-`d` primitive Gauss sum is nonzero.

Notable design point for B2/nonvanishing: Mathlib's `gaussSum_mul_gaussSum_eq_card` / `gaussSum_ne_zero_of_nontrivial` require the base ring to be a field, i.e. only cover prime modulus, so they do not apply to composite `d`. Instead the nonvanishing is obtained via a Fourier-inversion argument (`gaussSum_inversion` + primitivity via `gaussSum_mulShift_of_isPrimitive`), which needs only that `K` is an integral domain and therefore works for composite `d`. As anticipated, the hypothesis `hsep0` (τ(χ) ≠ 0) is not needed on this route; it was kept in the statement since `separable` supplies it and it mirrors the separability data.

No theorem/definition statements were changed (only the previously-`sorry`ed proof was filled and the stale docstring on `separable_implies_primitive` was updated to describe the actual proof), so the numerical-oracle guard is unaffected. All changes are committed and pushed.

# Summary of changes for run 4b57431b-2577-4717-bf89-abcd8541f5fa
Formalized Theorem 1.5 of Hiary–Saraeb ("Functional equations characterize Dirichlet characters", a converse to Gauss's separability theorem) in `HiarySaraeb_Thm15.lean`.

## What was done
The provided skeleton did not compile (auto-bound section-variable issues, wrong call arities, a non-existent `MulChar.conductor`, and a `Set ℕ+` cyclotomic set that current Mathlib states over `Set ℕ`). I rewrote it into a clean, compiling development with consistent explicit signatures, then proved the mathematics.

Everything is proved except a single, clearly documented `sorry`. Concretely, the following are now fully proved (verified to depend only on the standard axioms `propext`, `Classical.choice`, `Quot.sound`):
- Root-of-unity/exponent lemmas: `zN_isPrimitiveRoot`, `zN_pow_N`, `pow_reduce`, `pow_val_unit_inj`, `e_zero`, `e_add`, `e_powN`, `e_pow`, `f_ne_zero`.
- The Galois action `σ` (defined via `IsCyclotomicExtension.autEquivPow`) with `σ_root` (action on every m·N-th root of unity, via `modularCyclotomicCharacter`) and `σ_zeta`.
- The CRT unit lift `exists_lift`.
- The key intertwining identity `σ_Fhat` (σ maps 𝓕 f to 𝓕(fᶜ) at the dilated frequency).
- Multiplicativity `f_multiplicative` (the core functional-equation argument).
- Character packaging `chi`, `chi_apply_eq`; and `separable`.
- The coprime case: `p_dvd_order_of_primitive_prime_pow` and the level-N results `prime_sq_dvd_imp_p_dvd_m`, `factorsThrough_half`, culminating in `odd_and_squarefree_of_coprime` (a primitive character with m-th-root values and gcd(m,N)=1 forces N odd and squarefree) — proved without needing a CRT decomposition of Dirichlet characters.
- The assembled statement `thm15`: under the battery (★), f is the extension-by-zero of a primitive Dirichlet character mod N, and if gcd(m,N)=1 then N is odd and squarefree.

## The one remaining `sorry`
`separable_implies_primitive` — the converse of Apostol's separability theorem (Apostol Thm 8.19/8.20): separability of all Gauss sums together with τ(χ) ≠ 0 implies the character is primitive. To our knowledge this is not in Mathlib; it needs the Möbius/Ramanujan-sum evaluation of Gauss sums of imprimitive characters. It is left as a single `sorry` accompanied by a detailed proof outline (bridging `Fhat` to `gaussSum`, the primitive additive character `ê`, and the non-vanishing at frequency N/p). Consequently `thm15` currently depends on `sorryAx` solely through this lemma; every other result listed above is sorry-free.

The file builds cleanly (only benign `unusedSectionVars`/`unusedSimpArgs` style warnings remain). All changes are committed and pushed.