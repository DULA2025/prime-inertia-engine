# DULA Project — Ind-Banach Skeleton (Research Scaffold)

This package contains:
- The 9 verified canonical project files (3 sorrys, all documented).
- A NEW file `RequestProject/IndBanach.lean` providing a research-program
  skeleton for the inductive-limit-of-Banach-spaces topology on
  `WeilTestFunction`, motivated by the rigorous counterexample to
  continuity in the Schwartz subspace topology.

The skeleton has 20 sorrys, each marking a genuine open research target
(not a minor proof obligation). See `INSTRUCTIONS_FOR_ARISTOTLE.md` for
details.

## Honest framing

This is NOT a working ind-Banach formalization. It is a STRUCTURED
SCAFFOLD that lays out type definitions, key properties, and the
conditional theorem `Conjecture_A_Strong_WTF_indBanach → RH`, with
sorry bodies marking the genuine gaps.

Closing the substantive sorrys requires:
- Building LF-space theory in Mathlib (multi-week project).
- Verifying the Cohn-Elkies density question (off-Lean math research).

Aristotle running this is expected to close 0-3 of the easiest
infrastructure sorrys, leaving the substantive ones open. That is the
expected and acceptable outcome.

## Files

- `RequestProject/*.lean` — 10 Lean files (9 verified + 1 new skeleton).
- `INSTRUCTIONS_FOR_ARISTOTLE.md` — task description.
- `lakefile.toml`, `lean-toolchain` — build files.
