# Instructions for Aristotle — Ind-Banach Skeleton (Research Scaffold)

## What this is

A **research-program skeleton** for an inductive-limit (LF-space) topology
on `WeilTestFunction`. The new file `RequestProject/IndBanach.lean`
contains:

- Type definitions for the spaces `E_b` (Banach spaces of even Schwartz
  functions with exponential decay rate `(1/2 + b)`).
- Proposed Banach structure on each `E_b` (with sorry instances).
- Definition of the inductive-limit topology on `WeilTestFunction`.
- Statements of key properties (with sorry proofs).
- Conditional theorem `conjecture_a_strong_indBanach_implies_rh` (sorry).

## What this is NOT

This is NOT a typical Aristotle target. The 20 sorrys in `IndBanach.lean`
mark **genuine open research targets**, not minor Mathlib API
navigation. Specifically:

- LF-space (inductive limit of Banach spaces) theory is not currently
  developed in Mathlib in usable form. Mathlib has
  `TopologicalSpace.iSup` for sups of topologies but not the
  "regularity" property of LF-spaces (convergent sequences live in
  some `E_{b_0}`).
- Each `E_b` needs its Banach structure built from scratch.
- The continuity-of-Weil-functional theorem requires the full
  cross-term-bounded-linear analysis (see `topology_analysis.md`).
- The `Conjecture_A_Strong_WTF_indBanach` density question is OPEN
  MATHEMATICAL RESEARCH (depends on whether Cohn-Elkies extremal
  functions satisfy ind-Banach convergence).

## Honest expectation

The expected outcome of running this file is:
- It compiles with **20 sorrys in IndBanach.lean** (all genuine, no
  unsoundness).
- Aristotle's automated prover **will likely close 0 to 3 of the
  sorrys**, specifically the easiest "infrastructure" ones like
  `decayNorm_nonneg` (positivity from sup of non-negatives).
- The substantive sorrys (Banach structure, completeness, topology
  finer-than, regularity of LF-space, continuity of Weil functional,
  conditional reduction) **will not close** without substantial new
  Mathlib infrastructure.

This is not failure. The value of this round is having the structure
laid out clearly, with each gap named and documented.

## Task

1. Verify the project builds (yes, with the 23 sorrys).
2. Attempt to close any of the 20 sorrys in `IndBanach.lean` that are
   tractable. Specifically the easiest targets:
   - `decayNorm_nonneg` — sup of non-negatives is non-negative.
   - `decayNorm_lt_top` — bound by the witness `C` from `has_decay`.
   - `AddCommGroup` instance — routine if `Add`, `Zero`, etc. are filled.
3. Report which sorrys (if any) closed, and which remain.
4. If a sorry's resolution requires invoking infrastructure Aristotle
   cannot provide (LF-space theory, etc.), report the specific Mathlib
   gap.

## What NOT to do

- **DO NOT** modify any of the 9 existing files (they are the verified
  canonical state).
- **DO NOT** rebuild `WeilTestFunction.lean` or any other existing
  file from scratch. The new file `IndBanach.lean` IMPORTS from
  `RequestProject.WeilTestFunction`.
- **DO NOT** use `axiom`, `admit`, or `native_decide`.
- **DO NOT** silently change the type signatures or theorem statements
  in `IndBanach.lean`.
- **DO NOT** claim a proof "works" if it relies on sorries that you
  introduced elsewhere — chain-of-sorries is not progress.

## Reporting

In `ARISTOTLE_SUMMARY.md`:
- Final sorry count per file. Expected: 0 in 8 existing files, 1 in
  ContinuityHelpers, 2 in WeilTestFunction, ≤20 in IndBanach.
  TOTAL ≤ 23.
- For each sorry in IndBanach.lean, brief status:
  - "closed" / "attempted, failed" / "not attempted, requires LF-space theory"
- Build status.
- Honest assessment: which research gaps remain.

## Why this is a legitimate skeleton, not a shortcut

The reason this file is acceptable (despite 20 sorrys):

- Each sorry is a NAMED research target with documented proof obligation.
- The TYPE STRUCTURE is mathematically meaningful (defines the
  ind-Banach topology correctly).
- The CONDITIONAL theorem statements are correct (modulo their sorry
  premises).
- Future workers can pick up specific sorries as research projects.

This is what a "skeleton file" looks like: structure laid out, gaps
explicitly marked, no false claims of completeness.

The user is advised: this skeleton is a research-program scaffold,
not a working ind-Banach formalization. Closing the substantive
sorrys requires multi-week Mathlib infrastructure work that is
beyond a single Aristotle session.
