import Mathlib

set_option maxHeartbeats 8000000

/-! ## Collatz orbit definitions -/

/-- The Collatz step function: n/2 if n is even, 3n+1 if n is odd -/
def collatzStep (n : Nat) : Nat :=
  if n % 2 = 0 then n / 2 else 3 * n + 1

/-- The sign at each Collatz step: +1 for even, -1 for odd -/
def collatzSign (n : Nat) : Int :=
  if n % 2 = 0 then 1 else -1

/-- The true orbit length: number of steps to reach ≤ 1.
    This definition assumes termination of the Collatz sequence (decreasing_by sorry). -/
noncomputable def trueOrbitLength (n : Nat) : Nat :=
  if n ≤ 1 then 0 else 1 + trueOrbitLength (collatzStep n)
decreasing_by sorry

namespace collatzSignSum
/-- Accumulate the sign sum along the Collatz orbit with given fuel -/
def go : Nat → Int → Nat → Int
  | _, acc, 0 => acc
  | n, acc, Nat.succ fuel =>
    if n ≤ 1 then acc
    else go (collatzStep n) (acc + collatzSign n) fuel
end collatzSignSum

/-- Phase structure for orbital phase tracking -/
structure Phase where
  val : Int

/-- The net phase of a Collatz orbit -/
noncomputable def netPhase (n : Nat) : Phase :=
  ⟨collatzSignSum.go n 0 (trueOrbitLength n + 1)⟩

/-- Drop trigger: whether n has reached the base case -/
def dropTrigger (n : Nat) : Bool := decide (n ≤ 1)

/-! ## Helper lemmas -/

/-
collatzSign is always odd, so collatzSign n % 2 = 1
-/
lemma collatzSign_mod_two (n : Nat) : collatzSign n % 2 = 1 := by
  unfold collatzSign; split_ifs <;> norm_num;

/-
Generalized parity rule with arbitrary accumulator
-/
lemma collatz_parity_aux (n : Nat) (acc : Int) (fuel : Nat) (h : fuel ≥ trueOrbitLength n) :
    (collatzSignSum.go n acc fuel) % 2 = (acc + ↑(trueOrbitLength n)) % 2 := by
  induction' fuel with fuel ih generalizing n acc;
  · aesop;
  · by_cases hn : n ≤ 1;
    · unfold collatzSignSum.go; interval_cases n ; unfold trueOrbitLength ; aesop;
      unfold trueOrbitLength; aesop;
    · convert ih ( collatzStep n ) ( acc + collatzSign n ) _ using 1;
      · rw [ show collatzSignSum.go n acc ( fuel + 1 ) = collatzSignSum.go ( collatzStep n ) ( acc + collatzSign n ) fuel from ?_ ];
        exact if_neg hn;
      · rw [ show trueOrbitLength n = 1 + trueOrbitLength ( collatzStep n ) from ?_ ];
        · unfold collatzSign; split_ifs <;> ring;
          · grind +splitImp;
          · omega;
        · rw [ trueOrbitLength ] ; aesop;
      · unfold trueOrbitLength at h;
        grind

/-! ## §7 The Bipartite Selection Rule -/

/-
The parity of the net sign sum equals the parity of the true orbit length.
-/
lemma collatz_parity_rule (n : Nat) (fuel : Nat) (h : fuel ≥ trueOrbitLength n) :
    (collatzSignSum.go n 0 fuel) % 2 = (trueOrbitLength n : Int) % 2 := by
  rw [ collatz_parity_aux _ _ _ h ] ; norm_num

/-
The DULA phase parity matches orbital depth parity.
-/
theorem bipartite_walk_invariant (n : Nat) (_h : dropTrigger n = false) :
    (netPhase n).val % 2 = (trueOrbitLength n : Int) % 2 := by
  -- Apply the lemma collatz_parity_rule with fuel = trueOrbitLength n + 1.
  apply collatz_parity_rule n (trueOrbitLength n + 1) (by linarith)