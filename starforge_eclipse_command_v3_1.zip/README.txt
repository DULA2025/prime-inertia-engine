DULA GAME STUDIOS // STARFORGE: ECLIPSE COMMAND (V3.1 — WITH DYNAMIC SPACE MUSIC)
======================================================
Native Windows 11 C + OpenGL 4.6 Core Compute + NVIDIA NVML + GPU UI + WinMM Audio

WHAT'S NEW IN V3.0
------------------
- 4.0-Second Animated Splash Presentation ("DULA GAME STUDIOS PRESENTS") with
  holographic expanding rings, sweeping anamorphic light flare, deep-space ringed
  planet backdrop, and synthesized cosmic synth chord swell (click/Space to skip).
- New Title Branding: "STARFORGE: ECLIPSE COMMAND" across both the Windows titlebar
  and full-resolution GPU on-screen typography.
- Full Interactive Main Menu & In-Game Pause Menu (ESC / P):
  Mouse hover/click AND keyboard (W/S or Up/Down + Enter) navigation for Launch,
  Display (Fullscreen/Windowed), Optical Filter, Tone Mapper, Audio Mute, Restart,
  and Exit, plus Victory and Game Over summary screens.
- Borderless Fullscreen Mode Enabled by Default on Windows 11 (F11, Alt+Enter, or
  Menu toggle switches seamlessly between Fullscreen and Windowed mode).
- Custom Game Icon Embedded Everywhere:
  * starforge.ico + starforge.rc embedded directly into starforge.exe by build_starforge.bat
  * Runtime procedural 32x32 & 64x64 Win32 icon via CreateIconIndirect for taskbar,
    titlebar, and Alt-Tab switcher.
- Visual & Space Fleet Upgrades:
  * Distant analytical Ringed Gas Giant Planet with translucent rings & planet shadow.
  * 2 Imperial Escort Star Cruisers flanking the sculpted Orbital Dreadnought.
  * Dedicated Pass 8 Full-Res GPU 2D UI & Crisp 5x7 Bitmap Font Engine for sharp
    Fullscreen combat HUD telemetry (FPS, GPU ms, RTX model, Objectives, Hull/Shield).

HOW TO BUILD & PLAY (Windows 11)
--------------------------------
1. Extract this ZIP into a folder.
2. Double-click build_starforge.bat
   (Auto-detects MinGW-w64 gcc + windres OR Visual Studio cl + rc.)
3. starforge.exe compiles with the embedded icon and launches directly in Fullscreen!

CONTROLS
--------
- Mouse Move             : Aim & steer starfighter (auto-hides OS cursor in combat)
- Left-Click / Space     : Fire Quad Crimson Lasers
- Right-Click / E        : Launch Homing Proton Torpedoes
- W / S / Mouse Wheel    : Throttle Up / Brake
- A / D                  : Manual Barrel Roll
- Shift                  : Ion Afterburner Boost
- C / Tab                : Toggle S-Foils / Cycle Camera (Chase / Hero / Cockpit)
- ESC / P                : Pause Menu
- F / T / B ([ ])        : Optical Filter / Tone Mapper / Split-Screen HDR Wipe
- G / X / M / N / U      : TAA / Auto-Exp / Mute All / Space Music On-Off / VSync
- F5 - F8                : Render Scale (0.50x / 0.75x / 1.00x / 1.25x)
- F11 / Alt+Enter        : Toggle Fullscreen / Windowed
