"""Double-double table of K_0(2 pi n y) for n = 1..M at many heights y.

The naive cost is npts * M evaluations of K_0 -- 1.3e8 at the size we need --
which is out of reach in any multiprecision library.  The way through is an
identity, not a faster exp.

With the quadrature

    K_0(u) = sum_k w_k exp(-u cosh t_k),     u = 2 pi n y,

the argument is n times the argument at n = 1, so

    exp(-2 pi n y cosh t_k) = b_k^n,   b_k := exp(-2 pi y cosh t_k),

and the whole column n = 1..M is obtained from ONE set of exponentials by
repeated multiplication:

    K_0(2 pi n y) = sum_k w_k b_k^n,   b_k^n = b_k^(n-1) * b_k.

So the exponentials number npts * n_nodes = 2.7e6 rather than 1.3e8, and
everything else is multiply-add, which double-double does cheaply and
vectorises over all sample points at once.

The base must be carried in double-double.  Powering amplifies the base's
relative error linearly: a float64 base carries delta ~ 1e-16 and after
n = 12000 steps that is 1.2e-12, an order above the target.  The bases are
therefore computed once in mpmath and stored as dd; the 2.7e6 of them cost
under a minute, and the dd powering contributes only n * 2^-105 ~ 3e-28.

Error budget (all bounded):
  * quadrature discretisation   2 / (exp(pi^2/h) - 1)      = 1e-84 at h = 0.05
  * range truncation at T       exp(-u e^T / 2) / (u e^T/2)
  * dd base                     2^-105 per base
  * dd powering                 n * 2^-105
  * dd summation over k         n_nodes * 2^-105
"""

import numpy as np
import dd
from mpmath import mp, mpf, exp as mexp, cosh as mcosh

EPS_DD = 2.0 ** -105


def quad_nodes(ymin, h=1.0/32.0):
    """Nodes for the smallest argument in play, u_min = 2 pi ymin.

    h MUST be a power of two.  With h = 0.05 neither the step nor the nodes
    t_k = h k are exactly representable, and the resulting O(1e-16) jitter in
    the node positions propagates straight into the table -- measured, it caps
    the accuracy at 2e-17 no matter how good the arithmetic is.  With
    h = 1/32 the nodes and weights are exact binary, and the discretisation
    error 2/(exp(32 pi^2) - 1) = e^-316 is smaller still."""
    umin = 2 * np.pi * ymin
    T = max(1.0, float(np.log(200.0 / umin) + 1.0))
    n = int(np.ceil(T / h))
    t = h * np.arange(n + 1)
    w = np.full(n + 1, h)
    w[0] = 0.5 * h
    return t, w, T, n


def dd_bases(ys, t, dps=40):
    """b[i, k] = exp(-2 pi y_i cosh t_k) in double-double, via mpmath.

    Returns (hi, lo) arrays of shape (len(ys), len(t))."""
    old = mp.dps
    mp.dps = dps
    try:
        hi = np.empty((len(ys), len(t)))
        lo = np.empty_like(hi)
        two_pi = 2 * mp.pi
        for k, tk in enumerate(t):
            ch = mcosh(mpf(float(tk)))
            for i, y in enumerate(ys):
                v = mexp(-two_pi * mpf(float(y)) * ch)
                h0 = float(v)
                hi[i, k] = h0
                lo[i, k] = float(v - mpf(h0))
        return hi, lo
    finally:
        mp.dps = old


def bessel_table_dd(ys, M, h=1.0/32.0, progress=None):
    """K_0(2 pi n y_i) for n = 1..M, as double-double arrays of shape (npts, M).

    Memory: 2 * npts * M float64.  At npts = 24010, M = 12000 that is 4.6 GB.
    """
    ys = np.asarray(ys, dtype=float)
    t, w, T, nn = quad_nodes(ys.min(), h)
    bh, bl = dd_bases(ys, t)
    ph, pl = bh.copy(), bl.copy()              # b^1
    wh, wl = dd.from_f(np.broadcast_to(w, bh.shape).copy())
    Kh = np.empty((len(ys), M))
    Kl = np.empty_like(Kh)
    for n in range(1, M + 1):
        if n > 1:
            ph, pl = dd.mul(ph, pl, bh, bl)
        sh, sl = dd.mul(ph, pl, wh, wl)
        # compensated sum over the node axis
        ah = np.zeros(len(ys))
        al = np.zeros(len(ys))
        for k in range(sh.shape[1]):
            ah, al = dd.add(ah, al, sh[:, k], sl[:, k])
        Kh[:, n - 1], Kl[:, n - 1] = ah, al
        if progress and n % progress == 0:
            print("    n = %d / %d" % (n, M), flush=True)
    # rigorous additive error, uniform over the table
    disc = 2.0 / np.expm1(np.pi ** 2 / h) if np.pi ** 2 / h < 700 else 0.0
    u = 2 * np.pi * ys.min() * np.exp(T) / 2.0
    trunc = float(np.exp(-min(u, 700.0)) / max(u, 1e-300))
    err = disc + trunc + (M + nn + 2) * EPS_DD
    return Kh, Kl, err


# ---------------------------------------------------------------- self-test
if __name__ == "__main__":
    from mpmath import besselk
    mp.dps = 40
    print("=" * 74)
    print("dd Bessel table by repeated multiplication, against mpmath at 40 dps")
    print("=" * 74)
    ys = np.array([0.016, 0.0226, 4.35e-4])
    M = 300
    Kh, Kl, err = bessel_table_dd(ys, M)
    print("  uniform additive error bound on the table: %.3e" % err)
    print()
    print("  %-10s %-6s %-26s %-14s" % ("y", "n", "rel error vs mpmath", "float64 for comparison"))
    worst = 0.0
    for i, y in enumerate(ys):
        for n in (1, 10, 100, 300):
            got = mpf(float(Kh[i, n - 1])) + mpf(float(Kl[i, n - 1]))
            true = besselk(0, 2 * mp.pi * mpf(float(y)) * n)
            rel = abs((got - true) / true)
            worst = max(worst, float(rel))
            f64 = float(np.float64(Kh[i, n - 1]))
            rel64 = abs((mpf(f64) - true) / true)
            print("  %-10.4g %-6d %-26.3e %-14.3e" % (y, n, float(rel), float(rel64)))
    print()
    print("  worst relative error across the table: %.3e" % worst)
    print("  (float64 would give ~1e-16 at n=1 and ~n*1e-16 after powering)")
