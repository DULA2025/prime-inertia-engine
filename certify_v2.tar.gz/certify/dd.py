"""Vectorised double-double arithmetic in numpy (~32 significant digits).

A dd number is a pair (hi, lo) of float64 with hi + lo representing the value
and |lo| <= ulp(hi)/2.  All routines take and return pairs of numpy arrays, so
everything is vectorised.

This exists because the Hejhal system at level 1951 is conditioning-limited:
d_1/d_M = e^(2 pi M Y) is 7.1e10 at M = 8000, so float64 loses about eleven
digits and the automorphy defect bottoms out near 1e-6.  Double-double takes
cond * eps from 1.6e-5 to 7.1e-22, at which point the truncation (aliasing)
error takes over.  The optimum is M = 12000, where both sit near 6e-15.

The algorithms are the standard error-free transformations: Knuth's two_sum,
Dekker's splitting for two_prod.  No FMA is assumed.
"""

import numpy as np

_SPLIT = 134217729.0  # 2^27 + 1


def two_sum(a, b):
    s = a + b
    bb = s - a
    err = (a - (s - bb)) + (b - bb)
    return s, err


def quick_two_sum(a, b):
    s = a + b
    err = b - (s - a)
    return s, err


def _split(a):
    c = _SPLIT * a
    hi = c - (c - a)
    return hi, a - hi


def two_prod(a, b):
    p = a * b
    ah, al = _split(a)
    bh, bl = _split(b)
    err = ((ah * bh - p) + ah * bl + al * bh) + al * bl
    return p, err


# ------------------------------------------------------------------ dd ops --
def add(ah, al, bh, bl):
    s, e = two_sum(ah, bh)
    e = e + (al + bl)
    return quick_two_sum(s, e)


def sub(ah, al, bh, bl):
    return add(ah, al, -bh, -bl)


def mul(ah, al, bh, bl):
    p, e = two_prod(ah, bh)
    e = e + (ah * bl + al * bh)
    return quick_two_sum(p, e)


def mul_d(ah, al, b):
    """dd times plain float64."""
    p, e = two_prod(ah, b)
    e = e + al * b
    return quick_two_sum(p, e)


def from_f(x):
    x = np.asarray(x, dtype=np.float64)
    return x, np.zeros_like(x)


def to_f(ah, al):
    return ah + al


# ------------------------------------------------------- complex dd helpers -
def cmul(ar, al_, ai, ai_, br, bl_, bi, bi_):
    """(ar+i ai) * (br + i bi) in dd; each part is a (hi, lo) pair."""
    p1 = mul(ar, al_, br, bl_)
    p2 = mul(ai, ai_, bi, bi_)
    rr = sub(p1[0], p1[1], p2[0], p2[1])
    q1 = mul(ar, al_, bi, bi_)
    q2 = mul(ai, ai_, br, bl_)
    ri = add(q1[0], q1[1], q2[0], q2[1])
    return rr[0], rr[1], ri[0], ri[1]


def dot_real(Ah, Al, wh, wl, axis=-1):
    """Sum over `axis` of A * w, all dd."""
    ph, pl = mul(Ah, Al, wh, wl)
    sh = np.zeros(ph.shape[:axis] if axis == -1 else ph.shape, dtype=np.float64)
    # simple sequential compensated sum along the axis
    ph = np.moveaxis(ph, axis, 0)
    pl = np.moveaxis(pl, axis, 0)
    sh = np.zeros(ph.shape[1:], dtype=np.float64)
    sl = np.zeros_like(sh)
    for k in range(ph.shape[0]):
        sh, sl = add(sh, sl, ph[k], pl[k])
    return sh, sl


# ------------------------------------------------------------------ self-test
if __name__ == "__main__":
    from mpmath import mp, mpf
    mp.dps = 40
    rng = np.random.default_rng(0)
    print("=" * 70)
    print("double-double arithmetic: relative error against mpmath at 40 dps")
    print("=" * 70)
    a = rng.uniform(0.1, 10, 2000)
    b = rng.uniform(0.1, 10, 2000)
    ah, al = from_f(a)
    bh, bl = from_f(b)

    sh, sl = add(ah, al, bh, bl)
    mh, ml = mul(ah, al, bh, bl)
    err_s = max(abs((mpf(float(sh[i])) + mpf(float(sl[i])) - (mpf(float(a[i])) + mpf(float(b[i]))))
                    / (mpf(float(a[i])) + mpf(float(b[i])))) for i in range(50))
    err_m = max(abs((mpf(float(mh[i])) + mpf(float(ml[i])) - mpf(float(a[i])) * mpf(float(b[i])))
                    / (mpf(float(a[i])) * mpf(float(b[i])))) for i in range(50))
    print("  add : max relative error %.3e" % float(err_s))
    print("  mul : max relative error %.3e" % float(err_m))
    print("  (float64 eps = %.3e, dd eps ~ %.3e)" % (2.0 ** -53, 2.0 ** -105))

    # repeated multiplication, the operation the Bessel table leans on
    print()
    print("  b^n by repeated dd multiplication, b = 0.9, n = 1..4000:")
    bh0, bl0 = from_f(np.array([0.9]))
    ph, pl = bh0.copy(), bl0.copy()
    for n in range(2, 4001):
        ph, pl = mul(ph, pl, bh0, bl0)
    exact = mpf('0.9') ** 4000
    got = mpf(float(ph[0])) + mpf(float(pl[0]))
    print("    dd      relative error after 4000 mults : %.3e" % float(abs((got - exact) / exact)))
    p64 = 0.9 ** 4000
    print("    float64 relative error after 4000 mults : %.3e"
          % float(abs((mpf(float(p64)) - exact) / exact)))
