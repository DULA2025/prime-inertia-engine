"""Certified bound on the Fricke automorphy defect of the computed form.

This is the empirical input a BSV-style existence certificate needs: a
RIGOROUS upper bound on how far the numerical eigenfunction is from being
automorphic.  Everything below is an enclosure, never an estimate.

Why the circle |z| = 1/sqrt(N).
-------------------------------
The Fricke involution is sigma_0 z = -1/(N z).  On |z|^2 = 1/N one has
1/z = N conj(z), hence

    sigma_0 z = -conj(z) = -x + i y,

so sigma_0 preserves the imaginary part there.  Two consequences, both good:

  * both sides of the relation are evaluated at the SAME y, so no term of the
    expansion is being compared across wildly different scales;
  * y ~ 1/sqrt(1951) = 0.0226, which is fifty times larger than the sampling
    height of the solve.  At that height 2 pi n y > 45 once n > 320, so the
    Fourier tail is bounded by 1e-23 and only a few hundred terms matter.

The relation to test is f|W_N = lambda_N f-bar, that is

    f(-x + i y)  =  lambda_N * sum_n conj(c_n) W_|n|(y) e(nx)                (*)

with lambda_N pinned to the exact algebraic value tau(chi) zeta_5^3 / sqrt(N).

A warning about a shortcut that does not work: since both sides of (*) are
Fourier series in x at the same y, it is tempting to match coefficients and
conclude c_{-n} = lambda_N conj(c_n).  That is FALSE.  The arc carries only
|x| <= 1/sqrt(N) = 0.0226, a small sub-interval of the period, on which the
characters e(nx) are not orthogonal.  Measured on the data those brackets are
O(1), which is exactly the cancellation one should expect.  The defect has to
be bounded pointwise, and its supremum over the arc by subdivision.

Error budget, all bounded rather than estimated
-----------------------------------------------
1. K-Bessel.  K_0(x) = int_0^inf exp(-x cosh t) dt is evaluated by the
   trapezoidal rule.  The integrand is analytic and bounded in |Im t| < pi/2,
   so the discretisation error is at most 2/(exp(pi^2/h) - 1) = 1e-84 at
   h = 0.05, and the range truncation at T contributes exp(-x e^T/2)/(x e^T/2).
   The integrand is POSITIVE, so the float64 summation has no cancellation and
   its relative rounding error is at most n_terms * 2^-53.
2. Fourier truncation.  |c_n| <= d(n) n^theta with theta = 7/64 (Kim-Sarnak,
   unconditional), and d(n) <= 2 sqrt(n), so |c_n| <= 2 n^(1/2 + 7/64).  With
   K_0(u) <= sqrt(pi/(2u)) exp(-u) the tail beyond M is summed geometrically.
3. Variation across a box.  |e(n x) - e(n x_0)| <= 2 pi n |x - x_0| and the
   y-variation is controlled by |dW/dy| <= 2 pi n sqrt(y) K_1 + K_0/(2 sqrt y),
   with K_1 evaluated by the same positive-integrand quadrature.
4. Coefficient error.  The c_n are float64 output of the solve; the bound
   carries a per-coefficient uncertainty supplied by the caller.
"""

import numpy as np

N_LEVEL = 1951
THETA_KS = 7.0 / 64.0          # Kim-Sarnak
EPS64 = 2.0 ** -53


# ---------------------------------------------------------------- K-Bessel --
def _quad_nodes(xmin, h=0.05):
    T = max(1.0, np.log(200.0 / xmin) + 1.0)
    n = int(np.ceil(T / h))
    t = h * np.arange(n + 1)
    w = np.full(n + 1, h)
    w[0] = 0.5 * h
    return t, w, T, n


def k01_certified(x, h=0.05):
    """(K_0(x), K_1(x), relative error bound), vectorised over x > 0.

    Both integrands are positive, so the float64 sum cannot cancel and the
    relative rounding error is at most (n_terms + 2) * 2^-53.  The analytic
    errors are added separately by the caller through `rel`.
    """
    x = np.atleast_1d(np.asarray(x, dtype=float))
    xmin = float(x.min())
    t, w, T, n = _quad_nodes(xmin, h)
    ch = np.cosh(t)
    E = np.exp(-np.outer(x, ch))
    K0 = E @ w
    K1 = E @ (w * ch)
    # analytic: discretisation 2/(e^{pi^2/h}-1); range truncation
    disc = 2.0 / np.expm1(np.pi ** 2 / h) if np.pi ** 2 / h < 700 else 0.0
    u = x * np.exp(T) / 2.0
    trunc = np.where(u < 700, np.exp(-np.minimum(u, 700.0)) / np.maximum(u, 1e-300), 0.0)
    absolute = disc + trunc
    rel = (n + 2) * EPS64
    return K0, K1, absolute, rel


# ------------------------------------------------------------------- tails --
def fourier_tail_bound(M, y, theta=THETA_KS):
    """Rigorous bound on sum_{|n|>M} |c_n| sqrt(y) K_0(2 pi |n| y), both signs.

    |c_n| <= 2 n^(1/2+theta) (Kim-Sarnak with d(n) <= 2 sqrt n), and
    sqrt(y) K_0(2 pi n y) <= (1/2) n^(-1/2) e^(-2 pi n y), so each summand is at
    most n^theta e^(-c n) with c = 2 pi y, and both signs give a factor 2.

    Writing n = M+1+k and using (1 + k/(M+1))^theta <= 1 + k/(M+1) for
    0 <= theta <= 1,

        sum_{k>=0} (1 + k/(M+1)) e^(-ck)
            = 1/(1-e^-c) + e^-c / ((M+1) (1-e^-c)^2),

    which converges for EVERY c > 0 -- unlike the cruder majorant
    n^theta <= (M+1)^theta e^k, which needs c > theta and so fails at the low
    end of the arc, where 2 pi y = 0.1005 and theta = 0.109.
    """
    c = 2.0 * np.pi * y
    if c <= 0:
        raise ValueError("y must be positive")
    m = M + 1.0
    q = np.exp(-c)
    geo = 1.0 / (1.0 - q) + q / (m * (1.0 - q) ** 2)
    return 2.0 * (m ** theta) * np.exp(-c * m) * geo


# ------------------------------------------------------- certified defect ---
class CertifiedForm:
    """Enclosure of f(x + i y) = sum_{n != 0} c_n sqrt(y) K_0(2 pi |n| y) e(n x)."""

    def __init__(self, coeffs, coeff_err, M):
        self.M = M
        self.n = np.arange(1, M + 1)
        self.cp = np.array([coeffs[k] for k in range(1, M + 1)])
        self.cm = np.array([coeffs[-k] for k in range(1, M + 1)])
        self.cerr = coeff_err

    def enclose(self, x0, y0, dx, dy):
        """Enclosure of f over the box [x0-dx, x0+dx] x [y0-dy, y0+dy].

        Returns (centre value, radius), with the radius covering every error
        source: Bessel, truncation, box variation, coefficient uncertainty and
        float64 rounding.
        """
        n, M = self.n, self.M
        ylo, yhi = y0 - dy, y0 + dy
        K0, K1, babs, brel = k01_certified(2 * np.pi * n * y0)
        W = np.sqrt(y0) * K0
        val = np.sum(self.cp * W * np.exp(2j * np.pi * n * x0)
                     + self.cm * W * np.exp(-2j * np.pi * n * x0))
        absW = np.abs(W)
        s_abs = np.sum((np.abs(self.cp) + np.abs(self.cm)) * absW)

        # (a) Bessel: absolute + relative, scaled by |c_n| sqrt(y)
        e_bessel = np.sum((np.abs(self.cp) + np.abs(self.cm))
                          * (np.sqrt(y0) * babs + absW * brel))
        # (b) variation in x
        e_x = np.sum((np.abs(self.cp) + np.abs(self.cm)) * absW * 2 * np.pi * n * dx)
        # (c) variation in y:  |dW/dy| <= 2 pi n sqrt(y) K_1 + K_0 / (2 sqrt y)
        dWdy = 2 * np.pi * n * np.sqrt(yhi) * K1 + K0 / (2 * np.sqrt(max(ylo, 1e-300)))
        e_y = np.sum((np.abs(self.cp) + np.abs(self.cm)) * dWdy) * dy
        # (d) coefficient uncertainty
        e_c = 2.0 * self.cerr * np.sum(absW)
        # (e) float64 accumulation over 2M terms
        e_round = 2 * M * EPS64 * s_abs
        # (f) Fourier tail beyond M
        e_tail = fourier_tail_bound(M, ylo)
        return val, e_bessel + e_x + e_y + e_c + e_round + e_tail

    def conj_enclose(self, x0, y0, dx, dy):
        """Same for f-bar, the form with conjugated coefficients."""
        saved = (self.cp, self.cm)
        self.cp, self.cm = np.conj(self.cp), np.conj(self.cm)
        out = self.enclose(x0, y0, dx, dy)
        self.cp, self.cm = saved
        return out


def fricke_defect_sup(form, lam, nboxes=400, phi_lo=0.35, phi_hi=0.65):
    """Certified sup of |f(-x+iy) - lam * f-bar(x+iy)| over an arc of
    |z| = 1/sqrt(N), parametrised by phi in [phi_lo, phi_hi] * pi.

    Returns (sup bound, argmax phi, diagnostic dict).
    """
    R = 1.0 / np.sqrt(N_LEVEL)
    phis = np.linspace(phi_lo * np.pi, phi_hi * np.pi, nboxes + 1)
    best, bestphi = 0.0, None
    centre_max = 0.0
    for i in range(nboxes):
        p0, p1 = phis[i], phis[i + 1]
        pm = 0.5 * (p0 + p1)
        x0, y0 = R * np.cos(pm), R * np.sin(pm)
        xa, ya = R * np.cos(p0), R * np.sin(p0)
        xb, yb = R * np.cos(p1), R * np.sin(p1)
        dx = max(abs(xa - x0), abs(xb - x0))
        dy = max(abs(ya - y0), abs(yb - y0))
        lhs, elhs = form.enclose(-x0, y0, dx, dy)
        rhs, erhs = form.conj_enclose(x0, y0, dx, dy)
        d = abs(lhs - lam * rhs)
        centre_max = max(centre_max, d)
        tot = d + elhs + abs(lam) * erhs
        if tot > best:
            best, bestphi = tot, pm
    return best, bestphi, {"centre_max": centre_max}
