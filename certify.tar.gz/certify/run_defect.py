import numpy as np, time
from fricke_defect import CertifiedForm, fricke_defect_sup, k01_certified, fourier_tail_bound, N_LEVEL
from mpmath import mp, besselk, mpf
mp.dps=30
U='/root/.claude/uploads/d6915903-9316-57f9-9828-e10467dd6c20/'

print("="*74); print("Certified Fricke defect of the computed form"); print("="*74)
# --- validate the fast certified K-Bessel against mpmath
xs=np.array([0.1,1.0,5.0,20.0,45.0])
K0,K1,babs,brel=k01_certified(xs)
print("  K-Bessel check against mpmath (30 dps):")
for i,x in enumerate(xs):
    t0=float(besselk(0,mpf(float(x)))); t1=float(besselk(1,mpf(float(x))))
    b=babs[i]+abs(K0[i])*brel
    print("    x=%5.1f  K0 err %8.2e (bound %8.2e)  K1 err %8.2e   inside: %s"
          %(x,abs(K0[i]-t0),b,abs(K1[i]-t1),abs(K0[i]-t0)<=b))
print()
a=np.load(U+'08e051de-1789828800291_coeffs_1951_refined_M8000.npy')
idx=a[0].astype(int); c=a[1]+1j*a[2]; C={int(k):v for k,v in zip(idx,c)}
N=N_LEVEL
dl={};x=1
for k in range(N-1): dl[x]=k; x=(x*3)%N
z5=np.exp(2j*np.pi/5); tab=np.zeros(N,dtype=np.complex128)
for n in range(1,N): tab[n]=z5**((2*dl[n])%5)
aa=np.arange(1,N); tau=np.sum(tab[1:]*np.exp(2j*np.pi*aa/N))/np.sqrt(float(N))
lam=tau*z5**3; lam/=abs(lam)
R=1/np.sqrt(N)
print("  arc: |z| = 1/sqrt(1951) = %.6f ;  y in [%.5f, %.5f]"%(R,R*np.sin(0.35*np.pi),R))
print("  lambda_N = %.9f %+.9fi"%(lam.real,lam.imag))
print()
for M in (400,800,1500):
    print("  Fourier tail beyond M=%4d at y=%.5f :  %.3e"%(M,R*np.sin(0.35*np.pi),
          fourier_tail_bound(M,R*np.sin(0.35*np.pi))))
print()
for M,cerr in ((800,1e-11),(1500,1e-11)):
    f=CertifiedForm(C,cerr,M)
    t0=time.time(); sup,phi,diag=fricke_defect_sup(f,lam,nboxes=300); el=time.time()-t0
    print("  M=%4d  coeff unc %.0e :  CERTIFIED SUP = %.4e   (centre max %.4e)  [%.1fs]"
          %(M,cerr,sup,diag['centre_max'],el))
