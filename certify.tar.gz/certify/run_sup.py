import numpy as np, time
from defect_bb import ArcDefect, R_ARC
from fricke_defect import N_LEVEL
U='/root/.claude/uploads/d6915903-9316-57f9-9828-e10467dd6c20/'
def load(f):
    a=np.load(U+f); i=a[0].astype(int); c=a[1]+1j*a[2]
    return {int(k):v for k,v in zip(i,c)}
N=N_LEVEL; dl={}; x=1
for k in range(N-1): dl[x]=k; x=(x*3)%N
z5=np.exp(2j*np.pi/5); tab=np.zeros(N,dtype=np.complex128)
for n in range(1,N): tab[n]=z5**((2*dl[n])%5)
aa=np.arange(1,N); tau=np.sum(tab[1:]*np.exp(2j*np.pi*aa/N))/np.sqrt(float(N))
lam=tau*z5**3; lam/=abs(lam)

def sup_on_arc(D, lo, hi, target2=1e-9, cap=40000):
    B2=D.second_bound(lo,hi)
    r=np.sqrt(2*target2/B2)
    nb=min(cap,int(np.ceil((hi-lo)/(2*r))))
    r=(hi-lo)/(2*nb)
    cen=lo+r*(2*np.arange(nb)+1)
    best=0.0; bestphi=None; cmax=0.0
    for p in cen:
        v,dv,err=D.value_and_deriv(p)
        ub=abs(v)+abs(dv)*r+0.5*B2*r*r+err
        cmax=max(cmax,abs(v))
        if ub>best: best,bestphi=ub,p
    return best,cmax,nb,r,B2,bestphi

print("="*76)
print("CERTIFIED SUP OF THE FRICKE DEFECT  |f(-conj z) - lambda_N f-bar(z)|")
print("   over an arc of |z| = 1/sqrt(1951),  lambda_N = tau(chi) zeta_5^3 / sqrt(N)")
print("="*76)
C8=load('08e051de-1789828800291_coeffs_1951_refined_M8000.npy')
C4=load('34a66cfb-1789828790898_coeffs_1951_refined_M4000.npy')
lo,hi=0.25*np.pi,0.75*np.pi
print("  arc: phi in [0.25 pi, 0.75 pi],  y in [%.5f, %.5f]"%(R_ARC*np.sin(lo),R_ARC))
print()
print("  %-22s %12s %12s %9s %10s"%("source","CERTIFIED sup","max at centres","boxes","time"))
for name,C,M,cerr in (("M=8000 file, M'=600", C8, 600, 0.0),
                      ("M=8000 file, M'=900", C8, 900, 0.0),
                      ("M=8000 + 1e-11 unc",  C8, 900, 1e-11),
                      ("M=4000 file, M'=900", C4, 900, 0.0)):
    D=ArcDefect(C,lam,M,coeff_err=cerr)
    t0=time.time(); ub,cmax,nb,r,B2,bp=sup_on_arc(D,lo,hi,target2=1e-9,cap=26000); el=time.time()-t0
    print("  %-22s %12.4e %12.4e %9d %9.1fs"%(name,ub,cmax,nb,el),flush=True)
    print("     (r=%.2e  B2=%.3e  B2 r^2/2=%.2e  argmax phi/pi=%.4f)"%(r,B2,0.5*B2*r*r,bp/3.141592653589793),flush=True)
print()
print("  (box half-width r = %.3e, second-order term B2 r^2/2 = %.2e)"%(r,0.5*B2*r*r))
