"""Certified sup of the Fricke defect by adaptive branch-and-bound.

The first-order box bound is hopeless here, and for a structural reason worth
recording.  Write the defect on the arc as

    D(z) = f(-conj z) - lambda f-bar(z) = sum_n b_n W_|n|(y) e(n x),
    b_n = c_{-n} - lambda conj(c_n).

The b_n are O(1) -- measured, median 1e-3, max 8.4 -- while D itself is of size
1e-6.  The smallness of D is entirely cancellation.  So ANY bound that takes
absolute values term by term, as a Lipschitz bound must, throws away eight
orders of magnitude before it starts.

The fix is to keep the cancellation: evaluate D and its derivative by the same
cancelling sums, and let only the SECOND derivative be bounded crudely, where
it is multiplied by dx^2.  On a box of half-width r about phi_0,

    |D| <= |D(phi_0)| + |D'(phi_0)| r + (1/2) B_2 r^2,                      (*)

with B_2 = sum_n |b_n| * sup |d^2/dphi^2 (W_|n|(y(phi)) e(n x(phi)))|, bounded
term by term.  Then subdivide adaptively: a box whose bound already exceeds the
running best is discarded, and only the competitive ones are split.  Since D is
tiny almost everywhere, the queue stays short.

The derivatives are taken along the arc, parametrised by phi:
    x = R cos phi,  y = R sin phi,   R = 1/sqrt(N).
"""

import numpy as np
import heapq
from fricke_defect import k01_certified, fourier_tail_bound, N_LEVEL, EPS64

R_ARC = 1.0 / np.sqrt(N_LEVEL)


class ArcDefect:
    """D(phi) and its first two derivatives along |z| = 1/sqrt(N)."""

    def __init__(self, coeffs, lam, M, coeff_err=0.0):
        self.M = M
        self.lam = lam
        self.n = np.arange(1, M + 1, dtype=float)
        cp = np.array([coeffs[int(k)] for k in range(1, M + 1)])
        cm = np.array([coeffs[-int(k)] for k in range(1, M + 1)])
        # D(z) = f(-x+iy) - lam * fbar(x+iy)
        #      = sum_{n>=1} [ (cm_n - lam conj(cp_n)) e(nx)
        #                   + (cp_n - lam conj(cm_n)) e(-nx) ] W_n(y)
        self.bp = cm - lam * np.conj(cp)
        self.bm = cp - lam * np.conj(cm)
        self.absb = np.abs(self.bp) + np.abs(self.bm)
        self.cerr = coeff_err

    # --- W_n(y) = sqrt(y) K_0(2 pi n y) and its y-derivatives -------------
    def _W(self, y):
        u = 2 * np.pi * self.n * y
        K0, K1, babs, brel = k01_certified(u)
        sy = np.sqrt(y)
        W = sy * K0
        # dW/dy = K0/(2 sqrt y) - 2 pi n sqrt y K1
        dW = K0 / (2 * sy) - 2 * np.pi * self.n * sy * K1
        berr = sy * babs + np.abs(W) * brel
        return W, dW, K0, K1, berr

    def value_and_deriv(self, phi):
        """D(phi), D'(phi), and a rigorous bound on the evaluation error."""
        x, y = R_ARC * np.cos(phi), R_ARC * np.sin(phi)
        dx, dy = -R_ARC * np.sin(phi), R_ARC * np.cos(phi)
        W, dW, K0, K1, berr = self._W(y)
        ep = np.exp(2j * np.pi * self.n * x)
        em = np.conj(ep)
        D = np.sum(self.bp * W * ep + self.bm * W * em)
        Dp = np.sum(self.bp * (dW * dy * ep + W * 2j * np.pi * self.n * dx * ep)
                    + self.bm * (dW * dy * em - W * 2j * np.pi * self.n * dx * em))
        s_abs = np.sum(self.absb * np.abs(W))
        err = (np.sum(self.absb * berr)
               + 2 * self.M * EPS64 * s_abs
               + 2 * (1 + abs(self.lam)) * self.cerr * np.sum(np.abs(W))
               + fourier_tail_bound(self.M, y))
        return D, Dp, err

    def second_bound(self, phi_lo, phi_hi):
        """Crude but rigorous bound on |D''(phi)| over [phi_lo, phi_hi]."""
        ylo = R_ARC * min(np.sin(phi_lo), np.sin(phi_hi))
        W, dW, K0, K1, _ = self._W(ylo)
        # |d^2/dphi^2| <= R^2 * [ (2 pi n)^2 |W| + 2 (2 pi n) |dW| + |d2W| ]
        # with |d2W| <= (2 pi n)^2 sqrt(y) K_0 + ... ; bound K_1 <= K_0 (1 + 1/u)
        u = 2 * np.pi * self.n * ylo
        d2W = (2 * np.pi * self.n) ** 2 * np.sqrt(ylo) * K0 * (1 + 1 / u) + np.abs(dW) / ylo
        t = ((2 * np.pi * self.n) ** 2 * np.abs(W)
             + 2 * (2 * np.pi * self.n) * np.abs(dW) + d2W)
        return R_ARC ** 2 * np.sum(self.absb * t)


def certified_sup(D, phi_lo, phi_hi, n0=64, max_boxes=400000, target=None):
    """Adaptive branch-and-bound for sup |D| on [phi_lo, phi_hi].

    Returns (upper bound on the sup, best lower bound seen, boxes used)."""
    B2 = D.second_bound(phi_lo, phi_hi)
    lower = 0.0
    heap = []
    edges = np.linspace(phi_lo, phi_hi, n0 + 1)
    for i in range(n0):
        a, b = edges[i], edges[i + 1]
        heapq.heappush(heap, (-_box_bound(D, a, b, B2, out=None)[0], a, b))
    used = n0
    while heap and used < max_boxes:
        negub, a, b = heapq.heappop(heap)
        ub = -negub
        if target is not None and ub <= target:
            heapq.heappush(heap, (negub, a, b))
            break
        m = 0.5 * (a + b)
        for (aa, bb) in ((a, m), (m, b)):
            v, low = _box_bound(D, aa, bb, B2, out=None)
            lower = max(lower, low)
            heapq.heappush(heap, (-v, aa, bb))
        used += 2
        if -heap[0][0] <= lower * (1 + 1e-9):
            break
    return (-heap[0][0] if heap else 0.0), lower, used


def _box_bound(D, a, b, B2, out=None):
    """(*) applied to the box [a, b]; also returns |D| at the centre."""
    m = 0.5 * (a + b)
    r = 0.5 * (b - a)
    val, der, err = D.value_and_deriv(m)
    centre = abs(val)
    ub = centre + abs(der) * r + 0.5 * B2 * r * r + err
    return ub, centre
