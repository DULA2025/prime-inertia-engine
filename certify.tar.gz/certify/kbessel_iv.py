"""Certified enclosures of K_{iR}(x), for the BSV-style existence certificate.

The representation is

    K_{iR}(x) = int_0^infty exp(-x cosh t) cos(R t) dt,                    (1)

and the integrand is analytic and bounded in the strip |Im t| < pi/2.  For a
function analytic and bounded in a strip of half-width a, the trapezoidal rule
on the whole line has error bounded by

    E_h  <=  2 M_a / (exp(2 pi a / h) - 1),                                (2)

with M_a the sup of |g| on the strip.  Here a = pi/2, so the error decays like
exp(-pi^2 / h): at h = 0.05 that is exp(-197), far below any precision we will
ask for.  (1) is even in t, so the half-line integral is the half-line
trapezoid with the endpoint halved.

Everything below returns an INTERVAL that provably contains the true value.
Three error sources are carried separately and all of them are bounded, never
estimated:

  * truncation of the t-range at T, bounded by the tail integral;
  * the trapezoidal discretisation, bounded by (2);
  * floating-point arithmetic, carried by mpmath's interval type.

Validated against mpmath.besselk at 30 digits in the self-test.
"""

from mpmath import mp, iv, mpf, besselk, mpc
import math

mp.dps = 40
iv.dps = 40


def _cosh_iv(t):
    """cosh on intervals, built from iv.exp (mpmath's iv context has no cosh)."""
    e = iv.exp(t)
    return (e + 1 / e) / 2


def _strip_bound(R):
    """Sup of |exp(-x cosh t) cos(R t)| on |Im t| <= a for a slightly under pi/2.

    At t = u + i v with |v| < pi/2, cosh t = cosh u cos v + i sinh u sin v, so
    Re cosh t = cosh u cos v >= 0 and |exp(-x cosh t)| <= 1 for x > 0.
    |cos(R t)| <= cosh(R v) <= cosh(R pi / 2).
    So M_a <= cosh(R pi / 2), independent of x.
    """
    return _cosh_iv(iv.mpf(R) * iv.pi / 2)


def _quad_error(R, h, a_frac=0.98):
    """Bound (2) on the trapezoidal error, with the strip half-width shaved to
    a_frac * pi/2 so the sup bound is attained strictly inside."""
    a = iv.pi / 2 * iv.mpf(a_frac)
    M = _strip_bound(R * a_frac)
    denom = iv.exp(2 * iv.pi * a / iv.mpf(h)) - 1
    return 2 * M / denom


def _tail_error(x, T):
    """Bound on int_T^infty exp(-x cosh t) |cos(R t)| dt.

    For t >= T, cosh t >= cosh T and cosh t >= e^t / 2, so

        int_T^infty exp(-x cosh t) dt <= int_T^infty exp(-x e^t / 2) dt
                                       = E_1(x e^T / 2) <= exp(-x e^T / 2) / (x e^T / 2).

    |cos(Rt)| <= 1 for real t, which is all we need here.
    """
    u = iv.mpf(x) * iv.exp(iv.mpf(T)) / 2
    if u.a > 700:
        return iv.mpf([0, 1]) * iv.mpf('1e-300')
    return iv.exp(-u) / u


def kbessel_iv(R, x, h=None, T=None):
    """Interval enclosing K_{iR}(x) for real R >= 0 and real x > 0.

    Defaults adapt T to x so the tail is below 1e-40 and h so the
    discretisation error is below 1e-40.
    """
    x = iv.mpf(x)
    if x.a <= 0:
        raise ValueError("x must be positive")
    if T is None:
        # need x e^T / 2 >= 100  ->  T = log(200 / x)
        T = max(1.0, math.log(200.0 / float(x.a)) + 1.0)
    if h is None:
        h = 0.05  # error ~ exp(-pi^2/0.05) = exp(-197)
    n = int(math.ceil(T / h))
    acc = iv.mpf(0)
    Rv = iv.mpf(R)
    for k in range(n + 1):
        t = iv.mpf(h) * k
        w = iv.mpf(h) * (iv.mpf('0.5') if k == 0 else iv.mpf(1))
        acc += w * iv.exp(-x * _cosh_iv(t)) * iv.cos(Rv * t)
    err = _quad_error(R, h) + _tail_error(x, T)
    return acc + iv.mpf([-1, 1]) * err


def kbessel_scaled_iv(R, x):
    """sqrt(x) K_{iR}(x) -- the Whittaker normalisation W_{iR}."""
    return iv.sqrt(iv.mpf(x)) * kbessel_iv(R, x)


# --------------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 72)
    print("Certified K-Bessel: enclosures against mpmath at 40 digits")
    print("=" * 72)
    print("  the interval must CONTAIN the true value, and be tight")
    print()
    print("  %-8s %-14s %-26s %-12s" % ("R", "x", "enclosure width", "contains?"))
    bad = 0
    for R in (0.0, 0.0005, 0.115, 0.243, 1.0):
        for x in ('2.7e-3', '0.01', '1.0', '7.0', '25.0', '43.0'):
            iv_val = kbessel_iv(R, x)
            true = besselk(mpc(0, R), mpf(x)).real
            ok = (iv_val.a <= true <= iv_val.b)
            w = float(iv_val.b - iv_val.a)
            if not ok:
                bad += 1
            print("  %-8s %-14s %-26.3e %-12s" % (R, x, w, "yes" if ok else "NO"))
    print()
    print("  failures:", bad)
    print()
    print("  error budget at x = 2.7e-3, R = 0:")
    print("    trapezoid  <= %.3e" % float(_quad_error(0.0, 0.05).b))
    T = math.log(200.0 / 2.7e-3) + 1.0
    print("    tail (T=%.2f) <= %.3e" % (T, float(_tail_error(2.7e-3, T).b)))
