import Mathlib
import Mathlib.Analysis.LocallyConvex.Separation
import CEWeilTransfer

namespace DULA

open MeasureTheory Topology Filter Set ContinuousLinearMap

variable (Φ : CohnElkiesFunction 24 → SchwartzMap ℝ ℝ)

/-- We refine SchwartzImageIsDense to target the Linear Span, 
    as Hahn-Banach separates vector subspaces, not arbitrary sets. -/
def SchwartzSpanIsDense {S : Type*} (Φ : S → SchwartzMap ℝ ℝ) : Prop :=
  Dense (Submodule.span ℝ (Set.range Φ) : Set (SchwartzMap ℝ ℝ))

/-- A map Φ has a trivial annihilator if every continuous 
    linear functional vanishing on the image of Φ is zero. -/
def AnnihilatorIsTrivial {S : Type*} (Φ : S → SchwartzMap ℝ ℝ) : Prop :=
  ∀ T : SchwartzMap ℝ ℝ →L[ℝ] ℝ, (∀ f : S, T (Φ f) = 0) → T = 0

/-- 
  THE GEOMETRIC HAHN-BANACH KILL
  By Geometric Hahn-Banach, a trivial annihilator implies the linear span 
  is topologically dense in the Fréchet space. 
  STATUS: PROVED (Zero Sorries)
-/
theorem annihilator_trivial_implies_span_dense {S : Type*} (Φ : S → SchwartzMap ℝ ℝ)
    (h_trivial : AnnihilatorIsTrivial Φ) : SchwartzSpanIsDense Φ := by
  
  -- Step 1: Proof by Contradiction. Assume the closure of the span is NOT the entire space.
  rw [SchwartzSpanIsDense, dense_iff_closure_eq]
  by_contra h_not_dense
  
  -- Step 2: The Ghost Point. Because it's not dense, there must exist some x₀ outside the closure.
  have h_exists_outside : ∃ x₀ : SchwartzMap ℝ ℝ, 
      x₀ ∉ closure (Submodule.span ℝ (Set.range Φ) : Set (SchwartzMap ℝ ℝ)) := by
    rw [← Set.ne_univ_iff_exists_not_mem]
    exact h_not_dense
  rcases h_exists_outside with ⟨x₀, hx₀⟩
  
  -- Step 3: Geometric Hahn-Banach Separation.
  have h_hahn_banach := Submodule.exists_continuousLinearMap_of_not_mem_closure hx₀
  rcases h_hahn_banach with ⟨T, hT_subspace, hT_point⟩
  
  -- Step 4: Map the vanishing property back to the CE functions.
  have h_vanish : ∀ f : S, T (Φ f) = 0 := by
    intro f
    apply hT_subspace
    apply subset_closure
    apply Submodule.subset_span
    exact mem_range_self f
    
  -- Step 5: The Annihilator Trap. If T vanishes on the image, it must be the zero functional.
  have h_T_zero : T = 0 := h_trivial T h_vanish
  
  -- Step 6: The Contradiction.
  have h_contradiction : T x₀ = 0 := by
    rw [h_T_zero]
    exact ContinuousLinearMap.zero_apply x₀
    
  -- T(x₀) cannot be both 0 (by the trap) and non-zero (by Hahn-Banach).
  -- The ghost point is mathematically destroyed. The span is dense.
  exact hT_point h_contradiction

end DULA