# Over Q: the Galois series of rho, tested directly on Gamma_0(1951) (20 October 2026)

Author: Dula.

`maass_q_isolate.py` builds F(z) = sqrt(y) sum_n a_n K_0(2 pi n y) sin(2 pi n x) from the Dirichlet coefficients a_n of
L(rho, s) (trace table of the note, n <= 40000; no linear solve, so independent of Hejhal's method). It tests
F(gamma z) = chi(d) F(z) at 24 random gamma in Gamma_0(1951), with z and gamma z at height about 1/1951. Output:
`maass_q_isolate.log`, `maass_q_isolate.json`. [N]

- rho, nebentypus chi: largest relative defect 1.7e-10.
- rho'' = rho0'' (x) chi (sqrt5-conjugate traces, a_1951 = zeta5^4), nebentypus chi^2: 1.1e-10.
- Controls: rho with conj(chi) 1.9; rho'' with chi 1.9; rho as an even (cosine) series 12; traces shifted to the
  next prime 3.9.
- Eigenvalue: K_{ir}(x) = K_0(x) - (r^2/2) K2(x) + O(r^4) with K2(x) = int_0^oo exp(-x cosh t) t^2 dt. The value
  2 D0/D2 of r^2 that would cancel the defect at each gamma is below 3.8e-11 (real part) and 2.5e-11 (imaginary
  part); |D2|/|F| is about 18. So, to first order, the series is automorphic only at eigenvalues within about
  4e-11 of 1/4.

None of this proves anything about L(rho, s); it is a consistency check that does not use Hejhal's method.
