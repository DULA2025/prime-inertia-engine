"""Direction 1 of the relayed list, done numerically and independently of Hejhal's method: the Galois series of rho over Q,

  F_r(z) = sqrt(y) sum_n a_n K_{ir}(2 pi n y) sin(2 pi n x),     a_n = Dirichlet coefficients of L(rho, s),

built from the trace table alone (no linear solve), tested for F_r(gamma z) = chi(d) F_r(z) on Gamma_0(1951) at 24 random
gamma, with z and gamma z at height ~ 1/1951 (rho(c) = -I, so the form is odd: sine series).
Eigenvalue isolation: K_{ir}(x) = K_0(x) - (r^2/2) K2(x) + O(r^4), K2(x) = int_0^oo exp(-x cosh t) t^2 dt, so the defect
is D0(gamma) - (r^2/2) D2(gamma); the value of r^2 that would cancel it is 2 D0/D2.  If the series is automorphic exactly
at lambda = 1/4 + r^2 with r = 0, these values are at the noise level of D0.
Also: the sqrt5-conjugate rho'' = rho0'' (x) chi (traces sigma(a_p), nebentypus chi^2, a_1951 = zeta5^4), and controls.
Author: Dula."""
import json, numpy as np, time
from scipy.special import k0
B = "/home/claude/research/bianchi/"
PHI = (1 + 5 ** 0.5) / 2
T = np.array([2, -2, -1, 1, 0, PHI - 1, -PHI, 1 - PHI, PHI])
SIGMA_CODE = {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 6, 6: 5, 7: 8, 8: 7}        # sigma: phi <-> 1 - phi
OLD = json.load(open("/mnt/user-data/outputs/galois1951/galois_traces_150000.json"))
N0, M = 1951, 40000
d = np.load(B + "chunks/codes_000.npz"); P = d["p"]; Cc = d["c"].astype(np.int64)
m = P <= M; P, Cc = P[m], Cc[m]
for i in np.where(Cc < 0)[0]:
    q = int(P[i])
    if q != N0: Cc[i] = [k for k in range(9) if abs(T[k] - OLD["t"][str(q)]) < 1e-9][0]
dl = np.full(N0, -1, dtype=np.int64); x = 1
for k in range(N0 - 1): dl[x] = k % 5; x = x * 3 % N0
z5 = np.exp(2j * np.pi * np.arange(5) / 5)
def chi_pow(n, k): return z5[(2 * k * dl[n % N0]) % 5]
spf = np.zeros(M + 1, dtype=np.int64)
for q in P.tolist():
    sl = spf[q::q]; sl[sl == 0] = q

def coeffs(kind, shuffle=False):
    """kind 'rho': a_p = chi(p)^3 t_p, nebentypus chi, a_1951 = zeta5^2; kind 'rho2': sigma-conjugate (chi^2)."""
    ap = {}; plist = [q for q in P.tolist() if q != N0]
    src = {q: plist[(i + 1) % len(plist)] for i, q in enumerate(plist)} if shuffle else {q: q for q in plist}
    for q, c in zip(P.tolist(), Cc.tolist()):
        if q == N0: continue
        cq = dict(zip(P.tolist(), Cc.tolist()))[src[q]] if shuffle else c
        if kind == "rho": ap[q] = chi_pow(q, 1) ** 3 * T[cq] if False else z5[(3 * 2 * dl[q % N0]) % 5] * T[cq]
        else: ap[q] = z5[(2 * 2 * dl[q % N0] * 3) % 5] * T[SIGMA_CODE[cq]]
    nebk = 1 if kind == "rho" else 2
    a1951 = z5[2] if kind == "rho" else z5[4]
    a = np.zeros(M + 1, dtype=complex); a[1] = 1
    for n in range(2, M + 1):
        q = spf[n]; r = n; e = 0
        while r % q == 0: r //= q; e += 1
        if r > 1: a[n] = a[q ** e] * a[r]; continue
        if q == N0: a[n] = a1951 ** e; continue
        w = chi_pow(q, nebk)
        h0, h1 = 1.0 + 0j, ap[q]
        for _ in range(e - 1): h0, h1 = h1, ap[q] * h1 - w * h0
        a[n] = h1
    return a

# sanity: a_p for rho is chi(p)^3 t_p with chi(p) = zeta5^(2 dl(p)); for rho'' it is sigma(a_p) = chi(p)^6 sigma(t_p) = chi(p) sigma(t_p)
def K2(xv):
    out = np.empty_like(xv)
    for i0 in range(0, xv.size, 20000):
        xx = xv[i0:i0 + 20000]
        Tm = np.arccosh(1 + 45 / xx)
        t = np.linspace(0, 1, 801)[None, :] * Tm[:, None]
        f = np.exp(-xx[:, None] * np.cosh(t)) * t ** 2
        out[i0:i0 + 20000] = np.trapezoid(f, t, axis=1)
    return out

rng = np.random.default_rng(11); tests = []
while len(tests) < 24:
    dd = int(rng.integers(2, N0 - 1)); aa = pow(dd, -1, N0); b = (aa * dd - 1) // N0
    z = complex(-dd / N0 + rng.uniform(-3e-4, 3e-4), 1 / N0 * rng.uniform(0.8, 1.25))
    tests.append((dd, z, (aa * z + b) / (N0 * z + dd)))
n = np.arange(1, M + 1)
def series(a, z, kern="k0", parity="odd"):
    xx, y = z.real, z.imag; keep = 2 * np.pi * n * y < 60; nn = n[keep]; u = 2 * np.pi * nn * y
    kv = k0(u) if kern == "k0" else K2(u)
    trig = np.sin(2 * np.pi * nn * xx) if parity == "odd" else np.cos(2 * np.pi * nn * xx)
    return np.sqrt(y) * np.sum(a[1:][keep] * kv * trig)
t0 = time.time()
A = {"rho": coeffs("rho"), "rho''": coeffs("rho2"), "rho, traces shuffled": coeffs("rho", shuffle=True)}
print("coefficients: %.0fs; a_2, a_3 of rho: %s %s; of rho'': %s %s" % (time.time() - t0, A["rho"][2], A["rho"][3], A["rho''"][2], A["rho''"][3]), flush=True)
res = {"M": M, "n_gamma": len(tests), "cases": {}}
def run(label, a, nebk, parity="odd", conj=False):
    out = []
    for dd, z, gz in tests:
        nu = chi_pow(dd, nebk); nu = np.conj(nu) if conj else nu
        fz, fgz = series(a, z, parity=parity), series(a, gz, parity=parity)
        out.append(abs(fgz - nu * fz) / abs(fz))
    res["cases"][label] = out
    print("%-52s max rel defect over %d gamma: %.1e" % (label, len(out), max(out)), flush=True)
run("rho, nebentypus chi", A["rho"], 1)
run("rho'' (sqrt5-conjugate), nebentypus chi^2", A["rho''"], 2)
run("control: rho with nebentypus conj(chi)", A["rho"], 1, conj=True)
run("control: rho'' with nebentypus chi", A["rho''"], 1)
run("control: rho as an even form (cosine series)", A["rho"], 1, parity="even")
run("control: rho with traces shifted to the next prime", A["rho, traces shuffled"], 1)
# eigenvalue isolation
r2 = []
for dd, z, gz in tests:
    nu = chi_pow(dd, 1)
    D0 = series(A["rho"], gz) - nu * series(A["rho"], z)
    D2 = series(A["rho"], gz, kern="K2") - nu * series(A["rho"], z, kern="K2")
    r2.append(2 * D0 / D2)
r2 = np.array(r2)
print("eigenvalue isolation: r^2 = 2 D0/D2 over 24 gamma: max |Re| %.1e, max |Im| %.1e; |D2|/|F| typical %.2f"
      % (np.abs(r2.real).max(), np.abs(r2.imag).max(), np.median([abs(series(A["rho"], gz, kern="K2") - chi_pow(dd, 1) * series(A["rho"], z, kern="K2")) / abs(series(A["rho"], z)) for dd, z, gz in tests[:6]])), flush=True)
res["r2"] = [[float(v.real), float(v.imag)] for v in r2]
json.dump(res, open("maass_q_isolate.json", "w"), indent=1)
print("done %.0fs" % (time.time() - t0))
