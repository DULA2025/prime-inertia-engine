"""Mod-2 Hecke module at rho-bar in S_2(Gamma0(1951), chi^k) (x) F16, using the 2-SATURATED basis from sat.py.

T_p on q-expansions mod 2 (weight 2, p odd prime to 1951):  (T_p f)_n = f_{pn} + chibar^k(p) f_{n/p};   T_2 = U_2: (T_2 f)_n = f_{2n}.
Known for n <= NB/p.  Since NB/p >= 342 > Sturm bound 326 for p <= 7, the coordinates of T_p B_i in the basis are uniquely
determined by the first 326 coefficients, and the remaining coefficients up to NB/p are an independent consistency check.
Outputs: joint eigenspaces and generalised eigenspaces at the rho-bar eigenvalues, the T_2 action there, commutation checks.
Author: Dula."""
import json, numpy as np
exec(open("/home/claude/research/mod2/brute40np.py").read().split("N = 1951")[0])
N = 1951; NB = 2400; STURM = 326; PHI = (1 + 5 ** .5) / 2
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
VEC = {"2": [2, 0, 0, 0, 0], "-2": [-2, 0, 0, 0, 0], "0": [0] * 5, "1": [1, 0, 0, 0, 0], "-1": [-1, 0, 0, 0, 0],
       "phi": [1, 1, 0, 0, 1], "-phi": [-1, -1, 0, 0, -1], "phi-1": [0, 1, 0, 0, 1], "1-phi": [0, -1, 0, 0, -1]}
SIG = {"2": "2", "-2": "-2", "0": "0", "1": "1", "-1": "-1", "phi": "1-phi", "-phi": "phi-1", "phi-1": "-phi", "1-phi": "phi"}
def label(t):
    for val, s in ((PHI, "phi"), (-PHI, "-phi"), (PHI - 1, "phi-1"), (1 - PHI, "1-phi")):
        if abs(t - val) < 1e-9: return s
    return str(int(round(t)))
dl = {}; x = 1
for k in range(N - 1): dl[x] = k; x = x * 3 % N
def f16(vec, shift):
    acc = [0] * 5
    for i, c in enumerate(vec): acc[(i + shift) % 5] += c
    r = 0
    for i, c in enumerate(acc):
        if c % 2: r ^= POW[i]
    return r
def solve_left(A, Y):
    """X with X A = Y over F16; A (d x m) of rank d.  Gaussian elimination on [A^T | Y^T]."""
    d, m = A.shape
    M = np.concatenate([A.T, Y.T], axis=1).copy(); R = 0; piv = []
    for col in range(d):
        nz = np.nonzero(M[R:, col])[0]
        assert len(nz), "rank deficient"
        pr = R + nz[0]
        if pr != R: M[[R, pr]] = M[[pr, R]]
        M[R] = MUL[INV[M[R, col]], M[R]]
        f = M[:, col].copy(); f[R] = 0; rows = np.nonzero(f)[0]
        if len(rows): M[rows] ^= MUL[f[rows][:, None], M[R][None, :]]
        R += 1
    assert not M[d:, :d].any()
    return M[:d, d:].T.copy()          # X (Y.shape[0] x d)
def rank(A): return A.shape[1] - len(rref_kernel(A))
def minus_scalar(C, lam):
    C = C.copy(); C[np.arange(len(C)), np.arange(len(C))] ^= lam; return C
def kernel_rows(mats):
    """{c : c M = 0 for all M}  (row-vector convention: form = c . basis)."""
    return rref_kernel(np.concatenate([M.T for M in mats], axis=0))
def mpow(A, e):
    R = np.zeros_like(A); R[np.arange(len(A)), np.arange(len(A))] = 1; B = A.copy()
    while e:
        if e & 1: R = matmul(R, B)
        B = matmul(B, B); e >>= 1
    return R
out = {}
for k, conj, a in ((1, "rho0", 3), (2, "rho0''", 1)):
    Bm = np.load("/home/claude/research/mod2/basis_mod2_sat_k%d_%d.npy" % (k, NB)); d = len(Bm)
    chik = lambda p: POW[(2 * k * dl[p % N]) % 5]
    def abar(p):
        s = label(D["t"][str(p)]); s = SIG[s] if conj == "rho0''" else s
        return f16(VEC[s], 2 * a * dl[p % N])
    a2 = abar(2); c2 = chik(2); roots = [r for r in range(16) if MUL[r, r] ^ MUL[a2, r] ^ c2 == 0]
    C = {}; consist = {}
    for p in (2, 3, 5, 7):
        L = NB // p
        TB = np.zeros((d, L), np.uint8)
        for n in range(1, L + 1):
            col = Bm[:, p * n - 1].copy()
            if p != 2 and n % p == 0: col ^= MUL[chik(p), Bm[:, n // p - 1]]
            TB[:, n - 1] = col
        X = solve_left(Bm[:, :STURM], TB[:, :STURM])
        consist[p] = bool((matmul(X, Bm[:, :L]) == TB).all())       # coefficients STURM < n <= NB/p: independent check
        C[p] = X
    comm = {"%d,%d" % (p, q): bool((matmul(C[p], C[q]) == matmul(C[q], C[p])).all()) for p in C for q in C if p < q}
    lam = {p: abar(p) for p in (3, 5, 7)}
    res = dict(consistency=consist, commute=comm, roots=roots, eig={})
    # eigenspaces for growing sets of odd operators
    acc = []
    for p in (3, 5, 7):
        acc.append(minus_scalar(C[p], lam[p]))
        Kp = kernel_rows(acc)
        res["eig"]["T3..T%d" % p] = len(Kp)
    Eodd = kernel_rows(acc)                                    # joint eigenspace of T3, T5, T7
    # generalised joint eigenspace of T3, T5, T7
    gen = kernel_rows([mpow(M, d) for M in acc]); res["gen_T3T5T7"] = len(gen)
    for al in roots:
        Ka = kernel_rows(acc + [minus_scalar(C[2], al)])
        res["eig"]["T3,T5,T7 + T2=%d" % al] = len(Ka)
        Kg = kernel_rows([mpow(M, d) for M in acc] + [mpow(minus_scalar(C[2], al), d)])
        res["eig"]["generalised, T2=%d" % al] = len(Kg)
    # T2 restricted to Eodd: is Eodd T2-stable, and what is the char. poly there?
    if len(Eodd):
        img = matmul(Eodd, C[2])                               # rows: (c T2) for c in Eodd
        co = solve_left(np.concatenate([Eodd, np.eye(d, dtype=np.uint8)[:0]], axis=0)[:, :], img) if False else None
        stable = rank(np.concatenate([Eodd, img], axis=0).T) == len(Eodd)
        res["Eodd_T2_stable"] = bool(stable)
    # does the predicted q-expansion (alpha-normalised) match the eigenvector found, up to NB?
    out["chi^%d" % k] = res
    print("k=%d (%s x chi^%d):" % (k, conj, a), json.dumps(res), flush=True)
json.dump(out, open("/home/claude/research/mod2/hecke2.json", "w"), indent=1)
