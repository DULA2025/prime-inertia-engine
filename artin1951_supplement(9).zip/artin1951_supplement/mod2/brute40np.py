"""All 40 candidate mod-2 eigensystems vs T_p mod 2 on S_2(Gamma0(1951), chi_PARI); numpy F_16 arithmetic.
F_16 = F_2[z]/(z^4+z^3+z^2+z+1); elements 0..15 as bit-vectors in the basis 1, z, z^2, z^3.  Author: Dula."""
import json, os, numpy as np
MOD = 0b11111
def mul_s(a, b):
    r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a & 0b10000: a ^= MOD
    return r
MUL = np.array([[mul_s(a, b) for b in range(16)] for a in range(16)], dtype=np.uint8)
INV = np.zeros(16, np.uint8)
for a in range(1, 16): INV[a] = next(b for b in range(1, 16) if MUL[a, b] == 1)
POW = [1]
for _ in range(20): POW.append(int(MUL[POW[-1], 2]))
def rref_kernel(A):
    A = A.copy(); n_rows, n = A.shape; piv = []; R = 0
    for col in range(n):
        nz = np.nonzero(A[R:, col])[0]
        if len(nz) == 0: continue
        pr = R + nz[0]
        if pr != R: A[[R, pr]] = A[[pr, R]]
        A[R] = MUL[INV[A[R, col]], A[R]]
        f = A[:, col].copy(); f[R] = 0
        rows = np.nonzero(f)[0]
        if len(rows): A[rows] ^= MUL[f[rows][:, None], A[R][None, :]]
        piv.append(col); R += 1
        if R == n_rows: break
    free = [c for c in range(n) if c not in set(piv)]
    K = np.zeros((len(free), n), np.uint8)
    for t, fc in enumerate(free):
        K[t, fc] = 1
        for r, pc in enumerate(piv): K[t, pc] = A[r, fc]
    return K
def matmul(A, B):     # A (r x s), B (s x t) over F16
    out = np.zeros((A.shape[0], B.shape[1]), np.uint8)
    for k in range(A.shape[1]):
        out ^= MUL[A[:, k][:, None], B[k][None, :]]
    return out
def elt(coeffs, m):
    r = 0
    for i, c in enumerate(coeffs):
        if c % 2: r ^= POW[(m * i) % 5]
    return r
N = 1951; PHI = (1 + 5 ** .5) / 2
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
VEC = {"2": [2, 0, 0, 0, 0], "-2": [-2, 0, 0, 0, 0], "0": [0] * 5, "1": [1, 0, 0, 0, 0], "-1": [-1, 0, 0, 0, 0],
       "phi": [1, 1, 0, 0, 1], "-phi": [-1, -1, 0, 0, -1], "phi-1": [0, 1, 0, 0, 1], "1-phi": [0, -1, 0, 0, -1]}
SIG = {"2": "2", "-2": "-2", "0": "0", "1": "1", "-1": "-1", "phi": "1-phi", "-phi": "phi-1", "phi-1": "-phi", "1-phi": "phi"}
def label(t):
    for val, s in ((PHI, "phi"), (-PHI, "-phi"), (PHI - 1, "phi-1"), (1 - PHI, "1-phi")):
        if abs(t - val) < 1e-9: return s
    return str(int(round(t)))
dl = {}; x = 1
for k in range(N - 1): dl[x] = k; x = x * 3 % N
primes = [p for p in (3, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47) if os.path.exists("T%d.json" % p)]
Ts = {}
for p in primes:
    J = json.load(open("T%d.json" % p))
    Ts[p] = np.array([[elt(J[i][j], 1) for j in range(161)] for i in range(161)], np.uint8)
print("primes:", primes, flush=True)
found = []
for conj in ("rho0", "rho0''"):
    for a in range(5):
        for m in (1, 2, 3, 4):
            basis = None; trace = []
            for p in primes:
                s = label(D["t"][str(p)]); s = SIG[s] if conj == "rho0''" else s
                e = (a * 2 * dl[p % N]) % 5
                acc = [0] * 5
                for i, c in enumerate(VEC[s]): acc[(i + e) % 5] += c
                ab = 0
                for i, c in enumerate(acc):
                    if c % 2: ab ^= POW[(m * i) % 5]
                A = Ts[p].copy(); A[np.arange(161), np.arange(161)] ^= ab
                if basis is None:
                    basis = rref_kernel(A)
                else:
                    if len(basis) == 0: trace.append(0); continue
                    C = matmul(A, basis.T)                       # 161 x k : images of basis vectors
                    sol = rref_kernel(C)                         # combinations killed by A
                    basis = matmul(sol, basis) if len(sol) else np.zeros((0, 161), np.uint8)
                trace.append(len(basis))
            if trace[0] > 0: print("%-7s chi^%d zeta->z^%d : common kernel dims %s" % (conj, a, m, trace), flush=True)
            if trace[-1] > 0: found.append((conj, a, m, trace))
print("SURVIVORS (common eigenvector at all primes):", found, flush=True)
json.dump(found, open("brute40.json", "w"))
