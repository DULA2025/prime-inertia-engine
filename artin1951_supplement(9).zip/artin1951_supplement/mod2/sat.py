"""Saturate the 2-adic lattice of S_2(Gamma0(1951), chi^k) before testing mod-2 membership.

Why: PARI's mfbasis has integral q-expansions, but its reduction mod 2 has rank 153 < 161, so it spans only part of the
mod-2 space.  A positive membership test was valid; negative ones (wrong Frob_2 root, sqrt5-conjugate, shuffled) were
only tests against that 153-dim part.  Here: repeatedly take a mod-2 relation sum c_i B_i = 0, lift it to Z[zeta5],
divide by 2 (legal by Sturm: the sum vanishes mod 2 to n = 2400 > 326), and replace one basis row, until the reduction
has rank 161.  Then redo every test in the full mod-2 space.
(The odd-character space S_2(chi^k * eps_1951) is 0 in weight 2, so this is the whole chi-bar part of S_2(Gamma1(1951)) mod 2.)
Author: Dula."""
import json, sys, time, os, numpy as np, cypari2
from sympy import factorint
pari = cypari2.Pari(); pari.allocatemem(5 * 10**9)
exec(open("brute40np.py").read().split("N = 1951")[0])
NB = int(sys.argv[1]) if len(sys.argv) > 1 else 2400
N = 1951; PHI = (1 + 5 ** .5) / 2; PREC = 56; P = 2 ** PREC
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
VEC = {"2": [2, 0, 0, 0, 0], "-2": [-2, 0, 0, 0, 0], "0": [0] * 5, "1": [1, 0, 0, 0, 0], "-1": [-1, 0, 0, 0, 0],
       "phi": [1, 1, 0, 0, 1], "-phi": [-1, -1, 0, 0, -1], "phi-1": [0, 1, 0, 0, 1], "1-phi": [0, -1, 0, 0, -1]}
SIG = {"2": "2", "-2": "-2", "0": "0", "1": "1", "-1": "-1", "phi": "1-phi", "-phi": "phi-1", "phi-1": "-phi", "1-phi": "phi"}
def label(t):
    for val, s in ((PHI, "phi"), (-PHI, "-phi"), (PHI - 1, "phi-1"), (1 - PHI, "1-phi")):
        if abs(t - val) < 1e-9: return s
    return str(int(round(t)))
dl = {}; x = 1
for k in range(N - 1): dl[x] = k; x = x * 3 % N
def f16(vec, shift):
    acc = [0] * 5
    for i, c in enumerate(vec): acc[(i + shift) % 5] += c
    r = 0
    for i, c in enumerate(acc):
        if c % 2: r ^= POW[i]
    return r
mulf = lambda a, b: int(MUL[a, b])
G = pari.znstar(N, 1)
conv = pari("(v)->vector(#v,j, my(P=lift(v[j])); if(type(P)!=\"t_POL\",[P,0,0,0], vector(4,k,polcoef(P,k-1,variable(P)))))")
def rank(M): return M.shape[0] - len(rref_kernel(M.T.copy()))
def red2(R):                                   # (d, NB, 4) ints -> (d, NB) F16 bit-codes (z^j = bit j for j < 4)
    b = (R & 1).astype(np.uint8)
    return b[..., 0] | (b[..., 1] << 1) | (b[..., 2] << 2) | (b[..., 3] << 3)
def zmul(c, B):                                 # c in Z[s]/Phi5 (4 ints), B (NB, 4) -> c*B mod Phi5, mod P
    out = np.zeros((B.shape[0], 5), np.int64)
    for i in range(4):
        if c[i] == 0: continue
        for j in range(4): out[:, (i + j) % 5] += c[i] * B[:, j]
    return (out[:, :4] - out[:, 4:5]) % P
out = {}
for k, conj, a in ((1, "rho0", 3), (2, "rho0''", 1)):
    t0 = time.time(); P = 2 ** PREC
    mf = pari.mfinit([N, 2, pari("(G,c)->[G,[c]]")(G, (780 * k) % 1950)], 1)
    B = pari.mfbasis(mf); d = len(B)
    R = np.zeros((d, NB, 4), np.int64)
    for i in range(d):
        cv = conv(pari.mfcoefs(B[i], NB))
        for n in range(1, NB + 1):
            R[i, n - 1] = [int(cv[n][j]) % P for j in range(4)]
    print("k=%d: %d basis forms read (%.0fs)" % (k, d, time.time() - t0), flush=True)
    prec, rounds = PREC, 0
    while True:
        Bm = red2(R); Kr = rref_kernel(Bm.T.copy())
        print("  round %d: rank mod 2 = %d / %d" % (rounds, d - len(Kr), d), flush=True)
        if len(Kr) == 0: break
        # rref kernel: vector t has a 1 in its own free column and 0 in the other free columns, so all relations can be
        # used at once, each replacing its own free row (a unit coefficient).
        cols = np.nonzero((Kr != 0).sum(axis=0) == 1)[0]
        newrows = {}
        for t in range(len(Kr)):
            c = Kr[t]
            own = [i for i in np.nonzero(c)[0] if i in set(cols.tolist()) and c[i] == 1]
            i0 = int(own[0])
            S = np.zeros((NB, 4), np.int64)
            for i in np.nonzero(c)[0]:
                S = (S + zmul([(int(c[i]) >> j) & 1 for j in range(4)], R[i])) % P
            assert not (S & 1).any(), "relation does not vanish mod 2"
            newrows[i0] = S >> 1
        assert len(newrows) == len(Kr)
        prec -= 1; P = 2 ** prec
        for i0, v in newrows.items(): R[i0] = v
        R %= P; rounds += 1
        assert prec > 8
    Bm = red2(R); rB = rank(Bm)
    chi_k = lambda p: POW[(2 * k * dl[p % N]) % 5]
    def predicted(alpha, mode="true"):
        an = [0] * (NB + 1); an[1] = 1
        ps = [p for p in range(3, NB + 1) if p != N and all(p % q for q in range(2, int(p ** .5) + 1))]
        shuf = {p: ps[(i + 1) % len(ps)] for i, p in enumerate(ps)}
        def ap(p):
            q = shuf[p] if mode == "shuffled" and p in shuf else p
            s = label(D["t"][str(q)])
            if (conj == "rho0''") != (mode == "sigma"): s = SIG[s]
            return f16(VEC[s], 2 * a * dl[p % N])
        cache = {}
        for n in range(2, NB + 1):
            val = 1
            for p, e in factorint(n).items():
                if p == 2:
                    pe = 1
                    for _ in range(e): pe = mulf(pe, alpha)
                elif p == N: pe = 0
                else:
                    if p not in cache: cache[p] = ap(p)
                    cc = chi_k(p); prev, cur = 1, cache[p]
                    for _ in range(e - 1): prev, cur = cur, mulf(cache[p], cur) ^ mulf(cc, prev)
                    pe = cur
                val = mulf(val, pe)
            an[n] = val
        return np.array(an[1:], np.uint8)
    s2 = label(D["t"]["2"]); s2 = SIG[s2] if conj == "rho0''" else s2
    a2 = f16(VEC[s2], 2 * a * dl[2]); c2 = chi_k(2)
    roots = [r for r in range(16) if (mulf(r, r) ^ mulf(a2, r) ^ c2) == 0]
    mask = np.array([n % N != 0 for n in range(1, NB + 1)])
    rm = rank(Bm[:, mask]); res = {}
    for alpha in roots:
        for mode in ("true", "sigma", "shuffled"):
            tgt = predicted(alpha, mode)
            res["alpha=%d,%s" % (alpha, mode)] = bool(rank(np.vstack([Bm[:, mask], tgt[mask][None, :]])) == rm)
    # dimension of the joint (T3,T5,T7) eigen-system: predicted forms agreeing with rho at all n coprime to 2*1951
    out["chi^%d" % k] = dict(system="%s x chi^%d" % (conj, a), dim=d, rank_after=int(rB), rounds=rounds, NB=NB,
                             frob2_roots=roots, tr_frob2=int(a2), results=res)
    print("k=%d (%s x chi^%d): saturated in %d rounds, rank %d/%d, roots of X^2 + %d X + %d: %s  (%.0fs)\n   %s" %
          (k, conj, a, rounds, rB, d, a2, c2, roots, time.time() - t0, res), flush=True)
    np.save("basis_mod2_sat_k%d_%d.npy" % (k, NB), Bm)
json.dump(out, open("sat_%d.json" % NB, "w"), indent=1)
