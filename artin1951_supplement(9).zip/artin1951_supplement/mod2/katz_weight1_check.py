"""Data checks for Theorem D(v) of the note (the weight-one Katz form g1 modulo 2).

Uses the saturated mod-2 bases of S_2(Gamma0(1951), chi) and S_2(Gamma0(1951), chi^2) from sat.py
(basis_mod2_sat_k{1,2}_2400.npy, rows = basis forms, column n-1 = coefficient of q^n as an F16 code)
and the trace table.  F16 = F2[z]/(z^4+z^3+z^2+z+1), codes b0 + 2 b1 + 4 b2 + 8 b3 <-> b0 + b1 z + b2 z^2 + b3 z^3.

With G_x, G_y the two normalised eigenforms of Theorem D(i) (U_2-eigenvalues x = z + z^2 = 6, y = 1 + z^3 = 9):
  H = (x G_x + y G_y)/(x + y) = A g1 has q-expansion g1(q);  W = G_x - G_y = (x + y) V(g1) has q-expansion (x + y) H(q^2).
The proof of D(v) needs W' = sigma(W/(x+y)), a form in S_2(chi-bar^2) with q-expansion H(q)^2.  Check: H(q)^2 lies in the
saturated chi^2 space to n = 2400 (Sturm bound 326), with controls.  Also: the weight-one Hecke relations of g1 at
l = 2, 3, 5, 7, 11, 13, the F16 identities h_j + y h_{j-1} = x^j etc., and that the conjugate system rho0'' x chi gives
sigma(H) (so sigma g1 is its weight-one form, Remark 6.3).  Prints PASS/FAIL.  Author: Dula."""
import json, numpy as np
from sympy import factorint
exec(open("brute40np.py").read().split("N = 1951")[0])          # MUL, INV, POW, rref_kernel (F16 arithmetic)
N = 1951; NB = 2400; PHI = (1 + 5 ** .5) / 2
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
VEC = {"2": [2, 0, 0, 0, 0], "-2": [-2, 0, 0, 0, 0], "0": [0] * 5, "1": [1, 0, 0, 0, 0], "-1": [-1, 0, 0, 0, 0],
       "phi": [1, 1, 0, 0, 1], "-phi": [-1, -1, 0, 0, -1], "phi-1": [0, 1, 0, 0, 1], "1-phi": [0, -1, 0, 0, -1]}
SIG = {"2": "2", "-2": "-2", "0": "0", "1": "1", "-1": "-1", "phi": "1-phi", "-phi": "phi-1", "phi-1": "-phi", "1-phi": "phi"}
def label(t):
    for val, s in ((PHI, "phi"), (-PHI, "-phi"), (PHI - 1, "phi-1"), (1 - PHI, "1-phi")):
        if abs(t - val) < 1e-9: return s
    return str(int(round(t)))
dl = {}; t = 1
for k in range(N - 1): dl[t] = k; t = t * 3 % N
def f16(vec, shift):
    acc = [0] * 5
    for i, c in enumerate(vec): acc[(i + shift) % 5] += c
    r = 0
    for i, c in enumerate(acc):
        if c % 2: r ^= POW[i]
    return r
mul = lambda a, b: int(MUL[a, b]); inv = lambda a: int(INV[a])
sq = lambda a: mul(a, a)
results = []
def check(name, ok):
    results.append(bool(ok)); print("%s  %s" % ("PASS" if ok else "FAIL", name), flush=True)
def rank(M): return M.shape[0] - len(rref_kernel(M.T.copy()))
def inspace(B, v, mask=None):
    if mask is not None: B, v = B[:, mask], v[mask]
    return rank(np.vstack([B, v[None, :]])) == rank(B)

def system(k, a, conj, mode="true"):
    """F16 data of the eigensystem rho0 x chi^a (conj = 'rho0') or rho0'' x chi^a in S_2(chi^k):
    returns (chibar, abar) as functions of the prime p."""
    chik = lambda p: POW[(2 * k * dl[p % N]) % 5]
    def ap(p):
        s = label(D["t"][str(p)])
        if (conj == "rho0''") != (mode == "sigma"): s = SIG[s]
        return f16(VEC[s], 2 * a * dl[p % N])
    return chik, ap
def predicted(alpha, chik, ap):
    an = [0] * (NB + 1); an[1] = 1; cache = {}
    for n in range(2, NB + 1):
        val = 1
        for p, e in factorint(n).items():
            if p == 2:
                pe = 1
                for _ in range(e): pe = mul(pe, alpha)
            elif p == N: pe = 0                                   # never used below for the squares (n <= 1200)
            else:
                if p not in cache: cache[p] = ap(p)
                cc = chik(p); prev, cur = 1, cache[p]
                for _ in range(e - 1): prev, cur = cur, mul(cache[p], cur) ^ mul(cc, prev)
                pe = cur
            val = mul(val, pe)
        an[n] = val
    return np.array(an[1:], np.uint8)
def lincomb(c1, v1, c2, v2): return MUL[c1, v1] ^ MUL[c2, v2]
def square_series(v):                                             # (sum c_n q^n)^2 = sum c_n^2 q^{2n} in char 2
    out = np.zeros(NB, np.uint8)
    for n in range(1, NB // 2 + 1): out[2 * n - 1] = sq(int(v[n - 1]))
    return out

B1 = np.load("basis_mod2_sat_k1_2400.npy"); B2 = np.load("basis_mod2_sat_k2_2400.npy")
check("saturated bases have rank 161 (chi and chi^2 spaces)", rank(B1) == 161 and rank(B2) == 161)
mask = np.array([n % N != 0 for n in range(1, NB + 1)])
x, y = 6, 9
chik, ap = system(1, 3, "rho0")
check("x = z + z^2 and y = 1 + z^3 are the roots of X^2 + abar_2 X + chibar(2)",
      all((sq(r) ^ mul(ap(2), r) ^ chik(2)) == 0 for r in (x, y)) and ap(2) == x ^ y and chik(2) == mul(x, y))
Gx, Gy = predicted(x, chik, ap), predicted(y, chik, ap)
check("G_x and G_y lie in the chi-bar space (n <= 2400, n != 1951)", inspace(B1, Gx, mask) and inspace(B1, Gy, mask))
odd = np.array([n % 2 == 1 for n in range(1, NB + 1)])
check("odd coefficients of G_x and G_y agree", np.array_equal(Gx[odd], Gy[odd]))
s = inv(x ^ y)
H = MUL[s, lincomb(x, Gx, y, Gy)]                                 # H = (x G_x + y G_y)/(x + y) = A g1
W = Gx ^ Gy
Hq2 = np.zeros(NB, np.uint8)
for n in range(1, NB // 2 + 1): Hq2[2 * n - 1] = H[n - 1]
check("W = G_x - G_y has q-expansion (x + y) H(q^2)", np.array_equal(W, MUL[x ^ y, Hq2]))
check("H = A g1 lies in the chi-bar space", inspace(B1, H, mask))
# h_j identities in F16
h = {-1: 0}; xp, yp = x, y
for j in range(0, 62):
    h[j] = mul(xp ^ yp, s); xp, yp = mul(xp, x), mul(yp, y)  # h_j = (x^{j+1} + y^{j+1})/(x + y)
xj = lambda j: 1 if j == 0 else mul(xj(j - 1), x)
yj = lambda j: 1 if j == 0 else mul(yj(j - 1), y)
check("F16: h_j + y h_{j-1} = x^j, h_j + x h_{j-1} = y^j, h_{j+1} + xy h_{j-1} = (x+y) h_j for 0 <= j <= 60",
      all((h[j] ^ mul(y, h[j - 1])) == xj(j) and (h[j] ^ mul(x, h[j - 1])) == yj(j)
          and (h[j + 1] ^ mul(mul(x, y), h[j - 1])) == mul(x ^ y, h[j]) for j in range(0, 61)))
check("F16: x^2 = 1 + z + z^3 (code 11) and y^2 = 1 + z (code 3)", sq(x) == 11 and sq(y) == 3)
# the key identity behind div H >= div A: H(q)^2 is the q-expansion of a form in S_2(chi-bar^2)
H2 = square_series(H)
check("H(q)^2 lies in the chi-bar^2 space (all n <= 2400; Sturm bound 326)", inspace(B2, H2))
check("control: H(q) itself does not lie in the chi-bar^2 space", not inspace(B2, H))
check("control: H(q)^2 does not lie in the chi-bar space", not inspace(B1, H2, mask))
for mode in ("sigma",):
    ck, apc = system(1, 3, "rho0", mode)
    a2c = apc(2); rts = [r for r in range(16) if (sq(r) ^ mul(a2c, r) ^ ck(2)) == 0]
    if len(rts) == 2:
        Gc1, Gc2 = predicted(rts[0], ck, apc), predicted(rts[1], ck, apc)
        Hc = MUL[inv(rts[0] ^ rts[1]), lincomb(rts[0], Gc1, rts[1], Gc2)]
        check("control: the same construction with sqrt5-conjugate traces gives H_c(q)^2 outside the chi-bar^2 space",
              not inspace(B2, square_series(Hc)))
# weight-one Hecke relations of g1 (q-expansion H): a_{nl} + chibar(l) a_{n/l} = abar_l a_n
def hecke_ok(l):
    al, cl = ap(l) if l != 2 else (x ^ y), chik(l)
    for n in range(1, NB // l + 1):
        lhs = int(H[n * l - 1]) ^ (mul(cl, int(H[n // l - 1])) if n % l == 0 else 0)
        if lhs != mul(al, int(H[n - 1])): return False
    return True
check("g1: a_{nl} + chibar(l) a_{n/l} = abar_l a_n for l = 2, 3, 5, 7, 11, 13 and n <= 2400/l",
      all(hecke_ok(l) for l in (2, 3, 5, 7, 11, 13)))
# Remark 6.3: the conjugate system rho0'' x chi in the chi^2 space gives sigma(H)
chik2, ap2 = system(2, 1, "rho0''")
x2, y2 = sq(x), sq(y)
check("conjugate system: roots of X^2 + abar''_2 X + chibar^2(2) are x^2, y^2",
      all((sq(r) ^ mul(ap2(2), r) ^ chik2(2)) == 0 for r in (x2, y2)))
Gx2, Gy2 = predicted(x2, chik2, ap2), predicted(y2, chik2, ap2)
check("conjugate G''_{x^2}, G''_{y^2} lie in the chi-bar^2 space", inspace(B2, Gx2, mask) and inspace(B2, Gy2, mask))
H2c = MUL[inv(x2 ^ y2), lincomb(x2, Gx2, y2, Gy2)]
check("conjugate H'' = sigma(H) coefficientwise (n <= 2400, n != 1951), so sigma g1 is its weight-one form",
      np.array_equal(H2c[mask], np.array([sq(int(c)) for c in H], np.uint8)[mask]))
print("\n%d of %d checks passed" % (sum(results), len(results)))
