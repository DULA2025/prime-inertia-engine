"""Encoding-free characteristic-0 check that rho-bar (mod 2) occurs in S_2(Gamma0(1951), chi), chi of order 5.

For each prime l, with a_l = tr rho(Frob_l) = t_l * chi(l)^3 in Z[zeta5] (exact):
    D_l = det(a_l I - T_l) = P_l(a_l)   (P_l = characteristic polynomial of T_l; basis-independent; D_l in Z[zeta5]).
If rho-bar occurs in the space mod 2 (2 is inert in Z[zeta5]), then P_l(a_l) = 0 mod 2, i.e. v_2(D_l) >= 1, for EVERY l.
For l = 2: D_2 = det(T_2^2 - a_2 T_2 + chi(2)) = Res(P_2, X^2 - a_2 X + chi(2)), with X^2 - a_2 X + chi(2) the
characteristic polynomial of rho(Frob_2); v_2(D_2) >= 1 iff a root of it is an eigenvalue of T_2 mod 2.
Controls: (A) the trivial-character space S_2(Gamma0(1951)) (dim 162) -- the space the CLI auditor used;
          (B) sqrt5-conjugate traces sigma(t_l) chi(l)^3 in the chi space;  (C) shuffled traces t_{next prime}.
D_l is computed through the four complex embeddings at 600 digits, rounded to Z[zeta5] (coordinates in 1, z, z^2, z^3),
then CHECKED exactly modulo two primes p = 1 mod 5 (determinant over F_p).  v_2(D) = min over coordinates of v_2.
Author: Dula."""
import json, time, cypari2
pari = cypari2.Pari(); pari.allocatemem(4 * 10**9); pari.set_real_precision(600)
N = 1951; G = pari.znstar(N, 1)
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
dl = {}; x = 1
for k in range(N - 1): dl[x] = k; x = x * 3 % N
Z = pari("Mod(t, polcyclo(5,t))"); ONE = pari("Mod(1, polcyclo(5,t))")
PHI = (1 + 5 ** .5) / 2
def tval(tp, sig=False):
    """t_l as an element of Z[zeta5]: phi = 1 + z + z^4; sigma (sqrt5 -> -sqrt5) is z -> z^2."""
    phi = ONE + Z + Z ** 4
    table = ((2, 2 * ONE), (-2, -2 * ONE), (0, 0 * ONE), (1, ONE), (-1, -ONE), (PHI, phi), (-PHI, -phi),
             (PHI - 1, phi - 1), (1 - PHI, 1 - phi))
    for val, e in table:
        if abs(tp - val) < 1e-9:
            if sig: e = pari.subst(pari.lift(e), "t", pari("t^2")) * ONE
            return e
    raise ValueError(tp)
chi = lambda n: Z ** ((2 * dl[n % N]) % 5)
emb = [pari("exp(2*Pi*I*%d/5)" % k) for k in (1, 2, 3, 4)]
V = pari.matrix(4, 4, [emb[j] ** m for j in range(4) for m in range(4)])
Vinv = V ** -1
def evz(a, e): return pari.subst(pari.lift(a), "t", e)
def has_t(M): return "t" in str(pari.variables(pari.lift(M)))
def to_zeta(vals):
    c = Vinv * pari.matrix(4, 1, vals)
    rc = [pari.round(pari.real(c[m, 0])) for m in range(4)]
    err = max(float(pari.abs(c[m, 0] - rc[m])) for m in range(4))
    return [int(r) for r in rc], err
def v2(c):
    vs = [((cc & -cc).bit_length() - 1) for cc in c if cc]
    return min(vs) if vs else None
def run(space, mf, ells, mode):
    out = []
    plist = [int(p) for p in pari.primes([3, 400]) if int(p) != N]
    for l in ells:
        t0 = time.time()
        M = pari.mfheckemat(mf, l); n = len(M); Ml = pari.lift(M); tM = has_t(M)
        q = plist[(plist.index(l) + 1) % len(plist)] if l in plist else 3
        a = tval(D["t"][str(q if mode == "shuffled" else l)], sig=(mode == "sigma")) * chi(l) ** 3
        c2 = chi(2); I = pari.matid(n)
        vals = []
        for e in emb:
            Me = pari.substpol(Ml, "t", e) if tM else Ml * pari("1.0")
            A = (Me * Me - evz(a, e) * Me + evz(c2, e) * I) if l == 2 else (evz(a, e) * I - Me)
            vals.append(pari.matdet(A))
        coords, err = to_zeta(vals)
        checks = []
        for p in (1000000021, 1000000181):
            r = pow(int(pari.znprimroot(p).lift()), (p - 1) // 5, p)
            Mp = pari.Mod(pari.substpol(Ml, "t", r) if tM else Ml, p)
            ap = pari.Mod(pari.subst(pari.lift(a), "t", r), p); cp = pari.Mod(pari.subst(pari.lift(c2), "t", r), p)
            Ap = (Mp * Mp - ap * Mp + cp * I) if l == 2 else (ap * I - Mp)
            dp = int(pari.lift(pari.matdet(Ap)))
            checks.append(dp == sum(c * pow(r, m, p) for m, c in enumerate(coords)) % p)
        row = dict(space=space, mode=mode, l=l, v2=v2(coords), D_is_zero=not any(coords), round_err=err,
                   exact_modp_checks=checks, secs=round(time.time() - t0))
        out.append(row); print(json.dumps(row), flush=True)
    return out
if __name__ == "__main__":
    ells = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    mfc = pari.mfinit([N, 2, pari("(G)->[G,[780]]")(G)], 1)
    mft = pari.mfinit([N, 2, 1], 1)
    print("dims: chi %s, trivial %s" % (pari.mfdim(mfc), pari.mfdim(mft)), flush=True)
    res = []
    res += run("chi (dim 161)", mfc, ells, "true")
    res += run("trivial (dim 162)", mft, ells, "true")
    res += run("chi (dim 161)", mfc, ells, "sigma")
    res += run("chi (dim 161)", mfc, ells, "shuffled")
    json.dump(res, open("/home/claude/research/audit/charp2.json", "w"), indent=1)
    print("done", flush=True)
