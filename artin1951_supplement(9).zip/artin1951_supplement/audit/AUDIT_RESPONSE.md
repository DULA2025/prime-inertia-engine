# Response to the CLI audit (REPORT-2.md)  (Dula, 12 Oct 2026)

The audit's two FAIL verdicts do not stand.
- **Mod-2.** The audit tested the claim in the wrong space and read finite-field labels as integers.
- **Klein curve.** The audit did not have j₀.

Two documentation points on our side were fair and are now fixed:
- the 𝔽₁₆ labels were never decoded;
- the "41" lacked its qualifier.

The three PASS verdicts agree with our results. The audit's "Conditional reduction" printer states a different theorem from ours (see §4).

## 1. Mod-2: the claim lives in S₂(Γ₀(1951), χ), with χ of order 5
### Wrong space
The audit computed in S₂(Γ₀(1951)) with **trivial** character.
- That space has dimension 162. The sign-+ modular symbols have dimension 163, and T₂ factors as 1 + 65 + 97.
- ρ̄ cannot occur there, because det ρ̄ = χ̄ is non-trivial mod 2.

The claim concerns S₂(Γ₀(1951), χ).
- In PARI: `G = znstar(1951,1); mf = mfinit([1951, 2, [G,[780]]], 1)`, with χ(3) = ζ₅².
- `mfdim(mf)` = **161**, which is the rank 161 of our lattice.

### Labels, not integers
The values 6, 9, 3 and 11 are 4-bit codes for elements of 𝔽₁₆ = 𝔽₂[z]/(z⁴+z³+z²+z+1), where z = ζ₅ mod 2.
- The code is b₀ + 2b₁ + 4b₂ + 8b₃ ↔ b₀ + b₁z + b₂z² + b₃z³.
- Decoded: 6 = z + z², 9 = 1 + z³, 3 = 1 + z, 11 = 1 + z + z³.
- They are the two roots, mod 2, of X² − tr ρ(Frob₂)X + χ(2), the characteristic polynomial of ρ(Frob₂).
- They are residues, so Deligne's bound does not apply. A complex eigenvalue such as ζ₅ + ζ₅² has absolute value below 2 and reduces to z + z², which is code 6.

### Encoding-free check (`charp2.py`, `charp2_controls.py`)
This uses only PARI's characteristic-0 Hecke matrices. Let a_ℓ = tr ρ(Frob_ℓ) = t_ℓ·χ(ℓ)³ ∈ ℤ[ζ₅], and set D_ℓ = det(a_ℓ·I − T_ℓ) = P_ℓ(a_ℓ). For ℓ = 2, set D₂ = det(T₂² − a₂T₂ + χ(2)).

**Why this tests the claim.** If ρ̄ occurs in the space mod 2, then every D_ℓ is divisible by 2 (2 is inert in ℤ[ζ₅]).

**How D_ℓ is computed.**
- D_ℓ is evaluated in the four complex embeddings at 600 digits and rounded to ℤ[ζ₅].
- It is then checked **exactly** modulo the primes 1000000021 and 1000000181, both ≡ 1 mod 5. All checks hold.

| space | ℓ = 2 | 3 | 5 | 7 | 11 | 13 | 17 | 19 | 23 | 29 | 31 | 37 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S₂(Γ₀(1951), χ), dim 161 — v₂(D_ℓ) | 6 | 7 | 12 | 6 | 6 | 6 | 8 | 6 | 6 | 7 | 7 | 6 |
| S₂(Γ₀(1951)) trivial, dim 162 (the audit's space) | 0 | 0 | 0 | 10 | 0 | 0 | 0 | 0 | | | | |
| χ-space, √5-conjugate traces (control) | 6 | 0 | 12 | 6 | 0 | 6 | 0 | 0 |  |  |  |  |
| χ-space, shuffled traces (control) | 0 | 0 | 12 | 0 | 0 | 0 | 0 | 0 |  |  |  |  |

**Results.**
- In the χ-space every ℓ ≤ 37 gives v₂ ≥ 6, as the claim predicts.
- In the trivial-character space ρ̄ is absent: v₂ = 0 at 7 of 8 primes, and the single non-zero value at ℓ = 7 is a coincidence.
- **Controls in the χ-space.**
  - √5-conjugate traces give v₂ = 0 exactly where σ changes the trace: the order-5 classes ℓ = 3, 11, 17, 19. Where the trace is rational they match the true values: ℓ = 2, 5, 7, 13.
  - Shuffled traces give v₂ = 0 except at ℓ = 5, where the shuffled trace equals the true one (t = 0).

This is a characteristic-0 confirmation with no 𝔽₁₆ code anywhere. It is necessary-condition evidence prime by prime. The simultaneous eigenform is certified separately, by Sturm in the saturated lattice and by Khare–Wintenberger (`mod2/sat.py`, `mod2/hecke2.py`).

## 2. Klein curve
**j₀.** The audit's repository had no j₀. It is now in `j0_exact.json` as exact integers, with the convention j₀ = (ReA + i·ImA) + (ReB + i·ImB)·√5, F = ℚ[y]/(y⁴+3y²+1), i = y³+2y and √5 = 2y²+3. `klein_export.py` and `cmmod/efg.py` rebuild the integral model and every check from it.

**Counts.** There are **44** primes below 1200 that split completely in F; the audit is right. The **41** in our text are the testable ones:
- 29 and 41 each have a place with v(j₀) = −5 (potentially multiplicative);
- 1069 has j₀ ≡ 0 mod one place above it.

Our wording "41/41 split primes" omitted this, and it now reads "all 41 testable split primes (of 44)".

**Decomposed-generic witnesses.** For E[5] and E[3] they are computed with E's good reduction checked at all four places (`efg.json`, `witness_good_reduction`).

## 3. Quartic experiment
The audit's small search, with coefficients in [−2, 2], found no point on x² + z² = δ. An explicit point exists over K = ℚ(√5, √−3) = ℚ[y]/(y⁴ − 4y² + 64), with √5 = −y³/16 + 3y/4:
- a = 3/50·y³ + 31/100·y² + 29/50·y − 38/25
- b = −7/400·y³ + 17/100·y² − 69/100·y − 41/25

Then a² + b² = δ = −(10 + 2√5), checked exactly. So the order-4 twist ψ exists over K with an explicit certificate.

## 4. Proposition M5 and the reduction
**M5.** The audit's certificates use p = 2 or 3 for several discriminants. They are valid, since the argument only needs some Frobenius element, and they are smaller than ours.

**The printed "Theorem" and "Corollary."** These relabel H1 and H2 as the Caraiani–Newton hypotheses and a lifting theorem; that is not our reduction. In `mod2/PROOF_SKELETON.md`:
- **H1** is automorphy of ρ over F, or in the one-step version over a single imaginary quadratic field;
- **H2** is base change for GL(2) from ℚ (and ℚ(√5)) to the quintic A₄-field L₅;
- Lemmas 3–4 prove that H1 + H2 ⟹ ρ modular.

The printer should quote those statements. None of this proves that L(ρ, s) is entire, and nothing in our files claims that it is.
