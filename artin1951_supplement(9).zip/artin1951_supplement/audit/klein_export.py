"""Export the exact j0 of the Klein curve E/F (F = Q(i, sqrt5)) in a portable form, recount the split primes below 1200
with the reason each one is excluded or tested, and give an explicit norm certificate that (delta, -1) splits over
K = Q(sqrt5, sqrt-3).  Author: Dula."""
import json, pickle, cypari2
pari = cypari2.Pari(); pari.allocatemem(6 * 10**8)
J = pickle.load(open("/home/claude/research/moonshine/j0_exact_600.pkl", "rb"))
exp = {k: [str(J[k][0]), str(J[k][1])] for k in ("Re alpha", "Im alpha", "Re beta", "Im beta")}
exp["convention"] = "j0 = (ReA + i*ImA) + (ReB + i*ImB)*sqrt5, each entry [numerator, denominator]; F = Q[y]/(y^4+3y^2+1), i = y^3+2y, sqrt5 = 2y^2+3"
json.dump(exp, open("/home/claude/research/audit/j0_exact.json", "w"), indent=1)
q = lambda k: pari(J[k][0]) / pari(J[k][1])
F = pari.nfinit("y^4+3*y^2+1")
I_ = pari("Mod(y^3+2*y, y^4+3*y^2+1)"); S5 = pari("Mod(2*y^2+3, y^4+3*y^2+1)")
j0 = (q("Re alpha") + I_ * q("Im alpha")) + (q("Re beta") + I_ * q("Im beta")) * S5
rows = []
for l in map(int, pari.primes([2, 1200])):
    if l % 20 not in (1, 9): continue
    Ps = pari.idealprimedec(F, l); assert len(Ps) == 4 and all(int(P[3]) == 1 for P in Ps)
    vals = [int(pari.nfeltval(F, pari.lift(j0), P)) for P in Ps]
    if min(vals) < 0: rows.append(dict(l=l, status="excluded: v_P(j0) < 0 at a place (potentially multiplicative)", v=vals)); continue
    red = []
    for P in Ps:
        mp = pari.nfmodprinit(F, P); red.append(int(str(pari.nfmodpr(F, pari.lift(j0), mp))) % l)
    if any(r in (0, 1728 % l) for r in red):
        rows.append(dict(l=l, status="excluded: j0 = 0 or 1728 mod a place above l", j0_mod_P=red)); continue
    rows.append(dict(l=l, status="tested", j0_mod_P=red))
tested = [r["l"] for r in rows if r["status"] == "tested"]
print("primes l < 1200 splitting completely in F: %d" % len(rows))
for r in rows:
    if r["status"] != "tested": print("  ", r)
print("tested: %d" % len(tested))
# explicit certificate: delta = x^2 + z^2 over K = Q(sqrt5, sqrt-3)
K = pari.bnfinit("y^4 - 4*y^2 + 64", 1)
r5 = pari.nfroots(K, "x^2-5")[0]
delta = pari.nfbasistoalg(K, -10 - 2 * pari.nfalgtobasis(K, pari.nfbasistoalg(K, r5)))
T = pari.rnfisnorminit(K.nf_get_pol() if hasattr(K, "nf_get_pol") else pari("y^4 - 4*y^2 + 64"), "x^2+1")
sol = pari.rnfisnorm(T, delta)
w = sol[0]; factor = sol[1]
print("rnfisnorm over K = Q(sqrt5, sqrt-3), K(i)/K: delta = N(w) * %s" % factor)
cert = dict(field="y^4 - 4*y^2 + 64", w=str(w), cofactor=str(factor))
if factor == 1:
    Nw = pari("(w)->norm(w)")(w)     # relative norm K(i)/K of w = a + b x (x^2 = -1) is a^2 + b^2
    print("certificate: w =", str(w)[:300])
json.dump(dict(rows=rows, tested=tested, n_split=len(rows), quartic_norm_certificate=cert),
          open("/home/claude/research/audit/klein_counts.json", "w"), indent=1)
