"""Controls for charp2.py, run in parallel: (A) the trivial-character space the CLI auditor used, (B) sqrt5-conjugate traces
and (C) shuffled traces in the chi space.  Same determinant test and exact mod-p checks; Hecke matrices cached per l.
Author: Dula."""
import json, time, sys
sys.argv = ["x"]
import charp2 as C
pari = C.pari
ells = [2, 3, 5, 7, 11, 13, 17, 19]
mfc = pari.mfinit([C.N, 2, pari("(G)->[G,[780]]")(C.G)], 1)
mft = pari.mfinit([C.N, 2, 1], 1)
res = []
res += C.run("trivial (dim 162)", mft, ells, "true")
res += C.run("chi (dim 161)", mfc, ells, "sigma")
res += C.run("chi (dim 161)", mfc, ells, "shuffled")
json.dump(res, open("/home/claude/research/audit/charp2_controls.json", "w"), indent=1)
print("done", flush=True)
