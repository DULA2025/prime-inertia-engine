"""Mod-2 Bianchi classes at levels of index up to several million (sparse_big.py): H^1(Gamma_0(N O_E), F16(eps)) for
PGL_2(O_E), E = Q(sqrt-7), the rbar-part and the pairs (T_v, T_vbar) on it, and the joint eigenvectors in each pair.

Usage:
  python3 run_big.py 1951 [FILL]                 the target: rbar_2 of the even icosahedral rho of conductor 1951
  python3 run_big.py N k CHI_ORDER odd|even A5    a classical newform with projective image A5 (as run_sparse.py),
                                                  e.g. 633 1 10 odd A5 (the model of Buzzard-Lauder)
For 1951 the eigenvalues come from the Galois side (../questions/classes_1951.json; labelling L = 0 of
mod2_general.py, the one that passed in Theorem D): abar_l = psibar(l) tbar(class of Frob_l), psibar(l) = z^(log_g l),
chibar(l) = z^(2 log_g l), g = znstar(1951).gen; (x, y) = (z + z^2, 1 + z^3) = (6, 9).  The level carries eps^-1 o N
with eps = chi (engine convention: Level(eps^-1 o N) realises f in S_2(N, eps) with T_q -> a_q).
Environment: BIG_SEED (default 7), BIG_LW (initial Lanczos block / 64, default 4).  Author: Dula."""
import sys, os, json, time, resource
import numpy as np, cypari2
from sparse_h1 import FastLevel, MUL, INV, matmul16, gen_eigenspace
from bmf import Comp
from o7 import onorm, oconj
from mod2_refine import root as sroot
from sparse_big import BigH1
from lanczos16 import mm as mm16
import gf

def gen_eigenspace_fast(Ts, evs, D):
    """As sparse_h1.gen_eigenspace (kernel of (T - e)^(2^k), 2^k >= D, intersected over the operators), with the
    bitsliced products of lanczos16 for the repeated squaring."""
    V = np.eye(D, dtype=np.uint8)
    for T, e in zip(Ts, evs):
        if V.shape[0] == 0: break
        S = np.array(T, dtype=np.uint8) ^ (MUL[e, 1] * np.eye(D, dtype=np.uint8))
        P = S.copy(); k = 1
        while k < D:
            P = mm16(P, P); k *= 2
        Kk = gf.kernel16(P)
        M = np.vstack([V, Kk]); Kk2 = gf.kernel16(M.T)
        W = matmul16(np.ascontiguousarray(Kk2[:, :V.shape[0]]), V, MUL)
        A = np.array(W, copy=True); piv = gf.rref16(A, MUL, INV); V = A[:len(piv)]
    return V
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
t00 = time.time(); args = sys.argv[1:]
SEED = int(os.environ.get("BIG_SEED", "7")); LW = int(os.environ.get("BIG_LW", "4"))
def ev16(cs, th):
    r = 0; pw = 1
    for c in cs:
        if c: r ^= pw
        pw = int(MUL[pw, th])
    return r
PRS = [int(q) for q in pari("primes([3, 200])")]
# ---------------------------------------------------------------- target data
if args[0] == "1951":
    N = 1951; FILL = float(args[1]) if len(args) > 1 else 8.0; label = "N1951"
    C = {int(k): v for k, v in json.load(open("../questions/classes_1951.json"))["codes"].items()}
    g = int(pari("znstar(1951, 1).gen[1]")); dl = {}; t = 1
    for k in range(N - 1): dl[t] = k; t = t * g % N
    Z = 2; POW = [1]
    for _ in range(10): POW.append(int(MUL[POW[-1], Z]))
    PHI1 = Z ^ POW[4]                       # phi - 1 = z + z^4
    PHI0 = 1 ^ Z ^ POW[4]                   # phi = 1 + z + z^4
    def tbar(code):
        if code in ("1", "2A"): return 0
        if code == "3A": return 1
        return PHI1 if code == "5A" else PHI0
    AP = {l: int(MUL[POW[dl[l] % 5], tbar(C[l])]) for l in PRS if l != N}
    a2 = int(MUL[POW[dl[2] % 5], tbar(C[2])]); c2 = POW[(2 * dl[2]) % 5]
    xy = [r for r in range(16) if (int(MUL[r, r]) ^ int(MUL[a2, r]) ^ c2) == 0]
    assert sorted(xy) == [6, 9], xy
    x, y = 6, 9
    epsinv = np.zeros(N, dtype=np.uint8)
    for a in range(1, N): epsinv[a] = POW[(-2 * dl[a]) % 5]
    uu, vv = np.meshgrid(np.arange(N, dtype=np.int64), np.arange(N, dtype=np.int64), indexing="ij")
    tab = epsinv[(uu * uu + uu * vv + 2 * vv * vv) % N]; tab[0, 0] = 0
    del uu, vv
    comps = [Comp("Fp2", N)]; EC = [tab]
    print("%s: g = %d, abar_2 = %d, chibar(2) = %d, (x, y) = (%d, %d); abar_l for l = 3, 5, 7, 11, 13: %s"
          % (label, g, a2, c2, x, y, [AP[l] for l in (3, 5, 7, 11, 13)]), flush=True)
else:
    N = int(args[0]); k = int(args[1]); o = int(args[2]); par = args[3]; sel = args[4] if len(args) > 4 else "A5"; FILL = 8.0
    NB = 400
    pari("G = znstar(%d, 1); L = chargalois(G); IX = select(i -> charorder(G, L[i]) == %d && zncharisodd(G, L[i]) == %d, [1..#L]);" % (N, o, 1 if par == "odd" else 0))
    found = None
    for ii in range(1, int(pari("#IX")) + 1):
        pari("mf = mfinit([%d, %d, [G, L[IX[%d]]]], 0);" % (N, k, ii))
        if int(pari("mfdim(mf)")) == 0: continue
        pari("B = mfeigenbasis(mf);")
        if sel == "A5":
            pari("ty = mfgaloistype(mf);")
            for j in range(1, int(pari("#B")) + 1):
                if int(pari("ty[%d]" % j)) == -60: found = (ii, j); break
        else:
            found = (ii, int(sel))
        if found: break
    assert found, "no form found"
    ii, j = found
    pari("f = B[%d]; co = mfcoefs(f, %d); cm = mfparams(mf)[3]; Gm = znstar(cm.mod, 1); chm = znconreychar(Gm, cm); "
         "cyc = mfparams(mf)[5]; om = charorder(Gm, chm); P = mffields(mf)[%d];" % (j, NB, j))
    pari("R = rnfequation(cyc, P, 1); Pabs = R[1]; A = lift(R[2]); kk = R[3];")
    pari("toabs(c) = Mod(subst(subst(liftall(c), 'y, 'y - kk * A), 't, A), Pabs);")
    pari("epsv(p) = Mod(t^(chareval(Gm, chm, p) * om), cyc);")
    label = "N%d_k%d_o%d_%s" % (N, k, o, sel)
    pari("nf = nfinit([Pabs, [2]]); dec = idealprimedec(nf, 2);")
    cands = [kk_ for kk_ in range(1, int(pari("#dec")) + 1) if 4 % int(pari("dec[%d].f" % kk_)) == 0 and int(pari("dec[%d].f" % kk_)) > 1]
    pari("modP = nfmodprinit(nf, dec[%d]);" % cands[0])
    pari("rdx(x) = nfmodpr(nf, toabs(x), modP);")
    pari("g0 = rdx(co[3]); gen = ffgen(g0); m = gen.mod;")
    mc = [int(c) % 2 for c in pari("Vecrev(lift(m))")]
    th = [xx for xx in range(16) if ev16(mc, xx) == 0][0]
    def to16(expr):
        if int(pari("type(%s) == \"t_FFELT\"" % expr)):
            return ev16([int(c) % 2 for c in pari("my(z = %s); Vecrev(lift(z.pol))" % expr)], th)
        return ev16([int(pari("lift(%s)" % expr)) % 2], th)
    AP = {p: to16("rdx(co[%d + 1])" % p) for p in PRS if N % p}
    EP2 = to16("rdx(epsv(2))"); a2 = to16("rdx(co[3])")
    if k == 1:
        xy = [xx for xx in range(1, 16) if MUL[xx, xx] ^ MUL[a2, xx] ^ EP2 == 0]
        x, y = (xy[0], xy[1]) if len(xy) == 2 else (xy[0], xy[0])
    else:
        x = a2; y = int(MUL[EP2, INV[a2]])
    def eps_inv_table(q):
        gq0 = int(pari("znprimroot(%d)" % q).lift())
        gq = int(pari("lift(chinese(Mod(%d, %d), Mod(1, %d)))" % (gq0, q, N // q)))
        eg = int(INV[to16("rdx(epsv(%d))" % gq)])
        tabq = {}; cur = 1; acc = 1
        for _ in range(q - 1):
            tabq[cur] = acc; cur = cur * gq0 % q; acc = int(MUL[acc, eg])
        return tabq
    comps = []; EC = []
    for q in [int(q) for q in pari("factor(%d)[,1]~" % N)]:
        kr = int(pari("kronecker(-7, %d)" % q))
        if q == 7: comps.append(Comp("Fp", 7, 4)); EC.append(eps_inv_table(7))
        elif kr == 1:
            for w_ in (0, 1): comps.append(Comp("Fp", q, sroot(q, w_))); EC.append(eps_inv_table(q))
        else:
            comps.append(Comp("Fp2", q)); tq = eps_inv_table(q)
            EC.append({(u, v): tq[(u * u + u * v + 2 * v * v) % q] for u in range(q) for v in range(q) if (u, v) != (0, 0)})
    print("%s: Frob_2 eigenvalues (x, y) = (%d, %d) in F16" % (label, x, y), flush=True)
if os.environ.get("BIG_DRY"):
    print("eigenvalues (abar_l, l <= 79):", {l: AP[l] for l in PRS if l <= 79 and l in AP}); sys.exit(0)
# ---------------------------------------------------------------- Bianchi side
t0 = time.time()
L = FastLevel(comps, EC, name=label)
print("level %d O_E: components %s, index n = %d (%.0fs)" % (N, [(c.typ, c.p) for c in comps], L.n, time.time() - t0), flush=True)
CACHE = os.environ.get("BIG_CACHE") or ("big_cache_%s" % label)   # stages and Hecke matrices, for resuming a run
H = BigH1(L, fill=FILL, verbose=True, seed=SEED - 6, lanczos_w=LW, cache=CACHE)
rng = np.random.default_rng(SEED)
H.quotient_dm(rng)
D = H.d - (1 if H.drop is not None else 0)
print("dim H^1(Gamma_0, F16(eps)) [PGL] = %d%s (%.0fs)" % (D, " (after the quotient by delta m_par)" if H.drop is not None else "", time.time() - t00), flush=True)
def find_pi(p):
    for yy in range(1, 60):
        for xx in range(-120, 120):
            if onorm((xx, yy)) == p: return (xx, yy)
ops = [("v", (0, 1), 2, "split"), ("vbar", (1, -1), 2, "split")]
for q in (3, 5, 13):
    if N % q and int(pari("kronecker(-7, %d)" % q)) == -1: ops.append(("(%d)" % q, (q, 0), q, "inert"))
if N % 7: ops.append(("(sqrt-7)", (-1, 2), 7, "ram"))
for q in (11, 23, 29, 37, 43, 53, 67, 71, 79):
    if N % q: pi = find_pi(q); ops += [("q%d" % q, pi, q, "split"), ("q%dbar" % q, oconj(pi), q, "split")]
Ts = {}
for io, (nm, pi, p, typ) in enumerate(ops):
    t1 = time.time()
    fT = os.path.join(CACHE, "hecke_%s_s%d.npy" % (nm, SEED))
    if os.path.exists(fT): T = np.load(fT)
    else:
        T = H.hecke(pi, np.random.default_rng([SEED, io]))
        assert T is not None, "Hecke matrix inconsistent at %s" % nm
        np.save(fT, T)
    Ts[nm] = (T, p, typ)
    print("  T_%s (%.0fs)" % (nm, time.time() - t1), flush=True)
comm = all((mm16(Ts[a][0], Ts[b][0]) == mm16(Ts[b][0], Ts[a][0])).all() for a in Ts for b in Ts if a < b)
print("Hecke operators: %d, commute: %s (%.0fs)" % (len(Ts), comm, time.time() - t00), flush=True)
def evq(nm):
    T, p, typ = Ts[nm]; a = AP[p]
    return a if typ != "inert" else int(MUL[a, a])
names = [nm for nm in Ts if nm not in ("v", "vbar")]; first = names[:6]; rest = names[6:]
V = gen_eigenspace_fast([Ts[nm][0] for nm in first], [evq(nm) for nm in first], D)
res = {"label": label, "N": N, "n": L.n, "dimH1": D, "x": x, "y": y, "commute": bool(comm), "rbar_dim": int(V.shape[0]),
       "eigenvalues": {nm: evq(nm) for nm in names}, "seed": SEED, "fill": FILL,
       "reduction": {"classes": int(H.ncls), "nnz_dedup": int(H.nnz_dedup), "core_rows": H.core_shape[0], "core_cols": H.core_shape[1],
                     "core_nnz": H.core_shape[2], "records": int(len(H.rec_c)), "free": int(len(H.free_cls)), "seconds": {k: round(v) for k, v in H.t.items()}},
       "lanczos_runs": H.lanczos_runs, "kernel_complete_certified": bool(H.complete)}
print("rbar-part (from %s): dim %d" % (", ".join(first), V.shape[0]), flush=True)
np.save(os.path.join(CACHE, "rbar_part_s%d.npy" % SEED), V)
if V.shape[0]:
    def restrict(T, V):
        TV = matmul16(np.ascontiguousarray(V), np.ascontiguousarray(T.T), MUL)
        X = np.concatenate([V.T, TV.T], axis=1).astype(np.uint8); d = V.shape[0]
        piv = list(gf.rref16(X, MUL, INV)); assert all(p < d for p in piv), "not stable"
        Cm = np.zeros((d, d), dtype=np.uint8)
        for r, p in enumerate(piv): Cm[p] = X[r, d:]
        return Cm
    Rv = restrict(Ts["v"][0], V); Rvb = restrict(Ts["vbar"][0], V)
    pairs = []
    for a in range(16):
        Va = gen_eigenspace([Rv], [a], V.shape[0])
        if Va.shape[0] == 0: continue
        Rb = restrict(Rvb, Va)
        for b in range(16):
            Vb = gen_eigenspace([Rb], [b], Va.shape[0])
            if Vb.shape[0]: pairs.append((a, b, int(Vb.shape[0])))
    res["pairs"] = pairs
    print("(T_v, T_vbar) generalized eigenvalue pairs on the rbar-part:", pairs, " [(x, y) = (%d, %d)]" % (x, y), flush=True)
    for (a, b) in [(x, y), (y, x), (x, x), (y, y)]:
        Va = gen_eigenspace([Rv, Rvb], [a, b], V.shape[0]); W = matmul16(np.ascontiguousarray(Va), np.ascontiguousarray(V), MUL) if Va.shape[0] else Va
        ev_dim = 0
        if W.shape[0]:
            blocks = []
            for nm, lam in [("v", a), ("vbar", b)] + [(nm, evq(nm)) for nm in first + rest]:
                S = Ts[nm][0] ^ (MUL[lam, 1] * np.eye(D, dtype=np.uint8))
                blocks.append(matmul16(np.ascontiguousarray(W), np.ascontiguousarray(S.T), MUL))
            Cev = gf.kernel16(np.concatenate(blocks, axis=1).T); ev_dim = Cev.shape[0]
            if ev_dim:                                          # the joint eigenvectors, in the coordinates of H^1
                np.save(os.path.join(CACHE, "joint_%d_%d_s%d.npy" % (a, b, SEED)), matmul16(np.ascontiguousarray(Cev), np.ascontiguousarray(W), MUL))
        print("  (T_v, T_vbar) = (%d, %d): generalized eigenspace dim %d; joint eigenvectors with the rbar eigenvalues at all %d operators: %d"
              % (a, b, Va.shape[0], 2 + len(first) + len(rest), ev_dim), flush=True)
        res["pair_%d_%d" % (a, b)] = {"dim": int(Va.shape[0]), "joint_eigenvectors": int(ev_dim), "operators": ["v", "vbar"] + first + rest}
res["seconds"] = round(time.time() - t00); res["peak_rss_MB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
json.dump(res, open("big_%s%s.json" % (label, "" if SEED == 7 else "_seed%d" % SEED), "w"), indent=1, default=int)
print("done (%.0fs, peak RSS %d MB)" % (time.time() - t00, res["peak_rss_MB"]))
