"""Large levels: H^1(Gamma_0(n), F16(eps)) for PGL_2(O), O = Z[(1+sqrt-7)/2], by sparse elimination.

The equations are those of bmf.py (Fox calculus on the coset graph P^1(O/n), gauge fixed on a BFS tree), built with
numpy/numba instead of Python dictionaries.  They are then reduced in three steps:
  1. closure under the 1- and 2-term equations (a column forced to 0, or proportional to another: union-find with
     F16 factors);
  2. removal of duplicate equations, then Markowitz elimination (a column of minimal weight is eliminated with the
     shortest equation containing it) until the number of non-zeros reaches a bound;
  3. the remaining core is compressed by random sparse combinations of its equations to a square dense matrix and
     row-reduced (gf.rref16); every kernel vector is checked against all core equations.
Kernel vectors are lifted back (Markowitz records in reverse, then the union-find), and every lifted vector is checked
against ALL original equations.  FastLevel provides the interface of bmf.Level (tables, tree, walk, schreier, ...), so
hecke.py works unchanged on the result; hecke_matrix_sparse applies the functionals as a sparse product.
Author: Dula."""
import time, collections, heapq, random
import numpy as np, numba as nb
from o7 import *
import gf
from bmf import Comp, Level

MUL = gf.MUL16; INV = gf.INV16
GEN_ORDER = "ABUJ"
BITS_MIN = 1000          # cores with more columns use the bitsliced elimination

# ------------------------------------------------------------------ level tables
class FastLevel(Level):
    """bmf.Level for large n: tables by numpy, tree by numba.  eps_chars: list (one per component) of dicts
    {component scalar -> F16 code} (the nebentypus factorizes over the components), or None for trivial eps."""
    def __init__(self, comps, eps_chars=None, name="", field="F16"):
        self.eps_chars = eps_chars
        Level.__init__(self, comps, field=field, eps=None if eps_chars is None else self._eps_tuple, name=name, group="PGL")

    def _eps_tuple(self, lams):
        r = 1
        for k, l in enumerate(lams):
            r = int(MUL[r, self.eps_chars[k][l]])
        return r

    def build_tables(self):
        n = self.n; G = len(self.gens)
        mats = [GEN[g] for g in self.gens] + [GINV[g] for g in self.gens]
        nxt = np.zeros((2 * G, n), dtype=np.int64); nxe = np.ones((2 * G, n), dtype=np.uint8)
        xs = np.arange(n, dtype=np.int64)
        for s, M in enumerate(mats):
            acc_idx = np.zeros(n, dtype=np.int64); acc_eps = np.ones(n, dtype=np.uint8)
            for k, c in enumerate(self.comps):
                Mr = tuple(c.red(e) for e in M)
                if c.size > 50000:
                    loc_j, loc_e = _local_action_vec(c, Mr, None if self.eps_chars is None else self.eps_chars[k])
                else:
                    a, b, cm, dm = Mr
                    loc_j = np.zeros(c.size, dtype=np.int64); loc_e = np.ones(c.size, dtype=np.uint8)
                    for i in range(c.size):
                        cc, dd = c.rep(i)
                        nc = c.add(c.mul(cc, a), c.mul(dd, cm)); nd = c.add(c.mul(cc, b), c.mul(dd, dm))
                        j, l = c.normalize(nc, nd)
                        loc_j[i] = j
                        loc_e[i] = 1 if self.eps_chars is None else self.eps_chars[k][l]
                ik = (xs // self.strides[k]) % self.sizes[k]
                acc_idx += loc_j[ik] * self.strides[k]
                acc_eps = MUL[acc_eps, loc_e[ik]]
            nxt[s] = acc_idx; nxe[s] = acc_eps
        self.NXT = nxt; self.NXE = nxe
        self.nxt = {}; self.nxe = {}
        for s, g in enumerate(self.gens):
            self.nxt[g] = nxt[s]; self.nxe[g] = nxe[s]
            self.nxt[g.lower()] = nxt[G + s]; self.nxe[g.lower()] = nxe[G + s]
        lam, par_x, par_g = _bfs(nxt, nxe, G, n, self.root, MUL)
        assert (lam > 0).all(), "coset graph not connected"
        self.LAM = lam; self.PAR_X = par_x; self.PAR_G = par_g
        self.lam = lam                                   # numpy array: lam[x] = eps-transport along the tree path
        self.parent = _ParentView(par_x, par_g, self.gens)
        self.TREE = np.zeros(G * n, dtype=np.bool_)
        nonroot = np.nonzero(par_x >= 0)[0]
        self.TREE[par_g[nonroot] * n + par_x[nonroot]] = True
        self.tree = _TreeView(self)

    # the depth/path functions of bmf.Level use parent[x][0]; keep them, but path_word is iterative already
    def unk(self, g, x): return self.gens.index(g) * self.n + x

def _local_action_vec(c, Mr, chi):
    """Vectorized local action of a reduced matrix on P^1 of a component (Fp or Fp2), as Comp.normalize does it:
    new index and scalar; chi: dict scalar -> F16 code (or None)."""
    p = c.p; size = c.size; a, b, cm, dm = Mr
    i = np.arange(size, dtype=np.int64)
    if c.typ == "Fp":
        t = i.copy(); last = (i == p)
        r0 = np.where(last, 0, 1); r1 = np.where(last, 1, t)
        nc = (r0 * a + r1 * cm) % p; nd = (r0 * b + r1 * dm) % p
        nz = nc != 0
        invc = np.array([pow(int(x), p - 2, p) if x else 0 for x in range(p)], dtype=np.int64)
        j = np.where(nz, (nd * invc[nc]) % p, p)
        scal = np.where(nz, nc, nd)
        e = np.ones(size, dtype=np.uint8)
        if chi is not None:
            if isinstance(chi, np.ndarray): tab = chi
            else:
                tab = np.zeros(p, dtype=np.uint8)
                for x in range(1, p): tab[x] = chi[x]
            e = tab[scal]
        return j, e
    # Fp2: elements u + v t, t^2 = t - 2; points i < p^2: (1 : (i % p) + (i // p) t); i = p^2: (0 : 1)
    last = (i == p * p)
    u1 = np.where(last, 0, 1); v1 = np.zeros(size, dtype=np.int64)
    u2 = np.where(last, 1, i % p); v2 = np.where(last, 0, i // p)
    def mul(x, y):
        (xu, xv), (yu, yv) = x, y
        return ((xu * yu - 2 * xv * yv) % p, (xu * yv + xv * yu + xv * yv) % p)
    def cst(z): return (np.full(size, z[0] % p, dtype=np.int64), np.full(size, z[1] % p, dtype=np.int64))
    A_, B_, C_, D_ = cst(a), cst(b), cst(cm), cst(dm)
    m1 = mul((u1, v1), A_); m2 = mul((u2, v2), C_); ncu = (m1[0] + m2[0]) % p; ncv = (m1[1] + m2[1]) % p
    m3 = mul((u1, v1), B_); m4 = mul((u2, v2), D_); ndu = (m3[0] + m4[0]) % p; ndv = (m3[1] + m4[1]) % p
    nz = (ncu != 0) | (ncv != 0)
    # inverse of (u + v t): ((u + v) - v t) / N, N = u^2 + u v + 2 v^2
    Nn = (ncu * ncu + ncu * ncv + 2 * ncv * ncv) % p
    invp = np.zeros(p, dtype=np.int64); invp[1:] = [pow(x, p - 2, p) for x in range(1, p)]
    iN = invp[Nn]
    iu = ((ncu + ncv) * iN) % p; iv = ((-ncv) * iN) % p
    qu, qv = mul((ndu, ndv), (iu, iv))
    j = np.where(nz, qu + p * qv, p * p)
    su = np.where(nz, ncu, ndu); sv = np.where(nz, ncv, ndv)
    e = np.ones(size, dtype=np.uint8)
    if chi is not None:
        if isinstance(chi, np.ndarray): tab = chi
        else:
            tab = np.zeros((p, p), dtype=np.uint8)
            for (uu, vv), val in chi.items(): tab[uu, vv] = val
        e = tab[su, sv]
    return j, e

class _ParentView:
    def __init__(self, px, pg, gens): self.px, self.pg, self.gens = px, pg, gens
    def __getitem__(self, y):
        x = int(self.px[y])
        return None if x < 0 else (x, self.gens[int(self.pg[y])])

class _TreeView:
    """Membership test (g, x) in tree, as for the set in bmf.Level."""
    def __init__(self, L): self.L = L
    def __contains__(self, e):
        g, x = e
        return bool(self.L.TREE[self.L.gens.index(g) * self.L.n + x])
    def __len__(self): return int(self.L.TREE.sum())

@nb.njit(cache=True)
def _bfs(nxt, nxe, G, n, root, mul):
    lam = np.zeros(n, dtype=np.uint8); par_x = -np.ones(n, dtype=np.int64); par_g = -np.ones(n, dtype=np.int64)
    q = np.empty(n, dtype=np.int64); head = 0; tail = 0
    lam[root] = 1; q[tail] = root; tail += 1
    while head < tail:
        x = q[head]; head += 1
        for g in range(G):
            y = nxt[g, x]
            if lam[y] == 0:
                lam[y] = mul[lam[x], nxe[g, x]]; par_x[y] = x; par_g[y] = g
                q[tail] = y; tail += 1
    return lam, par_x, par_g

# ------------------------------------------------------------------ equations
def relator_arrays(L):
    toks = []
    for name, r in L.relators.items():
        toks.append([(L.gens.index(g), e) for g, e in r])
    T = max(len(t) for t in toks)
    tg = -np.ones((len(toks), T), dtype=np.int64); te = np.zeros((len(toks), T), dtype=np.int64)
    for i, t in enumerate(toks):
        for j, (g, e) in enumerate(t): tg[i, j] = g; te[i, j] = e
    return tg, te

@nb.njit(cache=True)
def _build_rows(nxt, nxe, tg, te, G, n, tree, mul):
    """Rows (relator r at point x) as fixed-width arrays: cols (-1 = empty), vals; tree columns dropped."""
    nr, T = tg.shape
    cols = -np.ones((nr * n, T), dtype=np.int32); vals = np.zeros((nr * n, T), dtype=np.uint8)
    for r in range(nr):
        for x in range(n):
            row = r * n + x; cur = x; w = np.uint8(1); m = 0
            for j in range(T):
                g = tg[r, j]
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; c = w
                    w = mul[w, nxe[g, cur]]; cur = nxt[g, cur]
                else:
                    w = mul[w, nxe[G + g, cur]]; cur = nxt[G + g, cur]
                    u = g * n + cur; c = w
                if tree[u]: continue
                found = False
                for t in range(m):
                    if cols[row, t] == u:
                        vals[row, t] ^= c; found = True; break
                if not found:
                    cols[row, m] = u; vals[row, m] = c; m += 1
            # compact (drop zero coefficients)
            k = 0
            for t in range(m):
                if vals[row, t] != 0:
                    cols[row, k] = cols[row, t]; vals[row, k] = vals[row, t]; k += 1
            for t in range(k, T):
                cols[row, t] = -1; vals[row, t] = 0
            if cur != x:
                cols[row, 0] = -2       # marker: relator did not close (must not happen)
    return cols, vals

def build_equations(L):
    tg, te = relator_arrays(L)
    cols, vals = _build_rows(L.NXT, L.NXE, tg, te, len(L.gens), L.n, L.TREE, MUL)
    assert not (cols[:, 0] == -2).any(), "a relator did not close"
    return cols, vals

# ------------------------------------------------------------------ step 1: closure under 1- and 2-term equations
@nb.njit(cache=True)
def _closure(cols, vals, ncol, mul, inv):
    par = np.arange(ncol); fac = np.ones(ncol, dtype=np.uint8); zero = np.zeros(ncol, dtype=np.bool_)
    R, T = cols.shape
    alive = np.ones(R, dtype=np.bool_)
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.uint8)
    changed = True; passes = 0
    while changed:
        changed = False; passes += 1
        for row in range(R):
            if not alive[row]: continue
            m = 0
            for t in range(T):
                u = cols[row, t]
                if u < 0: break
                # find root with factor (no compression here for simplicity)
                f = np.uint8(1); v = u
                while par[v] != v:
                    f = mul[f, fac[v]]; v = par[v]
                if zero[v]: continue
                c = mul[vals[row, t], f]
                found = False
                for s in range(m):
                    if rc[s] == v:
                        rv[s] ^= c; found = True; break
                if not found:
                    rc[m] = v; rv[m] = c; m += 1
            k = 0
            for s in range(m):
                if rv[s] != 0:
                    rc[k] = rc[s]; rv[k] = rv[s]; k += 1
            if k == 0:
                alive[row] = False
            elif k == 1:
                zero[rc[0]] = True; alive[row] = False; changed = True
            elif k == 2:
                a, b = rc[0], rc[1]
                # a1 c_a + a2 c_b = 0  ->  c_a = (a2 / a1) c_b
                par[a] = b; fac[a] = mul[rv[1], inv[rv[0]]]
                alive[row] = False; changed = True
    # final: resolve every column to (root, factor) or zero
    root = np.empty(ncol, dtype=np.int64); rfac = np.zeros(ncol, dtype=np.uint8)
    for u in range(ncol):
        f = np.uint8(1); v = u
        while par[v] != v:
            f = mul[f, fac[v]]; v = par[v]
        if zero[v]:
            root[u] = -1; rfac[u] = 0
        else:
            root[u] = v; rfac[u] = f
    return root, rfac, alive, passes

@nb.njit(cache=True)
def _rewrite(cols, vals, alive, root, rfac, mul):
    R, T = cols.shape
    nc = -np.ones((R, T), dtype=np.int32); nv = np.zeros((R, T), dtype=np.uint8); length = np.zeros(R, dtype=np.int32)
    for row in range(R):
        if not alive[row]: continue
        m = 0
        for t in range(T):
            u = cols[row, t]
            if u < 0: break
            v = root[u]
            if v < 0: continue
            c = mul[vals[row, t], rfac[u]]
            found = False
            for s in range(m):
                if nc[row, s] == v:
                    nv[row, s] ^= c; found = True; break
            if not found:
                nc[row, m] = v; nv[row, m] = c; m += 1
        k = 0
        for s in range(m):
            if nv[row, s] != 0:
                nc[row, k] = nc[row, s]; nv[row, k] = nv[row, s]; k += 1
        for s in range(k, T):
            nc[row, s] = -1; nv[row, s] = 0
        length[row] = k
    return nc, nv, length

# ------------------------------------------------------------------ the whole reduction
class Reduction:
    def __init__(self, L, fill=8.0, core_max=None, verbose=True, seed=1, solver="dense", lanczos_w=4):
        self.L = L; t0 = time.time(); G = len(L.gens); n = L.n; ncol = G * n
        cols, vals = build_equations(L)
        self.cols0, self.vals0 = cols, vals
        nnz0 = int((cols >= 0).sum())
        if verbose: print("  equations: %d rows, %d non-tree columns, nnz %d (%.1fs)" % (cols.shape[0], ncol - int(L.TREE.sum()), nnz0, time.time() - t0), flush=True)
        root, rfac, alive, passes = _closure(cols, vals, ncol, MUL, INV)
        root[L.TREE] = -1; rfac[L.TREE] = 0
        self.root, self.rfac = root, rfac
        nc, nv, length = _rewrite(cols, vals, alive, root, rfac, MUL)
        keep = np.nonzero(length > 0)[0]
        reps = np.unique(root[root >= 0])
        if verbose: print("  closure (%d passes): %d classes of columns, %d equations left (%.1fs)" % (passes, len(reps), len(keep), time.time() - t0), flush=True)
        # Python rows (dicts), deduplicated
        rows = {}; seen = set()
        for r in keep:
            k = int(length[r]); cs = nc[r, :k]; vs = nv[r, :k]
            order = np.argsort(cs); cs = cs[order]; vs = vs[order]
            s = int(INV[vs[0]]); key = (tuple(int(c) for c in cs), tuple(int(MUL[s, v]) for v in vs))
            if key in seen: continue
            seen.add(key); rows[len(rows)] = dict(zip(key[0], key[1]))
        del seen, nc, nv, length
        colrows = collections.defaultdict(set)
        for i, r in rows.items():
            for c in r: colrows[c].add(i)
        self.free_reps = [int(c) for c in reps if int(c) not in colrows]       # classes in no equation: free
        nnz1 = sum(len(r) for r in rows.values())
        if verbose: print("  deduplicated: %d equations, %d columns in equations, %d free classes, nnz %d (%.1fs)" % (len(rows), len(colrows), len(self.free_reps), nnz1, time.time() - t0), flush=True)
        # Markowitz elimination
        records = []
        heap = [(len(s), c) for c, s in colrows.items()]; heapq.heapify(heap)
        nnz = nnz1; bound = fill * max(nnz1, 1)
        while heap:
            w, c = heapq.heappop(heap)
            s = colrows.get(c)
            if not s: continue
            if len(s) != w:
                heapq.heappush(heap, (len(s), c)); continue
            if core_max is not None and len(colrows) <= core_max: heapq.heappush(heap, (w, c)); break
            piv = min(s, key=lambda i: len(rows[i])); pr = rows[piv]
            ap = pr[c]; iap = int(INV[ap]); fill_here = 0
            for j in list(s):
                if j == piv: continue
                rj = rows[j]; f = int(MUL[rj[c], iap])
                for v, a in pr.items():
                    nvv = rj.get(v, 0) ^ int(MUL[f, a])
                    if nvv:
                        if v not in rj: colrows[v].add(j); fill_here += 1
                        rj[v] = nvv
                    else:
                        if v in rj:
                            del rj[v]; colrows[v].discard(j); fill_here -= 1
                if not rj:
                    del rows[j]
            # remove pivot row, record
            for v in pr: colrows[v].discard(piv)
            del rows[piv]
            records.append((c, pr))
            nnz += fill_here - len(pr)
            for v in pr:
                if v != c and colrows.get(v):
                    heapq.heappush(heap, (len(colrows[v]), v))
                elif v != c and v in colrows and not colrows[v]:
                    del colrows[v]; self.free_reps.append(v)
            if c in colrows: del colrows[c]
            if nnz > bound: break
        self.records = records; self.rows = rows
        self.core_cols = sorted(c for c, s in colrows.items() if s)
        for c, s in list(colrows.items()):
            if not s and c not in self.free_reps: self.free_reps.append(c)
        nnzc = sum(len(r) for r in rows.values())
        if verbose: print("  Markowitz: %d columns eliminated; core %d equations x %d columns, nnz %d (%.1fs)" % (len(records), len(rows), len(self.core_cols), nnzc, time.time() - t0), flush=True)
        rng = np.random.default_rng(seed)
        C = len(self.core_cols); pos = {c: i for i, c in enumerate(self.core_cols)}
        rowlist = list(rows.values())
        lens = np.array([len(r) for r in rowlist], dtype=np.int64); ptr = np.zeros(len(rowlist) + 1, dtype=np.int64); ptr[1:] = np.cumsum(lens)
        cc = np.fromiter((pos[c] for r in rowlist for c in r), dtype=np.int32, count=int(ptr[-1]))
        vv = np.fromiter((v for r in rowlist for v in r.values()), dtype=np.uint8, count=int(ptr[-1]))
        self.core_csr = (ptr, cc, vv); self.solver = solver
        if solver == "none":
            self.core_kernel = None; self.t = time.time() - t0; return
        if solver == "lanczos" and C:
            # block Lanczos on M^T D M (lanczos16.py); the block is widened until the kernel found has dimension
            # C - (Krylov dimension), the kernel dimension of M^T D M
            import lanczos16
            w = lanczos_w; self.lanczos_runs = []
            while True:
                Kc, info = lanczos16.lanczos_kernel(ptr, cc, vv, C, w, seed=seed, verbose=verbose)
                self.lanczos_runs.append(info)
                if Kc.shape[0] >= C - info["krylov_dim"] or w >= 64: break
                w = (C - info["krylov_dim"]) // 64 + 2
                if verbose: print("  kernel found %d < %d: block widened to %d" % (Kc.shape[0], C - info["krylov_dim"], 64 * w), flush=True)
            piv = list(range(C - Kc.shape[0]))                          # rank of M (for the log)
        elif C:
            # dense core: random sparse combinations of the core equations, then rref16
            m = C + 48
            Mc = np.zeros((m, C), dtype=np.uint8)
            for r in range(len(rowlist)):
                cs = cc[ptr[r]:ptr[r + 1]].astype(np.int64); vs = vv[ptr[r]:ptr[r + 1]]
                for _ in range(3):
                    t = int(rng.integers(m)); f = int(rng.integers(1, 16))
                    Mc[t, cs] ^= MUL[f, vs]
            if C > BITS_MIN:
                import gf16_bits
                Kc, piv = gf16_bits.kernel_bits(Mc)                 # bitsliced RREF (same result as gf.rref16)
            else:
                A = Mc.copy(); piv = list(gf.rref16(A, MUL, INV))
                pset = set(piv); freec = [j for j in range(C) if j not in pset]
                Kc = np.zeros((len(freec), C), dtype=np.uint8)
                for k, fc in enumerate(freec):
                    Kc[k, fc] = 1
                    for r, pc in enumerate(piv): Kc[k, pc] = A[r, fc]
        else:
            piv = []; Kc = np.zeros((0, 0), dtype=np.uint8)
        freec = list(range(Kc.shape[0]))
        # check against every core equation (numba)
        bad = 0
        if C and len(rowlist):
            bad = _check_csr(ptr, cc.astype(np.int64), vv, np.ascontiguousarray(Kc), MUL)
        assert bad == 0, "core kernel fails %d equations: increase the combinations" % bad
        self.core_kernel = Kc
        if verbose: print("  core: rank %d, kernel %d; free classes %d; kernel dimension %d (%.1fs)" % (len(piv), len(freec), len(self.free_reps), len(freec) + len(self.free_reps), time.time() - t0), flush=True)
        self.t = time.time() - t0

    def kernel(self, verbose=True):
        """Basis of the gauge-fixed cocycles (rows, uint8, length G n), checked against all equations."""
        t0 = time.time(); L = self.L; G = len(L.gens); n = L.n; ncol = G * n
        d = self.core_kernel.shape[0] + len(self.free_reps)
        val = {}                                         # rep column -> vector of length d
        for k, c in enumerate(self.core_cols): val[c] = self.core_kernel[:, k].copy()
        off = self.core_kernel.shape[0]
        for j, c in enumerate(self.free_reps):
            v = np.zeros(d, dtype=np.uint8); v[off + j] = 1; val[c] = v
        for c in self.core_cols:
            if val[c].shape[0] != d:
                v = np.zeros(d, dtype=np.uint8); v[:off] = val[c]; val[c] = v
        for c, pr in reversed(self.records):
            ap = pr[c]; acc = np.zeros(d, dtype=np.uint8)
            for v, a in pr.items():
                if v == c: continue
                acc ^= MUL[a, val[v]]
            val[c] = MUL[int(INV[ap]), acc]
        reps = np.array(sorted(val), dtype=np.int64)
        V = np.zeros((len(reps), d), dtype=np.uint8)
        for i, c in enumerate(reps): V[i] = val[c]
        posr = -np.ones(ncol, dtype=np.int64); posr[reps] = np.arange(len(reps))
        K = _expand(self.root, self.rfac, posr, V, MUL)
        # check: every original equation
        bad = _check(self.cols0, self.vals0, K, MUL)
        assert bad == 0, "lifted kernel fails %d equations" % bad
        if verbose: print("  kernel lifted and checked against all %d equations: dimension %d (%.1fs)" % (self.cols0.shape[0], d, time.time() - t0), flush=True)
        return K

@nb.njit(cache=True)
def _check_csr(ptr, cc, vv, Kc, mul):
    d = Kc.shape[0]; bad = 0; acc = np.zeros(d, dtype=np.uint8)
    for r in range(ptr.shape[0] - 1):
        acc[:] = 0
        for t in range(ptr[r], ptr[r + 1]):
            c = cc[t]; a = vv[t]
            for k in range(d): acc[k] ^= mul[a, Kc[k, c]]
        for k in range(d):
            if acc[k] != 0:
                bad += 1; break
    return bad

@nb.njit(cache=True)
def _expand(root, rfac, posr, V, mul):
    ncol = root.shape[0]; d = V.shape[1]
    K = np.zeros((d, ncol), dtype=np.uint8)
    for u in range(ncol):
        r = root[u]
        if r < 0: continue
        p = posr[r]
        if p < 0: continue
        f = rfac[u]
        for k in range(d):
            K[k, u] = mul[f, V[p, k]]
    return K

@nb.njit(cache=True)
def _check(cols, vals, K, mul):
    R, T = cols.shape; d = K.shape[0]; bad = 0
    acc = np.zeros(d, dtype=np.uint8)
    for row in range(R):
        acc[:] = 0
        for t in range(T):
            u = cols[row, t]
            if u < 0: break
            a = vals[row, t]
            for k in range(d): acc[k] ^= mul[a, K[k, u]]
        for k in range(d):
            if acc[k] != 0:
                bad += 1; break
    return bad

# ------------------------------------------------------------------ coboundary of the eps-transport (non-trivial eps)
def delta_mpar(L):
    """delta m_par as a vector over the G n unknowns (zero if eps is trivial)."""
    if L.eps_chars is None: return None
    G = len(L.gens); n = L.n
    m = np.zeros(n, dtype=np.uint8)
    # m[y] = m[x] / nxe[g][x] along tree edges, m[root] = 1: m = 1 / lam
    m = INV[L.LAM]
    dm = np.zeros(G * n, dtype=np.uint8)
    xs = np.arange(n)
    for s in range(G):
        dm[s * n:(s + 1) * n] = MUL[L.NXE[s], m[L.NXT[s]]] ^ m
    return dm if dm.any() else None

def select_pivots(K, nontree, rng, extra=0):
    """d columns (among the non-tree ones) on which the rows of K are independent, found on random column subsets."""
    d = K.shape[0]; nt = np.nonzero(nontree)[0]
    m = min(len(nt), max(4 * d, 64))
    while True:
        sub = np.sort(rng.choice(nt, size=m, replace=False))
        A = np.ascontiguousarray(K[:, sub]); piv = list(gf.rref16(A, MUL, INV))
        if len(piv) == d: return [int(sub[p]) for p in piv]
        if m == len(nt): raise ValueError("K has dependent rows")
        m = min(len(nt), 2 * m)

def coords(K, piv, v):
    """Coordinates a with v = sum a_k K_k (checked on the pivot columns only)."""
    d = K.shape[0]
    A = np.concatenate([K[:, piv].T, v[piv][:, None]], axis=1).astype(np.uint8)
    p = list(gf.rref16(A, MUL, INV)); assert all(q < d for q in p), "not in the span"
    a = np.zeros(d, dtype=np.uint8)
    for r, q in enumerate(p): a[q] = A[r, d]
    return a

def quotient_by(K, dm, rng):
    """Rows of K spanning a complement of dm in span(K) (dm must lie in span(K)); dm is a coboundary."""
    if dm is None: return K
    piv = select_pivots(K, np.ones(K.shape[1], dtype=np.bool_), rng)
    a = coords(K, piv, dm)
    # check dm = sum a_k K_k on all columns
    acc = np.zeros(K.shape[1], dtype=np.uint8)
    for k in np.nonzero(a)[0]: acc ^= MUL[a[k], K[k]]
    assert (acc == dm).all(), "delta m_par not in the span of the kernel"
    drop = int(np.nonzero(a)[0][0])
    return np.delete(K, drop, axis=0)

# ------------------------------------------------------------------ Hecke operators on a large basis
def hecke_matrix_sparse(L, K, pi, pivots, rng, extra=8, dm=None, KT=None):
    """Matrix T (d x d) of T_pi on span(K) modulo dm: T[:, k] = coordinates of T(K_k), read off on the pivot columns
    and checked on `extra` further non-tree columns.  Functionals are applied as sparse sums over the basis."""
    import hecke
    d = K.shape[0]; n = L.n; G = len(L.gens)
    B = K if dm is None else np.vstack([K, dm[None, :]])
    nt = np.nonzero(~L.TREE)[0]
    extras = [int(u) for u in rng.choice(nt, size=extra, replace=False) if int(u) not in set(pivots)]
    cols = list(pivots) + extras
    vals = np.zeros((len(cols), d), dtype=np.uint8)
    for r, u in enumerate(cols):
        g = L.gens[u // n]; x = u % n
        h = L.schreier(g, x); pieces = hecke.hecke_pieces(L, pi, h)
        acc = np.zeros(d, dtype=np.uint8)
        for hi, w in pieces:
            dct = hecke.functional(L, hi)
            for v, c in dct.items():
                if c: acc ^= MUL[int(MUL[w, c]), (KT[v] if KT is not None else K[:, v])]
        vals[r] = MUL[int(INV[L.lam[x]]), acc]
    Bc = B[:, cols].T.astype(np.uint8)                       # (len(cols), d or d+1)
    Aug = np.concatenate([Bc, vals], axis=1)
    Dd = B.shape[0]
    piv = list(gf.rref16(Aug, MUL, INV))
    if any(p >= Dd for p in piv): return None
    X = np.zeros((Dd, d), dtype=np.uint8)
    for r, p in enumerate(piv): X[p] = Aug[r, Dd:]
    return X[:d] if dm is not None else X

@nb.njit(cache=True)
def matmul16(A, B, mul):
    n, k = A.shape; m = B.shape[1]
    C = np.zeros((n, m), dtype=np.uint8)
    for i in range(n):
        for t in range(k):
            a = A[i, t]
            if a == 0: continue
            for j in range(m):
                C[i, j] ^= mul[a, B[t, j]]
    return C

def kernel_rows(M):
    """Basis (rows) of {x : M x = 0}."""
    return gf.kernel16(M)

def gen_eigenspace(Ts, evs, D):
    """Joint generalized eigenspace (rows) of matrices acting on column vectors: kernel of (T - e)^(2^k), 2^k >= D."""
    V = np.eye(D, dtype=np.uint8)
    for T, e in zip(Ts, evs):
        if V.shape[0] == 0: break
        S = np.array(T, dtype=np.uint8) ^ (MUL[e, 1] * np.eye(D, dtype=np.uint8))
        P = S.copy(); k = 1
        while k < D:
            P = matmul16(P, P, MUL); k *= 2
        Kk = gf.kernel16(P)
        M = np.vstack([V, Kk]); Kk2 = gf.kernel16(M.T)
        W = matmul16(np.ascontiguousarray(Kk2[:, :V.shape[0]]), V, MUL)
        A = np.array(W, copy=True); piv = gf.rref16(A, MUL, INV); V = A[:len(piv)]
    return V
