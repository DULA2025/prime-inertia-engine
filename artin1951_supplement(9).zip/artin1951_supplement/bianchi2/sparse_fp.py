"""Characteristic-0 ranks of Bianchi cohomology at large levels: H^1(Gamma_0(n), F_P(chi psi)) for PGL_2(O_E),
E = Q(sqrt-7), by sparse elimination over a prime field F_P.

The equations are those of bmf.py and sparse_h1.py, with signs (Fox calculus: -w for an inverse letter) and the
nebentypus in F_P: chi is the Teichmueller lift of the F16 character of the level tables (z^k -> omega^k, omega a
fixed primitive 5th root of unity in F_P; any choice gives the same dimension, the four characters of order 5 being
Galois conjugate), optionally times a quadratic character psi of components of (O/n)^x (bits of
bockstein.quad_step_tables).  P < 2^20 with P = 1 mod 40.

dim_{F_P} H^1 >= dim_C H^1(Gamma_0(n), C(chi psi)) for every P (universal coefficients), so an upper bound for
dim_{F_P} H^1 bounds the characteristic-0 rank.  Steps (as sparse_big.py, with F_P arithmetic):
  1. closure under the 1- and 2-term equations (union-find with F_P factors), the rows re-derived from the level
     tables at every pass (no row storage);
  2. CSR over classes, normalized (first coefficient 1), deduplicated;
  3. Markowitz rounds, stopped at a cost ceiling (the product (core columns) x (core nnz) is smallest there);
  4. the core: dense elimination mod P if small (exact rank), otherwise Montgomery's block Lanczos over F_P on
     A = M^T D M (D a random invertible diagonal, start block in im A), which gives the certificate
     dim ker M <= dim ker A <= N - (Krylov dimension) - rank V_m.
Then dim Z_gauge <= (bound on dim ker core) + (free classes), and dim H^1 = dim Z_gauge - 1 when chi psi != 1 (the
coboundary delta m_par).  Author: Dula."""
import time, os, json
import numpy as np, numba as nb
from o7 import GEN, GINV
from sparse_h1 import relator_arrays
from sparse_big import SCHEDULE, _row_hash, _relabel

def choose_prime(bits=20, mod=40, below=None):
    import cypari2
    pari = cypari2.Pari()
    P = (below if below is not None else (1 << bits)) - 1
    P -= (P - 1) % mod
    while not int(pari("isprime(%d)" % P)): P -= mod
    return P

def chi_table(P, mod=5):
    """F16 codes of z^k (z = zeta_5 mod 2) -> omega^k in F_P; 0 elsewhere."""
    import cypari2, gf
    pari = cypari2.Pari()
    g = int(pari("lift(znprimroot(%d))" % P)); om = pow(g, (P - 1) // 5, P)
    t = np.zeros(16, dtype=np.int64); zk = 1; ok = 1
    for k in range(5):
        t[zk] = ok; zk = int(gf.MUL16[zk, 2]); ok = ok * om % P
    return t, om

@nb.njit(cache=True)
def _inv(a, P):
    r = 1; b = a % P; e = P - 2
    while e > 0:
        if e & 1: r = (r * b) % P
        b = (b * b) % P; e >>= 1
    return r

@nb.njit(cache=True)
def _walk(nxt, nxe, nxl, chip, qmask, tg, te, G, n, tree, P, r, x, eu, ev):
    """Terms of the equation (relator r at coset x): edges eu, values ev (mod P, merged, zeros dropped).
    Returns (number of terms, closes)."""
    T = tg.shape[1]; cur = np.int64(x); w = np.int64(1); m = 0
    for j in range(T):
        g = np.int64(tg[r, j])
        if g < 0: break
        if te[r, j] == 1:
            u = g * n + cur; c = w
            f = chip[nxe[g, cur]]
            if qmask != 0:
                bb = nxl[g, cur] & qmask; par_ = 0
                while bb:
                    par_ ^= bb & 1; bb >>= 1
                if par_: f = P - f
            w = (w * f) % P; cur = np.int64(nxt[g, cur])
        else:
            s = G + g
            f = chip[nxe[s, cur]]
            if qmask != 0:
                bb = nxl[s, cur] & qmask; par_ = 0
                while bb:
                    par_ ^= bb & 1; bb >>= 1
                if par_: f = P - f
            w = (w * f) % P; cur = np.int64(nxt[s, cur])
            u = g * n + cur; c = (P - w) % P
        if tree[u]: continue
        found = False
        for t in range(m):
            if eu[t] == u:
                ev[t] = (ev[t] + c) % P; found = True; break
        if not found:
            eu[m] = u; ev[m] = c; m += 1
    k = 0
    for t in range(m):
        if ev[t] != 0:
            eu[k] = eu[t]; ev[k] = ev[t]; k += 1
    return k, cur == x

@nb.njit(cache=True)
def _find(u, par, fac, P, stack):
    k = 0; v = u
    while par[v] != v:
        stack[k] = v; k += 1; v = par[v]
    f = np.int64(1)
    for i in range(k - 1, -1, -1):
        w = stack[i]; f = (fac[w] * f) % P; fac[w] = f; par[w] = v
    return v

@nb.njit(cache=True)
def closure_fp(nxt, nxe, nxl, chip, qmask, tg, te, G, n, tree, P):
    nr, T = tg.shape; ncol = G * n; R = nr * n
    par = np.arange(ncol, dtype=np.int64); fac = np.ones(ncol, dtype=np.int64); zero = np.zeros(ncol, dtype=np.bool_)
    stack = np.empty(ncol, dtype=np.int64); alive = np.ones(R, dtype=np.bool_)
    eu = np.empty(T, dtype=np.int64); ev = np.empty(T, dtype=np.int64)
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.int64)
    changed = True; passes = 0; notclosed = 0
    while changed:
        changed = False; passes += 1
        for row in range(R):
            if not alive[row]: continue
            r = row // n; x = row - r * n
            k0, ok = _walk(nxt, nxe, nxl, chip, qmask, tg, te, G, n, tree, P, r, x, eu, ev)
            if not ok: notclosed += 1
            mm_ = 0
            for t in range(k0):
                u = eu[t]
                v = _find(u, par, fac, P, stack)
                if zero[v]: continue
                f = fac[u] if u != v else np.int64(1)
                c = (ev[t] * f) % P
                found = False
                for s in range(mm_):
                    if rc[s] == v:
                        rv[s] = (rv[s] + c) % P; found = True; break
                if not found:
                    rc[mm_] = v; rv[mm_] = c; mm_ += 1
            k = 0
            for s in range(mm_):
                if rv[s] != 0:
                    rc[k] = rc[s]; rv[k] = rv[s]; k += 1
            if k == 0:
                alive[row] = False
            elif k == 1:
                zero[rc[0]] = True; alive[row] = False; changed = True
            elif k == 2:
                a = rc[0]; b = rc[1]
                par[a] = b; fac[a] = ((P - rv[1]) * _inv(rv[0], P)) % P       # rv0 x_a + rv1 x_b = 0
                alive[row] = False; changed = True
    root = np.empty(ncol, dtype=np.int64); rfac = np.zeros(ncol, dtype=np.int64)
    for u in range(ncol):
        v = _find(u, par, fac, P, stack)
        if zero[v]:
            root[u] = -1; rfac[u] = 0
        else:
            root[u] = v; rfac[u] = fac[u] if u != v else 1
    return root, rfac, alive, passes, notclosed

@nb.njit(cache=True)
def _row_terms_fp(nxt, nxe, nxl, chip, qmask, tg, te, G, n, tree, P, row, cls_of, rfac, eu, ev, rc, rv):
    """The equation of a row over the classes: (rc, rv)[:k], merged, zeros dropped."""
    r = row // n; x = row - r * n
    k0, ok = _walk(nxt, nxe, nxl, chip, qmask, tg, te, G, n, tree, P, r, x, eu, ev)
    mm_ = 0
    for t in range(k0):
        u = eu[t]; v = cls_of[u]
        if v < 0: continue
        c = (ev[t] * rfac[u]) % P
        found = False
        for s in range(mm_):
            if rc[s] == v:
                rv[s] = (rv[s] + c) % P; found = True; break
        if not found:
            rc[mm_] = v; rv[mm_] = c; mm_ += 1
    k = 0
    for s in range(mm_):
        if rv[s] != 0:
            rc[k] = rc[s]; rv[k] = rv[s]; k += 1
    return k

@nb.njit(cache=True)
def rows_to_csr_fp(nxt, nxe, nxl, chip, qmask, tg, te, G, n, tree, P, alive, cls_of, rfac):
    nr, T = tg.shape; R = nr * n
    eu = np.empty(T, dtype=np.int64); ev = np.empty(T, dtype=np.int64)
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.int64)
    lens = np.zeros(R, dtype=np.int64); total = 0; nrows = 0
    for row in range(R):
        if not alive[row]: continue
        k = _row_terms_fp(nxt, nxe, nxl, chip, qmask, tg, te, G, n, tree, P, row, cls_of, rfac, eu, ev, rc, rv)
        lens[row] = k; total += k
        if k: nrows += 1
    ptr = np.zeros(nrows + 1, dtype=np.int64); col = np.empty(total, dtype=np.int32); val = np.empty(total, dtype=np.int64)
    hs = np.empty(nrows, dtype=np.uint64); ri = 0; p = 0
    for row in range(R):
        if not alive[row] or lens[row] == 0: continue
        k = _row_terms_fp(nxt, nxe, nxl, chip, qmask, tg, te, G, n, tree, P, row, cls_of, rfac, eu, ev, rc, rv)
        for i in range(1, k):
            a = rc[i]; b = rv[i]; j = i - 1
            while j >= 0 and rc[j] > a:
                rc[j + 1] = rc[j]; rv[j + 1] = rv[j]; j -= 1
            rc[j + 1] = a; rv[j + 1] = b
        s0 = _inv(rv[0], P)
        for i in range(k):
            col[p + i] = rc[i]; val[p + i] = (rv[i] * s0) % P
        hs[ri] = _row_hash(col[p:p + k], val[p:p + k], k)
        p += k; ri += 1; ptr[ri] = p
    return ptr, col, val, hs

@nb.njit(cache=True)
def _dedup_keep_fp(ptr, col, val, hs, order):
    n = order.shape[0]; keep = np.zeros(n, dtype=np.bool_)
    i = 0
    while i < n:
        j = i
        while j < n and hs[order[j]] == hs[order[i]]: j += 1
        for a in range(i, j):
            ra = order[a]; dup = False
            for b in range(i, a):
                rb = order[b]
                if not keep[rb]: continue
                la = ptr[ra + 1] - ptr[ra]; lb = ptr[rb + 1] - ptr[rb]
                if la != lb: continue
                same = True
                for t in range(la):
                    if col[ptr[ra] + t] != col[ptr[rb] + t] or val[ptr[ra] + t] != val[ptr[rb] + t]:
                        same = False; break
                if same:
                    dup = True; break
            if not dup: keep[ra] = True
        i = j
    return keep

@nb.njit(cache=True)
def _select_rows_fp(ptr, col, val, keep):
    R = ptr.shape[0] - 1; nr = 0; nn = 0
    for r in range(R):
        if keep[r]: nr += 1; nn += ptr[r + 1] - ptr[r]
    p2 = np.zeros(nr + 1, dtype=np.int64); c2 = np.empty(nn, dtype=np.int32); v2 = np.empty(nn, dtype=np.int64)
    k = 0; i = 0
    for r in range(R):
        if not keep[r]: continue
        for t in range(ptr[r], ptr[r + 1]):
            c2[k] = col[t]; v2[k] = val[t]; k += 1
        i += 1; p2[i] = k
    return p2, c2, v2

@nb.njit(cache=True)
def _hash_rows_fp(ptr, col, val, P):
    R = ptr.shape[0] - 1; hs = np.empty(R, dtype=np.uint64)
    for r in range(R):
        lo = ptr[r]; hi = ptr[r + 1]
        if hi > lo:
            s = _inv(val[lo], P)
            if s != 1:
                for t in range(lo, hi): val[t] = (val[t] * s) % P
        hs[r] = _row_hash(col[lo:hi], val[lo:hi], hi - lo)
    return hs

def dedup_fp(ptr, col, val, P, hs=None):
    if hs is None: hs = _hash_rows_fp(ptr, col, val, P)
    order = np.argsort(hs, kind="stable")
    keep = _dedup_keep_fp(ptr, col, val, hs, order)
    return _select_rows_fp(ptr, col, val, keep)

@nb.njit(cache=True)
def _mk_round_fp(ptr, col, val, ncls, maxcost, P):
    R = ptr.shape[0] - 1; nnz = ptr[R]
    cw = np.zeros(ncls, dtype=np.int64)
    for t in range(nnz): cw[col[t]] += 1
    cptr = np.zeros(ncls + 1, dtype=np.int64)
    for c in range(ncls): cptr[c + 1] = cptr[c] + cw[c]
    crow = np.empty(nnz, dtype=np.int32); fp = cptr[:ncls].copy()
    for r in range(R):
        for t in range(ptr[r], ptr[r + 1]):
            c = col[t]; crow[fp[c]] = r; fp[c] += 1
    cand_cost = np.empty(ncls, dtype=np.int64); cand_col = np.empty(ncls, dtype=np.int64)
    prow = np.full(ncls, -1, dtype=np.int64); nc = 0
    for c in range(ncls):
        w = cw[c]
        if w == 0: continue
        best = -1; bl = 1 << 62
        for k in range(cptr[c], cptr[c + 1]):
            r = crow[k]; l = ptr[r + 1] - ptr[r]
            if l < bl:
                bl = l; best = r
        mc = (w - 1) * (bl - 1)
        if mc <= maxcost:
            cand_cost[nc] = mc; cand_col[nc] = c; prow[c] = best; nc += 1
    order = np.argsort(cand_cost[:nc], kind="mergesort")
    used = np.zeros(R, dtype=np.bool_)
    piv_of = np.full(R, -1, dtype=np.int64); mod_by = np.full(R, -1, dtype=np.int64)
    nsel = 0; extra = 0
    for oi in range(nc):
        c = cand_col[order[oi]]; ok = True
        for k in range(cptr[c], cptr[c + 1]):
            if used[crow[k]]:
                ok = False; break
        if not ok: continue
        p = prow[c]; lp = ptr[p + 1] - ptr[p]
        for k in range(cptr[c], cptr[c + 1]):
            r = crow[k]; used[r] = True
            if r == p: piv_of[r] = c
            else:
                mod_by[r] = c; extra += lp - 2
        nsel += 1
    bound = nnz + max(extra, 0)
    nptr = np.zeros(R + 1, dtype=np.int64); ncol_ = np.empty(bound, dtype=np.int32); nval = np.empty(bound, dtype=np.int64)
    nr = 0; k = 0
    for r in range(R):
        if piv_of[r] >= 0: continue
        c = mod_by[r]
        if c < 0:
            for t in range(ptr[r], ptr[r + 1]):
                ncol_[k] = col[t]; nval[k] = val[t]; k += 1
        else:
            p = prow[c]; arc = 0; apc = 0
            for t in range(ptr[r], ptr[r + 1]):
                if col[t] == c:
                    arc = val[t]; break
            for t in range(ptr[p], ptr[p + 1]):
                if col[t] == c:
                    apc = val[t]; break
            f = (arc * _inv(apc, P)) % P                 # row r -= f * row p
            i = ptr[r]; ie = ptr[r + 1]; j = ptr[p]; je = ptr[p + 1]
            while i < ie or j < je:
                if j >= je or (i < ie and col[i] < col[j]):
                    ncol_[k] = col[i]; nval[k] = val[i]; k += 1; i += 1
                elif i >= ie or col[j] < col[i]:
                    ncol_[k] = col[j]; nval[k] = (P - (f * val[j]) % P) % P; k += 1; j += 1
                else:
                    v = (val[i] - f * val[j]) % P
                    if v != 0:
                        ncol_[k] = col[i]; nval[k] = v; k += 1
                    i += 1; j += 1
        if k > nptr[nr]:
            nr += 1; nptr[nr] = k
    elim = np.zeros(ncls, dtype=np.bool_)
    for r in range(R):
        if piv_of[r] >= 0: elim[piv_of[r]] = True
    return nptr[:nr + 1].copy(), ncol_[:k].copy(), nval[:k].copy(), nsel, elim

def markowitz_fp(ptr, col, val, ncls, P, maxcost_stop=384, verbose=True, min_frac=0.002):
    t0 = time.time(); nrounds = 0; elim = np.zeros(ncls, dtype=np.bool_)
    for maxcost in SCHEDULE:
        if maxcost > maxcost_stop: break
        while True:
            out = _mk_round_fp(ptr, col, val, ncls, maxcost, P)
            nsel = out[3]
            if nsel == 0: break
            ptr, col, val = out[0], out[1], out[2]; elim |= out[4]; nrounds += 1
            live = int(np.count_nonzero(np.bincount(col, minlength=ncls))) if nrounds % 4 == 0 else None
            if live is not None and nsel < min_frac * live: break
        ptr, col, val = dedup_fp(ptr, col, val, P)
        if verbose:
            live = int(np.count_nonzero(np.bincount(col, minlength=ncls)))
            print("    cost <= %d: %d rounds, %d rows, %d live columns, nnz %d, product %.2e (%.0fs)" % (maxcost, nrounds, len(ptr) - 1, live, len(col), float(live) * len(col), time.time() - t0), flush=True)
    return ptr, col, val, elim

# ------------------------------------------------------------------ block Lanczos over F_P
@nb.njit(cache=True, parallel=True, fastmath={"contract"})
def spmv_fp(ptr, col, val, X, P):
    """Y = M X mod P; X (N, b) float64 with entries in [0, P), val float64; P < 2^20: products are < 2^40 and partial
    sums of up to 4096 of them stay below 2^52, so the float64 arithmetic is exact (in any order of summation)."""
    R = ptr.shape[0] - 1; b = X.shape[1]; Y = np.empty((R, b), dtype=np.float64)
    fP = float(P); invP = 1.0 / fP
    for r in nb.prange(R):
        acc = np.zeros(b, dtype=np.float64)
        lo = ptr[r]; hi = ptr[r + 1]; k = lo
        while k < hi:
            kend = min(hi, k + 4096)
            for kk in range(k, kend):
                c = col[kk]; v = val[kk]
                for j in range(b): acc[j] += v * X[c, j]
            for j in range(b):
                y = acc[j]; y -= fP * np.floor(y * invP)
                if y < 0: y += fP
                if y >= fP: y -= fP
                acc[j] = y
            k = kend
        for j in range(b): Y[r, j] = acc[j]
    return Y

@nb.njit(cache=True, parallel=True, fastmath={"contract"})
def spmv_fp32(ptr, col, val, X, P):
    """Y = M X mod P with X stored as float32 (entries < P < 2^20 < 2^24 are exact in float32); products and partial
    sums in float64 (exact, as in spmv_fp); output float32.  Rows in groups of 64 per parallel task."""
    R = ptr.shape[0] - 1; b = X.shape[1]; Y = np.empty((R, b), dtype=np.float32)
    fP = float(P); invP = 1.0 / fP
    nblk = (R + 63) // 64
    for bi in nb.prange(nblk):
        acc = np.empty(b, dtype=np.float64)
        for r in range(bi * 64, min(R, bi * 64 + 64)):
            for j in range(b): acc[j] = 0.0
            lo = ptr[r]; hi = ptr[r + 1]; k = lo
            while k < hi:
                kend = min(hi, k + 4096)
                for kk in range(k, kend):
                    c = col[kk]; v = val[kk]
                    for j in range(b): acc[j] += v * np.float64(X[c, j])
                for j in range(b):
                    y = acc[j]; y -= fP * np.floor(y * invP)
                    if y < 0: y += fP
                    if y >= fP: y -= fP
                    acc[j] = y
                k = kend
            for j in range(b): Y[r, j] = np.float32(acc[j])
    return Y

@nb.njit(cache=True)
def transpose_csr_fp(ptr, col, val, ncol):
    R = ptr.shape[0] - 1; nnz = ptr[R]
    cnt = np.zeros(ncol + 1, dtype=np.int64)
    for t in range(nnz): cnt[col[t] + 1] += 1
    for c in range(ncol): cnt[c + 1] += cnt[c]
    tp = cnt.copy(); tc = np.empty(nnz, dtype=np.int32); tv = np.empty(nnz, dtype=np.float64); fill = cnt[:ncol].copy()
    for r in range(R):
        for t in range(ptr[r], ptr[r + 1]):
            c = col[t]; tc[fill[c]] = r; tv[fill[c]] = val[t]; fill[c] += 1
    return tp, tc, tv

def _mm(A, B, P):
    """A B mod P for blocks (N, b) and (b, c), entries in [0, P), b <= 64: float64 products are exact (< 2^46)."""
    return np.fmod(np.asarray(A, dtype=np.float64) @ np.asarray(B, dtype=np.float64), float(P)).astype(np.int64)

def _mmf(A, B, P):
    return np.fmod(np.asarray(A, dtype=np.float64) @ np.asarray(B, dtype=np.float64), float(P))

def _gram(U, V, P):
    """U^T V mod P for (N, b) float64 blocks with entries in [0, P): float64 BLAS on chunks of 4096 rows (partial sums
    < 2^52, exact), reduced after each chunk."""
    N = U.shape[0]; out = np.zeros((U.shape[1], V.shape[1]), dtype=np.float64); step = 4096; fP = float(P)
    for s in range(0, N, step):
        out = np.fmod(out + U[s:s + step].astype(np.float64).T @ V[s:s + step].astype(np.float64), fP)
    return out.astype(np.int64)

@nb.njit(cache=True)
def select_fp(T, Sprev, P):
    """Montgomery's selection: Gauss-Jordan on [T | I] mod P, columns not in Sprev first.  Returns (Winv, S, ok)."""
    b = T.shape[0]
    M = np.zeros((b, 2 * b), dtype=np.int64)
    for i in range(b):
        for j in range(b): M[i, j] = T[i, j] % P
        M[i, b + i] = 1
    order = np.empty(b, dtype=np.int64); k = 0
    for j in range(b):
        if not Sprev[j]:
            order[k] = j; k += 1
    for j in range(b):
        if Sprev[j]:
            order[k] = j; k += 1
    pos2row = order.copy(); S = np.zeros(b, dtype=np.bool_)
    for jj in range(b):
        c = order[jj]; f = -1
        for kk in range(jj, b):
            if M[pos2row[kk], c] != 0:
                f = kk; break
        if f >= 0:
            tmp = pos2row[jj]; pos2row[jj] = pos2row[f]; pos2row[f] = tmp
            r = pos2row[jj]; S[c] = True
            s = _inv(M[r, c], P)
            for t in range(2 * b): M[r, t] = (M[r, t] * s) % P
            for kk in range(b):
                rr = pos2row[kk]
                if rr == r: continue
                fct = M[rr, c]
                if fct != 0:
                    for t in range(2 * b): M[rr, t] = (M[rr, t] - fct * M[r, t]) % P
        else:
            f = -1
            for kk in range(jj, b):
                if M[pos2row[kk], b + c] != 0:
                    f = kk; break
            if f < 0:
                return np.zeros((b, b), dtype=np.int64), S, False
            tmp = pos2row[jj]; pos2row[jj] = pos2row[f]; pos2row[f] = tmp
            r = pos2row[jj]
            s = _inv(M[r, b + c], P)
            for t in range(2 * b): M[r, t] = (M[r, t] * s) % P
            for kk in range(b):
                rr = pos2row[kk]
                if rr == r: continue
                fct = M[rr, b + c]
                if fct != 0:
                    for t in range(2 * b): M[rr, t] = (M[rr, t] - fct * M[r, t]) % P
            for t in range(2 * b): M[r, t] = 0
    Winv = np.zeros((b, b), dtype=np.int64)
    for jj in range(b):
        c = order[jj]; r = pos2row[jj]
        for t in range(b): Winv[c, t] = M[r, b + t]
    ok = True
    for j in range(b):
        if (not Sprev[j]) and (not S[j]): ok = False
    return Winv, S, ok

def _save(path, **kw):
    tmp = path + ".tmp.npz"; np.savez(tmp, **kw); os.replace(tmp, path)

def lanczos_bound(ptr, col, val, N, P, b=16, seed=1, verbose=True, ckpt=None, ckpt_seconds=600, check_every=0):
    """Montgomery's block Lanczos over F_P on A = M^T D M with a start block in im A.  Returns
    (Krylov dimension = sum |S_i|, rank V_m, iterations, gap = N - Krylov dimension - rank V_m) with dim ker A <= gap."""
    import gf
    rng = np.random.default_rng(seed + 2000); R = ptr.shape[0] - 1; t0 = time.time()
    d = rng.integers(1, P, size=R).astype(np.float64)
    dval = (np.repeat(d, np.diff(ptr)).astype(np.int64) * val.astype(np.int64)) % P
    vf = val.astype(np.float64); dvf = dval.astype(np.float64); del dval
    tp, tc, tv = transpose_csr_fp(ptr, col, vf, N)
    def apply_A(X):                                  # blocks are float32 (exact integers in [0, P))
        return spmv_fp32(tp, tc, tv, spmv_fp32(ptr, col, dvf, X, P), P)
    I = np.eye(b, dtype=np.int64); Z = np.zeros((b, b), dtype=np.int64)
    if ckpt is not None and os.path.exists(ckpt):
        st = np.load(ckpt)
        assert int(st["N"]) == N and int(st["b"]) == b and int(st["seed"]) == seed and int(st["P"]) == P
        it = int(st["it"]); dimK = int(st["dimK"]); V = st["V"].astype(np.float32)
        Vm1 = st["Vm1"].astype(np.float32) if st["Vm1"].size else None; Vm2 = st["Vm2"].astype(np.float32) if st["Vm2"].size else None
        Winv1 = st["Winv1"]; Winv2 = st["Winv2"]; VAV1 = st["VAV1"]; VA2V1 = st["VA2V1"]; S1 = st["S1"].astype(np.bool_)
        if verbose: print("    resumed at iteration %d (Krylov dimension %d)" % (it, dimK), flush=True)
    else:
        Y = rng.integers(0, P, size=(N, b)).astype(np.float32)
        V = apply_A(Y); Vm1 = None; Vm2 = None
        Winv1 = Z; Winv2 = Z; VAV1 = Z; VA2V1 = Z; S1 = np.ones(b, dtype=np.bool_); dimK = 0; it = 0
    it0 = it; t_save = time.time(); maxit = N // max(1, b // 2) + 40
    Wkeep = []; nchecks = 0
    while it < maxit:
        AV = apply_A(V)
        VAV = _gram(V, AV, P)
        if not VAV.any(): break
        VA2V = _gram(AV, AV, P)
        Winv, S, ok = select_fp(VAV, S1, P)
        if not ok: raise RuntimeError("block Lanczos breakdown at iteration %d" % it)
        dimK += int(S.sum()); Sm = S.astype(np.int64)[None, :]
        D = (I - _mm(Winv, (VA2V * Sm + VAV) % P, P)) % P
        Vn = np.fmod(AV * S.astype(np.float64)[None, :] + _mmf(V, D, P), float(P))
        if it >= 1:
            E = (-_mm(Winv1, VAV, P) * Sm) % P
            if E.any(): Vn = np.fmod(Vn + _mmf(Vm1, E, P), float(P))
        if it >= 2:
            F = (-_mm(_mm(Winv2, (I - _mm(VAV1, Winv1, P)) % P, P), (VA2V1 * S1.astype(np.int64)[None, :] + VAV1) % P, P) * Sm) % P
            if F.any(): Vn = np.fmod(Vn + _mmf(Vm2, F, P), float(P))
        Vn = Vn.astype(np.float32)
        if check_every and it % check_every == 0:
            Wkeep.append(V * S.astype(np.float64)[None, :]); Wkeep = Wkeep[-3:]
            AVn = apply_A(Vn)
            for Wj in Wkeep:
                assert not _gram(Wj, AVn, P).any(), "A-orthogonality fails at iteration %d" % it
            nchecks += 1
        Vm2, Vm1, V = Vm1, V, Vn
        Winv2, Winv1, VAV1, VA2V1, S1 = Winv1, Winv, VAV, VA2V, S
        it += 1
        if verbose and (it % 200 == 0 or it < 3):
            el = time.time() - t0
            print("    Lanczos F_P iteration %d: Krylov dimension %d of %d (%.0fs, %.2fs/it)" % (it, dimK, N, el, el / max(1, it - it0)), flush=True)
        if ckpt is not None and time.time() - t_save > ckpt_seconds:
            _save(ckpt, N=N, b=b, seed=seed, P=P, it=it, dimK=dimK, V=V, Vm1=Vm1 if Vm1 is not None else np.zeros(0), Vm2=Vm2 if Vm2 is not None else np.zeros(0),
                  Winv1=Winv1, Winv2=Winv2, VAV1=VAV1, VA2V1=VA2V1, S1=S1.astype(np.uint8))
            t_save = time.time()
            if verbose: print("    checkpoint saved at iteration %d" % it, flush=True)
    # rank of V_m (the last block; V^T A V = 0 there)
    Vt = np.ascontiguousarray(V.T.astype(np.int64) % P)
    rVm = len(gf.rrefp(Vt, P)) if V.any() else 0
    gap = N - dimK - rVm
    if verbose: print("    Lanczos F_P: %d iterations, Krylov dimension %d, rank V_m %d; dim ker A <= %d - %d - %d = %d (%.0fs)" % (it, dimK, rVm, N, dimK, rVm, gap, time.time() - t0), flush=True)
    return {"iterations": it, "krylov_dim": dimK, "rank_Vm": rVm, "gap": gap, "block": b, "seed": seed, "P": P,
            "orthogonality_checks_passed": nchecks, "seconds": round(time.time() - t0, 1)}

# ------------------------------------------------------------------ the whole computation
class FpH1:
    """dim H^1(Gamma_0(n), F_P(chi psi)) (exact for small cores, an upper bound with the Lanczos certificate)."""
    def __init__(self, L, P, chip, nxl=None, qmask=0, maxcost_stop=384, dense_max=4000, b=16, seed=1, verbose=True, cache=None, check_every=0):
        t0 = time.time(); G = len(L.gens); n = L.n; ncol = G * n; self.t = {}
        tg, te = relator_arrays(L)
        if nxl is None: nxl = np.zeros((2 * G, n), dtype=np.uint8)
        self.nontrivial = bool(qmask) or bool((chip[L.NXE] != 1).any())
        red = None if cache is None else os.path.join(cache, "fp_reduction_P%d_q%d.npz" % (P, qmask))
        if red is not None and os.path.exists(red):
            z = np.load(red); ptr, col, val = z["ptr"], z["col"], z["val"]; self.ncls = int(z["ncls"]); self.nfree = int(z["nfree"]); C = int(z["C"]); del z
            if verbose: print("  F_P reduction loaded from %s" % red, flush=True)
        else:
            root, rfac, alive, passes, notclosed = closure_fp(L.NXT, L.NXE, nxl, chip, qmask, tg, te, G, n, L.TREE, P)
            assert notclosed == 0
            root[L.TREE] = -1; rfac[L.TREE] = 0
            reps = np.unique(root[root >= 0]); ncls = len(reps)
            cls_of = -np.ones(ncol, dtype=np.int32); pos = -np.ones(ncol, dtype=np.int64); pos[reps] = np.arange(ncls)
            mk = root >= 0; cls_of[mk] = pos[root[mk]].astype(np.int32); del pos, mk, root
            if verbose: print("  F_P closure (%d passes): %d classes, %d equations left (%.0fs)" % (passes, ncls, int(alive.sum()), time.time() - t0), flush=True)
            ptr, col, val, hs = rows_to_csr_fp(L.NXT, L.NXE, nxl, chip, qmask, tg, te, G, n, L.TREE, P, alive, cls_of, rfac)
            del alive, cls_of, rfac
            ptr, col, val = dedup_fp(ptr, col, val, P, hs); del hs
            inrows = np.bincount(col, minlength=ncls) > 0
            if verbose: print("  deduplicated: %d equations, nnz %d, classes in equations %d of %d (%.0fs)" % (len(ptr) - 1, len(col), int(inrows.sum()), ncls, time.time() - t0), flush=True)
            ptr, col, val, elim = markowitz_fp(ptr, col, val, ncls, P, maxcost_stop=maxcost_stop, verbose=verbose)
            cw = np.bincount(col, minlength=ncls)
            core_x = np.nonzero(cw > 0)[0]; free = np.nonzero((cw == 0) & ~elim)[0]
            C = len(core_x); newid = -np.ones(ncls, dtype=np.int64); newid[core_x] = np.arange(C)
            col = _relabel(col, newid); self.ncls = ncls; self.nfree = len(free)
            if red is not None:
                os.makedirs(cache, exist_ok=True); np.savez(red, ptr=ptr, col=col, val=val, ncls=ncls, nfree=self.nfree, C=C)
        self.core_shape = (len(ptr) - 1, C, len(col)); self.t["reduction"] = time.time() - t0
        if verbose: print("  core %d x %d, nnz %d; free classes %d (%.0fs)" % (*self.core_shape, self.nfree, time.time() - t0), flush=True)
        t1 = time.time()
        if C <= dense_max:
            import gf
            Mc = np.zeros((len(ptr) - 1, C), dtype=np.int64)
            for r in range(len(ptr) - 1): Mc[r, col[ptr[r]:ptr[r + 1]]] = val[ptr[r]:ptr[r + 1]]
            rk = len(gf.rrefp(Mc, P))
            self.kercore = C - rk; self.exact = True; self.lanczos = None
        else:
            ck = None if cache is None else os.path.join(cache, "fp_lanczos_P%d_q%d_b%d_s%d.npz" % (P, qmask, b, seed))
            info = lanczos_bound(ptr, col, val, C, P, b=b, seed=seed, verbose=verbose, ckpt=ck, check_every=check_every)
            self.kercore = info["gap"]; self.exact = False; self.lanczos = info
        self.t["core"] = time.time() - t1
        self.dimZ = self.kercore + self.nfree
        self.dimH1 = self.dimZ - (1 if self.nontrivial else 0)
        if verbose: print("  dim Z_gauge %s %d; dim H^1(F_%d) %s %d (%.0fs)" % ("=" if self.exact else "<=", self.dimZ, P, "=" if self.exact else "<=", self.dimH1, time.time() - t0), flush=True)
