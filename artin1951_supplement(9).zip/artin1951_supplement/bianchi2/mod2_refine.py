"""Mixed refinements at the two primes above 2 for mod-2 Bianchi classes over E = Q(sqrt-7), in weight 2 at level
prime to 2.  For a mod-2 Galois representation rbar (trivial determinant) unramified at 2 with Frob_2 eigenvalues
x != y, base change gives eigenclasses with (T_v, T_vbar) = (x, x) and (y, y).  We compute the rbar-part of
H^1(Gamma_0(n), F2) (generalized eigenspace of T_q = tr rbar(Frob_q) for small q prime to 2n) and the joint
eigenvalues of T_v, T_vbar on it, over F16.
Usage: python3 mod2_refine.py CASE   (CASE in toy23, toy47, ...)
Author: Dula."""
import sys, json, time
import numpy as np
from bmf import *
from hecke import *
import gf

def root(p, which=0):
    rs = sorted(r for r in range(p) if (r * r - r + 2) % p == 0); return rs[which]

def gen_eigenspace(Ts, evs, D):
    """Joint generalized eigenspace (rows) of the matrices Ts (acting on column vectors) with eigenvalues evs."""
    V = np.eye(D, dtype=np.uint8)                      # rows span the current subspace
    for T, e in zip(Ts, evs):
        if V.shape[0] == 0: break
        S = np.array(T, dtype=np.uint8) ^ (gf.MUL16[e, 1] * np.eye(D, dtype=np.uint8))
        Sp = np.eye(D, dtype=np.uint8)
        for _ in range(D): Sp = gf.matmul16(S, Sp)
        K = gf.kernel16(Sp)                            # rows: column vectors killed by S^D
        # intersect span(V) and span(K)
        M = np.vstack([V, K]); Kk = gf.kernel16(M.T)   # a V + b K = 0
        W = gf.matmul16(Kk[:, :V.shape[0]], V)
        A = np.array(W, copy=True); piv = gf.rref16(A, gf.MUL16, gf.INV16); V = A[:len(piv)]
    return V

def restrict(T, V):
    """Matrix of T on the T-stable subspace spanned by the rows of V: T v_i = sum_j R[j, i] v_j."""
    TV = gf.matmul16(np.array(T, dtype=np.uint8), V.T).T       # rows: T v_i
    R = solve_rows(V, TV)
    return R

def solve_rows(V, W):
    """Coefficients C with W[i] = sum_j C[j, i] V[j]."""
    d = V.shape[0]; X = np.concatenate([V.T, W.T], axis=1)     # columns: V rows then W rows
    A = np.array(X, copy=True); piv = list(gf.rref16(A, gf.MUL16, gf.INV16))
    assert all(p < d for p in piv), "not stable"
    C = np.zeros((d, W.shape[0]), dtype=np.uint8)
    for r, p in enumerate(piv): C[p] = A[r, d:]
    return C

def eigen_pairs(Tv, Tvb):
    """Joint generalized eigenvalue pairs (with multiplicities) of two commuting matrices over F16."""
    D = Tv.shape[0]; out = []
    for a in range(16):
        Va = gen_eigenspace([Tv], [a], D)
        if Va.shape[0] == 0: continue
        Rb = restrict(Tvb, Va)
        for b in range(16):
            Vb = gen_eigenspace([Rb], [b], Va.shape[0])
            if Vb.shape[0]: out.append((a, b, Vb.shape[0]))
    return out

if __name__ == "__main__":
    case = sys.argv[1]; group = sys.argv[2] if len(sys.argv) > 2 else "PGL"
    import cypari2; pari = cypari2.Pari()
    Z = gf.Z
    def zp(k): return gf.f16_pow(Z, k % 5)
    if case == "toy23":
        # rbar = mod-2 representation of 23.2.a.a = S_3 rep of the Hilbert class field of Q(sqrt-23); traces in F2
        comps = [Comp("Fp", 23, root(23, 0)), Comp("Fp", 23, root(23, 1))]; Nlev = 23
        pari("mf = mfinit([23, 2], 0); f = mfeigenbasis(mf)[1]; co = mfcoefs(f, 200);")
        def trace(p):
            a = pari("lift(co[%d + 1])" % p)                   # polynomial in y, y^2 = y + 1
            c0 = int(pari("polcoef(%s, 0, y)" % a)) % 2; c1 = int(pari("polcoef(%s, 1, y)" % a)) % 2
            assert c1 == 0, ("trace not in F2", p, a)
            return c0
        systems = {"rbar": (trace, sorted(a for a in range(16) if gf.MUL16[a, a] ^ a ^ 1 == 0))}
    elif case == "toy47":
        # rbar = D_5 representation of the class group of Q(sqrt-47) (h = 5): psi(class of (2,1,6)) = z^s
        comps = [Comp("Fp2", 47)]; Nlev = 47
        def cls(p):
            if int(pari("kronecker(-47, %d)" % p)) != 1: return None
            for k, Q in ((0, "Qfb(1,1,12)"), (1, "Qfb(2,1,6)"), (2, "Qfb(3,1,4)")):
                if len(pari("qfbsolve(%s, %d)" % (Q, p))) > 0: return k
            raise ValueError(p)
        def make(s):
            def trace(p):
                k = cls(p)
                return 0 if k is None else zp(s * k) ^ zp(-s * k)
            return trace
        systems = {"rbar (psi(p2) = z)": (make(1), [zp(1), zp(4)]), "rbar' (psi(p2) = z^2)": (make(2), [zp(2), zp(3)])}
    else:
        raise SystemExit("unknown case")
    t0 = time.time()
    L = Level(comps, field="F2", name=case, group=group); K = L.cohomology(); D = K.shape[0]
    print("%s [%s]: level norm %d, n = %d, dim H^1(Gamma_0(n), F2) = %d  (%.1fs)" % (case, group, Nlev ** 2, L.n, D, time.time() - t0), flush=True)
    # Hecke operators: v, vbar and small primes q prime to 2N
    primes = [("v", (0, 1), 2, "split2"), ("vbar", (1, -1), 2, "split2"), ("(3)", (3, 0), 3, "inert"), ("(5)", (5, 0), 5, "inert"),
              ("(sqrt-7)", (-1, 2), 7, "ram"), ("q11", (1, 2), 11, "split"), ("q11bar", (3, -2), 11, "split"), ("(13)", (13, 0), 13, "inert"),
              ("q23", None, 23, "split"), ("q29", None, 29, "split"), ("(17)", (17, 0), 17, "inert"), ("(19)", (19, 0), 19, "inert")]
    def find_pi(p):
        for y in range(1, 20):
            for x in range(-40, 40):
                if onorm((x, y)) == p: return (x, y)
    Ts = {}; piv = None
    for name, pi, p, typ in primes:
        if p == Nlev: continue
        if pi is None: pi = find_pi(p)
        t1 = time.time(); T, ok, piv = hecke_matrix(L, K, pi, pivots=piv); assert ok
        Ts[name] = (T.astype(np.uint8), p, typ)
        print("  T_%s (pi = %s): done (%.1fs)" % (name, pi, time.time() - t1), flush=True)
    names = [k for k in Ts if k not in ("v", "vbar")]
    # commutation check
    for a in ["v", "vbar"] + names[:3]:
        for b in ["v", "vbar"] + names[:3]:
            assert (gf.matmul16(Ts[a][0], Ts[b][0]) == gf.matmul16(Ts[b][0], Ts[a][0])).all()
    print("  Hecke operators commute", flush=True)
    res = {"case": case, "group": group, "n": L.n, "dimH1": D, "systems": {}}
    for sname, (trace, xy) in systems.items():
        evs = []
        for k in names:
            T, p, typ = Ts[k]; t = trace(p)
            evs.append(t if typ != "inert" else int(gf.MUL16[t, t]))
        V = gen_eigenspace([Ts[k][0] for k in names], evs, D)
        d = V.shape[0]
        out = {"eigenvalues used": dict(zip(names, evs)), "Frob2 eigenvalues x, y": xy, "dim": d}
        print("  system %s: predicted T_q eigenvalues %s; Frob_2 eigenvalues %s; generalized eigenspace dim %d" % (sname, dict(zip(names, evs)), xy, d), flush=True)
        if d:
            Rv = restrict(Ts["v"][0], V); Rvb = restrict(Ts["vbar"][0], V)
            pairs = eigen_pairs(Rv, Rvb)
            print("    (T_v, T_vbar) generalized eigenvalue pairs (value, value, multiplicity):", pairs, flush=True)
            out["pairs"] = pairs
            mixed = [(a, b, m) for a, b, m in pairs if a != b and {a, b} == set(xy)]
            out["mixed"] = mixed
            print("    mixed refinements (x, y) or (y, x):", mixed if mixed else "none", flush=True)
        res["systems"][sname] = out
    json.dump(res, open("mod2_refine_%s_%s.json" % (case, group), "w"), indent=1, default=int)
    print("done (%.1fs)" % (time.time() - t0))
