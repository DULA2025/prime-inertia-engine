"""Direction (a), done as a test: for the models N = 23, 31, 47, check that the mixed (T_v, T_vbar) = (x, y), (y, x)
eigenvectors are eigenvectors of T_q with eigenvalue tr rbar(Frob_q) for EVERY prime q of E = Q(sqrt-7), prime to 2N,
with N(q) <= QMAX (split q of norm p: t_p; inert q = (p), norm p^2: t_p^2; q = (sqrt-7): t_7).
Usage: python3 extend_checks.py N ORBIT QMAX        Author: Dula."""
import sys, json, time
import numpy as np
import cypari2
from o7 import *
from bmf import *
from hecke import *
import gf
from mod2_refine import root, gen_eigenspace, restrict
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
N = int(sys.argv[1]); orb = int(sys.argv[2]); QMAX = int(sys.argv[3])
pari("mf = mfinit([%d, 2], 0); L = mfeigenbasis(mf); P = mffields(mf)[%d]; nf = nfinit(P); co = mfcoefs(L[%d], %d); dec = idealprimedec(nf, 2);" % (N, orb, orb, QMAX + 2))
k = next(k for k in range(1, int(pari("#dec")) + 1) if int(pari("dec[%d].f" % k)) in (2, 4)
         and pari("my(m = nfmodprinit(nf, dec[%d]), u = nfmodpr(nf, lift(co[3]), m)); u != 0 && u^2 != 1" % k) == 1)
pari("modP = nfmodprinit(nf, dec[%d]);" % k)
mc = [int(c) % 2 for c in pari("Vecrev(lift(modP[#modP]))")]
def ev16(cs, th):
    r = 0; pw = 1
    for c in cs:
        if c: r ^= pw
        pw = int(gf.MUL16[pw, th])
    return r
th = [t for t in range(16) if ev16(mc, t) == 0][0]
def to16(expr):
    cs = [int(c) % 2 for c in pari("my(z = %s, w = z.pol); if(type(w) == \"t_POL\", Vecrev(lift(w)), [lift(w)])" % expr)]
    return ev16(cs, th)
TR = {p: to16("nfmodpr(nf, lift(co[%d + 1]), modP)" % p) for p in [int(q) for q in pari("primes([3, %d])" % QMAX)] if N % p}
x = to16("nfmodpr(nf, lift(co[3]), modP)"); y = int(gf.INV16[x])
split = int(pari("kronecker(-7, %d)" % N)) == 1
comps = [Comp("Fp", N, root(N, 0)), Comp("Fp", N, root(N, 1))] if split else [Comp("Fp2", N)]
t0 = time.time(); Lv = Level(comps, field="F2", group="PGL"); K = Lv.cohomology(); D = K.shape[0]
# all primes q of E with N(q) <= QMAX, prime to 2N
qs = []
for p in [int(q) for q in pari("primes([3, %d])" % QMAX)]:
    if N % p == 0: continue
    kr = int(pari("kronecker(-7, %d)" % p))
    if p == 7: qs.append(("(sqrt-7)", (-1, 2), 7, "ram"))
    elif kr == 1:
        pi = next((xx, yy) for yy in range(1, 60) for xx in range(-120, 120) if onorm((xx, yy)) == p)
        qs += [("q%d" % p, pi, p, "split"), ("q%dbar" % p, oconj(pi), p, "split")]
    elif p * p <= QMAX: qs.append(("(%d)" % p, (p, 0), p, "inert"))
Ts = {}; piv = None
for nm, pi, p, typ in [("v", (0, 1), 2, ""), ("vbar", (1, -1), 2, "")] + qs:
    T, ok, piv = hecke_matrix(Lv, K, pi, pivots=piv); assert ok; Ts[nm] = (T.astype(np.uint8), p, typ)
def evq(nm):
    T, p, typ = Ts[nm]; t = TR[p]; return t if typ != "inert" else int(gf.MUL16[t, t])
first = [q[0] for q in qs[:6]]
V = gen_eigenspace([Ts[q][0] for q in first], [evq(q) for q in first], D)
Rv = restrict(Ts["v"][0], V); Rvb = restrict(Ts["vbar"][0], V)
out = {"N": N, "QMAX": QMAX, "dimH1": D, "rbar_dim": int(V.shape[0]), "primes_tested": [q[0] for q in qs[6:]], "results": {}}
for a, b in [(x, y), (y, x)]:
    Va = gen_eigenspace([Rv, Rvb], [a, b], V.shape[0]); W = gf.matmul16(Va, V)
    assert W.shape[0] == 1
    c = W[0]; bad = [q[0] for q in qs[6:] if not (gf.matmul16(Ts[q[0]][0], c[:, None])[:, 0] == gf.MUL16[evq(q[0]), c]).all()]
    out["results"]["%d_%d" % (a, b)] = {"failures": bad}
    print("N = %d: mixed (%d, %d): tested at %d primes q (N(q) <= %d) not used to define the rbar-part; failures: %s"
          % (N, a, b, len(qs) - 6, QMAX, bad if bad else "none"), flush=True)
json.dump(out, open("extend_checks_N%d.json" % N, "w"), indent=1)
print("done (%.0fs)" % (time.time() - t0))
