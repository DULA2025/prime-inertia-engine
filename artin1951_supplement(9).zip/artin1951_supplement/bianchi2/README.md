# Mod-2 Bianchi classes with mixed refinements at the primes above 2 (21 October 2026)

Author: Dula.

## The question

This is Question 3 of §9 of the note (Proposition 9.1(iii)). Take E ∈ 𝓕₇, so that 2 = v v̄ splits in E, and let ρ̄₂ be the residual representation of ρ. A residual starting point in the parallel direction would be a mod-2 Bianchi eigenclass of level 1951·O_E in the system of ρ̄₂|G_E with eigenvalues (x, y) for (T_v, T_v̄). Here x ≠ y are the Frobenius eigenvalues at 2. Base change of the forms of Theorem D gives only (x, x) and (y, y).

**Status (evening of 21 October).**
- **Level 1951·O_E:** **computed** (`run_big.py 1951`, block Lanczos over F₁₆; section "Level 1951·O_E"). dim H¹(Γ₀(1951·O_E), F₁₆(χ̄⁻¹∘N)) = 663 for PGL₂(O_E). The ρ̄₂-part has dimension 27, with (T_v, T_v̄) multiplicities (x,x) 7, (x,y) 3, (y,x) 3, (y,y) 14. Each of the four contains exactly one joint eigenvector with the eigenvalues of ρ̄₂ at all 24 Hecke operators computed [T]. So the mixed classes asked for exist at this level, at least for these operators; that they lie in the system of ρ̄₂|G_E is supported, not proved [C].
- **The icosahedral model of level 633** (index 449 440; the smallest weight-one level with projective image A₅) has been computed: its ρ̄-part contains one joint eigenvector in each of (x,y), (y,x), (x,x), (y,y), with the ρ̄ eigenvalues at all 23 Hecke operators used [T].
- New engines: a sparse direct elimination, a block Lanczos solver over F₁₆, and a memory-lean pipeline. Each was checked against the dense engine and against the others (`validate_sparse.log`, and four computations of the 633 model by different routes).

## Method

**The group.** Γ = PSL₂(O), O = ℤ[ω], ω = (1+√−7)/2, has the presentation

PSL₂(O) = ⟨A, B, U | B², (BA)³, AUA⁻¹U⁻¹, (BAU⁻¹BU)²⟩,

with A = (1 1; 0 1), B = (0 1; −1 0) and U = (1 ω; 0 1). This is Finis–Grunewald–Tirao, *The cohomology of lattices in SL(2, ℂ)*, Experiment. Math. 19 (2010), arXiv:0808.1204, §2.2, eq. (2.10). For PGL₂(O) = PSL₂(O) ⋊ ⟨J⟩ with J = diag(−1, 1), we add the relators J², (JA)², (JB)² and (JU)².

**Cohomology.**
- Shapiro's lemma: H¹(Γ₀(𝔫), V_ε) = H¹(Γ, M), where M is the space of functions F on primitive rows mod 𝔫 with F(λv) = ε(λ)F(v).
- Cocycles are computed by Fox calculus on the coset graph P¹(O/𝔫), gauge-fixed to vanish on a BFS spanning tree, by exact elimination. Over F₂ this uses bit-packed rows; it also runs over F₁₆ and over F_P.
- With a non-trivial nebentypus ε, the gauge-fixed cocycles contain one coboundary, δm_par, where m_par is the ε-transport of m(root) = 1 along the tree. Then H¹ is the quotient by it (`control_A5_31.py` does this; with trivial ε over F₂, δm_par = 0).

**Hecke operators.**
- T_π = Γ₀ diag(1, π) Γ₀, with the N(π) + 1 representatives (1 β; 0 π) and (π 0; 0 1).
- On the Γ₀-cocycle ψ(h) = f(h)(0, 1): (Tψ)(h) = Σᵢ ε(d_{αᵢ})⁻¹ ψ(hᵢ), where αᵢ h = hᵢ α_{s(i)}.
- Matrices are read off on the Schreier generators h_{x,g} of non-tree edges, where ψ(h_{x,g}) = ε(λ_x) f_g(x), and checked on extra edges.
- Elements of Γ₀ are written as words by the Euclidean algorithm in O.
- **Nebentypus convention** (found in the control below): the engine with ε⁻¹∘N realises a newform f ∈ S₂(N, ε) with T_q ↦ a_q; with ε∘N it realises the complex-conjugate form, T_q ↦ a_q/ε(q).

**PSL₂ versus PGL₂.** Galois representations are attached to the GL₂ (trivial central character) side, so all model results use PGL₂. PSL₂(O) has more cohomology:
- **Characteristic 0.** At levels (11), (23), (31) and (47), the PGL₂ cohomology is exactly the base changes, while PSL₂ has extra classes. At (23) these are a cubic orbit and two rational classes.
- **Mod 2.** At level 23·O_E, PSL₂ doubles the multiplicities: (x,x)×4, (x,y)×2, (y,x)×2, (y,y)×4, in `mod2_refine_toy23_PSL.log`.

The first run used PSL₂ and is kept only as a record of this point.

## Large levels: sparse elimination and block Lanczos

The dense engine stores the whole system and stops near n ≈ 10⁴. Three further engines compute the same H¹ (same presentation, gauge, nebentypus and Hecke operators) at larger n.

**Sparse direct elimination (`sparse_h1.py`, drivers `run_sparse.py`, `run_sparse_auto.py`).**
- The relator equations (8 per coset) are built in numba, without the tree columns.
- *Closure.* Equations with one term set a column to zero; equations with two terms make one column a multiple of another (union–find with F₁₆ factors). Repeating this leaves about 0.54 n classes of columns (`closure`).
- *Deduplication* of the rewritten equations, then *Markowitz elimination* (column of smallest weight, shortest pivot row) up to a fill bound of 8 × the deduplicated nnz.
- The remaining *core* is compressed by random sparse row combinations and solved by dense elimination over F₁₆; above 1000 columns the elimination is bitsliced (`gf16_bits.py`: four bit-planes, 64 columns per word, the 15 multiples of the pivot row precomputed).
- The kernel is lifted through the elimination records and checked against **every** original equation.
- Hecke operators are read off on d pivot columns and checked on 8 more; the matrices are d × d.

**Block Lanczos over F₁₆ (`lanczos16.py`).**
- Montgomery's block Lanczos (Eurocrypt 1995) for the symmetric matrix A = Mᵀ D M, where M is the core and D a random invertible diagonal. In characteristic 2 all signs in Montgomery's recurrences are +. The selection of the columns S_i is his Gauss–Jordan step on [V_iᵀ A V_i | I], with F₁₆ inverses.
- Blocks of b = 64w vectors are bitsliced as arrays (N, 4, w) of 64-bit words. Products of an N × b block with a b × b matrix, and inner products of two blocks, use tables over pairs of columns (256 entries per pair). The selection step works on bit-planes as well.
- The null space of M is extracted at the end from span(x − Y, V_m), by random row compressions of M, and checked against every row of M.
- **Completeness.** Let K = ker M ∩ span(x − Y, V_m) be the space found, and 𝒲 = W₀ ⊕ … ⊕ W_{m−1} the Krylov space, of dimension Σ|S_i|.
  - All V_i lie in im A. The W_i are A-orthogonal, with W_iᵀ A W_i invertible, and V_m is A-orthogonal to every W_i. So 𝒲 ⊕ span V_m ⊆ im A, and
    dim K ≤ dim ker M ≤ dim ker A ≤ g := N − Σ|S_i| − rank V_m.
  - If dim K = g, then K = ker M.
  - If dim K < g but ker A ∩ span(x − Y, V_m) has dimension g, then ker A lies in that span, and again K = ker M. This covers the case where Mᵀ D M has kernel beyond ker M.
  - Otherwise the block is widened to at least g + 64 and the run is repeated. If the block was already that wide, the run is repeated with another D and start block.
  - Example: at N = 127 (core of 553 columns) every run stops with V_m ≠ 0 at Krylov dimension 494. The term rank V_m = 1 gives g = 58, the kernel found.
- The state is saved every 10 minutes, so that a run can resume.

**Memory-lean pipeline (`sparse_big.py`, driver `run_big.py`).**
- Closure with path compression; equations rewritten into a compressed sparse row array over class ids and deduplicated by hashing.
- Markowitz elimination **in rounds**. In each round an independent set of pivots (disjoint row sets) of smallest Markowitz cost (w − 1)(l − 1) is eliminated at once. The cost ceiling rises from 0 to 8192, with a deduplication after each level.
- The core goes to block Lanczos (or to the dense method if it has at most 6000 columns).
- The kernel is kept on the classes, bitsliced; the value on an edge u is rfac(u) · V(class(u)).
- Every relator equation at every coset is re-derived on the fly to check the lifted kernel.
- δm_par is located in the kernel and checked on every edge.
- The stages (reduction, core kernel, Lanczos state, Hecke matrices) are saved in `big_cache_<label>/`, so a run can be resumed.

## Validation (`validate.py`, `validate.log`; coefficients F_P, P = 10⁹ + 7)

- **Presentation.** All 8 relators are ±I, and the word decomposition reproduces 500 random words.
- **Dimensions.** dim H¹ for PSL₂ equals LMFDB's SL(2) cusp-form dimension (page `sl2dims/2.0.7.1`) plus the number of cusps at the levels 1.1, (2), 25.1, 28.2, 36.2 and 23.1. Six levels, all equal.
- **Base change of 14a1** at (2)(√−7). The eigenvalues are T_(3) = −2, T_(5) = −10, T_𝔮₁₁ = T_𝔮̄₁₁ = 0 and T_(13) = −10, that is a_p or a_p² − 2p, beside the Eisenstein value Tr(π).
- **PGL₂ = base change.** At (11), (23), (31) and (47) the PGL₂ cohomology is the base change:
  - T_v has the minimal polynomial of a₂ at level 11, 23, 31 and 47;
  - BC(11a1) has T_(3) = −5 and T_v = −2.

**Sparse engines** (`validate_sparse.py`, `validate_sparse.log`):
- Block Lanczos on random sparse systems with planted kernels gives the same null space as dense elimination. With a block narrower than the kernel, it finds a block's worth of kernel vectors, and N − (Krylov dimension) still equals the kernel dimension.
- dim H¹(Γ₀(N O_E), F₁₆) for PGL₂ with trivial character is computed at N = 23, 31, 47, 79, 103, 127, 143 by three routes: `sparse_h1` with the dense core; `sparse_big` with the Lanczos core forced; `sparse_big` with the dense core. All three agree, and at 23, 31, 47, 79 they equal the dense engine (14, 15, 23, 42).
- The 633 model was computed four times: two dense cores with different random choices, the Lanczos core, and the memory-lean pipeline. All four give the same results (table in the 633 section).

## Models [T] (exact computations over F₂ / F₁₆; `run_model.py N ORBIT`, logs `model_N*.log`, data `model_N*.json`)

A model is a newform of odd level N whose mod-2 representation ρ̄ (at a prime 𝔓 | 2 of the Hecke field) is unramified at 2 with x ≠ y, with both refinements present over ℚ. The newform has weight 2, or weight one for 633. These are the models of the 1951 situation over ℚ. The models found by the searches below are dihedral or reducible. The weight-one form of level 633 is icosahedral.

Every model run here, over E = ℚ(√−7) and for PGL₂, gives the following. The traces come from a_p mod 𝔓 of the newform. The first four rows use the dense engine (`run_model.py`); the rows from 87 on use the sparse engines below (`run_sparse_auto.py N`, `run_sparse.py`, `run_big.py`; data `sparse_auto_N*.json`, `sparse_N*.json`, `big_N*.json`). At 87, 93, 115 and 143 there are two companion systems, in two Hecke orbits; both give the same table.

| N | ρ̄ (image) | N in E | index n | dim H¹(Γ₀(N O_E), F₂) (F₁₆ for the sparse rows, same dimension) | dim of ρ̄-part | (T_v, T_v̄) pairs: multiplicity | char. 0 (PGL₂) | time |
|---|---|---|---|---|---|---|---|---|
| 23 | S₃, x, y ∈ F₄ | split | 576 | 14 | 6 | (x,x) 2, **(x,y) 1, (y,x) 1**, (y,y) 2 | 2 = base change | 7 s |
| 31 | S₃, x, y ∈ F₄ | inert | 962 | 15 | 4 | (x,x) 1, **(x,y) 1, (y,x) 1**, (y,y) 1 | 2 = base change | 8 s |
| 47 | D₅, x, y = ζ₅^{±1} ∈ F₁₆ | inert | 2210 | 23 | 4 | (x,x) 1, **(x,y) 1, (y,x) 1**, (y,y) 1 | 4 = base change | 13 s |
| 79 | D₅, x, y = ζ₅^{±1} ∈ F₁₆ | split | 6400 | 42 | 6 | (x,x) 2, **(x,y) 1, (y,x) 1**, (y,y) 2 | not computed | 47 s, 3 GB |
| 87 | dihedral (ℚ(√−87)), x, y ∈ F₄ | 3 inert, 29 split | 9000 | 107 | 16 | (x,x) 4, **(x,y) 4, (y,x) 4**, (y,y) 4 | not computed | 76 s |
| 93 | dihedral (ℚ(√−31)), x, y ∈ F₄ | 3, 31 inert | 9620 | 86 | 36 | (x,x) 10, **(x,y) 8, (y,x) 8**, (y,y) 10 | not computed | 65 s |
| 103 | dihedral (ℚ(√−103)), x, y ∈ F₁₆ | inert | 10 610 | 45 | 4 | (x,x) 1, **(x,y) 1, (y,x) 1**, (y,y) 1 | not computed | 43 s |
| 115 | dihedral (ℚ(√−23)), x, y ∈ F₄ | 5 inert, 23 split | 14 976 | 100 | 40 | (x,x) 12, **(x,y) 8, (y,x) 8**, (y,y) 12 | not computed | 88 s |
| 127 | dihedral (ℚ(√−127)), x, y ∈ F₁₆ | split | 16 384 | 58 | 6 | (x,x) 2, **(x,y) 1, (y,x) 1**, (y,y) 2 | not computed | 48 s |
| 143 | dihedral (ℚ(√−143)), x, y ∈ F₁₆ | 11 split, 13 inert | 24 480 | 142 | 8 | (x,x) 2, **(x,y) 2, (y,x) 2**, (y,y) 2 | not computed | 89 s |
| **633** | **A₅** (weight one, 633.1.m.b), x, y ∈ F₁₆, nebentypus of order 5 mod 2 | 3 inert, 211 split | 449 440 | 348 (F₁₆) | 24 | (x,x) 8, **(x,y) 4, (y,x) 4**, (y,y) 8 | 68 = base change (nebentypus: Teichmüller lift; bound over F_P) | 296–616 s |

**How the classes were checked:**
- The ρ̄-part is the joint generalized eigenspace of T_q for six small primes q prime to 2N, with eigenvalue tr ρ̄(Frob_q), or tr ρ̄(Frob_q)² at inert q.
- For the dense rows: each mixed generalized eigenspace is 1-dimensional, and its vector is an eigenvector with the eigenvalue of ρ̄ at 6–9 further primes: 𝔮₂₃, 𝔮₂₉, 𝔮₃₇, 𝔮₄₃ (with conjugates where tested) and (13). In `verify_mixed.py` for N = 23, 𝔮₅₃ is tested as well.
- **Every split prime up to 200** (`extend_checks.py N ORBIT 200`, logs `extend_checks_N{23,31,47}.log/.json`). For N = 23, 31 and 47 both mixed vectors are eigenvectors with the eigenvalue of ρ̄ at every split prime 𝔮 of norm ≤ 200 not used above: 38 primes for N = 23 and 40 for N = 31 and 47 (𝔮 and 𝔮̄ for each rational prime). No failure. For dihedral ρ̄ this is the residual test that is available: the Frobenius traces at all primes in a range. There is no quintic, so the cycle-type conditions used for the Doud–Moore fields do not apply.
- For the sparse rows: inside each mixed generalized eigenspace, the space of joint eigenvectors with the eigenvalues of ρ̄ at all 23 or 24 operators (v, v̄, (3), (5), (13), (√−7) and 𝔮, 𝔮̄ for q = 11, 23, …, 79, those prime to the level) has dimension 1 (87, 127, 143, 633) or 2 (93, 115). At 103 each mixed generalized eigenspace is 1-dimensional, and its vector is an eigenvector at the 16 further operators 𝔮, 𝔮̄ (q = 23, …, 79).
- The Hecke operators commute.
- For N = 23 the cohomology was recomputed over F₁₆ with an independent elimination: dimension 14 again.

**Conclusions:**
- **Mixed classes are torsion.** For N = 23, 31 and 47 the characteristic-0 cohomology at this level, with trivial nebentypus, is the base change only, which reduces to (x,x) and (y,y). So the mixed classes come from 2-power torsion: they are not reductions of characteristic-0 classes at this level. On 26 October this was extended to every nebentypus that reduces to the trivial one. At 23 the mixed classes still lift modulo 4, so the torsion they come from has order at least 4 there. See "Lifting the mixed classes to characteristic 0" below.
- **Fit with the defect.** This is consistent with the defect ℓ₀ = 1 of weight-2 Bianchi forms: the mixed deformation problem has its residual point but, here, no weight-2 points in characteristic 0. There is no R = T theorem at ℓ = 2 here, so this is consistency, not a prediction checked.

**Label.** The table is an exact computation [T]. Characteristic 0 was computed for 23, 31 and 47 (all nebentypes that reduce to the trivial one), and for 633 and 1951 with the Teichmüller lift of the nebentypus. That these classes belong to ρ̄|G_E (rather than to another system with the same eigenvalues at the primes tested) is supported by the eigenvalues, not proved.

## Searches for models

**First search (`find_models.py`, `find_models.log`; superseded).** Prime levels N ≤ 400. It compared each mod-2 system only with its own Galois conjugates, so it missed companions in other orbits or at other primes above 2.

**Trivial character (`find_models2.py NMAX [DMAX] [NMIN]`; logs `find_models2.log` for N ≤ 151 and `find_models2_153_400.log` for 153 ≤ N ≤ 400).** Odd squarefree N ≤ 400, orbits of degree ≤ 24. All mod-2 systems are mapped into F_{2^12}, and companions are searched across orbits and primes above 2. Models occur at 39 levels: 23, 31, 47, 71, 79, 87, 93, 103, 115, 119, 127, 143, 151, 159, 161, 191, 199, 215, 223, 231, 235, 237, 239, 247, 253, 255, 257, 263, 287, 303, 309, 319, 321, 327, 335, 341, 367, 381, 391. All are dihedral: t_p = 0 at every p ≤ 150 inert in a quadratic field ℚ(√D), D | N, D ≡ 1 mod 4 (imaginary except at 257 and 321). The index printed for N divisible by 7 is that of the base-change level (√−7)·(N/7)·O_E. In `find_models2.log` the labels "(orbit a, Pb, f=c)" read (prime index a, residue degree b, residue degree c = b): the orbit was not printed. This formatting error was found on 21 October and is fixed in the script; levels and types are unaffected. Only systems whose residue field has degree dividing 12 are compared, so dihedral models with larger residue fields are not in this list: the first search found such models at N = 167 and 271 (class number 11, residue degree 10).

**With nebentypus (`find_models3.py LEVELS [NB] [TL]`, logs `find_models3.log` and `find_models3_redo.log`).**
- *Why characters are needed.* ρ̄₂ has nebentypus of order 5. If ρ̄ has projective image A₅ = PSL₂(F₄), then ρ̄ = λ ⊗ s with s: G_ℚ → SL₂(F₄) and λ a character (GL₂(F₄) = F₄^× × SL₂(F₄)). At a prime p where inertia acts through an element of order 3 or 5 and p ≡ 1 mod 3 (resp. mod 5), a twist by a character of order 3 (resp. 5) lowers the conductor exponent from 2 to 1; this is why ρ̄₂ has conductor 1951. So a twist-minimal icosahedral ρ̄ has det = ε with odd part of order dividing 15. Characters of 2-power order are trivial mod 2 but may be needed for a lift to characteristic 0, so all even ε whose odd part has order 1, 3, 5 or 15 are searched. Every mod-2 eigenform of weight 2 on Γ₁(N), N ≥ 5, lifts to characteristic 0 (Γ₁(N) is torsion-free), so this covers every ρ̄ of conductor N up to twist.
- *Projective image.* u_p = a_p²/ε(p) mod 𝔓 is a class function on PGL₂: u = 0 for elements of order 1 or 2, u = 1 for order 3, u ∈ F₄ − F₂ for order 5, and u ∉ F₄ otherwise. A system is called A₅ when all u_p (p ≤ 200) lie in F₄ and both 1 and a value in F₄ − F₂ occur. A companion class is called reducible when {p : u_p = 0} is the kernel of a character of odd order modulo a divisor of N. In characteristic 2 the subgroup A₄ of A₅ is a Borel subgroup, so "A₄" is reducible.
- *Convention check.* ε(p) from `chareval` is checked against a_{p²} = a_p² − p ε(p) for p ≤ 13.
- **Result** (`find_models3.log`, 67 min; levels: all odd N ≤ 150, and 161, 175, 189, 203, 217; traces at p ≤ 200). The last five are 7N′ with N′ small: over E an inertia group of order 2 at 7 disappears, so such a level can shrink over E.
  - **Models.** Among 1130 mod-2 systems there are 26 companion classes, at N = 23, 31, 47, 65, 69, 71, 77, 79, 87, 91, 93, 103, 115, 119, 123, 127, 133, 135, 141, 143, 161, 175 (two), 203 and 217 (two). Twenty are dihedral. Six are reducible (ρ̄^ss = ψ₁ ⊕ ψ₂ with ψ₁/ψ₂ of order 3 or 5), at 65, 91, 123, 133, 175 and 203. **None is icosahedral.**
  - **Nebentypus non-trivial mod 2,** as for ρ̄₂: this holds for the six reducible classes and for the dihedral classes at 77 and 217. The one at 77 comes from ℚ(√−7) = E itself, so it is reducible over E. The one at 217 comes from ℚ(√−31), with nebentypus of order 3 and Frob₂ of projective order 9. It needs coefficients in F₆₄ at index 7696, beyond the dense F₁₆ method here.
  - **Icosahedral systems.** There are 97, at 22 levels: 25, 31, 33, 43, 67, 73, 75, 77, 91, 93, 99, 101, 103, 107, 111, 123, 125, 129, 131, 133, 175, 217. None has a companion, so only one refinement occurs. 93 are ordinary at 2, and 4 (at 217) are supersingular.
  - **Skipped.** The main run used a limit of 2 × 150 s per newform and skipped 11 newforms, all at levels above 95.
    - Nine have coefficient fields of degree ≥ 80, from characters of order 15 to 48, at levels 97, 119 (two), 123, 143, 175 and 217 (three).
    - The other two, at 117 and 145 (degrees 24 and 26), were completed with a longer limit in `find_models3_redo.log`. They give no model and no icosahedral system.
    - Levels ≤ 95 had no skips.
  - **Reduction.** A newform is reduced modulo a prime of ℚ(χ) when its relative polynomial is squarefree there (397 newforms). Otherwise it goes through the absolute field with a 2-maximal order (291 newforms).
  - Companions are compared among systems whose residue field has degree dividing 24. This covers every icosahedral system, whose residue field lies in F₁₆.

## Control: an icosahedral system that is ramified at 2 (`control_A5_31.py ±1`, logs `control_A5_31_s1.log`, `control_A5_31_s-1.log`, data `.json`) [T]

- **Over ℚ.** The newform of level 31, weight 2, nebentypus ε of order 5 and conductor 31 has a mod-2 representation with projective image A₅ (by the traces at p ≤ 120: u_p ∈ F₄, and orders 3 and 5 occur), residue field F₁₆, and a₂ a unit. It has no companion: only one refinement occurs over ℚ. So ρ̄ is ordinary and ramified at 2. (An A₅ field unramified outside 31 would give an icosahedral Artin representation of conductor 31: there is none of odd type below level 633 (Buzzard–Lauder) and none of even type of prime conductor below 1951 (Doud–Moore).)
- **Over E.** 31 is inert in ℚ(√−7), as 1951 is. The level is 31·O_E (index 962), the nebentypus is ε^{±1}∘N of order 5, and the coefficients are F₁₆: the configuration of the 1951 target, at a small prime.
- **Result.**
  - Gauge-fixed cocycles: 12, containing δm_par; dim H¹ = 11. The 20 Hecke operators commute.
  - The ρ̄-part is 1-dimensional. Its only pair is (T_v, T_v̄) = (a₂, a₂) (codes (14, 14) with ε⁻¹∘N; (3, 3) = a₂/ε(2) with ε∘N). It is an eigenvector with the eigenvalue of ρ̄ at 12 further operators.
  - H¹ splits into six 1-dimensional joint eigenspaces of (T_v, T_v̄): four diagonal pairs and the two off-diagonal pairs (1, ζ₅) and (ζ₅, 1) (codes (0,0), (3,3), (5,5), (13,13), (1,2), (2,1) for ε∘N; with ε⁻¹∘N the off-diagonal pairs are (1, ζ₅⁻¹) and (ζ₅⁻¹, 1)). The two off-diagonal classes restrict non-trivially to the cusp ∞ (cocycle values on the A- and U-loops at the root coset), so they are Eisenstein classes; the four diagonal ones restrict to zero there. All six have T_𝔮 = T_𝔮̄ at the six split primes tested.
- **Reading [C].** When ρ̄ is ramified at 2 the refinement at v is forced to be the unit root a₂, and only (a₂, a₂) occurs, as expected. The mixed classes in the models occur where ρ̄ is unramified at 2 with x ≠ y. The Eisenstein pair (1, ζ₅), (ζ₅, 1) is the reducible analogue: its two characters take different values at v.

## The icosahedral model of level 633 [T]

**The form** (`check_633.py`, log `check_633.log`).
- Buzzard and Lauder computed all weight-one newforms of level ≤ 1500. The smallest level with projective image A₅ is 633 = 3·211, with a character of order 10 (K. Buzzard, A. Lauder, *A computation of modular forms of weight one and small level*, Ann. Math. Québec 41 (2017), 213–219; arXiv:1605.05346). In LMFDB it is 633.1.m.b. Its projective field is the Galois closure of the quintic field 5.1.17839074969.1, of discriminant 3²·211⁴, so it is unramified at 2.
- Recomputed with PARI (about 2 seconds): the odd characters of order 10 modulo 633 form 2 Galois orbits; for Mod(107, 633) the new space has dimension 3, with Galois types D₅ and A₅. For the A₅ form, u₂ = a₂²/ε(2) has minimal polynomial x² − 3x + 1, so Frob₂ has projective order 5. Modulo the prime above 2 (residue degree 4), u_p ∈ F₄ for every p ≤ 300, with the values 1 and F₄ − F₂ both occurring, and u₂ ≠ 0. So ρ̄ has projective image A₅ and x ≠ y.
- The relation a_{p²} = a_p² − ε(p) (weight one) checks the character convention for p ≤ 17. `mfgaloisprojrep` needs the `nflistdata` package, which is not installed, so the projective field is taken from LMFDB.
- **A model of the type of ρ̄₂.** ρ̄ = (633.1.m.b mod 2) is unramified at 2 with x ≠ y. Its conductor is 633 (inertia of order 2 at 3, of order 5 at 211), and its nebentypus modulo 2 is the odd part of the order-10 character, of order 5, as for ρ̄₂. Unlike ρ, it is odd, so it lifts to a weight-one form in characteristic 0.
- 3 is inert and 211 splits in ℚ(√−7), so the index of Γ₀(633·O_E) is 10·212² = 449 440.
- Is 633 the smallest model? Not proved. Modulo 2 the level of an icosahedral ρ̄ can be smaller than the conductor of its characteristic-0 lifts (inertia of 2-power order becomes unipotent), and even icosahedral representations also reduce to models. The search above covers odd N ≤ 150 directly.

**The class over E** (`run_sparse.py 633 1 10 odd A5`; three independent runs).

| run | core solver | elimination | dim H¹ | time | peak memory |
|---|---|---|---|---|---|
| `sparse_633.log` (seed 7) | dense, bitsliced | Markowitz, one pivot at a time | 348 | 616 s | 4.6 GB |
| `sparse_633_seed1234.log` | dense, bitsliced (other random combinations, pivots, check columns) | same | 348 | 601 s | 4.6 GB |
| `sparse_633_lanczos.log` | block Lanczos (b = 256, then 448) | same | 348 | 517 s | 4.6 GB |
| `big_633.log` | block Lanczos | Markowitz in rounds (`run_big.py`) | 348 | 296 s | 0.5 GB |

All four give the same results:
- **The system.** F₁₆ coefficients, nebentypus ε⁻¹∘N with ε of order 10 (order 5 modulo 2); (x, y) = (1, 15) in the encoding of `gf.py`. There are 3 595 520 equations in 1 348 321 non-tree unknowns. The closure leaves 241 995 classes; deduplication leaves 508 793 equations with nnz 1 952 886.
- **The core.** With one-at-a-time Markowitz it is 108 587 × 15 688, with nnz 15 625 281. With rounds it is 35 231 × 14 879, with nnz 6 643 388. Either way its kernel is 349: the dense rank is 15 339, and the two Lanczos runs reach Krylov dimension 15 339 and 14 530 respectively. The kernel is lifted and checked against all 3 595 520 equations.
- **H¹.** δm_par lies in the kernel (checked on every edge), and dim H¹ = 348.
- **Hecke operators.** 23 of them: v, v̄, (5), (13), (√−7), and 𝔮, 𝔮̄ for q = 11, 23, 29, 37, 43, 53, 67, 71, 79. ((3) divides the level.) They commute.
- **The ρ̄-part** (joint generalized eigenspace of (5), (13), (√−7), 𝔮₁₁, 𝔮̄₁₁, 𝔮₂₃) has dimension 24.
- **(T_v, T_v̄) pairs:** (x,x) 8, **(x,y) 4, (y,x) 4**, (y,y) 8.
- **Joint eigenvectors.** Each of the four generalized eigenspaces contains exactly one vector that is an eigenvector of all 23 operators with the eigenvalues of ρ̄: T_v = x, T_v̄ = y (or the other pair), a_q at the split primes, a_q² at the inert ones and a₇ at √−7.

**Reading.** The mixed refinements occur for an icosahedral ρ̄ of the type of ρ̄₂: nebentypus of order 5 modulo 2 and Frob₂ of projective order 5. This is the first non-dihedral model computed. As for the dihedral models, "in the system of ρ̄" is supported by the eigenvalues at 23 operators, not proved.

Characteristic 0 (26 October; section "Lifting the mixed classes to characteristic 0").
- With the nebentypus χ, the Teichmüller lift of the mod-2 one, the characteristic-0 cohomology at 633·O_E consists of the 68 base changes: dim over F_P ≤ 68 for two primes. So the mixed classes do not lift with this nebentypus.
- For the three quadratic twists of the nebentypus, the F_P bounds exceed the number of base changes, and the question is open there.

## Level 1951·O_E [T] (`run_big.py 1951`, log `big_1951.log`, record `big_N1951.json`)

**Setup.**
- E = ℚ(√−7). 1951 is inert in E, so the level 1951·O_E is prime, O/(1951) = F_{1951²}, and the index of Γ₀(1951·O_E) in PGL₂(O_E) is 1951² + 1 = 3 806 402.
- Coefficients F₁₆, with nebentypus ε⁻¹∘N, where ε = χ is the character of order 5 of Theorem D: χ(3) = e(2/5), and 3 generates (ℤ/1951)^×. This is the engine convention found with the control at level 31: Level(ε⁻¹∘N) realises f ∈ S₂(N, ε) with T_q ↦ a_q.
- **Eigenvalues of ρ̄₂.** They come from the Galois side, as in Theorem D (`../questions/mod2_general.py`, labelling L = 0, the one that passed there; the Frobenius classes are in `../questions/classes_1951.json`; the run read the extract `classes_1951_small.json`, which agrees with it at all 430 primes below 3000). The formula is ā_ℓ = ψ̄(ℓ)·t̄(class of Frob_ℓ), with ψ̄(ℓ) = z^{log₃ ℓ}. Here t̄ = 0 on the classes 1 and 2A, 1 on 3A, φ − 1 on 5A and φ on 5B.
  - ā₂ = z⁴ and χ̄(2) = z³, so (x, y) = (z + z², 1 + z³), the codes (6, 9) of `gf.py`.
  - ā₃, ā₅, ā₇, ā₁₁, ā₁₃ = 7, 0, 0, 3, 8.
  - As Bianchi eigenvalues: T_𝔮 ↦ ā_q at split q, T_(q) ↦ ā_q² at inert q, T_(√−7) ↦ ā₇.

**The computation.**

| stage | result | time |
|---|---|---|
| equations (8 relators at each of 3 806 402 cosets) | 30 451 216 rows, 11 419 207 non-tree unknowns, nnz 103 518 843 | 10 s |
| closure under 1- and 2-term equations | 2 037 851 classes, 9 954 027 equations left | 23 s |
| deduplication | 4 286 561 equations, nnz 16 452 793 | 7 s |
| Markowitz in 256 rounds (cost ≤ 8192) | 1 911 485 classes eliminated; core 301 036 × 126 366, nnz 56 054 527 | 4 min |
| block Lanczos, b = 256 | 492 iterations; Krylov dimension 125 702, V_m = 0, so the kernel has dimension ≤ 664; 256 kernel vectors (the block is narrower than the kernel) | 58 min |
| block Lanczos, b = 768 | 164 iterations; Krylov dimension 125 702, V_m = 0; null space of the core 664 = the bound, so **the kernel is complete** | 34 min |
| lifting, and check of all 30 451 216 equations (re-derived on the fly) | 664 gauge-fixed cocycles, all equations satisfied | 12 s |
| δm_par (checked on all 15 225 608 edges) | lies in the kernel; **dim H¹ = 663** | 9 s |
| 24 Hecke operators | they commute | 7 min |

Peak memory was about 3 GB. Background commands here are limited to 2 hours. The run was stopped after the first Lanczos run, to switch to the corrected completeness test (incident (2) in `../trace/STATUS.md`), and resumed from the cached stages; `big_1951.log` shows both slots.

**Result.**
- The ρ̄₂-part of H¹ has **dimension 27**. This is the joint generalized eigenspace of T_(3), T_(5), T_(13), T_(√−7), T_𝔮₁₁, T_𝔮̄₁₁ at the eigenvalues of ρ̄₂.
- (T_v, T_v̄) generalized eigenvalue pairs on it: (x,x) 7, **(x,y) 3, (y,x) 3**, (y,y) 14.
- Each of the four generalized eigenspaces contains **exactly one** vector that is an eigenvector of all 24 operators with the eigenvalues of ρ̄₂. The operators are v, v̄, (3), (5), (13), (√−7), and 𝔮, 𝔮̄ for q = 11, 23, 29, 37, 43, 53, 67, 71, 79. The eigenvalues are x and y (or y and x) at v and v̄, ā_q at the split primes, ā_q² at the inert ones and ā₇ at √−7.
- **Further operators** (`extend_big.py 1951 200 30`, `extend_big_N1951.log/.json`, 40 min). The four vectors are also eigenvectors, with the eigenvalues of ρ̄₂, at 26 further operators: T_𝔮 and T_𝔮̄ for the 12 split primes 79 < q ≤ 200, and T_(17), T_(19). So they have the eigenvalues of ρ̄₂ at every prime of E of norm ≤ 200 (48 prime ideals), and at (17) and (19): 50 operators in all.
- **Independent run** (`recheck_core.py big_cache_N1951 2 12`, `recheck_core_N1951.log`, `recheck_core_big_cache_N1951_s2.json`, 53 min). Block Lanczos on the same core, with another diagonal D and another start block, finds a kernel of 664 with the same span: the union has rank 664.

**Reading.**
- [T] For E = ℚ(√−7) there are mod-2 classes of level 1951·O_E, nebentypus χ̄⁻¹∘N and coefficients F₁₆, with (T_v, T_v̄) = (x, y) and with (y, x), each an eigenvector with the eigenvalues of ρ̄₂|G_E at every Hecke operator computed. This is the residual input asked for in Question 3 for case (iii) of Proposition 9.1.
- [C] That these classes lie in the system of ρ̄₂|G_E is supported by the eigenvalues, not proved. A proof would need more than finitely many eigenvalues, for example an identification of the Galois representation attached to the class (Scholze) with ρ̄₂|G_E.
- **Not known.**
  - Lifting to characteristic 0 (26 October; section "Lifting the mixed classes to characteristic 0").
    - With the nebentypus χ⁻¹∘N of the computation, the answer is no: the characteristic-0 cohomology is the 161 base changes.
    - With a nebentypus twisted by a character of order 2^k, the answer is not known: k = 1 (not computed), k = 2, …, 5 not computed. The first-order 2-adic obstructions vanish for every twist.
  - Whether the deformation theory of case (iii) then applies at ℓ = 2. There is no R = T theorem at ℓ = 2 here.
- None of this proves the modularity of ρ|G_E or of ρ.

## Lifting the mixed classes to characteristic 0 (26 October) [T]

**Question.** Are the mixed classes reductions of Bianchi eigenforms of weight 2, at the same level, in characteristic 0? This was Grok's suggested next step.

**Which nebentypus.**
- F₁₆(χ̄) is the reduction of O(χψ) for χ the Teichmüller lift of χ̄ and ψ any character of (O/N)^× of 2-power order with ψ(−1) = 1 (needed for PGL₂). So a mod-2 class can be the reduction of a class of characteristic 0 with nebentypus χψ for several ψ.
- ψ = 1 is the nebentypus of ρ (det ρ = χ), the one a deformation argument toward ρ|G_E would use.
- ψ = 1 or ψ quadratic: the coefficient ring is W = ℤ₂[ζ₅], unramified. ψ of order 2^k ≥ 4: the ring is W[ζ_{2^k}], ramified, with uniformizer ϖ = 1 − ζ_{2^k}.
- H¹(Γ₀, O(χψ)) is torsion-free, because H⁰(Γ₀, K/O(χψ)) = 0 when χ̄ ≠ 1, and the connecting map vanishes when χψ = 1.
- A mod-2 eigensystem comes from characteristic 0 with nebentypus χψ iff it occurs in the image of H¹(Γ₀, O(χψ)) in H¹(Γ₀, F(χ̄)). This is the Deligne–Serre lemma. A larger coefficient ring O_K gives the same image tensored with F_K.

**Method A, the rank in characteristic 0** (`sparse_fp.py`, `fp_big.py`).
- The relator equations with signs and the nebentypus in F_P, with P < 2²⁰ and P ≡ 1 mod 40. By universal coefficients, dim_{F_P} H¹ ≥ dim_C H¹(Γ₀, C(χψ)).
- The reduction is that of `sparse_big.py` with F_P arithmetic. The rows are re-derived at each pass of the closure, so they are not stored. Markowitz is stopped near the minimum of (core columns) × (core nnz). The core is solved by Montgomery's block Lanczos over F_P on A = MᵀDM, which gives dim ker ≤ N − (Krylov dimension) − rank V_m.
- The arithmetic is exact in float64 (products < 2⁴⁰, partial sums < 2⁵²). A-orthogonality is checked every 500 iterations.
- **Base changes** (`bc_counts.py`, `bc_counts_{633,1951}.json`).
  - For ψ = ψ₀∘N (ψ₀ a quadratic Dirichlet character or 1), f ∈ S₂(Γ₀(M), ε′) base changes to nebentypus ε′∘N, and ε′∘N = (εψ₀)∘N iff ε′ ∈ {εψ₀, εψ₀χ₋₇}.
  - Every form of S₂(Γ₀(N), εψ₀) gives one class, oldforms with their multiplicity. Forms of S₂(Γ₀(7N), εψ₀χ₋₇) give one class per pair f, f ⊗ χ₋₇ (π(1, χ₋₇) at 7 becomes unramified).
  - No form here has CM by E.
- If the F_P bound equals the number of base changes, every class of characteristic 0 is a base change. Then T_v = T_v̄ on it, its reduction is a pair (a, a), and no mixed class lifts with that nebentypus.

**Method B, first-order obstructions** (`bockstein.py`, `bock_small.py`, `bock_big.py`).
- **ψ = 1.** The Bockstein of 0 → F₁₆ → W/4 → F₁₆ → 0. Lift the cocycle u to W/4 = ℤ[ζ₅]/4 (GR(4,4), tables in `bockstein.py`, the character by its Teichmüller lift) and apply the signed equations: R̃ũ = 2b. Then u lifts modulo 4 iff b ∈ im R over F₁₆.
- **ψ quadratic.** The obstruction is b + R_λu, where λ is ψ written additively and R_λ multiplies each term by λ of its path scalar.
- **ψ of order 2^k ≥ 4.** Modulo ϖ² the equations are R + ϖR_λ, with λ = ψ^(2^(k−1)) written additively, so the obstruction is R_λu.
- All obstructions are decided at once by the augmented system R x + B t = 0. The right-hand sides go through the closure (affine union-find, with the decisions of the homogeneous closure, checked against the cached closure), the deduplication and the Markowitz rounds. Rows whose x-part vanishes become conditions on t. The core is solved with the completeness certificate.
- The kernel vectors with t = 0 must be ker R. The others are checked against every original equation.
- A non-zero obstruction proves that u does not lift with that ψ. A vanishing one proves nothing: the obstructions of higher order are not computed.

**Validation.**
- `fp_check.py`, `fp_check.json`. The F_P engine against the dense engine `bmf.py` at 23, 31, 47 (trivial χ̄) and 31 with χ̄ of order 5, for ψ = 1 and the quadratic ψ. All 8 cases agree, both with the dense core and with the Lanczos bound.
- `snf2_check.py`, `snf2_check_{23,31}.json`. The 2-adic elementary divisors of the integer relator matrix (trivial character), by a separate elimination over ℤ/2³¹.
  - Mod-2 kernel 14 and 15; classes lifting modulo 4: 7 and 10. These equal the first-order test.
  - Valuations: at 23, 2¹ seven times, 2² three times and 2⁶ twice; at 31, 2¹ five times, 2² six times, 2⁴ once and 2⁵ once.
- In every case the first-order liftable dimension is at least the characteristic-0 rank. At 31 with χ̄ of order 5, for ψ = 1 and the quadratic ψ, they are equal (1 and 9).

**Small levels, all of H¹** (`bock_small_{23,31,47,31c}.json`; `char0_psi.py`, `char0_psi_{31,47}_o*.json`).
- `char0_psi.py N K` computes H¹(Γ₀, C(ψ)) for ψ of order 2^K on the units of O/N. It works over F_P for every embedding of ζ_{2^K} and two primes. It reconstructs the characteristic polynomials of T_v, T_v̄ and T_v + T_v̄ over ℤ[ζ_{2^K}] (the two primes agree) and reduces them modulo ϖ.
- An eigenform reducing to a mixed pair would have T_v + T_v̄ ≡ x + y ≠ 0 mod ϖ.

| N | ψ | mod-4 / first-order obstruction of the mixed classes | characteristic 0 | do the mixed classes lift? |
|---|---|---|---|---|
| 23 | 1 | vanishes: they lift modulo 4 | rank 2 = base change | no |
| 23 | (·/23)∘N | non-zero | rank 8 | no |
| 31 | 1 | non-zero | rank 2 = base change | no |
| 31 | (·/31)∘N | non-zero | rank 9 | no |
| 31 | order 4, 8, 16, 32 | vanishes | ranks 3, 3, 2, 0; T_v + T_v̄ nilpotent mod ϖ | no |
| 47 | 1 | non-zero | rank 4 = base change | no |
| 47 | (·/47)∘N | non-zero | rank 15 | no |
| 47 | order 4, 8, 16 | vanishes | ranks 5, 4, 0; T_v + T_v̄ nilpotent mod ϖ | no |

These are all the ψ: at 23 the 2-parts of F₂₃^× have order 2, so with ψ(−1) = 1 only (·/23)∘N remains, and at 31 and 47 the orders are bounded by ψ(−1) = 1.

**633 and 1951.**

| level | ψ | first-order obstruction of the four eigenvectors | dim_{F_P} H¹ (bound) | base changes | mixed classes lift? |
|---|---|---|---|---|---|
| 633 | 1 | vanishes | ≤ 68 (P = 1 048 361; again ≤ 68 with P = 1 047 961, another seed, ceiling and block) | 68 | **no** |
| 633 | (·/3)∘N | vanishes | ≤ 316 | 280 | not decided |
| 633 | (·/211)∘N | vanishes | ≤ 282 | 280 | not decided |
| 633 | (·/633)∘N | vanishes | ≤ 212 | 68 | not decided |
| 633 | ψ on F₉^× of order 4, 8 | vanishes | not computed | 0 | not decided |
| 1951 | 1 | vanishes | ≤ 161 (P = 1 048 361) | 161 | **no** |
| 1951 | (·/1951)∘N | vanishes | not computed | 649 | not decided |
| 1951 | order 4–32 | vanishes | not computed | 0 | not decided |

- On the ρ̄-part, the classes lifting modulo 4 (ψ = 1) have dimension 20 of 24 at 633, with pairs (x,x) 6, (x,y) 4, (y,x) 4, (y,y) 6. At 1951 they have dimension 17 of 27: (x,x) 3, (x,y) 2, (y,x) 2, (y,y) 10.
- At 1951 the augmented solve has 31 right-hand sides: the 27 b-columns of the ρ̄₂-part and the 4 c-columns of the eigenvectors. Its kernel is 685 = 664 + 21, complete by the Krylov bound. All 30 451 216 equations are checked. It took 1 h 38 min.
- **1951, ψ = 1** (`fp_big.py 1951`, logs `fp_big_1951_q0.log`, `fp_big_1951_q0_resume1.log`, `fp_big_1951_q0_resume2.log`, record `fp_big_N1951_q0_P1048361_s1.json`).
  - Prime P = 1 048 361. Closure, deduplication and Markowitz up to cost 192 give a core of 565 431 × 217 275 with nnz 13 343 293, and no free classes.
  - Block Lanczos over F_P with b = 64 ran 3 393 iterations and reached Krylov dimension 217 113, with V_m = 0. So dim ker ≤ 217 275 − 217 113 = 162, hence dim Z_gauge ≤ 162 and dim H¹ ≤ 161 (δm_par is the extra coboundary).
  - A-orthogonality was checked 5 times in the last segment.
  - The run was resumed twice from checkpoints: once to make the BLAS single-threaded, once to switch to the float32 storage, which is exact.
  - Base change of S₂(Γ₀(1951), χ) gives 161 classes. So the characteristic-0 cohomology of Γ₀(1951·O_E) with the nebentypus χ⁻¹∘N (the Teichmüller lift of the computed one) consists of these 161 base changes. On them T_v = T_v̄.
  - So the mixed classes, and every class with T_v ≢ T_v̄, are not reductions of eigenforms of characteristic 0 with this nebentypus at this level. They come from torsion; since they lift modulo 4, from torsion of order at least 4.
  - The ρ̄₂-part in characteristic 0 is then the base change of the nine newforms of Theorem D(iii): 3 with a₂ ≡ x and 6 with a₂ ≡ y. Modulo 4 the liftable part of the ρ̄₂-part has (x,x) 3, which agrees.

## Summary across levels [C]

- In every model, and at level 1951·O_E, the mixed refinements (x,y) and (y,x) occur. The refined Serre-weight conjectures for GL₂ over imaginary quadratic fields predict this: the local weights at v and v̄ are independent.
- The models below 633 are dihedral or reducible, and for these a CM-type mechanism could be responsible. The model at 633 and the target at 1951 are icosahedral, with nebentypus of order 5 modulo 2 and Frob₂ of projective order 5.
- Icosahedral mod-2 systems without a companion (for example the control at level 31) show only the forced refinement.
- [T] Wherever characteristic 0 was computed, no mixed class lifts:
  - at 23, 31 and 47, for every nebentypus of 2-power order;
  - at 633 and 1951, with the Teichmüller lift of the nebentypus.
  The mixed classes there come from 2-power torsion. Lifts with twisted nebentypus are not decided at 633 and 1951.
- **A different Euclidean field is not available.** Among imaginary quadratic fields of class number 1, only ℚ(√−7) has 2 split. So among the fields of 𝓕₇, E = ℚ(√−7) is the one with a Euclidean ring of integers, where the presentation used here applies.

## Cost (measured)

| level | index n | classes after closure | core | method | time | peak memory |
|---|---|---|---|---|---|---|
| 633 | 449 440 | 241 995 | 108 587 × 15 688 | sparse elimination, dense bitsliced core | 616 s | 4.6 GB |
| 633 | 449 440 | 241 995 | 108 587 × 15 688 | sparse elimination, Lanczos core | 517 s | 4.6 GB |
| 633 | 449 440 | 241 995 | 35 231 × 14 879 | memory-lean, Lanczos | 296 s | 0.5 GB |
| 1951 | 3 806 402 | 2 037 851 | 301 036 × 126 366 | memory-lean, Lanczos | 1 h 44 min (in two slots) | about 3 GB |
| 1951, first-order lifting test (31 right-hand sides) | 3 806 402 | 2 037 851 | 301 036 × (126 366 + 31) | augmented reduction, Lanczos over F₁₆ (b = 768) | 1 h 38 min | 3.9 GB |
| 633, rank over F_P | 449 440 | 237 979 | 53 294 × 21 374 | F_P sparse elimination, block Lanczos over F_P (b = 16) | 2 min (7 min before the BLAS fix) | 0.4 GB |
| 1951, rank over F_P | 3 806 402 | 2 021 183 | 565 431 × 217 275 (Markowitz ceiling 192) | F_P sparse elimination, block Lanczos over F_P (b = 64) | about 2.5 h in three segments (2.5 s per iteration at the end) | 2.1 GB |

- The core is about 6% of the classes, and 3.3% of n, at both levels. Coset graphs of congruence subgroups are expanders, so no elimination order avoids a core of size proportional to n.
- A dense core of 126 366 columns would need about 8 GB, and 1.3·10¹⁴ word operations bitsliced. Block Lanczos needs O(N · nnz + N²·b) work and memory linear in N.
- The dense engine of the first models needs about 3n² bytes and stops near n ≈ 10⁴.
- Over F_P the Lanczos is memory-bound: the blocks do not fit in the cache at 1951. With OpenBLAS threads competing with the numba threads, the first segment ran at 13 s per iteration. With single-threaded BLAS it ran at 3 s, and with float32 storage at 2.5 s.

## Files

| File | Content |
|---|---|
| `o7.py` | arithmetic in O and PGL₂(O); presentation (FGT); word decomposition |
| `gf.py` | GF(16) with the note's encoding (z = ζ₅ mod 2; x = 6, y = 9 for 1951), packed GF(2) and F_P elimination |
| `bmf.py` | levels, coset tables, cocycle equations, gauge, H¹ basis (PSL₂ or PGL₂), nebentypus |
| `hecke.py` | Hecke operators on H¹ |
| `charpoly.py` | characteristic polynomials mod P |
| `validate.py`, `validate.log` | the validation above |
| `mod2_refine.py` | first model runs (traces from class-group formulas): `mod2_refine_toy23_PSL.*`, `mod2_refine_toy23_PGL.*`, `mod2_refine_toy47_PGL.*` |
| `run_model.py`, `model_N{23,31,47,79}.log/.json` | model runs with traces from the newforms mod 𝔓 |
| `verify_mixed.py`, `verify_mixed_toy23.log` | F₁₆ recomputation and eigenvector test at nine unused primes (N = 23) |
| `extend_checks.py`, `extend_checks_N{23,31,47}.log/.json` | eigenvector test of the mixed vectors at every split prime of norm ≤ 200 |
| `find_models.py`, `find_models.log` | first search (superseded) |
| `find_models2.py`, `find_models2.log`, `find_models2_153_400.log` | search with trivial character, odd squarefree N ≤ 400 |
| `find_models3.py`, `find_models3.log`, `find_models3_redo.log` | search with nebentypus, odd N ≤ 150 and 7N′ ≤ 217; the redo completes two newforms skipped by the time limit |
| `control_A5_31.py`, `control_A5_31_s{1,-1}.log/.json` | the icosahedral control at level 31·O_E with nebentypus of order 5 |
| `check_633.py`, `check_633.log` | the weight-one icosahedral newform of level 633 as a mod-2 model |
| `sparse_h1.py`, `gf16_bits.py` | sparse direct engine: closure, deduplication, Markowitz, dense core (bitsliced F₁₆ elimination), lifting and checks, Hecke operators on large bases |
| `run_sparse.py`, `run_sparse_auto.py` | drivers: one newform (with nebentypus, weight one or two), or every mod-2 system at a squarefree level; `sparse_N*.json`, `sparse_auto_N*.json/.log` |
| `sparse_633.log`, `sparse_633_seed1234.log`, `sparse_633_lanczos.log`, `sparse_N633_k1_o10_A5*.json` | the 633 model: two dense cores, one Lanczos core |
| `lanczos16.py` | block Lanczos over F₁₆ (bitsliced), null-space extraction, completeness bound, checkpoints |
| `sparse_big.py`, `run_big.py` | memory-lean pipeline (Markowitz in rounds, kernel on the classes, on-the-fly checks, cached stages) and its driver, including the 1951 target with the Galois-side eigenvalues |
| `big_633.log`, `big_633_v2.log`, `big_N633_k1_o10_A5.json`, `big_N31_k2_o5_1.json` | the 633 model and the level-31 control with the memory-lean pipeline |
| `big_1951.log`, `big_N1951.json`, `big_cache_N1951/lanczos_runs.json` | level 1951·O_E |
| `validate_sparse.py`, `validate_sparse.log` | Lanczos on planted kernels; dim H¹ by three routes at seven levels |
| `bockstein.py` | the 2-adic lifting test: GR(4,4) = ℤ[ζ₅]/4 tables, quadratic characters per step, right-hand sides b and R_λu, affine closure, augmented deduplication and Markowitz, core with certificate, checks |
| `bock_small.py`, `bock_small_{23,31,47,31c}.json` | the test on all of H¹ at small levels, with the characteristic-0 ranks over F_P for each ψ |
| `bock_big.py`, `bock_big_633.log`, `bock_big_1951.log`, `bock_big_N633_k1_o10_A5.json`, `bock_big_N1951.json` | the test on the ρ̄-part and the four eigenvectors at 633 and 1951 |
| `snf2_check.py`, `snf2_check_{23,31}.json`, `snf2_check_31.log` | 2-adic elementary divisors of the integer relator matrix (independent check of the test) |
| `char0_psi.py`, `char0_psi_{31,47}_o*.json`, `char0_psi_47.log`, `char0_psi_47_o16.log` | characteristic 0 with a nebentypus of order 2^K: dimensions, and characteristic polynomials of T_v, T_v̄, T_v + T_v̄ over ℤ[ζ_{2^K}] reduced modulo ϖ |
| `sparse_fp.py` | the sparse engine over F_P (P < 2²⁰): streamed closure, deduplication, Markowitz with a cost ceiling, dense core or block Lanczos over F_P with the bound |
| `fp_check.py`, `fp_check.json` | the F_P engine against the dense engine (8 cases) |
| `fp_big.py`, `fp_big_*.log`, `fp_big_N*_q*_P*_s*.json` | characteristic-0 rank bounds at 633 and 1951 (QMASK: quadratic twist) |
| `bc_counts.py`, `bc_counts_{633,1951}.json` | number of base changes for each Galois-invariant quadratic twist of the nebentypus |

The scripts use `numpy`, `numba`, `sympy` and `cypari2`, and run from this folder. `run_big.py 1951` reads `../questions/classes_1951.json` and writes its stages to `big_cache_N1951/` (about 1 GB; only `lanczos_runs.json` is kept in the supplement).
