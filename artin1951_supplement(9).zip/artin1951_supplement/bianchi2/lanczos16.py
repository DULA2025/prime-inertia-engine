"""Block Lanczos over GF(16) (encoding of gf.py) for the null space of a sparse matrix M (rows x N).

Blocks of b = 64 w vectors of length N are bitsliced: an array (N, 4, w) of uint64 holds bit-plane k of the entries,
64 columns per word (column j: word j // 64, bit j % 64).  Montgomery's block Lanczos (Eurocrypt 1995) runs on the
symmetric matrix A = M^T D M, with D a random invertible diagonal.  The null space of M is extracted at the end from span(x - Y, V_m) and checked against
every row of M.  Characteristic 2: all signs are +.

Dense products use tables over pairs of columns (256 entries per pair): U^T V and V Mat cost about N b^2 / 32 word
operations each.  Author: Dula."""
import numpy as np, numba as nb, time
import gf

MUL = gf.MUL16; INV = gf.INV16

def _mulmasks():
    """MASKS[s, k]: bitmask of the input planes l whose XOR is output plane k of s * x."""
    M = np.zeros((16, 4), dtype=np.int64)
    for s in range(16):
        for l in range(4):
            col = int(MUL[s, 1 << l])
            for k in range(4):
                if (col >> k) & 1: M[s, k] |= 1 << l
    return M
MASKS = _mulmasks()

# ------------------------------------------------------------------ conversions
@nb.njit(cache=True)
def to_bits(A, w):
    """(N, b) uint8 -> (N, 4, w) bitsliced (b <= 64 w)."""
    N, b = A.shape
    X = np.zeros((N, 4, w), dtype=np.uint64)
    for i in range(N):
        for j in range(b):
            e = A[i, j]
            if e:
                q = j >> 6; s = np.uint64(j & 63)
                for k in range(4):
                    if (e >> k) & 1: X[i, k, q] |= np.uint64(1) << s
    return X

@nb.njit(cache=True)
def from_bits(X, b):
    """(N, 4, w) -> (N, b) uint8 (the first b columns)."""
    N = X.shape[0]
    A = np.zeros((N, b), dtype=np.uint8)
    for i in range(N):
        for j in range(b):
            q = j >> 6; s = np.uint64(j & 63); e = 0
            for k in range(4):
                e |= int((X[i, k, q] >> s) & np.uint64(1)) << k
            A[i, j] = e
    return A

def random_block(N, w, rng):
    return np.frombuffer(rng.bytes(N * 4 * w * 8), dtype=np.uint64).reshape(N, 4, w).copy()

# ------------------------------------------------------------------ sparse products
@nb.njit(cache=True, parallel=True)
def spmv(ptr, col, val, X, masks):
    """Y = M X for M in CSR (ptr, col, val); X (N, 4, w) -> Y (R, 4, w)."""
    R = ptr.shape[0] - 1; w = X.shape[2]
    Y = np.zeros((R, 4, w), dtype=np.uint64)
    for r in nb.prange(R):
        for t in range(ptr[r], ptr[r + 1]):
            c = col[t]; a = val[t]
            for k in range(4):
                mk = masks[a, k]
                if mk & 1:
                    for j in range(w): Y[r, k, j] ^= X[c, 0, j]
                if mk & 2:
                    for j in range(w): Y[r, k, j] ^= X[c, 1, j]
                if mk & 4:
                    for j in range(w): Y[r, k, j] ^= X[c, 2, j]
                if mk & 8:
                    for j in range(w): Y[r, k, j] ^= X[c, 3, j]
    return Y

@nb.njit(cache=True, parallel=True)
def spmv_rows(ptr, col, val, X, masks, r0, r1):
    """Rows r0..r1-1 of M X."""
    w = X.shape[2]
    Y = np.zeros((r1 - r0, 4, w), dtype=np.uint64)
    for rr in nb.prange(r1 - r0):
        r = r0 + rr
        for t in range(ptr[r], ptr[r + 1]):
            c = col[t]; a = val[t]
            for k in range(4):
                mk = masks[a, k]
                for l in range(4):
                    if (mk >> l) & 1:
                        for j in range(w): Y[rr, k, j] ^= X[c, l, j]
    return Y

@nb.njit(cache=True)
def transpose_csr(ptr, col, val, ncol):
    R = ptr.shape[0] - 1; nnz = ptr[R]
    cnt = np.zeros(ncol + 1, dtype=np.int64)
    for t in range(nnz): cnt[col[t] + 1] += 1
    for c in range(ncol): cnt[c + 1] += cnt[c]
    tp = cnt.copy(); tcol = np.empty(nnz, dtype=np.int32); tval = np.empty(nnz, dtype=np.uint8)
    fill = cnt[:ncol].copy()
    for r in range(R):
        for t in range(ptr[r], ptr[r + 1]):
            c = col[t]; p = fill[c]; tcol[p] = r; tval[p] = val[t]; fill[c] += 1
    return tp, tcol, tval

@nb.njit(cache=True)
def compress_rows(ptr, col, val, target, factor, m, mul):
    """B = H M with H[target[r], r] = factor[r]: CSR of B (m rows), duplicate columns combined, zeros dropped."""
    R = ptr.shape[0] - 1
    cnt = np.zeros(m + 1, dtype=np.int64)
    for r in range(R): cnt[target[r] + 1] += ptr[r + 1] - ptr[r]
    for i in range(m): cnt[i + 1] += cnt[i]
    bc = np.empty(cnt[m], dtype=np.int32); bv = np.empty(cnt[m], dtype=np.uint8)
    fill = cnt[:m].copy()
    for r in range(R):
        i = target[r]; f = factor[r]
        for t in range(ptr[r], ptr[r + 1]):
            p = fill[i]; bc[p] = col[t]; bv[p] = mul[f, val[t]]; fill[i] += 1
    # sort each row by column, combine duplicates
    optr = np.zeros(m + 1, dtype=np.int64); oc = np.empty(cnt[m], dtype=np.int32); ov = np.empty(cnt[m], dtype=np.uint8)
    k = 0
    for i in range(m):
        lo = cnt[i]; hi = cnt[i + 1]
        order = np.argsort(bc[lo:hi], kind="mergesort")
        last = -1
        for o in order:
            c = bc[lo + o]; v = bv[lo + o]
            if c == last:
                ov[k - 1] ^= v
            else:
                oc[k] = c; ov[k] = v; k += 1; last = c
        # drop zeros
        j0 = optr[i]; kk = j0
        for j in range(j0, k):
            if ov[j] != 0:
                oc[kk] = oc[j]; ov[kk] = ov[j]; kk += 1
        k = kk; optr[i + 1] = k
    return optr, oc[:k].copy(), ov[:k].copy()

# ------------------------------------------------------------------ dense block products
@nb.njit(cache=True, inline="always")
def _pair_index(p0, p1, p2, p3, sh):
    a0 = (p0 >> sh) & np.uint64(3); a1 = (p1 >> sh) & np.uint64(3)
    a2 = (p2 >> sh) & np.uint64(3); a3 = (p3 >> sh) & np.uint64(3)
    return int((a0 & np.uint64(1)) | ((a1 & np.uint64(1)) << np.uint64(1)) | ((a2 & np.uint64(1)) << np.uint64(2))
               | ((a3 & np.uint64(1)) << np.uint64(3)) | ((a0 >> np.uint64(1)) << np.uint64(4)) | ((a1 >> np.uint64(1)) << np.uint64(5))
               | ((a2 >> np.uint64(1)) << np.uint64(6)) | ((a3 >> np.uint64(1)) << np.uint64(7)))

@nb.njit(cache=True, parallel=True)
def inner(U, V, masks, TB):
    """G = U^T V as a (64 wu) x (64 wv) uint8 matrix; U (N, 4, wu), V (N, 4, wv).  Parallel over blocks of TB column
    pairs of U; each block keeps a table (TB, 256, 4, wv) of partial sums indexed by the pair of entries."""
    N = U.shape[0]; wu = U.shape[2]; wv = V.shape[2]
    P = 32 * wu; nblk = (P + TB - 1) // TB
    G = np.zeros((2 * P, 64 * wv), dtype=np.uint8)
    for blk in nb.prange(nblk):
        t0 = blk * TB; t1 = min(P, t0 + TB)
        Acc = np.zeros((TB, 256, 4, wv), dtype=np.uint64)
        q0 = t0 >> 5; q1 = (t1 - 1) >> 5
        for i in range(N):
            for q in range(q0, q1 + 1):
                p0 = U[i, 0, q]; p1 = U[i, 1, q]; p2 = U[i, 2, q]; p3 = U[i, 3, q]
                if (p0 | p1 | p2 | p3) == 0: continue
                ta = max(t0, q * 32); tb = min(t1, q * 32 + 32)
                for t in range(ta, tb):
                    idx = _pair_index(p0, p1, p2, p3, np.uint64(2 * (t & 31)))
                    if idx == 0: continue
                    for k in range(4):
                        for j in range(wv):
                            Acc[t - t0, idx, k, j] ^= V[i, k, j]
        S1 = np.zeros((16, 4, wv), dtype=np.uint64); S2 = np.zeros((16, 4, wv), dtype=np.uint64)
        R1 = np.zeros((4, wv), dtype=np.uint64); R2 = np.zeros((4, wv), dtype=np.uint64)
        for t in range(t0, t1):
            S1[:] = 0; S2[:] = 0; R1[:] = 0; R2[:] = 0
            for idx in range(1, 256):
                e1 = idx & 15; e2 = idx >> 4
                for k in range(4):
                    for j in range(wv):
                        a = Acc[t - t0, idx, k, j]
                        S1[e1, k, j] ^= a; S2[e2, k, j] ^= a
            for e in range(1, 16):
                for k in range(4):
                    mk = masks[e, k]
                    for l in range(4):
                        if (mk >> l) & 1:
                            for j in range(wv):
                                R1[k, j] ^= S1[e, l, j]; R2[k, j] ^= S2[e, l, j]
            for c in range(64 * wv):
                qq = c >> 6; s = np.uint64(c & 63)
                v1 = 0; v2 = 0
                for k in range(4):
                    v1 |= int((R1[k, qq] >> s) & np.uint64(1)) << k
                    v2 |= int((R2[k, qq] >> s) & np.uint64(1)) << k
                G[2 * t, c] = v1; G[2 * t + 1, c] = v2
    return G

@nb.njit(cache=True, parallel=True)
def _tables(Mb, masks):
    """Tab[t, e1 + 16 e2] = e1 Mb[2t] + e2 Mb[2t+1] (bitsliced rows of length 64 wo)."""
    P = Mb.shape[0] // 2; wo = Mb.shape[2]
    Tab = np.zeros((P, 256, 4, wo), dtype=np.uint64)
    for t in nb.prange(P):
        m1 = np.zeros((16, 4, wo), dtype=np.uint64); m2 = np.zeros((16, 4, wo), dtype=np.uint64)
        for e in range(1, 16):
            for k in range(4):
                mk = masks[e, k]
                for l in range(4):
                    if (mk >> l) & 1:
                        for j in range(wo):
                            m1[e, k, j] ^= Mb[2 * t, l, j]; m2[e, k, j] ^= Mb[2 * t + 1, l, j]
        for e2 in range(16):
            for e1 in range(16):
                for k in range(4):
                    for j in range(wo):
                        Tab[t, e1 | (e2 << 4), k, j] = m1[e1, k, j] ^ m2[e2, k, j]
    return Tab

@nb.njit(cache=True, parallel=True)
def _apply_tables(V, Tab, TB):
    N = V.shape[0]; P = Tab.shape[0]; wo = Tab.shape[3]
    out = np.zeros((N, 4, wo), dtype=np.uint64)
    for t0 in range(0, P, TB):
        t1 = min(P, t0 + TB); q0 = t0 >> 5; q1 = (t1 - 1) >> 5
        for i in nb.prange(N):
            for q in range(q0, q1 + 1):
                p0 = V[i, 0, q]; p1 = V[i, 1, q]; p2 = V[i, 2, q]; p3 = V[i, 3, q]
                if (p0 | p1 | p2 | p3) == 0: continue
                ta = max(t0, q * 32); tb = min(t1, q * 32 + 32)
                for t in range(ta, tb):
                    idx = _pair_index(p0, p1, p2, p3, np.uint64(2 * (t & 31)))
                    if idx == 0: continue
                    for k in range(4):
                        for j in range(wo):
                            out[i, k, j] ^= Tab[t, idx, k, j]
    return out

def mulmat(V, Mat, TB=16):
    """V (N, 4, wi) times Mat ((<= 64 wi) x bo, uint8) -> (N, 4, wo), wo = ceil(bo / 64)."""
    wi = V.shape[2]; bi, bo = Mat.shape; wo = max(1, (bo + 63) // 64)
    Mp = np.zeros((64 * wi, bo), dtype=np.uint8); Mp[:bi] = Mat
    Tab = _tables(to_bits(Mp, wo), MASKS)
    return _apply_tables(V, Tab, TB)

def inner_u8(U, V, TB=4):
    return inner(U, V, MASKS, TB)

def mm(A, B):
    """Dense product of uint8 matrices over GF(16) through the bitsliced kernels."""
    wa = max(1, (A.shape[1] + 63) // 64)
    return from_bits(mulmat(to_bits(A, wa), B), B.shape[1])

@nb.njit(cache=True)
def _colmask(S, w):
    m = np.zeros(w, dtype=np.uint64)
    for j in range(S.shape[0]):
        if S[j]: m[j >> 6] |= np.uint64(1) << np.uint64(j & 63)
    return m

def select_cols(X, S):
    m = _colmask(S, X.shape[2])
    return X & m[None, None, :]

# ------------------------------------------------------------------ Montgomery's selection of S_i
@nb.njit(cache=True)
def select(T, Sprev, mul, inv):
    """Gauss-Jordan on [T | I] (b x 2b) with the columns not in Sprev first.  Returns (Winv, S, ok), Winv = S (S^T T S)^-1 S^T;
    ok is False if a column not in Sprev could not be selected (breakdown)."""
    b = T.shape[0]
    M = np.zeros((b, 2 * b), dtype=np.uint8)
    for i in range(b):
        for j in range(b): M[i, j] = T[i, j]
        M[i, b + i] = 1
    order = np.empty(b, dtype=np.int64); k = 0
    for j in range(b):
        if not Sprev[j]:
            order[k] = j; k += 1
    for j in range(b):
        if Sprev[j]:
            order[k] = j; k += 1
    pos2row = order.copy()
    S = np.zeros(b, dtype=np.bool_)
    for jj in range(b):
        c = order[jj]; f = -1
        for kk in range(jj, b):
            if M[pos2row[kk], c] != 0:
                f = kk; break
        if f >= 0:
            tmp = pos2row[jj]; pos2row[jj] = pos2row[f]; pos2row[f] = tmp
            r = pos2row[jj]; S[c] = True
            s = inv[M[r, c]]
            if s != 1:
                for t in range(2 * b): M[r, t] = mul[s, M[r, t]]
            for kk in range(b):
                rr = pos2row[kk]
                if rr == r: continue
                fct = M[rr, c]
                if fct != 0:
                    for t in range(2 * b): M[rr, t] ^= mul[fct, M[r, t]]
        else:
            f = -1
            for kk in range(jj, b):
                if M[pos2row[kk], b + c] != 0:
                    f = kk; break
            if f < 0:
                return np.zeros((b, b), dtype=np.uint8), S, False
            tmp = pos2row[jj]; pos2row[jj] = pos2row[f]; pos2row[f] = tmp
            r = pos2row[jj]
            s = inv[M[r, b + c]]
            if s != 1:
                for t in range(2 * b): M[r, t] = mul[s, M[r, t]]
            for kk in range(b):
                rr = pos2row[kk]
                if rr == r: continue
                fct = M[rr, b + c]
                if fct != 0:
                    for t in range(2 * b): M[rr, t] ^= mul[fct, M[r, t]]
            for t in range(2 * b): M[r, t] = 0
    Winv = np.zeros((b, b), dtype=np.uint8)
    for jj in range(b):
        c = order[jj]; r = pos2row[jj]
        for t in range(b): Winv[c, t] = M[r, b + t]
    ok = True
    for j in range(b):
        if (not Sprev[j]) and (not S[j]): ok = False
    return Winv, S, ok

@nb.njit(cache=True)
def _entry_rc(P, r, c):
    q = c >> 6; sh = np.uint64(c & 63); e = 0
    for k in range(4):
        e |= int((P[k, r, q] >> sh) & np.uint64(1)) << k
    return e

@nb.njit(cache=True)
def select_bits(T, Sprev, inv, masks):
    """Bitsliced version of select (same result): [T | I] as four bit-planes, 15 multiples of the pivot row."""
    b = T.shape[0]; W = (2 * b + 63) // 64
    P = np.zeros((4, b, W), dtype=np.uint64)
    for i in range(b):
        for j in range(b):
            e = T[i, j]
            if e:
                for k in range(4):
                    if (e >> k) & 1: P[k, i, j >> 6] |= np.uint64(1) << np.uint64(j & 63)
        jj = b + i; P[0, i, jj >> 6] |= np.uint64(1) << np.uint64(jj & 63)
    order = np.empty(b, dtype=np.int64); k = 0
    for j in range(b):
        if not Sprev[j]:
            order[k] = j; k += 1
    for j in range(b):
        if Sprev[j]:
            order[k] = j; k += 1
    pos2row = order.copy()
    S = np.zeros(b, dtype=np.bool_)
    mult = np.zeros((16, 4, W), dtype=np.uint64); tmp = np.zeros((4, W), dtype=np.uint64)
    for jj in range(b):
        c = order[jj]; f = -1; pc = c
        for kk in range(jj, b):
            if _entry_rc(P, pos2row[kk], c) != 0:
                f = kk; break
        if f >= 0:
            S[c] = True
        else:
            pc = b + c
            for kk in range(jj, b):
                if _entry_rc(P, pos2row[kk], pc) != 0:
                    f = kk; break
            if f < 0:
                return np.zeros((b, b), dtype=np.uint8), S, False
        t_ = pos2row[jj]; pos2row[jj] = pos2row[f]; pos2row[f] = t_
        r = pos2row[jj]
        s = inv[_entry_rc(P, r, pc)]
        if s != 1:
            tmp[:] = 0
            for kk2 in range(4):
                mk = masks[s, kk2]
                for l in range(4):
                    if (mk >> l) & 1:
                        for j in range(W): tmp[kk2, j] ^= P[l, r, j]
            for kk2 in range(4):
                for j in range(W): P[kk2, r, j] = tmp[kk2, j]
        for e in range(1, 16):
            for kk2 in range(4):
                mk = masks[e, kk2]
                for j in range(W): mult[e, kk2, j] = 0
                for l in range(4):
                    if (mk >> l) & 1:
                        for j in range(W): mult[e, kk2, j] ^= P[l, r, j]
        for kk in range(b):
            rr = pos2row[kk]
            if rr == r: continue
            e = _entry_rc(P, rr, pc)
            if e != 0:
                for kk2 in range(4):
                    for j in range(W): P[kk2, rr, j] ^= mult[e, kk2, j]
        if not S[c]:
            for kk2 in range(4):
                for j in range(W): P[kk2, r, j] = 0
    Winv = np.zeros((b, b), dtype=np.uint8)
    for jj in range(b):
        c = order[jj]; r = pos2row[jj]
        for t in range(b): Winv[c, t] = _entry_rc(P, r, b + t)
    ok = True
    for j in range(b):
        if (not Sprev[j]) and (not S[j]): ok = False
    return Winv, S, ok

# ------------------------------------------------------------------ the iteration
class Breakdown(Exception):
    pass

def _save_state(path, **kw):
    import os
    tmp = path + ".tmp.npz"
    np.savez(tmp, **{k: (np.zeros(0, np.uint64) if v is None else v) for k, v in kw.items()})
    os.replace(tmp, path)

def block_lanczos(apply_A, N, w, seed=1, verbose=True, maxit=None, check=False, ckpt=None, ckpt_seconds=600):
    """Montgomery's block Lanczos for the symmetric operator apply_A on GF(16)^N with a start block Y (N x 64 w):
    returns x (with A x = A Y when V_m = 0), Y, V_m, the Krylov dimension sum |S_i| and the number of iterations.
    With ckpt (a path), the state is saved every ckpt_seconds and a saved state for the same (N, w, seed) is resumed."""
    import os
    rng = np.random.default_rng(seed); b = 64 * w
    I = np.eye(b, dtype=np.uint8)
    Z = np.zeros((b, b), dtype=np.uint8)
    t0 = time.time(); Ws = []; t_save = time.time()
    if ckpt is not None and os.path.exists(ckpt):
        st = np.load(ckpt)
        assert int(st["N"]) == N and int(st["w"]) == w and int(st["seed"]) == seed, "checkpoint for another run"
        it = int(st["it"]); dimK = int(st["dimK"]); Y = st["Y"]; V0 = st["V0"]; V = st["V"]; x = st["x"]
        Vm1 = st["Vm1"] if st["Vm1"].size else None; Vm2 = st["Vm2"] if st["Vm2"].size else None
        Winv1 = st["Winv1"]; Winv2 = st["Winv2"]; VAV1 = st["VAV1"]; VA2V1 = st["VA2V1"]; S1 = st["S1"].astype(np.bool_)
        del st
        if verbose: print("    resumed from %s at iteration %d (Krylov dimension %d)" % (ckpt, it, dimK), flush=True)
    else:
        Y = random_block(N, w, rng)
        V0 = apply_A(Y); V = V0.copy(); Vm1 = None; Vm2 = None
        x = np.zeros_like(Y)
        Winv1 = Z; Winv2 = Z; VAV1 = Z; VA2V1 = Z; S1 = np.ones(b, dtype=np.bool_)
        dimK = 0; it = 0
    it0 = it
    maxit = maxit if maxit is not None else N // max(1, b // 2) + 20
    while it < maxit:
        AV = apply_A(V)
        G1 = inner_u8(V, np.concatenate([AV, V0], axis=2))           # [V^T A V | V^T V_0]
        VAV = np.ascontiguousarray(G1[:, :b]); VtV0 = np.ascontiguousarray(G1[:, b:])
        if not VAV.any(): break
        VA2V = inner_u8(AV, AV)
        Winv, S, ok = select_bits(VAV, S1, INV, MASKS)
        if not ok: raise Breakdown("iteration %d" % it)
        dimK += int(S.sum())
        Sm = S.astype(np.uint8)[None, :]
        D = I ^ mm(Winv, (VA2V * Sm) ^ VAV)
        VDC = mulmat(V, np.concatenate([D, mm(Winv, VtV0)], axis=1))   # [V D | V W_inv V^T V_0]
        x ^= VDC[:, :, w:]
        Vn = select_cols(AV, S) ^ VDC[:, :, :w]
        del VDC, G1
        if it >= 1:
            E = mm(Winv1, VAV) * Sm
            if E.any(): Vn ^= mulmat(Vm1, E)
        if it >= 2:
            F = mm(mm(Winv2, I ^ mm(VAV1, Winv1)), (VA2V1 * S1.astype(np.uint8)[None, :]) ^ VAV1) * Sm
            if F.any(): Vn ^= mulmat(Vm2, F)
        if check:
            Ws.append(select_cols(V, S))
            AVn = apply_A(Vn)
            for Wj in Ws[-3:]:
                assert not inner_u8(Wj, AVn).any(), "A-orthogonality fails at iteration %d" % it
        Vm2, Vm1, V = Vm1, V, Vn
        Winv2, Winv1, VAV1, VA2V1, S1 = Winv1, Winv, VAV, VA2V, S
        it += 1
        if verbose and (it % 10 == 0 or it < 3):
            el = time.time() - t0
            print("    Lanczos iteration %d: Krylov dimension %d of %d (%.0fs, %.1fs/it)" % (it, dimK, N, el, el / max(1, it - it0)), flush=True)
        if ckpt is not None and time.time() - t_save > ckpt_seconds:
            _save_state(ckpt, N=N, w=w, seed=seed, it=it, dimK=dimK, Y=Y, V0=V0, V=V, x=x, Vm1=Vm1, Vm2=Vm2,
                        Winv1=Winv1, Winv2=Winv2, VAV1=VAV1, VA2V1=VA2V1, S1=S1.astype(np.uint8))
            t_save = time.time()
            if verbose: print("    checkpoint saved at iteration %d" % it, flush=True)
    return x, Y, V, dimK, it

# ------------------------------------------------------------------ null space of M from candidate blocks
@nb.njit(cache=True)
def nonzero_cols(Y, k):
    """Flags (length k): column c of the bitsliced block Y is non-zero somewhere."""
    w = Y.shape[2]; acc = np.zeros(w, dtype=np.uint64)
    for i in range(Y.shape[0]):
        for l in range(4):
            for j in range(w): acc[j] |= Y[i, l, j]
    out = np.zeros(k, dtype=np.bool_)
    for c in range(k):
        out[c] = ((acc[c >> 6] >> np.uint64(c & 63)) & np.uint64(1)) != 0
    return out

def check_block(ptr, col, val, Kb, k, chunk_words=200_000_000):
    """Columns of Kb (N, 4, wk) that fail some row of M, computed in row chunks."""
    R = ptr.shape[0] - 1; bad = np.zeros(k, dtype=np.bool_)
    step = max(1, chunk_words // (4 * Kb.shape[2]))
    for r0 in range(0, R, step):
        bad |= nonzero_cols(spmv_rows(ptr, col, val, Kb, MASKS, r0, min(R, r0 + step)), k)
    return bad

def row_basis(K):
    """Reduced row echelon basis of the row space of K (k x N, uint8), via the bitsliced elimination."""
    import gf16_bits
    if K.shape[0] == 0: return K
    P = gf16_bits.to_planes(K)
    piv = gf16_bits.rref_planes(P, K.shape[1], INV, gf16_bits.MASKS)
    return gf16_bits.from_planes(P[:, :len(piv), :].copy(), K.shape[1])

def nullspace(ptr, col, val, N, Zb, rng, verbose=True):
    """Basis (rows, uint8, reduced) of {v in span of the columns of Zb (N, 4, wz) : M v = 0}, checked against every
    row of M.  Candidates are cut down by random row compressions of M until the exact check passes."""
    import gf16_bits
    R = ptr.shape[0] - 1; bz = 64 * Zb.shape[2]
    Cs = None; Kb = Zb; k = bz
    for attempt in range(8):
        m = k + 64
        H_t = rng.integers(0, m, size=R).astype(np.int64); H_f = rng.integers(1, 16, size=R).astype(np.uint8)
        hp, hc, hv = compress_rows(ptr, col, val, H_t, H_f, m, MUL)
        Q = from_bits(spmv(hp, hc, hv, Kb, MASKS), k)                       # (m, k)
        Kq, _ = gf16_bits.kernel_bits(Q)                                     # rows e with Q e = 0
        Cs = Kq if Cs is None else mm(Kq, Cs)
        k = Cs.shape[0]
        if k == 0: return np.zeros((0, N), dtype=np.uint8)
        Kb = mulmat(Zb, Cs.T.copy())                                         # (N, 4, wk): the vectors Z c
        bad = check_block(ptr, col, val, Kb, k)
        if not bad.any():
            return row_basis(from_bits(Kb, k).T.copy())
        if verbose: print("    null space: %d of %d candidates fail the exact check; refining" % (int(bad.sum()), k), flush=True)
    raise RuntimeError("null space extraction did not converge")

@nb.njit(cache=True)
def compress_block(X, target, factor, m, masks):
    """H X for the sparse H with H[target[i], i] = factor[i]: (m, 4, w)."""
    w = X.shape[2]; Q = np.zeros((m, 4, w), dtype=np.uint64)
    for i in range(X.shape[0]):
        t = target[i]; a = factor[i]
        for k in range(4):
            mk = masks[a, k]
            for l in range(4):
                if (mk >> l) & 1:
                    for j in range(w): Q[t, k, j] ^= X[i, l, j]
    return Q

def block_kernel(P, rng):
    """Rows c (uint8, independent) spanning {c : P c = 0} for a bitsliced block P (N, 4, wz), by random row
    compressions with an exact check."""
    import gf16_bits
    N = P.shape[0]; bz = 64 * P.shape[2]
    Cs = None; Pc = P; k = bz
    for attempt in range(8):
        m = k + 64
        tg = rng.integers(0, m, size=N).astype(np.int64); fc = rng.integers(1, 16, size=N).astype(np.uint8)
        Q = from_bits(compress_block(Pc, tg, fc, m, MASKS), k)
        Kq, _ = gf16_bits.kernel_bits(Q)
        Cs = Kq if Cs is None else mm(Kq, Cs)
        k = Cs.shape[0]
        if k == 0: return Cs
        Pc = mulmat(P, Cs.T.copy())
        if not nonzero_cols(Pc, k).any(): return Cs
    raise RuntimeError("block kernel extraction did not converge")

def kerA_in_span(apply_A, Zb, rng):
    """dim (ker A n span of the columns of Zb): the rank of {Z c : A Z c = 0}."""
    Cs = block_kernel(apply_A(Zb), rng)
    if Cs.shape[0] == 0: return 0
    V = from_bits(mulmat(Zb, Cs.T.copy()), Cs.shape[0]).T.copy()          # (k, N): the vectors Z c
    return row_basis(V).shape[0]

def lanczos_kernel(ptr, col, val, N, w, seed=1, verbose=True, check=False, ckpt=None):
    """Null space of the sparse matrix M (CSR, N columns) by block Lanczos on A = M^T D M (D a random invertible
    diagonal).  Returns (K, info)."""
    rng = np.random.default_rng(seed + 1000); t0 = time.time()
    R = ptr.shape[0] - 1
    d = rng.integers(1, 16, size=R).astype(np.uint8)
    dval = MUL[np.repeat(d, np.diff(ptr)), val]                              # D M
    tp, tc, tv = transpose_csr(ptr, col, val, N)                             # M^T
    if verbose: print("    M: %d x %d, nnz %d (%.1fs)" % (R, N, len(col), time.time() - t0), flush=True)
    def apply_A(X):
        return spmv(tp, tc, tv, spmv(ptr, col, dval, X, MASKS), MASKS)
    x, Y, Vm, dimK, it = block_lanczos(apply_A, N, w, seed=seed, verbose=verbose, check=check, ckpt=ckpt)
    if verbose: print("    Lanczos: %d iterations, Krylov dimension %d, V_m %s (%.0fs)" % (it, dimK, "= 0" if not Vm.any() else "!= 0", time.time() - t0), flush=True)
    Zb = np.concatenate([x ^ Y, Vm], axis=2)
    K = nullspace(ptr, col, val, N, Zb, rng, verbose=verbose)
    # Bound: V_m lies in im A and is A-orthogonal to every W_i, so rank A >= (Krylov dimension) + rank V_m and
    # dim ker A <= gap := N - (Krylov dimension) - rank V_m.  Certificate: dim K = gap, or dim (ker A n span Z) = gap
    # (then ker M lies in ker A, inside span Z, so K = ker M).
    rVm = row_basis(from_bits(Vm, 64 * w).T.copy()).shape[0] if Vm.any() else 0
    gap = N - dimK - rVm
    kerA = K.shape[0] if K.shape[0] >= gap else kerA_in_span(apply_A, Zb, rng)
    info = {"iterations": it, "krylov_dim": dimK, "Vm_zero": bool(not Vm.any()), "rank_Vm": int(rVm), "gap": int(gap), "block": 64 * w,
            "kernel": K.shape[0], "kerA_in_span": int(kerA), "seed": seed,
            "seconds": round(time.time() - t0, 1)}
    if verbose: print("    null space of M: dimension %d; ker A in the span: %d; bound N - Krylov dimension - rank V_m = %d - %d - %d = %d (%.0fs)" % (K.shape[0], kerA, N, dimK, rVm, gap, time.time() - t0), flush=True)
    return K, info
