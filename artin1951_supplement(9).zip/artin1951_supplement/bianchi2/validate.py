"""Validation of the Bianchi engine (bmf.py, hecke.py) in characteristic 0 (coefficients F_P, P = 10^9 + 7):
(1) the presentation: relators are +-I, word decomposition inverts word_matrix;
(2) dim H^1(Gamma_0(n)) for PSL_2(O) against LMFDB's SL(2) cusp-form dimensions over Q(sqrt-7) (page 'sl2dims/2.0.7.1':
    25.1, 28.2, 36.2 have one cusp form, 1.1, 2.x, 23.x none), plus the number of cusps;
(3) Hecke eigenvalues of base changes: 14a1 at (2)(sqrt-7) and 11a1 at (11);
(4) PSL_2 versus PGL_2: at (11), (23), (31), (47) the PGL_2 cohomology consists exactly of the base changes of the weight-2
    newforms of level 11, 23, 31, 47 (the extra PSL_2 classes are not trivial-character GL_2 newforms).
Author: Dula."""
import sys, time, random, sympy
from o7 import *
from bmf import *
from hecke import *
from charpoly import *
from mod2_refine import root
P = 1000000007
t0 = time.time()
print("(1) relators:", {k: same_psl(word_matrix(r), I2) for k, r in RELATORS_PGL.items()})
random.seed(5)
for _ in range(500):
    toks = [(random.choice("ABUJ"), random.choice((1, -1))) for _ in range(random.randint(1, 25))]
    M = word_matrix(toks); assert same_psl(word_matrix(decompose(M)), M)
print("    word decomposition verified on 500 random words")
v, vb, r7 = Comp("Fp", 2, 0), Comp("Fp", 2, 1), Comp("Fp", 7, 4)
r11 = [r for r in range(11) if (1 + 2 * r) % 11 == 0][0]
tests = [("1.1", [], 0, 1), ("(2) = v vbar", [v, vb], 0, 4), ("25.1 = (5)", [Comp("Fp2", 5)], 1, 2), ("28.2 = (2)(sqrt-7)", [v, vb, r7], 1, 8),
         ("36.2 = (6)", [v, vb, Comp("Fp2", 3)], 1, 8), ("23.1 = q23", [Comp("Fp", 23, root(23, 0))], 0, 2)]
print("(2) PSL_2: dim H^1 = (LMFDB SL(2) cusp forms) + (cusps)")
for name, comps, cf, cu in tests:
    L = Level(comps, field=("Fp", P)); d = L.cohomology().shape[0]
    print("    %-20s dim H^1 = %d, expected %d + %d: %s" % (name, d, cf, cu, "ok" if d == cf + cu else "MISMATCH"))
print("(3) base change eigenvalues")
L = Level([v, vb, r7], field=("Fp", P)); K = L.cohomology(); piv = None
exp = {"(3)": -2, "(5)": -10, "q11": 0, "q11bar": 0, "(13)": -10}
for nm, pi in [("(3)", (3, 0)), ("(5)", (5, 0)), ("q11", (1, 2)), ("q11bar", (3, -2)), ("(13)", (13, 0))]:
    T, ok, piv = hecke_matrix(L, K, pi, pivots=piv); cp = charpoly_modp(T, P); val = exp[nm]
    isroot = sum(c * pow(val, i, P) for i, c in enumerate(cp)) % P == 0
    eis = {"(3)": 6, "(5)": 10, "q11": 4, "q11bar": 4, "(13)": 26}[nm]    # Eisenstein: trace of the generator
    mult = 0; q = list(cp)
    while sum(c * pow(eis, i, P) for i, c in enumerate(q)) % P == 0 and len(q) > 1:   # divide by (x - eis) mod P
        nq = [0] * (len(q) - 1); acc = 0
        for i in range(len(q) - 1, 0, -1): acc = (acc * eis + q[i]) % P; nq[i - 1] = acc
        q = nq; mult += 1
    print("    (2)(sqrt-7), BC(14a1): T_%-7s char poly mod P = (x - %d)^%d (Eisenstein) times (x - r), r = %d; expected %d: %s"
          % (nm, eis, mult, (-q[0]) % P if (-q[0]) % P < P // 2 else (-q[0]) % P - P, val, "ok" if isroot else "MISSING"))
import sympy
for grp in ("PSL", "PGL"):
    pass
print("(4) PSL_2 versus PGL_2 (dimension of H^1, characteristic polynomials of T_(3) and T_v on PGL_2)")
for name, comps, N in [("(11)", [Comp("Fp", 11, root(11, 0)), Comp("Fp", 11, root(11, 1))], 11), ("(23)", [Comp("Fp", 23, root(23, 0)), Comp("Fp", 23, root(23, 1))], 23),
                       ("(31)", [Comp("Fp2", 31)], 31), ("(47)", [Comp("Fp2", 47)], 47)]:
    ds = Level(comps, field=("Fp", P), group="PSL").cohomology().shape[0]
    Lg = Level(comps, field=("Fp", P), group="PGL"); Kg = Lg.cohomology(); piv = None; line = ""
    for nm, pi in [("(3)", (3, 0)), ("v", (0, 1))]:
        T, ok, piv = hecke_matrix(Lg, Kg, pi, pivots=piv); f, _ = lift_factor(charpoly_modp(T, P), P); line += "  T_%s: %s" % (nm, f)
    import cypari2; pari = cypari2.Pari()
    nf = pari("mfinit([%d, 2], 0)" % N); a2 = pari("apply(f -> minpoly(mfcoef(f, 2)), mfeigenbasis(mfinit([%d, 2], 0)))" % N)
    print("    %-5s PSL dim %2d, PGL dim %d;%s;  minimal polynomials of a_2 at level %d over Q: %s" % (name, ds, Kg.shape[0], line, N, a2))
print("done (%.0fs)" % (time.time() - t0))
