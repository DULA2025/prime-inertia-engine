"""A second, independent block Lanczos run on the cached core of a run_big.py level, with another diagonal D and
another start block (another seed): the kernel found must have the same span as the cached core kernel.

Usage: python3 recheck_core.py CACHE_DIR SEED W        (block 64 W)
Writes recheck_core_<cache>_s<SEED>.json.  Author: Dula."""
import sys, os, json, time
import numpy as np
import lanczos16
from lanczos16 import row_basis
t0 = time.time()
cache = sys.argv[1]; seed = int(sys.argv[2]); w = int(sys.argv[3])
z = np.load(os.path.join(cache, "reduction.npz")); ptr, ccol, val = z["ptr"], z["ccol"], z["val"]; C = int(z["core_shape"][1]); del z
K1 = np.load(os.path.join(cache, "core.npz"))["Kc"]
print("core: %d columns, nnz %d; cached kernel %d" % (C, len(ccol), K1.shape[0]), flush=True)
K2, info = lanczos16.lanczos_kernel(ptr, ccol, val, C, w, seed=seed, verbose=True, ckpt=os.path.join(cache, "recheck_w%d_s%d.npz" % (w, seed)))
U = row_basis(np.vstack([K1, K2]))
res = {"cache": cache, "seed": seed, "block": 64 * w, "kernel_cached": int(K1.shape[0]), "kernel_new": int(K2.shape[0]),
       "rank_of_union": int(U.shape[0]), "same_span": bool(U.shape[0] == K1.shape[0] == K2.shape[0]), "lanczos": info,
       "seconds": round(time.time() - t0)}
json.dump(res, open("recheck_core_%s_s%d.json" % (os.path.basename(os.path.normpath(cache)), seed), "w"), indent=1, default=int)
print("cached kernel %d, new kernel %d, rank of the union %d: same span %s (%.0fs)" % (K1.shape[0], K2.shape[0], U.shape[0], res["same_span"], time.time() - t0))
