"""The 2-adic lifting test: first-order obstructions to lifting mod-2 Bianchi classes to characteristic 0.

Setting.  Gamma = Gamma_0(n) in PGL_2(O_E), E = Q(sqrt-7); V = F16(chibar) the induced module of bmf.py and
sparse_h1.py; R the matrix of the relator equations (Fox calculus along the coset graph, tree columns dropped).  A class
u in H^1(Gamma, F16(chibar)) is the reduction of a class of characteristic 0 with nebentypus chi*psi (chi the
Teichmueller lift of chibar, psi a character of (O/n)^x of 2-power order with psi(-1) = 1) only if a first-order
obstruction vanishes:
  * psi = 1 (coefficients W = Z_2[zeta_5], unramified): the Bockstein of 0 -> F16 -> W/4 -> F16 -> 0.  For a lift
    u~ of u to W/4 = GR(4,4) = Z[zeta_5]/4 and the signed equations R~ over W/4 (Teichmueller character), R~ u~ = 2 b
    with b in F16^rows; u lifts modulo 4 iff b lies in the image of R over F16.
  * psi quadratic (values +-1, still unramified): R~ for chi*psi gives b + R_lambda u, where lambda is psi written
    additively (1 where psi = -1) and R_lambda is R with each term multiplied by lambda of its path scalar.
  * psi of order 2^k >= 4 (ring W[zeta_{2^k}], uniformizer varpi = 1 - zeta, residue field F16): modulo varpi^2 the
    equations are R + varpi R_lambda with lambda = psi^(2^(k-1)) written additively; u lifts modulo varpi^2 iff
    R_lambda u lies in the image of R.
Every such obstruction is a combination of the columns b_k (one per cocycle u_k) and c_{k,j} = R_{lambda_j} u_k, where
lambda_j is the quadratic character of the j-th component of (O/n)^x (R_lambda is linear in lambda).

We decide for all combinations at once which lie in the image of R.  The augmented system R x + B t = 0 (B = the
columns) is reduced as in sparse_big.py with the right-hand sides carried along: union-find closure under the 1- and
2-term equations with affine offsets (the decisions are those of the homogeneous closure), deduplication and Markowitz
rounds on the x-part with the RHS rows updated alongside, rows whose x-part vanishes collected as conditions on t, and
the core (x-part plus RHS columns) solved densely or by block Lanczos with the completeness certificate of
lanczos16.py.  The projection of the kernel onto t is L = {t : B t in im R}.  The kernel vectors with t = 0 must form
ker R; those with t != 0 are checked against every original equation.
Author: Dula."""
import time, os
import numpy as np, numba as nb
from o7 import GEN, GINV
from sparse_h1 import relator_arrays, _build_rows, _local_action_vec, MUL, INV
from sparse_big import closure2, _row_hash, _select_rows, SCHEDULE, _relabel, lift, check_all
import lanczos16
from lanczos16 import MASKS, to_bits, from_bits
import gf

# ------------------------------------------------------------------ GR(4,4) = Z[zeta5]/4
# element a0 + a1 z + a2 z^2 + a3 z^3 (a_i in Z/4, z = zeta_5, z^4 = -(1 + z + z^2 + z^3)) as a0 | a1<<2 | a2<<4 | a3<<6
def _gr_dec(x): return [(x >> (2 * i)) & 3 for i in range(4)]
def _gr_enc(a): return sum((int(a[i]) % 4) << (2 * i) for i in range(4))
def _gr_mul_raw(a, b):
    c = [0] * 7
    for i in range(4):
        for j in range(4): c[i + j] += a[i] * b[j]
    c[0] += c[5]; c[1] += c[6]
    return [(c[i] - c[4]) % 4 for i in range(4)]
def _gr_tables():
    dec = [_gr_dec(x) for x in range(256)]
    gmul = np.array([[_gr_enc(_gr_mul_raw(dec[a], dec[b])) for b in range(256)] for a in range(256)], dtype=np.uint8)
    gadd = np.array([[_gr_enc([dec[a][i] + dec[b][i] for i in range(4)]) for b in range(256)] for a in range(256)], dtype=np.uint8)
    gneg = np.array([_gr_enc([-v for v in dec[a]]) for a in range(256)], dtype=np.uint8)
    red = np.array([sum((dec[a][i] & 1) << i for i in range(4)) for a in range(256)], dtype=np.uint8)
    half = np.array([sum(((dec[a][i] >> 1) & 1) << i for i in range(4)) for a in range(256)], dtype=np.uint8)
    liftt = np.array([_gr_enc([(f >> i) & 1 for i in range(4)]) for f in range(16)], dtype=np.uint8)
    teich = np.zeros(16, dtype=np.uint8)                     # zeta_5^k for the codes of z^k; 0 = not in mu_5
    zk = 1; gk = _gr_enc([1, 0, 0, 0]); zeta = _gr_enc([0, 1, 0, 0])
    for k in range(5):
        teich[zk] = gk; zk = int(gf.MUL16[zk, 2]); gk = int(gmul[gk, zeta])
    return gmul, gadd, gneg, red, half, liftt, teich
GMUL, GADD, GNEG, RED, HALF, LIFT, TEICH = _gr_tables()

def gr_selftest():
    a = np.arange(256)
    assert (RED[GMUL] == gf.MUL16[RED[a][:, None], RED[a][None, :]]).all(), "reduction is not multiplicative"
    assert (RED[GADD] == (RED[a][:, None] ^ RED[a][None, :])).all(), "reduction is not additive"
    assert (GADD[a, GNEG[a]] == 0).all()
    mu5 = [1, 2, 4, 8, 15]
    for x in mu5:
        assert RED[TEICH[x]] == x
        for y in mu5: assert GMUL[TEICH[x], TEICH[y]] == TEICH[int(gf.MUL16[x, y])], "Teichmueller lift not multiplicative"
    t = TEICH[2]; p = 1
    for _ in range(5): p = GMUL[p, t]
    assert p == 1 and GMUL[TEICH[2], 1] == TEICH[2]
    two = _gr_enc([2, 0, 0, 0])
    for x in range(256):                                      # 2 * x = 2 * (x mod 2), and HALF inverts it
        assert HALF[GMUL[two, x]] == RED[x] and RED[GMUL[two, x]] == 0
    return True
gr_selftest()

# ------------------------------------------------------------------ quadratic characters of the components, per step
def component_info(L):
    """For each component k of (O/n)^x: the residue field size q_k, e_k = v_2(q_k - 1), and whether -1 is a non-square."""
    out = []
    for c in L.comps:
        q = c.p if c.typ == "Fp" else c.p * c.p
        e = 0; t = q - 1
        while t % 2 == 0: t //= 2; e += 1
        out.append({"typ": c.typ, "p": c.p, "q": q, "e2": e, "minus1_nonsquare": e == 1})
    return out

def quad_step_tables(L):
    """NXL[s, x] (uint8): bit k = lambda_k(scalar of component k for step s from coset x), lambda_k the quadratic
    character of the k-th component (Legendre symbol, of the norm for F_{p^2}); s < G generators, s >= G inverses.
    The local actions are recomputed by _local_action_vec and must reproduce L.NXT."""
    n = L.n; G = len(L.gens)
    mats = [GEN[g] for g in L.gens] + [GINV[g] for g in L.gens]
    xs = np.arange(n, dtype=np.int64)
    tabs = []
    for c in L.comps:
        p = c.p; ns = np.ones(p, dtype=np.uint8); ns[0] = 0
        ns[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 0
        if c.typ == "Fp": tabs.append(ns)
        else:
            uu, vv = np.meshgrid(np.arange(p, dtype=np.int64), np.arange(p, dtype=np.int64), indexing="ij")
            t = ns[(uu * uu + uu * vv + 2 * vv * vv) % p]; t[0, 0] = 0
            tabs.append(np.ascontiguousarray(t.astype(np.uint8))); del uu, vv
    nxl = np.zeros((2 * G, n), dtype=np.uint8)
    for s, M in enumerate(mats):
        acc = np.zeros(n, dtype=np.uint8); idx = np.zeros(n, dtype=np.int64)
        for k, c in enumerate(L.comps):
            Mr = tuple(c.red(e) for e in M)
            j, loc = _local_action_vec(c, Mr, tabs[k])
            ik = (xs // L.strides[k]) % L.sizes[k]
            acc ^= (loc[ik].astype(np.uint8) << np.uint8(k)); idx += j[ik] * L.strides[k]
        assert (idx == L.NXT[s]).all(), "local action differs from the level tables"
        nxl[s] = acc
    return nxl

def allowed_types(info):
    """Types of psi (2-power order, psi(-1) = 1) as (kind, eps): kind 'trivial', 'quadratic' (psi = sum eps_k lambda_k,
    values +-1) or 'ramified' (order 2^kappa >= 4; eps = psi^(2^(kappa-1)) written additively).  For a component with
    e = v_2(q - 1), psi_k(-1) = -1 iff psi_k has order exactly 2^e on the cyclic 2-Sylow."""
    import itertools
    J = len(info); e = [c["e2"] for c in info]; out = [("trivial", (0,) * J)]
    for eps in itertools.product((0, 1), repeat=J):
        if not any(eps): continue
        if sum(1 for k in range(J) if eps[k] and e[k] == 1) % 2 == 0: out.append(("quadratic", eps))
    seen = set()
    for eps in itertools.product((0, 1), repeat=J):
        if not any(eps): continue
        Sk = [k for k in range(J) if eps[k]]
        for kappa in range(2, max(e) + 1):
            if any(e[k] < kappa for k in Sk): continue
            base = sum(1 for k in Sk if e[k] == kappa)
            flexible = any(1 <= e[k] < kappa for k in range(J) if not eps[k])
            if base % 2 == 0 or flexible:
                if eps not in seen: out.append(("ramified", eps)); seen.add(eps)
                break
    return out

def type_rows(kind, eps, qs, colb, colc, m):
    """Rows phi(e_q) (q in qs) of the obstruction map for a type: b-column, plus eps_j c_j-columns (quadratic), or the
    c-columns alone (ramified)."""
    Phi = np.zeros((len(qs), m), dtype=np.uint8)
    for i, q in enumerate(qs):
        if kind in ("trivial", "quadratic"):
            assert colb[q] >= 0; Phi[i, colb[q]] = 1
        if kind in ("quadratic", "ramified"):
            for j, ej in enumerate(eps):
                if ej:
                    assert colc[q, j] >= 0; Phi[i, colc[q, j]] = 1
    return Phi

# ------------------------------------------------------------------ the RHS columns
@nb.njit(cache=True, parallel=True)
def rhs_matrix(nxt, nxe, nxl, tg, te, G, n, tree, cls_of, rfac, S, colb, colc, m, mul, gmul, gadd, gneg, red, half, liftt, teich):
    """Columns of B for the cocycles u_q with class values S[:, q] (edge value rfac[u] S[cls_of[u], q]):
    B[row, colb[q]] = (R~ u~_q)/2 mod 2 for the naive lift u~ (if colb[q] >= 0), B[row, colc[q, j]] = (R_{lambda_j} u_q)
    (if colc[q, j] >= 0).  Rows r*n + x as _build_rows.  Returns B and the number of (row, q) with R u_q != 0 mod 2
    (plus 10^6 per relator walk that does not close); both must be 0."""
    nr, T = tg.shape; K = S.shape[1]; J = colc.shape[1]
    B = np.zeros((nr * n, m), dtype=np.uint8)
    bad = np.zeros(n, dtype=np.int64)
    for x in nb.prange(n):
        accg = np.zeros(K, dtype=np.uint8); accl = np.zeros((K, max(J, 1)), dtype=np.uint8)
        for r in range(nr):
            accg[:] = 0; accl[:] = 0
            cur = np.int64(x); w = np.uint8(1); wg = np.uint8(1); lb = np.uint8(0)
            for jj in range(T):
                g = np.int64(tg[r, jj])
                if g < 0: break
                if te[r, jj] == 1:
                    u = g * n + cur; c16 = w; cg = wg; cl = lb
                    e = nxe[g, cur]; w = mul[w, e]; wg = gmul[wg, teich[e]]; lb ^= nxl[g, cur]; cur = np.int64(nxt[g, cur])
                else:
                    s = G + g
                    e = nxe[s, cur]; w = mul[w, e]; wg = gmul[wg, teich[e]]; lb ^= nxl[s, cur]; cur = np.int64(nxt[s, cur])
                    u = g * n + cur; c16 = w; cg = gneg[wg]; cl = lb
                if tree[u]: continue
                k = cls_of[u]
                if k < 0: continue
                f = rfac[u]
                for q in range(K):
                    v16 = mul[f, S[k, q]]
                    if v16 == 0: continue
                    accg[q] = gadd[accg[q], gmul[cg, liftt[v16]]]
                    if cl != 0:
                        t16 = mul[c16, v16]
                        for j in range(J):
                            if (cl >> j) & 1: accl[q, j] ^= t16
            row = r * n + x
            if cur != x: bad[x] += 1000000
            for q in range(K):
                if red[accg[q]] != 0: bad[x] += 1
                if colb[q] >= 0: B[row, colb[q]] = half[accg[q]]
                for j in range(J):
                    if colc[q, j] >= 0: B[row, colc[q, j]] = accl[q, j]
    return B, bad.sum()

# ------------------------------------------------------------------ conditions on t (small echelon basis)
@nb.njit(cache=True)
def cond_add(Cb, cpiv, nb_, vec, mul, inv):
    """Add vec (length m, overwritten) to the reduced echelon basis Cb[:nb_] (pivots cpiv); returns the new size."""
    m = vec.shape[0]
    for i in range(nb_):
        a = vec[cpiv[i]]
        if a != 0:
            for j in range(m): vec[j] ^= mul[a, Cb[i, j]]
    for j in range(m):
        if vec[j] != 0:
            s = inv[vec[j]]
            for jj in range(m): Cb[nb_, jj] = mul[s, vec[jj]]
            cpiv[nb_] = j
            for i in range(nb_):
                a = Cb[i, j]
                if a != 0:
                    for jj in range(m): Cb[i, jj] ^= mul[a, Cb[nb_, jj]]
            return nb_ + 1
    return nb_

@nb.njit(cache=True)
def cond_add_many(Cb, cpiv, nb_, rows, nrows, mul, inv):
    m = rows.shape[1]; vec = np.empty(m, dtype=np.uint8)
    for r in range(nrows):
        nz = False
        for j in range(m):
            vec[j] = rows[r, j]
            if vec[j] != 0: nz = True
        if nz: nb_ = cond_add(Cb, cpiv, nb_, vec, mul, inv)
    return nb_

class Conditions:
    def __init__(self, m):
        self.m = m; self.Cb = np.zeros((m + 1, max(m, 1)), dtype=np.uint8); self.piv = np.zeros(m + 1, dtype=np.int64); self.n = 0
    def add(self, rows):
        if rows.shape[0] and self.m:
            self.n = cond_add_many(self.Cb, self.piv, self.n, np.ascontiguousarray(rows), rows.shape[0], MUL, INV)
    def rows(self): return self.Cb[:self.n].copy()

# ------------------------------------------------------------------ affine closure
@nb.njit(cache=True)
def _find_aff(u, par, fac, off, mul, stack, O):
    """Root of u with path compression; afterwards x_w = fac[w] x_root + off[w] for every w on the path; O = off of u
    relative to the root (0 if u is the root)."""
    k = 0; v = u
    while par[v] != v:
        stack[k] = v; k += 1; v = par[v]
    m = off.shape[1]
    for j in range(m): O[j] = 0
    f = np.uint8(1)
    for i in range(k - 1, -1, -1):
        w = stack[i]; a = fac[w]
        for j in range(m): O[j] = mul[a, O[j]] ^ off[w, j]
        f = mul[a, f]
        fac[w] = f; par[w] = v
        for j in range(m): off[w, j] = O[j]
    return v

@nb.njit(cache=True)
def closure2_affine(cols, vals, ncol, B, Cb, cpiv, mul, inv):
    """closure2 of sparse_big.py for R x + B t = 0: the same decisions (made on the x-part), with offsets
    x_u = fac[u] x_root + off[u] . t; a zero class has x_root = off[root] . t (fixed).  Rows whose x-part vanishes
    give conditions on t (added to Cb).  Returns root (-1: fixed class), rfac, off (x_u = rfac[u] X_root + off[u] . t,
    with X_root = 0 for fixed classes), alive, passes, size of the condition basis."""
    R, T = cols.shape; m = B.shape[1]
    par = np.arange(ncol, dtype=np.int64); fac = np.ones(ncol, dtype=np.uint8); zero = np.zeros(ncol, dtype=np.bool_)
    off = np.zeros((ncol, m), dtype=np.uint8)
    stack = np.empty(ncol, dtype=np.int64)
    alive = np.ones(R, dtype=np.bool_)
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.uint8)
    RB = np.zeros(m, dtype=np.uint8); O = np.zeros(m, dtype=np.uint8); vec = np.zeros(m, dtype=np.uint8)
    ncond = 0
    changed = True; passes = 0
    while changed:
        changed = False; passes += 1
        for row in range(R):
            if not alive[row]: continue
            mm_ = 0
            for j in range(m): RB[j] = B[row, j]
            for t in range(T):
                u = cols[row, t]
                if u < 0: break
                v = _find_aff(u, par, fac, off, mul, stack, O)
                a = vals[row, t]
                f = fac[u] if u != v else np.uint8(1)
                for j in range(m): RB[j] ^= mul[a, O[j]]
                c = mul[a, f]
                if zero[v]:
                    for j in range(m): RB[j] ^= mul[c, off[v, j]]
                    continue
                found = False
                for s in range(mm_):
                    if rc[s] == v:
                        rv[s] ^= c; found = True; break
                if not found:
                    rc[mm_] = v; rv[mm_] = c; mm_ += 1
            k = 0
            for s in range(mm_):
                if rv[s] != 0:
                    rc[k] = rc[s]; rv[k] = rv[s]; k += 1
            if k == 0:
                alive[row] = False
                nz = False
                for j in range(m):
                    vec[j] = RB[j]
                    if RB[j] != 0: nz = True
                if nz: ncond = cond_add(Cb, cpiv, ncond, vec, mul, inv)
            elif k == 1:
                a0 = rc[0]; zero[a0] = True; s0 = inv[rv[0]]
                for j in range(m): off[a0, j] = mul[s0, RB[j]]
                alive[row] = False; changed = True
            elif k == 2:
                a = rc[0]; b = rc[1]; s0 = inv[rv[0]]
                par[a] = b; fac[a] = mul[rv[1], s0]
                for j in range(m): off[a, j] = mul[s0, RB[j]]
                alive[row] = False; changed = True
    for u in range(ncol):
        _find_aff(u, par, fac, off, mul, stack, O)
    root = np.empty(ncol, dtype=np.int64); rfac = np.zeros(ncol, dtype=np.uint8)
    for u in range(ncol):
        v = par[u]
        if u == v:
            if zero[v]:
                root[u] = -1; rfac[u] = 0
            else:
                root[u] = u; rfac[u] = 1
        else:
            if zero[v]:
                root[u] = -1; rfac[u] = 0
                for j in range(m): off[u, j] ^= mul[fac[u], off[v, j]]
            else:
                root[u] = v; rfac[u] = fac[u]
    return root, rfac, off, alive, passes, ncond

@nb.njit(cache=True)
def rows_to_csr_affine(cols, vals, alive, cls_of, rfac, off, B, mul, inv):
    """Alive rows over class ids (merged, sorted, normalized: first coefficient 1) with their RHS rows
    B[row] + sum_t vals_t off[u_t] (scaled alike).  Returns ptr, col, val, hash (of the x-part), RHS, and the RHS rows
    of alive rows with an empty x-part (conditions)."""
    R, T = cols.shape; m = B.shape[1]
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.uint8)
    lens = np.zeros(R, dtype=np.int64); total = 0; nrows = 0; nempty = 0
    for row in range(R):
        if not alive[row]: continue
        mm_ = 0
        for t in range(T):
            u = cols[row, t]
            if u < 0: break
            v = cls_of[u]
            if v < 0: continue
            c = mul[vals[row, t], rfac[u]]
            found = False
            for s in range(mm_):
                if rc[s] == v:
                    rv[s] ^= c; found = True; break
            if not found:
                rc[mm_] = v; rv[mm_] = c; mm_ += 1
        k = 0
        for s in range(mm_):
            if rv[s] != 0: k += 1
        lens[row] = k; total += k
        if k: nrows += 1
        else: nempty += 1
    ptr = np.zeros(nrows + 1, dtype=np.int64); col = np.empty(total, dtype=np.int32); val = np.empty(total, dtype=np.uint8)
    hs = np.empty(nrows, dtype=np.uint64); RHS = np.zeros((nrows, m), dtype=np.uint8); EMP = np.zeros((nempty, m), dtype=np.uint8)
    RB = np.zeros(m, dtype=np.uint8)
    r = 0; p = 0; e = 0
    for row in range(R):
        if not alive[row]: continue
        for j in range(m): RB[j] = B[row, j]
        mm_ = 0
        for t in range(T):
            u = cols[row, t]
            if u < 0: break
            a = vals[row, t]
            for j in range(m): RB[j] ^= mul[a, off[u, j]]
            v = cls_of[u]
            if v < 0: continue
            c = mul[a, rfac[u]]
            found = False
            for s in range(mm_):
                if rc[s] == v:
                    rv[s] ^= c; found = True; break
            if not found:
                rc[mm_] = v; rv[mm_] = c; mm_ += 1
        if lens[row] == 0:
            for j in range(m): EMP[e, j] = RB[j]
            e += 1; continue
        k = 0
        for s in range(mm_):
            if rv[s] != 0:
                rc[k] = rc[s]; rv[k] = rv[s]; k += 1
        for i in range(1, k):
            a = rc[i]; b = rv[i]; j = i - 1
            while j >= 0 and rc[j] > a:
                rc[j + 1] = rc[j]; rv[j + 1] = rv[j]; j -= 1
            rc[j + 1] = a; rv[j + 1] = b
        s0 = inv[rv[0]]
        for i in range(k):
            col[p + i] = rc[i]; val[p + i] = mul[s0, rv[i]]
        for j in range(m): RHS[r, j] = mul[s0, RB[j]]
        hs[r] = _row_hash(col[p:p + k], val[p:p + k], k)
        p += k; r += 1; ptr[r] = p
    return ptr, col, val, hs, RHS, EMP

# ------------------------------------------------------------------ deduplication with RHS
@nb.njit(cache=True)
def _dedup_rep(ptr, col, val, hs, order):
    """rep[r] = r for kept rows, else the kept row with the same (normalized) x-part."""
    n = order.shape[0]; rep = np.full(n, -1, dtype=np.int64)
    i = 0
    while i < n:
        j = i
        while j < n and hs[order[j]] == hs[order[i]]: j += 1
        for a in range(i, j):
            ra = order[a]
            for b in range(i, a):
                rb = order[b]
                if rep[rb] != rb: continue
                la = ptr[ra + 1] - ptr[ra]; lb = ptr[rb + 1] - ptr[rb]
                if la != lb: continue
                same = True
                for t in range(la):
                    if col[ptr[ra] + t] != col[ptr[rb] + t] or val[ptr[ra] + t] != val[ptr[rb] + t]:
                        same = False; break
                if same:
                    rep[ra] = rb; break
            if rep[ra] < 0: rep[ra] = ra
        i = j
    return rep

@nb.njit(cache=True)
def _dup_conditions(rep, RHS):
    n = rep.shape[0]; m = RHS.shape[1]; nd = 0
    for r in range(n):
        if rep[r] != r: nd += 1
    out = np.zeros((nd, m), dtype=np.uint8); k = 0
    for r in range(n):
        if rep[r] != r:
            for j in range(m): out[k, j] = RHS[r, j] ^ RHS[rep[r], j]
            k += 1
    return out

@nb.njit(cache=True)
def _hash_rows_norm(ptr, col, val, RHS, mul, inv):
    """Normalize every row (first x-coefficient 1, RHS scaled alike) in place and hash its x-part."""
    R = ptr.shape[0] - 1; hs = np.empty(R, dtype=np.uint64); m = RHS.shape[1]
    for r in range(R):
        lo = ptr[r]; hi = ptr[r + 1]
        if hi > lo:
            s = inv[val[lo]]
            if s != 1:
                for t in range(lo, hi): val[t] = mul[s, val[t]]
                for j in range(m): RHS[r, j] = mul[s, RHS[r, j]]
        hs[r] = _row_hash(col[lo:hi], val[lo:hi], hi - lo)
    return hs

def dedup_aug(ptr, col, val, RHS, conds, hs=None):
    if hs is None: hs = _hash_rows_norm(ptr, col, val, RHS, MUL, INV)
    order = np.argsort(hs, kind="stable")
    rep = _dedup_rep(ptr, col, val, hs, order)
    conds.add(_dup_conditions(rep, RHS))
    keep = rep == np.arange(len(rep))
    p2, c2, v2 = _select_rows(ptr, col, val, keep)
    return p2, c2, v2, RHS[keep]

# ------------------------------------------------------------------ Markowitz rounds with RHS
@nb.njit(cache=True)
def _mk_round_aug(ptr, col, val, RHS, ncls, maxcost, mul, inv):
    R = ptr.shape[0] - 1; nnz = ptr[R]; m = RHS.shape[1]
    cw = np.zeros(ncls, dtype=np.int64)
    for t in range(nnz): cw[col[t]] += 1
    cptr = np.zeros(ncls + 1, dtype=np.int64)
    for c in range(ncls): cptr[c + 1] = cptr[c] + cw[c]
    crow = np.empty(nnz, dtype=np.int32); fp = cptr[:ncls].copy()
    for r in range(R):
        for t in range(ptr[r], ptr[r + 1]):
            c = col[t]; crow[fp[c]] = r; fp[c] += 1
    cand_cost = np.empty(ncls, dtype=np.int64); cand_col = np.empty(ncls, dtype=np.int64)
    prow = np.full(ncls, -1, dtype=np.int64); nc = 0
    for c in range(ncls):
        w = cw[c]
        if w == 0: continue
        best = -1; bl = 1 << 62
        for k in range(cptr[c], cptr[c + 1]):
            r = crow[k]; l = ptr[r + 1] - ptr[r]
            if l < bl:
                bl = l; best = r
        mc = (w - 1) * (bl - 1)
        if mc <= maxcost:
            cand_cost[nc] = mc; cand_col[nc] = c; prow[c] = best; nc += 1
    order = np.argsort(cand_cost[:nc], kind="mergesort")
    used = np.zeros(R, dtype=np.bool_)
    piv_of = np.full(R, -1, dtype=np.int64); mod_by = np.full(R, -1, dtype=np.int64)
    nsel = 0; extra = 0
    for oi in range(nc):
        c = cand_col[order[oi]]; ok = True
        for k in range(cptr[c], cptr[c + 1]):
            if used[crow[k]]:
                ok = False; break
        if not ok: continue
        p = prow[c]; lp = ptr[p + 1] - ptr[p]
        for k in range(cptr[c], cptr[c + 1]):
            r = crow[k]; used[r] = True
            if r == p: piv_of[r] = c
            else:
                mod_by[r] = c; extra += lp - 2
        nsel += 1
    bound = nnz + max(extra, 0)
    nptr = np.zeros(R + 1, dtype=np.int64); ncol_ = np.empty(bound, dtype=np.int32); nval = np.empty(bound, dtype=np.uint8)
    nRHS = np.empty((R, m), dtype=np.uint8); nemp = 0
    total_rec = 0
    for r in range(R):
        if piv_of[r] >= 0: total_rec += ptr[r + 1] - ptr[r]
    rec_c = np.empty(nsel, dtype=np.int32); rec_ptr = np.zeros(nsel + 1, dtype=np.int64)
    rec_col = np.empty(total_rec, dtype=np.int32); rec_val = np.empty(total_rec, dtype=np.uint8)
    rec_rhs = np.empty((nsel, m), dtype=np.uint8)
    EMP = np.empty((R, m), dtype=np.uint8)
    rb = np.empty(m, dtype=np.uint8)
    nr = 0; k = 0; ki = 0; kr = 0
    for r in range(R):
        if piv_of[r] >= 0:
            rec_c[ki] = piv_of[r]
            for t in range(ptr[r], ptr[r + 1]):
                rec_col[kr] = col[t]; rec_val[kr] = val[t]; kr += 1
            for j in range(m): rec_rhs[ki, j] = RHS[r, j]
            ki += 1; rec_ptr[ki] = kr
            continue
        c = mod_by[r]
        if c < 0:
            for t in range(ptr[r], ptr[r + 1]):
                ncol_[k] = col[t]; nval[k] = val[t]; k += 1
            for j in range(m): rb[j] = RHS[r, j]
        else:
            p = prow[c]; arc = 0; apc = 0
            for t in range(ptr[r], ptr[r + 1]):
                if col[t] == c:
                    arc = val[t]; break
            for t in range(ptr[p], ptr[p + 1]):
                if col[t] == c:
                    apc = val[t]; break
            f = mul[arc, inv[apc]]
            i = ptr[r]; ie = ptr[r + 1]; j = ptr[p]; je = ptr[p + 1]
            while i < ie or j < je:
                if j >= je or (i < ie and col[i] < col[j]):
                    ncol_[k] = col[i]; nval[k] = val[i]; k += 1; i += 1
                elif i >= ie or col[j] < col[i]:
                    ncol_[k] = col[j]; nval[k] = mul[f, val[j]]; k += 1; j += 1
                else:
                    v = val[i] ^ mul[f, val[j]]
                    if v != 0:
                        ncol_[k] = col[i]; nval[k] = v; k += 1
                    i += 1; j += 1
            for jj in range(m): rb[jj] = RHS[r, jj] ^ mul[f, RHS[p, jj]]
        if k > nptr[nr]:
            for jj in range(m): nRHS[nr, jj] = rb[jj]
            nr += 1; nptr[nr] = k
        else:
            for jj in range(m): EMP[nemp, jj] = rb[jj]
            nemp += 1
    return (nptr[:nr + 1].copy(), ncol_[:k].copy(), nval[:k].copy(), nRHS[:nr].copy(), rec_c, rec_ptr, rec_col, rec_val,
            rec_rhs, nsel, EMP[:nemp].copy())

def markowitz_aug(ptr, col, val, RHS, ncls, conds, fill=8.0, verbose=True, min_frac=0.002):
    t0 = time.time(); nnz0 = len(col); bound = fill * nnz0; records = []; nrounds = 0
    for maxcost in SCHEDULE:
        while True:
            out = _mk_round_aug(ptr, col, val, RHS, ncls, maxcost, MUL, INV)
            nsel = out[9]
            if nsel == 0: break
            ptr, col, val, RHS = out[0], out[1], out[2], out[3]; records.append(out[4:9]); nrounds += 1
            conds.add(out[10])
            if len(col) > bound: break
            live = int(np.count_nonzero(np.bincount(col, minlength=ncls))) if nrounds % 4 == 0 else None
            if live is not None and nsel < min_frac * live: break
        if len(col) > bound: break
        ptr, col, val, RHS = dedup_aug(ptr, col, val, RHS, conds)
        if verbose:
            live = int(np.count_nonzero(np.bincount(col, minlength=ncls)))
            print("    cost <= %d: %d rounds, %d rows, %d live columns, nnz %d, conditions %d (%.0fs)" % (maxcost, nrounds, len(ptr) - 1, live, len(col), conds.n, time.time() - t0), flush=True)
    ptr, col, val, RHS = dedup_aug(ptr, col, val, RHS, conds)
    return ptr, col, val, RHS, records

@nb.njit(cache=True)
def _records_with_rhs(rec_ptr, rec_col, rec_val, rec_rhs, ncls):
    """Append the RHS of each pivot row as entries on the t-classes ncls + j."""
    ns = rec_ptr.shape[0] - 1; m = rec_rhs.shape[1]
    extra = 0
    for i in range(ns):
        for j in range(m):
            if rec_rhs[i, j] != 0: extra += 1
    p2 = np.zeros(ns + 1, dtype=np.int64); c2 = np.empty(rec_col.shape[0] + extra, dtype=np.int32); v2 = np.empty(rec_col.shape[0] + extra, dtype=np.uint8)
    k = 0
    for i in range(ns):
        for t in range(rec_ptr[i], rec_ptr[i + 1]):
            c2[k] = rec_col[t]; v2[k] = rec_val[t]; k += 1
        for j in range(m):
            if rec_rhs[i, j] != 0:
                c2[k] = ncls + j; v2[k] = rec_rhs[i, j]; k += 1
        p2[i + 1] = k
    return p2, c2, v2

@nb.njit(cache=True)
def _core_with_rhs(ptr, ccol, val, RHS, Crows, C):
    """Core CSR: x-part (core ids < C) followed by the RHS entries on columns C + j; then the condition rows."""
    R = ptr.shape[0] - 1; m = RHS.shape[1]; nc = Crows.shape[0]
    extra = 0
    for r in range(R):
        for j in range(m):
            if RHS[r, j] != 0: extra += 1
    for r in range(nc):
        for j in range(m):
            if Crows[r, j] != 0: extra += 1
    p2 = np.zeros(R + nc + 1, dtype=np.int64); c2 = np.empty(ccol.shape[0] + extra, dtype=np.int32); v2 = np.empty(ccol.shape[0] + extra, dtype=np.uint8)
    k = 0
    for r in range(R):
        for t in range(ptr[r], ptr[r + 1]):
            c2[k] = ccol[t]; v2[k] = val[t]; k += 1
        for j in range(m):
            if RHS[r, j] != 0:
                c2[k] = C + j; v2[k] = RHS[r, j]; k += 1
        p2[r + 1] = k
    for r in range(nc):
        for j in range(m):
            if Crows[r, j] != 0:
                c2[k] = C + j; v2[k] = Crows[r, j]; k += 1
        p2[R + r + 1] = k
    return p2, c2[:k].copy(), v2[:k].copy()

# ------------------------------------------------------------------ checks
@nb.njit(cache=True, parallel=True)
def check_vec_aug(nxt, nxe, tg, te, G, n, tree, cls_of, rfac, off, B, X, t, mul):
    """Number of equations of R x + B t = 0 failed by x_u = rfac[u] X[cls_of[u]] + off[u] . t (X: class values, F16)."""
    nr, T = tg.shape; m = B.shape[1]; ncol = cls_of.shape[0]
    xo = np.zeros(ncol, dtype=np.uint8)
    for u in nb.prange(ncol):
        s = np.uint8(0)
        for j in range(m): s ^= mul[off[u, j], t[j]]
        k = cls_of[u]
        if k >= 0: s ^= mul[rfac[u], X[k]]
        xo[u] = s
    bad = np.zeros(n, dtype=np.int64)
    for x in nb.prange(n):
        for r in range(nr):
            acc = np.uint8(0); cur = np.int64(x); w = np.uint8(1)
            for jj in range(T):
                g = np.int64(tg[r, jj])
                if g < 0: break
                if te[r, jj] == 1:
                    u = g * n + cur; c = w; w = mul[w, nxe[g, cur]]; cur = np.int64(nxt[g, cur])
                else:
                    w = mul[w, nxe[G + g, cur]]; cur = np.int64(nxt[G + g, cur]); u = g * n + cur; c = w
                if tree[u]: continue
                acc ^= mul[c, xo[u]]
            row = r * n + x
            for j in range(m): acc ^= mul[B[row, j], t[j]]
            if acc != 0 or cur != x: bad[x] += 1
    return bad.sum()

# ------------------------------------------------------------------ the solver
class AugSolve:
    """Kernel of R x + B t = 0 for the level L and RHS columns B; L_t = projection of the kernel on t.
    B may be a memory-mapped array.  dimker_R: dim ker R (gauge-fixed cocycles) if known, for the check; ref_closure:
    (cls_of, rfac) of the homogeneous closure, which the affine closure must reproduce.  cache: directory for the
    stages (reduction, Lanczos runs and checkpoints, the offsets), so that an interrupted run can be resumed."""
    def __init__(self, L, B, fill=8.0, seed=1, lanczos_w=4, dense_max=6000, verbose=True, cache=None, dimker_R=None,
                 ref_closure=None):
        self.L = L; G = len(L.gens); n = L.n; m = B.shape[1]; self.m = m; t0 = time.time(); self.t = {}
        tg, te = relator_arrays(L); self.tg, self.te = tg, te
        red_path = None if cache is None else os.path.join(cache, "aug_reduction.npz")
        off_path = None if cache is None else os.path.join(cache, "aug_off.npy")
        if cache is not None: os.makedirs(cache, exist_ok=True)
        if red_path is not None and os.path.exists(red_path) and os.path.exists(off_path):
            z = np.load(red_path)
            for k in ("cls_of", "rfac", "rec_c", "rec_ptr", "rec_col", "rec_val", "core_cls", "free_cls", "cp", "cc", "cv", "Cb", "cpiv"):
                setattr(self, k, z[k])
            self.ncls = int(z["ncls"]); self.core_shape = tuple(int(v) for v in z["core_shape"]); self.t["reduction"] = float(z["t_reduction"])
            self.conds = Conditions(m); self.conds.Cb = self.Cb; self.conds.piv = self.cpiv; self.conds.n = int(z["ncond"]); del z
            self.off = np.load(off_path, mmap_mode="r")
            if verbose: print("  augmented reduction loaded from %s: core %d x %d, nnz %d" % (red_path, *self.core_shape), flush=True)
        else:
            self._reduce(B, fill, verbose, ref_closure, red_path, off_path)
        if ref_closure is not None:
            assert (ref_closure[0] == self.cls_of).all() and (ref_closure[1] == self.rfac).all(), "affine closure differs from the homogeneous closure"
            self.closure_matches_reference = True
        cls_of, rfac, off, ncls = self.cls_of, self.rfac, self.off, self.ncls
        C = self.core_shape[1]
        t1 = time.time()
        Kc = self._core(self.cp, self.cc, self.cv, C, seed, lanczos_w, dense_max, verbose, cache)
        self.t["core"] = time.time() - t1
        del self.cp, self.cc, self.cv
        dcore = Kc.shape[0]; d = dcore + len(self.free_cls); self.d = d
        wd = max(1, (d + 63) // 64); self.wd = wd
        Kcb = to_bits(Kc.T.copy(), wd) if dcore else np.zeros((C, 4, wd), dtype=np.uint64)
        del Kc
        V = lift(ncls + m, self.core_cls, Kcb, self.free_cls, d, self.rec_c, self.rec_ptr, self.rec_col, self.rec_val, MASKS, INV, wd)
        del Kcb
        self.Tm = from_bits(V[ncls:ncls + m].copy(), d)            # (m, d): t-values of the kernel vectors
        A = self.Tm.copy(); piv = list(gf.rref16(A, MUL, INV)); self.rank_t = len(piv)
        Kt = gf.kernel16(self.Tm)                                   # (d - r, d): combinations with t = 0
        self.dim_t0 = Kt.shape[0]
        if verbose: print("  kernel of the augmented system: %d; rank of its t-part (dim L): %d; vectors with t = 0: %d%s (%.0fs)"
                          % (d, self.rank_t, self.dim_t0, "" if dimker_R is None else " (dim ker R = %d)" % dimker_R, time.time() - t0), flush=True)
        if dimker_R is not None: assert self.dim_t0 == dimker_R, "t = 0 part differs from ker R"
        t2 = time.time()
        if self.dim_t0:
            V0 = lanczos16.mulmat(V[:ncls], Kt.T.copy())
            bad = check_all(L.NXT, L.NXE, tg, te, G, n, L.TREE, cls_of, rfac, V0, MASKS, MUL)
            assert bad == 0, "t = 0 kernel vectors fail %d equations" % bad
            del V0
        if self.rank_t:
            # rows (t-part of kernel vector i | e_i), reduced: rows with a pivot < m give an echelon basis of L and
            # the combinations q of kernel vectors that have these t-parts
            M2 = np.concatenate([self.Tm.T, np.eye(d, dtype=np.uint8)], axis=1).copy()   # (d, m + d)
            pv = list(gf.rref16(M2, MUL, INV))
            sel = [i for i, p in enumerate(pv) if p < m]
            Q = M2[sel, m:]                                          # (r, d): Q Tm^T = echelon rows of L
            self.Lech = M2[sel, :m].copy()
            for i in range(Q.shape[0]):
                X = from_bits(lanczos16.mulmat(V[:ncls], Q[i][:, None].copy()), 1)[:, 0].copy()
                tt = self.Lech[i].copy()
                bad = check_vec_aug(L.NXT, L.NXE, tg, te, G, n, L.TREE, cls_of, rfac, off, B, X, tt, MUL)
                assert bad == 0, "kernel vector with t != 0 fails %d equations" % bad
        else:
            self.Lech = np.zeros((0, m), dtype=np.uint8)
        del V
        self.t["checks"] = time.time() - t2
        if verbose: print("  checks: the %d vectors with t = 0 and the %d with t != 0 satisfy all %d equations (%.0fs)" % (self.dim_t0, self.rank_t, tg.shape[0] * n, time.time() - t2), flush=True)

    def _reduce(self, B, fill, verbose, ref_closure, red_path, off_path):
        L = self.L; G = len(L.gens); n = L.n; ncol = G * n; m = self.m; t0 = time.time(); tg, te = self.tg, self.te
        self.conds = Conditions(m)
        cols, vals = _build_rows(L.NXT, L.NXE, tg, te, G, n, L.TREE, MUL)
        assert not (cols[:, 0] == -2).any()
        assert cols.shape[0] == B.shape[0]
        root, rfac, off, alive, passes, ncond = closure2_affine(cols, vals, ncol, B, self.conds.Cb, self.conds.piv, MUL, INV)
        self.conds.n = ncond
        root[L.TREE] = -1; rfac[L.TREE] = 0; off[L.TREE] = 0
        reps = np.unique(root[root >= 0]); ncls = len(reps)
        cls_of = -np.ones(ncol, dtype=np.int32)
        pos = -np.ones(ncol, dtype=np.int64); pos[reps] = np.arange(ncls)
        mk = root >= 0; cls_of[mk] = pos[root[mk]].astype(np.int32); del pos, mk, root, reps
        if ref_closure is not None:
            assert (ref_closure[0] == cls_of).all() and (ref_closure[1] == rfac).all(), "affine closure differs from the homogeneous closure"
        self.cls_of, self.rfac, self.ncls = cls_of, rfac, ncls
        if verbose: print("  affine closure (%d passes): %d classes, %d equations left, conditions on t: %d (%.0fs)" % (passes, ncls, int(alive.sum()), self.conds.n, time.time() - t0), flush=True)
        ptr, col, val, hs, RHS, EMP = rows_to_csr_affine(cols, vals, alive, cls_of, rfac, off, B, MUL, INV)
        del cols, vals, alive
        if off_path is not None:
            np.save(off_path, off); del off
            self.off = np.load(off_path, mmap_mode="r")
        else:
            self.off = off
        self.conds.add(EMP); del EMP
        ptr, col, val, RHS = dedup_aug(ptr, col, val, RHS, self.conds, hs); del hs
        if verbose: print("  deduplicated: %d equations, nnz %d, conditions %d (%.0fs)" % (len(ptr) - 1, len(col), self.conds.n, time.time() - t0), flush=True)
        ptr, col, val, RHS, records = markowitz_aug(ptr, col, val, RHS, ncls, self.conds, fill=fill, verbose=verbose)
        self.rec_c = np.concatenate([r[0] for r in records]) if records else np.zeros(0, np.int32)
        if records:
            offs = np.cumsum([0] + [len(r[2]) for r in records])
            rp = np.concatenate([[0]] + [r[1][1:] + o for r, o in zip(records, offs[:-1])]).astype(np.int64)
            rcol = np.concatenate([r[2] for r in records]); rval = np.concatenate([r[3] for r in records])
            rrhs = np.concatenate([r[4] for r in records])
        else:
            rp = np.zeros(1, np.int64); rcol = np.zeros(0, np.int32); rval = np.zeros(0, np.uint8); rrhs = np.zeros((0, m), np.uint8)
        del records
        self.rec_ptr, self.rec_col, self.rec_val = _records_with_rhs(rp, rcol, rval, rrhs, ncls)
        del rp, rcol, rval, rrhs
        cw = np.bincount(col, minlength=ncls)
        elim = np.zeros(ncls, dtype=np.bool_); elim[self.rec_c] = True
        core_x = np.nonzero(cw > 0)[0]; free_x = np.nonzero((cw == 0) & ~elim)[0]
        Cx = len(core_x)
        newid = -np.ones(ncls, dtype=np.int64); newid[core_x] = np.arange(Cx)
        ccol = _relabel(col, newid); del col
        Crows = self.conds.rows()
        self.cp, self.cc, self.cv = _core_with_rhs(ptr, ccol, val, RHS, Crows, Cx)
        del ptr, ccol, val, RHS
        C = Cx + m
        self.core_cls = np.concatenate([core_x, ncls + np.arange(m)]).astype(np.int64); self.free_cls = free_x.astype(np.int64)
        self.core_shape = (len(self.cp) - 1, C, len(self.cc))
        self.t["reduction"] = time.time() - t0
        if verbose: print("  Markowitz: %d classes eliminated; core %d equations x (%d + %d RHS) columns, nnz %d; conditions %d; free classes %d (%.0fs)"
                          % (len(self.rec_c), len(self.cp) - 1, Cx, m, len(self.cc), self.conds.n, len(free_x), time.time() - t0), flush=True)
        if red_path is not None:
            np.savez(red_path, cls_of=self.cls_of, rfac=self.rfac, rec_c=self.rec_c, rec_ptr=self.rec_ptr, rec_col=self.rec_col,
                     rec_val=self.rec_val, core_cls=self.core_cls, free_cls=self.free_cls, cp=self.cp, cc=self.cc, cv=self.cv,
                     Cb=self.conds.Cb, cpiv=self.conds.piv, ncond=self.conds.n, ncls=self.ncls, core_shape=np.array(self.core_shape),
                     t_reduction=self.t["reduction"])

    def _core(self, ptr, ccol, val, C, seed, lanczos_w, dense_max, verbose, cache):
        import json
        self.lanczos_runs = []; self.complete = True
        if C <= dense_max:
            rng = np.random.default_rng(seed); mrows = C + 48
            Mc = np.zeros((mrows, C), dtype=np.uint8)
            for r in range(len(ptr) - 1):
                cs = ccol[ptr[r]:ptr[r + 1]].astype(np.int64); vs = val[ptr[r]:ptr[r + 1]]
                for _ in range(3):
                    t = int(rng.integers(mrows)); f = int(rng.integers(1, 16)); Mc[t, cs] ^= MUL[f, vs]
            import gf16_bits
            Kc, _ = gf16_bits.kernel_bits(Mc)
            bad = lanczos16.check_block(ptr, ccol, val, to_bits(Kc.T.copy(), max(1, (Kc.shape[0] + 63) // 64)), Kc.shape[0])
            assert not bad.any(), "dense core kernel fails the core equations"
            # the compression can only enlarge the kernel; the check shows every vector is a true kernel vector
            return Kc
        w = lanczos_w; sd = seed; extra = 0
        runs_file = None if cache is None else os.path.join(cache, "lanczos_runs.json")
        if runs_file is not None and os.path.exists(runs_file):
            self.lanczos_runs = json.load(open(runs_file))
            for r in self.lanczos_runs:
                g = r["gap"]
                if r["kernel"] >= g or r["kerA_in_span"] >= g: continue
                if r["block"] < g + 64: w = max(w, g // 64 + 2)
                else:
                    extra += 1; sd = seed + 7919 * extra; w = max(w, r["block"] // 64)
        while True:
            ck = None if cache is None else os.path.join(cache, "lanczos_w%d_s%d.npz" % (w, sd))
            Kc, info = lanczos16.lanczos_kernel(ptr, ccol, val, C, w, seed=sd, verbose=verbose, ckpt=ck)
            self.lanczos_runs.append(info)
            if runs_file is not None:
                with open(runs_file, "w") as f: json.dump(self.lanczos_runs, f)
            g = info["gap"]
            if Kc.shape[0] >= g or info["kerA_in_span"] >= g:
                self.complete = True; break
            if 64 * w < g + 64:
                w = g // 64 + 2
                if verbose: print("  kernel found %d < %d: block widened to %d" % (Kc.shape[0], g, 64 * w), flush=True)
                continue
            extra += 1
            if extra > 2:
                self.complete = False; break
            sd = seed + 7919 * extra
        return Kc

    # ---------------------------------------------------------------- reading L
    def in_L(self, vec):
        """Is the vector (length m, uint8) in L = {t : B t in im R}?"""
        if self.rank_t == 0: return not np.any(vec)
        A = np.concatenate([self.Lech, np.asarray(vec, dtype=np.uint8)[None, :]], axis=0).copy()
        return len(gf.rref16(A, MUL, INV)) == self.rank_t

    def preimage_dim(self, Phi):
        """Phi: (k, m) rows phi(e_i).  Returns (dim, basis rows a in F16^k) of {a : sum_i a_i phi(e_i) in L}."""
        k = Phi.shape[0]
        M = np.concatenate([Phi, self.Lech], axis=0).T.copy()        # (m, k + r): columns phi(e_i), then L
        Kk = gf.kernel16(M)                                          # combinations giving 0
        A = Kk[:, :k].copy()
        if A.shape[0] == 0: return 0, A
        piv = list(gf.rref16(A, MUL, INV))
        return len(piv), A[:len(piv)].copy()
