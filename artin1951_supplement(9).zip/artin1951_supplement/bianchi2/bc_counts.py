"""Number of base changes from Q to E = Q(sqrt-7) at level N O_E (N prime to 7) for the nebentypus chi*psi, chi = eps o N
with eps of order 5 modulo N, and psi = psi0 o N a quadratic twist that is Galois-invariant (psi0 a quadratic Dirichlet
character modulo N, or psi0 = 1).

f in S_2(Gamma_0(M), eps') base changes to nebentypus eps' o N; eps' o N = (eps psi0) o N iff eps' = eps psi0 or
eps psi0 chi_-7.  An odd eps' contributes nothing in weight 2.  For eps' = eps psi0 (even): every f in the full cusp
space S_2(Gamma_0(N), eps') gives one class (oldforms with their multiplicity).  For eps' = eps psi0 chi_-7 (even, so
psi0 is odd): f has level 7 N', the local component at 7 is pi(1, chi_-7), its base change is unramified at sqrt-7,
and f, f (x) chi_-7 have the same base change: the count is dim S_2(Gamma_0(7N), eps')/2.  No form here has CM by E
(that needs 7 | level and norms of ideals of E).  Usage: python3 bc_counts.py N.  Author: Dula."""
import sys, json
import cypari2
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
N = int(sys.argv[1])
ps = [int(p) for p in pari("factor(%d)[,1]~" % N)]
out = {"N": N, "types": []}
def dimS(M, cond_pred):
    """dim of the full cusp space at level M for the characters (up to Galois) selected by cond_pred(G, i)."""
    pari("G = znstar(%d, 1); L = chargalois(G);" % M)
    res = []
    for i in range(1, int(pari("#L")) + 1):
        if cond_pred(i): res.append(int(pari("mfdim([%d, 2, [G, L[%d]]], 1)" % (M, i))))
    return res
import itertools
for S in itertools.chain.from_iterable(itertools.combinations(ps, k) for k in range(len(ps) + 1)):
    d = 1
    for p in S: d *= p
    # psi0 = Legendre symbol modulo d (product over p in S); parity: odd iff an odd number of p = 3 mod 4
    odd0 = sum(1 for p in S if p % 4 == 3) % 2 == 1
    rec = {"psi0_modulus": d, "psi0_odd": odd0}
    def pred_direct(i, d=d):
        if int(pari("charorder(G, L[%d])" % i)) != (5 if d == 1 else 10): return False
        if int(pari("zncharisodd(G, L[%d])" % i)): return False
        c2 = int(pari("zncharconductor(G, charpow(G, L[%d], 5))" % i))
        return c2 == d
    def pred_tw(i, d=d):
        if int(pari("charorder(G, L[%d])" % i)) != 10: return False
        if int(pari("zncharisodd(G, L[%d])" % i)): return False
        c2 = int(pari("zncharconductor(G, charpow(G, L[%d], 5))" % i))
        return c2 == 7 * d
    if not odd0:
        dims = dimS(N, pred_direct); rec["direct"] = dims; rec["count"] = dims[0] if dims else 0
    else:
        dims = dimS(7 * N, pred_tw); rec["via_chi_-7"] = dims
        assert all(x % 2 == 0 for x in dims)
        rec["count"] = dims[0] // 2 if dims else 0
    out["types"].append(rec)
    print(rec, flush=True)
json.dump(out, open("bc_counts_%d.json" % N, "w"), indent=1)
