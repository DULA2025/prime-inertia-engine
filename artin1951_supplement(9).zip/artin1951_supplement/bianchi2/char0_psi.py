"""Characteristic-0 Bianchi cohomology at a small level with a nebentypus psi of 2-power order, and the reduction modulo
the prime above 2 of its Hecke characteristic polynomials.

For psi of order 2^k on the unit group of one component of (O/n)^x (psi(g^a) = zeta^a, g a generator), the cohomology
H^1(Gamma_0(n), Q(zeta)(psi)) for PGL_2(O_E) is computed over F_P for every embedding zeta -> zeta_P^j (j odd), P = 1
mod 2^k (dense engine bmf.py; P two different primes).  The characteristic polynomials of T_v, T_vbar and T_v + T_vbar
have coefficients in Z[zeta]; they are reconstructed from the 2^(k-1) embeddings (Vandermonde system mod P, symmetric
lift, checked against the second prime) and reduced modulo varpi = 1 - zeta (residue field F_2: zeta -> 1).
A form whose eigenvalues reduce to a mixed pair (x, y), x != y, has T_v + T_vbar = x + y != 0 modulo varpi.
Usage: python3 char0_psi.py CASE K   (CASE 23, 31, 47 as in bock_small.py; psi of order 2^K, K >= 1).  Author: Dula."""
import sys, json, time
import numpy as np, cypari2
from bmf import Comp, Level
from hecke import hecke_matrix
from charpoly import charpoly_modp
from mod2_refine import root as sroot
import gf
pari = cypari2.Pari()
t0 = time.time(); case = sys.argv[1]; Kexp = int(sys.argv[2]); order = 2 ** Kexp
if case == "23": comps = [Comp("Fp", 23, sroot(23, 0)), Comp("Fp", 23, sroot(23, 1))]
else: comps = [Comp("Fp2", int(case))]
c0 = comps[0]
q0 = c0.p if c0.typ == "Fp" else c0.p * c0.p
assert (q0 - 1) % order == 0, "no character of this order on the first component"
# discrete logarithm on the units of the first component
elts = list(range(1, c0.p)) if c0.typ == "Fp" else [(u, v) for u in range(c0.p) for v in range(c0.p) if (u, v) != (0, 0)]
LOG = None
for gcand in elts:
    tab = {}; x = c0.one(); ok = True
    for e in range(q0 - 1):
        if x in tab: ok = False; break
        tab[x] = e; x = c0.mul(x, gcand)
    if ok and len(tab) == q0 - 1: LOG = tab; break
minus1 = c0.red((-1, 0)); a_m1 = LOG[minus1]
psi_m1 = (a_m1 % order)                         # psi(-1) = zeta^(a_m1): must be 1
assert psi_m1 == 0, "psi(-1) != 1 for this order: not a PGL_2 nebentypus"
def primes_1mod(mod, count, start=10**9):
    out = []; P = start - start % mod + 1
    while len(out) < count:
        if int(pari("isprime(%d)" % P)): out.append(P)
        P += mod
    return out
PRIMES = primes_1mod(order, 2)
def cohom(P, zP):
    def eps(lams): return pow(zP, LOG[lams[0]] % order, P)
    L = Level(comps, field=("Fp", P), eps=eps if order > 1 else None, group="PGL")
    K = L.cohomology()
    if L.dmpar is not None:                      # rows of K completing delta m_par to a basis of Z_gauge
        keep = []; cur = (L.dmpar[None, :] % P).astype(np.int64)
        def rk(M):
            A = np.array(M, dtype=np.int64, copy=True); return len(gf.rrefp(A, P))
        for r in range(K.shape[0]):
            cand = np.vstack([cur, K[r:r + 1]])
            if rk(cand) == cand.shape[0]: cur = cand; keep.append(r)
        K = K[keep]
    return L, K
OPS = [("v", (0, 1)), ("vbar", (1, -1))]
res = {"case": case, "order": order, "primes": PRIMES, "embeddings": {}}
polys = {}
for P in PRIMES:
    gP = int(pari("lift(znprimroot(%d))" % P)); zP = pow(gP, (P - 1) // order, P)
    js = [j for j in range(1, order, 2)] if order > 2 else [1]
    for j in js:
        L, K = cohom(P, pow(zP, j, P))
        D = K.shape[0]; Ts = {}; piv = None
        for nm, pi in OPS:
            T, ok, piv = hecke_matrix(L, K, pi, pivots=piv); assert ok, nm; Ts[nm] = np.array(T, dtype=np.int64) % P
        S = (Ts["v"] + Ts["vbar"]) % P
        cp = {nm: charpoly_modp(Ts[nm], P) if D else [1] for nm in Ts}; cp["v+vbar"] = charpoly_modp(S, P) if D else [1]
        comm = bool(((Ts["v"] @ Ts["vbar"] - Ts["vbar"] @ Ts["v"]) % P == 0).all())
        polys[(P, j)] = cp
        res["embeddings"]["P%d_j%d" % (P, j)] = {"dimH1": D, "commute": comm}
        print("P = %d, zeta -> zeta_P^%d: dim H^1 = %d, T_v T_vbar commute: %s (%.0fs)" % (P, j, D, comm, time.time() - t0), flush=True)
# reconstruction over Z[zeta]: c(zeta^j) for the 2^(k-1) odd j; basis zeta^t, t < 2^(k-1)
half = max(1, order // 2)
def reconstruct(P, nm):
    gP = int(pari("lift(znprimroot(%d))" % P)); zP = pow(gP, (P - 1) // order, P)
    js = [j for j in range(1, order, 2)] if order > 2 else [1]
    deg = len(polys[(P, js[0])][nm]) - 1
    coeffs = []
    for kdeg in range(deg + 1):
        vals = [polys[(P, j)][nm][kdeg] for j in js]
        if order <= 2:
            a = vals[0]; coeffs.append([a if a <= P // 2 else a - P]); continue
        # solve sum_t a_t (zP^j)^t = vals_j
        M = pari.matrix(half, half, [pow(pow(zP, j, P), t, P) for j in js for t in range(half)])
        sol = pari("lift(matsolve(Mod(%s, %d), Mod(%s, %d)~))" % (str(M), P, str(vals), P))
        coeffs.append([int(s) if int(s) <= P // 2 else int(s) - P for s in sol])
    return coeffs
out = {}
for nm in ("v", "vbar", "v+vbar"):
    rec = [reconstruct(P, nm) for P in PRIMES]
    agree = rec[0] == rec[1]
    co = rec[0]
    # as a polynomial in X with coefficients in Z[zeta] (zeta = t), and its reduction modulo varpi (t -> 1, mod 2)
    pol = " + ".join("(%s)*X^%d" % (" + ".join("%d*t^%d" % (a, tt) for tt, a in enumerate(c)), kdeg) for kdeg, c in enumerate(co))
    red2 = [sum(c) % 2 for c in co]
    f2 = pari("factor(Mod(1, 2) * (%s))" % " + ".join("%d*X^%d" % (r, kdeg) for kdeg, r in enumerate(red2) if r) if any(red2) else "0")
    out[nm] = {"coefficients_Zzeta": co, "two_primes_agree": agree, "mod_varpi": red2, "mod_varpi_factored": str(f2)}
    print("char poly of T_%s: coefficients over Z[zeta] (constant first) %s; the two primes agree: %s; modulo varpi: %s" % (nm, co, agree, str(f2)), flush=True)
res["charpolys"] = out; res["seconds"] = round(time.time() - t0)
json.dump(res, open("char0_psi_%s_o%d.json" % (case, order), "w"), indent=1, default=int)
print("done (%.0fs)" % (time.time() - t0))
