"""Corrected search for models of the 1951 situation: weight-2 newforms of odd squarefree level N (trivial character) whose
mod-2 representation rbar is unramified at 2 with Frob_2 eigenvalues x != y AND both refinements occur over Q, i.e. two
mod-2 eigensystems with the same traces at odd p not dividing N and T_2 eigenvalues u, u' with u u' = 1, u != u'.
All systems (any orbit, any prime P | 2 with residue degree dividing 12) are mapped into F_{2^12} (ffembed), and the
companion may lie in another orbit or at another prime above 2 (the first search, find_models.py, only looked at Galois
conjugates of one system and so missed companions with Frob_2 of order 3).
Image: dihedral if t_p = 0 for every p inert in some quadratic field Q(sqrt D), D | N, D = 1 mod 4 (unramified at 2);
otherwise 'A5 = SL2(F4)' if the traces lie in F4 and take the value 1 and a value outside F2, else the trace field.
Index: of Gamma_0(N O_E) in PSL_2(O_E), E = Q(sqrt-7).
Usage: python3 find_models2.py NMAX [DMAX]      Author: Dula."""
import sys, cypari2
pari = cypari2.Pari(); pari.allocatemem(4 * 10**9)
NMAX = int(sys.argv[1]); DMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 24
pari("G = ffgen(2^12, 'g); PR = primes([3, 150]);")
def index_E(N):
    r = 1
    for q in [int(x) for x in pari("factor(%d)[,1]~" % N)]:
        k = int(pari("kronecker(-7, %d)" % q))
        r *= 8 if q == 7 else ((q + 1) ** 2 if k == 1 else q * q + 1)
    return r
found = []
NMIN = int(sys.argv[3]) if len(sys.argv) > 3 else 3
for N in range(NMIN | 1, NMAX + 1, 2):
    if int(pari("issquarefree(%d)" % N)) == 0: continue
    if int(pari("mfdim([%d, 2], 0)" % N)) == 0: continue
    pari("mf = mfinit([%d, 2], 0); L = mfeigenbasis(mf); F = mffields(mf); S = List();" % N)
    skipped = []
    for j in range(1, int(pari("#L")) + 1):
        d = int(pari("poldegree(F[%d])" % j))
        if d == 1: continue
        if d > DMAX: skipped.append(d); continue
        pari("nf = nfinit(F[%d]); co = mfcoefs(L[%d], 150); dec = idealprimedec(nf, 2);" % (j, j))
        for k in range(1, int(pari("#dec")) + 1):
            f = int(pari("dec[%d].f" % k))
            if f == 1 or 12 % f: continue
            pari("modP = nfmodprinit(nf, dec[%d]); u = nfmodpr(nf, lift(co[3]), modP);" % k)
            if pari("u == 0") == 1: continue
            pari("e = ffembed(ffgen(u), G); uG = ffmap(e, u); "
                 "T = vector(#PR, i, if(%d %% PR[i] == 0, 0*G, ffmap(e, nfmodpr(nf, lift(co[PR[i] + 1]), modP)) + 0*G)); "
                 "listput(S, [%d, %d, %d, uG, T]);" % (N, j, k, f))
    ns = int(pari("#S"))
    # companion search: S2 traces = Frob^k(S1 traces), u2 * Frob^k(u1) = 1, u2 != Frob^k(u1)
    pari("C = List(); for (a = 1, #S, for (b = 1, #S, for (k = 0, 11, "
         "my(T1 = S[a][5], T2 = S[b][5], u1 = S[a][4]^(2^k), u2 = S[b][4]); "
         "if (u2 * u1 == 1 && u2 != u1 && vecsum(vector(#T1, i, T1[i]^(2^k) != T2[i])) == 0 && vecsum(vector(#T2, i, T2[i] != 0)) > 0, "
         "listput(C, [a, b, k]); break))));")
    if int(pari("#C")) == 0: continue
    seen = set()
    for c in range(1, int(pari("#C")) + 1):
        a, b, k = [int(x) for x in pari("C[%d]" % c)]
        key = tuple(sorted((a, b)))
        if key in seen: continue
        seen.add(key)
        pari("T = S[%d][5]; u = S[%d][4];" % (b, b))
        tf = next(m for m in (1, 2, 3, 4, 6, 12) if pari("vecsum(vector(#T, i, T[i]^(2^%d) != T[i])) == 0" % m) == 1)
        # dihedral test over quadratic fields Q(sqrt D), D | N up to sign, D = 1 mod 4
        dih = None
        for D in [int(x) for x in pari("my(v = List()); fordiv(%d, m, if (m > 1, if ((m %% 4) == 1, listput(v, m)); if ((-m %% 4 + 4) %% 4 == 1, listput(v, -m)))); Vec(v)" % N)]:
            if pari("vecsum(vector(#PR, i, %d %% PR[i] != 0 && kronecker(%d, PR[i]) == -1 && T[i] != 0)) == 0" % (N, D)) == 1:
                dih = D; break
        has1 = pari("vecsum(vector(#T, i, T[i] == 1)) > 0") == 1
        hasF4 = pari("vecsum(vector(#T, i, T[i] != 0 && T[i] != 1 && T[i]^4 == T[i])) > 0") == 1
        typ = "dihedral (Q(sqrt %d))" % dih if dih is not None else ("A5 = SL2(F4)" if (tf == 2 and has1 and hasF4) else "non-dihedral, traces in F_{2^%d}" % tf)
        ou = int(pari("my(x = u, o = 1); while (x != 1, x *= u; o++); o"))
        sa = [int(x) for x in pari("S[%d][1..3]" % a)]; sb = [int(x) for x in pari("S[%d][1..3]" % b)]
        line = ("N = %3d: systems (orbit %d, P%d, f=%d) and (orbit %d, P%d, f=%d) [Frob^%d]: rbar %s; T_2 = u of order %d; index over Q(sqrt-7) %d"
                % (N, sa[0], sa[1], sa[2], sb[0], sb[1], sb[2], k, typ, ou, index_E(N)))
        # (S[.][1..3] = orbit, prime index, residue degree.  Logs written before 21 Oct 2026 printed (prime index,
        # residue degree, residue degree) in the places of (orbit, P, f): a formatting error, fixed here.)
        print(line + ("" if not skipped else "  (orbits of degree %s skipped)" % skipped), flush=True)
        found.append(line)
print("searched odd squarefree N <= %d, orbit degree <= %d; %d companion pairs" % (NMAX, DMAX, len(found)))
