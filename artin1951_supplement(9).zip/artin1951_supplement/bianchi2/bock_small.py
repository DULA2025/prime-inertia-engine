"""Validation of the 2-adic lifting test (bockstein.py) at small levels, on all of H^1.

For each case the mod-2 cohomology Z_gauge (gauge-fixed cocycles, sparse_big.BigH1) is computed, and for every type of
psi (trivial; quadratic; ramified, i.e. order >= 4) the subspace of first-order liftable classes is found (one
augmented solve with RHS columns b_q and c_{q,j} for every basis cocycle q).  These dimensions are upper bounds for the
characteristic-0 ranks dim H^1(Gamma_0(n), C(chi psi)), computed here over F_P (dense engine bmf.py, P = 1 mod 40):
for psi = 1 and each quadratic psi, and for one psi of order 4 per ramified type.  On the psi = 1 liftable subspace the
pairs (T_v, T_vbar) are listed.

Cases: 23 (split), 31, 47 (inert), trivial chibar; 31c: level 31 O_E with chibar = eps o N, eps(3) = z of order 5
(the type of the control control_A5_31.py).  Usage: python3 bock_small.py CASE.  Author: Dula."""
import sys, json, time, resource
import numpy as np, cypari2
from bmf import Comp, Level
from sparse_h1 import FastLevel, MUL, INV
from sparse_big import BigH1
from mod2_refine import root as sroot, eigen_pairs, restrict
import bockstein as bk
from bockstein import AugSolve, rhs_matrix, quad_step_tables, component_info, allowed_types, type_rows
import gf
pari = cypari2.Pari()
t0 = time.time(); case = sys.argv[1]
# ---------------------------------------------------------------- the level
if case == "23":
    comps = [Comp("Fp", 23, sroot(23, 0)), Comp("Fp", 23, sroot(23, 1))]; EC = None; chi5 = None
elif case in ("31", "47"):
    comps = [Comp("Fp2", int(case))]; EC = None; chi5 = None
elif case == "31c":
    N = 31; comps = [Comp("Fp2", N)]
    E31 = {}; cur = 1; acc = 1
    for k in range(30):
        E31[cur] = acc; cur = cur * 3 % N; acc = int(MUL[acc, 2])
    EC = [{(u, v): E31[(u * u + u * v + 2 * v * v) % N] for u in range(N) for v in range(N) if (u, v) != (0, 0)}]
    chi5 = {a: k % 5 for k, a in enumerate([pow(3, k, N) for k in range(30)])}       # eps(3^k) = z^k: exponent mod 5
else:
    raise SystemExit("unknown case")
L = FastLevel(comps, EC, name=case)
info = component_info(L); J = len(comps)
H = BigH1(L, verbose=True, seed=1)
rng = np.random.default_rng(7); H.quotient_dm(rng)
d = H.d; D = d - (1 if H.drop is not None else 0)
print("case %s: n = %d, components %s, dim Z_gauge = %d, dim H^1 = %d (%.0fs)" % (case, L.n, [(c["typ"], c["p"], "e2=%d" % c["e2"]) for c in info], d, D, time.time() - t0), flush=True)
# ---------------------------------------------------------------- RHS columns for every basis cocycle
from lanczos16 import from_bits
S = np.ascontiguousarray(from_bits(H.V, d))                  # (ncls, d) class values of the basis
K = d; colb = np.arange(K, dtype=np.int64); colc = (K + np.arange(K)[:, None] * J + np.arange(J)[None, :]).astype(np.int64)
m = K * (1 + J)
NXL = quad_step_tables(L)
B, bad = rhs_matrix(L.NXT, L.NXE, NXL, H.tg, H.te, len(L.gens), L.n, L.TREE, H.cls_of, H.rfac, S, colb, colc, m,
                    MUL, bk.GMUL, bk.GADD, bk.GNEG, bk.RED, bk.HALF, bk.LIFT, bk.TEICH)
assert bad == 0, "R u != 0 mod 2 at %d places" % bad
print("RHS: %d columns, %d non-zero entries (%.0fs)" % (m, int((B != 0).sum()), time.time() - t0), flush=True)
A = AugSolve(L, B, dimker_R=d, ref_closure=(H.cls_of, H.rfac))
types = allowed_types(info)
res = {"case": case, "n": L.n, "components": info, "dim_Z_gauge": d, "dimH1": D, "delta_mpar": H.drop is not None,
       "augmented": {"kernel": A.d, "dim_L": A.rank_t, "t0": A.dim_t0, "conditions": A.conds.n, "core": A.core_shape}, "types": []}
qs = list(range(K))
lift_sub = {}
for kind, eps in types:
    Phi = type_rows(kind, eps, qs, colb, colc, m)
    dimZ, basis = A.preimage_dim(Phi)
    lift_sub[(kind, eps)] = basis
    res["types"].append({"kind": kind, "eps": list(eps), "dim_liftable_Z": int(dimZ), "dim_liftable_H1": int(dimZ - (1 if H.drop is not None else 0))})
# delta m_par check (the obstruction of a combination is the combination of the rows of Phi)
if H.drop is not None:
    for t in res["types"]:
        Phi = type_rows(t["kind"], tuple(t["eps"]), qs, colb, colc, m)
        vec = np.zeros(m, dtype=np.uint8)
        for q in range(K):
            if H.dm_coords[q]: vec ^= MUL[H.dm_coords[q], Phi[q]]
        t["delta_mpar_lifts"] = bool(A.in_L(vec))
# ---------------------------------------------------------------- characteristic 0 over F_P
P = 1000000041
while not (P % 40 == 1 and int(pari("isprime(%d)" % P))): P += 40
g40 = int(pari("lift(znprimroot(%d))" % P)); i4 = pow(g40, (P - 1) // 4, P); w5 = pow(g40, (P - 1) // 5, P)
def legendre(a, p): return 1 if pow(a, (p - 1) // 2, p) == 1 else -1
def comp_quad(c, lam):
    return legendre(lam, c.p) if c.typ == "Fp" else legendre(c.norm(lam), c.p)
logs = {}
def comp_log(k, c):
    """discrete log table on the unit group of component k (generator found by search)."""
    if k in logs: return logs[k]
    q = c.p if c.typ == "Fp" else c.p * c.p
    elts = list(range(1, c.p)) if c.typ == "Fp" else [(u, v) for u in range(c.p) for v in range(c.p) if (u, v) != (0, 0)]
    for gcand in elts:
        tab = {}; x = c.one(); ok = True
        for e in range(q - 1):
            if x in tab: ok = False; break
            tab[x] = e; x = c.mul(x, gcand)
        if ok and len(tab) == q - 1: logs[k] = (tab, q - 1); return logs[k]
    raise RuntimeError("no generator")
def make_eps(kind, eps):
    def f(lams):
        r = 1
        if chi5 is not None:
            r = pow(w5, chi5[comps[0].norm(lams[0])], P)
        if kind == "quadratic":
            for k, ek in enumerate(eps):
                if ek and comp_quad(comps[k], lams[k]) == -1: r = (-r) % P
        elif kind == "ramified":
            # an order-4 character on the components in eps (where it exists), trivial elsewhere
            for k, ek in enumerate(eps):
                if ek:
                    tab, o = comp_log(k, comps[k]); r = r * pow(i4, tab[lams[k]] % 4, P) % P
        return r
    return f
for t in res["types"]:
    kind, eps = t["kind"], tuple(t["eps"])
    if kind == "ramified":
        # psi of order 4 with psi^2 = the quadratic character on the components in eps: psi_k(g_k^a) = i^a
        if any(info[k]["e2"] < 2 for k in range(J) if eps[k]): t["char0_rank"] = None; continue
    trivial = (kind == "trivial" and chi5 is None)
    Lp = Level(comps, field=("Fp", P), eps=None if trivial else make_eps(kind, eps), group="PGL")
    Kp = Lp.cohomology(); r0 = Kp.shape[0] - (1 if Lp.dmpar is not None else 0)
    if kind == "ramified":
        # psi(-1) = 1 is needed: check it on -1
        ok = make_eps(kind, eps)(tuple(c.red((-1, 0)) for c in comps)) == 1
        t["psi_minus1_is_1"] = bool(ok)
    t["char0_rank"] = int(r0); t["P"] = P
    print("  psi %-9s eps %s: first-order liftable H^1 %d; characteristic 0 (over F_%d) %d%s" % (kind, list(eps), t["dim_liftable_H1"], P, r0,
          "" if "delta_mpar_lifts" not in t else "; delta m_par lifts: %s" % t["delta_mpar_lifts"]), flush=True)
# ---------------------------------------------------------------- (T_v, T_vbar) on the psi = 1 liftable subspace
Tv = H.hecke((0, 1), np.random.default_rng([7, 1])); Tvb = H.hecke((1, -1), np.random.default_rng([7, 2]))
keep = np.array([k for k in range(d) if k != H.drop], dtype=np.int64)
def to_h1(a):
    a = a.astype(np.uint8).copy()
    if H.drop is not None and a[H.drop]:
        f = int(MUL[a[H.drop], INV[H.dm_coords[H.drop]]]); a = a ^ MUL[f, H.dm_coords]
    return a[keep]
res["pairs_all"] = eigen_pairs(Tv, Tvb)
for t in res["types"]:
    basis = lift_sub[(t["kind"], tuple(t["eps"]))]
    if basis.shape[0] == 0: t["pairs"] = []; continue
    Vh = np.array([to_h1(a) for a in basis], dtype=np.uint8)
    Ah = Vh.copy(); piv = list(gf.rref16(Ah, MUL, INV)); Vh = Ah[:len(piv)]
    if Vh.shape[0] == 0: t["pairs"] = []; continue
    try:
        t["pairs"] = eigen_pairs(restrict(Tv, Vh), restrict(Tvb, Vh))
    except AssertionError:
        t["pairs"] = "not Hecke-stable"
    print("  psi %-9s eps %s: (T_v, T_vbar) pairs on the liftable part: %s" % (t["kind"], t["eps"], t["pairs"]), flush=True)
print("(T_v, T_vbar) pairs on all of H^1:", res["pairs_all"], flush=True)
res["seconds"] = round(time.time() - t0); res["peak_rss_MB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
json.dump(res, open("bock_small_%s.json" % case, "w"), indent=1, default=int)
print("done (%.0fs)" % (time.time() - t0))
