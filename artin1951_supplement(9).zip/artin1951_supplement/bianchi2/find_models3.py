"""Search with nebentypus: mod-2 eigensystems of weight-2 newforms on Gamma_0(N) with character eps, N odd, for
(a) a projective image A5 = PSL_2(F_4) (an icosahedral model), and (b) companion pairs (rbar unramified at 2 with
Frobenius eigenvalues x != y, both refinements present over Q), which are models of the 1951 situation.

Why characters: the 1951 representation has nebentypus of order 5. If rbar has projective image A5, then
rbar = lambda (x) s with s : G_Q -> SL_2(F_4) and lambda a character; twisting by a character mu of order dividing 15
(locally the inverse of the tame inertia eigenvalue at primes with inertia of order 3 or 5) gives the minimal level, so
a twist-minimal icosahedral rbar has det = eps with odd part of order dividing 15. Characters of 2-power order are
trivial mod 2 but can be needed for a characteristic-0 lift, so every even eps whose odd part has order 1, 3, 5 or 15
is searched. Every mod-2 eigenform of weight 2 on Gamma_1(N) (N >= 5) lifts to characteristic 0 (Gamma_1(N) is
torsion-free), so this covers every rbar of conductor N up to twist.

Projective invariant: u_p = a_p^2 / eps(p) mod P (p odd, p not dividing N). For g in PGL_2(F2bar) with eigenvalue ratio
mu, u = mu + 1/mu: u = 0 (order 1 or 2), 1 (order 3), u in F_4 - F_2 (order 5), otherwise order not in {1, 2, 3, 5}.
A5 is reported when all u_p lie in F_4 and both 1 and a value in F_4 - F_2 occur (a subgroup of PGL_2(F2bar) with
elements of order 3 and 5 and no other orders > 2 among the Frobenius elements tested; dihedral groups D_15k would show
elements of order 15, which have u outside F_4).
Convention check: eps(p) from chareval with t = zeta_o is verified against a_{p^2} = a_p^2 - p eps(p) for p^2 <= NB.

Characters whose order has a large 2-part give coefficient fields of large degree; each step (the newform space of
one character orbit; the field of one newform) has a time limit TL seconds, and every orbit or form skipped by it is
listed in the log.
Usage: python3 find_models3.py LEVELS_SPEC [NB] [TL]
  LEVELS_SPEC: comma-separated items, each 'a-b' (all odd N in [a, b]) or a single N.        Author: Dula."""
import sys, time, cypari2
from cysignals.alarm import alarm, cancel_alarm, AlarmInterrupt
pari = cypari2.Pari(); pari.allocatemem(3 * 10**9)
spec = sys.argv[1]; NB = int(sys.argv[2]) if len(sys.argv) > 2 else 200; TL = int(sys.argv[3]) if len(sys.argv) > 3 else 240
LEVELS = []
for item in spec.split(","):
    if "-" in item:
        a, b = [int(x) for x in item.split("-")]; LEVELS += [n for n in range(a, b + 1) if n % 2 == 1 and n > 1]
    else: LEVELS.append(int(item))
SKIPPED = []
pari("G24 = ffgen(2^24, 'g); PR = primes([3, %d]);" % NB)

def index_E(N):
    r = 1
    for q, e in zip([int(x) for x in pari("factor(%d)[,1]~" % N)], [int(x) for x in pari("factor(%d)[,2]~" % N)]):
        k = int(pari("kronecker(-7, %d)" % q))
        if q == 7: r *= 8 * 7 ** (2 * e - 1 - 1) if e > 1 else 8          # (sqrt-7)^(2e-1), the base-change conductor
        elif k == 1: r *= ((q + 1) * q ** (e - 1)) ** 2
        else: r *= (q * q + 1) * q ** (2 * (e - 1))
    return r

t0 = time.time(); total_sys = 0; A5 = []; COMP = []; nonA5_F4 = 0; NREL = [0, 0]   # forms done by the relative / absolute method
for N in LEVELS:
    pari("Gc = znstar(%d, 1); Lc = chargalois(Gc); S = List();" % N)
    nch = int(pari("#Lc")); levsys = 0
    for ci in range(1, nch + 1):
        o = int(pari("charorder(Gc, Lc[%d])" % ci))
        if int(pari("zncharisodd(Gc, Lc[%d])" % ci)): continue
        oo = o
        while oo % 2 == 0: oo //= 2
        if 15 % oo: continue
        try:
            alarm(TL); pari("mf = mfinit([%d, 2, [Gc, Lc[%d]]], 0); dmf = mfdim(mf); if (dmf, B = mfeigenbasis(mf); F = mffields(mf));" % (N, ci)); cancel_alarm()
        except (AlarmInterrupt, cypari2.PariError):
            cancel_alarm()
            line = "N = %d: character orbit %d (order %d): SKIPPED, newform space not split within %d s (or PARI stack exceeded)" % (N, ci, o, TL)
            print(line, flush=True); SKIPPED.append(line); continue
        if int(pari("dmf")) == 0: continue
        # the character actually used by mf (it may replace ours by a Galois conjugate)
        # mfparams gives the character as a Conrey label Mod(c, N), or as a discriminant D for kronecker(D, .)
        pari("cm = mfparams(mf)[3];")
        if int(pari("type(cm) == \"t_INT\"")):
            om = 1 if int(pari("cm")) == 1 else 2; condm = abs(int(pari("cm")))
            pari("epsq(p) = kronecker(cm, p);")
        else:
            pari("Gm = znstar(cm.mod, 1); chm = znconreychar(Gm, cm); om = charorder(Gm, chm);")
            om = int(pari("om")); condm = int(pari("zncharconductor(Gm, chm)"))
            pari("epsq(p) = my(r = chareval(Gm, chm, p)); if (r == 0, 1, -1);")
        for j in range(1, int(pari("#B")) + 1):
            pari("co = mfcoefs(B[%d], %d); P = F[%d];" % (j, NB, j))
            if om > 2:
                pari("cyc = mfparams(mf)[5]; R = rnfequation(cyc, P, 1); Pabs = R[1]; A = lift(R[2]); kk = R[3];")
                assert pari("cyc == polcyclo(%d, 't)" % om) == 1
                pari("toabs0(c) = Mod(subst(subst(liftall(c), 'y, 'y - kk * A), 't, A), Pabs);")
                pari("epsv(p) = my(r = chareval(Gm, chm, p)); Mod(t^(r * %d), cyc);" % om)
            else:
                pari("Pabs = if (poldegree(P) == 0, 'y, P); toabs0(c) = Mod(liftall(c), Pabs);")
                pari("epsv(p) = epsq(p);")
            # convention check a_{p^2} = a_p^2 - p eps(p)
            ok = int(pari("my(ok = 1); forprime(p = 3, sqrtint(%d), if (%d %% p, "
                          "if (co[p^2 + 1] != co[p + 1]^2 - p * epsv(p), ok = 0))); ok" % (NB, N)))
            if not ok:
                print("N = %d char %d form %d: CONVENTION CHECK FAILED" % (N, ci, j), flush=True); continue
            # mod-2 systems of this form: SYS = list of [f, T, E, u2, e2] (T, E: a_p and eps(p) mod P for p in PR)
            pari("SYS = List(); dP = poldegree(P);")
            okrel = True
            try:
                # relative method: reduce modulo a prime q | 2 of Q(chi) (q = 2 for om <= 2); if P mod q is squarefree, the
                # order O[y]/P is q-maximal (Dedekind), so a_p has q-integral coordinates and the primes P | q are the
                # irreducible factors of P mod q
                if om > 2:
                    pari("nf0 = nfinit(cyc); dec0 = idealprimedec(nf0, 2);")
                    nq = int(pari("#dec0"))
                else:
                    nq = 1
                for iq in range(1, nq + 1):
                    if om > 2:
                        pari("mp0 = nfmodprinit(nf0, dec0[%d]); gq = nfmodpr(nf0, 't, mp0);" % iq)
                        pari("redq(c) = nfmodpr(nf0, lift(c), mp0);")
                    else:
                        pari("gq = ffgen([2, 1], 'b);")
                        pari("redq(c) = c * gq^0;")
                    pari("Pbar = sum(i = 0, dP, redq(polcoef(P, i, 'y)) * 'y^i);")
                    if int(pari("poldegree(Pbar) != dP || poldegree(gcd(Pbar, deriv(Pbar, 'y))) > 0")):
                        okrel = False; break
                    pari("faP = factor(Pbar);")
                    for ig in range(1, int(pari("#faP[,1]")) + 1):
                        pari("ext = ffextend(gq, faP[%d, 1]); rr = ext[1]; mm = ext[2];" % ig)
                        pari("evr(c) = my(L = lift(c)); sum(i = 0, dP - 1, ffmap(mm, redq(polcoef(L, i, 'y))) * rr^i) + 0 * rr;")
                        pari("listput(SYS, [rr.f, vector(#PR, i, if (%d %% PR[i], evr(co[PR[i] + 1]), 0 * rr)), "
                             "vector(#PR, i, if (%d %% PR[i], ffmap(mm, redq(epsv(PR[i]))) + 0 * rr, rr^0)), evr(co[3]), ffmap(mm, redq(epsv(2))) + 0 * rr]);" % (N, N))
            except cypari2.PariError:
                okrel = False
            if not okrel:
                pari("SYS = List();")
                # absolute field with a 2-maximal order: first directly, then (if that is too slow) after polredbest
                done_abs = False
                for attempt in (0, 1):
                    try:
                        alarm(TL)
                        if attempt == 0:
                            pari("Pred = Pabs; toabs(c) = toabs0(c);")
                        else:
                            pari("Rb = if (poldegree(Pabs) > 1, polredbest(Pabs, 1), [Pabs, Mod('y, Pabs)]); Pred = Rb[1]; rt = lift(Rb[2]);")
                            pari("toabs(c) = Mod(subst(lift(toabs0(c)), 'y, rt), Pred);")
                        pari("nf = nfinit([Pred, [2]]); dec = idealprimedec(nf, 2); "
                             "Tabs = vector(#PR, i, if (%d %% PR[i], toabs(co[PR[i] + 1]), 0)); "
                             "Eabs = vector(#PR, i, if (%d %% PR[i], toabs(epsv(PR[i])), 1)); a2 = toabs(co[3]); e2 = toabs(epsv(2));" % (N, N))
                        pari("SYS = List();")
                        for k in range(1, int(pari("#dec")) + 1):
                            pari("modP = nfmodprinit(nf, dec[%d]); listput(SYS, [dec[%d].f, vector(#PR, i, nfmodpr(nf, Tabs[i], modP)), "
                                 "vector(#PR, i, nfmodpr(nf, Eabs[i], modP)), nfmodpr(nf, a2, modP), nfmodpr(nf, e2, modP)]);" % (k, k))
                        cancel_alarm(); done_abs = True; break
                    except (AlarmInterrupt, cypari2.PariError):      # time limit, or PARI stack overflow
                        cancel_alarm()
                if not done_abs:
                    line = "N = %d: character orbit %d (order %d), form %d (degree %d over Q): SKIPPED, field not done within 2 x %d s (or PARI stack exceeded)" % (
                        N, ci, om, j, int(pari("poldegree(Pabs)")), TL)
                    print(line, flush=True); SKIPPED.append(line); continue
            NREL[0 if okrel else 1] += 1
            for k in range(1, int(pari("#SYS")) + 1):
                pari("f = SYS[%d][1]; T = SYS[%d][2]; E = SYS[%d][3]; u2 = SYS[%d][4]; ee2 = SYS[%d][5]; "
                     "U = vector(#PR, i, if (%d %% PR[i], T[i]^2 / E[i], 0));" % (k, k, k, k, k, N))
                total_sys += 1; levsys += 1
                f = int(pari("f"))
                inF4 = int(pari("vecsum(vector(#U, i, U[i]^4 != U[i])) == 0"))
                has1 = int(pari("vecsum(vector(#U, i, U[i] == 1)) > 0"))
                has5 = int(pari("vecsum(vector(#U, i, U[i] != 0 && U[i] != 1 && U[i]^4 == U[i])) > 0"))
                if inF4 and has1 and has5:
                    line = "N = %d, eps of order %d (conductor %d), form %d, P%d (f = %d): projective image A5; a_2 mod P %s" % (
                        N, om, condm, j, k, f, "= 0 (supersingular at 2)" if int(pari("u2 == 0")) else "a unit (ordinary at 2)")
                    print("  ** " + line, flush=True); A5.append(line)
                elif inF4: nonA5_F4 += 1
                if f == 1 or 24 % f or int(pari("u2 == 0")) == 1: continue      # x y = eps(2) != 0, x != y needs f > 1
                pari("emb = ffembed(ffgen(u2), G24);")
                pari("mp(x) = if (type(x) == \"t_FFELT\", ffmap(emb, x), x * G24^0) + 0 * G24;")
                pari("listput(S, [%d, %d, %d, %d, mp(u2), mp(ee2), vector(#T, i, mp(T[i])), vector(#E, i, mp(E[i])), %d]);"
                     % (ci, j, k, f, om))
    ns = int(pari("#S"))
    # companions: same traces and eps at odd p (after Frob^k), u_b * u_a^(2^k) = eps(2), u_b != u_a^(2^k)
    pari("C = List(); for (a = 1, #S, for (b = 1, #S, for (k = 0, 23, "
         "my(q = 2^k, sa = S[a], sb = S[b]); if (sb[5] != 0 && sa[5] != 0 && sb[5] * sa[5]^q == sb[6] && sb[5] != sa[5]^q "
         "&& vecsum(vector(#PR, i, sa[7][i]^q != sb[7][i] || sa[8][i]^q != sb[8][i])) == 0 "
         "&& vecsum(vector(#PR, i, sb[7][i] != 0)) > 0, listput(C, [a, b, k]); break))));")
    # group the systems into classes (one class = one rbar) by the companion relation
    par = {}
    def fnd(x):
        while par.setdefault(x, x) != x: x = par[x]
        return x
    for c in range(1, int(pari("#C")) + 1):
        a, b, k = [int(x) for x in pari("C[%d]" % c)]
        par[fnd(a)] = fnd(b)
    classes = {}
    for x in list(par): classes.setdefault(fnd(x), []).append(x)
    for root_, mem in sorted(classes.items(), key=lambda kv: min(kv[1])):
        b = min(mem)
        pari("T = S[%d][7]; E = S[%d][8]; U = vector(#PR, i, if (%d %% PR[i], T[i]^2 / E[i], 0));" % (b, b, N))
        dih = None
        # fundamental discriminants D = +-m, m | N squarefree, D = 1 mod 4 (quadratic fields unramified at 2 and outside N)
        for D in [int(x) for x in pari("my(v = List()); fordiv(%d, m, if (m > 1 && issquarefree(m), if ((m %% 4) == 1, listput(v, m)); "
                                       "if ((-m %% 4 + 4) %% 4 == 1, listput(v, -m)))); Vec(v)" % N)]:
            if int(pari("vecsum(vector(#PR, i, %d %% PR[i] != 0 && kronecker(%d, PR[i]) == -1 && T[i] != 0)) == 0" % (N, D))):
                dih = D; break
        # reducible: {p : u_p = 0} = kernel of a character chi of odd order > 1 modulo a divisor M of N (rbar^ss = psi1 + psi2,
        # psi1/psi2 = chi, u_p = chi(p) + 1/chi(p))
        red_ = None
        if dih is None:
            for M in [int(x) for x in pari("divisors(%d)" % N)][1:]:
                pari("GM = znstar(%d, 1); LM = chargalois(GM);" % M)
                for ci2 in range(1, int(pari("#LM")) + 1):
                    m = int(pari("charorder(GM, LM[%d])" % ci2))
                    if m == 1 or m % 2 == 0: continue
                    if int(pari("vecsum(vector(#PR, i, %d %% PR[i] != 0 && ((U[i] == 0) != (chareval(GM, LM[%d], PR[i]) == 0)))) == 0" % (N, ci2))):
                        red_ = (m, int(pari("zncharconductor(GM, LM[%d])" % ci2))); break
                if red_: break
        inF4 = int(pari("vecsum(vector(#U, i, U[i]^4 != U[i])) == 0")); has1 = int(pari("vecsum(vector(#U, i, U[i] == 1)) > 0"))
        has5 = int(pari("vecsum(vector(#U, i, U[i] != 0 && U[i] != 1 && U[i]^4 == U[i])) > 0"))
        if dih is not None: typ = "dihedral (Q(sqrt %d))" % dih
        elif red_ is not None: typ = "reducible (rbar^ss = psi1 + psi2, psi1/psi2 of order %d and conductor %d)" % red_
        elif inF4 and has1 and has5: typ = "A5"
        else: typ = "other"
        orders = sorted({int(pari("S[%d][9]" % x)) for x in mem})
        uo = int(pari("my(x = S[%d][5]^2 / S[%d][6], o = 1, y = x); while (y != 1, y *= x; o++); o" % (b, b)))
        desc = ", ".join("(char %d, form %d, P%d, f=%d)" % tuple(int(z) for z in pari("S[%d][1..4]" % x)) for x in sorted(mem))
        line = ("N = %3d: rbar %s; Frob_2 of projective order %d; %d companion systems [%s], eps of order %s; index over Q(sqrt-7) %d"
                % (N, typ, uo, len(mem), desc, "/".join(map(str, orders)), index_E(N)))
        print(line, flush=True); COMP.append(line)
    print("N = %d done: %d mod-2 systems (%.0f s)" % (N, levsys, time.time() - t0), flush=True)
print("levels %s, primes p <= %d: %d mod-2 systems; A5 (any, with or without companion): %d; other systems with all u_p in F_4: %d; companion classes (models): %d; skipped: %d; forms reduced by the relative / absolute method: %d / %d; %.0f s"
      % (spec, NB, total_sys, len(A5), nonA5_F4, len(COMP), len(SKIPPED), NREL[0], NREL[1], time.time() - t0))
