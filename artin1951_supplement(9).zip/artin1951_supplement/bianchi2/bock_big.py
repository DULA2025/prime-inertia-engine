"""The 2-adic lifting test (bockstein.py) at the levels computed by run_big.py: the 633 model and level 1951 O_E.

Inputs (from the cache of run_big.py): the basis of H^1(Gamma_0, F16(chibar)), the rbar-part (rbar_part_s7.npy), the
joint eigenvectors of the four pairs (T_v, T_vbar) = (x,x), (x,y), (y,x), (y,y) (joint_*_s7.npy) and T_v, T_vbar.
RHS columns: b_q for every basis vector q of the rbar-part (psi = 1), and c_{u,j} = R_{lambda_j} u for the four joint
eigenvectors u and every component j.  One augmented solve gives L = {t : B t in im R}.  Read off:
  * the first-order (mod 4) liftable subspace of the rbar-part for psi = 1, and the pairs (T_v, T_vbar) on it;
  * for each joint eigenvector u and each type of psi (trivial, quadratic, ramified), whether the first-order
    obstruction of u vanishes.
A non-vanishing obstruction shows that u is not the reduction of a characteristic-0 class with nebentypus chi*psi of
that type at this level; a vanishing one decides nothing (higher obstructions are not computed here).
Usage: python3 bock_big.py 1951 | 633.  Environment: BOCK_LW (Lanczos block / 64, default 12), BOCK_SEED (default 1).
Author: Dula."""
import sys, os, json, time, resource
import numpy as np
t00 = time.time()
target = sys.argv[1]
targs = ["1951"] if target == "1951" else ["633", "1", "10", "odd", "A5"]
# ---------------------------------------------------------------- level data: the header of run_big.py
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "run_big.py")).read()
head = src[:src.index("# ---------------------------------------------------------------- Bianchi side")]
argv0 = sys.argv; sys.argv = ["run_big.py"] + targs
ns = {"__name__": "run_big_head", "__file__": "run_big.py"}
exec(compile(head, "run_big.py(header)", "exec"), ns)
sys.argv = argv0
label, comps, EC, x, y = ns["label"], ns["comps"], ns["EC"], ns["x"], ns["y"]
from sparse_h1 import FastLevel, MUL, INV, matmul16, gen_eigenspace
from sparse_big import BigH1, dot_all
from mod2_refine import eigen_pairs, restrict
import bockstein as bk
from bockstein import AugSolve, rhs_matrix, quad_step_tables, component_info, allowed_types
import gf
LW = int(os.environ.get("BOCK_LW", "12")); BSEED = int(os.environ.get("BOCK_SEED", "1"))
SEED = 7
CACHE = "big_cache_%s" % label; AUG = os.path.join(CACHE, "aug_s%d" % BSEED); os.makedirs(AUG, exist_ok=True)
L = FastLevel(comps, EC, name=label)
info = component_info(L); J = len(comps)
print("%s: (x, y) = (%d, %d); components %s (%.0fs)" % (label, x, y, [(c["typ"], c["p"], "e2=%d" % c["e2"]) for c in info], time.time() - t00), flush=True)
H = BigH1(L, verbose=True, seed=SEED - 6, cache=CACHE)
rng = np.random.default_rng(SEED); H.quotient_dm(rng)
d = H.d; D = d - (1 if H.drop is not None else 0)
keep = np.array([k for k in range(d) if k != H.drop], dtype=np.int64)
Vr = np.load(os.path.join(CACHE, "rbar_part_s%d.npy" % SEED))                     # (r, D)
pairs_order = [(x, x), (x, y), (y, x), (y, y)]
joint = {}
for (a, b) in pairs_order:
    f = os.path.join(CACHE, "joint_%d_%d_s%d.npy" % (a, b, SEED))
    assert os.path.exists(f), f
    v = np.load(f); assert v.shape[0] == 1, "joint eigenspace not one-dimensional"
    joint[(a, b)] = v[0]
r = Vr.shape[0]
print("dim H^1 = %d; rbar-part %d; joint eigenvectors %s (%.0fs)" % (D, r, list(joint), time.time() - t00), flush=True)
def zc(a_h1):
    a = np.zeros(d, dtype=np.uint8); a[keep] = a_h1; return a
cocs = [zc(Vr[i]) for i in range(r)] + [zc(joint[p]) for p in pairs_order]
K = len(cocs)
colb = np.full(K, -1, dtype=np.int64); colb[:r] = np.arange(r)
colc = np.full((K, J), -1, dtype=np.int64)
for i in range(4):
    for j in range(J): colc[r + i, j] = r + i * J + j
m = r + 4 * J
Bpath = os.path.join(AUG, "B.npy")
if os.path.exists(Bpath):
    B = np.load(Bpath, mmap_mode="r"); print("RHS loaded from %s" % Bpath, flush=True)
else:
    S = np.zeros((H.ncls, K), dtype=np.uint8)
    for q, a in enumerate(cocs): S[:, q] = dot_all(H.V, a, d, MUL)
    NXL = quad_step_tables(L)
    B, bad = rhs_matrix(L.NXT, L.NXE, NXL, H.tg, H.te, len(L.gens), L.n, L.TREE, H.cls_of, H.rfac, S, colb, colc, m,
                        MUL, bk.GMUL, bk.GADD, bk.GNEG, bk.RED, bk.HALF, bk.LIFT, bk.TEICH)
    assert bad == 0, "R u != 0 mod 2 at %d places" % bad
    del S, NXL
    np.save(Bpath, B); del B
    B = np.load(Bpath, mmap_mode="r")
    print("RHS: %d columns computed and saved (%.0fs)" % (m, time.time() - t00), flush=True)
ref = (H.cls_of.copy(), H.rfac.copy())
del H.V
A = AugSolve(L, B, fill=8.0, seed=BSEED, lanczos_w=LW, cache=AUG, dimker_R=d, ref_closure=ref)
res = {"label": label, "x": x, "y": y, "components": info, "dimH1": D, "dim_Z_gauge": d, "rbar_dim": r, "m": m,
       "augmented": {"kernel": A.d, "dim_L": A.rank_t, "t0": A.dim_t0, "conditions": int(A.conds.n), "core": list(A.core_shape),
                     "lanczos_runs": A.lanczos_runs, "complete": bool(A.complete), "seconds": {k: round(v) for k, v in A.t.items()}}}
# ---------------------------------------------------------------- (a) the rbar-part, psi = 1
Phi = np.zeros((r, m), dtype=np.uint8); Phi[np.arange(r), colb[:r]] = 1
dl, basis = A.preimage_dim(Phi)
res["rbar_liftable_mod4_psi1"] = int(dl)
Tv = np.load(os.path.join(CACHE, "hecke_v_s%d.npy" % SEED)); Tvb = np.load(os.path.join(CACHE, "hecke_vbar_s%d.npy" % SEED))
if dl:
    Wh = matmul16(np.ascontiguousarray(basis), np.ascontiguousarray(Vr), MUL)       # H^1 coordinates
    Ah = Wh.copy(); pv = list(gf.rref16(Ah, MUL, INV)); Wh = Ah[:len(pv)]
    try: pr = eigen_pairs(restrict(Tv, Wh), restrict(Tvb, Wh))
    except AssertionError: pr = "not Hecke-stable"
else:
    pr = []
res["rbar_liftable_pairs"] = pr
print("rbar-part: first-order (mod 4) liftable subspace for psi = 1 has dimension %d of %d; (T_v, T_vbar) pairs on it: %s"
      % (dl, r, pr), flush=True)
# ---------------------------------------------------------------- (b) the joint eigenvectors, every type of psi
types = allowed_types(info)
A_r = np.ascontiguousarray(Vr.T)
def coeffs(u):
    Aug = np.concatenate([Vr.T, u[:, None]], axis=1).astype(np.uint8).copy()
    pv = list(gf.rref16(Aug, MUL, INV)); assert all(p < r for p in pv), "not in the rbar-part"
    a = np.zeros(r, dtype=np.uint8)
    for i, p in enumerate(pv): a[p] = Aug[i, r]
    return a
res["joint"] = {}
for i, p in enumerate(pairs_order):
    a = coeffs(joint[p]); out = {}
    for kind, eps in types:
        vec = np.zeros(m, dtype=np.uint8)
        if kind in ("trivial", "quadratic"): vec[:r] = a
        if kind in ("quadratic", "ramified"):
            for j, ej in enumerate(eps):
                if ej: vec[r + i * J + j] ^= 1
        out["%s %s" % (kind, "".join(map(str, eps)))] = bool(A.in_L(vec))
    res["joint"]["%d_%d" % p] = out
    print("  joint eigenvector (T_v, T_vbar) = (%d, %d): first-order obstruction vanishes for %s" % (p[0], p[1], out), flush=True)
res["types"] = [[k, list(e)] for k, e in types]
res["seconds"] = round(time.time() - t00); res["peak_rss_MB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
json.dump(res, open("bock_big_%s.json" % label, "w"), indent=1, default=int)
print("done (%.0fs, peak RSS %d MB)" % (time.time() - t00, res["peak_rss_MB"]))
