"""Memory-lean version of the sparse engine (sparse_h1.py) for indices n of several million.

Same mathematics: gauge-fixed cocycles of PGL_2(O_E) on P^1(O/n) with F16 coefficients and nebentypus, as the kernel
of the relator equations (Fox calculus along the coset graph, spanning tree from a BFS).  Differences:
  * closure under 1- and 2-term equations with path compression; rows rewritten into a CSR over compact class ids;
  * deduplication by hashing (numba), no Python dictionaries;
  * Markowitz elimination in rounds: in each round an independent set of pivots (disjoint row sets) of smallest
    Markowitz cost (w - 1)(l - 1) is eliminated at once, with a cost ceiling that rises from 0; stop at a fill bound;
  * the core is solved by block Lanczos (lanczos16.py) or, if small, by the bitsliced dense elimination;
  * the kernel lives on the classes, bitsliced (ncls, 4, ceil(d / 64)); values on an edge u are rfac[u] V[cls[u]];
  * every relator equation at every coset is re-derived on the fly to check the lifted kernel;
  * Hecke operators read the kernel through the class table.
Author: Dula."""
import time, numpy as np, numba as nb
from sparse_h1 import FastLevel, relator_arrays, _build_rows, delta_mpar, MUL, INV
import lanczos16
from lanczos16 import MASKS, to_bits, from_bits
import gf

# ------------------------------------------------------------------ closure with path compression
@nb.njit(cache=True)
def _find(u, par, fac, mul, stack):
    k = 0; v = u
    while par[v] != v:
        stack[k] = v; k += 1; v = par[v]
    f = np.uint8(1)
    for i in range(k - 1, -1, -1):
        w = stack[i]; f = mul[fac[w], f]; fac[w] = f; par[w] = v
    return v

@nb.njit(cache=True)
def closure2(cols, vals, ncol, mul, inv):
    """Union-find closure under the equations with 1 (class is zero) or 2 (one class a multiple of another) terms.
    Returns root (-1 for zero classes), rfac (column = rfac * root), alive rows, passes."""
    par = np.arange(ncol, dtype=np.int64); fac = np.ones(ncol, dtype=np.uint8); zero = np.zeros(ncol, dtype=np.bool_)
    stack = np.empty(ncol, dtype=np.int32)
    R, T = cols.shape
    alive = np.ones(R, dtype=np.bool_)
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.uint8)
    changed = True; passes = 0
    while changed:
        changed = False; passes += 1
        for row in range(R):
            if not alive[row]: continue
            m = 0
            for t in range(T):
                u = cols[row, t]
                if u < 0: break
                v = _find(u, par, fac, mul, stack)
                if zero[v]: continue
                f = fac[u] if u != v else np.uint8(1)
                c = mul[vals[row, t], f]
                found = False
                for s in range(m):
                    if rc[s] == v:
                        rv[s] ^= c; found = True; break
                if not found:
                    rc[m] = v; rv[m] = c; m += 1
            k = 0
            for s in range(m):
                if rv[s] != 0:
                    rc[k] = rc[s]; rv[k] = rv[s]; k += 1
            if k == 0:
                alive[row] = False
            elif k == 1:
                zero[rc[0]] = True; alive[row] = False; changed = True
            elif k == 2:
                a = rc[0]; b = rc[1]
                par[a] = b; fac[a] = mul[rv[1], inv[rv[0]]]
                alive[row] = False; changed = True
    root = np.empty(ncol, dtype=np.int64); rfac = np.zeros(ncol, dtype=np.uint8)
    for u in range(ncol):
        v = _find(u, par, fac, mul, stack)
        if zero[v]:
            root[u] = -1; rfac[u] = 0
        else:
            root[u] = v; rfac[u] = fac[u] if u != v else np.uint8(1)
    return root, rfac, alive, passes

@nb.njit(cache=True)
def _row_hash(cs, vs, k):
    h = np.uint64(1469598103934665603)
    for i in range(k):
        h ^= np.uint64(cs[i]) * np.uint64(0x9E3779B97F4A7C15) + np.uint64(vs[i])
        h *= np.uint64(0x100000001B3)
        h ^= h >> np.uint64(29)
    return h

@nb.njit(cache=True)
def rows_to_csr(cols, vals, alive, cls_of, rfac, mul, inv):
    """Alive rows rewritten over class ids (cls_of[u] = class of column u or -1), merged, sorted, normalized (first
    coefficient 1), empty rows dropped.  Returns ptr, col (int32), val, hash per row."""
    R, T = cols.shape
    rc = np.empty(T, dtype=np.int64); rv = np.empty(T, dtype=np.uint8)
    lens = np.zeros(R, dtype=np.int64); total = 0; nrows = 0
    for row in range(R):
        if not alive[row]: continue
        m = 0
        for t in range(T):
            u = cols[row, t]
            if u < 0: break
            v = cls_of[u]
            if v < 0: continue
            c = mul[vals[row, t], rfac[u]]
            found = False
            for s in range(m):
                if rc[s] == v:
                    rv[s] ^= c; found = True; break
            if not found:
                rc[m] = v; rv[m] = c; m += 1
        k = 0
        for s in range(m):
            if rv[s] != 0: k += 1
        lens[row] = k; total += k
        if k: nrows += 1
    ptr = np.zeros(nrows + 1, dtype=np.int64); col = np.empty(total, dtype=np.int32); val = np.empty(total, dtype=np.uint8)
    hs = np.empty(nrows, dtype=np.uint64)
    r = 0; p = 0
    for row in range(R):
        if lens[row] == 0: continue
        m = 0
        for t in range(T):
            u = cols[row, t]
            if u < 0: break
            v = cls_of[u]
            if v < 0: continue
            c = mul[vals[row, t], rfac[u]]
            found = False
            for s in range(m):
                if rc[s] == v:
                    rv[s] ^= c; found = True; break
            if not found:
                rc[m] = v; rv[m] = c; m += 1
        k = 0
        for s in range(m):
            if rv[s] != 0:
                rc[k] = rc[s]; rv[k] = rv[s]; k += 1
        # insertion sort by class id
        for i in range(1, k):
            a = rc[i]; b = rv[i]; j = i - 1
            while j >= 0 and rc[j] > a:
                rc[j + 1] = rc[j]; rv[j + 1] = rv[j]; j -= 1
            rc[j + 1] = a; rv[j + 1] = b
        s0 = inv[rv[0]]
        for i in range(k):
            col[p + i] = rc[i]; val[p + i] = mul[s0, rv[i]]
        hs[r] = _row_hash(col[p:p + k], val[p:p + k], k)
        p += k; r += 1; ptr[r] = p
    return ptr, col, val, hs

@nb.njit(cache=True)
def _dedup_keep(ptr, col, val, hs, order):
    n = order.shape[0]; keep = np.zeros(n, dtype=np.bool_)
    i = 0
    while i < n:
        j = i
        while j < n and hs[order[j]] == hs[order[i]]: j += 1
        for a in range(i, j):
            ra = order[a]; dup = False
            for b in range(i, a):
                rb = order[b]
                if not keep[rb]: continue
                la = ptr[ra + 1] - ptr[ra]; lb = ptr[rb + 1] - ptr[rb]
                if la != lb: continue
                same = True
                for t in range(la):
                    if col[ptr[ra] + t] != col[ptr[rb] + t] or val[ptr[ra] + t] != val[ptr[rb] + t]:
                        same = False; break
                if same:
                    dup = True; break
            if not dup: keep[ra] = True
        i = j
    return keep

@nb.njit(cache=True)
def _select_rows(ptr, col, val, keep):
    R = ptr.shape[0] - 1; nr = 0; nn = 0
    for r in range(R):
        if keep[r]: nr += 1; nn += ptr[r + 1] - ptr[r]
    p2 = np.zeros(nr + 1, dtype=np.int64); c2 = np.empty(nn, dtype=np.int32); v2 = np.empty(nn, dtype=np.uint8)
    k = 0; i = 0
    for r in range(R):
        if not keep[r]: continue
        for t in range(ptr[r], ptr[r + 1]):
            c2[k] = col[t]; v2[k] = val[t]; k += 1
        i += 1; p2[i] = k
    return p2, c2, v2

@nb.njit(cache=True)
def _hash_rows(ptr, col, val, mul, inv):
    """Normalize every row in place (first coefficient 1) and hash it."""
    R = ptr.shape[0] - 1; hs = np.empty(R, dtype=np.uint64)
    for r in range(R):
        lo = ptr[r]; hi = ptr[r + 1]
        if hi > lo:
            s = inv[val[lo]]
            if s != 1:
                for t in range(lo, hi): val[t] = mul[s, val[t]]
        hs[r] = _row_hash(col[lo:hi], val[lo:hi], hi - lo)
    return hs

def dedup(ptr, col, val, hs=None):
    if hs is None: hs = _hash_rows(ptr, col, val, MUL, INV)
    order = np.argsort(hs, kind="stable")
    keep = _dedup_keep(ptr, col, val, hs, order)
    return _select_rows(ptr, col, val, keep)

# ------------------------------------------------------------------ Markowitz elimination in rounds
@nb.njit(cache=True)
def _mk_round(ptr, col, val, ncls, maxcost, mul, inv):
    R = ptr.shape[0] - 1; nnz = ptr[R]
    cw = np.zeros(ncls, dtype=np.int64)
    for t in range(nnz): cw[col[t]] += 1
    cptr = np.zeros(ncls + 1, dtype=np.int64)
    for c in range(ncls): cptr[c + 1] = cptr[c] + cw[c]
    crow = np.empty(nnz, dtype=np.int32); fp = cptr[:ncls].copy()
    for r in range(R):
        for t in range(ptr[r], ptr[r + 1]):
            c = col[t]; crow[fp[c]] = r; fp[c] += 1
    cand_cost = np.empty(ncls, dtype=np.int64); cand_col = np.empty(ncls, dtype=np.int64)
    prow = np.full(ncls, -1, dtype=np.int64); nc = 0
    for c in range(ncls):
        w = cw[c]
        if w == 0: continue
        best = -1; bl = 1 << 62
        for k in range(cptr[c], cptr[c + 1]):
            r = crow[k]; l = ptr[r + 1] - ptr[r]
            if l < bl:
                bl = l; best = r
        mc = (w - 1) * (bl - 1)
        if mc <= maxcost:
            cand_cost[nc] = mc; cand_col[nc] = c; prow[c] = best; nc += 1
    order = np.argsort(cand_cost[:nc], kind="mergesort")
    used = np.zeros(R, dtype=np.bool_)
    piv_of = np.full(R, -1, dtype=np.int64); mod_by = np.full(R, -1, dtype=np.int64)
    nsel = 0; extra = 0
    for oi in range(nc):
        c = cand_col[order[oi]]; ok = True
        for k in range(cptr[c], cptr[c + 1]):
            if used[crow[k]]:
                ok = False; break
        if not ok: continue
        p = prow[c]; lp = ptr[p + 1] - ptr[p]
        for k in range(cptr[c], cptr[c + 1]):
            r = crow[k]; used[r] = True
            if r == p: piv_of[r] = c
            else:
                mod_by[r] = c; extra += lp - 2
        nsel += 1
    bound = nnz + max(extra, 0)
    nptr = np.zeros(R + 1, dtype=np.int64); ncol_ = np.empty(bound, dtype=np.int32); nval = np.empty(bound, dtype=np.uint8)
    total_rec = 0
    for r in range(R):
        if piv_of[r] >= 0: total_rec += ptr[r + 1] - ptr[r]
    rec_c = np.empty(nsel, dtype=np.int32); rec_ptr = np.zeros(nsel + 1, dtype=np.int64)
    rec_col = np.empty(total_rec, dtype=np.int32); rec_val = np.empty(total_rec, dtype=np.uint8)
    nr = 0; k = 0; ki = 0; kr = 0
    for r in range(R):
        if piv_of[r] >= 0:
            rec_c[ki] = piv_of[r]
            for t in range(ptr[r], ptr[r + 1]):
                rec_col[kr] = col[t]; rec_val[kr] = val[t]; kr += 1
            ki += 1; rec_ptr[ki] = kr
            continue
        c = mod_by[r]
        if c < 0:
            for t in range(ptr[r], ptr[r + 1]):
                ncol_[k] = col[t]; nval[k] = val[t]; k += 1
        else:
            p = prow[c]; arc = 0; apc = 0
            for t in range(ptr[r], ptr[r + 1]):
                if col[t] == c:
                    arc = val[t]; break
            for t in range(ptr[p], ptr[p + 1]):
                if col[t] == c:
                    apc = val[t]; break
            f = mul[arc, inv[apc]]
            i = ptr[r]; ie = ptr[r + 1]; j = ptr[p]; je = ptr[p + 1]
            while i < ie or j < je:
                if j >= je or (i < ie and col[i] < col[j]):
                    ncol_[k] = col[i]; nval[k] = val[i]; k += 1; i += 1
                elif i >= ie or col[j] < col[i]:
                    ncol_[k] = col[j]; nval[k] = mul[f, val[j]]; k += 1; j += 1
                else:
                    v = val[i] ^ mul[f, val[j]]
                    if v != 0:
                        ncol_[k] = col[i]; nval[k] = v; k += 1
                    i += 1; j += 1
        if k > nptr[nr]:
            nr += 1; nptr[nr] = k
    return nptr[:nr + 1].copy(), ncol_[:k].copy(), nval[:k].copy(), rec_c, rec_ptr, rec_col, rec_val, nsel

SCHEDULE = [0, 1, 2, 3, 4, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128, 160, 192, 256, 320, 384, 512,
            640, 768, 1024, 1536, 2048, 3072, 4096, 6144, 8192]

def markowitz(ptr, col, val, ncls, fill=8.0, verbose=True, min_frac=0.002):
    """Rounds of independent Markowitz pivots.  Returns (ptr, col, val) of the core and the records (list of rounds)."""
    t0 = time.time(); nnz0 = len(col); bound = fill * nnz0; records = []; ncols_left = None; nrounds = 0
    for maxcost in SCHEDULE:
        while True:
            out = _mk_round(ptr, col, val, ncls, maxcost, MUL, INV)
            nsel = out[7]
            if nsel == 0: break
            ptr, col, val = out[0], out[1], out[2]; records.append(out[3:7]); nrounds += 1
            if len(col) > bound: break
            live = int(np.count_nonzero(np.bincount(col, minlength=ncls))) if nrounds % 4 == 0 else None
            if live is not None and nsel < min_frac * live: break
        if len(col) > bound: break
        # duplicates created by the merges
        ptr, col, val = dedup(ptr, col, val)
        if verbose:
            live = int(np.count_nonzero(np.bincount(col, minlength=ncls)))
            print("    cost <= %d: %d rounds so far, %d rows, %d live columns, nnz %d (%.0fs)" % (maxcost, nrounds, len(ptr) - 1, live, len(col), time.time() - t0), flush=True)
    ptr, col, val = dedup(ptr, col, val)
    return ptr, col, val, records

@nb.njit(cache=True)
def _relabel(col, newid):
    out = np.empty(col.shape[0], dtype=np.int32)
    for t in range(col.shape[0]): out[t] = newid[col[t]]
    return out

# ------------------------------------------------------------------ lifting and evaluation on the classes
@nb.njit(cache=True)
def lift(ncls, core_cls, Kcb, free_cls, d, rec_c, rec_ptr, rec_col, rec_val, masks, inv, wd):
    """Kernel basis on all classes, bitsliced (ncls, 4, wd): core values from Kcb (C, 4, wd), unit vectors on the
    free classes (indices d - #free ... d - 1), eliminated classes from the records in reverse order."""
    V = np.zeros((ncls, 4, wd), dtype=np.uint64)
    for i in range(core_cls.shape[0]): V[core_cls[i]] = Kcb[i]
    dc = d - free_cls.shape[0]
    for j in range(free_cls.shape[0]):
        b = dc + j; V[free_cls[j], 0, b >> 6] |= np.uint64(1) << np.uint64(b & 63)
    acc = np.zeros((4, wd), dtype=np.uint64)
    for k in range(rec_c.shape[0] - 1, -1, -1):
        c = rec_c[k]; ap = 0; acc[:] = 0
        for t in range(rec_ptr[k], rec_ptr[k + 1]):
            v = rec_col[t]; a = rec_val[t]
            if v == c:
                ap = a; continue
            for kk in range(4):
                mk = masks[a, kk]
                for l in range(4):
                    if (mk >> l) & 1:
                        for j in range(wd): acc[kk, j] ^= V[v, l, j]
        s = inv[ap]
        for kk in range(4):
            mk = masks[s, kk]
            for l in range(4):
                if (mk >> l) & 1:
                    for j in range(wd): V[c, kk, j] ^= acc[l, j]
    return V

@nb.njit(cache=True, parallel=True)
def check_all(nxt, nxe, tg, te, G, n, tree, cls_of, rfac, V, masks, mul):
    """Number of (relator, coset) equations not satisfied by every basis vector (re-derived on the fly)."""
    nr, T = tg.shape; wd = V.shape[2]
    bad = np.zeros(n, dtype=np.int64)
    for x in nb.prange(n):
        acc = np.zeros((4, wd), dtype=np.uint64)
        for r in range(nr):
            acc[:] = 0; cur = np.int64(x); w = np.uint8(1)
            for j in range(T):
                g = np.int64(tg[r, j])
                if g < 0: break
                if te[r, j] == 1:
                    u = g * n + cur; c = w; w = mul[w, nxe[g, cur]]; cur = np.int64(nxt[g, cur])
                else:
                    w = mul[w, nxe[G + g, cur]]; cur = np.int64(nxt[G + g, cur]); u = g * n + cur; c = w
                if tree[u]: continue
                k = cls_of[u]
                if k < 0: continue
                a = mul[c, rfac[u]]
                for kk in range(4):
                    mk = masks[a, kk]
                    for l in range(4):
                        if (mk >> l) & 1:
                            for jj in range(wd): acc[kk, jj] ^= V[k, l, jj]
            nz = False
            for kk in range(4):
                for jj in range(wd):
                    if acc[kk, jj] != 0: nz = True
            if nz or cur != np.int64(x): bad[x] += 1
    return bad.sum()

@nb.njit(cache=True)
def accumulate(edges, coefs, cls_of, rfac, V, masks, mul):
    """sum_i coefs[i] * K(edges[i]) as a bitsliced vector (4, wd), K(u) = rfac[u] V[cls_of[u]]."""
    wd = V.shape[2]; acc = np.zeros((4, wd), dtype=np.uint64)
    for i in range(edges.shape[0]):
        u = edges[i]; k = cls_of[u]
        if k < 0: continue
        a = mul[coefs[i], rfac[u]]
        if a == 0: continue
        for kk in range(4):
            mk = masks[a, kk]
            for l in range(4):
                if (mk >> l) & 1:
                    for j in range(wd): acc[kk, j] ^= V[k, l, j]
    return acc

@nb.njit(cache=True, parallel=True)
def dot_all(V, a, d, mul):
    """s[k] = sum_j a[j] V[k, j] for every class k (a: uint8 of length d)."""
    ncls = V.shape[0]; wd = V.shape[2]
    # tables: for word j, byte position q, plane l: XOR of a over the set bits
    tab = np.zeros((wd, 8, 256), dtype=np.uint8)
    for j in range(wd):
        for q in range(8):
            for byte in range(256):
                s = 0
                for bit in range(8):
                    idx = j * 64 + q * 8 + bit
                    if (byte >> bit) & 1 and idx < d: s ^= a[idx]
                tab[j, q, byte] = s
    # plane l contributes beta_l * (XOR ...), beta_l = element with code 1 << l
    out = np.zeros(ncls, dtype=np.uint8)
    for k in nb.prange(ncls):
        tot = 0
        for l in range(4):
            s = 0
            for j in range(wd):
                wv = V[k, l, j]
                if wv == 0: continue
                for q in range(8):
                    s ^= tab[j, q, int((wv >> np.uint64(8 * q)) & np.uint64(255))]
            tot ^= mul[1 << l, s]
        out[k] = tot
    return out

@nb.njit(cache=True)
def edge_values_check(cls_of, rfac, tree, s, dm, mul):
    """Number of edges u with rfac[u] s[cls_of[u]] != dm[u] (tree edges and zero classes: value 0)."""
    bad = 0
    for u in range(cls_of.shape[0]):
        if tree[u] or cls_of[u] < 0: v = 0
        else: v = mul[rfac[u], s[cls_of[u]]]
        if v != dm[u]: bad += 1
    return bad

# ------------------------------------------------------------------ the whole computation
class BigH1:
    """Stages (each cached in the directory `cache` if given, so that a run can be resumed): reduction (closure,
    deduplication, Markowitz) -> core kernel (Lanczos, with checkpoints) -> lifting and the check of every equation."""
    def __init__(self, L, fill=8.0, verbose=True, seed=1, lanczos_w=4, dense_max=6000, cache=None):
        import os, json
        self.L = L; self.t = {}; t0 = time.time(); G = len(L.gens); n = L.n
        tg, te = relator_arrays(L); self.tg, self.te = tg, te
        path = None if cache is None else os.path.join(cache, "reduction.npz")
        if path is not None and os.path.exists(path):
            z = np.load(path)
            for k in ("cls_of", "rfac", "rep_edge", "core_cls", "free_cls", "rec_c", "rec_ptr", "rec_col", "rec_val", "ptr", "ccol", "val"):
                setattr(self, k, z[k])
            self.ncls = int(z["ncls"]); self.nnz_dedup = int(z["nnz_dedup"]); self.core_shape = tuple(int(v) for v in z["core_shape"])
            self.t["reduction"] = float(z["t_reduction"]); del z
            if verbose: print("  reduction loaded from %s: %d classes, core %d x %d, nnz %d" % (path, self.ncls, *self.core_shape), flush=True)
        else:
            self._reduce(fill, verbose)
            if path is not None:
                os.makedirs(cache, exist_ok=True)
                np.savez(path, cls_of=self.cls_of, rfac=self.rfac, rep_edge=self.rep_edge, core_cls=self.core_cls, free_cls=self.free_cls,
                         rec_c=self.rec_c, rec_ptr=self.rec_ptr, rec_col=self.rec_col, rec_val=self.rec_val, ptr=self.ptr, ccol=self.ccol,
                         val=self.val, ncls=self.ncls, nnz_dedup=self.nnz_dedup, core_shape=np.array(self.core_shape), t_reduction=self.t["reduction"])
        # core kernel
        t1 = time.time()
        path = None if cache is None else os.path.join(cache, "core.npz")
        C = self.core_shape[1]
        if path is not None and os.path.exists(path):
            z = np.load(path); Kc = z["Kc"]; self.lanczos_runs = json.loads(str(z["runs"])); self.t["core"] = float(z["t_core"]); del z
            self.complete = (not self.lanczos_runs) or any(r["kernel"] >= r.get("gap", C - r["krylov_dim"]) or r.get("kerA_in_span", -1) >= r.get("gap", C - r["krylov_dim"]) for r in self.lanczos_runs)
            if verbose: print("  core kernel loaded from %s: %d" % (path, Kc.shape[0]), flush=True)
        else:
            Kc = self._core(C, seed, lanczos_w, dense_max, verbose, cache)
            self.t["core"] = time.time() - t1
            if path is not None:
                np.savez(path, Kc=Kc, runs=json.dumps(self.lanczos_runs), t_core=self.t["core"])
        del self.ptr, self.ccol, self.val
        dcore = Kc.shape[0]; d = dcore + len(self.free_cls); self.d = d; self.dcore = dcore
        if verbose: print("  core kernel %d; kernel dimension %d (%.0fs)" % (dcore, d, time.time() - t0), flush=True)
        # lift and check
        t2 = time.time()
        wd = max(1, (d + 63) // 64); self.wd = wd
        Kcb = to_bits(Kc.T.copy(), wd) if dcore else np.zeros((C, 4, wd), dtype=np.uint64)
        del Kc
        self.V = lift(self.ncls, self.core_cls.astype(np.int64), Kcb, self.free_cls.astype(np.int64), d, self.rec_c, self.rec_ptr,
                      self.rec_col, self.rec_val, MASKS, INV, wd)
        del Kcb
        bad = check_all(L.NXT, L.NXE, tg, te, G, n, L.TREE, self.cls_of, self.rfac, self.V, MASKS, MUL)
        assert bad == 0, "lifted kernel fails %d equations" % bad
        self.t["lift_check"] = time.time() - t2
        if verbose: print("  kernel lifted to %d classes and checked against all %d equations (re-derived): dimension %d (%.0fs)" % (self.ncls, tg.shape[0] * n, d, time.time() - t0), flush=True)

    def _reduce(self, fill, verbose):
        L = self.L; t0 = time.time(); G = len(L.gens); n = L.n; ncol = G * n; tg, te = self.tg, self.te
        cols, vals = _build_rows(L.NXT, L.NXE, tg, te, G, n, L.TREE, MUL)
        assert not (cols[:, 0] == -2).any(), "a relator did not close"
        nnz0 = int((cols >= 0).sum())
        if verbose: print("  equations: %d rows, %d non-tree columns, nnz %d (%.0fs)" % (cols.shape[0], ncol - int(L.TREE.sum()), nnz0, time.time() - t0), flush=True)
        root, rfac, alive, passes = closure2(cols, vals, ncol, MUL, INV)
        root[L.TREE] = -1; rfac[L.TREE] = 0
        reps = np.unique(root[root >= 0]); ncls = len(reps)
        cls_of = -np.ones(ncol, dtype=np.int32)
        pos = -np.ones(ncol, dtype=np.int64); pos[reps] = np.arange(ncls)
        m = root >= 0; cls_of[m] = pos[root[m]].astype(np.int32)
        del pos, root, m
        self.cls_of, self.rfac, self.rep_edge, self.ncls = cls_of, rfac, reps, ncls
        if verbose: print("  closure (%d passes): %d classes of columns, %d equations left (%.0fs)" % (passes, ncls, int(alive.sum()), time.time() - t0), flush=True)
        ptr, col, val, hs = rows_to_csr(cols, vals, alive, cls_of, rfac, MUL, INV)
        del cols, vals, alive
        ptr, col, val = dedup(ptr, col, val, hs); del hs
        inrows = np.bincount(col, minlength=ncls) > 0
        if verbose: print("  deduplicated: %d equations, %d classes in equations, %d free classes, nnz %d (%.0fs)" % (len(ptr) - 1, int(inrows.sum()), ncls - int(inrows.sum()), len(col), time.time() - t0), flush=True)
        self.nnz_dedup = len(col)
        ptr, col, val, records = markowitz(ptr, col, val, ncls, fill=fill, verbose=verbose)
        nrec = sum(len(r[0]) for r in records)
        self.rec_c = np.concatenate([r[0] for r in records]) if records else np.zeros(0, np.int32)
        offs = np.cumsum([0] + [len(r[2]) for r in records])
        self.rec_ptr = np.concatenate([[0]] + [r[1][1:] + o for r, o in zip(records, offs[:-1])]).astype(np.int64)
        self.rec_col = np.concatenate([r[2] for r in records]) if records else np.zeros(0, np.int32)
        self.rec_val = np.concatenate([r[3] for r in records]) if records else np.zeros(0, np.uint8)
        del records
        cw = np.bincount(col, minlength=ncls)
        elim = np.zeros(ncls, dtype=np.bool_); elim[self.rec_c] = True
        core_cls = np.nonzero(cw > 0)[0]; free_cls = np.nonzero((cw == 0) & ~elim)[0]
        C = len(core_cls)
        newid = -np.ones(ncls, dtype=np.int64); newid[core_cls] = np.arange(C)
        ccol = _relabel(col, newid); del col
        self.core_cls, self.free_cls = core_cls, free_cls
        self.ptr, self.ccol, self.val = ptr, ccol, val
        if verbose: print("  Markowitz: %d classes eliminated; core %d equations x %d columns, nnz %d; free classes %d (%.0fs)" % (nrec, len(ptr) - 1, C, len(ccol), len(free_cls), time.time() - t0), flush=True)
        self.core_shape = (len(ptr) - 1, C, len(ccol)); self.t["reduction"] = time.time() - t0

    def _core(self, C, seed, lanczos_w, dense_max, verbose, cache):
        import os
        ptr, ccol, val = self.ptr, self.ccol, self.val
        self.lanczos_runs = []; self.complete = True
        if C == 0:
            return np.zeros((0, 0), dtype=np.uint8)
        if C <= dense_max:
            rng = np.random.default_rng(seed); mrows = C + 48
            Mc = np.zeros((mrows, C), dtype=np.uint8)
            for r in range(len(ptr) - 1):
                cs = ccol[ptr[r]:ptr[r + 1]].astype(np.int64); vs = val[ptr[r]:ptr[r + 1]]
                for _ in range(3):
                    t = int(rng.integers(mrows)); f = int(rng.integers(1, 16)); Mc[t, cs] ^= MUL[f, vs]
            import gf16_bits
            Kc, _ = gf16_bits.kernel_bits(Mc)
            bad = lanczos16.check_block(ptr, ccol, val, to_bits(Kc.T.copy(), max(1, (Kc.shape[0] + 63) // 64)), Kc.shape[0])
            assert not bad.any(), "dense core kernel fails the core equations"
            return Kc
        # Completeness: with K = ker M n span Z and K_A = ker A n span Z (A = M^T D M), and
        # g = C - (Krylov dimension) - rank V_m, dim K <= dim ker M <= dim ker A <= g.  If dim K = g, or dim K_A = g (then ker M lies in K_A, inside span Z, so
        # K = ker M), the kernel is complete.  Otherwise the block is widened to g + 64 or more, and, if it was already
        # that wide, the run is repeated with another D and start block (another seed), at most twice.
        import json
        w = lanczos_w; sd = seed; extra = 0
        runs_file = None if cache is None else os.path.join(cache, "lanczos_runs.json")
        if runs_file is not None and os.path.exists(runs_file):
            self.lanczos_runs = json.load(open(runs_file))
            for r in self.lanczos_runs:
                g = r.get("gap", C - r["krylov_dim"])
                if r["kernel"] >= g or r.get("kerA_in_span", -1) >= g: continue
                if r["block"] < g + 64: w = max(w, g // 64 + 2)
                else:
                    extra += 1; sd = seed + 7919 * extra; w = max(w, r["block"] // 64)
            if verbose: print("  earlier Lanczos runs: %s; next block %d, seed %d" % ([(r["block"], r["kernel"], r.get("kerA_in_span"), r.get("gap", C - r["krylov_dim"])) for r in self.lanczos_runs], 64 * w, sd), flush=True)
        while True:
            ck = None if cache is None else os.path.join(cache, "lanczos_w%d_s%d.npz" % (w, sd))
            Kc, info = lanczos16.lanczos_kernel(ptr, ccol, val, C, w, seed=sd, verbose=verbose, ckpt=ck)
            self.lanczos_runs.append(info)
            if runs_file is not None:
                with open(runs_file, "w") as f: json.dump(self.lanczos_runs, f)
            g = info["gap"]
            if Kc.shape[0] >= g or info["kerA_in_span"] >= g:
                self.complete = True; break
            if 64 * w < g + 64:
                w = g // 64 + 2
                if verbose: print("  kernel found %d < %d: block widened to %d" % (Kc.shape[0], g, 64 * w), flush=True)
                continue
            extra += 1
            if extra > 2:
                self.complete = False
                if verbose: print("  completeness not certified after %d runs (kernel %d, ker A in span %d, g = %d)" % (len(self.lanczos_runs), Kc.shape[0], info["kerA_in_span"], g), flush=True)
                break
            sd = seed + 7919 * extra
            if verbose: print("  kernel %d, ker A in span %d < g = %d with a wide block: rerun with seed %d" % (Kc.shape[0], info["kerA_in_span"], g, sd), flush=True)
        return Kc

    # ---------------------------------------------------------------- reading the basis
    def class_matrix(self, cls_list):
        """(len, d) uint8: values of the basis on the representative edges of the given classes."""
        return from_bits(self.V[np.asarray(cls_list, dtype=np.int64)], self.d)

    def edge_matrix(self, edges):
        edges = np.asarray(edges, dtype=np.int64); out = np.zeros((len(edges), self.d), dtype=np.uint8)
        k = self.cls_of[edges]; ok = (k >= 0) & ~self.L.TREE[edges]
        if ok.any():
            M = self.class_matrix(k[ok]); out[ok] = MUL[self.rfac[edges[ok]][:, None], M]
        return out

    def pivot_classes(self, rng, extra=0):
        d = self.d; m = min(self.ncls, max(4 * d, 64))
        while True:
            sub = np.sort(rng.choice(self.ncls, size=m, replace=False))
            A = np.ascontiguousarray(self.class_matrix(sub).T); piv = list(gf.rref16(A, MUL, INV))
            if len(piv) == d: return sub[piv]
            if m == self.ncls: raise ValueError("dependent basis")
            m = min(self.ncls, 2 * m)

    def quotient_dm(self, rng, verbose=True):
        """Coordinates of delta m_par (non-trivial nebentypus), checked on every edge; index dropped."""
        L = self.L; dm = delta_mpar(L); self.dm = dm
        self.pcls = self.pivot_classes(rng)
        if dm is None:
            self.drop = None; return
        P = self.class_matrix(self.pcls)                         # (d, d): rows pivots
        rhs = dm[self.rep_edge[self.pcls]]
        Aug = np.concatenate([P, rhs[:, None]], axis=1).astype(np.uint8)
        piv = list(gf.rref16(Aug, MUL, INV)); assert all(p < self.d for p in piv) and len(piv) == self.d
        a = np.zeros(self.d, dtype=np.uint8)
        for r, p in enumerate(piv): a[p] = Aug[r, self.d]
        s = dot_all(self.V, a, self.d, MUL)
        bad = edge_values_check(self.cls_of, self.rfac, L.TREE, s, dm, MUL)
        assert bad == 0, "delta m_par is not the combination found (%d edges)" % bad
        self.drop = int(np.nonzero(a)[0][0]); self.dm_coords = a
        if verbose: print("  delta m_par lies in the span (checked on all %d edges); basis vector %d dropped" % (len(dm), self.drop), flush=True)

    def hecke(self, pi, rng, extra=8):
        """Matrix (D x D, D = d or d - 1) of T_pi on H^1, columns = images of the basis vectors."""
        import hecke
        L = self.L; n = L.n; d = self.d
        keep = np.array([k for k in range(d) if k != self.drop], dtype=np.int64)
        pedges = [int(u) for u in self.rep_edge[self.pcls]]
        others = rng.choice(self.ncls, size=extra, replace=False)
        cols = pedges + [int(u) for u in self.rep_edge[others] if int(u) not in set(pedges)]
        vals = np.zeros((len(cols), len(keep)), dtype=np.uint8)
        for r, u in enumerate(cols):
            g = L.gens[u // n]; x = u % n
            h = L.schreier(g, x); pieces = hecke.hecke_pieces(L, pi, h)
            es = []; cs = []
            for hi, w in pieces:
                for v, c in hecke.functional(L, hi).items():
                    if c:
                        es.append(v); cs.append(int(MUL[w, c]))
            acc = accumulate(np.array(es, dtype=np.int64), np.array(cs, dtype=np.uint8), self.cls_of, self.rfac, self.V, MASKS, MUL)
            vec = from_bits(acc[None, :, :], d)[0]
            vals[r] = MUL[int(INV[L.lam[x]]), vec[keep]]
        Bc = self.edge_matrix(cols)                                # (len(cols), d): values of the d basis vectors
        if self.drop is not None:
            Bc = np.concatenate([Bc[:, keep], self.dm[np.array(cols)][:, None]], axis=1)
        Dd = Bc.shape[1]
        Aug = np.concatenate([Bc, vals], axis=1).astype(np.uint8)
        piv = list(gf.rref16(Aug, MUL, INV))
        if any(p >= Dd for p in piv): return None
        X = np.zeros((Dd, len(keep)), dtype=np.uint8)
        for r, p in enumerate(piv): X[p] = Aug[r, Dd:]
        return X[:len(keep)]
