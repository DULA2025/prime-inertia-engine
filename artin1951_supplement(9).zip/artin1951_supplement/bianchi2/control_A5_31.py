"""Control experiment with an icosahedral mod-2 system that is RAMIFIED at 2.

Over Q: the newform of level 31, weight 2, nebentypus eps of order 5 (conductor 31) found by find_models3.py has a
mod-2 representation rbar with projective image A5 = PSL_2(F_4), residue field F_16, a_2 a unit (ordinary at 2) and no
companion form, so rbar is ramified at 2 and only the refinement a_2 is allowed at 2.
Over E = Q(sqrt-7): 31 is inert (like 1951), the level is 31 O_E (index 962), and the nebentypus is eps o N_{E/Q}, of
order 5 (like chi o N for 1951); coefficients F_16.  We compute H^1(Gamma_0(31 O_E), F_16(eps o N)) for PGL_2(O_E),
the rbar-part (base change of rbar), and the pairs (T_v, T_vbar) on it.  Expectation (local weight at v and vbar
forced by the ordinary, ramified rbar|D_2): only (a_2, a_2); no mixed pairs.
Eigenvalue convention: the engine's T_q may realise a_q or a_q / eps(q) (complex-conjugate form), and its nebentypus
eps or eps^-1; both conventions are tried and reported.
Usage: python3 control_A5_31.py [EPS_SIGN]   (EPS_SIGN = 1 or -1: nebentypus eps o N or eps^-1 o N)   Author: Dula."""
import sys, json, time, resource
import numpy as np, cypari2
from bmf import *
from hecke import *
import gf
from mod2_refine import gen_eigenspace, restrict, eigen_pairs
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
SGN = int(sys.argv[1]) if len(sys.argv) > 1 else 1
N = 31; NB = 400
t0 = time.time()
# ---------------- the form over Q and its reduction ----------------
pari("Gc = znstar(%d, 1); Lc = chargalois(Gc); ci = select(i -> charorder(Gc, Lc[i]) == 5, [1..#Lc])[1];" % N)
pari("mf = mfinit([%d, 2, [Gc, Lc[ci]]], 0); B = mfeigenbasis(mf); F = mffields(mf); cm = mfparams(mf)[3]; "
     "Gm = znstar(cm.mod, 1); chm = znconreychar(Gm, cm); cyc = mfparams(mf)[5];" % N)
assert int(pari("charorder(Gm, chm)")) == 5 and int(pari("#B")) >= 1
pari("co = mfcoefs(B[1], %d); P = F[1]; R = rnfequation(cyc, P, 1); Pabs = R[1]; A = lift(R[2]); kk = R[3];" % NB)
pari("toabs(c) = Mod(subst(subst(liftall(c), 'y, 'y - kk * A), 't, A), Pabs);")
pari("epsv(p) = my(r = chareval(Gm, chm, p)); Mod(t^(r * 5), cyc);")
assert int(pari("my(ok = 1); forprime(p = 3, 19, if (p != %d, if (co[p^2 + 1] != co[p + 1]^2 - p * epsv(p), ok = 0))); ok" % N)) == 1
pari("nf = nfinit([Pabs, [2]]); dec = idealprimedec(nf, 2);")
# the prime P | 2 with projective image A5 (residue degree 4)
kP = None
for k in range(1, int(pari("#dec")) + 1):
    if int(pari("dec[%d].f" % k)) == 4: kP = k; break
pari("modP = nfmodprinit(nf, dec[%d]); rd2(x) = nfmodpr(nf, toabs(x), modP);" % kP)
pari("u2 = rd2(co[3]); gen = ffgen(u2); m = gen.mod;")
mc = [int(c) % 2 for c in pari("Vecrev(lift(m))")]
def ev16(cs, th):
    r = 0; pw = 1
    for c in cs:
        if c: r ^= pw
        pw = int(gf.MUL16[pw, th])
    return r
th = [x for x in range(16) if ev16(mc, x) == 0][0]
def to16(expr):
    cs = [int(c) % 2 for c in pari("my(z = %s); Vecrev(lift(z.pol))" % expr)] if int(pari("type(%s) == \"t_FFELT\"" % expr)) else [int(pari("lift(%s)" % expr)) % 2]
    return ev16(cs, th)
PRS = [int(q) for q in pari("primes([3, 120])") if int(q) != N]
AP = {p: to16("rd2(co[%d + 1])" % p) for p in PRS}; AP[2] = to16("u2")
EP = {p: to16("nfmodpr(nf, toabs(epsv(%d)), modP)" % p) for p in PRS + [2]}
U = {p: int(gf.MUL16[gf.MUL16[AP[p], AP[p]], gf.INV16[EP[p]]]) for p in PRS}
assert all(u in gf.F4 for u in U.values()) and 1 in U.values() and any(u not in (0, 1) for u in U.values()), "not A5"
print("level 31, eps of order 5: form 1 mod P (f = 4): a_2 -> %d, eps(2) -> %d; projective image A5 (u_p in F4, orders 3 and 5 occur)" % (AP[2], EP[2]), flush=True)
# eps on F_31^x via the primitive root 3
g = 3; E31 = {}; e3 = EP[3] if SGN == 1 else int(gf.INV16[EP[3]]); cur = 1; acc = 1
for k in range(30):
    E31[cur] = acc; cur = cur * g % N; acc = int(gf.MUL16[acc, e3])
assert len(E31) == 30
assert all(E31[p % N] == (EP[p] if SGN == 1 else int(gf.INV16[EP[p]])) for p in PRS[:20]), "eps table inconsistent"
comp = Comp("Fp2", N)
def eps_fn(lams): return E31[comp.norm(lams[0])]
# ---------------- Bianchi side ----------------
Lv = Level([comp], field="F16", eps=eps_fn, group="PGL", name="31 O_E")
K = Lv.cohomology(); DZ = K.shape[0]
# with eps != 1 the gauge-fixed cocycles contain the coboundary delta m_par (m_par: eps-transport of m(root) = 1 along the
# tree); H^1 = Z_gauge / <delta m_par>.  Choose rows of K completing delta m_par to a basis of Z_gauge.
if Lv.dmpar is not None:
    keep = []; cur = np.array(Lv.dmpar[None, :] % 16, dtype=np.uint8)
    assert gf.rank16(np.vstack([cur, K.astype(np.uint8)])) == DZ, "delta m_par not in Z_gauge"
    for r in range(DZ):
        cand = np.vstack([cur, K[r:r + 1].astype(np.uint8)])
        if gf.rank16(cand) == cand.shape[0]: cur = cand; keep.append(r)
    K = K[keep]
D = K.shape[0]
print("level 31 O_E (inert), n = %d, nebentypus eps%s o N: gauge-fixed cocycles %d, coboundary delta m_par %s; dim H^1(Gamma_0, F16(eps)) [PGL] = %d  (%.0fs)"
      % (Lv.n, "" if SGN == 1 else "^-1", DZ, "present" if Lv.dmpar is not None else "zero", D, time.time() - t0), flush=True)
def find_pi(p):
    for yy in range(1, 40):
        for xx in range(-80, 80):
            if onorm((xx, yy)) == p: return (xx, yy)
ops = [("v", (0, 1), 2, "split"), ("vbar", (1, -1), 2, "split"), ("(3)", (3, 0), 3, "inert"), ("(5)", (5, 0), 5, "inert"),
       ("(sqrt-7)", (-1, 2), 7, "ram")]
for p in (11, 23, 29, 37, 43, 53):
    pi = find_pi(p); ops += [("q%d" % p, pi, p, "split"), ("q%dbar" % p, oconj(pi), p, "split")]
ops += [("(13)", (13, 0), 13, "inert"), ("(17)", (17, 0), 17, "inert"), ("(19)", (19, 0), 19, "inert")]
Ts = {}; piv = None
for nm, pi, p, typ in ops:
    T, ok, piv = hecke_matrix(Lv, K, pi, pivots=piv); assert ok, nm; Ts[nm] = (T.astype(np.uint8), p, typ)
comm = all((gf.matmul16(Ts[a][0], Ts[b][0]) == gf.matmul16(Ts[b][0], Ts[a][0])).all() for a in Ts for b in Ts)
print("Hecke operators: %d, commute: %s  (%.0fs)" % (len(Ts), comm, time.time() - t0), flush=True)
allpairs = eigen_pairs(Ts["v"][0], Ts["vbar"][0])
print("(T_v, T_vbar) pairs on all of H^1:", allpairs, flush=True)
# each joint eigenspace of (T_v, T_vbar) on all of H^1: restriction to the cusp oo (cocycle values on the A- and U-loops
# at the root coset, where the stabiliser acts trivially on the fibre; non-zero = not cuspidal, i.e. Eisenstein) and
# whether T_q = T_qbar for the split q tested (as for a base change)
classes = []
for (a, b, m) in allpairs:
    Vab = gen_eigenspace([Ts["v"][0], Ts["vbar"][0]], [a, b], D); Wc = gf.matmul16(Vab, K.astype(np.uint8))
    cusp = any(int(w[Lv.unk("A", Lv.root)]) or int(w[Lv.unk("U", Lv.root)]) for w in Wc)
    sym = all((restrict(Ts["q%d" % p][0], Vab) == restrict(Ts["q%dbar" % p][0], Vab)).all() for p in (11, 23, 29, 37, 43, 53))
    classes.append({"pair": [a, b], "dim": int(Vab.shape[0]), "nonzero_at_cusp_oo": bool(cusp), "Tq_equals_Tqbar": bool(sym)})
    print("  (%d, %d): dim %d; restriction to the cusp oo %s; T_q = T_qbar at the split q tested: %s"
          % (a, b, Vab.shape[0], "NON-ZERO (Eisenstein)" if cusp else "zero", sym), flush=True)
res = {"N": N, "eps_sign": SGN, "n": Lv.n, "dim_Z_gauge": DZ, "dimH1": D, "commute": comm, "a2": AP[2], "eps2": EP[2], "pairs_all_H1": allpairs, "classes": classes, "conventions": {}}
names = [k for k in Ts if k not in ("v", "vbar")]; first = names[:6]; rest = names[6:]
for conv in ("a_q", "a_q/eps(q)"):
    def lam(p):
        a = AP[p] if conv == "a_q" else int(gf.MUL16[AP[p], gf.INV16[EP[p]]]); return a
    def evq(nm):
        T, p, typ = Ts[nm]; a = lam(p); return a if typ != "inert" else int(gf.MUL16[a, a])
    V = gen_eigenspace([Ts[k][0] for k in first], [evq(k) for k in first], D)
    out = {"rbar_dim": int(V.shape[0])}
    line = "convention T_q -> %s: rbar-part (from %s) dim %d" % (conv, ", ".join(first), V.shape[0])
    if V.shape[0]:
        Rv = restrict(Ts["v"][0], V); Rvb = restrict(Ts["vbar"][0], V); pr = eigen_pairs(Rv, Rvb)
        out["pairs"] = pr; out["expected_a2"] = lam(2)
        # eigenvector test at the remaining operators for each joint eigenvector of (T_v, T_vbar)
        tests = {}
        for (a, b, mlt) in pr:
            Va = gen_eigenspace([Rv, Rvb], [a, b], V.shape[0]); W = gf.matmul16(Va, V)
            okv = [all((gf.matmul16(Ts[nm][0], w[:, None])[:, 0] == gf.MUL16[evq(nm), w]).all() for nm in rest) for w in W]
            tests["%d,%d" % (a, b)] = okv
        out["eigenvector_tests_at"] = rest; out["eigenvector_tests"] = tests
        line += "; (T_v, T_vbar) pairs %s; expected (a_2, a_2) = (%d, %d) under this convention; eigenvector tests at %d further operators: %s" % (
            pr, lam(2), lam(2), len(rest), tests)
    print(line, flush=True); res["conventions"][conv] = out
res["seconds"] = round(time.time() - t0); res["peak_rss_MB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
json.dump(res, open("control_A5_31_s%d.json" % SGN, "w"), indent=1, default=int)
print("done (%.0fs, peak RSS %d MB)" % (time.time() - t0, res["peak_rss_MB"]))
