"""Generic model run: weight-2 newform orbit of prime level N, prime P | 2 of its Hecke field with the companion property;
traces tr rbar(Frob_p) = a_p mod P mapped into GF(16) (encoding of gf.py); Bianchi level N O_E over E = Q(sqrt-7), PGL_2,
coefficients F2.  Prints the rbar-part of H^1 and the joint generalized eigenvalues of (T_v, T_vbar).
Usage: python3 run_model.py N ORBIT [PRIME_INDEX]      Author: Dula."""
import sys, json, time, resource
import numpy as np
import cypari2
from bmf import *
from hecke import *
import gf
from mod2_refine import root, gen_eigenspace, restrict, eigen_pairs
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
N = int(sys.argv[1]); orb = int(sys.argv[2]); kP = int(sys.argv[3]) if len(sys.argv) > 3 else None
pari("mf = mfinit([%d, 2], 0); L = mfeigenbasis(mf); P = mffields(mf)[%d]; nf = nfinit(P); co = mfcoefs(L[%d], 500); dec = idealprimedec(nf, 2);" % (N, orb, orb))
cands = []
for k in range(1, int(pari("#dec")) + 1):
    pari("pr = dec[%d]; modP = nfmodprinit(nf, pr); u = nfmodpr(nf, lift(co[3]), modP);" % k)
    if int(pari("pr.f")) in (2, 4) and pari("u != 0 && u^2 != 1") == 1: cands.append(k)
k = kP if kP is not None else cands[0]
pari("pr = dec[%d]; modP = nfmodprinit(nf, pr); u = nfmodpr(nf, lift(co[3]), modP);" % k)
f = int(pari("pr.f")); assert int(pari("poldegree(modP[#modP])")) == f
mc = [int(c) % 2 for c in pari("Vecrev(lift(modP[#modP]))")]     # residue field F2[t]/(m), m = modP[#modP]; constant first
def ev16(poly_coeffs, th):
    r = 0; pw = 1
    for c in poly_coeffs:
        if c: r ^= pw
        pw = int(gf.MUL16[pw, th])
    return r
roots = [th for th in range(16) if ev16(mc, th) == 0]
assert roots, "residue field does not embed in F16"
th = roots[0]
def to16(expr):
    cs = [int(c) % 2 for c in pari("my(z = %s, w = z.pol); if(type(w) == \"t_POL\", Vecrev(lift(w)), [lift(w)])" % expr)]
    return ev16(cs, th)
TR = {p: to16("nfmodpr(nf, lift(co[%d + 1]), modP)" % p) for p in [int(q) for q in pari("primes([3, 100])")] if p != N}   # computed before the Bianchi part
def trace(p): return TR[p]
x = to16("u"); y = int(gf.INV16[x])
print("N = %d orbit %d (Hecke field degree %d), P | 2 of residue degree %d; T_2 eigenvalue u -> %d, Frob_2 eigenvalues (x, y) = (%d, %d)" % (N, orb, int(pari("poldegree(P)")), f, x, x, y), flush=True)
split = int(pari("kronecker(-7, %d)" % N)) == 1
comps = [Comp("Fp", N, root(N, 0)), Comp("Fp", N, root(N, 1))] if split else [Comp("Fp2", N)]
t0 = time.time()
Lv = Level(comps, field="F2", group="PGL"); K = Lv.cohomology(); D = K.shape[0]
print("level N O_E (%s), n = %d: dim H^1(Gamma_0, F2) [PGL] = %d  (%.0fs)" % ("split" if split else "inert", Lv.n, D, time.time() - t0), flush=True)
def find_pi(p):
    for yy in range(1, 40):
        for xx in range(-80, 80):
            if onorm((xx, yy)) == p: return (xx, yy)
ops = [("v", (0, 1), 2, "v"), ("vbar", (1, -1), 2, "v"), ("(3)", (3, 0), 3, "inert"), ("(5)", (5, 0), 5, "inert"), ("(sqrt-7)", (-1, 2), 7, "ram")]
for p in (11, 23, 29, 37, 43):
    if p == N: continue
    pi = find_pi(p); ops += [("q%d" % p, pi, p, "split"), ("q%dbar" % p, oconj(pi), p, "split")]
ops += [("(13)", (13, 0), 13, "inert")]
Ts = {}; piv = None
for nm, pi, p, typ in ops:
    t1 = time.time(); T, ok, piv = hecke_matrix(Lv, K, pi, pivots=piv); assert ok; Ts[nm] = (T.astype(np.uint8), p, typ)
print("Hecke operators computed (%d); commute: %s" % (len(Ts), all((gf.matmul16(Ts[a][0], Ts[b][0]) == gf.matmul16(Ts[b][0], Ts[a][0])).all() for a in Ts for b in Ts)), flush=True)
def evq(nm):
    T, p, typ = Ts[nm]; t = trace(p); return t if typ != "inert" else int(gf.MUL16[t, t])
use = [k for k in Ts if k not in ("v", "vbar")]
first = use[:6]; check = use[6:]
V = gen_eigenspace([Ts[k][0] for k in first], [evq(k) for k in first], D)
print("rbar-part (from %s): dim %d" % (", ".join(first), V.shape[0]), flush=True)
res = {"N": N, "orbit": orb, "residue_degree": f, "x": x, "y": y, "n": Lv.n, "dimH1_F2_PGL": D, "rbar_dim": int(V.shape[0])}
if V.shape[0]:
    Rv = restrict(Ts["v"][0], V); Rvb = restrict(Ts["vbar"][0], V)
    pairs = eigen_pairs(Rv, Rvb); res["pairs"] = pairs
    print("(T_v, T_vbar) generalized eigenvalue pairs:", pairs, flush=True)
    # verify eigenvectors of the mixed pairs at the remaining primes
    for (a, b) in [(x, y), (y, x)]:
        Va = gen_eigenspace([Rv, Rvb], [a, b], V.shape[0]); W = gf.matmul16(Va, V) if Va.shape[0] else Va
        okall = []
        for w in W:
            # w is in the generalized eigenspace; check genuine eigenvector for all remaining operators
            okall.append(all((gf.matmul16(Ts[nm][0], w[:, None])[:, 0] == gf.MUL16[evq(nm), w]).all() for nm in check))
        print("  mixed (%d, %d): dim %d; vectors that are eigenvectors with the rbar eigenvalue at %s: %s" % (a, b, Va.shape[0], ", ".join(check), okall), flush=True)
        res["mixed_%d_%d" % (a, b)] = {"dim": int(Va.shape[0]), "checked_at": check, "eigen_ok": okall}
json.dump(res, open("model_N%d.json" % N, "w"), indent=1, default=int)
res["seconds"] = round(time.time() - t0); res["peak_rss_MB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
json.dump(res, open("model_N%d.json" % N, "w"), indent=1, default=int)
print("done (%.0fs, peak RSS %d MB)" % (time.time() - t0, res["peak_rss_MB"]))
