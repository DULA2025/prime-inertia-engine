"""Validation of sparse_fp.py: dim H^1(Gamma_0(n), F_P(chi psi)) against the dense engine bmf.py.

Cases 23, 31, 47 (trivial chibar) and 31c (chibar of order 5), each with psi = 1 and with the allowed quadratic psi.
The sparse engine runs twice: with the dense core (exact rank) and with an early Markowitz stop so that the core goes
to the block Lanczos over F_P (upper bound with the certificate).  Usage: python3 fp_check.py.  Author: Dula."""
import json, time
import numpy as np, cypari2
from bmf import Comp, Level
from sparse_h1 import FastLevel, MUL
from mod2_refine import root as sroot
from bockstein import quad_step_tables, component_info, allowed_types
from sparse_fp import FpH1, choose_prime, chi_table
pari = cypari2.Pari()
t0 = time.time()
P = choose_prime(20, 40); chip, om = chi_table(P)
print("P = %d (< 2^20, = 1 mod 40), omega = %d" % (P, om), flush=True)
out = []
for case in ("23", "31", "47", "31c"):
    if case == "23": comps = [Comp("Fp", 23, sroot(23, 0)), Comp("Fp", 23, sroot(23, 1))]; EC = None; chi5 = None
    elif case in ("31", "47"): comps = [Comp("Fp2", int(case))]; EC = None; chi5 = None
    else:
        N = 31; comps = [Comp("Fp2", N)]
        E31 = {}; cur = 1; acc = 1
        for k in range(30):
            E31[cur] = acc; cur = cur * 3 % N; acc = int(MUL[acc, 2])
        EC = [{(u, v): E31[(u * u + u * v + 2 * v * v) % N] for u in range(N) for v in range(N) if (u, v) != (0, 0)}]
        chi5 = {pow(3, k, N): k % 5 for k in range(30)}
    L = FastLevel(comps, EC, name=case); info = component_info(L); NXL = quad_step_tables(L)
    for kind, eps in allowed_types(info):
        if kind == "ramified": continue
        qmask = sum(1 << k for k, e in enumerate(eps) if e)
        # dense engine over the same P, same characters (chi: 3 -> omega on F_31^x composed with the norm)
        def epsfn(lams, eps=eps):
            r = 1
            if chi5 is not None: r = pow(om, chi5[comps[0].norm(lams[0])], P)
            for k, e in enumerate(eps):
                if e:
                    c = comps[k]; a = lams[k] if c.typ == "Fp" else c.norm(lams[k])
                    if pow(a, (c.p - 1) // 2, c.p) != 1: r = (-r) % P
            return r
        triv = chi5 is None and not any(eps)
        Lp = Level(comps, field=("Fp", P), eps=None if triv else epsfn, group="PGL")
        Kp = Lp.cohomology(); dense = Kp.shape[0] - (1 if Lp.dmpar is not None else 0)
        A1 = FpH1(L, P, chip, nxl=NXL, qmask=qmask, verbose=False)
        A2 = FpH1(L, P, chip, nxl=NXL, qmask=qmask, verbose=False, maxcost_stop=2, dense_max=0, b=8)
        rec = {"case": case, "psi": [kind, list(eps)], "dense_bmf": dense, "sparse_dense_core": A1.dimH1, "sparse_exact": A1.exact,
               "sparse_lanczos_bound": A2.dimH1, "lanczos": A2.lanczos, "core_lanczos": A2.core_shape}
        out.append(rec)
        print("%-4s psi %-9s %s: dense engine %d; sparse (dense core) %d; sparse (Lanczos, core %s) <= %d  %s" % (case, kind, list(eps), dense, A1.dimH1,
              A2.core_shape, A2.dimH1, "ok" if dense == A1.dimH1 == A2.dimH1 else ("bound ok" if dense == A1.dimH1 <= A2.dimH1 else "MISMATCH")), flush=True)
json.dump({"P": P, "records": out}, open("fp_check.json", "w"), indent=1, default=int)
print("done (%.0fs)" % (time.time() - t0))
