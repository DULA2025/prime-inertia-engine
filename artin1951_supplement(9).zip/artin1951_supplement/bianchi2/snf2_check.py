"""Independent check of the psi = 1 lifting test (bockstein.py) at levels with trivial character: the 2-adic
elementary divisors of the integer relator matrix.

With trivial nebentypus the gauge-fixed relator matrix R~ (Fox calculus, signs, tree columns dropped) has integer
entries.  If 2^v_1, ..., 2^v_r are the 2-parts of its elementary divisors and c is the number of columns, then
  dim ker (R~ mod 2)                         = (c - r) + #{v_i >= 1}   (the mod-2 cocycles, Z_gauge),
  dim of the classes that lift modulo 4      = (c - r) + #{v_i >= 2},
  dim of the classes that lift modulo 2^j    = (c - r) + #{v_i >= j},
  rank of ker R~ over Q (characteristic 0)   = c - r.
The valuations are computed by elimination over Z/2^31 with pivots of minimal 2-adic valuation (rows of the pivot
cleared, then the pivot row and column removed), independently of bockstein.py and sparse_big.py.
Usage: python3 snf2_check.py CASE (23, 31).  Author: Dula."""
import sys, json, time
import numpy as np
from bmf import Comp, Level
from mod2_refine import root as sroot
t0 = time.time(); case = sys.argv[1]
comps = [Comp("Fp", 23, sroot(23, 0)), Comp("Fp", 23, sroot(23, 1))] if case == "23" else [Comp("Fp2", int(case))]
P = 1000000007
L = Level(comps, field=("Fp", P), group="PGL")
rows = L.relation_rows(); G = len(L.gens); n = L.n
keep = [u for u in range(G * n) if (L.gens[u // n], u % n) not in L.tree]
col = {u: j for j, u in enumerate(keep)}
M = np.zeros((len(rows), len(keep)), dtype=np.int64)
for i, r in enumerate(rows):
    for u, c in r.items():
        if u in col:
            cc = c if c <= P // 2 else c - P
            M[i, col[u]] += cc
print("case %s: integer matrix %d x %d, entries in [%d, %d] (%.0fs)" % (case, M.shape[0], M.shape[1], M.min(), M.max(), time.time() - t0), flush=True)
MOD = 1 << 31; MASK = MOD - 1
A = M & MASK                      # entries mod 2^31 (two's complement & mask gives the residue)
vals = []                         # 2-adic valuations of the elementary divisors found
level = 0
while A.size and A.any():
    odd = np.argwhere(A & 1)
    if len(odd) == 0:
        A = A >> 1; level += 1
        if level > 25: break
        continue
    # eliminate with odd pivots, one at a time, as long as some remain
    while True:
        odd = np.argwhere(A & 1)
        if len(odd) == 0: break
        i, j = odd[0]
        a = int(A[i, j]); ainv = pow(a, -1, MOD)
        colv = A[:, j].copy(); f = (colv * ainv) & MASK          # multipliers for every row
        f[i] = 0
        A = (A - ((f[:, None] * A[i][None, :]) & MASK)) & MASK
        A = np.delete(np.delete(A, i, axis=0), j, axis=1)
        vals.append(level)
c = M.shape[1]; r = len(vals)
cnt = {v: vals.count(v) for v in sorted(set(vals))}
res = {"case": case, "rows": M.shape[0], "cols": c, "rank": r, "char0_kernel": c - r, "valuations": cnt,
       "dim_mod2_kernel": c - r + sum(1 for v in vals if v >= 1)}
for j in range(2, 6): res["lift_mod_2^%d" % j] = c - r + sum(1 for v in vals if v >= j)
print(json.dumps(res), flush=True)
json.dump(res, open("snf2_check_%s.json" % case, "w"), indent=1)
print("done (%.0fs)" % (time.time() - t0))
