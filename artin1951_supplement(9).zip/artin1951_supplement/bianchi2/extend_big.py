"""Further Hecke operators at a level computed by run_big.py (same cache): the joint eigenvectors saved there are tested
for the eigenvalue of rbar at every split prime q of norm <= QMAX not used by run_big.py (both primes above q) and at
the inert primes q <= QI not dividing the level.

Usage: python3 extend_big.py 1951 [QMAX [QI]]        (defaults 200, 30)
Writes extend_big_<label>.json.  Author: Dula."""
import sys, os, json, time
import numpy as np, cypari2
from sparse_h1 import FastLevel, MUL, INV
from bmf import Comp
from o7 import onorm, oconj
from sparse_big import BigH1
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
t00 = time.time(); args = sys.argv[1:]
assert args[0] == "1951", "only the 1951 target is set up here"
QMAX = int(args[1]) if len(args) > 1 else 200; QI = int(args[2]) if len(args) > 2 else 30
SEED = int(os.environ.get("BIG_SEED", "7"))
N = 1951; label = "N1951"; CACHE = os.environ.get("BIG_CACHE") or ("big_cache_%s" % label)
# ---------------------------------------------------------------- rbar_2 eigenvalues (as run_big.py)
C = {int(k): v for k, v in json.load(open("../questions/classes_1951.json"))["codes"].items()}
g = int(pari("znstar(1951, 1).gen[1]")); dl = {}; t = 1
for k in range(N - 1): dl[t] = k; t = t * g % N
Z = 2; POW = [1]
for _ in range(10): POW.append(int(MUL[POW[-1], Z]))
PHI1 = Z ^ POW[4]; PHI0 = 1 ^ Z ^ POW[4]
def tbar(code):
    if code in ("1", "2A"): return 0
    if code == "3A": return 1
    return PHI1 if code == "5A" else PHI0
def abar(l): return int(MUL[POW[dl[l] % 5], tbar(C[l])])
epsinv = np.zeros(N, dtype=np.uint8)
for a in range(1, N): epsinv[a] = POW[(-2 * dl[a]) % 5]
uu, vv = np.meshgrid(np.arange(N, dtype=np.int64), np.arange(N, dtype=np.int64), indexing="ij")
tab = epsinv[(uu * uu + uu * vv + 2 * vv * vv) % N]; tab[0, 0] = 0
del uu, vv
L = FastLevel([Comp("Fp2", N)], [tab], name=label)
H = BigH1(L, verbose=True, seed=SEED - 6, cache=CACHE)
rng = np.random.default_rng(SEED)
H.quotient_dm(rng)
D = H.d - (1 if H.drop is not None else 0)
joint = {}
for (a, b) in [(6, 9), (9, 6), (6, 6), (9, 9)]:
    f = os.path.join(CACHE, "joint_%d_%d_s%d.npy" % (a, b, SEED))
    if os.path.exists(f): joint[(a, b)] = np.load(f)
print("dim H^1 = %d; joint eigenvectors loaded: %s" % (D, {k: v.shape[0] for k, v in joint.items()}), flush=True)
def find_pi(p):
    for yy in range(1, 200):
        for xx in range(-400, 400):
            if onorm((xx, yy)) == p: return (xx, yy)
used = {11, 23, 29, 37, 43, 53, 67, 71, 79}
ops = []
for q in [int(q) for q in pari("primes([3, %d])" % QMAX)]:
    if q in used or q == 7 or q == N: continue
    kr = int(pari("kronecker(-7, %d)" % q))
    if kr == 1:
        pi = find_pi(q); ops += [("q%d" % q, pi, q, "split"), ("q%dbar" % q, oconj(pi), q, "split")]
    elif kr == -1 and q <= QI and q not in (3, 5, 13):
        ops.append(("(%d)" % q, (q, 0), q, "inert"))
res = {"label": label, "dimH1": D, "seed": SEED, "tests": {}}
for io, (nm, pi, p, typ) in enumerate(ops):
    t1 = time.time()
    fT = os.path.join(CACHE, "hecke_%s_s%d.npy" % (nm, SEED))
    if os.path.exists(fT): T = np.load(fT)
    else:
        T = H.hecke(pi, np.random.default_rng([SEED, 1000 + io]))
        assert T is not None, "Hecke matrix inconsistent at %s" % nm
        np.save(fT, T)
    lam = abar(p) if typ == "split" else int(MUL[abar(p), abar(p)])
    out = {}
    for key, Vj in joint.items():
        ok = []
        for u in Vj:
            Tu = np.zeros(D, dtype=np.uint8)
            for k in np.nonzero(u)[0]: Tu ^= MUL[u[k], T[:, k]]
            ok.append(bool((Tu == MUL[lam, u]).all()))
        out["%d_%d" % key] = ok
    res["tests"][nm] = {"eigenvalue": lam, "eigenvector": out}
    print("  T_%s (eigenvalue %d): %s (%.0fs)" % (nm, lam, out, time.time() - t1), flush=True)
    json.dump(res, open("extend_big_%s.json" % label, "w"), indent=1, default=int)
allok = all(all(all(v) for v in r["eigenvector"].values()) for r in res["tests"].values())
res["all_eigenvector_tests_pass"] = allok; res["seconds"] = round(time.time() - t00)
json.dump(res, open("extend_big_%s.json" % label, "w"), indent=1, default=int)
print("%d further operators; all eigenvector tests pass: %s (%.0fs)" % (len(ops), allok, time.time() - t00))
