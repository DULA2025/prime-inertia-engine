"""Characteristic-0 rank at the levels of run_big.py (the 633 model, level 1951 O_E) by sparse_fp.py, compared with the
number of base changes.

For the nebentypus chi = Teichmueller lift of the level's chibar (psi = 1), or chi*psi with a quadratic psi (QMASK),
dim_{F_P} H^1(Gamma_0(n), F_P(chi psi)) is bounded by the block Lanczos certificate; it bounds the characteristic-0
rank.  Base change: for E = Q(sqrt-7) and level N O_E with N prime to 7, every f in S_2(Gamma_0(N), eps) (eps of order
5, the character of the level) gives one class (oldforms included with their multiplicity), so the characteristic-0
rank is at least dim S_2(Gamma_0(N), eps); if the bound equals it, H^1 in characteristic 0 consists of base changes.
Usage: python3 fp_big.py 1951 | 633.  Environment: FP_B (block, default 16), FP_STOP (Markowitz cost ceiling, default
384), FP_SEED (default 1), FP_BITS (prime size, default 20), QMASK (default 0).  Author: Dula."""
import sys, os, json, time, resource
import numpy as np
t00 = time.time()
target = sys.argv[1]
targs = ["1951"] if target == "1951" else ["633", "1", "10", "odd", "A5"]
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "run_big.py")).read()
head = src[:src.index("# ---------------------------------------------------------------- Bianchi side")]
argv0 = sys.argv; sys.argv = ["run_big.py"] + targs
ns = {"__name__": "run_big_head", "__file__": "run_big.py"}
exec(compile(head, "run_big.py(header)", "exec"), ns)
sys.argv = argv0
label, comps, EC, N = ns["label"], ns["comps"], ns["EC"], ns["N"]
pari = ns["pari"]
from sparse_h1 import FastLevel
from bockstein import quad_step_tables, component_info
from sparse_fp import FpH1, choose_prime, chi_table
B = int(os.environ.get("FP_B", "16")); STOP = int(os.environ.get("FP_STOP", "384")); SEED = int(os.environ.get("FP_SEED", "1"))
BITS = int(os.environ.get("FP_BITS", "20")); QMASK = int(os.environ.get("QMASK", "0")); CHECK = int(os.environ.get("FP_CHECK", "0"))
P = int(os.environ["FP_PRIME"]) if os.environ.get("FP_PRIME") else choose_prime(BITS, 40)
assert P < (1 << 20) and P % 40 == 1
chip, om = chi_table(P)
L = FastLevel(comps, EC, name=label); info = component_info(L)
NXL = quad_step_tables(L) if QMASK else None
CACHE = os.path.join("big_cache_%s" % label, "fp")
print("%s: P = %d, omega = %d, psi mask %d, block %d, Markowitz ceiling %d (%.0fs)" % (label, P, om, QMASK, B, STOP, time.time() - t00), flush=True)
# base change count: dim S_2(Gamma_0(N), eps), eps of order 5 (all Galois conjugates give the same dimension)
pari("Gz = znstar(%d, 1); Lz = chargalois(Gz); iz = select(i -> charorder(Gz, Lz[i]) == 5, [1..#Lz]);" % N)
bc = sorted(set(int(pari("mfdim([%d, 2, [Gz, Lz[iz[%d]]]], 1)" % (N, i))) for i in range(1, int(pari("#iz")) + 1)))
print("dim S_2(Gamma_0(%d), eps), eps of order 5 (each Galois orbit of characters): %s" % (N, bc), flush=True)
# the quadratic twist psi = psi0 o N as a set of primes (split primes need both components); its base-change count from
# bc_counts.py (bc_counts_N.json)
bc_psi = None
if QMASK:
    prs = {}
    for k, c in enumerate(comps):
        prs.setdefault(c.p, []).append((QMASK >> k) & 1)
    if all(len(set(v)) == 1 for v in prs.values()):
        mod0 = 1
        for p, v in prs.items():
            if v[0]: mod0 *= p
        fbc = "bc_counts_%d.json" % N
        if os.path.exists(fbc):
            for t in json.load(open(fbc))["types"]:
                if t["psi0_modulus"] == mod0: bc_psi = t["count"]
    print("psi = (./%s) o N: base changes %s (bc_counts.py)" % (mod0 if bc_psi is not None else "?", bc_psi), flush=True)
else:
    bc_psi = bc[0] if len(bc) == 1 else None
A = FpH1(L, P, chip, nxl=NXL, qmask=QMASK, maxcost_stop=STOP, b=B, seed=SEED, cache=CACHE, check_every=CHECK)
res = {"label": label, "N": N, "P": P, "omega": om, "qmask": QMASK, "block": B, "markowitz_ceiling": STOP, "seed": SEED,
       "core": list(A.core_shape), "free": A.nfree, "kernel_core_bound": A.kercore, "exact": A.exact, "dimZ_bound": A.dimZ,
       "dimH1_bound": A.dimH1, "lanczos": A.lanczos, "base_change_dims_psi1": bc, "base_change_count": bc_psi,
       "equals_base_change": bool(bc_psi is not None and A.dimH1 == bc_psi), "seconds": {k: round(v) for k, v in A.t.items()}}
print("dim H^1(Gamma_0(%d O_E), F_%d(chi psi)) %s %d; base change gives %s" % (N, P, "=" if A.exact else "<=", A.dimH1, bc_psi), flush=True)
res["total_seconds"] = round(time.time() - t00); res["peak_rss_MB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
json.dump(res, open("fp_big_%s_q%d_P%d_s%d.json" % (label, QMASK, P, SEED), "w"), indent=1, default=int)
print("done (%.0fs, peak RSS %d MB)" % (time.time() - t00, res["peak_rss_MB"]))
