"""Arithmetic in O = Z[w], w = (1+sqrt(-7))/2, w^2 = w - 2, and in PSL_2(O); words in the generators
A = (1 1; 0 1), B = (0 1; -1 0), U = (1 w; 0 1) of the presentation (Finis-Grunewald-Tirao, as quoted in
arXiv:2206.01262, Section 4):  PSL_2(O_-7) = < A, B, U | B^2, (BA)^3, A U A^-1 U^-1, (B A U^-1 B U)^2 >.
Author: Dula."""

def omul(a, b):
    (x1, y1), (x2, y2) = a, b
    return (x1 * x2 - 2 * y1 * y2, x1 * y2 + y1 * x2 + y1 * y2)
def oadd(a, b): return (a[0] + b[0], a[1] + b[1])
def osub(a, b): return (a[0] - b[0], a[1] - b[1])
def oneg(a): return (-a[0], -a[1])
def oconj(a): return (a[0] + a[1], -a[1])
def onorm(a): x, y = a; return x * x + x * y + 2 * y * y

def onearest(a, c):
    """q in O with N(a - q c) < N(c) (O is norm-Euclidean)."""
    N = onorm(c); u, v = omul(a, oconj(c))          # a/c = (u + v w)/N
    best = None
    for y in range(v // N - 1, v // N + 3):
        x0 = (2 * u + v - y * N) // (2 * N)
        for x in range(x0 - 1, x0 + 3):
            nr = onorm(osub(a, omul((x, y), c)))
            if best is None or nr < best[0]: best = (nr, (x, y))
    assert best[0] < N, (a, c, best)
    return best[1]

def mmul(M1, M2):
    a1, b1, c1, d1 = M1; a2, b2, c2, d2 = M2
    return (oadd(omul(a1, a2), omul(b1, c2)), oadd(omul(a1, b2), omul(b1, d2)),
            oadd(omul(c1, a2), omul(d1, c2)), oadd(omul(c1, b2), omul(d1, d2)))
def mdet(M): a, b, c, d = M; return osub(omul(a, d), omul(b, c))
def minv(M):
    a, b, c, d = M; assert mdet(M) == (1, 0); return (d, oneg(b), oneg(c), a)
def mneg(M): return tuple(oneg(e) for e in M)
I2 = ((1, 0), (0, 0), (0, 0), (1, 0))
GEN = {"A": ((1, 0), (1, 0), (0, 0), (1, 0)), "B": ((0, 0), (1, 0), (-1, 0), (0, 0)), "U": ((1, 0), (0, 1), (0, 0), (1, 0))}
GEN["J"] = ((-1, 0), (0, 0), (0, 0), (1, 0))          # J = diag(-1, 1), det -1: PGL_2(O) = PSL_2(O) x| <J>
def minv_gl(M):
    a, b, c, d = M; dt = mdet(M); assert dt in ((1, 0), (-1, 0))
    s = 1 if dt == (1, 0) else -1
    return tuple((s * e[0], s * e[1]) for e in (d, oneg(b), oneg(c), a))
GINV = {g: minv_gl(M) for g, M in GEN.items()}
RELATORS = {"B^2": [("B", 1), ("B", 1)],
            "(BA)^3": [("B", 1), ("A", 1)] * 3,
            "[A,U]": [("A", 1), ("U", 1), ("A", -1), ("U", -1)],
            "(BAU^-1BU)^2": [("B", 1), ("A", 1), ("U", -1), ("B", 1), ("U", 1)] * 2}

RELATORS_PGL = dict(RELATORS)
RELATORS_PGL.update({"J^2": [("J", 1), ("J", 1)], "(JA)^2": [("J", 1), ("A", 1)] * 2,
                     "(JB)^2": [("J", 1), ("B", 1)] * 2, "(JU)^2": [("J", 1), ("U", 1)] * 2})

def word_matrix(toks):
    M = I2
    for g, e in toks: M = mmul(M, GEN[g] if e == 1 else GINV[g])
    return M
def same_psl(M1, M2): return M1 == M2 or M1 == mneg(M2)

def trans_tokens(q):
    x, y = q
    return [("A", 1 if x > 0 else -1)] * abs(x) + [("U", 1 if y > 0 else -1)] * abs(y)

def decompose(M):
    """Tokens (gen, +-1) whose product equals M in PGL_2(O) (J used only if det M = -1): Euclidean algorithm."""
    toks = []; g = M
    if mdet(M) == (-1, 0):
        toks = [("J", 1)]; g = mmul(GEN["J"], M)             # M = J (J M), J^-1 = J
    assert mdet(g) == (1, 0)
    while g[2] != (0, 0):
        a, b, c, d = g
        q = onearest(a, c)
        toks += trans_tokens(q) + [("B", 1)]            # g = T_q B^-1 g',  B^-1 = B in PSL_2
        ap = osub(a, omul(q, c)); bp = osub(b, omul(q, d))
        g = (c, d, oneg(ap), oneg(bp))                  # g' = B T_-q g
    a, b, c, d = g
    assert a in ((1, 0), (-1, 0)) and d == a, g
    toks += trans_tokens(b if a == (1, 0) else oneg(b))
    return toks
