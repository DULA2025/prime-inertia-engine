"""H^1(Gamma_0(n), V_eps) for Gamma = PSL_2(O), O = Z[(1+sqrt-7)/2], via Shapiro's lemma: H^1(Gamma, M) with
M = {F on primitive rows (c, d) mod n : F(l c, l d) = eps(l) F(c, d)}, (g F)(v) = F(v g).  Cocycles are computed from
the presentation in o7.py (Fox calculus on the coset graph P^1(O/n)), gauge-fixed to vanish on a spanning tree.
Hecke operators: (T psi)(h) = sum_i eps(d_{alpha_i})^-1 psi(h_i), alpha_i h = h_i alpha_{s(i)}, on the Gamma_0-cocycle
psi(h) = f(h)(0,1), read back on the Schreier generators h_{x,g} (psi(h_{x,g}) = eps(lambda_x) f_g(x)).
Fields: 'F2' (trivial eps only), 'F16' (uint8, encoding of gf.py), ('Fp', P).
Author: Dula."""
import numpy as np, collections
from o7 import *
import gf

# ---------------- residue components ----------------
class Comp:
    """O/q for a prime q: 'Fp' (w -> r mod p) or 'Fp2' (O/(p) = F_p[t]/(t^2 - t + 2), w -> t)."""
    def __init__(self, typ, p, r=None):
        self.typ, self.p, self.r = typ, p, r
        self.size = p + 1 if typ == "Fp" else p * p + 1
        if typ == "Fp": assert (r * r - r + 2) % p == 0
    def red(self, a):
        x, y = a; p = self.p
        return (x + y * self.r) % p if self.typ == "Fp" else (x % p, y % p)
    def mul(self, a, b):
        p = self.p
        if self.typ == "Fp": return (a * b) % p
        (u1, v1), (u2, v2) = a, b
        return ((u1 * u2 - 2 * v1 * v2) % p, (u1 * v2 + v1 * u2 + v1 * v2) % p)
    def add(self, a, b):
        p = self.p
        return (a + b) % p if self.typ == "Fp" else ((a[0] + b[0]) % p, (a[1] + b[1]) % p)
    def iszero(self, a): return a == 0 if self.typ == "Fp" else a == (0, 0)
    def inv(self, a):
        p = self.p
        if self.typ == "Fp": return pow(a, p - 2, p)
        u, v = a; N = (u * u + u * v + 2 * v * v) % p; iN = pow(N, p - 2, p)
        return (((u + v) * iN) % p, (-v * iN) % p)
    def norm(self, a):                       # to F_p
        if self.typ == "Fp": return a
        u, v = a; return (u * u + u * v + 2 * v * v) % self.p
    def zero(self): return 0 if self.typ == "Fp" else (0, 0)
    def one(self): return 1 if self.typ == "Fp" else (1, 0)
    def elt_index(self, t): return t if self.typ == "Fp" else t[0] + self.p * t[1]
    def index_elt(self, i): return i if self.typ == "Fp" else (i % self.p, i // self.p)
    def normalize(self, c, d):
        """(c, d) = lam * rep; returns (index, lam)."""
        if not self.iszero(c):
            return self.elt_index(self.mul(d, self.inv(c))), c
        return self.size - 1, d
    def rep(self, i):
        if i == self.size - 1: return (self.zero(), self.one())
        return (self.one(), self.index_elt(i))

class Level:
    def __init__(self, comps, field="F2", eps=None, name="", group="PSL"):
        """comps: list of Comp; eps: function (tuple of component scalars) -> field element, or None (trivial);
        group: 'PSL' (generators A, B, U) or 'PGL' (A, B, U, J)."""
        self.comps, self.field, self.eps_fn, self.name, self.group = comps, field, eps, name, group
        self.gens = "ABU" if group == "PSL" else "ABUJ"
        self.relators = RELATORS if group == "PSL" else RELATORS_PGL
        self.sizes = [c.size for c in comps]; self.n = int(np.prod(self.sizes))
        self.strides = [int(np.prod(self.sizes[:i])) for i in range(len(comps))]
        self.root = sum((s - 1) * st for s, st in zip(self.sizes, self.strides))
        self.one = 1
        self.build_tables()

    # field helpers
    def fmul(self, a, b):
        if self.field == "F16": return int(gf.MUL16[a, b])
        if self.field == "F2": return a & b
        return (a * b) % self.field[1]
    def finv(self, a):
        if self.field == "F16": return int(gf.INV16[a])
        if self.field == "F2": assert a == 1; return 1
        return pow(a, self.field[1] - 2, self.field[1])
    def fneg(self, a):
        return a if self.field in ("F16", "F2") else (-a) % self.field[1]
    def fadd(self, a, b):
        if self.field in ("F16", "F2"): return a ^ b
        return (a + b) % self.field[1]
    def eps(self, lam):
        return 1 if self.eps_fn is None else self.eps_fn(lam)

    def red_matrix(self, M):
        return [tuple(c.red(e) for e in M) for c in self.comps]
    def act_point(self, i, Mred):
        """point index i, reduced matrix -> (index', eps(lam')) with rep(i) * M = lam' * rep(index')."""
        idx = 0; lam = []
        for k, c in enumerate(self.comps):
            ik = (i // self.strides[k]) % self.sizes[k]
            cc, dd = c.rep(ik); a, b, cm, dm = Mred[k]
            nc = c.add(c.mul(cc, a), c.mul(dd, cm)); nd = c.add(c.mul(cc, b), c.mul(dd, dm))
            j, l = c.normalize(nc, nd); idx += j * self.strides[k]; lam.append(l)
        return idx, self.eps(tuple(lam))

    def build_tables(self):
        self.nxt = {}; self.nxe = {}
        mats = {g: GEN[g] for g in self.gens}; mats.update({g.lower(): GINV[g] for g in self.gens})
        for s, M in mats.items():
            Mr = self.red_matrix(M); ni = np.empty(self.n, dtype=np.int64); ne = [0] * self.n
            for i in range(self.n):
                j, e = self.act_point(i, Mr); ni[i] = j; ne[i] = e
            self.nxt[s] = ni; self.nxe[s] = ne
        # spanning tree (BFS over forward edges A, B, U), path scalars eps(lambda_x), parent pointers
        self.tree = set(); self.lam = [None] * self.n; self.parent = [None] * self.n
        self.lam[self.root] = 1; dq = collections.deque([self.root])
        while dq:
            x = dq.popleft()
            for g in self.gens:
                y = int(self.nxt[g][x])
                if self.lam[y] is None:
                    self.lam[y] = self.fmul(self.lam[x], self.nxe[g][x]); self.parent[y] = (x, g)
                    self.tree.add((g, x)); dq.append(y)
        assert all(l is not None for l in self.lam), "coset graph not connected"

    def unk(self, g, x): return self.gens.index(g) * self.n + x

    def walk(self, toks, start=None, w=None):
        """Evaluation functional of the word toks at the point start (default root): dict unknown -> coef."""
        cur = self.root if start is None else start; w = 1 if w is None else w; out = collections.defaultdict(int)
        for g, e in toks:
            if e == 1:
                u = self.unk(g, cur); out[u] = self.fadd(out[u], w)
                w = self.fmul(w, self.nxe[g][cur]); cur = int(self.nxt[g][cur])
            else:
                s = g.lower(); w = self.fmul(w, self.nxe[s][cur]); cur = int(self.nxt[s][cur])
                u = self.unk(g, cur); out[u] = self.fadd(out[u], self.fneg(w))
        return out, cur, w

    def relation_rows(self):
        rows = []
        for name, r in self.relators.items():
            for x in range(self.n):
                d, cur, w = self.walk(r, start=x)
                assert cur == x
                rows.append({u: c for u, c in d.items() if c != 0})
        return rows

    def cohomology(self):
        """Basis of gauge-fixed cocycles representing H^1 (rows, over all 3n unknowns), plus delta m_par if eps != 1."""
        n = self.n; rows = self.relation_rows(); G = len(self.gens)
        keep = [u for u in range(G * n) if (self.gens[u // n], u % n) not in self.tree]
        col = {u: j for j, u in enumerate(keep)}; C = len(keep); R = len(rows)
        if self.field == "F2":
            D = np.zeros((R, C), dtype=np.uint8)
            for i, row in enumerate(rows):
                for u, c in row.items():
                    if u in col: D[i, col[u]] ^= (c & 1)
            P = gf.pack2(D); piv = list(gf.rref2(P, C)); A = gf.unpack2(P[:len(piv)], C)
        elif self.field == "F16":
            A = np.zeros((R, C), dtype=np.uint8)
            for i, row in enumerate(rows):
                for u, c in row.items():
                    if u in col: A[i, col[u]] ^= c
            piv = list(gf.rref16(A, gf.MUL16, gf.INV16)); A = A[:len(piv)]
        else:
            Pm = self.field[1]; A = np.zeros((R, C), dtype=np.int64)
            for i, row in enumerate(rows):
                for u, c in row.items():
                    if u in col: A[i, col[u]] = (A[i, col[u]] + c) % Pm
            piv = list(gf.rrefp(A, Pm)); A = A[:len(piv)]
        pset = set(piv); free = [c for c in range(C) if c not in pset]
        K = np.zeros((len(free), G * n), dtype=np.int64)
        for k, fc in enumerate(free):
            K[k, keep[fc]] = 1
            for r, pc in enumerate(piv):
                v = int(A[r, fc])
                K[k, keep[pc]] = v if self.field in ("F2", "F16") else (-v) % self.field[1]
        self.Z = K
        self.rank = len(piv)
        # delta m_par (only non-zero for non-trivial eps)
        m = [None] * n; m[self.root] = 1
        order = sorted(range(n), key=lambda x: self.depth(x))
        for y in order:
            if y == self.root: continue
            x, g = self.parent[y]
            # (delta m)(g)(x) = e * m(y) - m(x) = 0  with  rep(x) g = lam' rep(y), e = eps(lam')
            m[y] = self.fmul(m[x], self.finv(self.nxe[g][x]))
        dm = np.zeros(G * n, dtype=np.int64)
        for g in self.gens:
            for x in range(n):
                v = self.fadd(self.fmul(self.nxe[g][x], m[int(self.nxt[g][x])]), self.fneg(m[x]))
                dm[self.unk(g, x)] = v
        self.dmpar = dm if dm.any() else None
        return K

    def depth(self, x):
        d = 0
        while x != self.root: x = self.parent[x][0]; d += 1
        return d

    def path_word(self, x):
        toks = []
        while x != self.root:
            p, g = self.parent[x]; toks.append((g, 1)); x = p
        return toks[::-1]

    def schreier(self, g, x):
        """h_{x,g} = W_x g W_{x g}^-1 in Gamma_0(n) as a matrix (W_x the tree word from the root)."""
        y = int(self.nxt[g][x])
        return mmul(mmul(word_matrix(self.path_word(x)), GEN[g]), minv_gl(word_matrix(self.path_word(y))))

    def in_gamma0(self, M):
        return all(c.iszero(c.red(M[2])) for c in self.comps)

    def d_scalar(self, M):
        return tuple(c.red(M[3]) for c in self.comps)
