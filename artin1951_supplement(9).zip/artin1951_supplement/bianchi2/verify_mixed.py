"""Independent checks of the mixed (T_v, T_vbar) = (x, y) class in the model case (level 23 O_E, PGL_2, mod 2):
(1) recompute H^1 over F16 (rref16) instead of packed F2 and compare dimensions;
(2) extract the joint eigenvector with (T_v, T_vbar) = (x, y) inside the rbar-part and test T_q c = tr rbar(Frob_q) c
    at primes not used to define the rbar-part.  Author: Dula."""
import sys, json, time
import numpy as np
from bmf import *
from hecke import *
import gf
from mod2_refine import root, gen_eigenspace, restrict
import cypari2; pari = cypari2.Pari()
pari("mf = mfinit([23, 2], 0); f = mfeigenbasis(mf)[1]; co = mfcoefs(f, 400);")
def trace(p):
    a = pari("lift(co[%d + 1])" % p); c1 = int(pari("polcoef(%s, 1, y)" % a)) % 2; assert c1 == 0
    return int(pari("polcoef(%s, 0, y)" % a)) % 2
comps = [Comp("Fp", 23, root(23, 0)), Comp("Fp", 23, root(23, 1))]
L2 = Level(comps, field="F2", group="PGL"); K2 = L2.cohomology()
L16 = Level(comps, field="F16", group="PGL"); K16 = L16.cohomology()
print("dim H^1 over F2:", K2.shape[0], " over F16 (independent elimination):", K16.shape[0])
L, K = L16, K16; D = K.shape[0]
def find_pi(p):
    for y in range(1, 30):
        for x in range(-60, 60):
            if onorm((x, y)) == p: return (x, y)
base = [("(3)", (3, 0), 3, "inert"), ("(5)", (5, 0), 5, "inert"), ("(sqrt-7)", (-1, 2), 7, "ram"), ("q11", (1, 2), 11, "split"), ("q11bar", (3, -2), 11, "split")]
test = [("q29", find_pi(29), 29, "split"), ("q29bar", None, 29, "split"), ("q37", find_pi(37), 37, "split"), ("q37bar", None, 37, "split"),
        ("q43", find_pi(43), 43, "split"), ("q43bar", None, 43, "split"), ("q53", find_pi(53), 53, "split"), ("q53bar", None, 53, "split"), ("(13)", (13, 0), 13, "inert")]
for i, (nm, pi, p, t) in enumerate(test):
    if pi is None: test[i] = (nm, oconj(test[i - 1][1]), p, t)
piv = None; Ts = {}
for nm, pi, p, typ in [("v", (0, 1), 2, ""), ("vbar", (1, -1), 2, "")] + base + test:
    T, ok, piv = hecke_matrix(L, K, pi, pivots=piv); assert ok; Ts[nm] = (T.astype(np.uint8), p, typ)
def ev(nm):
    T, p, typ = Ts[nm]; t = trace(p); return t if typ != "inert" else int(gf.MUL16[t, t])
V = gen_eigenspace([Ts[k][0] for k, *_ in base], [ev(k) for k, *_ in base], D)
print("rbar-part from 5 operators only: dim", V.shape[0])
x, y = 12, 13
Rv = restrict(Ts["v"][0], V); Rvb = restrict(Ts["vbar"][0], V)
for (a, b) in [(x, y), (y, x), (x, x), (y, y)]:
    Va = gen_eigenspace([Rv, Rvb], [a, b], V.shape[0])          # coordinates w.r.t. rows of V
    W = gf.matmul16(Va, V) if Va.shape[0] else Va               # vectors in H^1 coordinates
    line = "(T_v, T_vbar) = (%d, %d): generalized eigenspace dim %d" % (a, b, Va.shape[0])
    if W.shape[0] == 1:
        c = W[0]
        res = []
        for nm, pi, p, typ in test:
            Tc = gf.matmul16(Ts[nm][0], c[:, None])[:, 0]
            lam = ev(nm); ok = (Tc == gf.MUL16[lam, c]).all(); res.append("%s:%s" % (nm, "ok" if ok else "FAIL"))
        line += "; eigenvector test at unused primes: " + " ".join(res)
    print(line)
