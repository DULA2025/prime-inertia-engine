"""Bitsliced dense row reduction over GF(16) (encoding of gf.py): a matrix is stored as four bit-planes (bit k of
every entry), 64 columns per word.  For each pivot the 15 multiples of the pivot row are precomputed, so eliminating
one row costs 4 XORs per word.  Returns the same reduced row echelon form as gf.rref16.  Author: Dula."""
import numpy as np, numba as nb
import gf

MUL = gf.MUL16; INV = gf.INV16

def to_planes(A):
    m, C = A.shape; W = (C + 63) // 64
    P = np.zeros((4, m, W), dtype=np.uint64)
    for k in range(4):
        bits = ((A >> k) & 1).astype(np.uint8)
        pad = np.zeros((m, W * 64), dtype=np.uint8); pad[:, :C] = bits
        # little-endian bit order inside each word: column c -> word c // 64, bit c % 64
        P[k] = np.packbits(pad.reshape(m, W, 64)[:, :, ::-1], axis=2, bitorder="big").view(">u8").astype(np.uint64).reshape(m, W)
    return P

def from_planes(P, C):
    _, m, W = P.shape
    A = np.zeros((m, C), dtype=np.uint8)
    for k in range(4):
        bits = np.unpackbits(P[k].astype(">u8").view(np.uint8).reshape(m, W, 8), axis=2, bitorder="big").reshape(m, W, 64)[:, :, ::-1]
        A |= (bits.reshape(m, W * 64)[:, :C] << k).astype(np.uint8)
    return A

def _mulmasks():
    """M[s, k] = bitmask of input planes l contributing to output plane k under multiplication by s."""
    M = np.zeros((16, 4), dtype=np.int64)
    for s in range(16):
        for l in range(4):
            col = int(MUL[s, 1 << l])
            for k in range(4):
                if (col >> k) & 1: M[s, k] |= 1 << l
    return M
MASKS = _mulmasks()

@nb.njit(cache=True)
def _entry(P, i, c):
    w = c >> 6; sh = np.uint64(c & 63)
    e = 0
    for k in range(4):
        e |= int((P[k, i, w] >> sh) & np.uint64(1)) << k
    return e

@nb.njit(cache=True)
def rref_planes(P, C, inv, masks):
    """In-place RREF of the bit-planes P (4, m, W); returns the pivot columns."""
    _, m, W = P.shape
    piv = np.empty(min(m, C), dtype=np.int64); r = 0
    T = np.zeros((16, 4, W), dtype=np.uint64)
    tmp = np.zeros((4, W), dtype=np.uint64)
    for c in range(C):
        if r >= m: break
        w = c >> 6; bit = np.uint64(1) << np.uint64(c & 63)
        p = -1
        for i in range(r, m):
            if (P[0, i, w] | P[1, i, w] | P[2, i, w] | P[3, i, w]) & bit:
                p = i; break
        if p < 0: continue
        if p != r:
            for k in range(4):
                for j in range(W):
                    t = P[k, r, j]; P[k, r, j] = P[k, p, j]; P[k, p, j] = t
        # scale the pivot row to have entry 1
        s = inv[_entry(P, r, c)]
        if s != 1:
            for k in range(4):
                for j in range(W): tmp[k, j] = 0
                mk = masks[s, k]
                for l in range(4):
                    if (mk >> l) & 1:
                        for j in range(W): tmp[k, j] ^= P[l, r, j]
            for k in range(4):
                for j in range(W): P[k, r, j] = tmp[k, j]
        # multiples f * (pivot row), f = 1..15
        for f in range(1, 16):
            for k in range(4):
                mk = masks[f, k]
                for j in range(W): T[f, k, j] = 0
                for l in range(4):
                    if (mk >> l) & 1:
                        for j in range(W): T[f, k, j] ^= P[l, r, j]
        for i in range(m):
            if i == r: continue
            if not ((P[0, i, w] | P[1, i, w] | P[2, i, w] | P[3, i, w]) & bit): continue
            f = _entry(P, i, c)
            for k in range(4):
                for j in range(W): P[k, i, j] ^= T[f, k, j]
        piv[r] = c; r += 1
    return piv[:r]

def kernel_bits(A):
    """Basis (rows, uint8) of {x : A x = 0} over GF(16), via the bitsliced RREF."""
    m, C = A.shape
    P = to_planes(A)
    piv = list(rref_planes(P, C, INV, MASKS))
    R = from_planes(P[:, :len(piv), :], C)
    pset = set(piv); free = [c for c in range(C) if c not in pset]
    K = np.zeros((len(free), C), dtype=np.uint8)
    for k, fc in enumerate(free):
        K[k, fc] = 1
        for r, pc in enumerate(piv): K[k, pc] = R[r, fc]
    return K, piv
