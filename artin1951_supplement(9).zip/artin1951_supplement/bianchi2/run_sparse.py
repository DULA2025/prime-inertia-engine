"""Mod-2 Bianchi classes at large levels with the sparse engine (sparse_h1.py): H^1(Gamma_0(N O_E), F16(eps)) for
PGL_2(O_E), E = Q(sqrt-7), the rbar-part for the mod-2 representation of a classical newform, and the pairs
(T_v, T_vbar) on it.

Usage:
  python3 run_sparse.py N ORBIT [PRIME]           weight-2 newform of level N, trivial character (as run_model.py)
  python3 run_sparse.py N k CHI_ORDER odd|even A5  the newform with projective image A5 of weight k, level N, with a
                                                   character of the given order and parity (weight one: mfgaloistype)
Traces tr rbar(Frob_p) = a_p mod P and eps(p) mod P are mapped into F16 (encoding of gf.py) by one embedding of the
residue field.  With a character, the level carries the nebentypus eps^-1 o N (engine convention found with
control_A5_31.py: then T_q has eigenvalue a_q).  Author: Dula."""
import sys, json, time, resource
import numpy as np, cypari2
from sparse_h1 import *
from mod2_refine import root as sroot
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
t00 = time.time()
args = sys.argv[1:]
NB = 400
def ev16(cs, th):
    r = 0; pw = 1
    for c in cs:
        if c: r ^= pw
        pw = int(MUL[pw, th])
    return r
# ---------------------------------------------------------------- the form and its reduction
if len(args) <= 3:
    N = int(args[0]); orb = int(args[1]); kP = int(args[2]) if len(args) > 2 else None; k = 2; has_char = False
    pari("mf = mfinit([%d, 2], 0); B = mfeigenbasis(mf); P = mffields(mf)[%d]; co = mfcoefs(B[%d], %d);" % (N, orb, orb, NB))
    pari("Pabs = if (poldegree(P) == 0, 'y, P);")
    pari("toabs(c) = Mod(liftall(c), Pabs);")
    pari("epsv(p) = 1;")
    label = "N%d_orbit%d" % (N, orb)
else:
    N = int(args[0]); k = int(args[1]); o = int(args[2]); par = args[3]; has_char = True; kP = None
    sel = args[4] if len(args) > 4 else "A5"
    pari("G = znstar(%d, 1); L = chargalois(G); IX = select(i -> charorder(G, L[i]) == %d && zncharisodd(G, L[i]) == %d, [1..#L]);" % (N, o, 1 if par == "odd" else 0))
    found = None
    for ii in range(1, int(pari("#IX")) + 1):
        pari("mf = mfinit([%d, %d, [G, L[IX[%d]]]], 0);" % (N, k, ii))
        if int(pari("mfdim(mf)")) == 0: continue
        pari("B = mfeigenbasis(mf);")
        if sel == "A5":
            pari("ty = mfgaloistype(mf);")
            for j in range(1, int(pari("#B")) + 1):
                if int(pari("ty[%d]" % j)) == -60: found = (ii, j); break
        else:
            found = (ii, int(sel))
        if found: break
    assert found, "no form found"
    ii, j = found
    pari("f = B[%d]; co = mfcoefs(f, %d); cm = mfparams(mf)[3]; Gm = znstar(cm.mod, 1); chm = znconreychar(Gm, cm); "
         "cyc = mfparams(mf)[5]; om = charorder(Gm, chm); P = mffields(mf)[%d];" % (j, NB, j))
    pari("R = rnfequation(cyc, P, 1); Pabs = R[1]; A = lift(R[2]); kk = R[3];")
    pari("toabs(c) = Mod(subst(subst(liftall(c), 'y, 'y - kk * A), 't, A), Pabs);")
    pari("epsv(p) = Mod(t^(chareval(Gm, chm, p) * om), cyc);")
    label = "N%d_k%d_o%d_%s" % (N, k, o, sel)
pari("nf = nfinit([Pabs, [2]]); dec = idealprimedec(nf, 2);")
cands = [kk_ for kk_ in range(1, int(pari("#dec")) + 1) if 4 % int(pari("dec[%d].f" % kk_)) == 0 and int(pari("dec[%d].f" % kk_)) > 1]
kP = kP if kP is not None else cands[0]
pari("modP = nfmodprinit(nf, dec[%d]);" % kP)
pari("rdx(x) = nfmodpr(nf, toabs(x), modP);")
pari("g0 = rdx(co[3]); gen = ffgen(g0); m = gen.mod;")
mc = [int(c) % 2 for c in pari("Vecrev(lift(m))")]
th = [x for x in range(16) if ev16(mc, x) == 0][0]
def to16(expr):
    if int(pari("type(%s) == \"t_FFELT\"" % expr)):
        return ev16([int(c) % 2 for c in pari("my(z = %s); Vecrev(lift(z.pol))" % expr)], th)
    return ev16([int(pari("lift(%s)" % expr)) % 2], th)
PRS = [int(q) for q in pari("primes([3, 200])") if N % int(q)]
AP = {p: to16("rdx(co[%d + 1])" % p) for p in PRS}
EP = {p: to16("rdx(epsv(%d))" % p) for p in PRS + [2]} if has_char else {p: 1 for p in PRS + [2]}
a2 = to16("rdx(co[3])")
if k == 1:          # weight one: a_2 = x + y, x y = eps(2)
    xy = [x for x in range(1, 16) if MUL[x, x] ^ MUL[a2, x] ^ EP[2] == 0]
    x, y = (xy[0], xy[1]) if len(xy) == 2 else (xy[0], xy[0])
else:               # weight two: a_2 = x (unit root), y = eps(2) / x
    x = a2; y = int(MUL[EP[2], INV[a2]])
print("%s: P%d, residue degree %d, Frob_2 eigenvalues (x, y) = (%d, %d) in F16; eps %s" % (label, kP, len(mc) - 1, x, y, "trivial" if not has_char else "of order %d" % int(pari("om"))), flush=True)
# ---------------------------------------------------------------- the level over E
comps = []; eps_chars = []
fa = [(int(q), int(e)) for q, e in zip(pari("factor(%d)[,1]~" % N), pari("factor(%d)[,2]~" % N))]
# nebentypus eps^-1 o N, factor by factor: for q split, both components see eps^-1 on F_q^x; for q inert, eps^-1 o N_{F_q^2/F_q}
def eps_inv_table(q):
    """dict a -> eps^-1(a) (F16 code) for a in F_q^x, through a primitive root."""
    g = int(pari("znprimroot(%d)" % q).lift())
    # the q-part of eps at g: eps(g') with g' = g mod q, g' = 1 mod N/q
    gq = int(pari("lift(chinese(Mod(%d, %d), Mod(1, %d)))" % (g, q, N // q)))
    eg = int(INV[to16("rdx(epsv(%d))" % gq)])
    tab = {}; cur = 1; acc = 1
    for _ in range(q - 1):
        tab[cur] = acc; cur = cur * g % q; acc = int(MUL[acc, eg])
    return tab
for q, e in fa:
    assert e == 1, "squarefree levels only"
    kr = int(pari("kronecker(-7, %d)" % q))
    if q == 7:
        c = Comp("Fp", 7, 4); comps.append(c)
        eps_chars.append(eps_inv_table(7) if has_char else None)
    elif kr == 1:
        for w in (0, 1):
            c = Comp("Fp", q, sroot(q, w)); comps.append(c)
            eps_chars.append(eps_inv_table(q) if has_char else None)
    else:
        c = Comp("Fp2", q); comps.append(c)
        if has_char:
            tq = eps_inv_table(q)
            eps_chars.append({(u, v): tq[(u * u + u * v + 2 * v * v) % q] for u in range(q) for v in range(q) if (u, v) != (0, 0)})
        else:
            eps_chars.append(None)
if has_char:
    for i, c in enumerate(comps):
        if eps_chars[i] is None:
            eps_chars[i] = {a: 1 for a in range(1, c.p)} if c.typ == "Fp" else {(u, v): 1 for u in range(c.p) for v in range(c.p) if (u, v) != (0, 0)}
    EC = eps_chars
else:
    EC = None
t0 = time.time()
L = FastLevel(comps, EC, name=label)
print("level %s O_E: components %s, index n = %d (%.1fs)" % (N, [(c.typ, c.p) for c in comps], L.n, time.time() - t0), flush=True)
import os
SEED = int(os.environ.get("SPARSE_SEED", "7"))           # seeds of the core compression, pivots and check columns
SOLVER = os.environ.get("SPARSE_SOLVER", "dense")         # core solver: dense (bitsliced elimination) or lanczos
LW = int(os.environ.get("SPARSE_LW", "4"))                  # initial Lanczos block width / 64
red = Reduction(L, fill=8.0, verbose=True, seed=SEED - 6, solver=SOLVER, lanczos_w=LW)
K = red.kernel(verbose=True)
rng = np.random.default_rng(SEED)
dm = delta_mpar(L)
if dm is not None:
    K = quotient_by(K, dm, rng)
D = K.shape[0]
print("dim H^1(Gamma_0, F16(eps)) [PGL] = %d%s (%.1fs)" % (D, " (after the quotient by delta m_par)" if dm is not None else "", time.time() - t00), flush=True)
pivots = select_pivots(K, ~L.TREE, rng)
KT = np.ascontiguousarray(K.T)
def find_pi(p):
    for yy in range(1, 60):
        for xx in range(-120, 120):
            if onorm((xx, yy)) == p: return (xx, yy)
ops = [("v", (0, 1), 2, "split"), ("vbar", (1, -1), 2, "split")]
for q in (3, 5, 13):
    if N % q and int(pari("kronecker(-7, %d)" % q)) == -1: ops.append(("(%d)" % q, (q, 0), q, "inert"))
if N % 7: ops.append(("(sqrt-7)", (-1, 2), 7, "ram"))
for q in (11, 23, 29, 37, 43, 53, 67, 71, 79):
    if N % q: pi = find_pi(q); ops += [("q%d" % q, pi, q, "split"), ("q%dbar" % q, oconj(pi), q, "split")]
Ts = {}
for nm, pi, p, typ in ops:
    t1 = time.time()
    T = hecke_matrix_sparse(L, K, pi, pivots, rng, dm=dm, KT=KT)
    assert T is not None, "Hecke matrix inconsistent at %s" % nm
    Ts[nm] = (T, p, typ)
    print("  T_%s (%.0fs)" % (nm, time.time() - t1), flush=True)
comm = all((matmul16(Ts[a][0], Ts[b][0], MUL) == matmul16(Ts[b][0], Ts[a][0], MUL)).all() for a in Ts for b in Ts)
print("Hecke operators: %d, commute: %s (%.0fs)" % (len(Ts), comm, time.time() - t00), flush=True)
def evq(nm):
    T, p, typ = Ts[nm]; a = AP[p]
    return a if typ != "inert" else int(MUL[a, a])
names = [nm for nm in Ts if nm not in ("v", "vbar")]; first = names[:6]; rest = names[6:]
V = gen_eigenspace([Ts[nm][0] for nm in first], [evq(nm) for nm in first], D)
res = {"label": label, "N": N, "n": L.n, "dimH1": D, "x": x, "y": y, "commute": bool(comm), "rbar_dim": int(V.shape[0]),
       "reduction": {"core_cols": len(red.core_cols), "records": len(red.records), "seconds": round(red.t)}}
print("rbar-part (from %s): dim %d" % (", ".join(first), V.shape[0]), flush=True)
if V.shape[0]:
    def restrict(T, V):
        TV = matmul16(np.ascontiguousarray(V), np.ascontiguousarray(T.T), MUL)            # rows: (T v_i)^T = v_i T^T
        X = np.concatenate([V.T, TV.T], axis=1).astype(np.uint8); d = V.shape[0]
        piv = list(gf.rref16(X, MUL, INV)); assert all(p < d for p in piv), "not stable"
        C = np.zeros((d, d), dtype=np.uint8)
        for r, p in enumerate(piv): C[p] = X[r, d:]
        return C
    Rv = restrict(Ts["v"][0], V); Rvb = restrict(Ts["vbar"][0], V)
    pairs = []
    for a in range(16):
        Va = gen_eigenspace([Rv], [a], V.shape[0])
        if Va.shape[0] == 0: continue
        Rb = restrict(Rvb, Va)
        for b in range(16):
            Vb = gen_eigenspace([Rb], [b], Va.shape[0])
            if Vb.shape[0]: pairs.append((a, b, int(Vb.shape[0])))
    res["pairs"] = pairs
    print("(T_v, T_vbar) generalized eigenvalue pairs on the rbar-part:", pairs, " [(x, y) = (%d, %d)]" % (x, y), flush=True)
    for (a, b) in [(x, y), (y, x), (x, x), (y, y)]:
        Va = gen_eigenspace([Rv, Rvb], [a, b], V.shape[0]); W = matmul16(np.ascontiguousarray(Va), np.ascontiguousarray(V), MUL) if Va.shape[0] else Va
        # true joint eigenvectors inside W, with the rbar eigenvalues at every operator
        ev_dim = 0
        if W.shape[0]:
            blocks = []
            for nm, lam in [("v", a), ("vbar", b)] + [(nm, evq(nm)) for nm in first + rest]:
                S = Ts[nm][0] ^ (MUL[lam, 1] * np.eye(D, dtype=np.uint8))
                blocks.append(matmul16(np.ascontiguousarray(W), np.ascontiguousarray(S.T), MUL))
            ev_dim = gf.kernel16(np.concatenate(blocks, axis=1).T).shape[0]
        print("  (T_v, T_vbar) = (%d, %d): generalized eigenspace dim %d; joint eigenvectors with the rbar eigenvalues at all %d operators: %d"
              % (a, b, Va.shape[0], 2 + len(first) + len(rest), ev_dim), flush=True)
        res["pair_%d_%d" % (a, b)] = {"dim": int(Va.shape[0]), "joint_eigenvectors": int(ev_dim), "operators": ["v", "vbar"] + first + rest}
res["seconds"] = round(time.time() - t00); res["peak_rss_MB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
res["seed"] = SEED; res["solver"] = SOLVER
if SOLVER == "lanczos": res["lanczos_runs"] = red.lanczos_runs
json.dump(res, open("sparse_%s%s%s.json" % (label, "" if SEED == 7 else "_seed%d" % SEED, "" if SOLVER == "dense" else "_" + SOLVER), "w"), indent=1, default=int)
print("done (%.0fs, peak RSS %d MB)" % (time.time() - t00, res["peak_rss_MB"]))
