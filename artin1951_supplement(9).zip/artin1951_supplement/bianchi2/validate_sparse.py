"""Validation of the sparse engines (sparse_h1.py with its dense core; sparse_big.py with Markowitz rounds and the
block Lanczos of lanczos16.py) against the dense engine and against each other.

  1. Block Lanczos on random sparse systems over F16 with a planted kernel: same null space as the dense kernel;
     with a block narrower than the kernel, N - (Krylov dimension) still equals the kernel dimension.
  2. dim H^1(Gamma_0(N O_E), F16) for PGL_2, trivial character, at N = 23, 31, 47, 79 (dense engine: 14, 15, 23, 42,
     model_N*.log), 103, 127, 143 (sparse runs): sparse_h1 with the dense core, sparse_big with the Lanczos core
     forced (dense_max = 0), sparse_big with the dense core.
The 633 comparisons are in sparse_633.log (dense core), sparse_633_lanczos.log (Lanczos core) and big_633.log
(sparse_big).  Author: Dula."""
import sys, time, numpy as np
from sparse_h1 import FastLevel, Reduction, MUL, INV, matmul16
from sparse_big import BigH1
from bmf import Comp
from mod2_refine import root as sroot
import lanczos16, gf, gf16_bits
import cypari2
pari = cypari2.Pari()
rng = np.random.default_rng(5)
def rnd(shape): return rng.integers(0, 16, size=shape).astype(np.uint8)
# ---------------------------------------------------------------- 1. planted kernels
def planted(N, d, R, k=10):
    K0 = rnd((d, N)); P = np.arange(d)
    while len(gf.rref16(K0[:, P].copy(), MUL, INV)) < d: K0 = rnd((d, N))
    Aug = np.concatenate([K0[:, P].T.copy(), np.eye(d, dtype=np.uint8)], axis=1); gf.rref16(Aug, MUL, INV); KPTinv = Aug[:, d:]
    rows = []
    for r in range(R):
        cs = rng.choice(np.arange(d, N), size=k, replace=False); vs = rng.integers(1, 16, size=k).astype(np.uint8)
        rf = np.zeros(N, np.uint8); rf[cs] = vs
        rf[P] = matmul16(matmul16(rf[None, :], K0.T.copy(), MUL), KPTinv, MUL)[0]
        rows.append(rf)
    Md = np.array(rows); assert not matmul16(Md, K0.T.copy(), MUL).any()
    ptr = np.zeros(R + 1, np.int64); ptr[1:] = np.cumsum((Md != 0).sum(1))
    return Md, ptr, np.nonzero(Md)[1].astype(np.int32), Md[Md != 0].astype(np.uint8)
print("1. block Lanczos on planted kernels", flush=True)
ok1 = True
for (N, d, R, w) in [(2000, 20, 3000, 1), (3000, 100, 4500, 2), (3000, 100, 4500, 1), (4000, 300, 6000, 6)]:
    Md, ptr, col, val = planted(N, d, R)
    t0 = time.time(); Kd, _ = gf16_bits.kernel_bits(Md.copy()); t1 = time.time()
    K, info = lanczos16.lanczos_kernel(ptr, col, val, N, w, seed=3, verbose=False)
    t2 = time.time()
    same = K.shape[0] == Kd.shape[0] and len(gf.rref16(np.vstack([K, Kd]).copy(), MUL, INV)) == Kd.shape[0]
    expect_full = 64 * w >= d + 16
    good = (same if expect_full else (K.shape[0] == 64 * w and N - info["krylov_dim"] == Kd.shape[0]))
    ok1 &= good
    print("  N = %d, kernel %d, block %d: Lanczos found %d, N - Krylov dimension = %d, %s  [%s]  (dense %.1fs, Lanczos %.1fs)"
          % (N, Kd.shape[0], 64 * w, K.shape[0], N - info["krylov_dim"], "same span as the dense kernel" if same else
             "a %d-dimensional part (block narrower than the kernel)" % K.shape[0], "OK" if good else "FAIL", t1 - t0, t2 - t1), flush=True)
# ---------------------------------------------------------------- 2. dimensions at Bianchi levels
print("2. dim H^1(Gamma_0(N O_E), F16), PGL_2, trivial character", flush=True)
ok2 = True
for N, dexp in [(23, 14), (31, 15), (47, 23), (79, 42), (103, None), (127, None), (143, None)]:
    comps = []
    for q in [int(q) for q in pari("factor(%d)[,1]~" % N)]:
        if int(pari("kronecker(-7, %d)" % q)) == 1: comps += [Comp("Fp", q, sroot(q, 0)), Comp("Fp", q, sroot(q, 1))]
        else: comps.append(Comp("Fp2", q))
    L = FastLevel(comps, None, name=str(N))
    t0 = time.time(); red = Reduction(L, fill=8.0, verbose=False); d1 = red.core_kernel.shape[0] + len(red.free_reps); t1 = time.time()
    H2 = BigH1(L, verbose=False, dense_max=0, lanczos_w=1); t2 = time.time()
    H3 = BigH1(L, verbose=False, dense_max=10**9); t3 = time.time()
    dims = [d1, H2.d, H3.d] + ([dexp] if dexp is not None else [])
    good = len(set(dims)) == 1; ok2 &= good
    print("  N = %d (n = %d): sparse_h1 %d (core %d, %.0fs); sparse_big Lanczos %d (core %d, runs %s, %.0fs); sparse_big dense %d (%.0fs)%s  [%s]"
          % (N, L.n, d1, len(red.core_cols), t1 - t0, H2.d, H2.core_shape[1], [(r["block"], r["kernel"]) for r in H2.lanczos_runs], t2 - t1,
             H3.d, t3 - t2, "; dense engine %d" % dexp if dexp is not None else "", "OK" if good else "FAIL"), flush=True)
print("all checks passed" if ok1 and ok2 else "SOME CHECK FAILED")
