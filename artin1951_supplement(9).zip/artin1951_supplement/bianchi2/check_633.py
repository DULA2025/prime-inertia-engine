"""The smallest icosahedral weight-one level, 633 (Buzzard-Lauder; LMFDB 633.1.m.b), as a mod-2 model of the 1951 type.
Recomputes with PARI: the weight-one newforms of level 633 with an odd character of order 10, their Galois types
(mfgaloistype), and for the A5 form: the projective field (mfgaloisprojrep) and its ramification, the projective order
of Frob_2 from u = a_2^2 / eps(2) (u = 2 + m + 1/m, m the eigenvalue ratio), and the reduction mod each prime above 2:
u_p = a_p^2 / eps(p) in F_4 with the values 1 and F_4 - F_2 (projective image A5 mod 2), u_2 outside {0} (x != y).
Usage: python3 check_633.py          Author: Dula."""
import time, cypari2
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
t0 = time.time(); N = 633
pari("G = znstar(%d, 1); L = chargalois(G); IX = select(i -> charorder(G, L[i]) == 10 && zncharisodd(G, L[i]), [1..#L]);" % N)
print("odd characters of order 10 mod 633: %d Galois orbits" % int(pari("#IX")), flush=True)
found = 0
for ii in range(1, int(pari("#IX")) + 1):
    pari("mf = mfinit([%d, 1, [G, L[IX[%d]]]], 0);" % (N, ii))
    d = int(pari("mfdim(mf)")); cm = pari("mfparams(mf)[3]")
    print("character %s: dim S_1^new = %d (%.0fs)" % (cm, d, time.time() - t0), flush=True)
    if d == 0: continue
    pari("B = mfeigenbasis(mf); ty = mfgaloistype(mf);")
    print("  Galois types (2n = D_n; -12 A4, -24 S4, -60 A5):", pari("ty"), flush=True)
    for j in range(1, int(pari("#B")) + 1):
        if int(pari("ty[%d]" % j)) != -60: continue
        found += 1
        pari("f = B[%d]; co = mfcoefs(f, 300); cmf = mfparams(mf)[3]; Gm = znstar(cmf.mod, 1); chm = znconreychar(Gm, cmf); "
             "cyc = mfparams(mf)[5]; o = charorder(Gm, chm); P = mffields(mf)[%d];" % (j, j))
        print("  A5 form %d: coefficient field over Q(chi): %s; a_2 = %s" % (j, pari("P"), pari("lift(co[3])")), flush=True)
        try:
            pari("pol = mfgaloisprojrep(mf, f); pol = polredbest(pol);")
            dg = int(pari("poldegree(pol)"))
            print("  projective field: degree %d polynomial %s" % (dg, pari("pol")), flush=True)
        except cypari2.PariError as e:
            print("  projective field: mfgaloisprojrep not available here (%s); LMFDB 633.1.m.b gives the Galois closure of 5.1.17839074969.1, "
                  "discriminant 17839074969 = %s" % (str(e).split(":")[0], pari("factor(17839074969)")), flush=True)
        # Frob_2 in char 0
        pari("epsv(p) = Mod(t^(chareval(Gm, chm, p) * o), cyc);")
        pari("e2 = epsv(2);")
        okc = int(pari("my(ok = 1); forprime(p = 3, 17, if (%d %% p, if (co[p^2 + 1] != co[p + 1]^2 - epsv(p), ok = 0))); ok" % N))
        print("  convention check a_{p^2} = a_p^2 - eps(p) (weight 1), p <= 17: %s" % bool(okc), flush=True)
        pari("R = rnfequation(cyc, P, 1); Pabs = R[1]; A = lift(R[2]); kk = R[3]; "
             "toabs(c) = Mod(subst(subst(liftall(c), 'y, 'y - kk * A), 't, A), Pabs);")
        pari("ua = toabs(co[3])^2 / toabs(e2); mp2 = minpoly(ua);")
        print("  u_2 = a_2^2/eps(2): minimal polynomial %s  (x^2 - 3x + 1: Frob_2 of projective order 5; x - 1: order 3)" % pari("mp2"), flush=True)
        pari("nf = nfinit([Pabs, [2]]); dec = idealprimedec(nf, 2); PR = primes([3, 300]);")
        for k in range(1, int(pari("#dec")) + 1):
            pari("modP = nfmodprinit(nf, dec[%d]); "
                 "U = vector(#PR, i, if (%d %% PR[i], nfmodpr(nf, toabs(co[PR[i] + 1])^2 / toabs(Mod(t^(chareval(Gm, chm, PR[i]) * o), cyc)), modP), 0)); "
                 "u2 = nfmodpr(nf, ua, modP);" % (k, N))
            inF4 = int(pari("vecsum(vector(#U, i, U[i]^4 != U[i])) == 0")); has1 = int(pari("vecsum(vector(#U, i, U[i] == 1)) > 0"))
            has5 = int(pari("vecsum(vector(#U, i, U[i] != 0 && U[i] != 1 && U[i]^4 == U[i])) > 0"))
            print("  mod P%d (f = %d): u_p in F4 for p <= 300: %s; value 1 occurs: %s; value in F4 - F2 occurs: %s; u_2 = %s (nonzero: x != y)"
                  % (k, int(pari("dec[%d].f" % k)), bool(inF4), bool(has1), bool(has5), pari("u2")), flush=True)
print("index of Gamma_0(633 O_E) over E = Q(sqrt-7): 3 inert (10) x 211 split (212^2) = %d; for 1951 (inert): %d" % (10 * 212 ** 2, 1951 ** 2 + 1))
print("A5 forms found: %d (%.0fs)" % (found, time.time() - t0))
