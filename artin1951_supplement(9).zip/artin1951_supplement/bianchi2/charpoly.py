"""Characteristic polynomials over F_P (Hessenberg reduction) with symmetric lift to Z.  Author: Dula."""
import numpy as np, sympy

def charpoly_modp(T, P):
    A = [[int(a) % P for a in row] for row in T.tolist()]; n = len(A)
    # Hessenberg reduction mod P
    for m in range(1, n - 1):
        piv = next((i for i in range(m, n) if A[i][m - 1] % P), None)
        if piv is None: continue
        if piv != m:
            A[m], A[piv] = A[piv], A[m]
            for r in range(n): A[r][m], A[r][piv] = A[r][piv], A[r][m]
        inv = pow(A[m][m - 1], P - 2, P)
        for i in range(m + 1, n):
            f = (A[i][m - 1] * inv) % P
            if f:
                for j in range(n): A[i][j] = (A[i][j] - f * A[m][j]) % P
                for r in range(n): A[r][m] = (A[r][m] + f * A[r][i]) % P
    # characteristic polynomial of the Hessenberg matrix (recurrence)
    p = [[1]]
    for k in range(1, n + 1):
        pk = [0] * (k + 1)
        prev = p[k - 1]
        for i, c in enumerate(prev):          # x * p_{k-1}
            pk[i + 1] = (pk[i + 1] + c) % P
        for i, c in enumerate(prev):          # - a_kk p_{k-1}
            pk[i] = (pk[i] - A[k - 1][k - 1] * c) % P
        t = 1
        for i in range(1, k):
            t = (t * A[k - i][k - i - 1]) % P
            coef = (t * A[k - i - 1][k - 1]) % P
            for j, c in enumerate(p[k - i - 1]):
                pk[j] = (pk[j] - coef * c) % P
        p.append(pk)
    return p[n]                                  # coefficients, constant first

def lift_factor(coeffs, P):
    x = sympy.symbols("x")
    poly = sum((c if c <= P // 2 else c - P) * x ** i for i, c in enumerate(coeffs))
    return sympy.factor(poly), poly
