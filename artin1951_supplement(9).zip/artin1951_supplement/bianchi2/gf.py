"""Small finite fields for the Bianchi computations: GF(2^4) with the encoding of the note
(F16 = F2[z]/(z^4+z^3+z^2+z+1), z = zeta_5 mod 2, codes b0 + 2 b1 + 4 b2 + 8 b3), GF(2) bit-packed elimination,
and prime fields F_P.  Dense linear algebra (rank, kernel, solve, generalized eigenspaces) for small matrices.
Author: Dula."""
import numpy as np, numba as nb

# ---- GF(16), modulus z^4 + z^3 + z^2 + z + 1 (z has order 5); a generator of F16^x is found below ----
def _f16_mul_raw(a, b):
    r = 0
    for i in range(4):
        if (b >> i) & 1: r ^= a << i
    for deg in (7, 6, 5, 4):
        if (r >> deg) & 1: r ^= 0b11111 << (deg - 4)
    return r
MUL16 = np.array([[_f16_mul_raw(a, b) for b in range(16)] for a in range(16)], dtype=np.uint8)
INV16 = np.zeros(16, dtype=np.uint8)
for a in range(1, 16):
    for b in range(1, 16):
        if MUL16[a, b] == 1: INV16[a] = b
assert all(MUL16[a, INV16[a]] == 1 for a in range(1, 16))
Z = 2                                     # z = zeta_5 mod 2
def f16_pow(a, e):
    r = 1
    for _ in range(e % 15 if a else e): r = int(MUL16[r, a])
    return r
assert f16_pow(Z, 5) == 1 and f16_pow(Z, 1) != 1
F4 = sorted({x for x in range(16) if f16_pow(x, 3) == 1} | {0})     # F4 inside F16: {0, 1, w, w^2}
assert len(F4) == 4

# ---- dense linear algebra over GF(16) (uint8 arrays) ----
@nb.njit(cache=True)
def rref16(M, mul, inv):
    """In-place reduced row echelon form over GF(16); returns pivot columns."""
    R, C = M.shape; piv = np.empty(min(R, C), dtype=np.int64); r = 0
    for c in range(C):
        if r >= R: break
        p = -1
        for i in range(r, R):
            if M[i, c] != 0: p = i; break
        if p < 0: continue
        if p != r:
            for j in range(C):
                t = M[r, j]; M[r, j] = M[p, j]; M[p, j] = t
        iv = inv[M[r, c]]
        for j in range(C): M[r, j] = mul[iv, M[r, j]]
        for i in range(R):
            if i != r and M[i, c] != 0:
                f = M[i, c]
                for j in range(C): M[i, j] ^= mul[f, M[r, j]]
        piv[r] = c; r += 1
    return piv[:r]

def kernel16(M):
    """Basis (rows) of {x : M x = 0} over GF(16)."""
    A = np.array(M, dtype=np.uint8, copy=True); R, C = A.shape
    piv = list(rref16(A, MUL16, INV16)); free = [c for c in range(C) if c not in set(piv)]
    K = np.zeros((len(free), C), dtype=np.uint8)
    for k, fc in enumerate(free):
        K[k, fc] = 1
        for r, pc in enumerate(piv): K[k, pc] = A[r, fc]        # char 2: -a = a
    return K

def matmul16(A, B):
    A = np.asarray(A, dtype=np.uint8); B = np.asarray(B, dtype=np.uint8)
    C = np.zeros((A.shape[0], B.shape[1]), dtype=np.uint8)
    for k in range(A.shape[1]):
        C ^= MUL16[A[:, k][:, None], B[k, :][None, :]]
    return C

def rank16(M):
    A = np.array(M, dtype=np.uint8, copy=True); return len(rref16(A, MUL16, INV16))

# ---- GF(2), bit-packed rows ----
@nb.njit(cache=True)
def rref2(M, ncols):
    """In-place RREF over GF(2) of a bit-packed matrix (rows of uint64 words); returns pivot columns."""
    R, W = M.shape; piv = np.empty(min(R, ncols), dtype=np.int64); r = 0
    for c in range(ncols):
        if r >= R: break
        w = c >> 6; b = np.uint64(1) << np.uint64(c & 63)
        p = -1
        for i in range(r, R):
            if M[i, w] & b: p = i; break
        if p < 0: continue
        if p != r:
            for j in range(W):
                t = M[r, j]; M[r, j] = M[p, j]; M[p, j] = t
        for i in range(R):
            if i != r and (M[i, w] & b):
                for j in range(w, W): M[i, j] ^= M[r, j]
        piv[r] = c; r += 1
    return piv[:r]

def pack2(dense01):
    R, C = dense01.shape; W = (C + 63) // 64
    P = np.zeros((R, W * 64), dtype=np.uint8); P[:, :C] = dense01 & 1
    return np.packbits(P.reshape(R, W, 64)[:, :, ::-1], axis=2, bitorder="big").view(">u8").astype(np.uint64).reshape(R, W)

def unpack2(P, C):
    R, W = P.shape
    bits = np.unpackbits(P.astype(">u8").view(np.uint8).reshape(R, W, 8), axis=2, bitorder="big").reshape(R, W, 64)[:, :, ::-1]
    return bits.reshape(R, W * 64)[:, :C].astype(np.uint8)

# ---- prime field F_P ----
@nb.njit(cache=True)
def rrefp(M, P):
    R, C = M.shape; piv = np.empty(min(R, C), dtype=np.int64); r = 0
    for c in range(C):
        if r >= R: break
        p = -1
        for i in range(r, R):
            if M[i, c] % P != 0: p = i; break
        if p < 0: continue
        if p != r:
            for j in range(C):
                t = M[r, j]; M[r, j] = M[p, j]; M[p, j] = t
        a = M[r, c] % P; iv = 1; e = P - 2; bb = a
        while e > 0:
            if e & 1: iv = (iv * bb) % P
            bb = (bb * bb) % P; e >>= 1
        for j in range(C): M[r, j] = (M[r, j] * iv) % P
        for i in range(R):
            if i != r and M[i, c] % P != 0:
                f = M[i, c] % P
                for j in range(C): M[i, j] = (M[i, j] - f * M[r, j]) % P
        piv[r] = c; r += 1
    return piv[:r]
