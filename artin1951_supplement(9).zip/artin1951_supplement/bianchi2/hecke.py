"""Hecke operators on the H^1 computed by bmf.Level.  Author: Dula."""
import numpy as np
from o7 import *
import gf

def hecke_reps(pi):
    """Right coset representatives of Gamma_0 diag(1, pi) Gamma_0 for (pi) prime to the level."""
    N = onorm(pi); reps = []
    # residues of O mod (pi): for prime pi of norm p (split or ramified) use 0..p-1; for inert p use x + y w, 0 <= x, y < p
    if any(pi == (q, 0) or pi == (-q, 0) for q in range(2, 100000) if q * q == N):
        p = abs(pi[0]); res = [(x, y) for y in range(p) for x in range(p)]
    else:
        res = [(x, 0) for x in range(N)]
    assert len(res) == N
    for b in res: reps.append(((1, 0), b, (0, 0), pi))
    reps.append((pi, (0, 0), (0, 0), (1, 0)))
    return reps

def odiv(a, pi):
    """a / pi in O, or None."""
    num = omul(a, oconj(pi)); N = onorm(pi)
    if num[0] % N or num[1] % N: return None
    return (num[0] // N, num[1] // N)

def adj(M): a, b, c, d = M; return (d, oneg(b), oneg(c), a)

def hecke_pieces(L, pi, h):
    """List of (h_i, weight eps(d_{alpha_i})^-1) with alpha_i h = h_i alpha_s(i)."""
    reps = hecke_reps(pi); out = []
    for ai in reps:
        X0 = mmul(ai, h); found = None
        for aj in reps:
            X = mmul(X0, adj(aj))
            Y = tuple(odiv(e, pi) for e in X)
            if None in Y: continue
            if mdet(Y) not in (((1, 0),) if L.group == "PSL" else ((1, 0), (-1, 0))) or not L.in_gamma0(Y): continue
            found = Y; break
        assert found is not None
        w = L.finv(L.eps(L.d_scalar(ai)))
        out.append((found, w))
    return out

def functional(L, M):
    d, cur, w = L.walk(decompose(M))
    return d

def apply_functional(L, d, vec):
    s = 0
    for u, c in d.items():
        if vec[u]: s = L.fadd(s, L.fmul(c, int(vec[u])))
    return s

def hecke_matrix(L, basis, pi, pivots=None, extra=8, rng=None):
    """Matrix of T_pi on span(basis) (rows = gauge-fixed cocycles); basis completed by L.dmpar if present.
    Returns (T, ok) where T[:, k] are the coordinates of T(basis_k) and ok is the consistency check on extra edges."""
    B = basis if L.dmpar is None else np.vstack([basis, L.dmpar[None, :]])
    D = B.shape[0]; n = L.n; G = len(L.gens)
    nontree = [u for u in range(G * n) if (L.gens[u // n], u % n) not in L.tree]
    # pivot columns: positions where B restricted is invertible
    if pivots is None:
        Bt = np.array(B[:, nontree], copy=True)
        piv = select_pivots(L, Bt)
        pivots = [nontree[j] for j in piv]
    rng = rng or np.random.default_rng(1)
    extras = list(rng.choice([u for u in nontree if u not in set(pivots)], size=min(extra, len(nontree) - D), replace=False)) if len(nontree) > D else []
    cols = list(pivots) + [int(u) for u in extras]
    # values of T(psi_k) on the Schreier generators of these edges, divided by eps(lambda_x)
    vals = np.zeros((len(cols), basis.shape[0]), dtype=np.int64)
    for r, u in enumerate(cols):
        g = L.gens[u // n]; x = u % n
        h = L.schreier(g, x); pieces = hecke_pieces(L, pi, h)
        funcs = [(functional(L, hi), w) for hi, w in pieces]
        il = L.finv(L.lam[x])
        for k in range(basis.shape[0]):
            s = 0
            for d, w in funcs: s = L.fadd(s, L.fmul(w, apply_functional(L, d, basis[k])))
            vals[r, k] = L.fmul(s, il)
    # solve B[:, cols]^T c = vals
    Bc = B[:, cols].T            # (len(cols), D)
    T = solve(L, Bc, vals)
    ok = T is not None
    if T is not None and L.dmpar is not None: T = T[:-1]
    return T, ok, pivots

def select_pivots(L, Bt):
    """Column indices j such that Bt[:, j] (D x D) is invertible: RREF pivots of Bt."""
    if L.field in ("F2", "F16"):
        A = np.array(Bt, dtype=np.uint8, copy=True); piv = gf.rref16(A, gf.MUL16, gf.INV16)
    else:
        A = np.array(Bt, dtype=np.int64, copy=True); piv = gf.rrefp(A, L.field[1])
    assert len(piv) == Bt.shape[0], (len(piv), Bt.shape)
    return list(piv)

def solve(L, Bc, vals):
    """Solve Bc X = vals (overdetermined, exact); returns X (D x k) or None if inconsistent."""
    D = Bc.shape[1]; k = vals.shape[1]
    if L.field in ("F2", "F16"):
        Aug = np.concatenate([Bc.astype(np.uint8), vals.astype(np.uint8)], axis=1)
        piv = list(gf.rref16(Aug, gf.MUL16, gf.INV16))
        if any(p >= D for p in piv): return None
        X = np.zeros((D, k), dtype=np.int64)
        for r, p in enumerate(piv): X[p] = Aug[r, D:]
        return X
    P = L.field[1]
    Aug = np.concatenate([Bc % P, vals % P], axis=1).astype(np.int64)
    piv = list(gf.rrefp(Aug, P))
    if any(p >= D for p in piv): return None
    X = np.zeros((D, k), dtype=np.int64)
    for r, p in enumerate(piv): X[p] = Aug[r, D:]
    return X
