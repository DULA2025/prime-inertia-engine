"""Search weight-2 newforms of prime level N (trivial character) for mod-2 eigensystems rbar (at a prime P | 2 of the Hecke
field) that are unramified at 2 with both refinements present (companion: a conjugate system with the same traces at
odd p and T_2 eigenvalue 1/u), and classify the projective image by the traces (S3: {0,1}; D5: {0} u F4\\F2;
A5: {0,1} u F4\\F2).  Reports the index of Gamma_0(N O_E) in PSL_2(O_E), E = Q(sqrt-7).  Author: Dula."""
import sys, cypari2
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
Nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 300
pari("PR = primes([3, 120]);")
out = []
for N in [int(q) for q in pari("primes([3, %d])" % Nmax)]:
    pari("mf = mfinit([%d, 2], 0); L = mfeigenbasis(mf); F = mffields(mf);" % N)
    for j in range(int(pari("#L"))):
        d = int(pari("poldegree(F[%d])" % (j + 1)))
        if d > 16 or d < 2: continue
        pari("P = F[%d]; nf = nfinit(P); co = mfcoefs(L[%d], 120); dec = idealprimedec(nf, 2);" % (j + 1, j + 1))
        for k in range(int(pari("#dec"))):
            f = int(pari("dec[%d].f" % (k + 1)))
            if f < 2: continue
            pari("pr = dec[%d]; modP = nfmodprinit(nf, pr); red(a) = nfmodpr(nf, lift(a), modP);" % (k + 1))
            pari("u = red(co[3]);")                                   # a_2 mod P (kept inside PARI)
            if pari("u == 0") == 1: continue
            if pari("u^2 == 1") == 1: continue                        # x = y: excluded (need distinct eigenvalues)
            # traces at odd p != N, and the subfield they generate
            pari("T = vector(#PR, i, if(PR[i] == %d, 0, red(co[PR[i] + 1])));" % N)
            fp = None
            for ff in range(1, f + 1):
                if f % ff: continue
                if pari("vecsum(vector(#T, i, T[i]^(2^%d) != T[i])) == 0" % ff) == 1: fp = ff; break
            comp = pari("u^(2^%d) * u == 1" % fp) == 1
            if not comp: continue
            # classify: values present among traces of primes != N
            has1 = pari("vecsum(vector(#T, i, PR[i] != %d && T[i] == 1)) > 0" % N) == 1
            hasF4 = pari("vecsum(vector(#T, i, PR[i] != %d && T[i] != 0 && T[i] != 1 && T[i]^4 == T[i])) > 0" % N) == 1
            hasbig = fp > 2
            typ = "S3" if (fp == 1 and has1) else ("A5 (SL2(F4))" if (fp == 2 and has1 and hasF4) else ("D5-like" if (fp == 2 and hasF4 and not has1) else "other f'=%d" % fp))
            split = pari("kronecker(-7, %d)" % N) == 1
            idx = (N + 1) ** 2 if split else N * N + 1
            out.append((N, j + 1, d, f, fp, typ, split, idx))
            print("N = %4d orbit %d (deg %2d): P | 2 with f = %d, traces in F_{2^%d}, companion present, image %s; N %s in E, index %d"
                  % (N, j + 1, d, f, fp, typ, "split" if split else "inert", idx), flush=True)
