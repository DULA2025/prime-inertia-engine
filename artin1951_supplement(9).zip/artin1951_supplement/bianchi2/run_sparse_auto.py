"""Models at larger levels with the sparse engine: for a squarefree level N (trivial character), compute
H^1(Gamma_0(N O_E), F16) for PGL_2(O_E), E = Q(sqrt-7), once, and then, for EVERY mod-2 system of the weight-2 newforms
of level N with residue field inside F16 and x != y (x = a_2 mod P, y = 1/x), its rbar-part and the pairs (T_v, T_vbar).
Usage: python3 run_sparse_auto.py N          Author: Dula."""
import sys, json, time, resource
import numpy as np, cypari2
from sparse_h1 import *
from mod2_refine import root as sroot
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
t00 = time.time(); N = int(sys.argv[1]); NB = 300
def ev16(cs, th):
    r = 0; pw = 1
    for c in cs:
        if c: r ^= pw
        pw = int(MUL[pw, th])
    return r
# ---------------------------------------------------------------- Bianchi side
comps = []
for q in [int(q) for q in pari("factor(%d)[,1]~" % N)]:
    if q == 7: comps.append(Comp("Fp", 7, 4))
    elif int(pari("kronecker(-7, %d)" % q)) == 1: comps += [Comp("Fp", q, sroot(q, 0)), Comp("Fp", q, sroot(q, 1))]
    else: comps.append(Comp("Fp2", q))
assert int(pari("issquarefree(%d)" % N))
L = FastLevel(comps, None, name=str(N))
print("level %d O_E: components %s, index n = %d" % (N, [(c.typ, c.p) for c in comps], L.n), flush=True)
red = Reduction(L, fill=8.0, verbose=True)
K = red.kernel(verbose=True); D = K.shape[0]
rng = np.random.default_rng(7)
pivots = select_pivots(K, ~L.TREE, rng)
def find_pi(p):
    for yy in range(1, 60):
        for xx in range(-120, 120):
            if onorm((xx, yy)) == p: return (xx, yy)
ops = [("v", (0, 1), 2, "split"), ("vbar", (1, -1), 2, "split")]
for q in (3, 5, 13):
    if N % q: ops.append(("(%d)" % q, (q, 0), q, "inert"))
if N % 7: ops.append(("(sqrt-7)", (-1, 2), 7, "ram"))
for q in (11, 23, 29, 37, 43, 53, 67, 71, 79):
    if N % q: pi = find_pi(q); ops += [("q%d" % q, pi, q, "split"), ("q%dbar" % q, oconj(pi), q, "split")]
Ts = {}
for nm, pi, p, typ in ops:
    T = hecke_matrix_sparse(L, K, pi, pivots, rng)
    assert T is not None, nm
    Ts[nm] = (T, p, typ)
comm = all((matmul16(Ts[a][0], Ts[b][0], MUL) == matmul16(Ts[b][0], Ts[a][0], MUL)).all() for a in Ts for b in Ts)
print("dim H^1 = %d; %d Hecke operators, commute: %s (%.0fs)" % (D, len(Ts), comm, time.time() - t00), flush=True)
names = [nm for nm in Ts if nm not in ("v", "vbar")]; first = names[:6]; rest = names[6:]
def restrict(T, V):
    TV = matmul16(np.ascontiguousarray(V), np.ascontiguousarray(T.T), MUL)
    X = np.concatenate([V.T, TV.T], axis=1).astype(np.uint8); d = V.shape[0]
    piv = list(gf.rref16(X, MUL, INV)); assert all(p < d for p in piv), "not stable"
    C = np.zeros((d, d), dtype=np.uint8)
    for r, p in enumerate(piv): C[p] = X[r, d:]
    return C
# ---------------------------------------------------------------- all mod-2 systems of level N
pari("mf = mfinit([%d, 2], 0); B = mfeigenbasis(mf); F = mffields(mf);" % N)
out = {"N": N, "n": L.n, "dimH1": D, "commute": bool(comm), "core_cols": len(red.core_cols), "systems": []}
for j in range(1, int(pari("#B")) + 1):
    pari("P = F[%d]; co = mfcoefs(B[%d], %d); Pabs = if (poldegree(P) == 0, 'y, P);" % (j, j, NB))
    pari("toabs(c) = Mod(liftall(c), Pabs);")
    pari("nf = nfinit([Pabs, [2]]); dec = idealprimedec(nf, 2);")
    for kP in range(1, int(pari("#dec")) + 1):
        f = int(pari("dec[%d].f" % kP))
        if f == 1 or 4 % f: continue
        pari("modP = nfmodprinit(nf, dec[%d]);" % kP)
        pari("rdx(x) = nfmodpr(nf, toabs(x), modP);")
        pari("g0 = rdx(co[3]); gen = ffgen(g0); m = gen.mod;")
        mc = [int(c) % 2 for c in pari("Vecrev(lift(m))")]
        th = [x for x in range(16) if ev16(mc, x) == 0][0]
        def to16(expr):
            if int(pari("type(%s) == \"t_FFELT\"" % expr)):
                return ev16([int(c) % 2 for c in pari("my(z = %s); Vecrev(lift(z.pol))" % expr)], th)
            return ev16([int(pari("lift(%s)" % expr)) % 2], th)
        x = to16("rdx(co[3])")
        if x == 0 or MUL[x, x] == 1: continue                     # need x != y = 1/x
        y = int(INV[x])
        AP = {}
        for p in set(op[2] for op in ops):
            if p != 2: AP[p] = to16("rdx(co[%d + 1])" % p)
        def evq(nm):
            T, p, typ = Ts[nm]; a = AP[p]
            return a if typ != "inert" else int(MUL[a, a])
        V = gen_eigenspace([Ts[nm][0] for nm in first], [evq(nm) for nm in first], D)
        rec = {"orbit": j, "prime": kP, "f": f, "x": x, "y": y, "rbar_dim": int(V.shape[0])}
        if V.shape[0]:
            Rv = restrict(Ts["v"][0], V); Rvb = restrict(Ts["vbar"][0], V)
            pairs = []
            for a in range(16):
                Va = gen_eigenspace([Rv], [a], V.shape[0])
                if Va.shape[0] == 0: continue
                Rb = restrict(Rvb, Va)
                for b in range(16):
                    Vb = gen_eigenspace([Rb], [b], Va.shape[0])
                    if Vb.shape[0]: pairs.append((a, b, int(Vb.shape[0])))
            rec["pairs"] = pairs
            for (a, b) in [(x, y), (y, x)]:
                Va = gen_eigenspace([Rv, Rvb], [a, b], V.shape[0])
                W = matmul16(np.ascontiguousarray(Va), np.ascontiguousarray(V), MUL) if Va.shape[0] else Va
                # true joint eigenvectors inside W: T_v w = a w, T_vbar w = b w, T_q w = lambda_q w for ALL q (first and rest)
                ev_dim = 0
                if W.shape[0]:
                    blocks = []
                    for nm, lam in [("v", a), ("vbar", b)] + [(nm, evq(nm)) for nm in first + rest]:
                        S = Ts[nm][0] ^ (MUL[lam, 1] * np.eye(D, dtype=np.uint8))
                        blocks.append(matmul16(np.ascontiguousarray(W), np.ascontiguousarray(S.T), MUL))   # rows: (S w)^T
                    M = np.concatenate(blocks, axis=1)                         # (dim W) x (k D): c^T M = 0 for eigen-combinations
                    ev_dim = gf.kernel16(M.T).shape[0]
                rec["mixed_%d_%d" % (a, b)] = {"dim": int(Va.shape[0]), "joint_eigenvectors": int(ev_dim), "operators": ["v", "vbar"] + first + rest}
        out["systems"].append(rec)
        print("orbit %d, P%d (f = %d), (x, y) = (%d, %d): rbar-part dim %d%s" % (j, kP, f, x, y, V.shape[0],
              ("; pairs %s; joint eigenvectors (rbar eigenvalues at all %d operators) in (x,y): %d, in (y,x): %d" % (rec["pairs"], 2 + len(first) + len(rest), rec["mixed_%d_%d" % (x, y)]["joint_eigenvectors"], rec["mixed_%d_%d" % (y, x)]["joint_eigenvectors"])) if V.shape[0] else ""), flush=True)
out["seconds"] = round(time.time() - t00); out["peak_rss_MB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024
json.dump(out, open("sparse_auto_N%d.json" % N, "w"), indent=1, default=int)
print("done (%.0fs, peak RSS %d MB)" % (time.time() - t00, out["peak_rss_MB"]))
