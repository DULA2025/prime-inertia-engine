"""p-adic follow-ups (Dula): (a) the second trivial-zero prime p = 37 (rho(Frob_37) has eigenvalue 1); (b) 2-adic
structure of the exact values L(rho, 1-n) in Z[zeta5] (2 is inert, residue field F16 = the field of the mod-2 Hecke
eigensystem of Theorem D); (c) the derivative of L_11(rho.omega, s) at the trivial zero s = 0, mod 11^2, at the four
primes above 11 (a numerical 'L-invariant' datum).  Values from brainstorm/neg[A-D].json and brainstorm2/negE.json."""
import sys, json, glob
sys.set_int_max_str_digits(0)
sys.path.insert(0, "/home/claude/research/brainstorm")
from fractions import Fraction
from q5 import *
T, D = load()
vals = {}
for f in sorted(glob.glob("/home/claude/research/brainstorm/neg[A-Z].json") + glob.glob("/home/claude/research/brainstorm2/neg[A-Z].json")):
    for k, o in json.load(open(f)).items():
        assert o["denominator"] == 1
        vals[int(k)] = tuple(int(Fraction(c)) for c in o["coords"])
def vp_int(x, p):
    if x == 0: return 10**9
    v = 0
    while x % p == 0: x //= p; v += 1
    return v
def vinert(x, p): return min(vp_int(c, p) for c in x)
def Ep(p, n):
    a = ap(1, p, T); d = detp(1, p)
    return add(sub(ONE, scal(p ** (n - 1), a)), scal(p ** (2 * n - 2), d))
out = {}
# (a) p = 37
p = 37
E1 = add(sub(ONE, ap(1, p, T)), detp(1, p))
ns = sorted(n for n in vals if (n - 1) % (p - 1) == 0)
rows = []
for n in ns:
    Ls = mul(Ep(p, n), vals[n])
    rows.append((n, vp_int(n - 1, p) + 1, vinert(Ls, p)))
print("p = 37: E_37(1) = %s (trivial zero: %s); 37 = 2 mod 5 is inert in Q(zeta5)" % (E1, E1 == ZERO))
for n, pred, v in rows:
    print("   n = %-5d  v_37(n-1)+1 = %d   v_37(L*(rho,1-n)) = %d" % (n, pred, v))
kum = []
for i, n in enumerate(ns):
    for n2 in ns[i + 1:]:
        d = vinert(sub(mul(Ep(p, n), vals[n]), mul(Ep(p, n2), vals[n2])), p)
        kum.append(d - (vp_int(n2 - n, p) + 1))
print("   Kummer pairs: %d, min margin %d, all equal: %s" % (len(kum), min(kum), all(k == 0 for k in kum)))
out["p37"] = {"rows": rows, "kummer_pairs": len(kum), "kummer_min_margin": min(kum)}
# (b) 2-adic look: v_2 of L(rho,1-n) and the residue of L/2^v in F16 = Z[zeta5]/2 (code b0 + 2 b1 + 4 b2 + 8 b3)
v2 = {}
for n in sorted(vals):
    x = vals[n]; v = vinert(x, 2)
    red = tuple((c >> v) & 1 for c in x)
    v2[n] = (v, red)
print("2-adic: v_2(L(rho,1-n)) for odd n:", sorted(set(v for v, r in v2.values())), "; residues of L/2^v in F16:",
      sorted(set(r for v, r in v2.values())))
L0 = (0, -4, -4, 0)
print("   L(rho,0) = -4(z+z^2): v_2 = %d, residue %s" % (vinert(L0, 2), tuple((c >> 2) & 1 for c in L0)))
# 2-adic Kummer-type check on the same values (p = 2: n = n' mod 2^k => congruence mod 2^{k+?}); report the pattern
pairs = []
ns2 = sorted(vals)
for i, n in enumerate(ns2):
    for n2 in ns2[i + 1:]:
        a = mul(Ep(2, n), vals[n]); b = mul(Ep(2, n2), vals[n2])
        pairs.append((vp_int(n2 - n, 2), vinert(sub(a, b), 2)))
from collections import defaultdict
tab = defaultdict(list)
for k, v in pairs: tab[k].append(v)
print("   2-adic differences: v_2(n'-n) -> min v_2(L*(n) - L*(n')) over pairs:", {k: min(v) for k, v in sorted(tab.items())})
out["two_adic"] = {"v2": sorted(set(v for v, r in v2.values())), "residues": sorted(set(r for v, r in v2.values())),
                   "diff_table": {k: min(v) for k, v in tab.items()}}
# (c) derivative at the trivial zero, p = 11: L_11(s) = s * D + O(s^2), s = 1 - n; D mod 11^{v(s)} from L*(n)/s
def roots_mod(p, K):
    out = []; mod = p ** K
    for r in range(2, p):
        if pow(r, 5, p) == 1:
            x = r
            for _ in range(K + 2): x = (x - (pow(x, 5, mod) - 1) * pow(5 * pow(x, 4, mod), -1, mod)) % mod
            out.append(x)
    return out
p = 11; K = 8
rts = roots_mod(p, K)
dd = {}
for n in sorted(n for n in vals if (n - 1) % 10 == 0):
    vs = vp_int(n - 1, p); vT = 1 + vs                     # v(T_n), T_n = 12^(1-n) - 1
    Tn = (pow(pow(12, n - 1, p ** K), -1, p ** K) - 1) % p ** K
    assert vp_int(Tn, p) == vT
    Ls = mul(Ep(p, n), vals[n])
    row = []
    for r in rts:
        x = (Ls[0] + Ls[1] * r + Ls[2] * r * r + Ls[3] * r ** 3) % p ** K
        assert vp_int(x, p) == vT, (n, vp_int(x, p), vT)
        g1 = (x // p ** vT) * pow(Tn // p ** vT, -1, p ** K) % p ** vT     # G(T_n)/T_n = g1 + O(T_n): g1 mod 11^{v(T_n)}
        row.append(g1)
    dd[n] = (vT, row)
print("p = 11: g1 = dG/dT at T = 0 (L_11(rho.omega, s) = G((1+11)^s - 1)), at z -> %s:" % [r % p for r in rts])
for n, (vT, row) in sorted(dd.items()):
    print("   n = %-5d  g1 mod 11^%d = %s" % (n, vT, row))
cons = all(all(dd[n][1][i] % 11 == dd[11][1][i] % 11 for i in range(4)) for n in dd)
deep = [n for n in dd if dd[n][0] >= 2]
cons2 = all(all(dd[n][1][i] % 121 == dd[deep[-1]][1][i] % 121 for i in range(4)) for n in deep)
print("   consistent mod 11 across all n: %s; mod 121 across n with 11 | n-1: %s" % (cons, cons2))
out["p11_derivative"] = {str(n): v for n, v in dd.items()}
json.dump(out, open("padic2_report.json", "w"), indent=1, default=str)
