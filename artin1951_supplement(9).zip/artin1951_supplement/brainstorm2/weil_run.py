"""Run the restricted Weil form for L(rho,s): eigenvalues, minimiser zeros vs PARI zeros.  Author: Dula.
usage: python3 weil_run.py X m dps [shuffle_seed]"""
import sys, json, time, mpmath
from mpmath import mp, mpf
import weilform as W
X = float(sys.argv[1]); m = int(sys.argv[2]); dps = int(sys.argv[3])
seed = int(sys.argv[4]) if len(sys.argv) > 4 else 0
Tm = W.shuffled_labels(seed) if seed else None
t0 = time.time()
Q, L, J, aux = W.build(X, m, dps=dps, Tm=Tm)
mp.dps = dps
E, V = mpmath.eigsy(Q / L)
ev = [E[i] for i in range(len(J))]
order = sorted(range(len(J)), key=lambda i: ev[i])
mu = [ev[i] for i in order]
print("  eig in %.0fs: smallest %s" % (time.time() - t0, [mpmath.nstr(x, 6) for x in mu[:5]]), flush=True)
i0 = order[0]
cvec = [V[a, i0] for a in range(len(J))]
R = float(2 * mp.pi * m / L) * 0.8
zs = W.zeros_of(cvec, J, L, R, step=0.01)
REF = "zeros_hp_B420_T26.json" if R <= 25.5 else "zeros_hp_B160_T45.json"
ref = [mpf(x) for x in json.load(open(REF))["zeros"]]
rows = []
for z in zs:
    near = min(ref, key=lambda g: abs(g - z))
    rows.append((float(z), float(near), float(abs(z - near))))
out = {"X": X, "L": float(L), "m": m, "dps": dps, "shuffle_seed": seed, "eigs": [mpmath.nstr(x, 12) for x in mu[:8]],
       "zeros": rows, "R": R, "n_ref_in_R": sum(1 for g in ref if abs(g) <= R)}
json.dump(out, open("weil_X%g_m%d_dps%d_s%d.json" % (X, m, dps, seed), "w"), indent=0)
json.dump([mpmath.nstr(x, dps - 5) for x in cvec], open("weil_vec_X%g_m%d_s%d.json" % (X, m, seed), "w"))
print("X=%g L=%.3f m=%d: min eig %s, 2nd %s ; %d minimiser zeros in |r|<=%.1f (PARI has %d there)" %
      (X, float(L), m, mu[0], mpmath.nstr(mu[1], 6), len(zs), R, out["n_ref_in_R"]))
for z, g, d in rows:
    print("   eta^ zero %+.12f   nearest L(rho) zero %+.12f   |diff| %.2e" % (z, g, d))
