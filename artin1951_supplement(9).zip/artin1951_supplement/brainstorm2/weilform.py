"""Connes-style restricted Weil quadratic form for L(rho, s), rho = rho0 x chi^3 (conductor 1951).  Author: Dula.

Test functions phi on I = [-L/2, L/2], L = log X, basis e_j(x) = exp(i w_j x), w_j = 2 pi j / L, |j| <= m.
Q(phi) = W(phi * phi~),  phi~(x) = conj(phi(-x)),  W = explicit-formula functional of L(rho, s):
    W(g) = (log N - 2 log pi - 2 gamma_E) g(0) + 2 int_0^inf [2 e^{-2x} g(0) - e^{-3x/2}(g(x) + g(-x))]/(1 - e^{-2x}) dx
           - sum_{n <= X} n^{-1/2} [Lam(n) g(log n) + conj(Lam(n)) g(-log n)]            (validated: weil_validate.py)
If L(rho, s) is entire, W(phi * phi~) = sum over zeros 1/2 + i gamma of |phi^(gamma)|^2 >= 0 (a pole at 1/2 + i gamma_p
would enter with a minus sign).  The prime side needs only n <= X = e^L: nothing here assumes holomorphy.
Closed forms (g_jk = e_j * e_k~ on [0, L]):
    j != k:  g_jk(x) = (-1)^{j-k} (e^{i w_k x} - e^{i w_j x}) / (i (w_j - w_k)),    j = k:  g_jj(x) = (L - x) e^{i w_j x}
    Q_jk = -4 (-1)^{j-k} [I_s(w_k) - I_s(w_j)]/(w_j - w_k) - 2 (-1)^{j-k} Im(P(w_k) - P(w_j))/(w_j - w_k)
    Q_jj = L(log N - 2 log pi - 2 gamma_E) + 4 I_c(w_j) - 2 L log(1 - e^{-2L}) - 2 Re(L P(w_j) - P1(w_j))
    P(w) = sum Lam(n) n^{-1/2} e^{i w log n},  P1(w) = sum Lam(n) n^{-1/2} log n e^{i w log n}
    I_s(w) = int_0^L e^{-3x/2} sin(wx)/(1-e^{-2x}) dx = Im psi(3/4 + iw/2)/2 - sum_k e^{-a_k L} w/(a_k^2 + w^2), a_k = 3/2 + 2k
    I_c(w) = int_0^L [L e^{-2x} - (L-x) e^{-3x/2} cos wx]/(1-e^{-2x}) dx
           = (L/2)(Re psi(3/4+iw/2) + gamma_E) + Re psi'(3/4+iw/2)/4 - L sum e^{-(2k+2)L}/(2k+2) - Re sum e^{-(2k+3/2)L}/(2k+3/2-iw)^2
Q is real symmetric (Hermitian with real entries); Gram matrix = L * Id.  The minimiser eta = sum c_j e_j has
    eta^(r) = 2 sin(rL/2) sum_j c_j (-1)^j / (r + w_j),   real on the real line;
its real zeros are compared with the zeros of L(rho, s) computed by PARI (which assumes holomorphy)."""
import sys, json, math, time
sys.path.insert(0, "/home/claude/research/brainstorm")
import mpmath
from mpmath import mp, mpf, mpc
from q5 import *

T_, D_ = load("/home/claude/research/overnight/traces/galois_traces_3200000.json")

def lam_exact(X, Tm=None):
    """[(n, Lam(n)/log p as exact 4-vector, p)] for prime powers n <= X; Tm overrides the trace labels"""
    Tm = Tm or T_
    out = []
    for p in sorted(list(T_) + [N]):
        if p > X: break
        if p == N:
            al = zpow(2); P = [None, al]
            q = p; k = 1
            while q <= X:
                out.append((q, P[k] if k < len(P) else None, p)); q *= p; k += 1
                if k >= len(P): P.append(mul(P[-1], al))
            continue
        a = ap(1, p, Tm); d = detp(1, p)
        P = [None, a, sub(mul(a, a), scal(2, d))]
        q = p; k = 1
        while q <= X:
            while len(P) <= k: P.append(sub(mul(a, P[-1]), mul(d, P[-2])))
            out.append((q, P[k], p)); q *= p; k += 1
    return out

def shuffled_labels(seed=1, pmin=3):
    """control: the trace labels t_p permuted at random among the primes pmin <= p < 3.2e6 (chi kept)"""
    import random
    ps = sorted(p for p in T_ if p >= pmin)
    labs = [T_[p] for p in ps]
    random.Random(seed).shuffle(labs)
    Tm = dict(T_); Tm.update(dict(zip(ps, labs)))
    return Tm

def build(X, m, dps=60, Tm=None, verbose=True):
    """Q (mpmath matrix, size 2m+1) for cutoff X; Tm = alternative trace labels (control)."""
    mp.dps = dps
    L = mpmath.log(X)
    zs = [mpmath.expjpi(mpf(2 * k) / 5) for k in range(5)]
    E = lambda a: a[0] + a[1] * zs[1] + a[2] * zs[2] + a[3] * zs[3]
    t0 = time.time()
    lst = lam_exact(X, Tm)
    c, ell, u = [], [], []
    twopi_L = 2 * mp.pi / L
    for n, v, p in lst:
        ln = mpmath.log(n)
        c.append(E(v) * mpmath.log(p) / mpmath.sqrt(n)); ell.append(ln); u.append(mpmath.expj(twopi_L * ln))
    J = range(-m, m + 1)
    P = {}; P1 = {}
    pw = [mpc(1)] * len(c)
    P[0] = sum(c); P1[0] = sum(ci * li for ci, li in zip(c, ell))
    for j in range(1, m + 1):
        pw = [a * b for a, b in zip(pw, u)]
        P[j] = sum(ci * w for ci, w in zip(c, pw)); P1[j] = sum(ci * li * w for ci, li, w in zip(c, ell, pw))
        cw = [w.conjugate() for w in pw]
        P[-j] = sum(ci * w for ci, w in zip(c, cw)); P1[-j] = sum(ci * li * w for ci, li, w in zip(c, ell, cw))
    w = {j: twopi_L * j for j in J}
    eg = mpmath.euler
    def Is(om):
        s = mpmath.im(mpmath.digamma(mpf(3) / 4 + 1j * om / 2)) / 2
        k = 0
        while True:
            a = mpf(3) / 2 + 2 * k; t = mpmath.exp(-a * L) * om / (a * a + om * om)
            s -= t; k += 1
            if abs(t) < mpf(10) ** (-dps - 5) or k > 200: break
        return s
    def Ic(om):
        z = mpf(3) / 4 + 1j * om / 2
        s = L / 2 * (mpmath.re(mpmath.digamma(z)) + eg) + mpmath.re(mpmath.psi(1, z)) / 4
        k = 0
        while True:
            b = 2 * k + 2; zz = mpf(2 * k) + mpf(3) / 2 - 1j * om
            t1 = L * mpmath.exp(-b * L) / b; t2 = mpmath.re(mpmath.exp(-(2 * k + mpf(3) / 2) * L) / zz ** 2)
            s -= t1 + t2; k += 1
            if abs(t1) + abs(t2) < mpf(10) ** (-dps - 5) or k > 200: break
        return s
    Isv = {j: Is(w[j]) for j in J}; Icv = {j: Ic(w[j]) for j in J}
    n = 2 * m + 1
    Q = mpmath.matrix(n, n)
    base = L * (mpmath.log(N) - 2 * mpmath.log(mp.pi) - 2 * eg) - 2 * L * mpmath.log(1 - mpmath.exp(-2 * L))
    for a, j in enumerate(J):
        for b, k in enumerate(J):
            if j == k:
                Q[a, b] = base + 4 * Icv[j] - 2 * mpmath.re(L * P[j] - P1[j])
            elif b > a:
                sg = -1 if (j - k) % 2 else 1
                d = w[j] - w[k]
                val = -4 * sg * (Isv[k] - Isv[j]) / d - 2 * sg * mpmath.im(P[k] - P[j]) / d
                Q[a, b] = val; Q[b, a] = val
    if verbose:
        print("  built Q: X=%g L=%.4f m=%d (%d prime powers, %d x %d) in %.0fs" % (X, float(L), m, len(c), n, n, time.time() - t0), flush=True)
    return Q, L, list(J), {"P": P, "P1": P1, "Is": Isv, "Ic": Icv, "w": w}

def etahat(cvec, J, L, r):
    """eta^(r) for coefficient vector cvec over J"""
    r = mpf(r)
    s = mpc(0)
    for cj, j in zip(cvec, J):
        om = 2 * mp.pi * j / L
        if abs(r + om) < mpf(10) ** (-mp.dps // 2):
            return cj * L * (1 if True else 0)
        s += cj * (-1) ** (j % 2) / (r + om)
    return 2 * mpmath.sin(r * L / 2) * s

def zeros_of(cvec, J, L, R, step=0.01):
    """real zeros of eta^ in [-R, R] by sign changes + bisection/secant refinement"""
    f = lambda r: mpmath.re(etahat(cvec, J, L, r))
    xs = [mpf(-R) + step * i for i in range(int(2 * R / step) + 1)]
    vals = [f(x) for x in xs]
    out = []
    for i in range(len(xs) - 1):
        if vals[i] == 0: out.append(xs[i]); continue
        if vals[i] * vals[i + 1] < 0:
            try:
                rt = mpmath.findroot(f, (xs[i], xs[i + 1]), solver="anderson")
            except Exception:
                rt = mpmath.findroot(f, (xs[i], xs[i + 1]), solver="bisect")
            out.append(rt)
    return out
