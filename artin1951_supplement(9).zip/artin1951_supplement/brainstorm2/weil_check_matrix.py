"""Checks of weilform.build: (1) closed forms I_s, I_c against direct quadrature; (2) c^T Q c against the zero side
sum |phi^(gamma)|^2 for a continuous test function (raised cosine, phi^ = O(r^-3)), zeros from PARI to |t| <= 45
(160 bits) and the certified grid intervals (midpoints) for 45 < |t| <= 146."""
import json, mpmath
from mpmath import mp, mpf
import weilform as W
mp.dps = 30
X, m = 3000.0, 3
Q, L, J, aux = W.build(X, m, dps=30)
for j in (0, 1, 3):
    om = aux["w"][j]
    qs = mpmath.quad(lambda x: mpmath.exp(-1.5 * x) * mpmath.sin(om * x) / (1 - mpmath.exp(-2 * x)), [0, 1, L])
    qc = mpmath.quad(lambda x: (L * mpmath.exp(-2 * x) - (L - x) * mpmath.exp(-1.5 * x) * mpmath.cos(om * x)) / (1 - mpmath.exp(-2 * x)), [0, 1, L])
    print("j=%d  I_s closed-quad %.2e   I_c closed-quad %.2e" % (j, float(aux["Is"][j] - qs), float(aux["Ic"][j] - qc)))
c = {0: 2, 1: 1, -1: 1}
vec = [mpf(c.get(j, 0)) for j in J]
form = sum(vec[a] * Q[a, b] * vec[b] for a in range(len(J)) for b in range(len(J)))
def phihat(r):
    r = mpf(r); s = 0
    for j, cj in c.items():
        om = 2 * mp.pi * j / L
        s += cj * (L if abs(r + om) < 1e-20 else 2 * mpmath.sin((r + om) * L / 2) / (r + om))
    return s
z45 = [mpf(x) for x in json.load(open("zeros_hp_B160_T45.json"))["zeros"]]
zc = []
for line in open("zeros_L_rho_1951.txt"):
    if line.startswith("#"): continue
    a, b = map(float, line.split()); mid = (a + b) / 2
    if abs(mid) > 45: zc.append(mpf(mid))
side = sum(phihat(g) ** 2 for g in z45) + sum(phihat(g) ** 2 for g in zc)
# tail |t| > 146: density (1/2pi) log(N t^2/(4 pi^2)) per sign, phihat^2 ~ (2 sin(rL/2))^2 * (sum c_j(-1)^j ... )^2: use average
tail = 2 * mpmath.quad(lambda t: mpmath.log(1951 * t * t / (4 * mp.pi ** 2)) / (2 * mp.pi) * phihat(t) ** 2, [146, 300, 1000, mpmath.inf])
print("c^T Q c = %.10f ; zero side (|t|<=146) = %.10f ; + tail estimate %.2e -> %.10f ; diff %.2e" %
      (float(form), float(side), float(tail), float(side + tail), float(form - side - tail)))
