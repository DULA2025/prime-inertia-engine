"""Dipole scan (Dula): how close must a pole at 1/2 + 7.6i sit to an extra zero to keep the restricted Weil form at
X = 1e5, m = 45 positive?  Q + w w^T - v v^T, v = e^(7.6), w = e^(7.6 + delta).  Observed (no dipole): +5.18e-45."""
import json, mpmath
from mpmath import mp, mpf
import weilform as W
X, m, dps = 1e5, 45, 110
Q, L, J, aux = W.build(X, m, dps=dps)
mp.dps = dps
def ehat(r):
    return mpmath.matrix([2 * (-1) ** (j % 2) * mpmath.sin(r * L / 2) / (r + 2 * mp.pi * j / L) for j in J])
gp = mpf("7.6"); v = ehat(gp)
res = {}
for e in (1, 3, 6, 9, 15, 20, 30, 40, 43, 44, 45, 46, 48, 50, 60):
    d = mpf(10) ** (-e)
    w = ehat(gp + d)
    E, V = mpmath.eigsy((Q + w * w.T - v * v.T) / L)
    mu = min(E[i] for i in range(len(J)))
    res[e] = mpmath.nstr(mu, 8)
    print("delta = 1e-%d: min eig %s" % (e, mpmath.nstr(mu, 6)), flush=True)
json.dump(res, open("weil_dipole_scan.json", "w"), indent=1)
