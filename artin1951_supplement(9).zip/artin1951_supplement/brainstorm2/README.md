# brainstorm2/ — Weil quadratic form of L(ρ, s) from primes; p-adic follow-ups (16 Oct 2026)

Author: Dula. Labels: [T] theorem (with the cited inputs), [N] numerical, [C] conjecture, [S] speculation.
Nothing here proves that L(ρ, s) is entire.

## 1. Restricted Weil form (Connes-style), `weilform.py`
Test functions φ on [−L/2, L/2], L = log X, basis e^{iω_j x}, ω_j = 2πj/L, |j| ≤ m. The form
Q(φ) = W(φ∗φ̃) is the explicit-formula functional of L(ρ, s) (conductor 1951, Γ_ℝ(s+1)²); its prime side uses
only n ≤ X, so building Q assumes nothing about holomorphy. If L(ρ, s) is entire, Q(φ) = Σ_γ |φ̂(γ)|² ≥ 0; a
pole would enter with a minus sign. Weil (1972 framework for Artin–Hecke L-functions): positivity for every
support ⟺ L(ρ) entire and GRH for L(ρ).

| file | what |
|---|---|
| `weil_validate.py` | explicit-formula conventions vs the PARI zero list (Gaussian tests, agreement 1e-15) |
| `weil_check_matrix.py` | closed forms of the archimedean integrals vs quadrature (1e-31); cᵀQc vs Σ|φ̂(γ)|² over 553 zeros (3e-11) |
| `weil_run.py X m dps [seed]` | eigenvalues; zeros of the minimiser's Fourier transform vs PARI zeros (`zeros_hp_*.json`) |
| `weil_certify.py X m bits mu0 [vec]` | python-flint/Arb: LDLᵀ of Q − μ₀L·Id in ball arithmetic ⇒ λ_min > μ₀; Rayleigh upper bound |
| `weil_pole_demo.py`, `weil_dipole_scan.py` | signature of an injected pole / pole–zero dipole |
| `pari_hp.py` | PARI zeros of L(ρ, s) at 160/256/420 bits (cypari2 needs `precision=` on every lfun call) |
| `weil_figure.py` → `weil_form_1951.png` | figure |

## 2. p-adic follow-ups, `padic2.py` → `padic2_report.json`
Values L(ρ, 1−n) from `../brainstorm/negvalues.py` (new: n = 181, 217, 289, 361, 397, 433, 469, 1333 in `negE.json`).

## Results
**Weil form** (minimiser zeros vs PARI zeros at 420/160 bits; PARI assumes holomorphy, the minimiser does not):

| primes ≤ X | basis | λ_min(Q/L) | zeros matched | first zero (γ = −1.0364181…) | worst matched |
|---|---|---|---|---|---|
| 10³ | 41 | 2.3·10⁻⁴ | ~10 to < 0.05 | 6·10⁻⁶ | — |
| 10⁴ | 61 | 3.11·10⁻¹⁹ [Arb: > 3.0·10⁻¹⁹] | 40 of 40 in \|γ\| ≤ 16.4 | 1.3·10⁻²⁰ | 8·10⁻⁵ |
| 10⁵ | 91 | 5.18·10⁻⁴⁵ [Arb: (5.1, 5.19)·10⁻⁴⁵] | 49 of 49 in \|γ\| ≤ 19.6 | 2.3·10⁻⁴⁶ | 1.5·10⁻²⁰ |
| 10⁶ | 121 | 1.01·10⁻⁷⁷ [Arb: > 1.0·10⁻⁷⁷] | 57 of 57 in \|γ\| ≤ 21.8 | 5.2·10⁻⁷⁹ | 1.3·10⁻⁴¹ |

- [T, computer-assisted; input: the Frobenius table] At X = 10⁴, 10⁵, 10⁶ the restricted Weil form of L(ρ, s) is
  positive definite on the stated subspace, with the stated lower bounds (python-flint ball LDLᵀ, 300/1600/3000 bits).
- [N] Control: Frobenius labels shuffled (seed 7), X = 10⁴: λ_min = −3.86, −2.49, −1.73, −0.41; zeros not matched.
- [N] Calibration (X = 10⁵): an injected simple pole at 1/2 + 7.6i gives λ_min = −7.9 and the minimiser peaks at 7.6;
  a pole with an extra zero at distance δ gives λ_min < 0 for δ ≥ 10⁻³⁰ (−5.5·10⁻³⁴) and stays positive for
  δ ≤ 10⁻⁴⁰. So at this scale a pole near height 7.6 escapes the test only inside a dipole narrower than ~10⁻³⁸.
- Not a proof of anything about poles: positivity on a finite-dimensional space at one scale is a consequence of
  "entire + GRH", and a narrow enough pole–zero dipole is invisible at any finite scale.

**p-adic** (`padic2_report.json`):
- p = 37 (second trivial-zero prime, inert in Q(ζ₅)): v₃₇(L*(ρ,1−n)) = v₃₇(n−1) + 1 for all 14 n ≡ 1 mod 36 up to
  1333; 91 Kummer pairs tight. Simple zero at s = 0 with unit derivative, as at p = 11 [N].
- 2-adic: every value L(ρ,1−n), n odd 3…1459, is exactly 4 × (2-adic unit), ≡ 4(1+ζ+ζ³) mod 8; differences have
  v₂ = v₂(n−n′) + 4 exactly; continuity reaches E₂(1)L(ρ,0) = 4·(unit) consistently. The 2-adic L-function behaves
  as 4 × (unit power series) [N].
- p = 11: g₁ = dG/dT at T = 0 (L₁₁(ρω, s) = G(12ˢ − 1)) ≡ 513, 1041, 1268, 1186 mod 11³ at ζ₅ ↦ 3, 4, 5, 9,
  consistent across all 22 values [N]. Gross's conjecture relates it to the ρ-isotypic 11-unit of a degree-120 field
  (not computable here).

**Integrality and the factor 4** (`padic3.py` → `padic3_report.json`, `padic3.log`; 16 Oct, audit of a second
outside text):
- E_p(1) = det(1 − ρ(Frob_p)) is a unit for p = 3, 5, 7, 13 (norms 25, 1, 1, 1), so the congruences of Remark 7.4(1)
  can be divided by it [T, exact].
- p = 2: all 2211 pairwise differences have v₂ exactly v₂(n−n′) + 4 (every pair, not only the minimum); PARI's value at
  s = 0 fits, since (z + z²)² = 1 + z + z³ in 𝔽₁₆ [N: the values are identified numerically].
- Normalisation check of the 2-adic factor 2^([F:ℚ]·dim) (Deligne–Ribet; Greenberg, *On p-adic Artin L-functions II*,
  property (9)) in dimension 1 over ℚ: for the 36 odd quadratic χ_d with |d| < 120, d ≠ −4, −8, and n = 1, 3, 5, 7,
  the 2-adic values of χ_d·ω₄ are all even (min v₂ = 1 over 130 non-zero values; 14 trivial zeros). Control: d = −8,
  where χ₈ factors through the cyclotomic ℤ₂-extension, gives v₂ = 0 [T, exact Bernoulli numbers].
- Literature [T, cited]: for odd p the Iwasawa power series of every totally even Artin character has integral
  coefficients (Greenberg's refined conjecture; Ritter–Weiss 2004, Remark (G), as recorded in Forrás, arXiv:2404.15078,
  Thm 3.3; Greenberg, Artin II, §§3–4, from Wiles). Hence L(ρ, 1−n) ∈ ℤ[ζ₅][1/2] for odd n ≥ 3, and λ_p = μ_p = 0 at
  p = 3, 5, 7, 13 once one value is known exactly. At p = 2 the factor 4 = 2^(dim ρ) comes out of Brauer induction;
  that the quotient is a unit power series is unexplained.
