"""p-adic checks for the audit of the second Gemini text (Dula), 16 Oct 2026.

(a) For p = 3, 5, 7, 13 the Euler factor E_p(1) = det(1 - rho(Frob_p)) is a p-adic unit, so the congruences of
    Remark 7.4(1) can be divided by it (they then concern L(rho, 0) itself).
(b) p = 2: every value L*(n) = E_2(n) L(rho, 1-n) (n odd, 3 <= n <= 1459) has v_2 exactly 2, all L*(n)/4 have the
    same residue 1 + z + z^3 in F_16 = Z[zeta5]/2, and EVERY pair (not only the minimum) has
    v_2(L*(n) - L*(n')) = v_2(n - n') + 4.  This is the pattern of 4 * u(T), u a unit power series with unit linear
    coefficient, T = 5^s - 1.  The value at n = 1 (pari's L(rho,0) = -4(z + z^2), which assumes holomorphy) fits:
    E_2(1) L(rho,0)/4 = (z + z^2)^2 = 1 + z + z^3 in F_16.
(c) Normalisation check of the 2-adic factor 2^{[F:Q] dim} (Deligne-Ribet; Greenberg, p-adic Artin L-functions II,
    property (9)) in dimension 1 over Q: for even psi = chi_d omega_4 (chi_d odd quadratic, psi not factoring through
    Gal(Q_infty/Q)), L_2(1-n, psi) = (1 - chi_d(2) 2^(n-1)) (-B_{n,chi_d}/n) is divisible by 2 for odd n; the type-W
    control psi = chi_8 (d = -8) is not.
Values: brainstorm/neg[A-E].json (67 odd n; negE.json is also in brainstorm2/), exact Z[zeta5] coordinates."""
import sys, json, glob
sys.set_int_max_str_digits(0)
sys.path.insert(0, "/home/claude/research/brainstorm")
from fractions import Fraction
from math import comb
from q5 import *
T, D = load()
vals = {}
for f in sorted(glob.glob("/home/claude/research/brainstorm/neg[A-E].json")):
    for k, o in json.load(open(f)).items():
        assert o["denominator"] == 1
        vals[int(k)] = tuple(int(Fraction(c)) for c in o["coords"])
assert len(vals) == 67
def vp_int(x, p):
    if x == 0: return 10 ** 9
    v = 0
    while x % p == 0: x //= p; v += 1
    return v
def vinert(x, p): return min(vp_int(c, p) for c in x)
def Ep(p, n):
    a = ap(1, p, T); d = detp(1, p)
    return add(sub(ONE, scal(p ** (n - 1), a)), scal(p ** (2 * n - 2), d))
out = {}
# (a)
ra = {}
for p in (3, 5, 7, 13):
    e = Ep(p, 1); nm = norm(e)
    ra[p] = {"E_p(1)": e, "norm": nm, "v_p(norm)": vp_int(nm, p)}
    print("(a) p = %-2d  E_p(1) = %-16s  norm = %-5d  v_p(norm) = %d" % (p, e, nm, vp_int(nm, p)))
assert all(r["v_p(norm)"] == 0 for r in ra.values())
out["a_euler_units"] = {str(p): r for p, r in ra.items()}
# (b)
Ls = {n: mul(Ep(2, n), vals[n]) for n in vals}
v2 = {n: vinert(x, 2) for n, x in Ls.items()}
res = {n: tuple((c >> 2) & 1 for c in x) for n, x in Ls.items()}
ns = sorted(Ls)
bad = []; npairs = 0
for i, n in enumerate(ns):
    for n2 in ns[i + 1:]:
        npairs += 1
        if vinert(sub(Ls[n], Ls[n2]), 2) != vp_int(n2 - n, 2) + 4: bad.append((n, n2))
L0 = (0, -4, -4, 0)
Ls1 = mul(Ep(2, 1), L0)
res1 = tuple((c >> 2) & 1 for c in Ls1)
pairs1 = [(n, vinert(sub(Ls1, Ls[n]), 2), vp_int(n - 1, 2) + 4) for n in ns]
bad1 = [t for t in pairs1 if t[1] != t[2]]
zz = add((0, 1, 0, 0), (0, 0, 1, 0))
sq = tuple(c & 1 for c in mul(zz, zz))
print("(b) v_2(L*(n)) over the 67 values: %s; residues of L*(n)/4 mod 2: %s" % (sorted(set(v2.values())), sorted(set(res.values()))))
print("    pairs with v_2(L*(n) - L*(n')) != v_2(n - n') + 4: %d of %d" % (len(bad), npairs))
print("    n = 1 (pari's L(rho,0)): v_2(E_2(1) L(rho,0)) = %d, residue %s; (z + z^2)^2 mod 2 = %s; mismatched pairs with n = 1: %d of %d"
      % (vinert(Ls1, 2), res1, sq, len(bad1), len(pairs1)))
assert set(v2.values()) == {2} and len(set(res.values())) == 1 and not bad and not bad1
assert res1 == sq == list(res.values())[0] == (1, 1, 0, 1)
out["b_two_adic"] = {"v2": sorted(set(v2.values())), "residue": list(res.values())[0], "pairs": npairs, "pairs_exact": npairs - len(bad),
                     "n1_residue": res1, "n1_pairs_exact": len(pairs1) - len(bad1)}
# (c)
def bern_numbers(m):
    B = [Fraction(0)] * (m + 1); B[0] = Fraction(1)
    for k in range(1, m + 1):
        B[k] = -sum(comb(k + 1, j) * B[j] for j in range(k)) / (k + 1)
    return B
BN = bern_numbers(12)
def bern_poly(n, x): return sum(comb(n, k) * BN[k] * x ** (n - k) for k in range(n + 1))
def kronecker(d, a):
    if a == 0: return 1 if abs(d) == 1 else 0
    r = 1
    if a < 0: a = -a; r = -1 if d < 0 else 1
    while a % 2 == 0:
        a //= 2
        if d % 2 == 0: return 0
        r *= 1 if d % 8 in (1, 7) else -1
    # Jacobi symbol (d / a), a odd positive
    dd = d % a; aa = a; j = 1
    while dd:
        while dd % 2 == 0:
            dd //= 2
            if aa % 8 in (3, 5): j = -j
        dd, aa = aa, dd
        if dd % 4 == 3 and aa % 4 == 3: j = -j
        dd %= aa
    return r * j if aa == 1 else 0
def gen_bern(n, d):
    f = abs(d)
    return Fraction(f) ** (n - 1) * sum(kronecker(d, a) * bern_poly(n, Fraction(a, f)) for a in range(1, f + 1))
def v2q(x):
    if x == 0: return None
    x = Fraction(x); return vp_int(x.numerator, 2) - vp_int(x.denominator, 2)
fund = [d for d in range(-3, -120, -1) if (d % 4 == 1 and all(d % (q * q) for q in range(3, 12, 2))) or
        (d % 4 == 0 and (d // 4) % 4 in (2, 3) and all((d // 4) % (q * q) for q in range(3, 12, 2)))]
rows = []
for d in fund:
    for n in (1, 3, 5, 7):
        L2 = (1 - kronecker(d, 2) * 2 ** (n - 1)) * (-gen_bern(n, d) / n)
        rows.append((d, n, v2q(L2)))
typeS = [r for r in rows if r[0] not in (-4, -8)]
nz = [r[2] for r in typeS if r[2] is not None]
ctrl = [r for r in rows if r[0] == -8]
print("(c) %d fundamental d < 0 with |d| < 120 (d != -4, -8), n = 1, 3, 5, 7: min v_2 = %d over %d non-zero values (%d trivial zeros);"
      % (len({r[0] for r in typeS}), min(nz), len(nz), sum(r[2] is None for r in typeS)))
print("    control d = -8 (psi = chi_8 factors through Gal(Q_infty/Q)): v_2 = %s" % [r[2] for r in ctrl])
assert min(nz) == 1 and ctrl[0][2] == 0
out["c_dirichlet"] = {"n_chars": len({r[0] for r in typeS}), "min_v2": min(nz), "values": len(nz), "control_d-8": [r[2] for r in ctrl]}
json.dump(out, open("padic3_report.json", "w"), indent=1, default=str)
print("ALL CHECKS PASS")
