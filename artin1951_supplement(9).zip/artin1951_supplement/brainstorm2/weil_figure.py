"""Figure for the restricted Weil form of L(rho, s) (Dula).  Palette: dataviz reference instance (light surface),
ordinal blue ramp 250/400/550/700 for the four prime cutoffs (validated --ordinal), slot 1 blue / slot 2 orange for
single series; text in ink tokens."""
import json, math, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
SURF, INK, INK2, MUTED, GRID, BASE = "#fcfcfb", "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
RAMP = ["#86b6ef", "#3987e5", "#1c5cab", "#0d366b"]
BLUE, ORANGE = "#2a78d6", "#eb6834"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": BASE, "axes.labelcolor": INK2,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.facecolor": SURF, "figure.facecolor": SURF})
runs = [("1e+03", "weil_X1000_m20_dps50_s0.json"), ("1e+04", "weil_X10000_m30_dps60_s0.json"),
        ("1e+05", "weil_X100000_m45_dps90_s0.json"), ("1e+06", "weil_X1e+06_m60_dps130_s0.json")]
fig, ax = plt.subplots(1, 3, figsize=(15.5, 4.9), gridspec_kw={"width_ratios": [1.35, 1, 1]})
a = ax[0]
for (lab, f), col in zip(runs, RAMP):
    d = json.load(open(f))
    pts = sorted((z, -math.log10(max(df, 1e-300))) for z, g, df in d["zeros"] if df < 0.05)
    a.plot([p[0] for p in pts], [p[1] for p in pts], "-o", color=col, lw=1.6, ms=4.2, mec=SURF, mew=0.8,
           label="primes ≤ 10%s  (%d zeros)" % ("³⁴⁵⁶"[int(lab[-1]) - 3], len(pts)))
    top = max(pts, key=lambda p: p[1])
    a.annotate("X = 10%s" % "³⁴⁵⁶"[int(lab[-1]) - 3], (top[0], top[1]), textcoords="offset points", xytext=(6, 3), color=INK2, fontsize=8)
a.set_xlabel("zero of L(ρ, s) at 1/2 + iγ:  γ")
a.set_ylabel("matching digits:  −log₁₀ |minimiser zero − PARI zero|")
a.set_title("Zeros of L(ρ,s) recovered from the first primes alone\n(minimiser of the restricted Weil form; no holomorphy assumed)",
            fontsize=10, color=INK, loc="left")
a.legend(frameon=False, fontsize=8, loc="upper left", labelcolor=INK2)
a.grid(color=GRID, lw=0.6); a.set_ylim(0, 102)
b = ax[1]
X = [3, 4, 5, 6]; lam = [2.34259e-4, 3.11404e-19, 5.18113e-45, 1.00720e-77]
cert = [False, True, True, None]
try:
    c6 = json.load(open("weil_cert_X1000000_m60.json")); cert[3] = c6.get("certified_lambda_min_gt_mu0", False)
except Exception:
    cert[3] = False
b.plot(X, [math.log10(v) for v in lam], "-", color=BLUE, lw=1.6, zorder=1)
for x, v, c in zip(X, lam, cert):
    b.plot([x], [math.log10(v)], "o", ms=7, color=BLUE if c else SURF, mec=BLUE, mew=1.6, zorder=2)
    b.annotate("%.1e" % v + ("  (Arb)" if c else ""), (x, math.log10(v)), textcoords="offset points", xytext=(7, 4),
               color=INK2, fontsize=8)
b.set_xticks(X); b.set_xticklabels(["10³", "10⁴", "10⁵", "10⁶"])
b.set_xlabel("prime cutoff X  (test functions supported in |x| ≤ ½ log X)")
b.set_ylabel("log₁₀ of the smallest eigenvalue λ_min(Q/L)")
b.set_title("Weil positivity at each scale: λ_min > 0\n(filled = certified in ball arithmetic)", fontsize=10, color=INK, loc="left")
b.text(0.03, 0.06, "control, X = 10⁴, Frobenius labels shuffled:\nλ_min = −3.86 (not positive; zeros not matched)",
       transform=b.transAxes, color=INK2, fontsize=8)
b.grid(color=GRID, lw=0.6); b.set_xlim(2.7, 6.6)
c = ax[2]
try:
    ds = json.load(open("weil_dipole_scan.json"))
except Exception:
    ds = {}
xs_neg, ys_neg, xs_pos, ys_pos = [], [], [], []
for e, s in sorted(ds.items(), key=lambda t: int(t[0])):
    v = float(s)
    if v < 0: xs_neg.append(-int(e)); ys_neg.append(math.log10(-v))
    else: xs_pos.append(-int(e)); ys_pos.append(math.log10(v))
c.plot(xs_neg, ys_neg, "-o", color=ORANGE, lw=1.6, ms=6, mec=SURF, mew=0.8, label="λ_min < 0: plotted |λ_min|")
if xs_pos:
    c.plot(xs_pos, ys_pos, "s", color=SURF, mec=ORANGE, mew=1.6, ms=6, label="λ_min > 0 (dipole invisible)")
obs = math.log10(5.18113e-45)
c.axhline(obs, color=MUTED, lw=1, ls="--")
c.text(-61, obs + 1.6, "observed λ_min = +5.2·10⁻⁴⁵ (no dipole added)", color=INK2, fontsize=8)
c.set_xlabel("log₁₀ δ  (pole at 1/2 + 7.6i, extra zero at 1/2 + (7.6+δ)i)")
c.set_ylabel("log₁₀ |λ_min| of the form with the dipole added")
c.set_title("What a hidden pole would cost (X = 10⁵)\nsimple pole alone: λ_min = −7.9", fontsize=10, color=INK, loc="left")
c.legend(frameon=False, fontsize=8, loc="upper left", labelcolor=INK2)
c.grid(color=GRID, lw=0.6)
for s in ("top", "right"):
    for a_ in ax: a_.spines[s].set_visible(False)
fig.suptitle("L(ρ,s), ρ even icosahedral of conductor 1951: Connes-style restricted Weil form from the Euler product",
             fontsize=11, color=INK, x=0.01, ha="left")
fig.tight_layout()
fig.savefig("weil_form_1951.png", dpi=150)
print("saved weil_form_1951.png")
