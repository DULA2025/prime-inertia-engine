"""Validate sign conventions of the explicit formula for L(rho, s) (Dula).
Lambda(s) = 1951^{s/2} Gamma_R(s+1)^2 L(rho, s);  zeros 1/2 + i gamma.
For g with ghat(r) = int g(x) e^{irx} dx:
  sum_gamma ghat(gamma) = (1/2pi) int ghat(r) K(r) dr - sum_n n^{-1/2} [Lam(n) g(log n) + conj(Lam(n)) g(-log n)]
  K(r) = log 1951 - 2 log pi + 2 Re psi(3/4 + i r/2),   Lam(p^k) = (alpha^k + beta^k) log p.
Test: g(x) = exp(-x^2/(2 s^2)) cos(t0 x) (several s, t0) against the zero list x3_zeros_T25.json
(PARI, assuming holomorphy, |gamma| <= 25)."""
import sys, json, math, cmath
sys.path.insert(0, "/home/claude/research/brainstorm")
import numpy as np, mpmath
from q5 import *
T, D = load()
z5 = [cmath.exp(2j * math.pi * k / 5) for k in range(5)]
def emb(a): return a[0] + a[1] * z5[1] + a[2] * z5[2] + a[3] * z5[3]
def Lam_list(X):
    out = []
    for p in sorted(list(T) + [N]):
        if p > X: break
        if p == N:
            al, be = emb(zpow(2)), 0.0
        else:
            a = emb(ap(1, p, T)); d = emb(detp(1, p))
            disc = cmath.sqrt(a * a - 4 * d); al, be = (a + disc) / 2, (a - disc) / 2
        q, k = p, 1
        while q <= X:
            out.append((q, (al ** k + be ** k) * math.log(p))); q *= p; k += 1
    return out
Z = json.load(open("/home/claude/research/overnight/x3_zeros_T25.json"))["rho"]
K = lambda r: math.log(N) - 2 * math.log(math.pi) + 2 * float(mpmath.re(mpmath.digamma(0.75 + 0.5j * r)))
lam = Lam_list(10 ** 6)
for s, t0 in ((0.5, 0.0), (0.5, 3.0), (0.7, 6.0), (1.0, 2.0)):
    g = lambda x: math.exp(-x * x / (2 * s * s)) * math.cos(t0 * x)
    gh = lambda r: math.sqrt(2 * math.pi) * s * 0.5 * (math.exp(-(r - t0) ** 2 * s * s / 2) + math.exp(-(r + t0) ** 2 * s * s / 2))
    arch = float(mpmath.quad(lambda r: gh(r) * K(r), [-60, -20, 0, 20, 60])) / (2 * math.pi)
    prime = -sum((L * g(math.log(n)) + L.conjugate() * g(-math.log(n))) / math.sqrt(n) for n, L in lam).real
    zs = sum(gh(gm) for gm in Z)
    print("s=%.2f t0=%.1f   zeros side %.12f   arch %.6f  prime %.6f  sum %.12f   diff %.2e" % (s, t0, zs, arch, prime, arch + prime, zs - arch - prime))
