"""Ball-arithmetic certificate (python-flint / Arb) for the restricted Weil form of L(rho, s) (Dula).

Rebuilds Q (weilform.py conventions) with every quantity an Arb ball:
  * prime side: exact Lam(n)/log p in Z[zeta5] (power sums from the Frobenius labels), embedded with zeta5 = e^{2 pi i/5};
  * archimedean side: closed forms with acb digamma/trigamma and the exponentially small k-sums, tails bounded
    geometrically (ratio e^{-2L});
then runs an LDL^T factorisation of Q - mu0 L Id in ball arithmetic.  If every pivot is certified > 0, then
Q - mu0 L Id is positive definite for every matrix in the balls, i.e. lambda_min(Q/L) > mu0 [T, computer-assisted].
An upper bound comes from the Rayleigh quotient of a rounded eigenvector (also in balls).
usage: python3 weil_certify.py X m prec_bits mu0 [vecfile]"""
import sys, json, time
sys.path.insert(0, "/home/claude/research/brainstorm")
from flint import arb, acb, ctx
import weilform as W
X = int(float(sys.argv[1])); m = int(sys.argv[2]); ctx.prec = int(sys.argv[3]); mu0 = arb(sys.argv[4])
t0 = time.time()
Nn = arb(1951)
L = arb(X).log()
pi = arb.pi()
zeta = (acb(0, 1) * 2 * pi / 5).exp()
zp = [acb(1), zeta, zeta ** 2, zeta ** 3]
lst = W.lam_exact(X)
c, u, ell = [], [], []
for n, v, p in lst:
    ln = arb(n).log()
    val = sum((zp[i] * v[i] for i in range(4) if v[i]), acb(0))
    c.append(val * arb(p).log() / arb(n).sqrt()); ell.append(ln)
    u.append((acb(0, 1) * 2 * pi * ln / L).exp())
J = list(range(-m, m + 1))
P, P1 = {}, {}
pw = [acb(1)] * len(c)
P[0] = sum(c, acb(0)); P1[0] = sum((a * b for a, b in zip(c, ell)), acb(0))
for j in range(1, m + 1):
    pw = [a * b for a, b in zip(pw, u)]
    P[j] = sum((a * b for a, b in zip(c, pw)), acb(0)); P1[j] = sum((a * b * w for a, b, w in zip(c, ell, pw)), acb(0))
    cw = [w.conjugate() for w in pw]
    P[-j] = sum((a * b for a, b in zip(c, cw)), acb(0)); P1[-j] = sum((a * b * w for a, b, w in zip(c, ell, cw)), acb(0))
w = {j: 2 * pi * j / L for j in J}
eg = arb.const_euler()
q = (-2 * L).exp()                                   # ratio of the k-sums
def geo_tail(first):                                 # bound sum_{k>=K} of terms <= first * q^(k-K)
    return arb(0, (first / (1 - q)).upper())
import math
K = int(math.ceil(ctx.prec * math.log(2) / (2 * float(L.mid())))) + 3     # k-sum terms: tail below 2^-prec
def Is(om):
    z = acb(arb(3) / 4, om / 2)
    s = z.digamma().imag / 2
    for k in range(K):
        a = arb(3) / 2 + 2 * k
        s -= (-a * L).exp() * om / (a * a + om * om)
    a = arb(3) / 2 + 2 * K
    return s + geo_tail(((-a * L).exp() / a).abs_upper() if True else 0)
def Ic(om):
    z = acb(arb(3) / 4, om / 2)
    s = L / 2 * (z.digamma().real + eg) + z.polygamma(1).real / 4
    for k in range(K):
        b = 2 * k + 2; zz = acb(arb(2 * k) + arb(3) / 2, -om)
        s -= L * (-b * L).exp() / b + ((-(arb(2 * k) + arb(3) / 2) * L).exp() / zz ** 2).real
    b = 2 * K + 2
    return s + geo_tail((L * (-b * L).exp() / b + (-(arb(2 * K) + arb(3) / 2) * L).exp()).abs_upper())
Isv = {j: Is(w[j]) for j in J}; Icv = {j: Ic(w[j]) for j in J}
base = L * (Nn.log() - 2 * pi.log() - 2 * eg) - 2 * L * (1 - (-2 * L).exp()).log()
n = len(J)
Q = [[None] * n for _ in range(n)]
for a, j in enumerate(J):
    for b, k in enumerate(J):
        if j == k:
            Q[a][b] = base + 4 * Icv[j] - 2 * (L * P[j] - P1[j]).real
        elif b > a:
            sg = -1 if (j - k) % 2 else 1
            d = w[j] - w[k]
            Q[a][b] = -4 * sg * (Isv[k] - Isv[j]) / d - 2 * sg * (P[k] - P[j]).imag / d
            Q[b][a] = Q[a][b]
print("built ball matrix %dx%d (X=%d, %d prime powers, prec %d) in %.0fs; max radius %.1e" %
      (n, n, X, len(c), ctx.prec, time.time() - t0, max(float(x.rad()) for row in Q for x in row)), flush=True)
# LDL^T of Q - mu0 L I
A = [[Q[i][j] - (mu0 * L if i == j else 0) for j in range(n)] for i in range(n)]
Lm = [[arb(0)] * n for _ in range(n)]; Dv = [arb(0)] * n
ok = True; minpiv = None
for i in range(n):
    s = A[i][i] - sum((Lm[i][k] ** 2 * Dv[k] for k in range(i)), arb(0))
    Dv[i] = s
    if not (s > 0):
        ok = False; print("pivot %d not certified positive: %s" % (i, s.str(5))); break
    minpiv = s if minpiv is None or s.upper() < minpiv.upper() else minpiv
    for jj in range(i + 1, n):
        Lm[jj][i] = (A[jj][i] - sum((Lm[jj][k] * Lm[i][k] * Dv[k] for k in range(i)), arb(0))) / s
res = {"X": X, "m": m, "prec": ctx.prec, "mu0": sys.argv[4], "certified_lambda_min_gt_mu0": ok,
       "min_pivot": minpiv.str(8) if minpiv is not None else None, "secs": round(time.time() - t0)}
print("lambda_min(Q/L) > %s certified: %s   (smallest pivot %s)" % (sys.argv[4], ok, minpiv.str(8) if minpiv is not None else None))
if len(sys.argv) > 5:
    vec = [arb(x) for x in json.load(open(sys.argv[5]))]
    num = sum((vec[a] * Q[a][b] * vec[b] for a in range(n) for b in range(n)), arb(0))
    den = L * sum((x * x for x in vec), arb(0))
    rq = num / den
    res["rayleigh_upper"] = rq.str(8)
    print("Rayleigh quotient of the rounded minimiser (upper bound for lambda_min): %s" % rq.str(8))
json.dump(res, open("weil_cert_X%d_m%d.json" % (X, m), "w"), indent=1)
