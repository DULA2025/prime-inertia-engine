"""What a pole would do to the restricted Weil form (Dula).  If L(rho,s) had a pole at 1/2 + i g_p, the true form would
be Q_true = Q_entire - v v^T with v_j = e_j^(g_p) (the explicit formula counts poles with a minus sign).  Our Q is
computed from primes and so already IS the true form; this script shows the signature of a pole by adding one by hand
(and of a pole-zero dipole: + w w^T - v v^T, w = e^(g_p + delta)), to calibrate what positivity of the computed Q
excludes."""
import sys, json, mpmath
from mpmath import mp, mpf
import weilform as W
X, m, dps = 1e5, 45, 90
Q, L, J, aux = W.build(X, m, dps=dps)
mp.dps = dps
def ehat(r):
    return mpmath.matrix([2 * (-1) ** (j % 2) * mpmath.sin(r * L / 2) / (r + 2 * mp.pi * j / L) for j in J])
def minev(M):
    E, V = mpmath.eigsy(M / L)
    i = min(range(len(J)), key=lambda k: E[k])
    return E[i], [V[a, i] for a in range(len(J))]
res = {}
mu0, _ = minev(Q)
print("no pole: min eig %s" % mpmath.nstr(mu0, 6))
gp = mpf("7.6")
v = ehat(gp)
mu, c = minev(Q - v * v.T)
eta = lambda r: W.etahat(c, J, L, r)
grid = [mpf(x) / 10 for x in range(-180, 181)]
peak = max(grid, key=lambda r: abs(eta(r)))
print("simple pole at 7.6 (between zeros 7.2563 and 7.9531): min eig %s, |eta^| peaks at r = %s" % (mpmath.nstr(mu, 6), mpmath.nstr(peak, 4)))
res["pole_7.6"] = {"min_eig": mpmath.nstr(mu, 8), "peak": float(peak)}
for d in ("1e-1", "1e-2", "1e-3", "1e-4", "1e-6", "1e-9"):
    w = ehat(gp + mpf(d))
    mu, _ = minev(Q + w * w.T - v * v.T)
    print("dipole: pole at 7.6, extra zero at 7.6 + %s: min eig %s" % (d, mpmath.nstr(mu, 6)))
    res["dipole_" + d] = mpmath.nstr(mu, 8)
# a pole placed exactly on a zero cancels it (order 0): positivity then only loses that zero
z0 = mpf("7.256310531753243")
mu, _ = minev(Q - ehat(z0) * ehat(z0).T)
print("pole exactly at the zero 7.2563 (cancels it): min eig %s" % mpmath.nstr(mu, 6))
res["pole_on_zero"] = mpmath.nstr(mu, 8)
json.dump(res, open("weil_pole_demo.json", "w"), indent=1)
