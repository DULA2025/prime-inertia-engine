"""High-precision zeros of L(rho, s) with PARI (assuming holomorphy, as every PARI lfun computation does).
cypari2 lfun* calls default to 53 bits: pass precision= explicitly."""
import sys, json, cypari2
sys.path.insert(0, "/home/claude/research/brainstorm")
from q5 import *
from rootnum import coeffs
pari = cypari2.Pari(); pari.allocatemem(3 * 10**9)
B = int(sys.argv[1]) if len(sys.argv) > 1 else 256
T = float(sys.argv[2]) if len(sys.argv) > 2 else 12
pari.set_real_precision_bits(B)
z = pari("exp(2*Pi*I/5)")
tau = pari("sum(x=1,1950, exp(2*Pi*I*((2*znlog(x,Mod(3,1951)))%5)/5)*exp(2*Pi*I*x/1951))")
W = -z ** 3 * tau / pari("sqrt(1951)")
L0 = pari.lfuncreate([pari("[1]"), 1, [1, 1], 1, N, W])
need = int(pari.lfunthetacost(L0, precision=B))
M = need + 100
print("bits", B, "theta cost", need, flush=True)
a = coeffs(1, M)
v = pari.vector(M, [x[0] + x[1] * z + x[2] * z ** 2 + x[3] * z ** 3 for x in a[1:]])
L = pari.lfuncreate([v, 1, [1, 1], 1, N, W])
print("checkfeq bits", pari.lfuncheckfeq(L, precision=B))
print("|L(rho,0) + 4(z+z^2)| =", pari.abs(pari.lfun(L, 0, precision=B) + 4 * (z + z ** 2)))
Li = pari.lfuninit(L, [0.5, 0, T + 1], precision=B)
zs = pari.lfunzeros(Li, [-T, T], precision=B)
out = [str(x) for x in zs]
print(len(out), out[:3])
json.dump({"bits": B, "T": T, "zeros": out}, open("zeros_hp_B%d_T%g.json" % (B, T), "w"), indent=0)
