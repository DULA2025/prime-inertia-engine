"""Least certifying prime for Theorem B over each imaginary quadratic field of discriminant -d, d <= 100.
A prime p certifies that rho0 mod sqrt5 is not (twist of) E'[5] over K0 = Q(sqrt(-d)) if
  p splits in K0, p = +-2 mod 5 (omega5(Frob) a non-square) and t_p != 0 mod sqrt5 (projective order != 2).
Any such Frobenius g gives tr(rhobar (x) psi)(g) = tbar_p * psi(g) with psi(g)^2 = p a non-square in F5, so the trace is not
in F5: a contradiction.  No reduction hypothesis on E' is needed, so p = 2, 3 are allowed (p = 5, 1951 are excluded).
Output: m5_least_primes.json = [[disc, least p, A5 class of Frob_p], ...].   Author: Dula."""
import json
from sympy import primerange
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
def is_fund(D0):
    # fundamental discriminants D0 < 0
    if D0 % 4 == 1:
        m = -D0
        return all(m % (q * q) for q in range(2, int(m ** .5) + 1))
    if D0 % 4 == 0:
        m = D0 // 4
        if m % 4 not in (2, 3): return False
        m = -m
        return all(m % (q * q) for q in range(2, int(m ** .5) + 1))
    return False
def splits(D0, p):
    if p == 2: return D0 % 8 == 1
    return pow(D0 % p, (p - 1) // 2, p) == 1
def tbar_nonzero(t): return abs(t) > 1e-9
out = []
for d in range(3, 101):
    D0 = -d
    if not is_fund(D0): continue
    for p in primerange(2, 10**5):
        if p in (5, 1951) or str(p) not in D["t"]: continue
        if splits(D0, p) and p % 5 in (2, 3) and tbar_nonzero(D["t"][str(p)]):
            out.append([D0, p, D["cls"][str(p)]]); break
json.dump(out, open("m5_least_primes_check.json", "w"))
print(len(out), "fields; max least prime", max(r[1] for r in out))
old = json.load(open("m5_least_primes.json"))
print("matches saved m5_least_primes.json:", out == old)
