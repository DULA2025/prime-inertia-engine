"""Can rho-bar = rho0 mod sqrt5 (image SL2(F5), det 1) come from an elliptic curve over a quadratic field K'?
E'[5] (x) F5bar = rho-bar (x) psi  forces psi^2 = omega5 (Weil pairing), and the traces t-bar_p * psi(Frob_P) must lie in F5.
Witness of impossibility over K' (Chebotarev): a prime p split in K' with p = 2, 3 mod 5 (omega5(Frob_P) a non-square, so
psi(Frob_P) is not in F5) and t_p != 0 mod sqrt5 (t-bar_p in F5*).  Then t-bar_p * psi(Frob_P) is not in F5: contradiction.
Expected density of witnesses among split primes: P(omega5 non-square) * P(projective order != 2) = 1/2 * 45/60 = 3/8,
provided the joint image of (rho-bar, omega5) on G_K' is SL2(F5) x F5* (true when sqrt5 is not in K').
Contrast: F = Q(i, sqrt5) -- primes of degree 1 in F are = +-1 mod 5, so omega5 is always a square: no witnesses.
Author: Dula."""
import json, math
from sympy import jacobi_symbol, primerange
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
PHI = (1 + 5 ** .5) / 2
def tbar(t):                                  # t_p mod sqrt5 (phi -> 3): values in F5
    for val, r in ((2, 2), (-2, 3), (0, 0), (1, 1), (-1, 4), (PHI, 3), (-PHI, 2), (PHI - 1, 2), (1 - PHI, 3)):
        if abs(t - val) < 1e-9: return r
    raise ValueError(t)
def kron(dK, p): return jacobi_symbol(dK % p, p) if p > 2 else (1 if dK % 8 == 1 else (-1 if dK % 8 == 5 else 0))
fields = {"Q(i)": -4, "Q(sqrt-2)": -8, "Q(sqrt-3)": -3, "Q(sqrt-7)": -7, "Q(sqrt-11)": -11, "Q(sqrt-19)": -19,
          "Q(sqrt-43)": -43, "Q(sqrt-67)": -67, "Q(sqrt-163)": -163, "Q(sqrt-5)": -20, "Q(sqrt-1951)": -1951, "Q(sqrt-15)": -15}
primes = [p for p in primerange(7, 3200000) if p != 1951 and str(p) in D["t"]]
out = {}
for name, dK in fields.items():
    split = wit = 0; first = None
    for p in primes:
        if dK % p == 0 or kron(dK, p) != 1: continue
        split += 1
        tb = tbar(D["t"][str(p)])
        if p % 5 in (2, 3) and tb != 0:
            wit += 1
            if first is None: first = dict(p=p, cls=D["cls"][str(p)], t=D["t"][str(p)], tbar=tb, omega5=p % 5)
    out[name] = dict(disc=dK, split=split, witnesses=wit, density=wit / split, first=first)
    print("%-13s split primes %7d  witnesses %7d  density %.4f (3/8 = 0.375)   first: p=%d class %s  tbar=%d  omega5(p)=%d" %
          (name, split, wit, wit / split, first["p"], first["cls"], first["tbar"], first["omega5"]))
# F = Q(i, sqrt5): degree-1 primes are p = 1, 9 mod 20
spl = [p for p in primes if p % 20 in (1, 9)]
wF = sum(1 for p in spl if p % 5 in (2, 3) and tbar(D["t"][str(p)]) != 0)
out["F=Q(i,sqrt5)"] = dict(split=len(spl), witnesses=wF, density=wF / len(spl))
print("F = Q(i,sqrt5): degree-1 primes %d, witnesses %d (omega5 = +-1 on all of them)" % (len(spl), wF))
json.dump(out, open("/home/claude/research/mod5/m5_quadratic.json", "w"), indent=1)
