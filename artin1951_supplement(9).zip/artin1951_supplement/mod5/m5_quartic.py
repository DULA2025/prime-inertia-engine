"""Existence of the twist psi over CM quartic fields K containing sqrt5.
omega5|G_K is the quadratic character of K(zeta5) = K(sqrt(delta)), delta = -(10 + 2 sqrt5)  [since (zeta5 - zeta5^-1)^2 = -(5+sqrt5)/2].
psi: G_K -> F5* with psi^2 = omega5 exists iff K(sqrt delta)/K embeds in a cyclic quartic extension iff the quaternion
algebra (delta, -1)_K splits.  Over Q(sqrt5) we compute the local symbols at every place where they can be non-trivial
(above 2 and 5; the real places by signs) and then the global symbol over several CM quartic K = Q(sqrt5)(sqrt gamma).
Author: Dula."""
import json, cypari2
pari = cypari2.Pari(); pari.allocatemem(10**9)
K2 = pari.nfinit("t^2-5"); delta = pari("-10-2*t")
assert pari.nfeltnorm(K2, delta) == 80
loc = {}
for p in (2, 5):
    for pr in pari.idealprimedec(K2, p):
        loc["p=%d e=%d f=%d" % (p, int(pr[2]), int(pr[3]))] = int(pari.nfhilbert(K2, delta, -1, pr))
emb = [float(x) for x in pari.nfeltembed(K2, delta)]
loc["real places (signs of delta)"] = emb
glob_Q5 = int(pari.nfhilbert(K2, delta, -1))
print("over Q(sqrt5): local symbols (delta,-1)_v:", loc, " global:", glob_Q5)
print("  -> ramified exactly at the two real places (delta < 0 at both, -1 < 0); split at every finite place")
# CM quartic fields K = Q(sqrt5)(sqrt gamma), gamma totally negative
cands = {"F = Q(i,sqrt5)": "-1", "Q(sqrt5,sqrt-2)": "-2", "Q(sqrt5,sqrt-3)": "-3", "Q(sqrt5,sqrt-7)": "-7",
         "Q(sqrt5,sqrt-11)": "-11", "Q(sqrt5,sqrt-1951)": "-1951", "Q(zeta5)": "-10-2*t",
         "Q(sqrt5)(sqrt(-4-sqrt5)) [non-Galois, D4]": "-4-t", "Q(sqrt5)(sqrt(-5-sqrt5)) [cyclic]": "-5-t"}
res = {}
for name, g in cands.items():
    gam = pari(g)
    em = [float(x) for x in pari.nfeltembed(K2, gam)]
    assert all(x < 0 for x in em), (name, em)
    rel = pari.rnfequation(K2, pari("x^2 - (%s)" % g).subst("t", pari("t")), 1)
    pol = pari.substpol(pari.polredabs(rel[0]), "x", "y"); K = pari.nfinit(pol)
    # map t (sqrt5) and delta into K
    r5 = pari.nfroots(K, "x^2-5")[0]
    dK = pari.nfalgtobasis(K, pari("-10") - 2 * pari.nfbasistoalg(K, r5))
    h = int(pari.nfhilbert(K, dK, -1))
    zeta_in = len(pari.nfroots(K, "x^4+x^3+x^2+x+1")) > 0
    gal = int(pari.polgalois(pari.substpol(pol, "y", "x"))[0])
    res[name] = dict(poly=str(pol), galois_order=gal, zeta5_in_K=zeta_in, hilbert_delta_minus1=h)
    print("%-42s poly %-28s |Gal(closure)| = %2d  zeta5 in K: %-5s  (delta,-1)_K = %+d  -> psi exists" %
          (name, str(pol), gal, zeta_in, h))
json.dump(dict(Q5_local=loc, Q5_global=glob_Q5, quartics=res), open("/home/claude/research/mod5/m5_quartic.json", "w"), indent=1)
