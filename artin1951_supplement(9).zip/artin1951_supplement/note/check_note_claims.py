"""Exact checks of the smaller computational statements in the note
"The even icosahedral representation of conductor 1951" (Notation, Sections 3-9; Section 3 checks added 19 Oct 2026,
Section 8 checks added 20 Oct 2026; Question 3 checks added 21 Oct 2026).
Each line prints PASS/FAIL. Needs cypari2 (PARI/GP). Runs in about a minute.
Author: Dula."""
import os, sys
import cypari2
sys.set_int_max_str_digits(0)
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
results = []
def check(name, ok):
    results.append(bool(ok)); print("%s  %s" % ("PASS" if ok else "FAIL", name), flush=True)

N = 1951
# --- the character chi -------------------------------------------------------------------------
check("3 is a primitive root mod 1951", all(pow(3, (N - 1) // q, N) != 1 for q in (2, 3, 5, 13)))
check("3^780 = 908 mod 1951, so chi(3) = e(780/1950) = zeta5^2 is Conrey 1951.908", pow(3, 780, N) == 908)
ind2 = next(k for k in range(N - 1) if pow(3, k, N) == 2)
check("chi(2) = zeta5^3 (ind_3 2 = %d)" % ind2, (2 * ind2) % 5 == 3)
check("dim S_2(Gamma0(1951), chi) = 161 with chi = Mod(908,1951)", int(pari.mfdim([N, 2, pari("Mod(908,1951)")], 1)) == 161)
check("dim S_2(Gamma0(1951)) = 162", int(pari.mfdim([N, 2, 1], 1)) == 162)

# --- the quintic field L5 ---------------------------------------------------------------------
f5 = pari("x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344")
nf = pari.nfinit(f5)
check("disc(L5) = 1951^4", nf[2] == N ** 4)
check("poldisc(f5) = 2^2 7^2 71^2 137^2 1951^4", pari.poldisc(f5) == 2**2 * 7**2 * 71**2 * 137**2 * N**4)
check("Gal(f5) = A5 (order 60)", int(pari.polgalois(f5)[0]) == 60)
check("L5 totally real", int(pari.polsturm(f5)) == 5)
dec2 = sorted(int(P[3]) for P in pari.idealprimedec(nf, 2))
check("Frob_2 has cycle type (3,1,1) in L5, so t_2 = +-1", dec2 == [1, 1, 3])
tr = lambda a: pari.nfelttrace(nf, a)
B = pari.nfbasis(f5)
T = pari.matrix(5, 5, [tr(pari.nfalgtobasis(nf, B[i] * B[j])) for i in range(5) for j in range(5)])
trv = pari.matrix(1, 5, [tr(pari.nfalgtobasis(nf, B[i])) for i in range(5)])
K0 = pari.matkerint(trv)
G = pari.mattranspose(K0) * T * K0
A4 = pari("[2,-1,0,0;-1,2,-1,0;0,-1,2,-1;0,0,-1,2]")
check("trace-zero lattice of O_L5 is isometric to A4 scaled by 1951", pari.qfisom(G, N * A4) != 0)
UV = {1: ("(-229*x^4-27*x^3+180034*x^2+602971*x-653282)/19454", "(689*x^4-386*x^3-535218*x^2-1566799*x+622376)/68089"),
      3: ("(3275*x^4-1143*x^3-2565972*x^2-7306095*x+8710406)/136178", "(-145*x^4-187*x^3+112806*x^2+519501*x+192652)/19454")}
for d, (us, vs) in UV.items():
    u = pari.nfalgtobasis(nf, pari(us)); v = pari.nfalgtobasis(nf, pari(vs))
    integral = all(pari.denominator(c) == 1 for c in list(u) + list(v))
    m = lambda a, b: pari.nfeltmul(nf, a, b)
    ok = integral and tr(u) == 0 and tr(v) == 0 and tr(m(u, v)) == 0 and tr(m(u, u)) == d * tr(m(v, v)) and tr(m(v, v)) == 3902
    check("d=%d: u, v integral, Tr u = Tr v = Tr uv = 0, Tr u^2 = %d * Tr v^2 = %d" % (d, d, d * 3902), ok)

# --- the fields F, K, K6, K24 -----------------------------------------------------------------
Fpol = pari("y^4 + 3*y^2 + 1"); Kpol = pari("a^4 - a^3 + 2*a^2 + a + 1")
check("F = Q(i, sqrt5): polredabs of the compositum", pari.polredabs(pari.polcompositum("x^2+1", "x^2-5")[0]) == pari.substpol(Fpol, "y", "x"))
check("K = Q(sqrt5, sqrt-3): polredabs of the compositum", pari.polredabs(pari.polcompositum("x^2+3", "x^2-5")[0]) == pari.substpol(Kpol, "a", "x"))
bF = pari.bnfinit(Fpol, 1); bK = pari.bnfinit(Kpol, 1)
check("class numbers h(F) = h(K) = 1 (certified with bnfcertify)",
      bF.bnf_get_no() == 1 and bK.bnf_get_no() == 1 and int(pari.bnfcertify(bF)) == 1 and int(pari.bnfcertify(bK)) == 1)
check("disc(K) = 225", bK[6][2] == 225)
iF = pari("Mod(y^3 + 2*y, y^4 + 3*y^2 + 1)"); s5F = pari("Mod(2*y^2 + 3, y^4 + 3*y^2 + 1)")
check("in F: (y^3+2y)^2 = -1 and (2y^2+3)^2 = 5", iF ** 2 == -1 and s5F ** 2 == 5)
check("zeta5 not in F and not in K", len(pari.nfroots(bF, "x^4+x^3+x^2+x+1")) == 0 and len(pari.nfroots(bK, "x^4+x^3+x^2+x+1")) == 0)
z = pari("Mod(t, polcyclo(5, t))"); s5 = 2 * (z + z ** 4) + 1     # sqrt5 = 1 + 2(z + z^-1)
phi = (1 + s5) / 2
delta = -(10 + 2 * s5)
check("sqrt5 = 1 + 2(z + z^4) in Q(zeta5)", s5 ** 2 == 5)
check("delta = -(10 + 2 sqrt5) = -4 sqrt5 phi", delta == -4 * s5 * phi)
check("(2(zeta5 - zeta5^-1))^2 = delta, so Q(zeta5) = Q(sqrt5)(sqrt delta)", (2 * (z - z ** 4)) ** 2 == delta)
# Hilbert symbol (delta, -1) over Q(sqrt5) at the finite places above 2 and 5, and over F, K
k5 = pari.nfinit("w^2 - 5")
dk = pari("Mod(-10 - 2*w, w^2 - 5)").lift()
hs = [int(pari.nfhilbert(k5, dk, -1, P)) for p in (2, 5) for P in pari.idealprimedec(k5, p)]
check("over Q(sqrt5): (delta,-1) split at the places above 2 and 5", hs == [1, 1])
check("over Q(sqrt5): delta totally negative (ramified at both real places)", all(float(pari.real(r)) < 0 for r in pari.polroots(pari.charpoly(pari("Mod(-10 - 2*w, w^2 - 5)")))))
for name, b, s5pol in (("F", bF, "2*y^2+3"), ("K", bK, None)):
    nfb = b
    if s5pol is None:
        r5 = pari.nfroots(nfb, "x^2-5")[0]; s5el = pari.nfbasistoalg(nfb, r5).lift()
    else:
        s5el = pari(s5pol)
    dl = -10 - 2 * s5el
    check("over %s: Hilbert symbol (delta,-1) = 1 (split)" % name, int(pari.nfhilbert(nfb, dl, -1)) == 1)
K6 = pari("x^6 - 75*x^4 - 70*x^3 + 826*x^2 - 210*x - 625")
check("K6: Galois group of order 60 on 6 points, disc 1951^4", int(pari.polgalois(K6)[0]) == 60 and pari.nfdisc(K6) == N ** 4)
K24 = pari(open(os.path.join(ROOT, "overnight", "traces", "K24.txt")).read().strip())
dK24 = pari.nfdisc([K24, [2, 3, 5, 7, 17, 139, 271, 40427, 1951]])
check("K24: disc = 1951^16 = disc(K6)^4 (unramified over K6 at finite places)", dK24 == N ** 16)
check("K24 contains K6", any(pari.nfisisom(pari.polredbest(s[0]), pari.polredbest(K6)) != 0 for s in pari.nfsubfields(K24, 6)))
check("K24 is totally imaginary (so rho0(c) = -I)", int(pari.polsturm(K24)) == 0)

# --- Section 6 numerics -----------------------------------------------------------------------
check("Sturm bounds: 2*1952/12 < 326 and 4*1952/12 < 651", 2 * 1952 / 12 < 326 and 4 * 1952 / 12 < 651)
from fractions import Fraction
check("Eisenstein series: 24/1950 = 4/325 has 2-adic valuation 2", Fraction(24, 1950) == Fraction(4, 325))
# F16 = F2[z]/(z^4+z^3+z^2+z+1): x = z + z^2, y = 1 + z^3
F16 = lambda e: pari("Mod(Mod(1,2)*(%s), Mod(1,2)*(z^4+z^3+z^2+z+1))" % e)
xx, yy = F16("z+z^2"), F16("1+z^3")
check("in F16: x + y = z^4 and x*y = z^3", xx + yy == F16("z^4") and xx * yy == F16("z^3"))
check("sigma (sqrt5 -> -sqrt5) fixes every trace value mod sqrt5 (phi = 3, 1-phi = 3), so rho0'' mod lambda = rhobar",
      all((a - b) % 5 == 0 for a, b in ((3, 1 - 3), (-3, -(1 - 3)), (3 - 1, (1 - 3) - 1), (1 - 3, 1 - (1 - 3)))))
# zeros of Galois-conjugate Dirichlet L-functions differ (sigma does not act on analytic data)
G11 = pari.znstar(11, 1)
z1 = float(pari.lfunzeros(pari.lfuncreate([G11, [2]]), 8)[0]); z2 = float(pari.lfunzeros(pari.lfuncreate([G11, [4]]), 8)[0])
check("psi mod 11 with psi(2) = zeta5: first zeros of L(s,psi), L(s,psi^2) at %.3f, %.3f (different)" % (z1, z2),
      abs(z1 - 5.134) < 1e-3 and abs(z2 - 4.629) < 1e-3)
# --- Section 7 ------------------------------------------------------------------------------------
import json, math
TR = json.load(open(os.path.join(ROOT, "overnight", "traces", "galois_traces_3200000.json")))
zz = pari("Mod(t, polcyclo(5, t))"); phi = 1 + zz + zz ** 4
PHI = (1 + 5 ** 0.5) / 2
def tval(p):
    t = TR["t"][str(p)]
    for val, e in ((PHI, phi), (-PHI, -phi), (PHI - 1, phi - 1), (1 - PHI, 1 - phi)):
        if abs(t - val) < 1e-9: return e
    return int(round(t))
ind = lambda p: next(k for k in range(N - 1) if pow(3, k, N) == p % N)
def Ep1(p):                      # det(1 - rho(Frob_p)) = 1 - a_p + chi(p), a_p = t_p chi(p)^3, chi(p) = zeta5^(2 ind p)
    c = zz ** (2 * ind(p)); return 1 - tval(p) * c ** 3 + c
check("t_11 = t_37 = -phi (order 5) and det(1 - rho(Frob_p)) = 0 for p = 11, 37 (eigenvalue 1)",
      tval(11) == -phi and tval(37) == -phi and Ep1(11) == 0 and Ep1(37) == 0)
e2 = pari.lift(Ep1(2))                                   # polynomial in t of degree <= 3
e2c = [int(pari.polcoef(e2, k, "t")) % 2 for k in range(4)]
check("det(1 - rho(Frob_2)) = z + z^2 in F16 (so the Euler factor at 2 is a 2-adic unit)", e2c == [0, 1, 1, 0])
def vp(x, p):
    v = 0
    while x and x % p == 0: x //= p; v += 1
    return v if x else 10 ** 9
nm = {p: int(pari.norm(Ep1(p))) for p in (3, 5, 7, 13)}
check("det(1 - rho(Frob_p)) is a p-adic unit for p = 3, 5, 7, 13 (norms %s)" % [nm[p] for p in (3, 5, 7, 13)],
      all(vp(nm[p], p) == 0 for p in nm))
# Question 3: the family F7 = {Q(sqrt(-q)) : q = 7 mod 8 prime} for Theorem A'
F7 = [q for q in range(7, 400, 8) if all(q % d for d in range(2, int(q ** 0.5) + 1))][:15]
leg = lambda a, p: pow(a % p, (p - 1) // 2, p)          # Euler's criterion: 1 for a non-zero square
sieve = bytearray([1]) * 100001; sieve[0:2] = b"\x00\x00"
for i in range(2, 317):
    if sieve[i]: sieve[i * i::i] = bytearray(len(sieve[i * i::i]))
odd_p = [n for n in range(3, 100001) if sieve[n]]
check("Question 3: 2 splits in Q(sqrt(-q)) for q = 7 mod 8, and every odd prime p < 10^5 splits in one of the first 15 such fields (q <= %d)" % F7[-1],
      all((-q) % 8 == 1 for q in F7) and all(any(q != p and leg(-q, p) == 1 for q in F7) for p in odd_p))
# Remark 7.4(3): the exact values L(rho,1-n), 67 odd n <= 1459 (Z[zeta5] coordinates, no holomorphy assumed)
from fractions import Fraction
vals = {}
for f in ("brainstorm/negA.json", "brainstorm/negB.json", "brainstorm/negC.json", "brainstorm/negD.json", "brainstorm/negE.json"):
    for k, o in json.load(open(os.path.join(ROOT, f))).items():
        vals[int(k)] = sum(int(Fraction(c)) * zz ** i for i, c in enumerate(o["coords"]))
def Ep(p, n):
    c = zz ** (2 * ind(p)); return 1 - tval(p) * c ** 3 * p ** (n - 1) + c * p ** (2 * n - 2)
coef = lambda x: [int(pari.polcoef(pari.lift(x), k, "t")) for k in range(4)]
v2 = lambda x: min(vp(c, 2) for c in coef(x))
Ls = {n: Ep(2, n) * x for n, x in vals.items()}
ns = sorted(Ls)
res = {tuple((c >> 2) & 1 for c in coef(x)) for x in Ls.values()}
exact = all(v2(Ls[a] - Ls[b]) == vp(b - a, 2) + 4 for i, a in enumerate(ns) for b in ns[i + 1:])
sq = tuple(c % 2 for c in coef((zz + zz ** 2) ** 2))
check("[N] p = 2: the %d values E_2(n) L(rho,1-n) are 4 times 2-adic units, all = 4(1+z+z^3) mod 8, and all %d differences "
      "have v_2 = v_2(n-n') + 4; (z+z^2)^2 = 1+z+z^3 in F16" % (len(ns), len(ns) * (len(ns) - 1) // 2),
      len(ns) == 67 and all(v2(x) == 2 for x in Ls.values()) and res == {(1, 1, 0, 1)} and exact and sq == (1, 1, 0, 1))
# numerical [N]: PARI's L(rho,s) at 256 bits (assumes holomorphy) against the exact values used in Remark 7.4
pari.set_real_precision_bits(256)
M = 1400
zc = pari("exp(2*Pi*I/5)")
def emb(x): return pari.subst(pari.lift(x), "t", zc)
# multiplicative coefficients from the trace table (p < M) and the inertia line at 1951 (eigenvalue zeta5^2)
import sympy
cache = {}
def ap_c(p):
    if p not in cache:
        c = zz ** (2 * ind(p)); cache[p] = (emb(tval(p) * c ** 3), emb(c))
    return cache[p]
vec = []
for n in range(1, M + 1):
    val = pari(1)
    for p, e in sympy.factorint(n).items():
        if p == N: val *= zc ** (2 * e); continue
        A, D = ap_c(p); prev, cur = pari(1), A
        for _ in range(e - 1): prev, cur = cur, A * cur - D * prev
        val *= cur
    vec.append(val)
v = pari.vector(M, vec)
tau = pari("sum(x=1,1950, exp(2*Pi*I*((2*znlog(x,Mod(3,1951)))%5)/5)*exp(2*Pi*I*x/1951))")
W = -zc ** 3 * tau / pari("sqrt(1951)")
Lr = pari.lfuncreate([v, 1, [1, 1], 1, N, W])
fe = int(pari.lfuncheckfeq(Lr, precision=256))
check("[N] W(rho) = -zeta5^3 tau(chi)/sqrt(1951): the functional equation holds to 2^%d at 256 bits" % fe, fe < -240)
L0 = pari.lfun(Lr, 0, precision=256); Lm2 = pari.lfun(Lr, -2, precision=256)
ex = lambda c: c[0] + c[1] * zc + c[2] * zc ** 2 + c[3] * zc ** 3
d0 = float(pari.abs(L0 - ex((0, -4, -4, 0)))); d2 = float(pari.abs(Lm2 - ex((8612, -23244, -8800, 26804))))
check("[N] PARI L(rho,0) = -4(z+z^2) to %.0e and L(rho,-2) = 8612-23244z-8800z^2+26804z^3 to %.0e" % (d0, d2), d0 < 1e-60 and d2 < 1e-60)
# --- Section 3: Theorem A'', Remark 3.8, Question 3 (added 19 Oct 2026) --------------------------
import itertools
def kron(a, n): return int(pari.kronecker(a, n))
check("1951 is inert in Q(i) and Q(sqrt-2) and splits in Q(sqrt2)", kron(-4, N) == -1 and kron(-8, N) == -1 and kron(8, N) == 1)
check("every odd prime p < 10^5 splits in Q(i), Q(sqrt-2) or Q(sqrt2): (-4/p)(8/p)(-8/p) = 1",
      all(kron(-4, p) * kron(8, p) * kron(-8, p) == 1 for p in pari.primes(9592)[1:]))
def order(g):
    k, h = 1, g
    while h != tuple(range(5)): h = tuple(g[i] for i in h); k += 1
    return k
def sgn(g): return (-1) ** sum(1 for i in range(5) for j in range(i + 1, 5) if g[i] > g[j])
ords = sorted({order(g) for g in itertools.permutations(range(5)) if sgn(g) == 1})
check("element orders in A5 are %s: no element of order 2l for l >= 3 (Theorem A'', Step 2)" % ords, ords == [1, 2, 3, 5])
K12 = pari("x^12 - 113*x^10 + 4482*x^8 - 72251*x^6 + 388968*x^4 - 48712*x^2 + 1225")
nf12 = pari.nfinit(K12)
check("K12 = x^12 - 113x^10 + ... + 1225: field discriminant 1951^8, totally real", nf12[2] == N ** 8 and int(pari.polsturm(K12)) == 12)
check("K6 (sextic resolvent) is a subfield of K12", pari.nfisincl(pari("x^6-75*x^4-70*x^3+826*x^2-210*x-625"), K12) != 0)
pari("bnf12 = bnfinit(%s, 1); fu12 = apply(u -> lift(u), bnf12.fu);" % K12)
check("K12 has 11 independent units of norm 1 (bnfinit; regulator %.4e)" % float(pari("bnf12.reg")),
      int(pari("#fu12")) == 11 and all(int(pari("norm(Mod(fu12[%d], bnf12.pol))" % i)) == 1 for i in range(1, 12)))
pari("F12 = factorpadic(bnf12.pol, 2, 300)")
pari("plog12(U, f) = my(W = (U^(2^f - 1))^(2^6), X = W - 1, S = 0, T = 1); for (n = 1, 60, T = T * X; S += (-1)^(n + 1) * T / n); S / ((2^f - 1) * 2^6)")
pari("M12 = matrix(12, 11); r12 = 0; for (j = 1, #F12[,1], g = F12[j,1]; f = poldegree(g); for (i = 1, 11, v = Vec(lift(plog12(Mod(fu12[i], g), f))); v = concat(vector(f - #v, t, 0), v); for (t = 1, f, M12[r12 + t, i] = v[t])); r12 += f)")
mins = [pari("my(rr = setminus([1..12], [%d])); matdet(matrix(11, 11, a, b, M12[rr[a], b]))" % r) for r in range(1, 13)]
vals = [int(pari.valuation(m, 2)) for m in mins]; precs = [int(pari.padicprec(m, 2)) for m in mins]
check("Leopoldt for K12 at 2: all twelve 11x11 minors of the 2-adic log matrix are non-zero (valuations %s, precision >= 2^%d)"
      % (sorted(set(vals)), min(precs)), all(v < q - 20 for v, q in zip(vals, precs)))

# --- Section 8 (added 20 Oct 2026): the six representations of [DM] ----------------------------------------
Q = os.path.join(ROOT, "questions")
DM6 = json.load(open(os.path.join(Q, "fields6.json")))
P6 = [1951, 2141, 3701, 3821, 8501, 9461]
A4m = pari("[2,-1,0,0;-1,2,-1,0;0,-1,2,-1;0,0,-1,2]")
ok_fields = []
for p in P6:
    f = pari(DM6[str(p)]["poly"]); nfp = pari.nfinit(f)
    Bp = pari.nfbasis(f)
    Tp = pari.matrix(5, 5, [pari.nfelttrace(nfp, pari.nfalgtobasis(nfp, Bp[i] * Bp[j])) for i in range(5) for j in range(5)])
    tv = pari.matrix(1, 5, [pari.nfelttrace(nfp, pari.nfalgtobasis(nfp, Bp[i])) for i in range(5)])
    Kp = pari.matkerint(tv); Gp = pari.mattranspose(Kp) * Tp * Kp
    ok_fields.append(nfp[2] == p ** 4 and int(pari.polsturm(f)) == 5 and int(pari.polgalois(f)[0]) == 60
                     and pari.qfisom(Gp, p * A4m) != 0 and math.gcd(*[int(tv[0, i]) for i in range(5)]) == 1)
check("Section 8: the six fields of [DM] are totally real A5 quintics of discriminant p^4, Tr(O_L) = Z, and the trace-zero lattice is p*A4 (qfisom)",
      all(ok_fields))
check("Section 8: all p in P are 1 mod 5, and all but 1951 are 5 mod 8 (so the characters of order 4 mod p are odd)",
      all(p % 5 == 1 for p in P6) and all(p % 8 == 5 for p in P6[1:]) and 1951 % 8 == 7
      and all(((p - 1) // 2) % 4 == 2 for p in P6[1:]))
gr = pari.qfgaussred(A4m)
check("Lemma 8.1/Cor. 8.2: Gram-Schmidt of A4 gives <2, 3/2, 4/3, 5/4>", [gr[i, i] for i in range(4)] == [pari(2), pari("3/2"), pari("4/3"), pari("5/4")])
cart = {"A4": A4m, "D4": pari("[2,-1,0,0;-1,2,-1,-1;0,-1,2,0;0,-1,0,2]"), "A3+A1": pari("[2,-1,0,0;-1,2,-1,0;0,-1,2,0;0,0,0,2]"),
        "A2+A2": pari("[2,-1,0,0;-1,2,0,0;0,0,2,-1;0,0,-1,2]"), "A2+2A1": pari("[2,-1,0,0;-1,2,0,0;0,0,2,0;0,0,0,2]"), "4A1": pari("2*matid(4)")}
check("Lemma 8.1: rank-4 root lattices have determinants A4 5, D4 4, A3+A1 8, A2+A2 9, A2+2A1 12, 4A1 16",
      [int(pari.matdet(cart[k])) for k in ("A4", "D4", "A3+A1", "A2+A2", "A2+2A1", "4A1")] == [5, 4, 8, 9, 12, 16])
check("Cor. 8.2: 5 is a non-square in Q_2 (5 mod 8), Q_3 (non-residue), Q_5 (valuation 1)",
      5 % 8 != 1 and pow(5, 1, 3) == 2 and int(pari.kronecker(5, 3)) == -1)
e = lambda *ix: [sum(c for i, c in ix if i == k) for k in range(1, 6)]
v_ = e((5, 1), (1, -1)); us = [e((4, 1), (2, -1)), e((3, 1), (4, 1), (1, -1), (5, -1)), e((4, 2), (1, -1), (5, -1))]
dot = lambda a, b: sum(x * y for x, y in zip(a, b))
check("Cor. 8.2: v = e5 - e1 is orthogonal to e4 - e2, e3 + e4 - e1 - e5, 2e4 - e1 - e5 of norms 2d (d = 1, 2, 3)",
      all(dot(u, v_) == 0 and dot(u, u) == 2 * d and sum(u) == 0 for d, u in zip((1, 2, 3), us)) and dot(v_, v_) == 2)
ok_uv = []; ok_cert = []; nk = 0
for p in P6:
    for d in (1, 2, 3):
        jf, cf = os.path.join(Q, "klein_p%d_d%d.json" % (p, d)), os.path.join(Q, "klein_certify_p%d_d%d.json" % (p, d))
        if not os.path.exists(cf): continue
        J, C = json.load(open(jf)), json.load(open(cf)); nk += 1
        f = pari(DM6[str(p)]["poly"]); nfp = pari.nfinit(f)
        u = pari.nfalgtobasis(nfp, pari(J["u"])); v = pari.nfalgtobasis(nfp, pari(J["v"]))
        trp = lambda a: pari.nfelttrace(nfp, a); mul = lambda a, b: pari.nfeltmul(nfp, a, b)
        ok_uv.append(all(pari.denominator(c) == 1 for c in list(u) + list(v)) and trp(u) == 0 and trp(v) == 0 and trp(mul(u, v)) == 0
                     and trp(mul(u, u)) == d * trp(mul(v, v)) and trp(mul(v, v)) == 2 * p and trp(mul(u, u)) == 2 * d * p)
        ok_cert.append(C["frobenius_degree1"][0] == C["frobenius_degree1"][1] > 300 and C["fibre_irreducible"] and C["K0K6_in_isogeny_field"]
                       and C["degrees"] == [24, 24] and len(C["decomposed_generic_witnesses"]) > 0)
check("Theorem E: for all %d curves, u, v are integral with Tr u = Tr v = Tr uv = 0, Tr v^2 = 2p, Tr u^2 = 2dp" % nk, nk == 11 and all(ok_uv))
check("Theorem E: all %d certificates record the Frobenius check, an irreducible fibre with stem field of degree 24 containing K_d K6, and witnesses" % nk,
      all(ok_cert))
# re-derive one witness and the places with v(j) < 0 for each new curve, from the stored rational coordinates of j
okw = []
for p in P6:
    for d in (1, 2, 3):
        cf = os.path.join(Q, "klein_certify_p%d_d%d.json" % (p, d))
        if not os.path.exists(cf) or (p == 1951 and d != 2): continue
        J, C = json.load(open(os.path.join(Q, "klein_p%d_d%d.json" % (p, d)))), json.load(open(cf))
        qq = lambda k: pari(J[k][0]) / pari(J[k][1])
        Kpol = pari.polredabs(pari.polcompositum("a^2+%d" % d, "a^2-5")[0]); Kn = pari.nfinit(Kpol)
        sd = pari.Mod(pari.nfbasistoalg(Kn, pari.nfroots(Kn, "x^2+%d" % d)[0]).lift(), Kpol)
        s5 = pari.Mod(pari.nfbasistoalg(Kn, pari.nfroots(Kn, "x^2-5")[0]).lift(), Kpol)
        jK = (qq("Re alpha") + sd * qq("Im alpha / sqrt d")) + (qq("Re beta") + sd * qq("Im beta / sqrt d")) * s5
        E = pari.ellinit(pari.ellfromj(pari.lift(jK)), Kn)
        l, aps = C["decomposed_generic_witnesses"][0]
        dec = pari.idealprimedec(Kn, l)
        ap2 = [int(pari.ellap(E, P)) for P in dec]
        gen = len(dec) == 4 and sorted(ap2) == sorted(aps) and all((a - 1 - l) % 5 and (a + 1 + l) % 5 for a in ap2)
        den = int(pari.denominator(pari.content(pari.nfalgtobasis(Kn, pari.lift(jK)))))
        neg = sorted([int(P[0]) for l2 in pari.factor(den)[0] for P in [Pp for Pp in pari.idealprimedec(Kn, int(l2))]
                      if int(pari.nfeltval(Kn, pari.lift(jK), P)) < 0])
        okw.append(gen and neg == sorted(w[0] for w in C["v_j_negative"]))
check("Theorem E: recomputed from the exact j, the first witness l splits in K_d with a_v != +-(1+l) mod 5 at all four places, and the places with v(j) < 0 match the certificates (%d curves)" % len(okw),
      len(okw) == 11 and all(okw))
okm = []
for p, dims in ((2141, (177, 178)), (3701, (307, 308)), (3821, (317, 318))):
    for eps, dm in zip((0, 1), dims):
        M = json.load(open(os.path.join(Q, "mod2_p%d_eps%d.json" % (p, eps))))
        good = [L for L in (0, 1) if all(v for k, v in M["membership"].items() if k.startswith("L=%d" % L) and "shuffled" not in k)]
        E2 = M["eigenspaces L=%d" % good[0]] if len(good) == 1 else {}
        gen = [v for k, v in E2.items() if k.startswith("generalised")]
        one = [v for k, v in E2.items() if k.startswith("T3,T5,T7,T2=")]
        ef = M.get("eigenforms L=%d" % good[0], {}) if good else {}
        okm.append(len(good) == 1 and M["dim"] == dm and not any(v for k, v in M["membership"].items() if "shuffled" in k)
                   and E2.get("T3,T5,T7") == 2 and sorted(gen) == [3, 3] and one == [1, 1] and M["commute"]
                   and ef.get("odd_coefficients_agree_to_NB") is True and M["NB"] > p + 1 and M["NB"] > 5 * (p + 1) / 6)
check("Theorem F: in the six spaces (2141, 3701, 3821; chi and chi*eps_p), exactly one labelling occurs, controls absent, joint T3,T5,T7 kernel 2, with T2 1 and 1, generalised 3 and 3, odd coefficients of G_x, G_y agree to N_B > p + 1",
      len(okm) == 6 and all(okm))
dm8 = []
for p in (2141, 3701, 3821, 8501, 9461):
    c0 = 2 * (p - 1) // 5
    dm8.append([int(pari("mfdim([%d,2,[znstar(%d,1),[%d]]],1)" % (p, p, (c0 + e * (p - 1) // 2) % (p - 1)))) for e in (0, 1)])
check("Theorem F and Remark 8.3: dim S_2(Gamma0(p), chi), S_2(Gamma0(p), chi*eps_p) = %s for p = 2141, 3701, 3821, 8501, 9461" % dm8,
      dm8 == [[177, 178], [307, 308], [317, 318], [707, 708], [787, 788]])
check("Theorem F, proof: (p-1)/2 * (p+1)/6 = (p^2-1)/12 = deg omega^2 on X1(p)", all(Fraction(p - 1, 2) * Fraction(p + 1, 6) == Fraction(p * p - 1, 12) for p in P6))
oks = []
for p in P6:
    S8 = json.load(open(os.path.join(Q, "stark_ad_p%d_prec57.json" % p)))
    st = S8["stark"]
    oks.append(len(st) >= 15 and all(max(s["log10 residual a"], s["log10 residual b"]) < -43 for s in st)
               and all((int(s["a"]) - int(s["b"])) % 2 == 0 for s in st) and S8["V"]["lfuncheckfeq"] < -180 and S8["V'"]["lfuncheckfeq"] < -180)
check("[N] Remark 8.4: for all six p, every non-degenerate A(V,f) = a + b sqrt5 in Z[phi] and A(V',f) = a - b sqrt5 to 1e-43; functional equations to 2^-180",
      all(oks))

okl = []
for p in P6:
    for ell in (2, 3, 5, 7):
        Lj = json.load(open(os.path.join(Q, "leopoldt_p%d_ell%d.json" % (p, ell))))
        okl.append(Lj["rank11"] and Lj["matrank"] == 11 and len(Lj["nonzero_minors_without_row"]) >= 10)
pari("Vq = read(\"%s\"); Qq = Vq[1]; fuq = Vq[3];" % os.path.join(Q, "k12_units_p9461.gp").replace("\\", "/"))
pari("Fq = factorpadic(Qq, 2, 300)")
pari("plogq(U, f) = my(W = (U^(2^f - 1))^(2^6), X = W - 1, S = 0, T = 1); for (n = 1, 60, T = T * X; S += (-1)^(n + 1) * T / n); S / ((2^f - 1) * 2^6)")
pari("Mq = matrix(12, 11); rq = 0; for (j = 1, #Fq[,1], g = Fq[j,1]; f = poldegree(g); for (i = 1, 11, v = Vec(lift(plogq(Mod(fuq[i], g), f))); v = concat(vector(f - #v, t, 0), v); for (t = 1, f, Mq[rq + t, i] = v[t])); rq += f)")
mq = pari("matdet(matrix(11, 11, a, b, Mq[a + 1, b]))")
check("Q3 update: Leopoldt for K12 at ell = 2, 3, 5, 7 for all six conductors (24 records, rank 11); recomputed for 9461 at ell = 2: an 11x11 minor of valuation %d, known to 2^%d"
      % (int(pari.valuation(mq, 2)), int(pari.padicprec(mq, 2))),
      len(okl) == 24 and all(okl) and int(pari.valuation(mq, 2)) < int(pari.padicprec(mq, 2)) - 20)

okl2 = []
for p in P6:
    for ell in (11, 31, 41, 61, 71):
        Lj = json.load(open(os.path.join(Q, "leopoldt_p%d_ell%d.json" % (p, ell))))
        okl2.append(Lj["rank11"] and Lj["matrank"] == 11 and len(Lj["nonzero_minors_without_row"]) >= 10)
pari("Fr = factorpadic(Qq, 11, 120)")
pari("plogr(U, f) = my(W = (U^(11^f - 1))^(11^6), X = W - 1, S = 0, T = 1); for (n = 1, 30, T = T * X; S += (-1)^(n + 1) * T / n); S / ((11^f - 1) * 11^6)")
pari("Mr = matrix(12, 11); rr = 0; for (j = 1, #Fr[,1], g = Fr[j,1]; f = poldegree(g); for (i = 1, 11, v = Vec(lift(plogr(Mod(fuq[i], g), f))); v = concat(vector(f - #v, t, 0), v); for (t = 1, f, Mr[rr + t, i] = v[t])); rr += f)")
mr = pari("matdet(matrix(11, 11, a, b, Mr[a + 1, b]))")
check("Proposition 9.1: Leopoldt for K12 at ell = 11, 31, 41, 61, 71 for all six conductors (30 records, rank 11); recomputed for 9461 at ell = 11: an 11x11 minor of valuation %d, known to 11^%d"
      % (int(pari.valuation(mr, 11)), int(pari.padicprec(mr, 11))),
      len(okl2) == 30 and all(okl2) and int(pari.valuation(mr, 11)) < int(pari.padicprec(mr, 11)) - 20)
cl1171 = [[json.load(open(os.path.join(Q, "classes_%d.json" % p)))["codes"][str(ell)] for ell in (11, 71)] for p in P6]
check("Proposition 9.1, example: 11 and 71 split in Q(sqrt-7), and Frob_11, Frob_71 are not central for the six p (classes %s)" % cl1171,
      all(kron(-7, ell) == 1 for ell in (11, 71)) and all(c != "1A" for row in cl1171 for c in row))

MQ = json.load(open(os.path.join(ROOT, "maassq", "maass_q_isolate.json")))
cs = MQ["cases"]
okq = (max(cs["rho, nebentypus chi"]) < 1e-9 and max(cs["rho'' (sqrt5-conjugate), nebentypus chi^2"]) < 1e-9
       and min(max(v) for k, v in cs.items() if k.startswith("control")) > 0.1
       and max(max(abs(a), abs(b)) for a, b in MQ["r2"]) < 1e-10)
check("[N] Introduction: Galois series over Q invariant under Gamma0(1951) to %.1e (rho, chi) and %.1e (rho'', chi^2) at %d gamma; controls > 0.1; first-order r^2 < %.0e"
      % (max(cs["rho, nebentypus chi"]), max(cs["rho'' (sqrt5-conjugate), nebentypus chi^2"]), MQ["n_gamma"],
         max(max(abs(a), abs(b)) for a, b in MQ["r2"])), okq)

HR = json.load(open(os.path.join(ROOT, "hilbert", "hr2_C3.00_s2.json")))
hv = HR["variants"]
hr_rho = max(hv["rho | odd,odd"]["defect"])
hr_a2 = min(hv["a_2 + 1e-3 | odd,odd"]["defect"])
hr_oth = min([max(v["defect"]) for k, v in hv.items() if k not in ("rho | odd,odd", "a_2 + 1e-3 | odd,odd")]
             + [max(hv["rho | odd,odd"]["defect_conj"])])
check("[N] Remark 3.10, Q(sqrt2): the Galois series with signs sgn(N alpha) is invariant under Gamma0(1951 O_F) with chi(N d) to %.1e at %d gamma (%d terms, C = %.0f); a_2 + 1e-3 gives >= %.1e, the other controls >= %.1f"
      % (hr_rho, len(hv["rho | odd,odd"]["defect"]), HR["nterms"], HR["C"], hr_a2, hr_oth),
      hr_rho < 1e-7 and hr_a2 > 1e-4 and hr_oth > 0.5 and len(hv["rho | odd,odd"]["defect"]) == 6)

# Question 3, 21 October: mod-2 Bianchi models over Q(sqrt-7) (bianchi2/): recompute N = 23 exactly, check the records 31, 47, 79
sys.path.insert(0, os.path.join(ROOT, "bianchi2"))
import importlib
bmf2 = importlib.import_module("bmf"); hk2 = importlib.import_module("hecke"); gf2 = importlib.import_module("gf"); mr2 = importlib.import_module("mod2_refine")
pari("mf23 = mfinit([23, 2], 0); f23 = mfeigenbasis(mf23)[1]; co23 = mfcoefs(f23, 40);")
def tr23(p):
    assert int(pari("polcoef(lift(co23[%d + 1]), 1, y)" % p)) % 2 == 0
    return int(pari("polcoef(lift(co23[%d + 1]), 0, y)" % p)) % 2
L23 = bmf2.Level([bmf2.Comp("Fp", 23, mr2.root(23, 0)), bmf2.Comp("Fp", 23, mr2.root(23, 1))], field="F2", group="PGL"); K23 = L23.cohomology()
ops23 = [("v", (0, 1), 2, "v"), ("vbar", (1, -1), 2, "v"), ("(3)", (3, 0), 3, "inert"), ("(5)", (5, 0), 5, "inert"), ("(sqrt-7)", (-1, 2), 7, "ram"),
         ("q11", (1, 2), 11, "split"), ("q11bar", (3, -2), 11, "split"), ("q29", (-3, 4), 29, "split")]
T23 = {}; piv23 = None
for nm, pi, p, typ in ops23:
    T, ok, piv23 = hk2.hecke_matrix(L23, K23, pi, pivots=piv23); T23[nm] = (T.astype("uint8"), p, typ)
def ev23(nm):
    T, p, typ = T23[nm]; t = tr23(p); return t if typ != "inert" else int(gf2.MUL16[t, t])
use23 = [k for k in T23 if k not in ("v", "vbar")]
V23 = mr2.gen_eigenspace([T23[k][0] for k in use23], [ev23(k) for k in use23], K23.shape[0])
pairs23 = sorted(tuple(int(t) for t in pq) for pq in mr2.eigen_pairs(mr2.restrict(T23["v"][0], V23), mr2.restrict(T23["vbar"][0], V23)))
recs = {N: json.load(open(os.path.join(ROOT, "bianchi2", "model_N%d.json" % N))) for N in (31, 47, 79)}
okrec = all([r["x"], r["y"], 1] in r["pairs"] and [r["y"], r["x"], 1] in r["pairs"]
            and all(v["eigen_ok"] == [True] for k, v in r.items() if k.startswith("mixed_")) for r in recs.values())
check("Question 3 (models): PGL_2(O), E = Q(sqrt-7), level 23 O_E, mod 2: dim H^1 = %d, rbar-part %d, (T_v, T_vbar) pairs %s include (x, y) and (y, x); records for N = 31, 47, 79 show mixed pairs, eigenvector checks passed"
      % (K23.shape[0], V23.shape[0], pairs23),
      K23.shape[0] == 14 and V23.shape[0] == 6 and pairs23 == [(12, 12, 2), (12, 13, 1), (13, 12, 1), (13, 13, 2)] and okrec)

# Question 3, 21 October (afternoon): searches with nebentypus, the icosahedral control at 31 O_E, the 633 model (bianchi2/)
import subprocess, tempfile, re
B2 = os.path.join(ROOT, "bianchi2")
with tempfile.TemporaryDirectory() as tmp:
    env = dict(os.environ); env["PYTHONPATH"] = B2 + os.pathsep + env.get("PYTHONPATH", "")
    subprocess.run([sys.executable, os.path.join(B2, "control_A5_31.py"), "-1"], cwd=tmp, env=env, check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    CR = json.load(open(os.path.join(tmp, "control_A5_31_s-1.json")))
ca = CR["conventions"]["a_q"]
okc = (CR["dimH1"] == 11 and CR["dim_Z_gauge"] == 12 and CR["commute"] and ca["rbar_dim"] == 1 and ca["pairs"] == [[14, 14, 1]]
       and all(all(v) for v in ca["eigenvector_tests"].values()) and CR["conventions"]["a_q/eps(q)"]["rbar_dim"] == 0
       and all(c["nonzero_at_cusp_oo"] == (c["pair"][0] != c["pair"][1]) for c in CR["classes"]))
check("Question 3 (control, recomputed): level 31 O_E, F16, nebentypus eps^-1 o N of order 5: dim H^1 = %d; the icosahedral rbar-part has dim %d and pairs %s only; the off-diagonal pairs %s are Eisenstein (non-zero at the cusp oo)"
      % (CR["dimH1"], ca["rbar_dim"], ca["pairs"], [c["pair"] for c in CR["classes"] if c["pair"][0] != c["pair"][1]]), okc)
lg = open(os.path.join(B2, "find_models3.log")).read().splitlines()
lr = open(os.path.join(B2, "find_models3_redo.log")).read().splitlines()
cls = [l for l in lg + lr if re.match(r"N = +\d+: rbar ", l)]
a5 = [l for l in lg + lr if "projective image A5" in l]
fin = [l for l in lg if l.startswith("levels 3-150,161,175,189,203,217")]
skp = [l for l in lg if "SKIPPED" in l]
skl = [(int(re.match(r"N = (\d+)", l).group(1)), int(re.search(r"degree (\d+) over Q", l).group(1))) for l in skp]
okf = (len(fin) == 1 and lg[-1] == "exit 0" and lr[-1] == "exit 0" and any("skipped: 0" in l for l in lr)
       and len(cls) > 0 and all((" rbar dihedral" in l) or (" rbar reducible" in l) for l in cls) and len(a5) > 0
       and all(n > 95 for n, d in skl) and sorted(n for n, d in skl if d < 80) == [117, 145])
check("Question 3 (searches): with nebentypus (odd part of order 1, 3, 5, 15), odd N <= 150 and 7N' <= 217: %d companion classes, all dihedral or reducible; %d icosahedral systems, none with a companion; %d forms skipped, all at levels > 95, the two of degree < 80 (N = 117, 145) completed in the redo run"
      % (len(cls), len(a5), len(skp)), okf)
l6 = open(os.path.join(B2, "check_633.log")).read()
ok6 = ("A5 forms found: 1" in l6 and "x^2 - 3*x + 1" in l6 and "449440" in l6 and "value in F4 - F2 occurs: True" in l6)
check("Question 3 (633): the icosahedral weight-one newform of level 633 [BL]: Frob_2 of projective order 5 (u_2 root of x^2 - 3x + 1), A5 modulo 2, index 449440 over Q(sqrt-7)", ok6)


# Question 3, 21 October (evening): sparse engines and block Lanczos (bianchi2/); the 633 model computed four ways;
# level 1951 O_E (record of run_big.py); a recomputation at N = 127 by three routes
r633 = [json.load(open(os.path.join(B2, f))) for f in ("sparse_N633_k1_o10_A5.json", "sparse_N633_k1_o10_A5_seed1234.json",
                                                         "sparse_N633_k1_o10_A5_lanczos.json", "big_N633_k1_o10_A5.json")]
ok633 = all(r["dimH1"] == 348 and r["commute"] and r["rbar_dim"] == 24 and r["pairs"] == [[1, 1, 8], [1, 15, 4], [15, 1, 4], [15, 15, 8]]
            and all(r["pair_%d_%d" % pq]["joint_eigenvectors"] == 1 and len(r["pair_%d_%d" % pq]["operators"]) == 23
                    for pq in [(1, 15), (15, 1), (1, 1), (15, 15)]) for r in r633)
check("Question 3 (633, computed four ways: two dense cores, a Lanczos core, the memory-lean pipeline): dim H^1 = 348 over F16 with nebentypus; rbar-part 24; (T_v, T_vbar) pairs (x,x) 8, (x,y) 4, (y,x) 4, (y,y) 8; one joint eigenvector with the rbar eigenvalues at all 23 operators in each", ok633)
with tempfile.TemporaryDirectory() as tmp:
    code = ("import sys; sys.path.insert(0, %r)\n" % B2 +
            "from sparse_h1 import FastLevel, Reduction\nfrom sparse_big import BigH1\nfrom bmf import Comp\nfrom mod2_refine import root as sroot\n"
            "L = FastLevel([Comp('Fp', 127, sroot(127, 0)), Comp('Fp', 127, sroot(127, 1))], None, name='127')\n"
            "red = Reduction(L, verbose=False)\nd1 = red.core_kernel.shape[0] + len(red.free_reps)\n"
            "H2 = BigH1(L, verbose=False, dense_max=0, lanczos_w=1)\nH3 = BigH1(L, verbose=False, dense_max=10**9)\n"
            "print(d1, H2.d, H3.d, int(H2.complete), H2.lanczos_runs[0]['gap'])\n")
    out = subprocess.run([sys.executable, "-c", code], cwd=tmp, env=env, check=True, capture_output=True, text=True).stdout.split()
d127 = [int(v) for v in out[-5:]]
check("Question 3 (sparse engines, recomputed): dim H^1(Gamma_0(127 O_E), F16), PGL_2: %d (sparse elimination, dense core), %d (memory-lean, block Lanczos; completeness certified by the bound %d), %d (memory-lean, dense core); 58 in sparse_auto_N127.json"
      % (d127[0], d127[1], d127[4], d127[2]), d127[:3] == [58, 58, 58] and d127[3] == 1 and d127[4] == 58
      and json.load(open(os.path.join(B2, "sparse_auto_N127.json")))["dimH1"] == 58)
R51 = json.load(open(os.path.join(B2, "big_N1951.json")))
# eigenvalues of rbar_2 recomputed from the Frobenius classes (labelling L = 0 of Theorem D), encoding of gf.py
C51 = {int(k): v for k, v in json.load(open(os.path.join(ROOT, "questions", "classes_1951.json")))["codes"].items()}
dl51 = {}; t51 = 1
for k51 in range(1950): dl51[t51] = k51; t51 = t51 * 3 % 1951
M16 = gf2.MUL16; P51 = [1]
for _ in range(10): P51.append(int(M16[P51[-1], 2]))
def tb51(c): return 0 if c in ("1", "2A") else (1 if c == "3A" else ((2 ^ P51[4]) if c == "5A" else (1 ^ 2 ^ P51[4])))
def ab51(l): return int(M16[P51[dl51[l] % 5], tb51(C51[l])])
ev51 = {}
for nm in R51["eigenvalues"]:
    if nm.startswith("q"): ev51[nm] = ab51(int(nm[1:].replace("bar", "")))
    elif nm == "(sqrt-7)": ev51[nm] = ab51(7)
    else: q51 = int(nm.strip("()")); ev51[nm] = int(M16[ab51(q51), ab51(q51)])
x51 = [r for r in range(16) if (int(M16[r, r]) ^ int(M16[ab51(2), r]) ^ P51[(2 * dl51[2]) % 5]) == 0]
EX51 = json.load(open(os.path.join(B2, "extend_big_N1951.json")))
RC51 = json.load(open(os.path.join(B2, "recheck_core_big_cache_N1951_s2.json")))
last = R51["lanczos_runs"][-1]
ok51 = (R51["n"] == 1951 ** 2 + 1 and R51["dimH1"] == 663 and R51["commute"] and R51["kernel_complete_certified"]
        and last["kernel"] == last["gap"] == 664 and R51["rbar_dim"] == 27 and (R51["x"], R51["y"]) == (6, 9) and x51 == [6, 9]
        and R51["pairs"] == [[6, 6, 7], [6, 9, 3], [9, 6, 3], [9, 9, 14]]
        and all(R51["pair_%d_%d" % pq]["joint_eigenvectors"] == 1 and len(R51["pair_%d_%d" % pq]["operators"]) == 24 for pq in [(6, 9), (9, 6), (6, 6), (9, 9)])
        and ev51 == R51["eigenvalues"]
        and EX51["all_eigenvector_tests_pass"] and all(len(v) == 1 for r in EX51["tests"].values() for v in r["eigenvector"].values())
        and RC51["same_span"] and RC51["kernel_new"] == 664)
check("Question 3 (1951, record): level 1951 O_E, index %d, F16, nebentypus chibar^-1 o N: kernel 664 = Krylov bound (complete; an independent Lanczos run gives the same span), dim H^1 = %d; 24 Hecke operators commute; rbar_2-part %d, (T_v, T_vbar) multiplicities %s, (x, y) = %s; one joint eigenvector with the rbar_2 eigenvalues (recomputed from the Frobenius classes) at all 24 operators in each, and at %d further operators"
      % (R51["n"], R51["dimH1"], R51["rbar_dim"], [p[2] for p in R51["pairs"]], tuple(x51), len(EX51["tests"])), ok51)


# Question 3, 26 October: lifting the mixed classes to characteristic 0 (bianchi2/: bockstein.py, sparse_fp.py)
# (1) the F_P engine against the dense engine (record) and the first-order test against independent 2-adic Smith forms;
# (2) the level-23 test recomputed here (all of H^1, every psi; about half a minute); (3) small levels, every nebentypus;
# (4) the 633 model and level 1951 O_E (records).
import glob
FC = json.load(open(os.path.join(B2, "fp_check.json")))
okfc = len(FC["records"]) == 8 and all(r["dense_bmf"] == r["sparse_dense_core"] == r["sparse_lanczos_bound"] for r in FC["records"])
S23 = json.load(open(os.path.join(B2, "snf2_check_23.json"))); S31 = json.load(open(os.path.join(B2, "snf2_check_31.json")))
BS = {c: json.load(open(os.path.join(B2, "bock_small_%s.json" % c))) for c in ("23", "31", "47", "31c")}
with tempfile.TemporaryDirectory() as tmp:
    subprocess.run([sys.executable, os.path.join(B2, "bock_small.py"), "23"], cwd=tmp, env=env, check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    BS23 = json.load(open(os.path.join(tmp, "bock_small_23.json")))
same23 = all(BS23[k] == BS["23"][k] for k in ("dim_Z_gauge", "dimH1", "types", "pairs_all"))
def lt(c, kind): return [t for t in BS[c]["types"] if t["kind"] == kind][0]
oksnf = (S23["dim_mod2_kernel"] == BS["23"]["dim_Z_gauge"] == 14 and S23["lift_mod_2^2"] == lt("23", "trivial")["dim_liftable_Z"] == 7
         and S23["char0_kernel"] == lt("23", "trivial")["char0_rank"] == 2
         and S31["dim_mod2_kernel"] == BS["31"]["dim_Z_gauge"] == 15 and S31["lift_mod_2^2"] == lt("31", "trivial")["dim_liftable_Z"] == 10
         and S31["char0_kernel"] == lt("31", "trivial")["char0_rank"] == 2)
check("Question 3 (characteristic 0, validation): the sparse F_P engine equals the dense engine in 8 of 8 cases (levels 23, 31, 47, and 31 with chibar of order 5; psi = 1 and quadratic; dense core and Lanczos bound); the 2-adic first-order test equals the 2-adic Smith form of the integer relator matrix at 23 and 31 (mod-2 kernel 14, 15; lifting modulo 4: 7, 10; rank 2, 2 in characteristic 0); the level-23 test recomputed: same record %s"
      % same23, okfc and oksnf and same23)
mixed = {"23": [[12, 13], [13, 12]], "31": [[12, 13], [13, 12]], "47": [[2, 15], [15, 2], [4, 8], [8, 4]]}
def has_mixed(t, c): return any([p[0], p[1]] in mixed[c] for p in t["pairs"])
CP = {}
for c, orders in (("31", (4, 8, 16, 32)), ("47", (4, 8, 16))):
    for o in orders:
        d = json.load(open(os.path.join(B2, "char0_psi_%s_o%d.json" % (c, o))))
        CP[(c, o)] = (list(d["embeddings"].values())[0]["dimH1"], d["charpolys"]["v+vbar"]["mod_varpi"],
                      all(v["two_primes_agree"] for v in d["charpolys"].values()))
okmix = (lt("23", "trivial")["char0_rank"] == 2 and has_mixed(lt("23", "trivial"), "23") and not has_mixed(lt("23", "quadratic"), "23")
         and all(not has_mixed(lt(c, k), c) for c in ("31", "47") for k in ("trivial", "quadratic"))
         and all(lt(c, "trivial")["char0_rank"] == r for c, r in (("31", 2), ("47", 4)))
         and all(ag and all(v == 0 for v in red[:-1]) and red[-1] == 1 for (dim, red, ag) in CP.values()))
check("Question 3 (characteristic 0, small levels): at 23, 31, 47 the mixed classes are reductions of no eigenform of characteristic 0 with nebentypus psi of 2-power order: psi = 1, ranks 2, 2, 4 = base change (at 23 they lift modulo 4); psi quadratic, non-zero first-order obstruction; psi of order 4..32 at 31 and 4..16 at 47, ranks %s, T_v + T_vbar nilpotent modulo varpi"
      % ([CP[k][0] for k in sorted(CP)]), okmix)
def fpjson(label, q):
    out = []
    for f in sorted(glob.glob(os.path.join(B2, "fp_big_%s_q%d_P*_s*.json" % (label, q)))):
        d = json.load(open(f)); out.append(d)
    return out
F633 = fpjson("N633_k1_o10_A5", 0)
B633 = json.load(open(os.path.join(B2, "bock_big_N633_k1_o10_A5.json")))
ok633c = (len(F633) >= 2 and len(set(d["P"] for d in F633)) >= 2 and all(d["dimH1_bound"] == 68 and d["lanczos"]["rank_Vm"] == 0 for d in F633)
          and json.load(open(os.path.join(B2, "bc_counts_633.json")))["types"][0]["count"] == 68
          and all(all(v.values()) for v in B633["joint"].values()))
check("Question 3 (characteristic 0, 633): over F_P for the primes %s, dim H^1(Gamma_0(633 O_E), F_P(chi)) <= 68 = number of base changes, so with the Teichmueller lift of the nebentypus the mixed classes do not lift; their first-order obstructions vanish for every psi"
      % sorted(d["P"] for d in F633), ok633c)
F51 = fpjson("N1951", 0)
B51 = json.load(open(os.path.join(B2, "bock_big_N1951.json")))
pari("G51 = znstar(1951, 1); L51 = chargalois(G51); i51 = select(i -> charorder(G51, L51[i]) == 5, [1..#L51]);")
bc51 = [int(pari("mfdim([1951, 2, [G51, L51[i51[%d]]]], 1)" % i)) for i in range(1, int(pari("#i51")) + 1)]
ok51c = (len(F51) >= 1 and all(d["dimH1_bound"] == 161 and d["lanczos"]["rank_Vm"] == 0 and d["lanczos"]["orthogonality_checks_passed"] >= 1 for d in F51)
         and bc51 == [161] and json.load(open(os.path.join(B2, "bc_counts_1951.json")))["types"][0]["count"] == 161
         and B51["augmented"]["complete"] and B51["augmented"]["kernel"] == 685 and B51["augmented"]["t0"] == 664
         and B51["rbar_liftable_mod4_psi1"] == 17 and B51["rbar_liftable_pairs"] == [[6, 6, 3], [6, 9, 2], [9, 6, 2], [9, 9, 10]]
         and all(all(v.values()) for v in B51["joint"].values()))
check("Question 3 (characteristic 0, 1951): over F_%s, dim H^1(Gamma_0(1951 O_E), F_P(chi^-1 o N)) <= 161 (Krylov bound, V_m = 0) = dim S_2(Gamma_0(1951), chi) (recomputed: %s), so in characteristic 0 this cohomology is the 161 base changes and the mixed classes do not lift with this nebentypus; their first-order 2-adic obstructions vanish for every psi; on the rbar_2-part the classes lifting modulo 4 have pairs (x,x) 3, (x,y) 2, (y,x) 2, (y,y) 10"
      % ([d["P"] for d in F51], bc51), ok51c)

print("\n%d of %d checks passed" % (sum(results), len(results)))
