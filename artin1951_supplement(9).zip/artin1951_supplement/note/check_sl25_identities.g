SizeScreen([200, 24]);;
# Character checks behind Remark "identities from solvable subgroups" of the note
# "The even icosahedral representation of conductor 1951".  G = SL(2,5) x C5 = Gal(N/Q), N the field cut out by rho.
# rho = rho0 * lam, with rho0 a faithful 2-dimensional character of SL(2,5) and lam a faithful character of C5 (= chi^3).
# Prints PASS/FAIL lines.  Run:  gap -q check_sl25_identities.g   (or through Sage's libgap).  Author: Dula.
G0 := DirectProduct(SL(2,5), CyclicGroup(IsPermGroup, 5));
iso := IsomorphismPermGroup(G0); G := Image(iso); inv := InverseGeneralMapping(iso);
p1 := CompositionMapping(Projection(G0, 1), inv); p2 := CompositionMapping(Projection(G0, 2), inv);
S := Source(Embedding(G0, 1)); C := Source(Embedding(G0, 2));
cc := ConjugacyClasses(G);
mk := function(psi, lam) return ClassFunction(G, List(cc, c -> (Representative(c)^p1)^psi * (Representative(c)^p2)^lam)); end;
zS := First(Elements(Centre(S)), g -> Order(g) = 2);
faithful := Filtered(Irr(S), psi -> zS^psi < 0);
deg := d -> Filtered(faithful, psi -> psi[1] = d);
lam := First(Irr(C), l -> l[1] = 1 and not IsOne(l) );
one := TrivialCharacter(C);
rho0 := deg(2)[1]; rho0pp := deg(2)[2];
rho := mk(rho0, lam); rhopp := mk(rho0pp, lam); pi4 := mk(deg(4)[1], lam); pi6 := mk(deg(6)[1], lam);
ok := true;
report := function(name, b) if b then Print("PASS  ", name, "\n"); else Print("FAIL  ", name, "\n"); ok := false; fi; end;
report("SL(2,5) has faithful irreducibles of degrees 2, 2, 4, 6", SortedList(List(faithful, x -> x[1])) = [2, 2, 4, 6]);
# symmetric powers: 4_f = Sym^3 rho0, 6_f = Sym^5 rho0 (as characters of SL(2,5))
tS := CharacterTable(S);
sym := n -> SymmetricParts(tS, [rho0], n)[1];
report("4_f = Sym^3 rho0", ValuesOfClassFunction(sym(3)) = ValuesOfClassFunction(deg(4)[1]));
report("6_f = Sym^5 rho0", ValuesOfClassFunction(sym(5)) = ValuesOfClassFunction(deg(6)[1]));
report("Sym^3 rho0'' = 4_f as well", ValuesOfClassFunction(SymmetricParts(tS, [rho0pp], 3)[1]) = ValuesOfClassFunction(deg(4)[1]));
# the subgroups fixing K6 (preimage of D10: binary dihedral B20 x C5) and L5 (preimage of A4: SL(2,3) x C5)
emb1 := CompositionMapping(iso, Embedding(G0, 1)); emb2 := CompositionMapping(iso, Embedding(G0, 2));
B20 := Normalizer(S, SylowSubgroup(S, 5)); SL23 := Normalizer(S, SylowSubgroup(S, 2));
report("|B20| = 20 and |SL(2,3)| = 24", Size(B20) = 20 and Size(SL23) = 24);
H6 := ClosureGroup(Image(emb1, B20), Image(emb2, C)); H5 := ClosureGroup(Image(emb1, SL23), Image(emb2, C));
report("[G:H6] = 6 and [G:H5] = 5", Index(G, H6) = 6 and Index(G, H5) = 5);
ind := function(H, chi) return InducedClassFunction(chi, G); end;
res := function(chi, H) return RestrictedClassFunction(chi, H); end;
report("Ind_{K6}(rho|K6) = rho + 4_f chi^3 + 6_f chi^3", ind(H6, res(rho, H6)) = rho + pi4 + pi6);
report("Ind_{L5}(rho|L5) = rho + rho0'' chi^3 + 6_f chi^3", ind(H5, res(rho, H5)) = rho + rhopp + pi6);
# alpha: characters of order 3 of H5 that are trivial on the C5 factor (they factor through SL(2,3) -> C3)
C5img := Image(emb2, C);
ord := a -> First([1..12], n -> ForAll(ValuesOfClassFunction(a^n), v -> v = 1));
alphas := Filtered(LinearCharacters(H5), a -> ord(a) = 3 and ForAll(GeneratorsOfGroup(C5img), g -> g^a = 1));
report("two characters alpha of order 3 of Gal(N/L5), trivial on C5", Length(alphas) = 2);
report("Ind_{L5}(rho|L5 * alpha) = 4_f chi^3 + 6_f chi^3 (both alpha)", ForAll(alphas, a -> ind(H5, res(rho, H5) * a) = pi4 + pi6));
report("Ind_{K6}(rho|) - Ind_{L5}(rho| * alpha) = rho, so L(rho) = L(rho|K6) / L(rho|L5 * alpha)",
       ind(H6, res(rho, H6)) - ind(H5, res(rho, H5) * alphas[1]) = rho);
report("Gemini's ratio L(rho|K6) L(pi6) / L(rho|L5 * alpha) is NOT L(rho): it equals rho + 6_f chi^3",
       ind(H6, res(rho, H6)) + pi6 - ind(H5, res(rho, H5) * alphas[1]) = rho + pi6);
# the two ghosts restrict to genuine characters on every solvable subgroup
ghosts := [pi6 - rho, rhopp + pi4 - rho];
reps := List(ConjugacyClassesSubgroups(G), Representative);
solv := Filtered(reps, IsSolvableGroup);
Print("subgroup classes: ", Length(reps), ", solvable: ", Length(solv), "\n");
genuine := function(th, J) return ForAll(Irr(J), psi -> ScalarProduct(RestrictedClassFunction(th, J), psi) >= 0); end;
report("ghost -rho + 6_f chi^3 restricts to a genuine character on every solvable subgroup", ForAll(solv, J -> genuine(ghosts[1], J)));
report("ghost -rho + rho0'' chi^3 + 4_f chi^3 restricts to a genuine character on every solvable subgroup", ForAll(solv, J -> genuine(ghosts[2], J)));
report("control: -rho alone does not (it is negative on the trivial subgroup)", not genuine(-rho, TrivialSubgroup(G)));
report("control: the ghosts are not genuine on G itself", not genuine(ghosts[1], G) and not genuine(ghosts[2], G));
# fixed vectors (for the remark on p-adic L-functions): rho^H != 0 forces |H| <= 5, so a field carrying a
# rho-isotypic unit has degree >= 120; on such an H (order 5) the faithful chi^3-sector has fixed dimensions (1,0,1,1)
fix := function(chi, J) return ScalarProduct(RestrictedClassFunction(chi, J), TrivialCharacter(J)); end;
withfix := Filtered(reps, J -> fix(rho, J) > 0);
report("every subgroup with rho^H != 0 is trivial or cyclic of order 5; minimal index 120",
       ForAll(withfix, J -> Size(J) in [1, 5]) and Minimum(List(withfix, J -> Index(G, J))) = 120);
report("on each such H of order 5: dim (rho, rho0'' chi^3, 4_f chi^3, 6_f chi^3)^H = (1, 0, 1, 1)",
       ForAll(Filtered(withfix, J -> Size(J) = 5), J -> List([rho, rhopp, pi4, pi6], x -> fix(x, J)) = [1, 0, 1, 1]));
Print("classes of order-5 subgroups with rho^H != 0: ", Number(withfix, J -> Size(J) = 5), "\n");
# line stabilisers (proof of the fixed-vector lemma, corrected 16 Oct 2026): in the 2-dimensional representation rho0
# of SL(2,5), the stabiliser of an eigenline of a non-central element is cyclic of order 4, 6 or 10 (so its order need
# not divide 10), the eigenvalue on the line is a faithful character of it, and the elements acting on the line by a
# fifth root of unity form a subgroup of order 1 or 5
hom := IrreducibleRepresentationsDixon(S, rho0);
F := CF(Lcm(Conductor(Flat(List(GeneratorsOfGroup(S), x -> x^hom))), 60));
stabdata := []; i := 0; v := 0;
for c in ConjugacyClasses(S) do
  g := Representative(c);
  if not g in Centre(S) then
    for v in Eigenvectors(F, g^hom) do
      st := Filtered(Elements(S), h -> RankMat([v, v * h^hom]) = 1);
      i := PositionProperty(v, x -> x <> 0);
      ev := List(st, h -> (v * h^hom)[i] / v[i]);
      Add(stabdata, [Size(st), IsCyclic(Group(st)), Size(Set(ev)) = Size(st), Number(ev, x -> x^5 = 1)]);
    od;
  fi;
od;
Print("eigenline stabilisers [size, cyclic, eigenvalue faithful, #acting by a 5th root of 1]: ", Set(stabdata), "\n");
report("eigenline stabilisers in SL(2,5) are cyclic of orders 4, 6, 10 with faithful eigenvalue; fifth-root part of order 1 or 5",
       Set(List(stabdata, x -> x[1])) = [4, 6, 10] and ForAll(stabdata, x -> x[2] and x[3] and x[4] in [1, 5]));
if ok then Print("ALL PASS\n"); else Print("SOME FAILED\n"); fi;
