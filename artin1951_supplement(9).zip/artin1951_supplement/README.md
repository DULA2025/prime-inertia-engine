# Supplement: the even icosahedral representation of conductor 1951

This supplement accompanies the note *The even icosahedral representation of conductor 1951: a conditional reduction and explicit residual bridges* (Dula, 16 October 2026; updated 19 October, twice on 20 October, three times on 21 October, and on 26 October 2026). The note is in `note/`.

Every computational statement in the note is listed below, with the script that produces it and the output that records it.
- **Exact** statements use PARI/GP through `cypari2`.
- **Numerical** statements are marked [N]: the Hejhal computation and the Galois series over ℚ in the introduction, Remark 3.10 (five imaginary quadratic fields and ℚ(√2)), the remarks of §7, and Remark 8.4. None is used in any proof.
- **Ball arithmetic:** Proposition 7.1 is certified with Arb through `python-flint`.

## Requirements and setup

- **Software:** Python 3 with `cypari2` (run with PARI/GP 2.17.4), plus `numpy`, `numba`, `sympy`, `mpmath` and `scipy`; `python-flint` 0.9 for Proposition 7.1. One script, `note/check_sl25_identities.g`, uses GAP (run with GAP 4.16.1).
- **Paths:** the scripts were run in a directory `/home/claude/research`, and many use absolute paths that begin with that prefix. Before re-running anything, run `sh relocate.sh` once from this folder. It rewrites the prefix to the folder's actual location.
- **Working directory:** run each script from its own folder, for example `cd mod2 && python3 sat.py`, because some scripts read and write files relative to the current directory.
- **Memory:** the field-equality certificates allocate 5–6 GB for the PARI stack.

## Map from the note to the files

### Notation (§2) and smaller exact facts

`note/check_note_claims.py` checks 78 statements; its output is `note/check_note_claims.out` (78 of 78 pass; the six checks labelled [N] are numerical). It runs in a few minutes. The 13 checks for §8 are described in the §8 entry below. The last sixteen checks are:
- the update to Question 3 (Leopoldt for all six fields K₁₂ at ℓ ≤ 7);
- Leopoldt at ℓ = 11, 31, 41, 61, 71, the hypothesis of Proposition 9.1, and its example E = ℚ(√−7) with ℓ = 11, 71;
- the two new numerical tests (the Galois series over ℚ and over ℚ(√2));
- the mod-2 Bianchi models of Question 3. This check recomputes level 23·O_E exactly and reads the records for 31, 47 and 79; it needs `numba`;
- the additions of the afternoon of 21 October: the icosahedral control at level 31·O_E (recomputed, about 30 seconds), the record of the search with nebentypus, and the record of the weight-one form of level 633;
- the additions of the evening of 21 October:
  - the 633 model computed four ways (records);
  - the sparse engines recomputed at level 127·O_E by three routes (about a minute);
  - the record of level 1951·O_E. With it, the eigenvalues of ρ̄₂ are recomputed from the Frobenius classes, and the records of the further Hecke operators and of the independent Lanczos run are read;
- the additions of 26 October (lifting the mixed classes to characteristic 0):
  - the validation of the two new engines (records), with the 2-adic test at level 23 recomputed (about a minute);
  - the small levels 23, 31 and 47, for every nebentypus of 2-power order;
  - the 633 model;
  - level 1951·O_E. Here dim S₂(Γ₀(1951), χ) = 161 is recomputed.

The statements it checks:

- **The character χ:** χ(3) = ζ₅², 3 is a primitive root mod 1951, χ is Conrey 1951.908, and χ(2) = ζ₅³.
- **Dimensions:** dim S₂(Γ₀(1951), χ) = 161 and dim S₂(Γ₀(1951)) = 162.
- **The quintic field L₅:**
  - disc L₅ = 1951⁴, and poldisc f₅ = 2²·7²·71²·137²·1951⁴;
  - Frob₂ has cycle type (3,1,1) in L₅;
  - the trace-zero lattice of O_{L₅} is A₄ scaled by 1951;
  - the explicit u, v for d = 1 and d = 3 have the stated properties.
- **The fields F and K:**
  - their defining polynomials;
  - h(F) = h(K) = 1, certified with `bnfcertify`;
  - disc K = 225;
  - ζ₅ ∉ F, K.
- **The quaternion algebra (δ, −1):**
  - δ = −(10+2√5) = −4√5·φ, and (2(ζ₅−ζ₅⁻¹))² = δ;
  - over ℚ(√5), (δ, −1) is split at the places above 2 and 5 and ramified at both real places;
  - it is split over F and over K.
- **The fields K₆ and K₂₄:**
  - K₆ has Galois group of order 60 on 6 points and discriminant 1951⁴;
  - disc K₂₄ = 1951¹⁶ = (disc K₆)⁴, so K₂₄/K₆ is unramified at finite places;
  - K₂₄ ⊃ K₆, and K₂₄ is totally imaginary.
- **Section 6 constants:**
  - the Sturm bounds;
  - 24/1950 = 4/325 (the Eisenstein series 𝓔 ≡ 1 mod 4);
  - x + y = z⁴ and xy = z³ in 𝔽₁₆.
- **Remark 6.3 (the √5-conjugate):**
  - σ fixes every trace value modulo √5, so ρ₀″ mod λ = ρ̄;
  - for the character ψ mod 11 with ψ(2) = ζ₅, the first zeros of L(s, ψ) and L(s, ψ²) differ (5.134 and 4.629), so σ does not act on analytic data.

The trace table t_p = tr ρ₀(Frob_p) for p < 3.2·10⁶ comes from `overnight/traces/galois_traces.py 3200000`. That script uses the helper `dokchitser.py` (resolvents for the two classes of 5-cycles) and the files `K24.txt` and `local1951.json`. Its output is `galois_traces_3200000.json`, with log `t3200k.log`.
- `local1951.json` records which class of elements of order 5 carries |t| = φ − 1, fixed by a local computation at 1951. That choice is certified independently by Theorem D (see §6 below and Table 1 of the note).
- The sign choice is fixed by K₂₄, which is unramified over K₆ (checked above).

### Theorems A′ and A″, Proposition 3.9, Remark 3.11 (§3)

Theorems A′ and A″, Lemmas 3.5 and 3.7, Remark 3.8 and Proposition 3.9 are proved in the note and use no computation, apart from three small facts checked in `note/check_note_claims.py`: A₅ has no element of order 6 or 10; 1951 is inert in ℚ(i) and ℚ(√−2); every odd prime splits in ℚ(i), ℚ(√−2) or ℚ(√2).

`note/check_sl25_identities.g` (GAP) checks the character identities of Remark 3.11 in G = SL(2,5) × C₅ = Gal(N/ℚ). Run it with `echo 'Read("check_sl25_identities.g");' | gap -q` from `note/` (or `sage -gap -q`). Its output is `note/check_sl25_identities.out` (all pass). It checks:

- 4_f = Sym³ρ₀ and 6_f = Sym⁵ρ₀;
- Ind_{K₆}(ρ|) = ρ + 4_f χ³ + 6_f χ³, Ind_{L₅}(ρ|) = ρ + ρ₀″χ³ + 6_f χ³, and Ind_{L₅}(ρ| ⊗ α) = 4_f χ³ + 6_f χ³ for both characters α of order 3, so L(ρ, s) = L(ρ|_{K₆}, s) / L(ρ|_{L₅} ⊗ α, s);
- the variant with an extra factor L(6_f χ³, s) in the numerator gives ρ + 6_f χ³, not ρ;
- the virtual characters −ρ + 6_f χ³ and −ρ + ρ₀″χ³ + 4_f χ³ restrict to genuine characters on all 26 classes of solvable subgroups (28 classes in all).

### Theorem B (§4)

| Statement | Script | Output |
|---|---|---|
| (δ, −1) over ℚ(√5) and the CM quartic fields | `mod5/m5_quartic.py`; also `note/check_note_claims.py` | `mod5/m5_quartic.json` |
| Least certifying prime for the 31 imaginary quadratic fields with \|disc\| ≤ 100 (maximum 53; 13 for ℚ(i), 2 for ℚ(√−7)) | `mod5/m5_least_primes.py` | `mod5/m5_least_primes.json` |
| Density 0.375 ± 0.001 for twelve fields (split primes 7 ≤ p < 3.2·10⁶) | `mod5/m5_quadratic.py` | `mod5/m5_quadratic.json` |

`m5_quadratic.py` starts at p = 7, so its "first" prime can be larger than the least prime in `m5_least_primes.json` (for ℚ(√−7): 37 versus 2).

### Theorem C (§5)

**The curve E₀ over F = ℚ(i, √5), with accessory irrationality √−1.**

| Statement | Script | Output |
|---|---|---|
| Lattice and u, v | `moonshine/lattice.py` | `moonshine/lattice.pkl` |
| j₀ at 600 digits, recognised exactly | `moonshine/klein4.py 600` | `moonshine/j0_exact_600.pkl`, `moonshine/j0_exact.txt`; exported to `audit/j0_exact.json` by `audit/klein_export.py` |
| (i) the 5-isogeny field equals F·K₆ | `moonshine/certify_iso.py` | `moonshine/certify_iso.log` |
| Projective Frobenius orders at 970 primes of F, all four conjugates of j₀ | `moonshine/verify_E.py` | `moonshine/verify_E.log` |
| Integral model, places with v(j₀) < 0, witnesses (30 of the 41 testable split primes < 1200, smallest 89) | `cmmod/efg.py` | `cmmod/efg.json` |
| 44 split primes, the three excluded ones, and the norm-conic point | `audit/klein_export.py` | `audit/klein_counts.json` |

**The curve E₁ over K = ℚ(√5, √−3), with accessory irrationality √−3.**

| Statement | Script | Output |
|---|---|---|
| Lattice vectors with Tr u² = 3·Tr v² | `klein3/lattice3.py` | `klein3/lattice3.pkl` |
| j₁ at 600 digits (residual 10⁻⁵⁹⁴) | `klein3/klein_sqrt3.py 600` | `klein3/j1_exact_600.pkl`, `klein3/j1_exact.json`, `klein3/klein_sqrt3.log` |
| (i) the 5-isogeny field equals K·K₆; a_P² ≡ N(P)·t̄_p² mod 5 at 383 of 383 degree-one primes | `klein3/certify_iso_K.py` | `klein3/certify_iso_K.json`, `klein3/certify_iso_K.log` |
| (ii) places with v(j₁) < 0; integral model; Frobenius orders at 1227 of 1227 primes, all four conjugates; witnesses (34 of 51, smallest 19) | `klein3/certify_K.py` | `klein3/certify_K.json` |

`cmmod/README.md`, `cm_hyp.py` and `dg3.py` record the earlier check of the Caraiani–Newton hypotheses for E₀, including E[3].

### Theorem D (§6)

| Statement | Script | Output |
|---|---|---|
| 2-saturation (rank 153 → 161 in four rounds); the predicted q-expansions lie in S̄ for n ≤ 2400; the controls do not | `mod2/sat.py` (uses `mod2/brute40np.py`) | `mod2/sat_2400.json`, `mod2/sat.log`, `mod2/basis_mod2_sat_k{1,2}_2400.npy` |
| Hecke matrices T₂, T₃, T₅, T₇ on S̄: consistency to n ≤ 2400/ℓ, commutation, joint kernels 4, 3, 2, 1, 1, generalised dimensions 3 + 6 | `mod2/hecke2.py` (reads the saturated bases) | `mod2/hecke2.json` (key `chi^1`; key `chi^2` is the conjugate system ρ″ = ρ₀″ ⊗ χ of Remark 6.3, with T₂-roots 11 = x² and 3 = y² and generalised dimensions 3 and 6) |
| (v) the weight-one form g₁: H(q)² lies in the reduction of S₂(Γ₀(1951), χ²) to n ≤ 2400 (controls: H(q) itself, H(q)² in the χ space, √5-conjugate traces); weight-one Hecke relations at ℓ = 2, 3, 5, 7, 11, 13; the identities h_j + y h_{j−1} = x^j etc. in 𝔽₁₆; the conjugate system gives σ(H) | `mod2/katz_weight1_check.py` (uses `mod2/brute40np.py` and the saturated bases) | `mod2/katz_weight1_check.log` (16 of 16 pass) |
| Table 1, v₂(D_ℓ) and controls | `audit/charp2.py`, `audit/charp2_controls.py` | `audit/charp2.json`, `audit/charp2_controls.json` and logs |

`audit/AUDIT_RESPONSE.md` records an earlier outside audit of these computations, and why its negative results came from using the trivial-character space and from reading 𝔽₁₆ codes as integers.

**Encoding of 𝔽₁₆.** 𝔽₁₆ = 𝔽₂[z]/(z⁴+z³+z²+z+1), where z = ζ₅ mod 2. The JSON files write elements as 4-bit codes b₀ + 2b₁ + 4b₂ + 8b₃ ↔ b₀ + b₁z + b₂z² + b₃z³. So x = z + z² is 6, y = 1 + z³ is 9, ā₂ = z⁴ is 15 and χ̄(2) = z³ is 8.

### Section 7: two further computations

| Statement | Script | Output |
|---|---|---|
| Explicit-formula conventions for L(ρ, s) (Gaussian tests against the zero list, 10⁻¹⁵) | `brainstorm2/weil_validate.py` | printed |
| Closed forms of the archimedean entries (10⁻³¹ vs quadrature); cᵀQc against Σ\|φ̂(γ)\|² over 553 zeros (3·10⁻¹¹) | `brainstorm2/weil_check_matrix.py` (uses `zeros_L_rho_1951.txt`, certified sign-change intervals of the zeros, conditional on holomorphy) | printed |
| Proposition 7.1: positivity of Q_X on V_m for (X, m) = (10⁴, 30), (10⁵, 45), (10⁶, 60), lower bounds 3.0·10⁻¹⁹, 5.1·10⁻⁴⁵, 1.0·10⁻⁷⁷; upper bound 5.19·10⁻⁴⁵ at 10⁵ | `brainstorm2/weil_certify.py X m bits mu0 [vector]` | `brainstorm2/weil_cert_X*.json`, `weil_cert_1e5.log`, `weil_cert_1e6.log` |
| Remark 7.2(1) [N]: zeros of the minimiser vs PARI zeros (160 and 420 bits) | `brainstorm2/weil_run.py X m dps`, `brainstorm2/pari_hp.py bits T` | `brainstorm2/weil_X*_s0.json`, `weil_1e*.log`, `zeros_hp_*.json` |
| Remark 7.2(2) [N]: shuffled traces (seed 7) | `brainstorm2/weil_run.py 10000 30 60 7` | `brainstorm2/weil_X10000_m30_dps60_s7.json` |
| Remark 7.2(3) [N]: injected pole and pole–zero pairs | `brainstorm2/weil_pole_demo.py`, `brainstorm2/weil_dipole_scan.py` | `brainstorm2/weil_pole_demo.json`, `weil_dipole_scan.json` |
| Lemma 7.3: ρ^H ≠ 0 only for \|H\| ≤ 5, one class of order 5, fixed dimensions (1, 0, 1, 1); in its proof, the stabilisers of eigenlines of non-central elements of SL(2,5) are cyclic of orders 4, 6, 10 | `note/check_sl25_identities.g` (GAP) | `note/check_sl25_identities.out` |
| det(1 − ρ(Frob_p)) = 0 for p = 11, 37; det(1 − ρ̄₂(Frob₂)) = z + z²; det(1 − ρ(Frob_p)) a unit for p = 3, 5, 7, 13; [N] the 2-adic pattern of Remark 7.4(3); [N] root number and PARI values at s = 0, −2 | `note/check_note_claims.py` (last six checks) | `note/check_note_claims.out` |
| Remark 7.4 [N]: root numbers of the four conjugates (unique Gauss-sum candidate) | `brainstorm/rootnum.py` | `brainstorm/rootnumbers.json` |
| Remark 7.4 [N]: L(ρ, 1−n) ∈ ℤ[ζ₅] for 67 odd n ≤ 1459 (functional equation + Euler product, no holomorphy assumption) | `brainstorm/negvalues.py n,n,... out.json` (needs the trace table to 3·10⁷ for n ≳ 200: regenerate with `overnight/traces/galois_traces.py`, P = 3·10⁷; not shipped, 75 MB) | `brainstorm/neg[A-E].json` and logs |
| Remark 7.4(1)–(2) [N]: units, 4034 tight congruences for p = 3, 5, 7, 13, limits to s = 0, trivial zero at p = 11 | `brainstorm/padic.py` | `brainstorm/padic_report.json`, `padic_all.log` |
| Remark 7.4(2)–(3) [N]: p = 37, p = 2, derivative at p = 11 | `brainstorm2/padic2.py` | `brainstorm2/padic2_report.json` |
| Remark 7.4(1), (3): the Euler factors at s = 0 are units for p = 3, 5, 7, 13; [N] p = 2: all 2211 differences exact, residue 1 + ζ₅ + ζ₅³ mod 2, PARI's L(ρ, 0) fits; normalisation check of the factor 2^{[F:ℚ]} on 36 odd quadratic characters, with the control χ₈ | `brainstorm2/padic3.py` | `brainstorm2/padic3_report.json`, `padic3.log` |

### Section 8: the six representations of prime conductor below 10⁴ (added 20 October 2026)

All files are in `questions/`, which has its own README with the results for Questions 1–5 of §9. Run the scripts from that folder.

| Statement | Script | Output |
|---|---|---|
| The six fields of Doud–Moore, discriminants p⁴; Lemma 8.1 checked with `qfisom` | `questions/fields6.py`, `questions/klein_general.py`; also `note/check_note_claims.py` | `questions/fields6.json`, `questions/klein_p*_d*.log` |
| Corollary 8.2: explicit orthogonal pairs in A₄ with norm ratio d, for every squarefree d ≤ 40 | `questions/a4_pairs.py` | `questions/a4_pairs.log` |
| Frobenius classes for each p (5A/5B by resolvents; for 1951, 0 mismatches with the trace table on 21218 primes) | `questions/classes.py p NB` | `questions/classes_<p>.json`, `classes_<p>_<NB>.log` |
| Theorem E and Table 2: Klein invariants at 600/700 digits; 5-isogeny field = K_d K₆; places with v(j) < 0; witnesses; Frobenius check | `questions/klein_general.py p d DPS`, `questions/klein_certify.py p d 3000` (chains: `run_klein_chain.sh`) | `questions/klein_p<p>_d<d>.json/.log`, `questions/klein_certify_p<p>_d<d>.json/.log` |
| Theorem F and Table 3: saturation, membership and controls, Hecke matrices, eigenspaces, odd coefficients | `questions/mod2_general.py p NB eps` (uses `questions/f16.py`) | `questions/mod2_p<p>_eps<e>.json/.log` |
| Remark 8.3(2): the run for 8501 was killed for lack of memory (a hold, not a result) | `questions/mod2_general.py 8501 10000 0` | `questions/mod2_p8501_eps0.log` |
| Remark 8.4 [N] and Table 4: K₁₂, its units, L-values at 57 digits, the A(V, f) | `questions/k12_general.py p`, `questions/stark_general.py p 57 NB` (chain: `run_stark_chain.sh p NB`) | `questions/k12_p<p>.*`, `questions/stark_ad_p<p>_prec57.json`, `stark_p<p>_57.log` |
| Remark 8.4, cross-check for 1951 with the trace table of §2 | `questions/stark_ad.py` (reads `bianchi/chunks`, not shipped) | `questions/stark_ad_prec57.json` |
| Tables 2–4 of the note | `questions/summarize_questions.py`, `questions/make_note_section8.py` | `questions/questions_summary.json`, `questions_tables.md`, `note_section8.tex` |

`note/check_note_claims.py` re-checks the exact statements of §8. It verifies the six fields and lattices; the local facts behind Corollary 8.2; the root-lattice determinants; and the u, v of all eleven new curves. It recomputes, from the exact j, the first witness and the places with v(j) < 0 of each curve. It also checks the six mod-2 spaces, the dimensions of the spaces for 8501 and 9461, and the Sturm identity in the proof of Theorem F. A final check covers the Stark values [N].

### Section 9, Question 3 (the family F₇ for Theorem A′)

| Statement | Script | Output |
|---|---|---|
| 2 splits in ℚ(√−q) for q ≡ 7 mod 8; every odd prime p < 10⁶ splits in one of the first fifteen such fields (q ≤ 263) | `roadA/family_check.py` (p < 10⁵ also in `note/check_note_claims.py`) | `roadA/family_check.log` |

### Remark 3.10 and Question 3 (added 19 October 2026)

The Bianchi scripts read the trace table as class codes per prime (`bianchi/chunks/codes_000.npz` … `codes_043.npz`, primes < 4.4·10⁸, 44 MB, not shipped). Regenerate them with `bianchi/drive_codes.py part nparts 4.4e8` (it uses `bianchi/fasttraces.py`, `resolvents.json`, `local1951.json`, `K24.txt`; `check_codes.py` compares with the older table, 0 mismatches on 13848 primes). `bianchi/bianchi.py` also reads the classes of the primes of bad reduction for the auxiliary polynomials from `galois_traces_150000.json` (path at the top of `load_codes`).

| Statement | Script | Output |
|---|---|---|
| Remark 3.10 [N], ℚ(√−7), N(ν) ≤ 10⁸ | `bianchi/bianchi.py`, `bianchi/run_h1.py` | `bianchi/h1_X1e8_s2.log`, `h1_X1e+08_s2.json` |
| Remark 3.10 [N], ℚ(√−23), ℚ(√−31) (principal component, h = 3) | `bianchi/bianchi_q.py`, `bianchi/run_h1q.py 23 3.3e8 8 4`, `… 31 4.4e8 8 5` | `bianchi/h1q23_X3.3e8_s4.log`, `h1q31_X4.4e8_s5.log`, json |
| Remark 3.10 [N], ℚ(i), ℚ(√−2) (2 ramified) | `bianchi/bianchi_m.py`, `bianchi/run_h1m.py 1 1e8 8 6`, `… 2 2e8 8 7` | `bianchi/h1m1_X1e8_s6.log`, `h1m2_X2e8_s7.log`, json |
| Remark 3.10, the table (largest defect for ρ, smallest defect of a control) | `bianchi/h1_summary.py` | `bianchi/h1_summary.json`, `h1_five_fields.png` |
| Remark 3.10, sign changes over ℚ break Γ₀(1951) | `bianchi/q_signflip.py`, `q_signflip2.py` | `bianchi/q_signflip*.log/.json` |
| Question 3: K₁₂ (fixed field of C₅ in M), discriminant 1951⁸ | `h1proof/k12_build.py` | `h1proof/k12.json` |
| Question 3: units of K₁₂ (bnfinit; GRH-conditional, not needed for the rank statement) | `h1proof/k12_units.py` | `h1proof/k12_units.log`, `k12_bnf_units.gp` |
| Question 3: Leopoldt for K₁₂ at p = 2, 3, 5, 7 (rank 11 of the p-adic logarithms) | `h1proof/k12_leopoldt.py p prec` | `h1proof/leopoldt_p2.log` … `leopoldt_p7.log`; p = 2 also in `note/check_note_claims.py` |
| §9, Question 3, update (20 October): Leopoldt for the fields K₁₂ of all six conductors at ℓ = 2, 3, 5, 7 (24 cases, rank 11) | `questions/k12_leopoldt_general.py p ℓ 400`, chain `questions/run_leopoldt.sh` | `questions/leopoldt_p<p>_ell<ℓ>.json/.log`; 9461 at ℓ = 2 recomputed in `note/check_note_claims.py` |
| Proposition 9.1 (nearly ordinary tangent spaces; proof in the note): its hypothesis H¹(G_ℚ, ad⁰ρ ⊗ ℚ̄_ℓ) = 0 at ℓ = 11, 31, 41, 61, 71, the primes ≡ 1 mod 5 below 100, for all six conductors (30 cases, rank 11) | `questions/k12_leopoldt_general.py p ℓ 300`, chain `questions/run_leopoldt_aux.sh` | `questions/leopoldt_p<p>_ell<ℓ>.json/.log`; 9461 at ℓ = 11 recomputed in `note/check_note_claims.py` |
| Remark 3.10 [N], the real quadratic field ℚ(√2) (Hilbert–Maass series on ℍ × ℍ, sign sgn(Nα) from ρ(c) = −I at both real places) | `hilbert/hilbert_r2.py 3.0 6 2 k 2` for k = 0, 1, then `hilbert/hr2_combine.py 3.0 2 2`; see `hilbert/README.md` | `hilbert/hr2_C3_s2_p0.log`, `hr2_C3_s2_p1.log`, `hr2_C3_s2_combine.log`, `hr2_C3.00_s2.json`; pilot `hr2_C1_s1.log`, `hr2_C1.00_s1.json` |

### §9, Question 3: mod-2 Bianchi classes with mixed refinements (added 21 October 2026, extended the same afternoon and evening, and on 26 October)

All files are in `bianchi2/`, with their own README. The class at level 1951·O_E (index 3 806 402) was computed on the evening of 21 October, with sparse elimination and block Lanczos over F₁₆. Whether the mixed classes lift to characteristic 0 was tested on 26 October (last four rows). Two tools were used: a 2-adic first-order test, and the characteristic-0 rank bounded over a prime field F_P and compared with the number of base changes.

| Statement | Script | Output |
|---|---|---|
| Validation: presentation (Finis–Grunewald–Tirao (2.10)); dim H¹ against LMFDB `sl2dims/2.0.7.1` at six levels; base change of 14a1 and 11a1; PGL₂ cohomology = base change at (11), (23), (31), (47) | `bianchi2/validate.py` | `bianchi2/validate.log` |
| First search for models, prime N ≤ 400 (superseded: it compared each system only with its own Galois conjugates) | `bianchi2/find_models.py 400` | `bianchi2/find_models.log` |
| Search for models with trivial character: odd squarefree N ≤ 400, companions across Hecke orbits and primes above 2; models at 39 levels, all dihedral | `bianchi2/find_models2.py 151`, `find_models2.py 400 24 153` | `bianchi2/find_models2.log`, `find_models2_153_400.log` |
| Search for models with nebentypus: odd N ≤ 150 and 161, 175, 189, 203, 217, every even character whose odd part has order 1, 3, 5 or 15; 26 companion classes, all dihedral or reducible; 97 icosahedral systems at 22 levels, none with a companion; 11 newforms skipped by the time limit, all at levels > 95 (two completed in the redo) | `bianchi2/find_models3.py 3-150,161,175,189,203,217 200 150`, redo `find_models3.py 117,145 200 1200` | `bianchi2/find_models3.log`, `find_models3_redo.log` |
| The models N = 23, 31, 47, 79 over ℚ(√−7), PGL₂, mod 2: ρ̄-parts and (T_v, T_v̄) pairs, including (x, y) and (y, x) | `bianchi2/run_model.py N ORBIT` | `bianchi2/model_N*.log/.json` |
| Independent recomputation over F₁₆ for N = 23, and eigenvector tests at nine unused primes | `bianchi2/verify_mixed.py` | `bianchi2/verify_mixed_toy23.log` |
| The mixed vectors for N = 23, 31, 47 are eigenvectors with the eigenvalue of ρ̄ at every split prime of norm ≤ 200 (38, 40, 40 primes) | `bianchi2/extend_checks.py N ORBIT 200` | `bianchi2/extend_checks_N*.log/.json` |
| Control: the icosahedral system of level 31 with nebentypus of order 5 (ordinary at 2, no companion); at level 31·O_E with F₁₆ and nebentypus of order 5, its ρ̄-part is 1-dimensional with only (a₂, a₂); the off-diagonal pairs of H¹ are Eisenstein | `bianchi2/control_A5_31.py ±1` | `bianchi2/control_A5_31_s1.log/.json`, `control_A5_31_s-1.log/.json` |
| The weight-one newform 633.1.m.b (projective image A₅, the smallest such level by Buzzard–Lauder): Frob₂ of projective order 5, A₅ modulo 2; index 449 440 over ℚ(√−7) | `bianchi2/check_633.py` | `bianchi2/check_633.log` |
| Sparse engines: sparse elimination with a bitsliced dense core; block Lanczos over F₁₆ with a completeness certificate; a memory-lean pipeline. Checked against the dense engine and each other (planted kernels; dim H¹ at seven levels by three routes) | `bianchi2/sparse_h1.py`, `gf16_bits.py`, `lanczos16.py`, `sparse_big.py`; `validate_sparse.py` | `bianchi2/validate_sparse.log` |
| Dihedral models 87, 93, 103, 115, 127, 143: mixed pairs, with joint eigenvectors at 23–24 Hecke operators | `bianchi2/run_sparse_auto.py N`, `run_sparse.py 103 2 2` | `bianchi2/sparse_auto_N*.json/.log`, `sparse_N103_orbit2.json` |
| The 633 model over ℚ(√−7) (F₁₆, nebentypus): dim H¹ = 348; ρ̄-part 24; pairs (x,x) 8, (x,y) 4, (y,x) 4, (y,y) 8; one joint eigenvector at all 23 operators in each. Computed four ways | `bianchi2/run_sparse.py 633 1 10 odd A5` (with `SPARSE_SEED`, `SPARSE_SOLVER`), `run_big.py 633 1 10 odd A5` | `bianchi2/sparse_633.log`, `sparse_633_seed1234.log`, `sparse_633_lanczos.log`, `big_633.log`, `big_633_v2.log`, `sparse_N633_k1_o10_A5*.json`, `big_N633_k1_o10_A5.json` |
| Level 1951·O_E (F₁₆, nebentypus χ̄⁻¹∘N, eigenvalues of ρ̄₂ from the Galois side): kernel 664 = Krylov bound (complete), dim H¹ = 663; 24 Hecke operators commute; ρ̄₂-part 27; pairs (x,x) 7, (x,y) 3, (y,x) 3, (y,y) 14; one joint eigenvector at all 24 operators in each | `bianchi2/run_big.py 1951` | `bianchi2/big_1951.log`, `big_N1951.json`, `big_cache_N1951/lanczos_runs.json` |
| 1951: the four joint eigenvectors are eigenvectors with the eigenvalues of ρ̄₂ at 26 further operators (T_𝔮, T_𝔮̄ for the split primes 79 < q ≤ 200, and T_(17), T_(19)), so at every prime of E of norm ≤ 200; an independent Lanczos run (another diagonal and start block) gives the same 664-dimensional kernel | `bianchi2/extend_big.py 1951 200 30`, `recheck_core.py big_cache_N1951 2 12` | `bianchi2/extend_big_N1951.log/.json`, `recheck_core_N1951.log`, `recheck_core_big_cache_N1951_s2.json` |
| First runs (traces from class-group formulas); the PSL₂ run doubles the multiplicities | `bianchi2/mod2_refine.py toy23|toy47 PSL|PGL` | `bianchi2/mod2_refine_toy*_*.log/.json` |
| Lifting to characteristic 0, validation: the F_P engine (closure, Markowitz, block Lanczos over F_P with a Krylov bound) equals the dense engine in 8 cases; the 2-adic first-order test (lifting modulo 4 or modulo ϖ²) equals the 2-adic Smith form of the integer relator matrix at 23 and 31 | `bianchi2/sparse_fp.py`, `fp_check.py`; `bockstein.py`, `snf2_check.py 23|31` | `bianchi2/fp_check.json`, `snf2_check_23.json`, `snf2_check_31.json`, `snf2_check_31.log` |
| Lifting at 23, 31, 47: the mixed classes are reductions of no eigenform of characteristic 0 at that level with any nebentypus of 2-power order. ψ = 1: rank 2, 2, 4 = base change. Quadratic ψ: the mod-4 obstruction is non-zero. ψ of order 4–32: the characteristic-0 spaces are computed, and T_v + T_v̄ is nilpotent mod ϖ on them | `bianchi2/bock_small.py N`, `char0_psi.py N K` | `bianchi2/bock_small_*.json`, `char0_psi_*.json`, `char0_psi_47.log`, `char0_psi_47_o16.log` |
| Lifting at 633. With the Teichmüller lift of the nebentypus: dim H¹ over F_P ≤ 68 = number of base changes, for two primes, so there is no lift. Quadratic twists: bounds 316, 282, 212 against 280, 280, 68 base changes (not decided). The first-order obstructions of the four eigenvectors vanish for every ψ | `bianchi2/fp_big.py 633` (env `QMASK`, `FP_PRIME`, `FP_SEED`), `bc_counts.py 633`, `bock_big.py 633` | `bianchi2/fp_big_633*.log`, `fp_big_N633_*.json`, `bc_counts_633.json`, `bock_big_633.log`, `bock_big_N633_k1_o10_A5.json` |
| Lifting at 1951. dim H¹(Γ₀(1951·O_E), F_P(χ⁻¹∘N)) ≤ 161 = dim S₂(Γ₀(1951), χ) (P = 1 048 361; block Lanczos over F_P, V_m = 0). So with this nebentypus the characteristic-0 cohomology is the 161 base changes, and the mixed classes do not lift. The first-order obstructions vanish for every ψ. On the ρ̄₂-part the classes lifting modulo 4 are (x,x) 3, (x,y) 2, (y,x) 2, (y,y) 10. Base changes for the quadratic twist: 649 | `bianchi2/fp_big.py 1951`, `bc_counts.py 1951`, `bock_big.py 1951` | `bianchi2/fp_big_1951_q0*.log`, `fp_big_N1951_q0_*.json`, `bc_counts_1951.json`, `bock_big_1951.log`, `bock_big_N1951.json` |

`h1proof/README.md` gives the proofs of Theorem A″ and Proposition 3.9 in plain text, the deduction of H¹(G_{ℚ,S}, ad⁰ρ ⊗ ℚ̄_p) = 0 from Leopoldt for K₁₂, and the defect table. Its statement that every first-order deformation of ρ|G_E has anti-parallel weights was wrong in general and is corrected there (20 October): it holds for the base-change choice of ordinary lines, and Proposition 9.1 of the note treats both choices.

`questions/README.md` (last section) answers the four directions of the list relayed on the afternoon of 20 October. Over ℚ(√2) (`hilbert/`), the Galois series of ρ|G_F is invariant under Γ₀(1951·O_F) to 5.6·10⁻⁹ at 6 random γ, against at least 1.9·10⁻³ for the controls.

### Introduction, numerical [N]

| Statement | Script | Output |
|---|---|---|
| Hejhal's method on Γ₀(1951) with nebentypus χ and λ = 1/4; agreement 3·10⁻⁸ for n ≤ 800 | `maass/hejhal.py` (see `maass/HEJHAL_README.md`); `maass/h_compare.py` | `maass/hejhal_*.json`, `maass/h_compare.json` |
| Agreement 6·10⁻⁷ for n ≤ 2000, and the √5-conjugate form at level 1951 (nebentypus χ², files `*_k2.json`) | `maass/quartet.py` | `maass/quartet.json` |
| The Galois series √y Σ a_n K₀(2πny) sin(2πnx), n ≤ 40000, without Hejhal's method: invariance under Γ₀(1951) at 24 random γ to 1.7·10⁻¹⁰ (ρ, χ) and 1.1·10⁻¹⁰ (ρ″, χ²); controls 1.9 to 12; first-order r² below 4·10⁻¹¹ | `maassq/maass_q_isolate.py` (reads `bianchi/chunks`, not shipped); see `maassq/README.md` | `maassq/maass_q_isolate.log`, `maass_q_isolate.json` |

The file `hejhal_eps-1_Y4.00e-04_M5000_conj.json` is a control with nebentypus χ̄ (complex conjugation), not the √5-conjugate form.

The helper `div/dcore.py` builds the Dirichlet coefficients of L(ρ, s) from the trace table.

## Labels

- [T] means a theorem or an exact computation.
- [N] means numerical evidence.
- Nothing in this supplement proves that L(ρ, s) is entire. Theorem A of the note is conditional on two open hypotheses, H1 and H2; Theorem A′ is conditional on H1 for infinitely many imaginary quadratic fields; Theorem A″ is conditional on H1 for one quadratic field and one cyclic cubic field.
