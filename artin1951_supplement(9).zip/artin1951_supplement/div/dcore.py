"""Core for the divisibility / pole detector.

L(rho) = L(psi,K12) / L(phi,K10)  (Hecke, both entire)  =>  Lambda(rho,s) is meromorphic, satisfies its functional equation
Lambda(rho,s) = W Lambda(rho~,1-s), and its only possible poles are at zeros of L(phi,K10).  Shifting the Mellin contour:

    D(t) := theta(t) - W t^{-1} theta~(1/t)  =  sum over poles s0 of Lambda(rho) of  Res_{s=s0} Lambda(rho,s) t^{-s}

for complex t with |arg t| < pi/2, where theta(t) = sum a_n K(n t / sqrt N) and K is the inverse Mellin transform of the
gamma factor.  Divisibility L(phi,K10) | L(psi,K12) (= Artin for rho) <=> D == 0.  On the ray arg t = alpha a pole at
height gamma is damped only by exp(-(pi/2 - alpha) gamma), so rotating t toward the imaginary axis reaches high poles.
Gamma factor here: Gamma_R(s+1)^2 (rho0(c) = -I), K(x) = 4 x K_0(2 pi x);  zeta^2 control: Gamma_R(s)^2, K = 4 K_0(2 pi x)."""
import json, math, numpy as np
from scipy.special import kv
N0 = 1951
PHI = (1 + 5 ** .5) / 2
_D = None
def traces(path="/home/claude/research/overnight/traces/galois_traces_3200000.json"):
    global _D
    if _D is None: _D = json.load(open(path))
    return _D
def dlog():
    dl = np.zeros(N0, int); x = 1
    for k in range(N0 - 1): dl[x] = k; x = x * 3 % N0
    return dl
def coeffs(name, M, a1951=None):
    """a_n, n <= M.  name: 'rho0' (N=1951^2, a_{1951}=0), 'rho0pp', 'rho' = rho0 x chi^3 (N=1951, a_1951 given)."""
    D = traces(); dl = dlog(); z5 = np.exp(2j * np.pi / 5)
    a = np.zeros(M + 1, complex); a[1] = 1
    ps = sorted(int(p) for p in D["t"] if int(p) <= M)
    if M >= N0: ps = sorted(set(ps + [N0]))
    for p in ps:
        if p == N0:
            ap, det = (0.0 if name.startswith("rho0") else a1951), 0.0
        else:
            t = D["t"][str(p)]
            if name == "rho0pp":
                t = {PHI: 1 - PHI, 1 - PHI: PHI, -PHI: PHI - 1, PHI - 1: -PHI}.get(min((PHI, 1 - PHI, -PHI, PHI - 1, 99), key=lambda v: abs(v - t)), t) if min(abs(t - v) for v in (PHI, 1 - PHI, -PHI, PHI - 1)) < 1e-9 else t
            if name == "rho":
                c = z5 ** ((2 * dl[p % N0]) % 5); ap, det = t * c ** 3, c ** 6
            else:
                ap, det = t, 1.0
        A = [1.0, ap]; q = p
        while q * p <= M: A.append(ap * A[-1] - det * A[-2]); q *= p
        pk = 1; k = 0
        while pk * p <= M:
            pk *= p; k += 1
            m = np.arange(1, M // pk + 1); m = m[m % p != 0]
            a[m * pk] = a[m] * A[k]
    return a
def K(x, shift):
    """inverse Mellin of Gamma_R(s+shift)^2, complex x with Re x > 0."""
    return 4 * (x ** shift) * kv(0, 2 * np.pi * x)
def theta(a, N, t, shift, conj=False, cut=7.0):
    t = complex(t); sq = math.sqrt(N)
    nmax = min(len(a) - 1, int(cut * sq / (abs(t) * math.cos(math.atan2(t.imag, t.real)))) + 1)
    n = np.arange(1, nmax + 1); co = np.conj(a[1:nmax + 1]) if conj else a[1:nmax + 1]
    terms = co * K(n * t / sq, shift)
    return terms.sum(), np.abs(terms).sum(), nmax
def defect(a, N, t, W, shift):
    th, s1, n1 = theta(a, N, t, shift)
    tt, s2, n2 = theta(a, N, 1 / t, shift, conj=True)
    return th - W * tt / t, s1 + abs(W * tt / t) + s2 / abs(t), max(n1, n2)
def gammaR2(s, shift):
    import mpmath as mp
    return complex(mp.power(mp.pi, -(s + shift)) * mp.gamma((s + shift) / 2) ** 2)
def fitW(a, N, shift, t0=1.3):
    th, _, _ = theta(a, N, t0, shift); tt, _, _ = theta(a, N, 1 / t0, shift, conj=True)
    return t0 * th / tt
