"""Galois-side traces of rho at unramified primes, from the number fields alone.

  t_p = tr rho0(Frob_p),  rho0 = rho (x) chi^-3 : G_Q -> SL(2,5),  a_p = chi(p)^3 t_p.

  * A5 class of Frob_p   : cycle type of the quintic f5, and 5A/5B by Dokchitser resolvents;
  * order of the SL(2,5) lift : cycle type on 24 points = factorisation in K24 (the cyclic
    quartic narrow class field of the sextic resolvent field K6, which is the kernel field of
    rho0 cut down by the unipotent C5);
  * which 5-class has |t| = phi - 1 : the inertia generator at 1951 (local computation).
  * a_1951 = chi(u)^-3, u = f(c)/1951 mod 1951  (local factor at the ramified prime)
"""
import sys, json
import numpy as np
import cypari2
from dokchitser import classify
pari = cypari2.Pari(); pari.allocatemem(4*10**9)
N = 1951
PHI = (1 + 5 ** 0.5) / 2
f = pari('x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344')
Q = pari(open("K24.txt").read().strip())
IDX_F = {2, 7, 71, 137}
IDX_Q = {2, 3, 5, 7, 17, 139, 271, 40427}
LOC = json.load(open("local1951.json"))      # written by local1951.py
SMALLCLASS = LOC["small_class"]              # the 5-class whose order-5 lifts have trace phi - 1

def ctype_poly(pol, p):
    F = pari.factormod(pol, p)
    d = []
    for i in range(len(F[0])):
        d += [int(pari.poldegree(F[0][i]))] * int(F[1][i])
    return tuple(sorted(d, reverse=True))

nf_cache = {}
def ctype_nf(pol, p, key):
    if (key, p) not in nf_cache:
        nf = pari.nfinit([pol, [p]])
        dec = pari.idealprimedec(nf, p)
        d = []
        for P in dec:
            assert int(P[2]) == 1
            d += [int(P[3])]
        nf_cache[(key, p)] = tuple(sorted(d, reverse=True))
    return nf_cache[(key, p)]

def trace(p):
    c5 = ctype_nf(f, p, 'f') if p in IDX_F else ctype_poly(f, p)
    c24 = ctype_nf(Q, p, 'Q') if p in IDX_Q else ctype_poly(Q, p)
    if c5 == (1, 1, 1, 1, 1):
        assert c24 in ((1,) * 24, (2,) * 12), (p, c24)
        return (2.0 if c24 == (1,) * 24 else -2.0), 'id'
    if c5 == (2, 2, 1):
        assert c24 == (4,) * 6, (p, c24)
        return 0.0, '2B'
    if c5 == (3, 1, 1):
        assert c24 in ((3,) * 8, (6,) * 4), (p, c24)
        return (-1.0 if c24 == (3,) * 8 else 1.0), '3A'
    assert c5 == (5,), (p, c5)
    assert c24 in ((5, 5, 5, 5, 1, 1, 1, 1), (10, 10, 2, 2)), (p, c24)
    order5 = c24 == (5, 5, 5, 5, 1, 1, 1, 1)
    cls = classify(p)
    small = (cls == SMALLCLASS)
    if order5:
        return (PHI - 1 if small else -PHI), '5' + cls
    return (1 - PHI if small else PHI), '5' + cls

def chi_table():
    dl, x = {}, 1
    for k in range(N - 1):
        dl[x] = k
        x = (x * 3) % N
    return dl

if __name__ == "__main__":
    P = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
    dl = chi_table()
    z5 = np.exp(2j * np.pi / 5)
    chi = lambda n: z5 ** ((2 * dl[n % N]) % 5)
    rows = {}
    for p in pari.primes([2, P]):
        p = int(p)
        if p == N:
            continue
        t, cls = trace(p)
        rows[p] = (t, cls)
    u = LOC["u"]
    a1951 = LOC["eps"] * chi(u) ** -3
    k1951 = int(round(np.angle(a1951) / (2 * np.pi / 5))) % 5
    print("a_1951 = chi(877)^-3 = zeta5^%d   (log_3 877 mod 5 = %d)" % (k1951, dl[877] % 5))
    json.dump({"P": P, "t": {str(p): rows[p][0] for p in rows}, "cls": {str(p): rows[p][1] for p in rows},
               "a1951_k": k1951}, open("galois_traces_%d.json" % P, "w"))
    from collections import Counter
    cnt = Counter((rows[p][1], rows[p][0]) for p in rows)
    for k in sorted(cnt): print("  class %-3s t = %+.3f : %d primes" % (k[0], k[1], cnt[k]))
