#!/bin/sh
# Rewrite the absolute path prefix used when the scripts were run (/home/claude/research)
# to the location of this folder. Run once, from this folder:  sh relocate.sh
HERE="$(cd "$(dirname "$0")" && pwd)"
grep -rlI --include='*.py' '/home/claude/research' "$HERE" | while read -r f; do
  sed -i.bak "s#/home/claude/research#$HERE#g" "$f" && rm -f "$f.bak"
done
echo "paths now point to $HERE"
