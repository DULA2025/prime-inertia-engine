#!/bin/sh
# Leopoldt for K12 at the auxiliary primes l = 1 mod 5 (direction 3); usage: sh run_leopoldt_aux.sh "p1 p2 ..."
for p in $1; do for ell in 11 31 41 61 71; do
  python3 -u k12_leopoldt_general.py $p $ell 300 > leopoldt_p${p}_ell${ell}.log 2>&1
done; done
