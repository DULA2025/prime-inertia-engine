"""Exact checks for the curve from klein_general.py over K0 = Q(sqrt5, sqrt(-d)) (generalising klein3/certify_K.py,
klein3/certify_iso_K.py for p = 1951).

Usage: python3 klein_certify.py p d
(a) 5-isogeny field: the fibre (X^2+250X+3125)^3 - j X^5 is irreducible over K0 and its stem field contains K0*K6, where
    K6 is the sextic resolvent field of f5 (fixed field of D5, built here from the roots); both of degree 24, so they are
    equal and the projective mod-5 representation of E equals that of rho over K0 (as in the proof of Theorem C(i)).
(b) Frobenius check: at degree-1 primes P | l of K0 (l < LMAX), a_P(E)^2 = l * tbar_l^2 mod 5, with tbar_l^2 = 4, 0, 1, 4
    for the A5-classes 1, 2A, 3A, 5 (independent of signs and of 5A/5B).
(c) Places with v(j) < 0 (potentially multiplicative) and decomposed-generic witnesses: l splitting completely in K0, good
    reduction at the four places, a_v(E) != +-(1 + l) mod 5 at all of them (Caraiani-Newton, Section 6.1).
Author: Dula."""
import sys, json, itertools, time, cypari2
pari = cypari2.Pari(); pari.allocatemem(4 * 10**9); pari.default("parisizemax", 6 * 10**9)
pari("default(realprecision, 300)")
p = int(sys.argv[1]); dd = int(sys.argv[2]); LMAX = int(sys.argv[3]) if len(sys.argv) > 3 else 3000
J = json.load(open("klein_p%d_d%d.json" % (p, dd)))
CL = {int(k): v for k, v in json.load(open("classes_%d.json" % p))["codes"].items()}
DM = json.load(open("fields6.json"))
fstr = DM[str(p)]["poly"]
q = lambda k: pari(J[k][0]) / pari(J[k][1])
Kpol = pari.polredabs(pari.polcompositum("a^2+%d" % dd, "a^2-5")[0]); K = pari.nfinit(Kpol)
sd = pari.Mod(pari.nfbasistoalg(K, pari.nfroots(K, "x^2+%d" % dd)[0]).lift(), Kpol)
s5 = pari.Mod(pari.nfbasistoalg(K, pari.nfroots(K, "x^2-5")[0]).lift(), Kpol)
jK = (q("Re alpha") + sd * q("Im alpha / sqrt d")) + (q("Re beta") + sd * q("Im beta / sqrt d")) * s5
res = {"p": p, "d": dd, "K0": str(Kpol), "disc_K0": int(K[2])}
den = int(pari.denominator(pari.content(pari.nfalgtobasis(K, pari.lift(jK)))))
res["denominator_of_j"] = str(pari.factor(den))
E = pari.ellinit(pari.ellfromj(pari.lift(jK)), K)
# (b) Frobenius check at degree-1 primes
T2 = {"1": 4, "2A": 0, "3A": 1, "5A": 4, "5B": 4}
ok = bad = 0; badlist = []
for l in map(int, pari.primes([7, LMAX])):
    if l == p: continue
    for P in pari.idealprimedec(K, l):
        if int(P[3]) != 1 or int(pari.elllocalred(E, P)[0]) != 0: continue
        a = int(pari.ellap(E, P))
        if (a * a - l * T2[CL[l]]) % 5 == 0: ok += 1
        else: bad += 1; badlist.append(l)
res["frobenius_degree1"] = [ok, ok + bad, badlist[:10]]
print("p = %d, d = %d: a_P^2 = l tbar^2 mod 5 at degree-1 primes l < %d: %d of %d" % (p, dd, LMAX, ok, ok + bad), flush=True)
# (a) isogeny field contains K0*K6
t0 = time.time()
R = pari("vecsort(real(polroots(%s)))" % fstr); r = [R[i] for i in range(5)]
def sgn(g): return (-1) ** sum(1 for i in range(5) for j in range(i + 1, 5) if g[i] > g[j])
vals = []
for g in itertools.permutations(range(5)):
    if sgn(g) != 1: continue
    th = sum(r[g[i]] * r[g[(i + 1) % 5]] for i in range(5))
    if all(abs(th - v) > pari("1e-100") for v in vals): vals.append(th)
assert len(vals) == 6, len(vals)
X = pari("'x"); S6 = pari(1)
for v in vals: S6 *= X - v
S6 = pari.round(pari.real(S6)); K6 = pari.polredabs(S6)
res["K6"] = str(K6); res["disc_K6"] = str(pari.factor(pari.nfinit(K6)[2]))
fib = pari.lift(pari("(x^2+250*x+3125)^3") - jK * pari("x^5"))
nfac = len(pari.nffactor(K, fib)[0])
Pabs = pari.polredbest(pari.rnfequation(K, fib))
Gabs = pari.polredbest(pari.rnfequation(K, K6))
inc = pari.nfisincl(Gabs, Pabs)
res["fibre_irreducible"] = nfac == 1; res["K0K6_in_isogeny_field"] = inc != 0
res["degrees"] = [int(pari.poldegree(Pabs)), int(pari.poldegree(Gabs))]
print("K6 =", K6, "disc", res["disc_K6"], "; fibre irreducible:", nfac == 1, "; K0*K6 in isogeny field:", inc != 0,
      "(degrees %s, %.0fs)" % (res["degrees"], time.time() - t0), flush=True)
# (c) potentially multiplicative places and decomposed-generic witnesses
pm = []
for l in [int(x) for x in pari.factor(den)[0]]:
    for P in pari.idealprimedec(K, l):
        v = int(pari.nfeltval(K, pari.lift(jK), P))
        if v < 0: pm.append([l, int(P[3]), v])
res["v_j_negative"] = pm
wit = []
for l in map(int, pari.primes([7, 4000])):
    dec = pari.idealprimedec(K, l)
    if len(dec) != 4 or l == p: continue
    aps = []
    for P in dec:
        if int(pari.elllocalred(E, P)[0]) != 0: aps = None; break
        aps.append(int(pari.ellap(E, P)))
    if aps is None: continue
    gen = all((a - (1 + l)) % 5 != 0 and (a + (1 + l)) % 5 != 0 for a in aps)
    if gen: wit.append([l, aps])
    if len(wit) >= 5: break
res["decomposed_generic_witnesses"] = wit
print("places with v(j) < 0:", pm, "\nwitnesses (l, a_v):", wit[:3], flush=True)
json.dump(res, open("klein_certify_p%d_d%d.json" % (p, dd), "w"), indent=1)
