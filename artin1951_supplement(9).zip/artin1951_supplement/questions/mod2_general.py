"""Analogue of Theorem D (reduction mod 2 in weight 2) for an even icosahedral representation of prime conductor p.

Usage: python3 mod2_general.py p NB [eps]
  eps = 0: S = S_2(Gamma0(p), chi);  eps = 1: S = S_2(Gamma0(p), chi * eps_p)  (non-zero only for p = 1 mod 4).
chi is the character of order 5 with chi(g) = e(2/5), g = znstar(p).gen; psi = chi^3, rho = rho0 (x) psi, det rho = chi.
Mod 2 (F16 = F2[z], z = zeta5 mod 2): abar_l = psibar(l) tbar_l, with tbar = 0 (classes 1, 2A), 1 (3A), and for 5-cycles
phibar - 1 or phibar according to the labelling L (L = 0: class 5A has |t| = phi - 1; L = 1: class 5B does).
Steps (as in mod2/sat.py, mod2/hecke2.py for p = 1951):
  1. PARI basis of S, q-expansions to NB in the Z[zeta5]-basis 1, t, t^2, t^3 (order-10 characters converted with
     zeta10 = -zeta5^3); 2-adic saturation (divide by 2 every combination vanishing mod 2; legitimate by Sturm).
  2. Membership of the predicted eigenforms G_alpha = sum abar_n q^n (abar_{2^j} = alpha^j, alpha a root of
     X^2 + abar_2 X + chibar(2)) for both labellings, n <= NB, p not dividing n; control: shuffled traces.
  3. Hecke matrices mod 2 of T_2 (= U_2), T_3, T_5, T_7 from the first STURM = (p+1)/6 coefficients, with a consistency check
     up to NB/l; joint and generalised eigenspaces at the rho-bar eigenvalues.
  4. The two eigenforms in S-bar (if they exist): do their odd coefficients agree up to NB?  By Sturm for Gamma0(4p)
     (weight 2, bound p + 1), agreement up to p + 1 implies agreement for all n, which gives the weight-one Katz form.
Author: Dula."""
import sys, json, time, numpy as np, cypari2
from sympy import factorint
from f16 import MUL, INV, POW, mulf, f16, rref_kernel, matmul, rank, solve_left, minus_scalar, kernel_rows, mpow
p = int(sys.argv[1]); NB = int(sys.argv[2]); EPS = int(sys.argv[3]) if len(sys.argv) > 3 else 0
STURM = (p + 1) // 6 + 1
C = {int(k): v for k, v in json.load(open("classes_%d.json" % p))["codes"].items()}
assert max(C) >= NB
pari = cypari2.Pari(); pari.allocatemem(12 * 10**9)
g = int(pari("znstar(%d,1).gen[1]" % p))
dl = {}; x = 1
for k in range(p - 1): dl[x] = k; x = x * g % p
c_chi = 2 * (p - 1) // 5
c = (c_chi + ((p - 1) // 2) * EPS) % (p - 1)
t0 = time.time()
pari("G = znstar(%d,1); mf = mfinit([%d, 2, [G, [%d]]], 1); B = mfbasis(mf); d = #B; FP = mfparams(mf)[5];" % (p, p, c))
d = int(pari("d")); FP = str(pari("FP"))
o = 5 if FP == "t^4 + t^3 + t^2 + t + 1" else (10 if FP == "t^4 - t^3 + t^2 - t + 1" else None)
assert o is not None, FP
print("p = %d, eps = %d: dim S = %d, character Mod(%s), field %s (order %d)  (%.0fs)"
      % (p, EPS, d, pari("znconreyexp(G, [%d])" % c), FP, o, time.time() - t0), flush=True)
PREC = 56; P2 = 2 ** PREC
pari("conv5(a) = my(P = if (type(a) == \"t_POLMOD\", lift(a), a)); if (%d == 10 && type(P) == \"t_POL\", P = lift(Mod(subst(P, t, -'s^3), polcyclo(5, 's)))); if (type(P) == \"t_POL\", vector(4, k, polcoef(P, k - 1, variable(P))), [P, 0, 0, 0])" % o)
R = np.zeros((d, NB, 4), np.int64)
for i in range(d):
    row = pari("my(V = mfcoefs(B[%d], %d), w = concat(vector(%d, n, conv5(V[n + 1])))); w = w * denominator(w); [denominator(content(w)), apply(x -> lift(Mod(x, 2^%d)), w)]" % (i + 1, NB, NB, PREC))
    w = [int(v) for v in row[1]]
    R[i] = np.array(w, np.int64).reshape(NB, 4)
print("  q-expansions to %d read (%.0fs)" % (NB, time.time() - t0), flush=True)
def red2(R):
    b = (R & 1).astype(np.uint8)
    return b[..., 0] | (b[..., 1] << 1) | (b[..., 2] << 2) | (b[..., 3] << 3)
def zmul(cc, Bv):
    out = np.zeros((Bv.shape[0], 5), np.int64)
    for i in range(4):
        if cc[i] == 0: continue
        for j in range(4): out[:, (i + j) % 5] += cc[i] * Bv[:, j]
    return (out[:, :4] - out[:, 4:5]) % P2
# --- 1. saturation ---------------------------------------------------------------------------------------------
prec, rounds = PREC, 0
while True:
    Bm = red2(R); Kr = rref_kernel(Bm.T.copy())
    print("  saturation round %d: rank mod 2 = %d / %d" % (rounds, d - len(Kr), d), flush=True)
    if len(Kr) == 0: break
    cols = set(np.nonzero((Kr != 0).sum(axis=0) == 1)[0].tolist())
    newrows = {}
    for tt in range(len(Kr)):
        cvec = Kr[tt]
        own = [i for i in np.nonzero(cvec)[0] if i in cols and cvec[i] == 1]
        i0 = int(own[0]); S = np.zeros((NB, 4), np.int64)
        for i in np.nonzero(cvec)[0]:
            S = (S + zmul([(int(cvec[i]) >> j) & 1 for j in range(4)], R[i])) % P2
        assert not (S & 1).any(), "relation does not vanish mod 2"
        newrows[i0] = S >> 1
    prec -= 1; P2 = 2 ** prec
    for i0, v in newrows.items(): R[i0] = v
    R %= P2; rounds += 1
    assert prec > 8
Bm = red2(R)
assert rank(Bm[:, :STURM]) == d, "first STURM coefficients do not determine the forms"
# --- 2. predicted eigenforms -----------------------------------------------------------------------------------
TB = {"1": 0, "2A": 0, "3A": 1}
PHI1 = f16([0, 1, 0, 0, 1], 0)      # phi - 1 = zeta + zeta^4
PHI0 = f16([1, 1, 0, 0, 1], 0)      # phi = 1 + zeta + zeta^4
def tbar(code, L):
    if code in TB: return TB[code]
    small = "5A" if L == 0 else "5B"
    return PHI1 if code == small else PHI0
def chibar(l): return POW[(2 * dl[l % p]) % 5]
def abar(l, L): return mulf(POW[dl[l % p] % 5], tbar(C[l], L))
def predicted(alpha, L, shuffle=False):
    ps = [l for l in sorted(C) if l != 2 and l != p and l <= NB]
    sh = {l: ps[(i + 1) % len(ps)] for i, l in enumerate(ps)}
    an = [0] * (NB + 1); an[1] = 1; cache = {}
    for n in range(2, NB + 1):
        val = 1
        for l, e in factorint(n).items():
            if l == 2:
                pe = 1
                for _ in range(e): pe = mulf(pe, alpha)
            elif l == p: pe = 0
            else:
                if l not in cache:
                    q = sh[l] if shuffle else l
                    cache[l] = mulf(POW[dl[l % p] % 5], tbar(C[q], L))
                cc = chibar(l); prev, cur = 1, cache[l]
                for _ in range(e - 1): prev, cur = cur, mulf(cache[l], cur) ^ mulf(cc, prev)
                pe = cur
            val = mulf(val, pe)
        an[n] = val
    return np.array(an[1:], np.uint8)
mask = np.array([n % p != 0 for n in range(1, NB + 1)])
rm = rank(Bm[:, mask])
res = {"p": p, "eps": EPS, "dim": d, "NB": NB, "sturm": STURM, "saturation_rounds": rounds,
       "char_conrey": str(pari("znconreyexp(G, [%d])" % c)), "frob2_class": C[2], "membership": {}}
roots = {}
for L in (0, 1):
    a2 = abar(2, L); c2 = chibar(2)
    roots[L] = [r for r in range(16) if (mulf(r, r) ^ mulf(a2, r) ^ c2) == 0]
    for alpha in roots[L]:
        for sh in (False, True):
            tgt = predicted(alpha, L, sh)
            ok = rank(np.vstack([Bm[:, mask], tgt[mask][None, :]])) == rm
            res["membership"]["L=%d alpha=%d%s" % (L, alpha, " shuffled" if sh else "")] = bool(ok)
print("  membership:", res["membership"], flush=True)
# --- 3. Hecke matrices mod 2 and eigenspaces -------------------------------------------------------------------
Hc = {}; consist = {}
for l in (2, 3, 5, 7):
    Ln = NB // l
    TBm = np.zeros((d, Ln), np.uint8)
    for n in range(1, Ln + 1):
        col = Bm[:, l * n - 1].copy()
        if l != 2 and n % l == 0: col ^= MUL[chibar(l), Bm[:, n // l - 1]]
        TBm[:, n - 1] = col
    X = solve_left(Bm[:, :STURM], TBm[:, :STURM])
    consist[l] = bool((matmul(X, Bm[:, :Ln]) == TBm).all()) if Ln > STURM else None
    Hc[l] = X
res["hecke_consistency_beyond_sturm"] = consist
res["commute"] = all(bool((matmul(Hc[a], Hc[b]) == matmul(Hc[b], Hc[a])).all()) for a in Hc for b in Hc if a < b)
for L in (0, 1):
    lam = {l: abar(l, L) for l in (3, 5, 7)}
    acc = [minus_scalar(Hc[l], lam[l]) for l in (3, 5, 7)]
    E = {"T3": len(kernel_rows(acc[:1])), "T3,T5": len(kernel_rows(acc[:2])), "T3,T5,T7": len(kernel_rows(acc))}
    for al in roots[L]:
        E["T3,T5,T7,T2=%d" % al] = len(kernel_rows(acc + [minus_scalar(Hc[2], al)]))
        E["generalised T2..T7, T2=%d" % al] = len(kernel_rows([mpow(M, d) for M in acc] + [mpow(minus_scalar(Hc[2], al), d)]))
    res["eigenspaces L=%d" % L] = E
    print("  L=%d: roots %s, %s" % (L, roots[L], E), flush=True)
# --- 4. the eigenforms in S-bar: odd coefficients ----------------------------------------------------------------
for L in (0, 1):
    lam = {l: abar(l, L) for l in (3, 5, 7)}
    forms = {}
    for al in roots[L]:
        K = kernel_rows([minus_scalar(Hc[l], lam[l]) for l in (3, 5, 7)] + [minus_scalar(Hc[2], al)])
        if len(K) == 1:
            f = matmul(K, Bm)[0]
            f = MUL[INV[f[0]], f] if f[0] else f
            forms[al] = f
    if len(forms) == 2:
        (a1, f1), (a2_, f2) = forms.items()
        odd = np.arange(1, NB + 1) % 2 == 1
        agree = bool((f1[odd & mask] == f2[odd & mask]).all())
        first = int(np.nonzero(odd & mask & (f1 != f2))[0][0]) + 1 if not agree else None
        pred_ok = {al: bool((forms[al][mask] == predicted(al, L)[mask]).all()) for al in forms}
        res["eigenforms L=%d" % L] = dict(odd_coefficients_agree_to_NB=agree, first_disagreement=first,
                                         match_prediction=pred_ok, sturm_gamma0_4p=p + 1, NB_covers=NB >= p + 1)
        print("  L=%d eigenforms: odd coefficients agree to %d: %s; match predictions: %s" % (L, NB, agree, pred_ok), flush=True)
json.dump(res, open("mod2_p%d_eps%d.json" % (p, EPS), "w"), indent=1)
print("done (%.0fs)" % (time.time() - t0))
