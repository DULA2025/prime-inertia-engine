"""Theorem C analogue for an even icosahedral A5 quintic of prime conductor p: Klein's resolvent with accessory
irrationality sqrt(-d), d in {1, 3}, giving j in Q(sqrt5, sqrt(-d)) and an elliptic curve whose mod-5 projective
representation should match that of rho over K0 = Q(sqrt5, sqrt(-d)).

Usage: python3 klein_general.py p d DPS   -> klein_p<p>_d<d>.json (exact j as rationals), log on stdout.
Steps (generalising klein3/lattice3.py and klein3/klein_sqrt3.py, written for p = 1951):
  1. trace-zero lattice of O_L5 with the trace form, LLL-reduced (for p = 1951 it is p * A4);
  2. orthogonal u, v in it with Tr u^2 = d Tr v^2, of least total norm;
  3. y = u + sqrt(-d) v has Tr y = Tr y^2 = 0; Klein's invariant j of y on the two rulings (the two A5-invariant
     coordinates z = c2/c4 for zeta5^k, k = 1, 2), at DPS digits;
  4. alpha = (j_1 + j_2)/2, beta = (j_1 - j_2)/(2 sqrt5): recognise Re, Im/sqrt d as rationals.
Author: Dula."""
import sys, itertools, json, cypari2, mpmath as mp
from fractions import Fraction as Fr
DM = {1951: "x^5-x^4-780*x^3-1795*x^2+3106*x+344", 2141: "x^5-x^4-856*x^3+4025*x^2+28501*x-40877",
      3701: "x^5-x^4-1480*x^3-18209*x^2+2191*x+9683", 3821: "x^5-x^4-1528*x^3-1987*x^2+16629*x-12281",
      8501: "x^5-x^4-3400*x^3-41825*x^2+671511*x-966731", 9461: "x^5-x^4-3784*x^3+2649*x^2+2960082*x-2781864"}
p = int(sys.argv[1]); dd = int(sys.argv[2]); DPS = int(sys.argv[3]) if len(sys.argv) > 3 else 600
mp.mp.dps = DPS
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
fstr = DM[p]; f = pari(fstr); nf = pari.nfinit(f); B = pari.nfbasis(f); n = 5
Tr = lambda a: pari.nfelttrace(nf, pari.nfalgtobasis(nf, pari.Mod(a, f)))
G = [[int(Tr(B[i] * B[j])) for j in range(n)] for i in range(n)]
t = [int(Tr(B[i])) for i in range(n)]
K0 = pari.matkerint(pari.matrix(1, n, t))
Gm = pari.matrix(n, n, [G[i][j] for i in range(n) for j in range(n)])
Q0 = pari.mattranspose(K0) * Gm * K0
R = pari.qflllgram(Q0); Q1 = pari.mattranspose(R) * Q0 * R
A4 = pari("[2,-1,0,0;-1,2,-1,0;0,-1,2,-1;0,0,-1,2]")
print("p = %d: LLL Gram of the trace-zero lattice:" % p, Q1, " isometric to p*A4:", bool(pari.qfauto(Q1)[0] == pari.qfauto(A4)[0]) and int(pari.matdet(Q1)) == 5 * p ** 4, flush=True)
sv = pari.qfminim(Q1, p * 8, 10**6)
nc = int(pari.matsize(sv[2])[1]); vecs = [[int(sv[2][i, k]) for i in range(4)] for k in range(nc)]
Qf = lambda a: sum(a[i] * a[j] * int(Q1[i, j]) for i in range(4) for j in range(4))
Bf = lambda a, b: sum(a[i] * b[j] * int(Q1[i, j]) for i in range(4) for j in range(4))
best = None
for u in vecs:
    for v in vecs:
        if Bf(u, v) != 0 or Qf(u) != dd * Qf(v): continue
        if best is None or Qf(u) + Qf(v) < best[2]: best = (u, v, Qf(u) + Qf(v))
assert best, "no orthogonal pair with ratio %d" % dd
def elem(w):
    cvec = K0 * R * pari.matrix(4, 1, w)
    return sum(cvec[i, 0] * B[i] for i in range(5))
ue, ve = elem(best[0]), elem(best[1])
print("u =", ue, "\nv =", ve, "\nTr u^2, Tr v^2 =", Qf(best[0]), Qf(best[1]), flush=True)
fco = [int(pari.polcoef(f, 5 - k)) for k in range(6)]
xs = sorted([mp.re(r) for r in mp.polyroots(fco, maxsteps=5000, extraprec=4 * DPS)])
def ev(pol, x):
    co = [pari.polcoef(pol, k) for k in range(5)]
    return mp.fsum(mp.mpf(int(pari.numerator(c))) / mp.mpf(int(pari.denominator(c))) * x ** k for k, c in enumerate(co))
U = [ev(ue, x) for x in xs]; V = [ev(ve, x) for x in xs]
def sign(pm):
    s = 1
    for i in range(5):
        for j in range(i + 1, 5):
            if pm[i] > pm[j]: s = -s
    return s
evens = [pm for pm in itertools.permutations(range(5)) if sign(pm) == 1]
def J_of(ys, k):
    Z = mp.exp(2j * mp.pi * k / 5)
    def W(pm): return [[mp.fsum(Z ** (-kk * nu + l * pm[nu]) for nu in range(5)) / 5 for l in range(1, 5)] for kk in range(1, 5)]
    def apply(Wm, c): return [mp.fsum(Wm[i][l] * c[l] for l in range(4)) for i in range(4)]
    def C_of(c): return mp.matrix([[c[0], c[1]], [-c[2], c[3]]])
    def c_of(C): return [C[0, 0], C[0, 1], -C[1, 0], C[1, 1]]
    def colA(Wm):
        def col(C):
            return mp.matrix([C[0, 0], C[1, 0]]) if abs(C[0, 0]) + abs(C[1, 0]) > abs(C[0, 1]) + abs(C[1, 1]) else mp.matrix([C[0, 1], C[1, 1]])
        mu0 = mp.matrix([1, mp.mpf(1) / 3]); e1, e2 = mp.matrix([1, 0]), mp.matrix([0, 1])
        vv = [col(C_of(apply(Wm, c_of(l * mu0.T)))) for l in (e1, e2, e1 + e2)]
        M = mp.matrix([[vv[0][0], vv[1][0]], [vv[0][1], vv[1][1]]]); st = mp.lu_solve(M, vv[2])
        return mp.matrix([[vv[0][0] * st[0], vv[1][0] * st[1]], [vv[0][1] * st[0], vv[1][1] * st[1]]])
    Gs = [colA(W(pm)) for pm in evens]
    tol = mp.mpf(10) ** (-DPS // 2)
    def order(M):
        P = M
        for o in range(1, 7):
            if abs(P[0, 1]) < tol * abs(P[0, 0]) and abs(P[1, 0]) < tol * abs(P[0, 0]) and abs(P[0, 0] - P[1, 1]) < tol * abs(P[0, 0]): return o
            P = P * M
    def fixed(M):
        a_, b_, c_, d_ = M[0, 0], M[0, 1], M[1, 0], M[1, 1]
        if abs(c_) < tol * abs(a_): return [b_ / (d_ - a_)]
        r = mp.sqrt((a_ - d_) ** 2 + 4 * b_ * c_)
        return [(a_ - d_ + r) / (2 * c_), (a_ - d_ - r) / (2 * c_)]
    def dedup(Lst):
        out = []
        for w in Lst:
            if all(abs(w - q) > tol * (1 + abs(w)) for q in out): out.append(w)
        return out
    ords = [order(M) for M in Gs]
    Vx = dedup([q for M, o in zip(Gs, ords) if o == 5 for q in fixed(M)])
    Fx = dedup([q for M, o in zip(Gs, ords) if o == 3 for q in fixed(M)])
    Ex = dedup([q for M, o in zip(Gs, ords) if o == 2 for q in fixed(M)])
    assert len(Fx) == 20 and len(Ex) == 30 and len(Vx) in (11, 12)
    fp = lambda w: mp.fprod(w - q for q in Vx); Hp = lambda w: mp.fprod(w - q for q in Fx)
    c = [mp.fsum(Z ** (-kk * nu) * ys[nu] for nu in range(5)) for kk in range(1, 5)]
    z = c[1] / c[3]
    return 1728 * (Hp(z) ** 3 / fp(z) ** 5) / (Hp(Ex[0]) ** 3 / fp(Ex[0]) ** 5)
SD = mp.sqrt(dd)
ys = [a + 1j * SD * b for a, b in zip(U, V)]
print("|sum y|, |sum y^2|:", mp.nstr(abs(mp.fsum(ys)), 3), mp.nstr(abs(mp.fsum(y * y for y in ys)), 3), flush=True)
j1 = J_of(ys, 1); j2 = J_of(ys, 2)
print("j (ruling 1) =", mp.nstr(j1, 40)); print("j (ruling 2) =", mp.nstr(j2, 40), flush=True)
alpha = (j1 + j2) / 2; beta = (j1 - j2) / (2 * mp.sqrt(5))
def rat(xv):
    q = Fr(mp.nstr(xv, DPS - 10)).limit_denominator(10 ** (DPS // 3))
    return q, abs(xv - mp.mpf(q.numerator) / q.denominator)
out = {"p": p, "d": dd, "DPS": DPS, "u": str(ue), "v": str(ve), "Tr_u2": Qf(best[0]), "Tr_v2": Qf(best[1])}
worst = -10 ** 9          # (was 0 in the runs recorded here, so their json field reads 0; the logs give the residuals)
for name, val in (("Re alpha", mp.re(alpha)), ("Im alpha / sqrt d", mp.im(alpha) / SD), ("Re beta", mp.re(beta)), ("Im beta / sqrt d", mp.im(beta) / SD)):
    q, err = rat(val); out[name] = [str(q.numerator), str(q.denominator)]
    worst = max(worst, float(mp.log10(err + mp.mpf(10) ** (-DPS))))
    print("%-18s denominator %s  (residual 1e%.0f)" % (name, pari.factor(q.denominator), float(mp.log10(err + mp.mpf(10) ** (-DPS)))), flush=True)
out["log10_worst_residual"] = worst
json.dump(out, open("klein_p%d_d%d.json" % (p, dd), "w"), indent=1)
