"""The six even icosahedral A5 quintics of prime conductor < 10^4 (Doud-Moore, Table 1): basic data."""
import cypari2, json
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
DM = {1951: "x^5-x^4-780*x^3-1795*x^2+3106*x+344", 2141: "x^5-x^4-856*x^3+4025*x^2+28501*x-40877",
      3701: "x^5-x^4-1480*x^3-18209*x^2+2191*x+9683", 3821: "x^5-x^4-1528*x^3-1987*x^2+16629*x-12281",
      8501: "x^5-x^4-3400*x^3-41825*x^2+671511*x-966731", 9461: "x^5-x^4-3784*x^3+2649*x^2+2960082*x-2781864"}
CT = {(1,1,1,1,1): "1", (1,2,2): "2A", (1,1,3): "3A", (5,): "5AB"}
out = {}
for p, f in DM.items():
    F = pari(f); nf = pari.nfinit(F)
    pat = {}
    for l in (2, 3, 5, 7, 11, 13):
        fa = pari.factormod(F, l)
        degs = tuple(sorted(int(pari.poldegree(fa[0][i])) * int(fa[1][i]) for i in range(len(fa[0]))))
        sq = all(int(fa[1][i]) == 1 for i in range(len(fa[0])))
        pat[l] = (CT.get(degs, str(degs)) if sq else "ramified/index " + str(degs))
    gal = pari.polgalois(F)
    print("p = %d: Gal %s, real roots %d, disc(K5) = %s, p mod 4 = %d, p mod 5 = %d, Frob classes %s"
          % (p, gal[3], int(pari.polsturm(F)), pari.factor(nf[2]), p % 4, p % 5, pat))
    out[p] = dict(poly=f, frob=pat)
json.dump(out, open("fields6.json", "w"), indent=1)
