#!/bin/sh
# usage: sh run_stark_chain.sh p NB   (Frobenius classes to NB, K12 and its units, rank-3 Stark check with NB coefficients)
p=$1; NB=$2
cp classes_${p}.json classes_${p}_small.json 2>/dev/null
python3 -u classes.py $p $NB > classes_${p}_${NB}.log 2>&1 || exit 1
[ -f k12_p${p}.json ] || python3 -u k12_general.py $p > k12_p${p}.log 2>&1 || exit 1
python3 -u stark_general.py $p 57 $NB > stark_p${p}_57.log 2>&1
