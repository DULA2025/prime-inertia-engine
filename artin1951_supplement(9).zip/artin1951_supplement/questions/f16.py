"""F16 = F2[z]/(z^4+z^3+z^2+z+1) arithmetic with numpy; elements 0..15 as bit-vectors in the basis 1, z, z^2, z^3.
z is the reduction of zeta5 (2 is inert in Z[zeta5]).  Taken from mod2/brute40np.py and mod2/hecke2.py.  Author: Dula."""
import numpy as np
MOD = 0b11111
def mul_s(a, b):
    r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a & 0b10000: a ^= MOD
    return r
MUL = np.array([[mul_s(a, b) for b in range(16)] for a in range(16)], dtype=np.uint8)
INV = np.zeros(16, np.uint8)
for a in range(1, 16): INV[a] = next(b for b in range(1, 16) if MUL[a, b] == 1)
POW = [1]
for _ in range(20): POW.append(int(MUL[POW[-1], 2]))
def mulf(a, b): return int(MUL[a, b])
def f16(vec, shift):
    """reduction of sum_i vec[i] zeta5^(i + shift) (vec of length 5)."""
    acc = [0] * 5
    for i, c in enumerate(vec): acc[(i + shift) % 5] += c
    r = 0
    for i, c in enumerate(acc):
        if c % 2: r ^= POW[i]
    return r
def rref_kernel(A):
    A = A.copy(); n_rows, n = A.shape; piv = []; R = 0
    for col in range(n):
        if R == n_rows: break
        nz = np.nonzero(A[R:, col])[0]
        if len(nz) == 0: continue
        pr = R + nz[0]
        if pr != R: A[[R, pr]] = A[[pr, R]]
        A[R] = MUL[INV[A[R, col]], A[R]]
        f = A[:, col].copy(); f[R] = 0
        rows = np.nonzero(f)[0]
        if len(rows): A[rows] ^= MUL[f[rows][:, None], A[R][None, :]]
        piv.append(col); R += 1
    free = [c for c in range(n) if c not in set(piv)]
    K = np.zeros((len(free), n), np.uint8)
    for t, fc in enumerate(free):
        K[t, fc] = 1
        for r, pc in enumerate(piv): K[t, pc] = A[r, fc]
    return K
def matmul(A, B):
    out = np.zeros((A.shape[0], B.shape[1]), np.uint8)
    for k in range(A.shape[1]):
        out ^= MUL[A[:, k][:, None], B[k][None, :]]
    return out
def rank(A): return A.shape[1] - len(rref_kernel(A))
def solve_left(A, Y):
    """X with X A = Y over F16; A (d x m) of rank d."""
    d, m = A.shape
    M = np.concatenate([A.T, Y.T], axis=1).copy(); R = 0
    for col in range(d):
        nz = np.nonzero(M[R:, col])[0]
        assert len(nz), "rank deficient"
        pr = R + nz[0]
        if pr != R: M[[R, pr]] = M[[pr, R]]
        M[R] = MUL[INV[M[R, col]], M[R]]
        f = M[:, col].copy(); f[R] = 0; rows = np.nonzero(f)[0]
        if len(rows): M[rows] ^= MUL[f[rows][:, None], M[R][None, :]]
        R += 1
    assert not M[d:, :d].any()
    return M[:d, d:].T.copy()
def minus_scalar(C, lam):
    C = C.copy(); C[np.arange(len(C)), np.arange(len(C))] ^= lam; return C
def kernel_rows(mats):
    """{c : c M = 0 for all M} (row-vector convention)."""
    return rref_kernel(np.concatenate([M.T for M in mats], axis=0))
def mpow(A, e):
    R = np.zeros_like(A); R[np.arange(len(A)), np.arange(len(A))] = 1; B = A.copy()
    while e:
        if e & 1: R = matmul(R, B)
        B = matmul(B, B); e >>= 1
    return R
