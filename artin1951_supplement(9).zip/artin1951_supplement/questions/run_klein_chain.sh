#!/bin/sh
# usage: sh run_klein_chain.sh "p1 p2 ..." DPS
for p in $1; do
  for d in 1 3; do
    [ -f klein_p${p}_d${d}.json ] || python3 -u klein_general.py $p $d $2 > klein_p${p}_d${d}.log 2>&1
    python3 -u klein_certify.py $p $d 3000 > klein_certify_p${p}_d${d}.log 2>&1
  done
done
