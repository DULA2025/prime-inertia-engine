"""Frobenius classes in A5 for an even icosahedral quintic f5 of prime conductor p (Doud-Moore list).

Usage: python3 classes.py p NB      -> classes_p.json : {ell: code} for primes ell <= NB, ell != p
Codes: "1" (identity), "2A", "3A", "5A", "5B" (5A = A5-class of the 5-cycle i -> i+1 in the polroots labelling,
sorted ascending), "5?" (order 5, class not resolved), "ram" (ell = p).
5A/5B: Dokchitser resolvents Gamma_C(X) = prod_{s in C} (X - sum_i h(r_i) r_{s(i)}), tested on Tr(h(x) x^ell) mod ell,
with several h; a prime is resolved only when exactly one of Gamma_A, Gamma_B vanishes for some h.
Index primes (f5 not squarefree mod ell, ell != p): cycle type from idealprimedec; 5-cycles there are left as "5?".
Author: Dula."""
import sys, json, itertools, cypari2
pari = cypari2.Pari(); pari.allocatemem(4 * 10**9)
pari("default(realprecision, 500)")
DM = {1951: "x^5-x^4-780*x^3-1795*x^2+3106*x+344", 2141: "x^5-x^4-856*x^3+4025*x^2+28501*x-40877",
      3701: "x^5-x^4-1480*x^3-18209*x^2+2191*x+9683", 3821: "x^5-x^4-1528*x^3-1987*x^2+16629*x-12281",
      8501: "x^5-x^4-3400*x^3-41825*x^2+671511*x-966731", 9461: "x^5-x^4-3784*x^3+2649*x^2+2960082*x-2781864"}
p = int(sys.argv[1]); NB = int(sys.argv[2])
fstr = DM[p]; f = pari(fstr)
R = pari("vecsort(real(polroots(%s)))" % fstr); r = [R[i] for i in range(5)]
def sgn(g): return (-1) ** sum(1 for i in range(5) for j in range(i + 1, 5) if g[i] > g[j])
A5 = [g for g in itertools.permutations(range(5)) if sgn(g) == 1]
def comp(a, b): return tuple(a[b[i]] for i in range(5))
def inv(a):
    q = [0] * 5
    for i in range(5): q[a[i]] = i
    return tuple(q)
c0 = (1, 2, 3, 4, 0)
classA = sorted({comp(comp(g, c0), inv(g)) for g in A5})
five = [g for g in A5 if all(g[i] != i for i in range(5))]
classB = sorted(set(five) - set(classA))
assert len(classA) == 12 and len(classB) == 12
HS = ["x^2+3*x+1", "x^3-2*x+5", "x^2-7", "x^3+x^2-4*x+2", "x^4-3*x+1", "x^2+5*x-3"]
import random
random.seed(5)
for _ in range(60):
    HS.append("+".join("(%d)*x^%d" % (random.randint(-9, 9), k) for k in range(5)))
def resolvent(h, cls):
    X = pari("'X"); P = pari(1)
    for s in cls:
        P *= X - sum(pari.subst(pari(h), "x", r[i]) * r[s[i]] for i in range(5))
    co = [pari.polcoef(P, k, "X") for k in range(13)]
    ro = [pari.round(pari.real(c)) for c in co]
    err = max(abs(c - q) for c, q in zip(co, ro))
    assert err < pari("1e-100"), err
    return pari.Pol(list(reversed(ro)), "X")
RES = [(h, resolvent(h, classA), resolvent(h, classB)) for h in HS]
nf = pari.nfinit(f)
CT = {(1, 1, 1, 1, 1): "1", (1, 2, 2): "2A", (1, 1, 3): "3A", (5,): "5"}
def cls(l):
    if l == p: return "ram"
    fa = pari.factormod(f, l)
    sq = all(int(fa[1][i]) == 1 for i in range(len(fa[0])))
    if sq:
        degs = tuple(sorted(int(pari.poldegree(fa[0][i])) for i in range(len(fa[0]))))
    else:
        dec = pari.idealprimedec(nf, l)
        assert all(int(P[2]) == 1 for P in dec), "ramified at %d" % l
        degs = tuple(sorted(int(P[3]) for P in dec))
    c = CT[degs]
    if c != "5": return c
    if not sq: return "5?"
    for h, GA, GB in RES:
        v = pari("my(fp = %s * Mod(1,%d), xp = Mod(x * Mod(1,%d), fp)^%d); trace(Mod(subst(%s, x, x) * lift(xp), fp))" % (fstr, l, l, l, h))
        a = pari.subst(GA, "X", v) == 0; b = pari.subst(GB, "X", v) == 0
        if a != b: return "5A" if a else "5B"
    return "5?"
out = {}
for l in pari.primes(int(pari.primepi(NB))):
    out[int(l)] = cls(int(l))
cnt = {}
for c in out.values(): cnt[c] = cnt.get(c, 0) + 1
print("p = %d, primes <= %d: %s" % (p, NB, dict(sorted(cnt.items()))))
print("small primes:", {l: out[l] for l in list(out)[:15]})
json.dump({"p": p, "f5": fstr, "NB": NB, "classA": classA, "codes": out}, open("classes_%d.json" % p, "w"))
