"""Leopoldt's conjecture for K12 = fixed field of a subgroup of order 5 in the A5 closure M, at a prime ell, for each
of the six conductors p of Doud-Moore (generalising h1proof/k12_leopoldt.py, written for p = 1951).

Usage: python3 k12_leopoldt_general.py p ell [PREC]   (reads k12_units_p<p>.gp written by k12_general.py)
Method as in h1proof/k12_leopoldt.py: factorpadic gives the local factors g_j of the defining polynomial at ell; each
fundamental unit u is raised to (ell^f - 1) ell^6, so that it lies in 1 + ell^7 O, and its logarithm is summed as a
series; the 12 x 11 matrix of coordinates has rank 11 if some 11 x 11 minor has valuation below its precision.
(Some minors vanish identically: the rows satisfy the relation sum_j Tr_j(log u) = log|N u| = 0, so deleting a row
outside its support leaves 11 dependent rows.  This happens when the defining polynomial is even and two of its
ell-adic factors have the form x^2 - delta, whose x-coordinate rows do not enter the relation; residue degree 2 alone
does not cause it.)
Rank 11 is Leopoldt for K12 at ell.  Since V and V' (the two 3-dimensional representations of A5) have non-zero
invariants under the subgroup of order 5, this gives H^1(G_{Q,S}, ad^0 rho (x) Qbar_ell) = 0 for every finite S, as in
Question 3 of the note, for rho0 and rho0'' alike.  The units come from bnfinit (GRH-conditional); any subgroup of
finite index of the units has the same p-adic rank, so the conclusion does not depend on GRH.
Author: Dula."""
import sys, json, cypari2
pari = cypari2.Pari(); pari.allocatemem(3 * 10**9)
P0 = int(sys.argv[1]); ell = int(sys.argv[2]); PREC = int(sys.argv[3]) if len(sys.argv) > 3 else 400
pari("V = read(\"k12_units_p%d.gp\"); Q = V[1]; fu = V[3];" % P0)
assert int(pari("#fu")) == 11 and int(pari("poldegree(Q)")) == 12
pari("p = %d; PREC = %d;" % (ell, PREC))
pari("F = factorpadic(Q, p, PREC); nloc = #F[,1];")
degs = [int(x) for x in pari("apply(poldegree, F[,1]~)")]; mult = [int(x) for x in pari("F[,2]~")]
assert sum(degs) == 12 and all(m == 1 for m in mult)
pari("plog(U, f) = my(W = (U^(p^f - 1))^(p^6), X = W - 1, S = 0, T = 1); for (n = 1, ceil(1.2 * PREC / 7) + 10, T = T * X; S += (-1)^(n + 1) * T / n); S / ((p^f - 1) * p^6)")
pari("coords(L, f) = my(v = Vec(lift(L))); concat(vector(f - #v, i, 0), v)")
pari("M = matrix(12, #fu); row = 0;")
pari("for (j = 1, nloc, g = F[j, 1]; f = poldegree(g); for (i = 1, #fu, c = coords(plog(Mod(fu[i], g), f), f); for (t = 1, f, M[row + t, i] = c[t])); row += f)")
pari("mins = vector(12, r, my(rr = setminus([1..12], [r])); matdet(matrix(11, 11, a, b, M[rr[a], b])))")
vals = [int(pari("valuation(mins[%d])" % r)) for r in range(1, 13)]
precs = [int(pari("padicprec(mins[%d], p)" % r)) for r in range(1, 13)]
nonzero = [r + 1 for r, (v, q) in enumerate(zip(vals, precs)) if v < q - 20]   # minors known to be non-zero
vanishing = [r + 1 for r, (v, q) in enumerate(zip(vals, precs)) if v >= q - 5]  # zero to working precision
ok = len(nonzero) > 0          # one non-zero 11 x 11 minor proves rank 11
res = {"p": P0, "ell": ell, "PREC": PREC, "local_degrees": degs, "minor_valuations": vals, "minor_precisions": precs,
       "nonzero_minors_without_row": nonzero, "minors_zero_to_precision_without_row": vanishing,
       "rank11": ok, "matrank": int(pari("matrank(M)"))}
print(json.dumps(res), flush=True)
json.dump(res, open("leopoldt_p%d_ell%d.json" % (P0, ell), "w"))
