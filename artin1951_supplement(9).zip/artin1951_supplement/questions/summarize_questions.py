"""Collect the results for the six even icosahedral representations of prime conductor < 10^4 (Doud-Moore) into
questions_summary.json and questions_tables.md: Klein curves (Theorem C analogue), mod-2 weight-one forms (Theorem D
analogue), rank-3 Stark checks.  Reads only the json/log outputs in this directory.
Author: Dula."""
import json, os, re, glob
P6 = [1951, 2141, 3701, 3821, 8501, 9461]
F16 = {1: "1", 2: "z", 4: "z^2", 8: "z^3", 15: "z^4", 6: "z+z^2", 9: "1+z^3", 3: "1+z", 5: "1+z^2", 10: "z+z^3",
       12: "z^2+z^3", 7: "1+z+z^2", 11: "1+z+z^3", 13: "1+z^2+z^3", 14: "z+z^2+z^3"}
out = {"klein": [], "mod2": [], "stark": []}
def residuals(log):
    return [int(m) for m in re.findall(r"residual 1e(-?\d+)", open(log).read())]
for p in P6:
    for d in (1, 2, 3):
        jf, cf = "klein_p%d_d%d.json" % (p, d), "klein_certify_p%d_d%d.json" % (p, d)
        if p == 1951 and d in (1, 3):
            continue                                   # the note's Theorem C (klein3/ in the supplement)
        if not (os.path.exists(jf) and os.path.exists(cf)):
            continue
        J, C = json.load(open(jf)), json.load(open(cf))
        res = residuals("klein_p%d_d%d.log" % (p, d))
        fr = C["frobenius_degree1"]
        out["klein"].append({
            "p": p, "d": d, "K0": C["K0"], "DPS": J["DPS"], "Tr_u2": J["Tr_u2"], "Tr_v2": J["Tr_v2"],
            "recognition_residual_log10_max": max(res) if res else None,
            "denominator_of_j": C["denominator_of_j"], "frobenius_ok": fr[0], "frobenius_total": fr[1],
            "fibre_irreducible": C["fibre_irreducible"], "K0K6_in_isogeny_field": C["K0K6_in_isogeny_field"],
            "degrees": C["degrees"], "K6": C["K6"], "disc_K6": C["disc_K6"],
            "v_j_negative": C["v_j_negative"], "witnesses": [w[0] for w in C["decomposed_generic_witnesses"]],
            "certified": bool(fr[0] == fr[1] and C["fibre_irreducible"] and C["K0K6_in_isogeny_field"]
                              and C["degrees"] == [24, 24] and len(C["decomposed_generic_witnesses"]) > 0)})
for f in sorted(glob.glob("mod2_p*_eps*.json")):
    M = json.load(open(f))
    L = [k for k in ("eigenforms L=0", "eigenforms L=1") if k in M]
    Lgood = None
    for Lv in (0, 1):
        mem = M["membership"]
        if all(v for k, v in mem.items() if k.startswith("L=%d" % Lv) and "shuffled" not in k):
            Lgood = Lv
    E = M["eigenspaces L=%d" % Lgood]
    roots = sorted(int(k.split("=")[-1]) for k in E if k.startswith("T3,T5,T7,T2="))
    ef = M.get("eigenforms L=%d" % Lgood, {})
    out["mod2"].append({
        "p": M["p"], "eps": M["eps"], "dim": M["dim"], "NB": M["NB"], "saturation_rounds": M["saturation_rounds"],
        "char_conrey": M["char_conrey"], "frob2_class": M["frob2_class"], "labelling_L": Lgood,
        "U2_roots": [F16[r] for r in roots],
        "other_labelling_member": any(v for k, v in M["membership"].items() if k.startswith("L=%d" % (1 - Lgood)) and "shuffled" not in k),
        "shuffled_control_member": any(v for k, v in M["membership"].items() if "shuffled" in k),
        "joint_T3": E["T3"], "joint_T3T5": E["T3,T5"], "joint_T3T5T7": E["T3,T5,T7"],
        "with_T2": [E["T3,T5,T7,T2=%d" % r] for r in roots],
        "generalised": [E["generalised T2..T7, T2=%d" % r] for r in roots],
        "hecke_consistency_beyond_sturm": M["hecke_consistency_beyond_sturm"], "commute": M["commute"],
        "odd_coefficients_agree": ef.get("odd_coefficients_agree_to_NB"), "sturm_gamma0_4p": ef.get("sturm_gamma0_4p"),
        "NB_covers": ef.get("NB_covers"), "match_prediction": ef.get("match_prediction")})
for f in sorted(glob.glob("stark_ad_*prec57.json")):
    if f == "stark_ad_prec57.json":
        continue                     # 1951 via the trace table of the note: cross-check below
    S = json.load(open(f))
    p = int(re.findall(r"_p(\d+)_", f)[0])
    st = S["stark"]
    out["stark"].append({
        "p": p, "ncoef": S["ncoef"], "c(V)": S["V"]["c = L'''(0)/6"][:30], "c(V')": S["V'"]["c = L'''(0)/6"][:30],
        "lfuncheckfeq": [S["V"]["lfuncheckfeq"], S["V'"]["lfuncheckfeq"]], "choices": len(st),
        "degenerate": len(S.get("degenerate", [])),
        "worst_log10_residual": max(max(s["log10 residual a"], s["log10 residual b"]) for s in st),
        "values a + b sqrt5": sorted({"%s%+d*sqrt5" % (s["a"], int(s["b"])) for s in st}),
        "norms A(V)A(V')": sorted({s["A*A' (Tate: rational)"] for s in st})})
CK = "c = L'''(0)/6"
SA, SB = json.load(open("stark_ad_prec57.json")), json.load(open("stark_ad_p1951_prec57.json"))
out["stark_1951_crosscheck"] = {
    "note": "stark_ad.py (trace table of the note, 400000 coefficients) vs stark_general.py (classes.py, 240000)",
    "c(V) equal to 57 digits": SA["V"][CK] == SB["V"][CK], "c(V') equal to 57 digits": SA["V'"][CK] == SB["V'"][CK],
    "same (a, b) values": sorted((s["a"], s["b"]) for s in SA["stark"]) == sorted((s["a"], s["b"]) for s in SB["stark"])}
json.dump(out, open("questions_summary.json", "w"), indent=1)
L = ["## Klein curves (Theorem C analogue)", "",
     "| p | d | K0 | Tr u^2, Tr v^2 | recognition | Frobenius | isogeny field | v(j) < 0 at | witnesses |",
     "|---|---|---|---|---|---|---|---|---|"]
for k in out["klein"]:
    primes = sorted({w[0] for w in k["v_j_negative"]})
    L.append("| %d | %d | `%s` | %d, %d | 1e%d | %d/%d | K0K6 (deg 24) %s | %s | %s |" % (
        k["p"], k["d"], k["K0"], k["Tr_u2"], k["Tr_v2"], k["recognition_residual_log10_max"], k["frobenius_ok"],
        k["frobenius_total"], "yes" if k["certified"] else "NO", ", ".join(map(str, primes)), ", ".join(map(str, k["witnesses"][:3]))))
L += ["", "## Mod-2 weight-one forms (Theorem D analogue)", "",
      "| p | space | dim | rounds | L | U2 roots x, y | T3 / T3T5 / T3T5T7 | +T2 | generalised | odd coeffs agree to NB (Sturm Gamma0(4p)) | controls |",
      "|---|---|---|---|---|---|---|---|---|---|---|"]
for m in out["mod2"]:
    L.append("| %d | %s | %d | %d | %d | %s | %d / %d / %d | %s | %s | %s to %d (%s) | other labelling %s, shuffled %s |" % (
        m["p"], "chi" if m["eps"] == 0 else "chi*eps_p", m["dim"], m["saturation_rounds"], m["labelling_L"],
        ", ".join(m["U2_roots"]), m["joint_T3"], m["joint_T3T5"], m["joint_T3T5T7"], m["with_T2"], m["generalised"],
        m["odd_coefficients_agree"], m["NB"], m["sturm_gamma0_4p"], "no" if m["other_labelling_member"] else "absent",
        "no" if m["shuffled_control_member"] else "absent"))
L += ["", "## Stark's conjecture in rank 3 for ad^0 rho0 and its sqrt5-conjugate (numerical)", "",
      "| p | coefficients | lfuncheckfeq (V, V') | choices of f | worst log10 residual | A(V) found | A(V)A(V') |",
      "|---|---|---|---|---|---|---|"]
for s in out["stark"]:
    L.append("| %d | %d | %s | %d (+%d degenerate) | %.1f | %s | %s |" % (
        s["p"], s["ncoef"], s["lfuncheckfeq"], s["choices"], s["degenerate"], s["worst_log10_residual"],
        "; ".join(s["values a + b sqrt5"]), ", ".join(s["norms A(V)A(V')"])))
open("questions_tables.md", "w").write("\n".join(L) + "\n")
print("\n".join(L))
