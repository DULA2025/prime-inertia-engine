#!/bin/sh
# usage: sh run_leopoldt.sh "p1 p2 ..."   (ell = 2, 3, 5, 7)
for p in $1; do for ell in 2 3 5 7; do
  python3 -u k12_leopoldt_general.py $p $ell 400 > leopoldt_p${p}_ell${ell}.log 2>&1
done; done
