"""Stark's conjecture in rank 3 for V = ad^0 rho0 and V' = ad^0 rho0'' (the two 3-dimensional irreducible
representations of A5 = Gal(M/Q), M the Galois closure of f5, conductor 1951^2, V(c) = 1).

Stark (Tate's formulation, S = infinite places): for a Q[G]-isomorphism f: Q X -> Q E (X = degree-0 part of Z[places of M],
E = units of M), A(chi, f) = R(chi, f)/c(chi) lies in Q(chi) = Q(sqrt5) and A(chi^sigma, f) = sigma(A(chi, f)).
Here r(chi) = dim V^{c} = 3 and c(chi) = lim s^-3 L(s, chi) (full Artin L-function, Euler factor (1 - 1951^-s)^-1 at 1951).

Regulator through K12 = M^H, H = C5 (k12.json, units in k12_bnf_units.gp): the real places of K12 are the cosets gH,
A5 acts by left multiplication, Lambda(u) = (log|u|_v)_v.  P_V = (3/60) sum_g chi_V(g) L_g projects R^12 onto the
3-dimensional V-part.  For f defined by delta_{j_i} -> u_{k_i} (i = 1, 2, 3; extended Hecke-equivariantly, which is a
Q-rational G-isomorphism on the V + V' part), R(V, f) = det[P_V Lambda(u_k)] / det[P_V delta_j].
L-values: L(s, V) from the Frobenius classes (bianchi/chunks codes for p < 4.4e8; Euler factor
1/((1-X)(1 - u X + X^2)) with u = t^2 - 2 = 2, -2, -1, -phi (5A), phi - 1 (5B) for classes 1, 2A, 3A, 5A, 5B;
5A = class with |t| = phi - 1 for rho0, as fixed in the note).  Functional equation checked with lfuncheckfeq.
Author: Dula."""
import json, sys, itertools, numpy as np, cypari2
pari = cypari2.Pari(); pari.allocatemem(8 * 10**9)
P0 = int(sys.argv[1]); PREC = int(sys.argv[2]) if len(sys.argv) > 2 else 57
NCOEF = int(sys.argv[3]) if len(sys.argv) > 3 else 450000
FSTR = json.load(open("fields6.json"))[str(P0)]["poly"]
pari("default(realprecision, %d)" % PREC)
# ---------------------------------------------------------------- L-functions of V and V'
CLJ = {int(k): v for k, v in json.load(open("classes_%d.json" % P0))["codes"].items()}
NAME = {"1": 1, "2A": 2, "3A": 3, "5A": 4, "5B": 5}
ps = [int(q) for q in pari.primes(int(pari.primepi(NCOEF)))]
assert max(CLJ) >= ps[-1]
cl = [0 if q == P0 else NAME[CLJ[q]] for q in ps]
pari("CLV = Vecsmall(%s); w = quadgen(5);" % str(cl).replace(" ", ""))
res = {"prec": PREC, "ncoef": NCOEF}
cval = {}
import os
CACHE = "stark_cvals_p%d_prec%d.json" % (P0, PREC)
if os.path.exists(CACHE):
    cc = json.load(open(CACHE)); cval = {k: pari(v) for k, v in cc["c"].items()}; res.update(cc["res"])
for name, U in (("V", "[2, -2, -1, -w, w - 1]"), ("V'", "[2, -2, -1, w - 1, -w]")):
    if name in cval: continue
    pari("U = %s; an = direuler(q = 2, %d, if (q == %d, 1/(1 - X), my(u = U[CLV[primepi(q)]]); 1/((1 - X)*(1 - u*X + X^2))));" % (U, NCOEF, P0))
    pari("L = lfuncreate([apply(z -> real(z * 1.), an), 0, [0, 0, 0], 1, %d^2, 1, []]);" % P0)
    fe = int(pari("lfuncheckfeq(L)"))
    pari("Li = lfuninit(L, [0, 0, 0], 3)")
    vals = [pari("lfun(Li, 0, %d)" % k) for k in range(4)]
    c = vals[3] / 6
    cval[name] = c
    res[name] = {"lfuncheckfeq": fe, "L(0), L'(0), L''(0)": [str(pari.real(v))[:25] for v in vals[:3]], "c = L'''(0)/6": str(c)}
    print("%s: lfuncheckfeq %d; L, L', L'' at 0: %s; c = %s" % (name, fe, [float(pari.abs(v)) for v in vals[:3]], c), flush=True)
json.dump({"c": {k: str(v) for k, v in cval.items()}, "res": {k: res[k] for k in ("V", "V'")}}, open(CACHE, "w"))
# ---------------------------------------------------------------- regulators
K = json.load(open("k12_p%d.json" % P0))
pari("Vu = read(\"k12_units_p%d.gp\"); Q = Vu[1]; a = Vu[2]; fu = Vu[3];" % P0)
pari("Pth = %s;" % K["P"])
roots = pari("polroots(Q)")
cos = K["cosets"]; theta = [pari(tv) for tv in K["theta"]]
xs = pari("vecsort(real(polroots(%s)))" % FSTR)
xs = [xs[i] for i in range(5)]
def th(g): return sum(xs[g[i]] ** 2 * xs[g[(i + 1) % 5]] for i in range(5))
# coset representatives in the sorted labelling (recompute theta values; K["theta"] used polroots order)
def sgn(g): return (-1) ** sum(1 for i in range(5) for j in range(i + 1, 5) if g[i] > g[j])
A5 = [g for g in itertools.permutations(range(5)) if sgn(g) == 1]
cosets, tvals = [], []
for g in A5:
    t = th(g)
    for k, v in enumerate(tvals):
        if abs(v - t) < pari("1e-30") * (1 + abs(t)):
            cosets[k].append(g); break
    else:
        tvals.append(t); cosets.append([g])
assert len(tvals) == 12
# embeddings of K12 (roots y of Q) -> coset index via theta = a(y)
alift = pari("lift(a)")
emb = []
for i in range(12):
    y = pari.real(roots[i]); tv = pari.subst(alift, "x", y)
    k = min(range(12), key=lambda k: abs(tvals[k] - tv))
    assert abs(tvals[k] - tv) < pari("1e-20") * (1 + abs(tv)), (i, tv)
    emb.append((k, y))
assert sorted(k for k, _ in emb) == list(range(12))
order = sorted(emb)                 # sorted by coset index
Lam = np.array([[float(pari.log(pari.abs(pari.subst(pari("fu[%d]" % (j + 1)), "x", y)))) for j in range(11)] for (k, y) in order])
Lam_hp = [[pari.log(pari.abs(pari.subst(pari("fu[%d]" % (j + 1)), "x", y))) for j in range(11)] for (k, y) in order]
# left action of A5 on cosets
def comp(a, b): return tuple(a[b[i]] for i in range(5))
cidx = {g: k for k, cl_ in enumerate(cosets) for g in cl_}
def order_of(g):
    k, h = 1, g
    while h != tuple(range(5)): h = comp(g, h); k += 1
    return k
c0 = (1, 2, 3, 4, 0)
def inv(a):
    q = [0] * 5
    for i in range(5): q[a[i]] = i
    return tuple(q)
classA = {comp(comp(g, c0), inv(g)) for g in A5}
phi = (1 + pari("sqrt(5)")) / 2
def chi_val(g, which):
    o = order_of(g)
    if o == 1: return pari(3)
    if o == 2: return pari(-1)
    if o == 3: return pari(0)
    small = (g in classA) if which == "V" else (g not in classA)
    return 1 - phi if small else phi            # tr Ad = t^2 - 1: small |t| = phi - 1 -> 1 - phi; big -> phi
def projector(which):
    P = pari.matrix(12, 12)
    for g in A5:
        cv = chi_val(g, which)
        for k in range(12):
            gk = cidx[comp(g, cosets[k][0])]
            P[gk, k] += cv
    return P * pari(3) / 60
res["coset_check"] = True
Rv = {}
for which in ("V", "V'"):
    P = projector(which)
    rk = int(pari.matrank(P)); assert rk == 3, rk
    trP = pari.trace(P)
    Bm = pari.matimage(P)             # basis of the image (12 x 3)
    def coords(vec):
        sol = pari.matsolve(pari.mattranspose(Bm) * Bm, pari.mattranspose(Bm) * vec)
        return sol
    LamM = pari.matrix(12, 11, [Lam_hp[i][j] for i in range(12) for j in range(11)])
    Rv[which] = (P, Bm, coords, LamM)
    print("%s: projector rank %d, trace %s" % (which, rk, trP), flush=True)
import random
random.seed(11)
# units of K12 that come from K6 = Q(y^2) (Q is even in y) have zero V- and V'-components
k6units = [j for j in range(11) if pari("lift(Mod(subst(fu[%d], x, -x), Q)) == fu[%d]" % (j + 1, j + 1))]
print("fundamental units lying in K6 (invariant under y -> -y):", k6units, flush=True)
res["units_in_K6"] = k6units
choices = [((0, 1, 2), (0, 1, 2)), ((0, 1, 2), (4, 6, 10)), ((2, 5, 9), (1, 3, 8))]
others = [j for j in range(11) if j not in k6units]
while len(choices) < 60:
    choices.append((tuple(sorted(random.sample(range(12), 3))), tuple(sorted(random.sample(others, 3)))))
res["stark"] = []
for js, ks in choices:
    A = {}
    for which in ("V", "V'"):
        P, Bm, coords, LamM = Rv[which]
        D = pari.matrix(3, 3); Ub = pari.matrix(3, 3)
        for c_, j in enumerate(js):
            e = pari.matrix(12, 1); e[j, 0] = 1
            v = coords(P * e)
            for r_ in range(3): D[r_, c_] = v[r_, 0]
        for c_, k in enumerate(ks):
            col = pari.matrix(12, 1, [LamM[i, k] for i in range(12)])
            v = coords(P * col)
            for r_ in range(3): Ub[r_, c_] = v[r_, 0]
        dU, dD = pari.matdet(Ub), pari.matdet(D)
        if pari.abs(dD) < pari("1e-40") or pari.abs(dU) < pari("1e-40"):
            A = None; break
        A[which] = (dU / dD) / cval[which]
    if A is None:
        res.setdefault("degenerate", []).append([js, ks]); continue
    s = (A["V"] + A["V'"]) / 2; dlt = (A["V"] - A["V'"]) / (2 * pari("sqrt(5)"))
    ra, rb = pari.bestappr(s, 10**9), pari.bestappr(dlt, 10**9)
    def lg(z):
        z = pari.abs(z)
        return -999.0 if z == 0 else float(pari.log(z) / pari.log(10))
    rec = {"js": js, "ks": ks, "A(V)": "%.30g" % float(A["V"]) if abs(float(A["V"])) > 1e-30 else "%.3e" % float(A["V"]),
           "A(V')": "%.30g" % float(A["V'"]) if abs(float(A["V'"])) > 1e-30 else "%.3e" % float(A["V'"]),
           "a": str(ra), "b": str(rb), "log10 residual a": round(lg(s - ra), 1), "log10 residual b": round(lg(dlt - rb), 1),
           "A*A' (Tate: rational)": str(pari.bestappr(A["V"] * A["V'"], 10**9)), "log10 |A(V)|": round(lg(A["V"]), 1)}
    res["stark"].append(rec)
    print(json.dumps(rec), flush=True)
json.dump(res, open("stark_ad_p%d_prec%d.json" % (P0, PREC), "w"), indent=1)
