## Klein curves (Theorem C analogue)

| p | d | K0 | Tr u^2, Tr v^2 | recognition | Frobenius | isogeny field | v(j) < 0 at | witnesses |
|---|---|---|---|---|---|---|---|---|
| 1951 | 2 | `a^4 + 6*a^2 + 4` | 7804, 3902 | 1e-693 | 403/403 | K0K6 (deg 24) yes | 569, 1951, 18371, 30859, 7091231370161 | 19, 59, 89 |
| 2141 | 1 | `a^4 + 3*a^2 + 1` | 4282, 4282 | 1e-595 | 385/385 | K0K6 (deg 24) yes | 29, 149, 2141, 4552789, 3862149761 | 41, 89, 101 |
| 2141 | 3 | `a^4 - a^3 + 2*a^2 + a + 1` | 12846, 4282 | 1e-595 | 388/388 | K0K6 (deg 24) yes | 19, 829, 2141, 1566199, 1721658659471131 | 31, 79, 109 |
| 3701 | 1 | `a^4 + 3*a^2 + 1` | 7402, 7402 | 1e-695 | 389/389 | K0K6 (deg 24) yes | 41, 3701, 5281, 292480791140893601 | 29, 61, 89 |
| 3701 | 3 | `a^4 - a^3 + 2*a^2 + a + 1` | 22206, 7402 | 1e-694 | 392/392 | K0K6 (deg 24) yes | 3701, 15180828043218724497986065351 | 19, 61, 109 |
| 3821 | 1 | `a^4 + 3*a^2 + 1` | 7642, 7642 | 1e-694 | 390/390 | K0K6 (deg 24) yes | 541, 3821, 14741, 9220134010860181 | 29, 41, 89 |
| 3821 | 3 | `a^4 - a^3 + 2*a^2 + a + 1` | 22926, 7642 | 1e-691 | 390/390 | K0K6 (deg 24) yes | 19, 3821, 3539317036217533699 | 79, 139, 151 |
| 8501 | 1 | `a^4 + 3*a^2 + 1` | 17002, 17002 | 1e-694 | 389/389 | K0K6 (deg 24) yes | 509, 1549, 8501, 954415467134858269 | 29, 89, 109 |
| 8501 | 3 | `a^4 - a^3 + 2*a^2 + a + 1` | 51006, 17002 | 1e-693 | 389/389 | K0K6 (deg 24) yes | 19, 61, 4639, 8501, 4856192474278602729271 | 109, 139, 151 |
| 9461 | 1 | `a^4 + 3*a^2 + 1` | 18922, 18922 | 1e-695 | 390/390 | K0K6 (deg 24) yes | 89, 9461, 17056691749, 5332528102961 | 29, 41, 61 |
| 9461 | 3 | `a^4 - a^3 + 2*a^2 + a + 1` | 56766, 18922 | 1e-685 | 390/390 | K0K6 (deg 24) yes | 31, 9461, 857807719, 3564692749 | 19, 61, 109 |

## Mod-2 weight-one forms (Theorem D analogue)

| p | space | dim | rounds | L | U2 roots x, y | T3 / T3T5 / T3T5T7 | +T2 | generalised | odd coeffs agree to NB (Sturm Gamma0(4p)) | controls |
|---|---|---|---|---|---|---|---|---|---|---|
| 1951 | chi | 161 | 4 | 0 | z+z^2, 1+z^3 | 4 / 3 / 2 | [1, 1] | [3, 6] | True to 2400 (1952) | other labelling absent, shuffled absent |
| 2141 | chi | 177 | 5 | 1 | z^3, z^4 | 4 / 2 / 2 | [1, 1] | [3, 3] | True to 2600 (2142) | other labelling absent, shuffled absent |
| 2141 | chi*eps_p | 178 | 4 | 1 | z^3, z^4 | 5 / 3 / 2 | [1, 1] | [3, 3] | True to 2600 (2142) | other labelling absent, shuffled absent |
| 3701 | chi | 307 | 4 | 0 | z^3, z^4 | 2 / 2 / 2 | [1, 1] | [3, 3] | True to 4400 (3702) | other labelling absent, shuffled absent |
| 3701 | chi*eps_p | 308 | 4 | 0 | z^3, z^4 | 3 / 2 / 2 | [1, 1] | [3, 3] | True to 4400 (3702) | other labelling absent, shuffled absent |
| 3821 | chi | 317 | 4 | 1 | z^2, z^3 | 2 / 2 / 2 | [1, 1] | [3, 3] | True to 4600 (3822) | other labelling absent, shuffled absent |
| 3821 | chi*eps_p | 318 | 4 | 1 | z^2, z^3 | 2 / 2 / 2 | [1, 1] | [3, 3] | True to 4600 (3822) | other labelling absent, shuffled absent |

## Stark's conjecture in rank 3 for ad^0 rho0 and its sqrt5-conjugate (numerical)

| p | coefficients | lfuncheckfeq (V, V') | choices of f | worst log10 residual | A(V) found | A(V)A(V') |
|---|---|---|---|---|---|---|
| 1951 | 240000 | [-187, -188] | 28 (+32 degenerate) | -47.2 | -12+4*sqrt5; -2+2*sqrt5; -2-2*sqrt5; -4+0*sqrt5; -4+4*sqrt5; -6+2*sqrt5; -6-2*sqrt5; -8+0*sqrt5; 2+2*sqrt5; 2-2*sqrt5; 4+0*sqrt5; 6+2*sqrt5; 6-2*sqrt5; 8+0*sqrt5 | -16, -64, 16, 64 |
| 2141 | 450000 | [-186, -188] | 15 (+45 degenerate) | -47.0 | -16-8*sqrt5; -2-2*sqrt5; -4+0*sqrt5; -4-4*sqrt5; 12+4*sqrt5; 16+8*sqrt5; 4+0*sqrt5; 6+2*sqrt5 | -16, -64, 16, 64 |
| 3701 | 240000 | [-184, -183] | 26 (+34 degenerate) | -47.3 | -2+0*sqrt5; -2+2*sqrt5; -2-2*sqrt5; -3+1*sqrt5; -3-1*sqrt5; -4+0*sqrt5; -5-1*sqrt5; -6+2*sqrt5; 1-1*sqrt5; 2+0*sqrt5; 2+2*sqrt5; 2-2*sqrt5; 3+1*sqrt5; 3-1*sqrt5; 6-2*sqrt5 | -16, -4, 16, 20, 4 |
| 3821 | 240000 | [-186, -185] | 44 (+16 degenerate) | -45.9 | -1+1*sqrt5; -1-1*sqrt5; -2+0*sqrt5; -2+2*sqrt5; -2-2*sqrt5; -3-1*sqrt5; -4+0*sqrt5; -4-2*sqrt5; -6+2*sqrt5; -8-4*sqrt5; 0-2*sqrt5; 1+1*sqrt5; 1-1*sqrt5; 10+4*sqrt5; 2+0*sqrt5; 2+2*sqrt5; 2-2*sqrt5; 3+1*sqrt5; 4+0*sqrt5; 4+2*sqrt5; 5+1*sqrt5; 5+3*sqrt5; 5-1*sqrt5 | -16, -20, -4, 16, 20, 4 |
| 8501 | 500000 | [-187, -185] | 27 (+33 degenerate) | -43.6 | -2+2*sqrt5; -2-2*sqrt5; -4+0*sqrt5; -4+4*sqrt5; -4-4*sqrt5; -6-2*sqrt5; 2+2*sqrt5; 2-2*sqrt5; 4+0*sqrt5; 4+4*sqrt5; 6-2*sqrt5; 8+0*sqrt5 | -16, -64, 16, 64 |
| 9461 | 550000 | [-185, -185] | 29 (+31 degenerate) | -43.2 | -2+2*sqrt5; -2-2*sqrt5; -4+0*sqrt5; -4-4*sqrt5; -6-2*sqrt5; -8+0*sqrt5; -8+4*sqrt5; 2+2*sqrt5; 2-2*sqrt5; 4+0*sqrt5; 4+4*sqrt5; 6+2*sqrt5; 8+0*sqrt5; 8+4*sqrt5 | -16, -64, 16, 64 |
