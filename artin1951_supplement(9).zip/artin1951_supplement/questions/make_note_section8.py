"""Write note_section8.tex (Section 8 of the note: the six representations of [DM]) with its three tables filled in from
questions_summary.json.  Author: Dula."""
import json
from collections import Counter
S = json.load(open("questions_summary.json"))
K12H = {1951: 1, 2141: 1, 3701: 2, 3821: 4, 8501: 1, 9461: 1}       # class numbers of K12 (k12*.json, bnfinit)
F16TEX = {"z+z^2": "z+z^2", "1+z^3": "1+z^3", "z^3": "z^3", "z^4": "z^4", "z^2": "z^2"}

def big(n):
    s = str(n)
    return s if len(s) <= 12 else r"\scriptsize " + s
rows_E = []
for k in sorted(S["klein"], key=lambda k: (k["p"], k["d"])):
    c = Counter(w[0] for w in k["v_j_negative"] if w[0] != k["p"])
    pl = ", ".join(("$%s$ (2)" % l) if m == 2 else ("$%s$" % l) for l, m in sorted(c.items()))
    vp = sum(1 for w in k["v_j_negative"] if w[0] == k["p"])
    rows_E.append(r"%d & %d & %s & %d & %d & %d/%d \\" % (k["p"], k["d"], pl, vp, k["witnesses"][0], k["frobenius_ok"], k["frobenius_total"]))
ORD2 = {"1": 1, "2A": 2, "3A": 3, "5A": 5, "5B": 5}
rows_F = []
for m in S["mod2"]:
    sp = r"$\chi$" if m["eps"] == 0 else r"$\chi\varepsilon_p$"
    x, y = m["U2_roots"]
    rows_F.append(r"%d & %s & %d & %d & %d & $%s$, $%s$ & %d, %d, %d & %d, %d & %d \\" % (
        m["p"], sp, m["dim"], m["saturation_rounds"], ORD2[m["frob2_class"]], x, y, m["joint_T3"], m["joint_T3T5"],
        m["joint_T3T5T7"], m["generalised"][0], m["generalised"][1], m["NB"]))
rows_G = []
for s in sorted(S["stark"], key=lambda s: s["p"]):
    vals = s["values a + b sqrt5"]
    def tex(v):
        a, b = v.split("*sqrt5")[0].rsplit("+", 1) if "+" in v[1:] else v.split("*sqrt5")[0].rsplit("-", 1)
        return v
    norms = sorted({abs(int(n)) for n in s["norms A(V)A(V')"]})
    rows_G.append(r"%d & %d & %d & %d, %d & %d & $%.1f$ & %s \\" % (
        s["p"], K12H[s["p"]], s["ncoef"], s["lfuncheckfeq"][0], s["lfuncheckfeq"][1], s["choices"],
        s["worst_log10_residual"], ", ".join(str(n) for n in norms)))

TEX = r"""\section{The six representations of prime conductor below \texorpdfstring{$10^4$}{10\^{}4}}\label{sec:F}

Doud and Moore \cite{DM} list all even icosahedral representations of prime conductor below $10^4$. Their quintic fields $L_5^{(p)}$ are totally real with Galois closure $A_5$ and discriminant $p^4$, for
\[
p\in\mathcal P=\{1951,\ 2141,\ 3701,\ 3821,\ 8501,\ 9461\}.
\]
All these $p$ are $\equiv1\pmod5$, and all but $1951$ are $\equiv5\pmod8$. For $p\in\mathcal P$ we use the notation of \S\ref{sec:notation} with $1951$ replaced by $p$: $\chi$ has order $5$ and conductor $p$, with $\chi(g)=\zeta_5^2$ for the generator $g$ of $(\Z/p)^\times$ chosen by \textsc{pari}; $\rho=\rho_0\otimes\chi^3$ has conductor $p$ and determinant $\chi$, where $\rho_0$ is the one of the two conjugate twist-minimal representations for which this conductor is $p$; and $M$, $K_6$, $\rbar$, $\rbar_2$ are as before. Theorems~\ref{thm:A}, \ref{thm:Ap}, \ref{thm:App} and~\ref{thm:B} and their proofs apply to each of them without change. They use only the projective image, the determinant, the field $L_5$, and tame ramification at $p\equiv1\pmod5$.

\begin{lemma}[the trace-zero lattice]\label{lem:A4}
Let $L$ be a totally real quintic field of discriminant $p^4$, where $p>5$ is prime, and let $\Lambda_0=\{x\in\mathcal O_L:\Tr x=0\}$ with the form $\Tr(xy)$. Then $\Lambda_0$ is isometric to the root lattice $A_4$ with its form multiplied by $p$.
\end{lemma}

\begin{proof}
\begin{itemize}
\item \emph{Ramification.} As $p>5$, the ramification at $p$ is tame, so the exponent of $p$ in the discriminant is $\sum(e_i-1)f_i$ over the primes above $p$, where $\sum e_if_i=5$. This sum is $4$ only for a single prime with $e=5$.
\item \emph{Determinant.} The trace map $\mathcal O_L\to\Z$ is onto. Otherwise its image is $5\Z$, then $\mathcal O_L=\Z\oplus\Lambda_0$ as an orthogonal sum, and $5$ divides the discriminant. So $[\mathcal O_L:\Z\oplus\Lambda_0]=5$, and $5\det\Lambda_0=25p^4$.
\item \emph{Divisibility by $p$.} A totally and tamely ramified extension of $\Q_p$ of degree $5$ has a uniformiser $\pi$ with $\pi^5=pu$ for a unit $u\in\Z_p^\times$ \cite[II, \S5, Prop.~12]{Lg}. So $\mathcal O_L\otimes\Z_p=\Z_p[\pi]$, $\Tr\pi^k=0$ for $1\le k\le4$, and $\Tr\pi^5=5pu$. Hence $\Lambda_0\otimes\Z_p$ has basis $\pi,\dots,\pi^4$, and its Gram matrix is $5pu$ times the anti-diagonal matrix of ones. So $\Tr(xy)\in p\Z$ on $\Lambda_0$, and $\Lambda_1=(\Lambda_0,\Tr(xy)/p)$ is an integral lattice of determinant $5$.
\item \emph{Evenness.} For $x\in\Lambda_0$, $\Tr(x^2)=\Tr(x)^2-2e_2(x)$ is even, where $e_2(x)$ is the second elementary symmetric function of the conjugates. As $p$ is odd, $\Lambda_1$ is even.
\item \emph{Identification.} $\Lambda_1$ is positive definite, since $L$ is totally real. Let $\lambda_1\le\dots\le\lambda_4$ be its successive minima (squared lengths). Minkowski's second theorem \cite[VIII.2]{Cas}, with Hermite's constant $\gamma_4=\sqrt2$ \cite[Ch.~1, Table~1.2]{CS}, gives $\lambda_1\cdots\lambda_4\le\gamma_4^4\det\Lambda_1=20$. The $\lambda_i$ are even, so they are all $2$. Hence the roots of $\Lambda_1$ span a root lattice $R$ of rank $4$, with $\det R=5\,[\Lambda_1:R]^2$. The root lattices of rank $4$ have determinants $5$ ($A_4$), $4$ ($D_4$), $8$, $9$, $12$ and $16$. So $R=A_4$ and $R=\Lambda_1$.
\end{itemize}
\end{proof}

For $p=1951$ this explains the isometry found by computation in \S\ref{sec:C}; for all $p\in\mathcal P$ we also checked it with \texttt{qfisom}. It is the analogue, for these non-Galois fields, of the theorem of Mantilla-Soler and Monsurr\`o that the trace-zero form of a tamely ramified cyclic field of prime degree $\ell$ is $A_{\ell-1}$ scaled by the radical of the discriminant \cite[Thm.~2.9]{MSM}.

\begin{corollary}[accessory irrationalities]\label{cor:acc}
Let $L$ be as in Lemma~\ref{lem:A4}, and let $k$ be a number field without real places. Then $\Tr y^2=0$ for some $0\ne y\in\Lambda_0\otimes k$. For $k=\Q(\sqrt{-d})$ this means that $y=u+\sqrt{-d}\,v$ with $u,v\in\Lambda_0$, $\Tr uv=0$ and $\Tr u^2=d\,\Tr v^2$. For $d=1,2,3$ one can take $\Tr v^2=2p$ and $\Tr u^2=2dp$.
\end{corollary}

\begin{proof}
By the lemma, $\Lambda_0\otimes\Q$ is similar to $A_4\otimes\Q\cong\langle2,\tfrac32,\tfrac43,\tfrac54\rangle\cong\langle2,6,3,5\rangle$.
\begin{itemize}
\item A quaternary form over $\Q_\ell$ whose discriminant is not a square is isotropic \cite[IV.2.2, Thm.~6]{Se}. The discriminant $5$ is not a square in $\Q_2$, $\Q_3$, $\Q_5$, nor in $\Q_\ell$ for $\ell\equiv\pm2\pmod5$.
\item For $\ell\equiv\pm1\pmod5$ the coefficients are $\ell$-adic units, so the Hasse invariant is $1=(-1,-1)_\ell$, and the form is again isotropic \cite[loc.\ cit.]{Se}.
\end{itemize}
So the form is isotropic at every place of $k$, hence over $k$ by the Hasse--Minkowski theorem. In $A_4=\{x\in\Z^5:\sum x_i=0\}$, the vector $v=e_5-e_1$ is orthogonal to $e_4-e_2$, $e_3+e_4-e_1-e_5$ and $2e_4-e_1-e_5$, of squared lengths $2d$ for $d=1,2,3$.
\end{proof}

So the first step of Klein's construction in \S\ref{sec:C} is available over every imaginary quadratic field: any imaginary quadratic irrationality can serve as the accessory irrationality for these quintics. We carried out the remaining steps, at $600$ or $700$ digits, for $d=1,3$ and every $p\in\mathcal P$, and for $d=2$ and $p=1951$. Let $K_d=\Q(\sqrt5,\sqrt{-d})$; then $K_1=F$, $K_3=K$, and $K_2=\Q[a]/(a^4+6a^2+4)$.

\begin{thmx}\label{thm:E}
Let $p\in\mathcal P$ and $d\in\{1,3\}$, or $(p,d)=(1951,2)$. Let $j_{p,d}\in K_d$ be Klein's invariant, computed as in \S\ref{sec:C}, of the element $y=u+\sqrt{-d}\,v$ of Corollary~\ref{cor:acc} with the $u,v$ given in the supplement, and let $E/K_d$ be an elliptic curve with $j(E)=j_{p,d}$. For $p=1951$ and $d\in\{1,3\}$ these are the curves of Theorem~\ref{thm:C}.
\begin{enumerate}[label=\textup{(\roman*)}]
\item The field of definition of a $5$-isogeny of $E$ is $K_dK_6$. So $E[5]\otimes\bar\F_5\cong\rbar|_{G_{K_d}}\otimes\psi$ for a character $\psi$.
\item $v(j_{p,d})<0$ exactly at the places in Table~\ref{tab:E}, and $v(j_{p,d})=-5$ at those not above $p$. Elsewhere $E$ has potentially good reduction.
\item $E$ is modular.
\end{enumerate}
\end{thmx}

\begin{proof}
As for Theorem~\ref{thm:C}. In each case the fibre polynomial is irreducible over $K_d$, its stem field has degree $24$ and contains $K_dK_6$ (\texttt{nfisincl}), and the hypotheses of \cite[\S6.1]{CN} hold, with the decomposed-generic witnesses of Table~\ref{tab:E}. As a further check, $a_P(E)^2\equiv N(P)\,\bar t_\ell^{\,2}\pmod5$ at every degree-one prime $P\nmid p$ of good reduction with $N(P)=\ell<3000$.
\end{proof}

\begin{table}[h]
\centering
\caption{The curves of Theorem~\ref{thm:E} (for $p=1951$ and $d=1,3$ see Theorem~\ref{thm:C}): the primes $\ell\ne p$ with a place where $v(j)=-5$ (two such places where marked), the number of places above $p$ with $v(j)<0$, the smallest decomposed-generic witness $\ell$, and the Frobenius check in the proof.}\label{tab:E}
\small
\begin{tabular}{rrlccc}
\toprule
$p$ & $d$ & $\ell\ne p$ with $v(j)=-5$ & above $p$ & witness & Frobenius \\
\midrule
ROWS_E
\bottomrule
\end{tabular}
\end{table}

\begin{thmx}\label{thm:F}
Let $p\in\{2141,3701,3821\}$, let $\varepsilon_p$ be the quadratic character of conductor $p$, which is even, and let $S$ be $S_2(\Gamma_0(p),\chi)$ or $S_2(\Gamma_0(p),\chi\varepsilon_p)$.
\begin{enumerate}[label=\textup{(\roman*)}]
\item Statements (i)--(iii) of Theorem~\ref{thm:D} hold for $\rho$ and $S$, with the eigenvalues $x,y$ of $\rbar_2(\Frob_2)$ and the dimensions of Table~\ref{tab:F}. In particular the joint eigenspace of $T_3,T_5,T_7$ is two-dimensional, and the generalised eigenspaces have dimensions $3$ and $3$. So in each of the two spaces exactly three newforms with $a_2\equiv x$ and three with $a_2\equiv y$ are congruent to $\rho$ modulo the maximal ideal of $\bar\Z_2$.
\item There is a Katz cusp form $g_1^{(p)}$ of weight $1$ on $\Gamma_1(p)$ over $\F_{16}$, on which the diamond operators act through $\bar\chi$, with $a_1=1$ and $T_\ell g_1^{(p)}=\bar a_\ell g_1^{(p)}$ for every prime $\ell\nmid2p$. No eigenform of weight one in characteristic $0$ is congruent to it, as in Theorem~\ref{thm:D}(v).
\end{enumerate}
Statement (iv) of Theorem~\ref{thm:D} holds for every $p\in\mathcal P$.
\end{thmx}

\begin{proof}
The computations are those of Theorem~\ref{thm:D}, in both spaces. The Sturm bounds are $(p+1)/6$ in weight $2$ and $(p+1)/3$ in weight $4$, and the coefficients were compared up to $N_B$ of Table~\ref{tab:F}, which exceeds $p+1$. After clearing denominators in the \textsc{pari} bases, saturation takes the number of rounds shown, and in each space the predicted forms for the other labelling of the classes of order $5$, and for shuffled traces, do not occur. This fixes $\rho_0$ against $\rho_0''$, as in \S\ref{sec:notation}.

For (i) at all $\ell$: by \cite{KW,Kis}, $\rbar_2$ comes from a newform $h$ of weight $2$ on $\Gamma_1(p)$ whose character reduces to $\bar\chi$. That character is $\chi\eta$ with $\eta$ of $2$-power order and conductor dividing $p$. Since $p\equiv5\pmod8$, $\eta$ is $1$, $\varepsilon_p$, or one of two odd characters of order $4$, so $h$ lies in one of the two spaces. There the argument of Theorem~\ref{thm:D}(i) applies. It transfers to the other space as follows.
\begin{itemize}
\item The forms $G_x$ of the two spaces have the same $q$-expansion up to $N_B$. Both are Katz forms of weight $2$ on $\Gamma_1(p)$ on which the diamond operators act through $\bar\chi$, since $\bar\varepsilon_p=1$.
\item Such a form whose $q$-expansion at $\infty$ vanishes to order greater than $(p+1)/6$ is zero. Indeed, it then vanishes to the same order at each of the $(p-1)/2$ cusps above $\infty$, which the diamond operators permute, and $(p-1)/2\cdot(p+1)/6$ is the degree $(p^2-1)/12$ of $\omega^{2}$ on $X_1(p)$.
\end{itemize}
So the two forms $G_x$ coincide, and likewise the two forms $G_y$. Statement (ii) follows as in the proof of Theorem~\ref{thm:D}(v), and (iv) has the same proof as there.
\end{proof}

\begin{table}[h]
\centering
\caption{Theorem~\ref{thm:F}, with Theorem~\ref{thm:D} in the first row: the space, its dimension, the saturation rounds, the order of $\Frob_2$ in $A_5$, the $U_2$-eigenvalues $x,y\in\F_{16}=\F_2(z)$, the dimensions of the joint eigenspaces of $T_3$, of $\{T_3,T_5\}$ and of $\{T_3,T_5,T_7\}$ (each becomes $1$ after adding $T_2-x$ or $T_2-y$), the generalised eigenspaces for $x$ and $y$, and the coefficient bound $N_B$.}\label{tab:F}
\small
\begin{tabular}{rlrrclccr}
\toprule
$p$ & $S$ & $\dim$ & rounds & $\Frob_2$ & $x$, $y$ & joint & generalised & $N_B$ \\
\midrule
ROWS_F
\bottomrule
\end{tabular}
\end{table}

\begin{remark}\label{rem:Fsizes}
\begin{enumerate}[label=(\arabic*)]
\item For $p=1951$ the two maximal ideals have ranks $3$ and $6$; in the six spaces of Theorem~\ref{thm:F} both ranks are $3$.
\item For $p=8501$ and $9461$ the spaces $S_2(\Gamma_0(p),\chi)$ have dimensions $707$ and $787$. Constructing the space for $8501$ in \textsc{pari} exceeded the $8$ GB of memory available to us (the run was stopped by the system), and we did not attempt the larger space for $9461$; so Theorem~\ref{thm:F} is not stated for them. Lemma~\ref{lem:A4}, Theorem~\ref{thm:E} and Remark~\ref{rem:stark} cover all six representations.
\end{enumerate}
\end{remark}

\begin{remark}[numerical: Stark's conjecture in rank $3$]\label{rem:stark}
Let $V$ and $V'$ be the two irreducible three-dimensional representations of $\Gal(M/\Q)\cong A_5$, namely $\Ad\rho_0$ and $\Ad\rho_0''$, and let $\sigma$ be the non-trivial automorphism of $\Q(\sqrt5)$. As $M$ is totally real, $L(s,V)$ has a zero of order $r(V)=\dim V=3$ at $s=0$. Let $c(V)$ be the leading coefficient there, for the full Artin $L$-function, whose Euler factor at $p$ is $(1-p^{-s})^{-1}$ because $p\equiv1\pmod5$. For a $\Q[G]$-isomorphism $f$ from the degree-zero part of $\Q[\text{places of }M]$ to $\mathcal O_M^\times\otimes\Q$, let $R(V,f)$ be Stark's regulator. Stark's conjecture \cite[Ch.~I, \S5]{Ta} says that $A(V,f)=R(V,f)/c(V)$ lies in $\Q(\sqrt5)$ and that $A(V',f)=\sigma(A(V,f))$.

We computed $R(V,f)$ through the fixed field $K_{12}$ of a subgroup of order $5$, on whose $12$ real places $V$ and $V'$ each occur once. The Hecke algebra of $K_{12}$ acts on the $(V\oplus V')$-parts of $\Q[\text{places of }K_{12}]$ and of $\mathcal O_{K_{12}}^\times\otimes\Q$ through $\Q(\sqrt5)$. So sending three places to three units defines $f$ on these parts, and $R(V,f)$ is a ratio of two $3\times3$ determinants. The check does not depend on the units being fundamental. The values $c(V)$ and $c(V')$ come from \textsc{pari}'s \texttt{lfun} at $57$ digits, with Frobenius classes computed as in \S\ref{sec:notation} and the functional equation checked by \texttt{lfuncheckfeq}. Table~\ref{tab:stark} summarises the results. For every $p\in\mathcal P$ and every non-degenerate choice of $f$, $A(V,f)$ agrees with an element $a+b\sqrt5$ of $\Z[\varphi]$, and $A(V',f)$ with $a-b\sqrt5$, to within $10^{-43}$. Typical values are $4$ and $\pm2\pm2\sqrt5$.

Tate proved Stark's conjecture for rational-valued characters \cite[Ch.~II]{Ta}, so the rationality of $A(V,f)A(V',f)$ is known. The content checked here is that $A(V,f)$ lies in $\Q(\sqrt5)$ and is $\sigma$-equivariant. We have not found earlier numerical checks of Stark's conjecture for a non-abelian character of rank greater than $1$. Jehanne, Roblot and Sands \cite{JRS} treat odd icosahedral representations, in rank $1$, and McGown, Sands and Valli\`eres \cite{MSV} treat abelian characters of higher rank.
\end{remark}

\begin{table}[h]
\centering
\caption{Remark~\ref{rem:stark}: the class number of $K_{12}$, the number of Dirichlet coefficients, the bit accuracy of the functional equations of $L(s,V)$ and $L(s,V')$, the number of non-degenerate choices of $f$, the largest $\log_{10}$ distance of $(A(V,f)+A(V',f))/2$ and $(A(V,f)-A(V',f))/2\sqrt5$ from the integers $a$, $b$, and the values of $|N(A(V,f))|$.}\label{tab:stark}
\small
\begin{tabular}{rrrcrcl}
\toprule
$p$ & $h(K_{12})$ & coefficients & \texttt{lfuncheckfeq} & choices & $\log_{10}$ residual & $|N(A)|$ \\
\midrule
ROWS_G
\bottomrule
\end{tabular}
\end{table}
"""
TEX = TEX.replace("ROWS_E", "\n".join(rows_E)).replace("ROWS_F", "\n".join(rows_F)).replace("ROWS_G", "\n".join(rows_G))
open("note_section8.tex", "w").write(TEX)
print(TEX[-3000:])
