# Questions 1–5 of the note: computations and literature (20 October 2026)

Author: Dula.

This folder holds the work on the five questions at the end of the note *The even icosahedral representation of conductor 1951* (§9 in the version of 20 October 2026). It also holds the computations behind the new §8 of the note, which treats all six even icosahedral representations of prime conductor below 10⁴. Doud and Moore list these six, with conductors 1951, 2141, 3701, 3821, 8501 and 9461.

Labels: [T] is a theorem or an exact computation; [N] is numerical evidence; [L] is a literature finding, which is only as good as our search. Nothing here proves that L(ρ, s) is entire, or that H1 holds for any field.

## Results

### Question 1: the sign, and Booker's remark on Ad ρ [L], [T]

- **Booker's remark.** Booker [Bo3, §2] writes that a result of Flicker implies that ρ is modular if and only if Ad ρ is. We still do not see how to get from Ad ρ to ρ without solving the sign problem of Lemma 3.4. The symmetric-square theory gives a cuspidal π on GL₂ with Ad π ↔ Ad ρ, that is, an SL(2) L-packet, and the packet does not see the sign.
- **Booker 2019.** Booker's later paper [Bo2, §1] treats Maass forms of icosahedral type. It assumes that both π and its √5-conjugate are automorphic, and says that producing an Artin representation would need the expected cuspidality criterion for the symmetric sixth power.
- **Reformulation [T].** Suppose H1 holds for one quadratic field E, and let Π_ℚ be a descent. Then ρ is modular if and only if Π_ℚ corresponds to some Artin representation ρ′. Indeed, ρ′ then satisfies ρ′|G_E ≅ ρ|G_E, so ρ′ is ρ or ρ ⊗ ε_E.

### Question 2: non-normal quintic base change [L], [T]

- We know of no case for a π that is not already known to be of Galois type.
- **Conditionally:** automorphic induction from L₅ to GL(5), for all Hecke characters λ of L₅, gives H2 through the converse theorem over L₅. This is because L(s, BC(π) ⊗ λ) = L(s, π × AI(λ)).
- **What 𝟒 gives:** automorphy of 𝟒 alone covers only the twists by λ = μ∘N, for which AI(λ) = μ ⊞ μ𝟒. These do not suffice.

### Question 3: a lifting theorem for ρ|G_E in Hodge–Tate weights 0 [L], [T], [N]

We know of no such theorem. Three remarks:

- **The defect is not the obstruction by itself.** For a totally odd two-dimensional Artin representation of a totally real field of degree d, the defect is ℓ₀ = d. Modularity lifting in parallel weight one is nevertheless known there (Kassaei 2013; Kassaei–Sasaki–Tian 2014; Pilloni–Stroh 2016; Sasaki 2019). These proofs work on Hilbert modular varieties. For GL₂ over an imaginary quadratic field there is no Shimura variety, and Artin-type forms contribute to no cohomology of Bianchi groups.
- **The defect equals the order of vanishing.** r(ad⁰ρ) = 3 = ℓ₀. By Stark's conjecture, the leading term of L(s, ad⁰ρ) at s = 0 is the regulator of the rank-3 ad⁰ρ-part of the units of M, up to a factor in ℚ(√5). We checked this numerically for all six representations (below).
- **Anti-invariance for all six [T].** Leopoldt's conjecture holds for the field K₁₂ of each of the six conductors at ℓ = 2, 3, 5, 7: in all 24 cases the ℓ-adic logarithms of the 11 units have rank 11. Hence H¹(G_{ℚ,S}, ad⁰ρ ⊗ ℚ̄_ℓ) = 0, and for every imaginary quadratic field E the group Gal(E/ℚ) acts by −1 on the first-order deformations of ρ|G_E. The note had this for 1951 only. In three cases (1951 at ℓ = 5 and 7, 2141 at ℓ = 3) two of the twelve 11 × 11 minors vanish identically and the other ten are non-zero. The reason: the polynomial defining K₁₂ is even, two of its ℓ-adic factors have the form x² − δ, and the norm relation among the rows does not involve the two rows of their x-coordinates. (Corrected wording: the morning version attributed this to residue degree 2, but for 9461 at ℓ = 11, with all residue degrees 2 and an odd polynomial, no minor vanishes.)
- **Correction (afternoon of 20 October) [T].** The morning version of this README, and the note of 19 October, drew the further conclusion that "every first-order deformation of ρ|G_E has opposite weight changes at the two embeddings". That holds only for nearly ordinary deformations whose ordinary lines at v and v̄ correspond under Gal(E/ℚ). Proposition 9.1 of the note covers a split ℓ with ρ(Frob_ℓ) non-scalar:
  - with the base-change choice of lines, the nearly ordinary tangent space is 2-dimensional with weights (w, −w);
  - with lines for different Frobenius eigenvalues at v and v̄, it is 1-dimensional with parallel weights (w, w), w ≠ 0.

  So a parallel-weight Hida family through ρ|G_E is not excluded at first order. Its classical members would be Bianchi forms that are not base changes, which is the "even" exception that Calegari–Mazur allow for.

### Question 4: Klein curves [T]

**Lemma 8.1 [T].** Let L be a totally real quintic field of discriminant p⁴, with p > 5 prime. Then the trace-zero lattice of O_L with the trace form is isometric to p·A₄. The proof has five steps:

1. p is totally and tamely ramified in L.
2. [O_L : ℤ ⊕ Λ₀] = 5, so det Λ₀ = 5p⁴.
3. The local structure at p, where π⁵ = pu, shows that Λ₀ is divisible by p.
4. (1/p)Λ₀ is even.
5. Minkowski's second theorem, with γ₄⁴ = 4, forces the successive minima to be 2. The only rank-4 root lattice of determinant 5 is A₄.

For the six fields we also checked the isometry with `qfisom`. The lemma is the non-Galois analogue of Mantilla-Soler–Monsurrò's result for cyclic fields of prime degree.

**Corollary 8.2 [T].** A₄ ⊗ ℚ is isotropic over every ℚ_ℓ: its discriminant 5 is a non-square in ℚ₂, ℚ₃ and ℚ₅ and for ℓ ≡ ±2 (mod 5), and for ℓ ≡ ±1 (mod 5) it has unit coefficients. So Klein's quadric Tr y = Tr y² = 0 has points over every number field without real places. In particular, any imaginary quadratic irrationality √−d can serve as the accessory irrationality. `a4_pairs.py` exhibits explicit pairs u ⊥ v in A₄ with |u|² = d|v|², for every squarefree d ≤ 40 (`a4_pairs.log`).

**Theorem E [T].** We have curves for p ∈ {2141, 3701, 3821, 8501, 9461} with d = 1, 3, and for p = 1951 with d = 2. Each is an elliptic curve over ℚ(√5, √−d) with j = Klein's invariant, and for each:

- its 5-isogeny field equals K_d·K₆ (fibre irreducible, degree 24, `nfisincl`);
- the places with v(j) < 0 are as listed;
- decomposed-generic witnesses exist;
- a_P² ≡ N(P) t̄² (mod 5) at all degree-one primes P with N(P) < 3000.

So each curve is modular by Caraiani–Newton, as in Theorem C. With Theorem C itself (1951, d = 1, 3), this covers all six representations.

### Question 5: weight-one forms modulo 2 [T]

**Theorem F [T].** The cases are p ∈ {2141, 3701, 3821}, each in both S₂(Γ₀(p), χ) and S₂(Γ₀(p), χε_p); here p ≡ 5 (mod 8), so ε_p is even and the characters of order 4 are odd. In each case:

- the predicted forms G_x and G_y lie in S̄;
- the other labelling of the classes of order 5, and shuffled traces, do not;
- the joint eigenspace of T₃, T₅, T₇ is 2-dimensional, and becomes 1-dimensional with T₂;
- the generalised eigenspaces have dimensions 3 and 3 (for 1951 they are 3 and 6);
- the odd coefficients of G_x and G_y agree up to N_B > p + 1.

The two spaces give the same G_x and G_y. Both are Katz forms with diamond character χ̄, and a Sturm argument on X₁(p) applies, with bound (p + 1)/6. So the weight-one Katz form g₁⁽ᵖ⁾ exists, and it does not lift, by parity.

For 8501 and 9461 the spaces have dimensions 707/708 and 787/788. PARI's `mfinit` at level 8501 exceeded the 8 GB of the machine: the run was killed by the system, and `mod2_p8501_eps0.log` holds only the stack warning. This is a hold, not a result. 9461 was not attempted.

### Stark's conjecture in rank 3 [N]

For the two three-dimensional representations V and V′ of A₅ (ad⁰ρ₀ and ad⁰ρ₀″), and all six conductors:

- A(V, f) = R(V, f)/c(V) agrees with an element a + b√5 of ℤ[φ], and A(V′, f) with a − b√5, to 10⁻⁴³ or better;
- this holds for 15 to 44 non-degenerate choices of f per conductor;
- c is the leading coefficient of L(s, V) at s = 0, at 57 digits;
- the functional equations hold to 2⁻¹⁸³ or better.

Tate's theorem for rational characters covers only the product A(V, f)A(V′, f). The values have norms ±16 and ±64 when h(K₁₂) = 1, and also ±4 and ±20 for p = 3701 (h = 2) and 3821 (h = 4). We do not interpret this pattern.

For 1951, `stark_general.py`, with classes from `classes.py` and 240000 coefficients, reproduces `stark_ad.py`, with the trace table of the note and 400000 coefficients. The c-values are identical to 57 digits, and the 28 values (a, b) are the same. Over the 21218 primes < 240000 compared, the class codes of `classes.py` and of the trace table agree (0 mismatches).

## Map from statements to files

| Statement | Script | Output |
|---|---|---|
| The six Doud–Moore polynomials | `fields6.py` | `fields6.json` |
| Frobenius classes in A₅ (5A/5B by Dokchitser resolvents) | `classes.py p NB` | `classes_<p>.json`, `classes_<p>_<NB>.log` |
| Lemma 8.1 (computational check), Klein invariants (Cor. 8.2, Theorem E) | `klein_general.py p d DPS` | `klein_p<p>_d<d>.json/.log` |
| Theorem E (i)–(iii) certificates | `klein_certify.py p d 3000` | `klein_certify_p<p>_d<d>.json/.log` |
| Chains | `run_klein_chain.sh "p1 p2" DPS` | — |
| Theorem F, Table 3 | `mod2_general.py p NB eps` (uses `f16.py`) | `mod2_p<p>_eps<e>.json/.log` |
| K₁₂ and its units (bnfinit, GRH-conditional; the Stark check does not need fundamental units) | `k12_general.py p` | `k12_p<p>.json`, `k12_units_p<p>.gp`, `k12_p<p>.log` |
| Remark 8.4 [N], Table 4 | `stark_general.py p 57 NB`; chain `run_stark_chain.sh p NB` | `stark_ad_p<p>_prec57.json`, `stark_p<p>_57.log`, cache `stark_cvals_p<p>_prec57.json` |
| Remark 8.4 cross-check for 1951 with the trace table of the note | `stark_ad.py` (reads `bianchi/chunks`, not shipped; see the top-level README) | `stark_ad_prec57.json`, `stark_cvals_prec57.json` (its log was not kept) |
| Explicit A₄ pairs for squarefree d ≤ 40 | `a4_pairs.py` | `a4_pairs.log` |
| Question 3: Leopoldt for K₁₂ at ℓ = 2, 3, 5, 7, all six conductors | `k12_leopoldt_general.py p ℓ 400` (chain: `run_leopoldt.sh "p1 p2 ..."`) | `leopoldt_p<p>_ell<ℓ>.json/.log` |
| Direction 3: Leopoldt for K₁₂ at ℓ = 11, 31, 41, 61, 71, all six conductors | `k12_leopoldt_general.py p ℓ 300` (chain: `run_leopoldt_aux.sh "p1 p2 ..."`) | `leopoldt_p<p>_ell<ℓ>.json/.log` |
| Summary and tables | `summarize_questions.py` | `questions_summary.json`, `questions_tables.md` |
| §8 of the note (tables filled from the summary) | `make_note_section8.py` | `note_section8.tex` |

All exact statements of §8 are also checked by `note/check_note_claims.py` (14 new checks; the Stark check is [N]). One of them recomputes, from the exact j, the first decomposed-generic witness and the places with v(j) < 0 for each of the eleven new curves.

## Notes

- **Recognition residuals.** The field `log10_worst_residual` in `klein_p*_d*.json` reads 0 because of an initialisation bug, which is now fixed in the script. The actual residuals are in the logs (10⁻⁵⁹⁵ at 600 digits, 10⁻⁶⁸⁵ to 10⁻⁶⁹⁵ at 700 digits). Theorem E does not depend on the recognition step: the certificates concern the exact values.
- **The 5A/5B labelling.** For each p, Theorem F fixes which class of 5-cycles carries |t| = φ − 1 for ρ₀, because only one labelling occurs in S̄. This fixes ρ₀ against ρ₀″, as Theorem D does for 1951. Theorem E and Remark 8.4 do not depend on the labelling.
- **Commands.** The scripts read and write files in the current directory; run them from this folder. `stark_ad.py` uses absolute paths, which `relocate.sh` rewrites.

## The four directions of the relayed list (afternoon of 20 October)

### 1. The Maass form over ℚ, independently of Hejhal's method [N]

A computation gives evidence, not a proof: an exact cusp form with these Hecke eigenvalues is the modularity of ρ.
- **Rigorous trace-formula computations [L].** They exist for squarefree level up to 105 with trivial character, with completeness proved for prime levels up to 67 (Seymour-Howell, ANTS XV, arXiv:2201.08760; Lowry-Duda's database, arXiv:2502.01442). They certify eigenvalues and Hecke eigenvalues in small intervals. An interval cannot show that the eigenvalue is exactly 1/4, or that the Hecke eigenvalues are exactly the traces of ρ.
- **Level 1951 [S].** With a character of order 5, this is far outside that range. Weyl's law for a subgroup of index 1952 puts the nearest other spectral parameters about 0.1 from r = 0.
- **"Higher rank."** GL₂ over ℚ has real rank one, so a "higher-rank" trace formula does not apply.

What we did (`maassq/`): build F(z) = √y Σ a_n K₀(2πny) sin(2πnx) from the trace table alone, with no linear solve, and test it on Γ₀(1951) at 24 random γ.
- **Invariance:** ρ with nebentypus χ to 1.7·10⁻¹⁰; ρ″ = ρ₀″ ⊗ χ with nebentypus χ² to 1.1·10⁻¹⁰.
- **Controls:** wrong nebentypus, the even (cosine) series and shifted traces all give defects of order 1.
- **Eigenvalue:** with K_{ir} in place of K₀, the values of r² that would cancel the defects to first order are below 4·10⁻¹¹.

### 2. Galois representations for torsion classes and the eigenvariety [L]

Galois representations for torsion classes in the cohomology of Bianchi manifolds exist (Scholze, Ann. of Math. 2015). Local–global compatibility is known in many cases (Allen–Calegari–Caraiani–Gee–Helm–Le Hung–Newton–Scholze–Taylor–Thorne, Ann. of Math. 2023). That is not the missing step. The Artin point has weight (1, 1), outside the cohomological range: Maass forms on hyperbolic 3-space with eigenvalue 1 contribute to no cohomology of Bianchi groups. No known classicality theorem applies at that weight.

### 3. Ordinary lifting at an auxiliary prime [T]

- **The auxiliary prime ℓ ≡ 1 (mod 5) has no residual input.** There the residual representation is even over ℚ and is not known to be modular over E, so there is no Hida family to compare with. The residual input over E exists at ℓ = 2, and at ℓ = 5 only over the fields K_d of Theorem E.
- **Proposition 9.1 of the note.** Assume ℓ splits in E, ρ(Frob_ℓ) is not scalar, and H¹(G_ℚ, ad⁰ρ ⊗ ℚ̄_ℓ) = 0. Then:
  - H¹(G_E, ad⁰ρ) is 3-dimensional, and it maps isomorphically onto the local inertial classes at v.
  - With the base-change choice of ordinary lines, the nearly ordinary tangent space is 2-dimensional with weights (w, −w).
  - With the other choice, it is 1-dimensional with weights (w, w), w ≠ 0.
- **Where it applies [T].** The condition H¹ = 0 follows from Leopoldt for K₁₂ at ℓ. For all six representations it holds at ℓ = 2, 3, 5, 7 (Question 3 above). It also holds at the five primes ℓ ≡ 1 (mod 5) below 100, namely ℓ = 11, 31, 41, 61, 71: 30 more cases, all of rank 11 (`run_leopoldt_aux.sh`, `leopoldt_p<p>_ell<ℓ>.json`). Two minors vanish for 1951 and 3821 at ℓ = 71, for the reason given above. For example, 11 and 71 split in ℚ(√−7), and Frob₁₁ and Frob₇₁ are not central for any of the six representations (`classes_<p>.json`). So the proposition applies to E = ℚ(√−7) at both primes.
- **Consequence.** This corrects the rigidity statement of 19 October (see Question 3 above). At ℓ = 2 and E ∈ F₇, the residual input for the parallel case would be a mod-2 Bianchi eigenclass of level 1951·O_E for ρ̄₂|G_E, with Hecke eigenvalues x at v and y at v̄. Base change gives only (x, x) and (y, y). Computed on the evening of 21 October for E = ℚ(√−7); see the next item but one.
- **Models of the mixed class (21 October) [T].** Over E = ℚ(√−7), `bianchi2/` computes H¹(Γ₀(N O_E), F₂) for PGL₂(O_E), with Hecke operators (presentation of Finis–Grunewald–Tirao).
  - **Validation:** LMFDB's SL(2) dimensions, and the base changes of 11a1 and 14a1.
  - **Models:** the mod-2 representations of the weight-2 newforms of level N = 23, 31, 47, 79. These are dihedral, unramified at 2, with x ≠ y, and both refinements occur over ℚ.
  - **Result:** in all four, the ρ̄-part contains eigenclasses with (T_v, T_v̄) = (x, y) and (y, x), besides (x, x) and (y, y), each checked at 6–9 further primes.
  - **Torsion:** for N = 23, 31, 47 the characteristic-0 cohomology at that level is the base change only, so the mixed classes are torsion classes (2-power torsion; at 23 of order at least 4). Since 26 October this covers every nebentypus of 2-power order; see the last item.
  - **Scope:** the searches (`find_models2.py`: trivial character, odd squarefree N ≤ 400; `find_models3.py`: odd N ≤ 150 and the levels 7N′ ≤ 217 relevant over E, with every nebentypus whose odd part has order dividing 15, which includes the twist-minimal icosahedral case) found only dihedral and reducible models. So for ρ̄₂ this is evidence, not a computation of the class itself. See `bianchi2/README.md`, including why PSL₂(O_E) must not be used here.
- **The two directions relayed on 21 October (afternoon).**
  - **(a) Residual filter [T].** For dihedral ρ̄ the available filter is the Frobenius trace at more primes; there is no quintic, so the cycle-type conditions of the Doud–Moore fields do not apply. The mixed vectors for N = 23, 31, 47 are eigenvectors with the eigenvalue of ρ̄ at every split prime of norm ≤ 200: 38, 40 and 40 primes, no failure (`bianchi2/extend_checks_N*.log`).
  - **(b) An icosahedral model within reach: none.** Icosahedral mod-2 systems occur at small levels (25, 31, 33, 43, 67, 73, 75, 77, 91, 93 and 12 levels between 99 and 217), but none has a companion, so only one refinement occurs. The smallest icosahedral weight-one newform has level 633 (Buzzard–Lauder; LMFDB 633.1.m.b). Mod 2 it is a model of the type of ρ̄₂: nebentypus of order 5 and Frob₂ of projective order 5 (`bianchi2/check_633.log`). Its index over ℚ(√−7) is 449 440, beyond the dense method (computed in the evening with the sparse engines; see the next item). A different Euclidean field is not available: ℚ(√−7) is the only imaginary quadratic field of class number 1 in which 2 splits.
  - **Control [T].** The icosahedral system of level 31 with nebentypus of order 5 is ramified at 2. Over E it was computed at level 31·O_E: 31 is inert, as 1951 is; the index is 962; the coefficients are F₁₆ and the nebentypus has order 5, as for 1951. Its ρ̄-part is 1-dimensional with only (T_v, T_v̄) = (a₂, a₂). The only off-diagonal pairs in H¹ there are two Eisenstein classes (`bianchi2/control_A5_31_s*.log`). So mixed classes appear in the models, where ρ̄ is unramified at 2 with x ≠ y, and not in the control, where the refinement at v is forced.
- **The class at level 1951·O_E (21 October, evening) [T].** This continues the step named at the end of the previous reply: an iterative solver over F₁₆, tested on the 633 model and then run at 1951.
  - **Engines.** `bianchi2/` now has three more engines for the same cohomology:
    - sparse elimination with a bitsliced dense core (`sparse_h1.py`);
    - block Lanczos over F₁₆ (`lanczos16.py`), with a certificate that the kernel is complete;
    - a memory-lean pipeline (`sparse_big.py`, `run_big.py`).

    They agree with the dense engine and with each other (`bianchi2/validate_sparse.log`).
  - **New dihedral models.** At 87, 93, 103, 115, 127 and 143 the mixed refinements occur, with joint eigenvectors at 23–24 Hecke operators.
  - **The 633 model, computed four ways.** dim H¹(Γ₀(633·O_E), F₁₆) = 348 with nebentypus. The ρ̄-part has dimension 24, with (T_v, T_v̄) multiplicities (x,x) 8, (x,y) 4, (y,x) 4, (y,y) 8. Each contains exactly one joint eigenvector with the ρ̄ eigenvalues at all 23 operators.
  - **Level 1951·O_E** (index 3 806 402; F₁₆; nebentypus χ̄⁻¹∘N; eigenvalues of ρ̄₂ from the Galois side, as in Theorem D).
    - Core: 301 036 × 126 366. Block Lanczos with b = 768 finds a kernel of 664, equal to the Krylov bound, so the kernel is complete. Every cocycle satisfies all 30 451 216 relator equations.
    - **dim H¹ = 663.** The ρ̄₂-part has dimension 27, with (T_v, T_v̄) multiplicities (x,x) 7, **(x,y) 3, (y,x) 3**, (y,y) 14.
    - Each of the four contains exactly one eigenvector with the eigenvalues of ρ̄₂ at all 24 Hecke operators of the run. At 26 further operators they are again eigenvectors with those eigenvalues, so they have the eigenvalues of ρ̄₂ at every prime of E of norm ≤ 200, and at (17) and (19) (`bianchi2/extend_big_N1951.log`).
    - About 1 h 45 min, about 3 GB (`bianchi2/big_1951.log`, `big_N1951.json`).
    - A second, independent Lanczos run (another D and another start block) gives the same 664-dimensional kernel (`bianchi2/recheck_core_N1951.log`).
  - **Reading.**
    - [T] The mixed classes asked for in Question 3 exist at level 1951·O_E for E = ℚ(√−7), at least for the Hecke operators tested.
    - [C] That they lie in the system of ρ̄₂|G_E for all operators is supported by the eigenvalues, not proved.
    - Not known: whether they lift to characteristic 0, and whether case (iii) of the deformation argument can be started from them at ℓ = 2. The first question was answered on 26 October for the nebentypus of ρ; see the next item.
    - None of this proves the modularity of ρ|G_E or of ρ.
- **Lifting the mixed classes to characteristic 0 (26 October) [T].** This is the next step suggested by Grok: test the lift with a solver over a large prime field, or p-adically. Both were built (`bianchi2/README.md`, section "Lifting the mixed classes to characteristic 0").
  - **Which nebentypus.** F₁₆(χ̄⁻¹∘N) is the reduction of the modules with nebentypus (χ⁻¹∘N)ψ, for χ the Teichmüller lift and every character ψ of 2-power order of (O_E/1951)^× with ψ(−1) = 1. ψ = 1 is the nebentypus of ρ.
  - **Large prime.** `sparse_fp.py` computes the rank over F_P, which bounds the characteristic-0 rank. It is compared with the number of base changes.
    - At 1951, dim H¹(Γ₀(1951·O_E), F_P(χ⁻¹∘N)) ≤ 161 = dim S₂(Γ₀(1951), χ), with P = 1 048 361 and block Lanczos over F_P (Krylov bound, V_m = 0).
    - So in characteristic 0 this cohomology consists of the 161 base changes, and T_v = T_v̄ on it.
    - **The mixed classes do not lift to characteristic 0 with the nebentypus of ρ.** They come from 2-power torsion, of order at least 4, since they lift modulo 4.
    - The ρ̄₂-part in characteristic 0 is the base change of the nine newforms of Theorem D(iii).
  - **633 model.** With the Teichmüller lift of the nebentypus, the rank is 68 = base change, for two primes: no lift.
  - **Small levels 23, 31, 47.** No lift for any nebentypus of 2-power order.
  - **p-adic.** The first-order obstruction is lifting modulo 4, or modulo ϖ² for ψ of order ≥ 4. It is validated against 2-adic Smith forms at 23 and 31. For the four eigenvectors at 1951 and 633 it vanishes for every ψ, so it decides nothing there.
  - **Open.** Lifts with a twisted nebentypus at 1951:
    - the quadratic twist (·/1951)∘N, with 649 base changes (a run over F_P was started);
    - twists of order 4 to 32.
    Also open: whether case (iii) of the deformation argument can be started at ℓ = 2. With the nebentypus of ρ, these classes do not provide characteristic-0 points at level 1951·O_E.
  - None of this proves the modularity of ρ|G_E or of ρ.

### 4. H1 over ℚ(√2), the real field of the three-field variant [N]

Computing the space of Hilbert–Maass forms of level 1951·O_F is beyond this machine. Instead, `hilbert/hilbert_r2.py` builds the Galois series of ρ|G_F on ℍ × ℍ and tests it on Γ₀(1951 O_F) with nebentypus χ(N d), as was done for the five imaginary quadratic fields. The series is

f(z₁, z₂) = Σ_{α ∈ ℤ[√2], α ≠ 0} c((α)) sgn(N α) √(y₁y₂) K₀(2π|α₁|y₁/2√2) K₀(2π|α₂|y₂/2√2) e((α₁x₁ − α₂x₂)/2√2).

The factor sgn(Nα) appears because ρ(c) = −I at both real places.

**Results [N].** The run used C = 3, 6 random γ and 4.7·10⁸ terms, at points of height about 1/1951 in both factors (`hilbert/README.md` has the full table).
- **ρ:** the largest relative defect is 5.6·10⁻⁹.
- **a₂ changed by 10⁻³:** defects from 1.9·10⁻³ to 1.8·10⁻².
- **Other controls:** the other signs at the real places, the √5-conjugate traces and the conjugate nebentypus give at least 1.6.
- **Pilot at C = 1:** limited by truncation (1.2·10⁻³).

So the Galois series passes over all three fields of the variant, ℚ(i), ℚ(√−2) and ℚ(√2). It is a consistency check: the modularity of ρ would give H1 over ℚ(√2) by base change. Over ℚ(√2), ρ is totally even, so H1 there is a problem of the same kind as the modularity of ρ itself.
