"""Orthogonal pairs u, v in A4 = {x in Z^5: sum x = 0} with |u|^2 = d |v|^2, for every squarefree d <= 40
(Corollary 8.2 proves existence for every d > 0 by Hasse-Minkowski; this only exhibits vectors).
Author: Dula."""
import itertools
def search(d, R=9, NV=12):
    vs = [v for v in itertools.product(range(-3, 4), repeat=4)]
    cands_v = []
    for x in vs:
        v = x + (-sum(x),)
        n = sum(t * t for t in v)
        if 0 < n <= NV: cands_v.append((n, v))
    cands_v.sort()
    for nv, v in cands_v:
        target = d * nv
        for x in itertools.product(range(-R, R + 1), repeat=4):
            u = x + (-sum(x),)
            if sum(t * t for t in u) == target and sum(a * b for a, b in zip(u, v)) == 0:
                return u, v, target, nv
    return None
for d in [d for d in range(1, 41) if all(d % (q * q) for q in range(2, 7))]:
    print(d, search(d), flush=True)
