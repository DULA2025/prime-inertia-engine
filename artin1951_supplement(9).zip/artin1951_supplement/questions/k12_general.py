"""K12 = fixed field of C5 = <(01234)> (sorted polroots labelling) in the A5 closure of f5, for conductor p; units.
Usage: python3 k12_general.py p  ->  k12_p<p>.json (P, polredabs Q, map a, cosets, theta) and k12_units_p<p>.gp.
Author: Dula."""
import sys, itertools, json, time, cypari2
pari = cypari2.Pari(); pari.allocatemem(6 * 10**9); pari("default(realprecision, 300)")
p = int(sys.argv[1]); fstr = json.load(open("fields6.json"))[str(p)]["poly"]
R = pari("vecsort(real(polroots(%s)))" % fstr); xs = [R[i] for i in range(5)]
def sign(g): return (-1) ** sum(1 for i in range(5) for j in range(i + 1, 5) if g[i] > g[j])
A5 = [g for g in itertools.permutations(range(5)) if sign(g) == 1]
def theta(g): return sum(xs[g[i]] ** 2 * xs[g[(i + 1) % 5]] for i in range(5))
vals, cos = [], []
for g in A5:
    t = theta(g)
    for k, v in enumerate(vals):
        if abs(v - t) < pari("1e-150"): cos[k].append(g); break
    else: vals.append(t); cos.append([g])
assert len(vals) == 12 and all(len(c) == 5 for c in cos)
P = pari(1)
for v in vals: P *= pari("x") - v
P = pari.round(pari.real(P))
nf = pari.nfinit(P); assert int(pari.polsturm(P)) == 12
print("p = %d: K12 field discriminant %s" % (p, pari.factor(nf[2])), flush=True)
red = pari.polredabs(P, 1); Q, a = red[0], red[1]
print("polredabs:", Q, flush=True)
t0 = time.time()
pari("bnf = bnfinit(%s, 1);" % Q)
print("bnfinit %.0fs: class group %s, regulator %s" % (time.time() - t0, pari("bnf.cyc"), pari("bnf.reg")), flush=True)
pari("write(\"k12_units_p%d.gp\", [bnf.pol, %s, apply(u -> lift(u), bnf.fu)])" % (p, a))
json.dump({"p": p, "P": str(P), "Q": str(Q), "a": str(a), "cosets": [[list(g) for g in c] for c in cos],
           "theta": [str(v) for v in vals], "h": str(pari("bnf.cyc")), "R": str(pari("bnf.reg"))}, open("k12_p%d.json" % p, "w"))
