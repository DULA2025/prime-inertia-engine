"""H1 for E = Q(sqrt(-7)), seen numerically: is the Galois series Pi of rho|G_E invariant under Gamma_0(1951 O_E)?

For gamma = (a b; c d) in SL2(O_E) with c in 1951 O_E, test Pi(gamma P) = nu(d) Pi(P), nu(d) = chi(N d) or its conjugate,
at points P = z + r j with z = -d/c + delta, |delta| ~ 0.2..0.5/|c|, r ~ 0.8..1.1/|c|, so both P and gamma P sit at
height ~ 1/|c| ~ 5e-4.  Variants of the coefficients (controls) are summed in the same pass.
Usage: python3 run_h1.py X [npairs] [seed]
"""
import sys, json, time, math, numpy as np
from scipy.special import k0
from bianchi import (sieve_spf, load_codes, row_coeffs, DL5, T_OF_CODE, Z5, SQ7, OMEGA, chi, N0)

X = int(float(sys.argv[1])) if len(sys.argv) > 1 else 10**7
NPAIRS = int(sys.argv[2]) if len(sys.argv) > 2 else 8
SEED = int(sys.argv[3]) if len(sys.argv) > 3 else 1
A1951 = Z5[2]

# ---------- exact arithmetic in O_E = Z[w], w^2 = w - 2 ----------
def mul(u, v): a, b = u; c, d = v; return (a * c - 2 * b * d, a * d + b * c + b * d)
def add(u, v): return (u[0] + v[0], u[1] + v[1])
def sub(u, v): return (u[0] - v[0], u[1] - v[1])
def norm(u): a, b = u; return a * a + a * b + 2 * b * b
def conj(u): a, b = u; return (a + b, -b)
def cval(u): return u[0] + u[1] * OMEGA
def divmod_e(u, v):
    num = mul(u, conj(v)); n = norm(v)
    best = None
    for qa in (math.floor(num[0] / n), math.ceil(num[0] / n)):
        for qb in (math.floor(num[1] / n), math.ceil(num[1] / n)):
            r = sub(u, mul((qa, qb), v))
            if best is None or norm(r) < norm(best[1]): best = ((qa, qb), r)
    assert norm(best[1]) < norm(v)
    return best
def xgcd(u, v):
    """returns (g, s, t) with s u + t v = g"""
    s0, s1, t0, t1 = (1, 0), (0, 0), (0, 0), (1, 0)
    while v != (0, 0):
        q, r = divmod_e(u, v)
        u, v = v, r
        s0, s1 = s1, sub(s0, mul(q, s1))
        t0, t1 = t1, sub(t0, mul(q, t1))
    return u, s0, t0
UNITS = [(1, 0), (-1, 0)]

def make_gamma(c0, d):
    c = mul((N0, 0), c0)
    g, s, t = xgcd(d, c)                       # s d + t c = g, g a unit
    assert norm(g) == 1, (g, d, c)
    ginv = (1, 0) if g == (1, 0) else (-1, 0)
    a, b = mul(s, ginv), mul(mul(t, ginv), (-1, 0))   # a d - b c = 1
    assert sub(mul(a, d), mul(b, c)) == (1, 0)
    return a, b, c, d

def act(g, z, r):
    a, b, c, d = (cval(u) for u in g)
    cz_d = c * z + d
    D = abs(cz_d) ** 2 + abs(c) ** 2 * r * r
    zz = ((a * z + b) * np.conj(cz_d) + a * np.conj(c) * r * r) / D
    return zz, r / D

rng = np.random.default_rng(SEED)
C0S = [(1, 0)]          # |c| = 1951, the largest common height for P and gamma P
pairs = []
while len(pairs) < NPAIRS:
    c0 = C0S[len(pairs) % len(C0S)]
    d = (int(rng.integers(-N0, N0)), int(rng.integers(-N0, N0)))
    if norm(d) % N0 == 0: continue
    g, _, _ = xgcd(d, mul((N0, 0), c0))
    if norm(g) != 1: continue
    gam = make_gamma(c0, d)
    cc = cval(gam[2])
    k1, k2 = rng.uniform(0.1, 0.3), rng.uniform(0.9, 1.05)
    z = -cval(d) / cc + k1 / abs(cc) * np.exp(2j * np.pi * rng.uniform())
    r = k2 / abs(cc)
    z2, r2 = act(gam, z, r)
    nd = norm(d) % N0
    pairs.append(dict(c0=c0, d=d, gam=gam, P=(z, r), Q=(z2, r2), nu=chi(nd)))
pts = []
for pr in pairs: pts += [pr["P"], pr["Q"]]
zs = np.array([p[0] for p in pts]); rs = np.array([p[1] for p in pts])
print("X = %.2e, %d pairs, heights %.2e .. %.2e" % (X, len(pairs), rs.min(), rs.max()), flush=True)

# ---------- the sum ----------
t0 = time.time()
spf = sieve_spf(X)
code = load_codes(X)
print("sieve + codes: %.0fs" % (time.time() - t0), flush=True)
VARIANTS = [("rho (Galois traces)", -1, 0, 0.0, A1951, 1),
            ("control: a_2 + 1e-3", -1, 2, 1e-3, A1951, 1),
            ("control: a_1951 = 1 instead of zeta5^2", -1, 0, 0.0, 1.0 + 0j, 1),
            ("control: sqrt5-conjugate traces (rho'' x chi^3)", 0, 0, 0.0, A1951, 1),
            ("control: chi^3 twist dropped (rho0 traces)", -1, 0, 0.0, A1951, 0)]
nv = len(VARIANTS)
X1 = X // 4
S = np.zeros((nv, len(pts)), dtype=np.complex128)     # full sum, N(nu) <= X
S1 = np.zeros((nv, len(pts)), dtype=np.complex128)    # partial sum, N(nu) <= X/4 (convergence check)
ymax = int(math.isqrt(4 * X // 7)) + 1
fac = 4 * np.pi / SQ7
t0 = time.time()
for y in range(0, ymax + 1):
    disc = 4 * X - 7 * y * y
    if disc < 0: break
    s = math.isqrt(disc)
    lo, hi = (-y - s) // 2 - 1, (-y + s) // 2 + 1
    xs = np.arange(lo, hi + 1, dtype=np.int64)
    Nn = xs * xs + xs * y + 2 * y * y
    keep = (Nn <= X) & (Nn > 0)
    if y == 0: keep &= xs > 0
    xs, Nn = xs[keep], Nn[keep]
    if xs.size == 0: continue
    nu = xs + y * OMEGA
    absnu = np.abs(nu)
    W = 2 * rs[:, None] * k0(fac * absnu[None, :] * rs[:, None]) * np.cos(fac * (nu[None, :] * zs[:, None]).imag)
    m1 = Nn <= X1
    for v, (_, flip, pp, amt, a19, tw) in enumerate(VARIANTS):
        cvec = row_coeffs(y, xs, spf, code, DL5, T_OF_CODE, Z5, a19, flip, pp, amt, tw)
        S[v] += W @ cvec
        S1[v] += W[:, m1] @ cvec[m1]
    if y % 1000 == 0: print("  row %d / %d  (%.0fs)" % (y, ymax, time.time() - t0), flush=True)
print("sum done: %.0fs" % (time.time() - t0), flush=True)

res = {"X": X, "seed": SEED, "pairs": []}
for v, (name, *_r) in enumerate(VARIANTS):
    d_nu, d_cn, d_conv = [], [], []
    for i, pr in enumerate(pairs):
        fP, fQ = S[v, 2 * i], S[v, 2 * i + 1]
        d_nu.append(abs(fQ - pr["nu"] * fP) / abs(fP))
        d_cn.append(abs(fQ - np.conj(pr["nu"]) * fP) / abs(fP))
        d_conv.append(max(abs(S[v, 2 * i] - S1[v, 2 * i]), abs(S[v, 2 * i + 1] - S1[v, 2 * i + 1])) / abs(fP))
    print("%-48s max rel defect  nu(d)=chi(Nd): %.1e   conj: %.1e   |sum(X) - sum(X/4)|: %.1e"
          % (name, max(d_nu), max(d_cn), max(d_conv)))
    res[name] = dict(defect_nu=d_nu, defect_conj=d_cn, conv=d_conv)
for i, pr in enumerate(pairs):
    res["pairs"].append(dict(c0=pr["c0"], d=pr["d"], gamma=[list(u) for u in pr["gam"]],
                             P=[pr["P"][0].real, pr["P"][0].imag, pr["P"][1]], Q=[pr["Q"][0].real, pr["Q"][0].imag, pr["Q"][1]],
                             Pi_P=[S[0, 2 * i].real, S[0, 2 * i].imag], Pi_Q=[S[0, 2 * i + 1].real, S[0, 2 * i + 1].imag]))
json.dump(res, open("h1_X%.0e_s%d.json" % (X, SEED), "w"), indent=1)
