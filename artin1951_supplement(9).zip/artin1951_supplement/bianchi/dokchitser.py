"""5A/5B classes of Frobenius (Dokchitser resolvents) and of the inertia generator at 1951."""
import cypari2, itertools, json
pari = cypari2.Pari(); pari.allocatemem(4*10**9)
pari('default(realprecision, 400)')
fstr = 'x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344'
f = pari(fstr)
r = pari('real(polroots(%s))' % fstr)
r = [r[i] for i in range(5)]

def parity(p):
    s, seen = 0, set()
    for i in range(5):
        if i in seen: continue
        j, L = i, 0
        while j not in seen:
            seen.add(j); j = p[j]; L += 1
        s += L - 1
    return s % 2
A5 = [p for p in itertools.permutations(range(5)) if parity(p) == 0]
def comp(a, b): return tuple(a[b[i]] for i in range(5))      # (a o b)(i) = a(b(i))
def inv(a):
    q = [0]*5
    for i in range(5): q[a[i]] = i
    return tuple(q)
c0 = (1, 2, 3, 4, 0)                                            # i -> i+1
classA = sorted({comp(comp(g, c0), inv(g)) for g in A5})
fivecycles = [p for p in A5 if all(p[i] != i for i in range(5)) and len({p[p[p[p[0]]]]}) and
              all(pow_ok for pow_ok in [True])]
def is5cycle(p):
    j, L = 0, 0
    while True:
        j = p[j]; L += 1
        if j == 0: break
    return L == 5
five = [p for p in A5 if is5cycle(p)]
classB = sorted(set(five) - set(classA))
assert len(classA) == 12 and len(classB) == 12

def resolvent(h, cls):
    X = pari('X')
    P = pari(1)
    for s in cls:
        th = sum(h(r[i]) * r[s[i]] for i in range(5))
        P *= (X - th)
    co = [pari.polcoef(P, k, 'X') for k in range(13)]
    ro = [pari.round(c) for c in co]
    err = max(abs(c - q) for c, q in zip(co, ro))
    assert err < pari('1e-50'), err
    return [int(q) for q in ro]

hs = [lambda x: x**2 + 3*x + 1, lambda x: x**3 - 2*x + 5, lambda x: x**2 - 7]
hcoef = [[1, 3, 1], [1, 0, -2, 5], [1, 0, -7]]                 # highest degree first
GA = [resolvent(h, classA) for h in hs]
GB = [resolvent(h, classB) for h in hs]
json.dump({"GA": [[str(c) for c in g] for g in GA], "GB": [[str(c) for c in g] for g in GB],
           "hcoef": hcoef, "classA": classA, "classB": classB}, open("resolvents.json", "w"))
print("resolvents: max coefficient digits", max(len(str(abs(c))) for g in GA + GB for c in g))

# power sums of the roots (exact, Newton's identities)
coef = [int(pari.polcoef(f, k)) for k in range(6)]              # c0..c5
e = [1, -coef[4], coef[3], -coef[2], coef[1], -coef[0]]          # elementary symmetric
S = [5]
for k in range(1, 40):
    s = 0
    for i in range(1, min(k, 5) + 1):
        s += (-1) ** (i - 1) * e[i] * (S[k - i] if k - i > 0 else (k if i == k else 0))
    if k <= 5:
        s = sum((-1) ** (i - 1) * e[i] * S[k - i] for i in range(1, k)) + (-1) ** (k - 1) * k * e[k]
    else:
        s = sum((-1) ** (i - 1) * e[i] * S[k - i] for i in range(1, 6))
    S.append(s)
assert abs(S[1] - sum(r)) < 1e-100 and abs(S[3] - sum(z**3 for z in r)) < 1e-90

def polmulmod(a, b, p):   # polys as lists low->high, mod f and p
    res = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b):
                res[i + j] = (res[i + j] + x * y) % p
    for d in range(len(res) - 1, 4, -1):     # reduce x^d, f monic
        c = res[d]
        if c:
            for k in range(5):
                res[d - 5 + k] = (res[d - 5 + k] - c * coef[k]) % p
        res[d] = 0
    return (res + [0] * 5)[:5]
def xpow(n, p):
    result, base = [1, 0, 0, 0, 0], [0, 1, 0, 0, 0]
    while n:
        if n & 1: result = polmulmod(result, base, p)
        base = polmulmod(base, base, p); n >>= 1
    return result
def trace(z, p): return sum(z[k] * S[k] for k in range(5)) % p
def peval(g, v, p):
    acc = 0
    for c in reversed(g):   # g low->high: evaluate by Horner from high
        acc = (acc * v + c) % p
    return acc

def classify(p):
    xp = xpow(p, p)
    for hc, ga, gb in zip(hcoef, GA, GB):
        hpoly = list(reversed(hc)) + [0] * (5 - len(hc))
        v = trace(polmulmod(hpoly[:5] if len(hc) <= 5 else hpoly, xp, p), p)
        A, B = peval(ga, v, p) == 0, peval(gb, v, p) == 0
        if A != B:
            return "A" if A else "B"
    return None

if __name__ == "__main__":
    import sys
    P = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
    out, amb = {}, []
    for p in pari.primes([2, P]):
        p = int(p)
        if p in (2, 7, 71, 137, 1951): continue
        F = pari.factormod(f, p)
        if len(F[0]) == 1 and int(pari.poldegree(F[0][0])) == 5:
            c = classify(p)
            if c is None: amb.append(p)
            else: out[p] = c
    print("5-cycle primes < %d: %d  (A: %d, B: %d, ambiguous: %s)" %
          (P, len(out), sum(v == 'A' for v in out.values()), sum(v == 'B' for v in out.values()), amb))
    json.dump(out, open("class5_upto%d.json" % P, "w"))
