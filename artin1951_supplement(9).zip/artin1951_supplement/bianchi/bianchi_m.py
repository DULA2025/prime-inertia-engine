"""Galois series of rho|G_E on hyperbolic 3-space for E = Q(sqrt(-m)), m in {1, 2}: O_E = Z[sqrt(-m)], 2 ramified.

  Pi(z, r) = sum_{0 != nu in O_E} c((nu)) * r * K_0(4 pi |nu| r / sqrt|d|) * e(2 Im(nu z) / sqrt|d|),   |d| = 4m.

The different is (sqrt(d)) = (2 sqrt(-m)), principal; mu = nu / sqrt(d) runs over the inverse different, and
2 Im(nu z)/sqrt|d| = Tr(mu z).  The pairing (nu, beta) -> 2 Im(nu beta)/sqrt|d| is integral and unimodular on O_E.
N(x + y sqrt(-m)) = x^2 + m y^2.  Splitting for odd p != 1951: (-m/p) = +1 (Q(i): p = 1 mod 4; Q(sqrt-2): p = 1, 3 mod 8).
2 = P^2 is ramified: c(P^j) = h_j(a_2, chi(2)).  1951 is inert in both fields: c((1951)^j) = (a_1951^2)^j.
Split / inert odd primes as in bianchi_q.py.
"""
import numpy as np, numba as nb

@nb.njit(cache=True)
def _hseq(a, w, j):
    h0 = 1.0 + 0j
    if j == 0:
        return h0
    h1 = a
    for _ in range(j - 1):
        h0, h1 = h1, a * h1 - w * h0
    return h1

@nb.njit(cache=True)
def _gcd(a, b):
    while b:
        a, b = b, a % b
    return a

@nb.njit(cache=True)
def _splits(m, p):
    if m == 1:
        return p % 4 == 1
    r = p % 8
    return r == 1 or r == 3

@nb.njit(cache=True)
def row_coeffs_m(m, y, xs, spf, code, dl5, Tc, z5, a1951, flipcode, pert_p, pert_amt, twist):
    """c((x + y sqrt(-m))) for x in xs."""
    n = xs.shape[0]
    out = np.empty(n, dtype=np.complex128)
    for i in range(n):
        x = xs[i]
        N = x * x + m * y * y
        g = _gcd(abs(x), abs(y))
        c = 1.0 + 0j
        M = N
        while M > 1:
            p = spf[M]
            e = 0
            while M % p == 0:
                M //= p
                e += 1
            if p == 1951:
                c *= a1951 ** e
                continue
            dlp = dl5[p % 1951]
            chip = z5[(2 * dlp) % 5] if twist == 1 else 1.0 + 0j
            cd = code[p]
            if flipcode >= 0 and cd >= 5:
                if cd == 5:
                    cd = 6
                elif cd == 6:
                    cd = 5
                elif cd == 7:
                    cd = 8
                else:
                    cd = 7
            t = Tc[cd]
            ap = z5[dlp % 5] * t if twist == 1 else t + 0j
            if p == pert_p:
                ap = ap + pert_amt
            if p == 2:                                   # ramified
                c *= _hseq(ap, chip, e)
            elif _splits(m, p):                          # split
                kc = 0
                gg = g
                while gg % p == 0 and kc * 2 < e:
                    gg //= p
                    kc += 1
                c *= _hseq(ap, chip, e - kc) * _hseq(ap, chip, kc)
            else:                                        # inert: e even
                A2 = ap * ap - 2.0 * chip
                c *= _hseq(A2, chip * chip, e // 2)
        out[i] = c
    return out
