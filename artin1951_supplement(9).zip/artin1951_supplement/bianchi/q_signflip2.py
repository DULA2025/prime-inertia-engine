"""The sign problem of descent with TWO fields, Q(sqrt-7) and Q(sqrt-23), seen over Q.

Over E = Q(sqrt(-7)) the Galois series only uses c((p)) = a_p^2 - 2 chi(p) at primes p inert in E, so flipping the sign
of a_p at any set of inert primes gives the SAME function on hyperbolic 3-space (identical coefficients, not a numerical
statement).  Over Q the flipped series is a different function.  Test its invariance under Gamma_0(1951):
  F(z) = sqrt(y) sum_n a_n K_0(2 pi n y) sin(2 pi n x),   F(gamma z) = chi(d) F(z)   (as in maass/maass_shape.py)
at points with both z and gamma z at height ~ 1/1951.
"""
import json, os, numpy as np
from scipy.special import k0

B = "/home/claude/research/bianchi/"
PHI = (1 + 5 ** 0.5) / 2
T = np.array([2, -2, -1, 1, 0, PHI - 1, -PHI, 1 - PHI, PHI])
OLD = json.load(open("/mnt/user-data/outputs/galois1951/galois_traces_150000.json"))
N0, M = 1951, 40000
d = np.load(B + "chunks/codes_000.npz"); P = d["p"]; C = d["c"].astype(np.int64)
m = P <= M; P, C = P[m], C[m]
for i in np.where(C < 0)[0]:
    q = int(P[i])
    if q != N0: C[i] = [k for k in range(9) if abs(T[k] - OLD["t"][str(q)]) < 1e-9][0]
dl = np.full(N0, -1, dtype=np.int64); x = 1
for k in range(N0 - 1): dl[x] = k % 5; x = x * 3 % N0
z5 = np.exp(2j * np.pi * np.arange(5) / 5)
chi = lambda n: z5[(2 * dl[n % N0]) % 5]
A1951 = z5[2]

def series(flip):
    """flip: set of primes p where a_p -> -a_p."""
    ap = {}
    for q, c in zip(P.tolist(), C.tolist()):
        if q == N0: continue
        a = z5[dl[q % N0]] * T[c]
        ap[q] = -a if q in flip else a
    spf = np.zeros(M + 1, dtype=np.int64)
    for q in P.tolist():
        sl = spf[q::q]; sl[sl == 0] = q
    a = np.zeros(M + 1, dtype=complex); a[1] = 1
    for n in range(2, M + 1):
        q = spf[n]; r = n; e = 0
        while r % q == 0: r //= q; e += 1
        if r > 1: a[n] = a[q ** e] * a[r]; continue
        if q == N0: a[n] = A1951 ** e; continue
        h0, h1 = 1.0 + 0j, ap[q]
        for _ in range(e - 1): h0, h1 = h1, ap[q] * h1 - chi(q) * h0
        a[n] = h1
    return a

def F(a, z):
    xx, y = z.real, z.imag; n = np.arange(1, M + 1); keep = 2 * np.pi * n * y < 60
    n = n[keep]; return np.sqrt(y) * np.sum(a[1:][keep] * k0(2 * np.pi * n * y) * np.sin(2 * np.pi * n * xx))

rng = np.random.default_rng(7); tests = []
for _ in range(12):
    dd = int(rng.integers(2, N0 - 1)); aa = pow(dd, -1, N0); b = (aa * dd - 1) // N0
    z = complex(-dd / N0 + rng.uniform(-3e-4, 3e-4), 1 / N0 * rng.uniform(0.8, 1.25))
    tests.append((dd, z, (aa * z + b) / (N0 * z + dd)))
def defect(a): return max(abs(F(a, gz) - chi(dd) * F(a, z)) / abs(F(a, z)) for dd, z, gz in tests)

qr7 = {1, 2, 4}; qr23 = {x * x % 23 for x in range(1, 23)}
inert = [q for q in P.tolist() if q not in (2, 7, 23) and q % 7 not in qr7 and q % 23 not in qr23]   # inert in BOTH Q(sqrt-7) and Q(sqrt-23)
rng2 = np.random.default_rng(11)
half = set(q for q in inert if rng2.random() < 0.5)
print("primes < %d inert in both fields: %d of %d (density 1/4 expected); first: %s" % (M, len(inert), len(P), inert[:8]))
rows = [("rho (no flip)", set()),
        ("flip a_5 only (inert in both; a_5 = 0, so the flip is empty)", {5}),
        ("flip a_17 only (inert in both; a_17 = chi(17)^3 phi)", {17}),
        ("flip a_p at a random half of the primes inert in both", half),
        ("flip a_p at every prime inert in both fields", set(inert))]
out = {}
for name, fl in rows:
    dv = defect(series(fl)); out[name] = dv
    print("%-64s max rel defect under Gamma_0(1951): %.1e" % (name, dv), flush=True)
json.dump(out, open(B + "q_signflip2.json", "w"), indent=1)
