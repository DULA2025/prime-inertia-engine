"""Fast Frobenius classes of rho0 (SL(2,5) image) for many primes, inside PARI.

Class code per prime p (p not dividing disc(f5) or disc(K24)):
  order of rho0(Frob_p) from the distinct-degree pattern of K24 mod p (24 = |SL(2,5)/C5|):
    {1}->1, {2}->2 (= -I), {3}->3, {6}->6, {4}->4, {1,5}->5, {2,10}->10
  5A/5B for orders 5 and 10 by the Dokchitser resolvents of f5 (as in dokchitser.py).
Codes: 0 id (t=2), 1 -I (t=-2), 2 ord3 (t=-1), 3 ord6 (t=1), 4 ord4 (t=0),
       5 ord5 small (t=phi-1), 6 ord5 big (t=-phi), 7 ord10 small (t=1-phi), 8 ord10 big (t=phi).
"small" = Dokchitser class LOC['small_class'] (from local1951.json), as in galois_traces.py.
"""
import json, sys, time
import numpy as np
import cypari2
pari = cypari2.Pari()
pari.allocatemem(2 * 10**9)
pari.default("parisizemax", 4 * 10**9)

HERE = "/home/claude/research/bianchi/"
R = json.load(open(HERE + "resolvents.json"))
LOC = json.load(open(HERE + "local1951.json"))
SMALL = LOC["small_class"]
Q24 = open(HERE + "K24.txt").read().strip()

def gp_poly(coeffs, var="X"):
    n = len(coeffs) - 1   # coefficient lists in resolvents.json are low -> high? check below
    return coeffs

GA = [[int(c) for c in g] for g in R["GA"]]
GB = [[int(c) for c in g] for g in R["GB"]]
HC = R["hcoef"]          # highest degree first

def to_gp(cl):           # cl low -> high (as used by peval in dokchitser.py: reversed(g) is Horner from high)
    return "Pol([" + ",".join(str(c) for c in reversed(cl)) + "],'X)"

setup = """
fpol = x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344;

Q24 = %s;

H = [%s];

GA = [%s];

GB = [%s];

ordcode(p) = {
  my(D = factormodDDF(Q24, p), degs = vector(#D[,1], i, D[i,2]), s = Set(degs));
  if (s == [1], return(1)); if (s == [2], return(2)); if (s == [3], return(3));
  if (s == [6], return(6)); if (s == [4], return(4)); if (s == [1,5], return(5));
  if (s == [2,10], return(10)); return(-1);
}

cls5(p) = {
  my(fp = fpol * Mod(1,p), xp = lift(Mod(x*Mod(1,p), fp)^p));
  for (i = 1, 3,
    my(g = lift(Mod(subst(H[i], x, x) * xp, fp)), v = trace(Mod(g, fp)));
    v = v * Mod(1, p); my(a = (subst(GA[i], 'X, v) == 0), b = (subst(GB[i], 'X, v) == 0));
    if (a != b, return(if (a, 1, 2))));
  return(0);
}

frcode(p) = {
  my(o = ordcode(p), c);
  if (o == 1, return(0)); if (o == 2, return(1)); if (o == 3, return(2));
  if (o == 6, return(3)); if (o == 4, return(4));
  if (o == 5 || o == 10,
    c = cls5(p); if (c == 0, return(-2));
    my(small = (c == %d));
    if (o == 5, return(if (small, 5, 6)), return(if (small, 7, 8))));
  return(-1);
}

codes(a, b) = {
  my(L = List()); forprime(p = a, b, listput(L, [p, frcode(p)])); Vec(L);
}
""" % (Q24,
       ",".join("Pol([%s])" % ",".join(str(c) for c in hc) for hc in HC),
       ",".join(to_gp(g) for g in GA), ",".join(to_gp(g) for g in GB),
       1 if SMALL == "A" else 2)
for stmt in setup.strip().split("\n\n"):
    pari(" ".join(stmt.split("\n")))

BAD = {2, 3, 5, 7, 17, 71, 137, 139, 271, 1951, 40427}

def run(a, b):
    v = pari("codes(%d,%d)" % (a, b))
    ps = np.array([int(w[0]) for w in v], dtype=np.int64)
    cs = np.array([int(w[1]) for w in v], dtype=np.int8)
    return ps, cs

if __name__ == "__main__":
    a, b = int(sys.argv[1]), int(sys.argv[2])
    t0 = time.time()
    ps, cs = run(a, b)
    np.savez_compressed(HERE + "codes_%d_%d.npz" % (a, b), p=ps, c=cs)
    bad = np.isin(ps, list(BAD))
    print("primes %d..%d: %d, time %.1fs, unresolved (code<0, not bad): %d"
          % (a, b, len(ps), time.time() - t0, int(((cs < 0) & ~bad).sum())))
