"""Galois series of rho|G_E on hyperbolic 3-space for E = Q(sqrt(-q)), q = 3 mod 4 prime (the F7 family has q = 7 mod 8).

  Pi(z, r) = sum_{0 != nu in O_E} c((nu)) * r * K_0(4 pi |nu| r / sqrt q) * e(2 Im(nu z) / sqrt q)

O_E = Z[w], w = (1 + sqrt(-q))/2, w^2 = w - k, k = (q + 1)/4, N(x + y w) = x^2 + x y + k y^2.  The different is
(sqrt(-q)), principal, so mu = nu / sqrt(-q) runs over the inverse different and mu * different = (nu).
When the class number is > 1 this is the function on the principal component of the adelic quotient; it involves c
only on principal ideals.  Splitting: for odd p != q, (-q/p) = (p/q); 2 splits since -q = 1 mod 8.
Ideal coefficients as in bianchi.py (q = 7); 1951 must be inert in E (checked by the caller).
"""
import json, os, numpy as np, numba as nb
from bianchi import sieve_spf, load_codes, DL5, T_OF_CODE, Z5, chi, N0

@nb.njit(cache=True)
def _hseq(a, w, j):
    h0 = 1.0 + 0j
    if j == 0:
        return h0
    h1 = a
    for _ in range(j - 1):
        h0, h1 = h1, a * h1 - w * h0
    return h1

@nb.njit(cache=True)
def _gcd(a, b):
    while b:
        a, b = b, a % b
    return a

@nb.njit(cache=True)
def row_coeffs_q(q, k, qr, y, xs, spf, code, dl5, Tc, z5, a1951, flipcode, pert_p, pert_amt, twist):
    """c((x + y w)) for x in xs.  qr[r] = +1 if r is a nonzero square mod q, -1 if a non-square."""
    n = xs.shape[0]
    out = np.empty(n, dtype=np.complex128)
    for i in range(n):
        x = xs[i]
        N = x * x + x * y + k * y * y
        g = _gcd(abs(x), abs(y))
        c = 1.0 + 0j
        M = N
        while M > 1:
            p = spf[M]
            e = 0
            while M % p == 0:
                M //= p
                e += 1
            if p == 1951:
                c *= a1951 ** e
                continue
            dlp = dl5[p % 1951]
            chip = z5[(2 * dlp) % 5] if twist == 1 else 1.0 + 0j
            cd = code[p]
            if flipcode >= 0 and cd >= 5:
                if cd == 5:
                    cd = 6
                elif cd == 6:
                    cd = 5
                elif cd == 7:
                    cd = 8
                else:
                    cd = 7
            t = Tc[cd]
            ap = z5[dlp % 5] * t if twist == 1 else t + 0j
            if p == pert_p:
                ap = ap + pert_amt
            if p == q:                                   # ramified
                c *= _hseq(ap, chip, e)
            elif p == 2 or qr[p % q] == 1:               # split
                kc = 0
                gg = g
                while gg % p == 0 and kc * 2 < e:
                    gg //= p
                    kc += 1
                c *= _hseq(ap, chip, e - kc) * _hseq(ap, chip, kc)
            else:                                        # inert: e even
                A2 = ap * ap - 2.0 * chip
                c *= _hseq(A2, chip * chip, e // 2)
        out[i] = c
    return out

def qr_table(q):
    t = np.full(q, -1, dtype=np.int64); t[0] = 0
    for x in range(1, q): t[x * x % q] = 1
    return t
