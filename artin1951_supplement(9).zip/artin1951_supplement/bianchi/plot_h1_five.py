"""Dot plots of the Gamma_0(1951 O_E) defects for five imaginary quadratic fields (2 x 3 grid, last cell = key)."""
import json, sys
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

FILES = [("Q(sqrt-7), h = 1", "h1_X1e+08_s2.json"), ("Q(sqrt-23), h = 3", "h1q23_X3e+08_s4.json"),
         ("Q(sqrt-31), h = 3", "h1q31_X4e+08_s5.json"), ("Q(i), h = 1", "h1m1_X1e+08_s6.json"),
         ("Q(sqrt-2), h = 1", "h1m2_X2e+08_s7.json")]
KEYS = [("rho, nebentypus chi(N d)", "rho (Galois traces)", "defect_nu"),
        ("rho, conjugate nebentypus*", "rho (Galois traces)", "defect_conj"),
        ("a_2 + 1e-3", "control: a_2 + 1e-3", "defect_nu"),
        ("a_1951 = 1", "control: a_1951 = 1 instead of zeta5^2", "defect_nu"),
        ("sqrt5-conjugate traces", "control: sqrt5-conjugate traces (rho'' x chi^3)", "defect_nu"),
        ("chi^3 twist dropped", "control: chi^3 twist dropped (rho0 traces)", "defect_nu")]
COL = ["#2a78d6", "#6250d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]   # validated categorical slots
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3de"
fig, axes = plt.subplots(2, 3, figsize=(15, 8.2), sharex=True)
for k, (title, fn) in enumerate(FILES):
    ax = axes[k // 3][k % 3]; R = json.load(open(fn))
    for i, (lab, key, fld) in enumerate(KEYS):
        y = len(KEYS) - 1 - i
        ax.scatter(R[key][fld], [y] * len(R[key][fld]), s=36, color=COL[i], edgecolor="white", linewidth=1.1, zorder=3)
    tr = R["rho (Galois traces)"]["conv"]
    ax.axvspan(min(tr), max(tr), color=GRID, zorder=0)
    ax.set_xscale("log"); ax.set_xlim(1e-13, 1e2)
    ax.set_title("%s,  N(nu) <= %.1e" % (title, R["X"]), fontsize=10, color=INK)
    ax.grid(axis="x", color=GRID, lw=0.6); ax.set_axisbelow(True)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    for s in ("left", "bottom"): ax.spines[s].set_color(MUTED)
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.set_yticks(range(len(KEYS)))
    ax.set_yticklabels([kk[0] for kk in KEYS][::-1] if k % 3 == 0 else [], fontsize=9, color=INK)
    if k // 3 == 1 or k == 2: ax.set_xlabel("relative defect, 8 test pairs", fontsize=9, color=INK)
    if k == 2: ax.tick_params(labelbottom=True)
key = axes[1][2]; key.axis("off")
key.text(0.0, 0.95, "Galois series of rho|G_E on hyperbolic 3-space,\ntested under Gamma_0(1951 O_E).\n\n"
         "rho (blue) passes in every field;\nevery control fails by 10^3.8 or more.\n\n"
         "Grey band: size of the last 3/4 of the sum,\n|sum(X) - sum(X/4)|.\n\n"
         "* pairs with chi(N d) = 1 cannot tell the\ntwo nebentypes apart.\n\n"
         "H1 follows from the modularity of rho,\nso these are consistency checks.",
         va="top", ha="left", fontsize=9.5, color=INK, transform=key.transAxes)
plt.tight_layout(); plt.savefig("h1_five_fields.png", dpi=130); print("saved h1_five_fields.png")
