"""Summary of the characteristic-0 H1 tests over five imaginary quadratic fields (Dula, 19 Oct 2026).
For each field: largest relative defect of rho (nebentypus chi(N d)), smallest defect of any control over all pairs
(the conjugate-nebentypus control only on pairs with chi(N d) != 1, where it can fail), and the truncation size."""
import json, numpy as np
from bianchi import chi, N0
RUNS = [("Q(sqrt-7)", 1, "h1_X1e+08_s2.json", lambda d: d[0]**2 + d[0]*d[1] + 2*d[1]**2),
        ("Q(sqrt-23)", 3, "h1q23_X3e+08_s4.json", lambda d: d[0]**2 + d[0]*d[1] + 6*d[1]**2),
        ("Q(sqrt-31)", 3, "h1q31_X4e+08_s5.json", lambda d: d[0]**2 + d[0]*d[1] + 8*d[1]**2),
        ("Q(i)", 1, "h1m1_X1e+08_s6.json", lambda d: d[0]**2 + d[1]**2),
        ("Q(sqrt-2)", 1, "h1m2_X2e+08_s7.json", lambda d: d[0]**2 + 2*d[1]**2)]
out = []
for name, h, fn, nrm in RUNS:
    try: R = json.load(open(fn))
    except FileNotFoundError: print("%-11s (pending)" % name); continue
    nus = [chi(nrm(p["d"]) % N0) for p in R["pairs"]]
    nontriv = [abs(v - 1) > 1e-9 for v in nus]
    rho = R["rho (Galois traces)"]
    ctrl = [c for k, c in R.items() if k.startswith("control")]
    mins = [min(c["defect_nu"]) for c in ctrl]
    conj = [d for d, nt in zip(rho["defect_conj"], nontriv) if nt]
    smallest = min(mins + conj)
    gap = np.log10(smallest / max(rho["defect_nu"]))
    print("%-11s h=%d X=%.1e  rho max %.1e  smallest control %.1e  gap %.1f orders  truncation %.1e  (pairs with chi(Nd)=1: %d)"
          % (name, h, R["X"], max(rho["defect_nu"]), smallest, gap, max(rho["conv"]), nontriv.count(False)))
    out.append(dict(field=name, h=h, X=R["X"], rho_max=max(rho["defect_nu"]), smallest_control=smallest, gap=gap,
                    truncation=max(rho["conv"])))
json.dump(out, open("h1_summary.json", "w"), indent=1)
