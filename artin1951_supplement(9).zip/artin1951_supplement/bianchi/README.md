# H1 for E = ℚ(√−7), seen numerically: the Galois series of ρ|G_E on hyperbolic 3-space (Dula, 19 Oct 2026)

Labels: [T] theorem or exact identity, [N] numerical. This is evidence for hypothesis H1 of Theorem A′ in one field of
the family F₇ (q = 7). It is not a proof of H1, and H1 for one field does not give Artin for ρ
(note, Remark on Theorem A′, items (1) and (3)).

## The object
- E = ℚ(√−7), O_E = ℤ[ω], ω = (1+√−7)/2. 1951 is inert in E, so the conductor of ρ|G_E is 𝔭 = 1951·O_E,
  of norm 1951². 2 splits and 7 ramifies.
- The Galois series, a function of (z, r) ∈ ℂ × ℝ₊ (hyperbolic 3-space), summed over 0 ≠ ν ∈ O_E:
  Π(z, r) = Σ_ν c((ν)) · r K₀(4π|ν|r/√7) · e(Tr(νz/√−7)).
- Here c(𝔫) is the coefficient of N𝔫^{−s} in L(ρ|G_E, s), built from the Frobenius classes of all primes < 10⁸:
  - split p = 𝔮𝔮̄: c(𝔮) = a_p;
  - inert p: c((p)) = a_p² − 2χ(p);
  - c(√−7) = a₇;
  - c(𝔭) = a₁₉₅₁² = ζ₅⁴;
  - prime powers follow the Hecke recursion with central character χ∘N.
- [T] Each term is an exact eigenfunction of the Laplacian of hyperbolic 3-space with eigenvalue 1, which is spectral
  parameter 0, the Artin case. If H1 holds for E, Π is a Bianchi Maass cusp form for Γ₀(𝔭) with nebentypus χ(N d).

## The test (`run_h1.py`, `bianchi.py`)
- For γ = (a b; 1951 d) ∈ SL₂(O_E), compare Π(γP) with χ(N d)·Π(P) at P = z + rj.
- P is chosen so that P and γP both sit at height ≈ 1/1951: z = −d/1951 + δ, |δ| = 0.1–0.3/1951, r = 0.9–1.05/1951.
  The sum runs over all ν with N(ν) ≤ X.
- Controls, computed in the same pass:
  - a₂ perturbed by 10⁻³;
  - a₁₉₅₁ = 1 instead of ζ₅²;
  - the √5-conjugate traces (ρ″⊗χ³, conductor 1951²);
  - the χ³ twist dropped (ρ₀);
  - the conjugate nebentypus.

## Results (`h1_X1e8_s2.log`, `h1_X1e+08_s2.json`, `h1_X1e+08_s2.png`)
- Run: N(ν) ≤ 10⁸, about 1.2·10⁸ terms; 8 random γ with c = 1951; heights 4.8–5.4·10⁻⁴; 375 s.

| coefficients | max relative defect, nebentypus χ(N d) |
|---|---|
| **ρ (Galois traces)** | **2.9·10⁻¹⁰** (per pair 3.5·10⁻¹¹ … 2.9·10⁻¹⁰) |
| ρ with the conjugate nebentypus | 1.9 (the 2 pairs with χ(N d) = 1 pass, as they must) |
| a₂ + 10⁻³ | 9.3·10⁻³ |
| a₁₉₅₁ = 1 instead of ζ₅² | 4.9·10⁻⁵ |
| √5-conjugate traces (ρ″⊗χ³) | 3.6 |
| χ³ twist dropped (ρ₀) | 17 |

- [N] The Galois series of ρ|G_E is invariant under Γ₀(1951·O_E) with nebentypus χ(N d), to 10 digits.
  The partial sum up to X/4 differs from the full sum by up to 6·10⁻⁵, so the agreement is not a truncation artefact.
- Every control fails, including the local factor at the inert prime 1951.
- This shows the object H1 asks for over q = 7: a Bianchi Maass form of icosahedral Galois type, level 𝔭 of norm
  1951², Laplace eigenvalue 1 on hyperbolic 3-space. A quick literature search found no earlier computation of such a form.
- Why it is expected: if ρ is automorphic, H1 for E follows by quadratic base change. So the test checks consistency;
  it adds no logical strength toward Artin. Its value is that it shows the hypothesis of Theorem A′, in its first case,
  directly in data.

## The sign problem, made concrete (`q_signflip.py`)
- [T] Over E the series uses only c((p)) = a_p² − 2χ(p) at inert p. So flipping the sign of a_p at any set of
  primes inert in E gives exactly the same Π: identical coefficients, not a numerical coincidence.
- [N] Over ℚ the flipped series are different functions. Under Γ₀(1951), with the same test points as
  `../maass/maass_shape.py`, the maximum relative defect is:

  | series | max relative defect |
  |---|---|
  | ρ | 4.5·10⁻¹¹ |
  | a₃ flipped | 21 |
  | a₃, a₅, a₁₃ flipped | 4.2 |
  | a random half of the inert primes flipped | 5.0 |
  | all inert primes flipped (the twist by ε₋₇: a genuine representation, but even, of level 1951·49) | 6.4 |
  | control: a₂ flipped (2 splits) | 5.6 |

- So a passing H1 test over one field cannot tell ρ from series that fail over ℚ by factors 4–20.
  This is items (1) and (3) of the remark on Theorem A′, seen in data. H1 for one field makes Ad ρ automorphic;
  the sign of a_p at primes inert in every chosen field stays free. That is why Theorem A′ takes the whole family.

## Second and third fields: ℚ(√−23) and ℚ(√−31), class number 3 (`bianchi_q.py`, `run_h1q.py`)
- 1951 is inert in both fields (PARI: Kronecker symbol −1), so the level is again 𝔭 = 1951·O_E.
- Of the other fields an outside text proposed, ℚ(√−71) (h = 7) is inert, but in ℚ(√−47) 1951 **splits**.
- O_E = ℤ[ω], ω = (1+√−23)/2. The different (√−23) is principal, so the classical series on the principal component
  has the same shape as before, with √7 replaced by √23. It involves c only on principal ideals.
- Because O_E is not Euclidean, a = d⁻¹ mod 1951·O_E is computed as conj(d)·N(d)⁻¹.
- [T, exact] The generalised coefficient kernel reproduces the q = 7 coefficients exactly (58 908 values,
  difference 0).
- Precision. The dual lattice is finer by √(23/7), so the norm bound for 10 digits grows in proportion to q:
  about 3.3·10⁸ for q = 23 and 4.4·10⁸ for q = 31. The Frobenius class table was extended to 4.4·10⁸
  (`../traces/chunks/codes_000…043`, 0 unresolved).

| run | ρ, χ(N d) | conj. | a₂ + 10⁻³ | a₁₉₅₁ = 1 | √5-conj. | χ³ dropped | max over pairs of abs(sum(X) − sum(X/4))/abs(Π(P)) |
|---|---|---|---|---|---|---|---|
| q = 23 pilot, N(ν) ≤ 10⁸ | 9.6·10⁻⁶ | 1.9 | 1.9·10⁻² | 1.5·10⁻³ | 4.0 | 14 | 6.6·10⁻³ |
| q = 23, N(ν) ≤ 3.3·10⁸ (1878 s) | **9.6·10⁻¹⁰** | 1.9 | 2.2·10⁻² | 7.6·10⁻⁴ | 3.2 | 3.0 | 6.9·10⁻⁵ |
| q = 31, N(ν) ≤ 4.4·10⁸ (2645 s) | **2.4·10⁻⁹** | 1.9 | 3.6·10⁻³ | 9.1·10⁻⁴ | 2.3 | 18 | 2.4·10⁻⁵ |

## Two fields still leave a quarter of the signs free (`q_signflip2.py`)
- [T] A prime inert in both ℚ(√−7) and ℚ(√−23) enters both Bianchi series only through a_p² − 2χ(p).
  Below 4·10⁴ there are 1057 such primes out of 4203, close to the expected density ¼.
- [N] Over ℚ, flipping a₁₇ (17 is inert in both) breaks Γ₀(1951) by 3.9; flipping a random half of these primes gives 5.9,
  and all of them 3.7. ρ itself gives 4.5·10⁻¹¹.
- Flipping a₅ changes nothing: a₅ = 0, the case "tr ρ(Frob_p) = 0, the sign is irrelevant" in the proof of
  Theorem A′.
- With n fields, the primes inert in all of them have density 2⁻ⁿ, so no finite family closes the gap (Remark 3.6(1)).

- [N] H1 holds numerically for the first three fields of F₇: 2.9·10⁻¹⁰ (q = 7), 9.6·10⁻¹⁰ (q = 23), 2.4·10⁻⁹ (q = 31).
  Every control fails in every test pair. The worst-case gap is between ρ's largest defect and the smallest defect of
  any control: 4.1, 4.7 and 3.8 orders of magnitude. The closest control each time is the local factor at 1951 (a₁₉₅₁ = 1).
- `h1_fields.png` shows the three fields side by side. Scripts: `plot_h1_fields.py`, `q_signflip2.py/.log/.json`.
- An outside "pilot" (`h1_pilot_q23.py`, numpy only) is not a test of H1. Its class codes are random, it has no lattice
  over O_E and no group element, and its "defect" is fixed by its own 10⁻³ shift.

## Fourth and fifth fields: Q(i) and Q(√−2), 2 ramified (`bianchi_m.py`, `run_h1m.py`)
- Why these fields: by Theorem A″ / Remark 3.8(2) of the note (19 Oct 2026), H1 for Q(i), Q(√−2) and Q(√2) — all ramified
  only at 2 — already implies modularity. 1951 is inert in Q(i) and Q(√−2) (1951 ≡ 7 mod 8).
- O_E = Z[√−m]; the different is (√d_E) = (2√−m), so Π(z, r) = Σ c((ν)) r K₀(4π|ν|r/√|d|) e(2 Im(νz)/√|d|), |d| = 4m.
  The prime above 2 is ramified: c(𝔭₂ʲ) = h_j(a₂, χ(2)).
- [T, exact] The kernel agrees with PARI's ideal factorisation on 400 random ν per field (difference ≤ 1.3·10⁻¹⁵).

| run | ρ, χ(N d) | conj. | a₂ + 10⁻³ | a₁₉₅₁ = 1 | √5-conj. | χ³ dropped | max over pairs of abs(sum(X) − sum(X/4))/abs(Π(P)) |
|---|---|---|---|---|---|---|---|
| Q(i), N(ν) ≤ 10⁸ (2120 s) | **6.4·10⁻¹¹** | 1.9 | 5.3·10⁻³ | 1.6·10⁻⁵ | 6.6 | 11 | 5.9·10⁻⁷ |
| Q(√−2), N(ν) ≤ 2·10⁸ (2388 s) | **2.1·10⁻¹⁰** | 1.9 | 7.5·10⁻³ | 5.5·10⁻⁵ | 6.5 | 3.6 | 9.4·10⁻⁷ |

- [N] H1 holds numerically over five fields; worst-case gaps between ρ's largest defect and the smallest control defect:
  4.1 (q = 7), 4.7 (23), 3.8 (31), 4.9 (Q(i)), 3.8 (Q(√−2)) orders (`h1_summary.py` → `h1_summary.json`).
- `h1_five_fields.png` (`plot_h1_five.py`) shows all five.
