"""H1 for E = Q(sqrt(-m)), m = 1, 2 (O_E = Z[sqrt(-m)], 2 ramified): is the Galois series Pi of rho|G_E invariant
under Gamma_0(1951 O_E)?  Same design as run_h1q.py: gamma = (a b; 1951 d), P and gamma P at height ~ 1/1951,
controls in the same pass.  a = d^{-1} mod 1951 O_E is computed as conj(d) N(d)^{-1}.
Usage: python3 run_h1m.py m X [npairs] [seed]
"""
import sys, json, time, math, numpy as np
from scipy.special import k0
from bianchi import sieve_spf, load_codes, DL5, T_OF_CODE, Z5, chi, N0
from bianchi_m import row_coeffs_m

m = int(sys.argv[1]); X = int(float(sys.argv[2]))
NPAIRS = int(sys.argv[3]) if len(sys.argv) > 3 else 8
SEED = int(sys.argv[4]) if len(sys.argv) > 4 else 1
assert m in (1, 2)
D = 4 * m                                          # |disc E|
assert (m == 1 and N0 % 4 == 3) or (m == 2 and N0 % 8 in (5, 7)), "1951 must be inert in E"
SQ = D ** 0.5
OM = complex(0.0, m ** 0.5)                        # sqrt(-m)
A1951 = Z5[2]

def mul(u, v): a, b = u; c, d = v; return (a * c - m * b * d, a * d + b * c)
def norm(u): a, b = u; return a * a + m * b * b
def conj(u): a, b = u; return (a, -b)
def cval(u): return u[0] + u[1] * OM

def make_gamma(d):
    n = norm(d) % N0
    inv = pow(n, -1, N0)
    cd = conj(d)
    a = ((cd[0] * inv) % N0, (cd[1] * inv) % N0)
    ad = mul(a, d)
    assert (ad[0] - 1) % N0 == 0 and ad[1] % N0 == 0
    b = ((ad[0] - 1) // N0, ad[1] // N0)
    c = (N0, 0)
    assert mul(a, d)[0] - mul(b, c)[0] == 1 and mul(a, d)[1] - mul(b, c)[1] == 0
    return a, b, c, d

def act(g, z, r):
    a, b, c, d = (cval(u) for u in g)
    cz_d = c * z + d
    D = abs(cz_d) ** 2 + abs(c) ** 2 * r * r
    return ((a * z + b) * np.conj(cz_d) + a * np.conj(c) * r * r) / D, r / D

rng = np.random.default_rng(SEED)
pairs = []
while len(pairs) < NPAIRS:
    d = (int(rng.integers(-N0, N0)), int(rng.integers(-N0, N0)))
    if norm(d) % N0 == 0: continue
    gam = make_gamma(d)
    k1, k2 = rng.uniform(0.1, 0.3), rng.uniform(0.9, 1.05)
    z = -cval(d) / N0 + k1 / N0 * np.exp(2j * np.pi * rng.uniform())
    r = k2 / N0
    pairs.append(dict(d=d, gam=gam, P=(z, r), Q=act(gam, z, r), nu=chi(norm(d) % N0)))
pts = []
for pr in pairs: pts += [pr["P"], pr["Q"]]
zs = np.array([p[0] for p in pts]); rs = np.array([p[1] for p in pts])
print("m = %d, X = %.2e, %d pairs, heights %.2e .. %.2e" % (m, X, len(pairs), rs.min(), rs.max()), flush=True)

t0 = time.time()
spf = sieve_spf(X); code = load_codes(X)
print("sieve + codes: %.0fs" % (time.time() - t0), flush=True)
VARIANTS = [("rho (Galois traces)", -1, 0, 0.0, A1951, 1),
            ("control: a_2 + 1e-3", -1, 2, 1e-3, A1951, 1),
            ("control: a_1951 = 1 instead of zeta5^2", -1, 0, 0.0, 1.0 + 0j, 1),
            ("control: sqrt5-conjugate traces (rho'' x chi^3)", 0, 0, 0.0, A1951, 1),
            ("control: chi^3 twist dropped (rho0 traces)", -1, 0, 0.0, A1951, 0)]
nv = len(VARIANTS); X1 = X // 4
S = np.zeros((nv, len(pts)), dtype=np.complex128); S1 = np.zeros_like(S)
fac = 4 * np.pi / SQ
ymax = int(math.isqrt(X // m)) + 1
t0 = time.time()
for y in range(0, ymax + 1):
    rem = X - m * y * y
    if rem < 0: break
    s = math.isqrt(rem)
    xs = np.arange(-s - 1, s + 2, dtype=np.int64)
    Nn = xs * xs + m * y * y
    keep = (Nn <= X) & (Nn > 0)
    if y == 0: keep &= xs > 0
    xs, Nn = xs[keep], Nn[keep]
    if xs.size == 0: continue
    nu = xs + y * OM
    W = 2 * rs[:, None] * k0(fac * np.abs(nu)[None, :] * rs[:, None]) * np.cos(fac * (nu[None, :] * zs[:, None]).imag)
    m1 = Nn <= X1
    for v, (_, flip, pp, amt, a19, tw) in enumerate(VARIANTS):
        cvec = row_coeffs_m(m, y, xs, spf, code, DL5, T_OF_CODE, Z5, a19, flip, pp, amt, tw)
        S[v] += W @ cvec; S1[v] += W[:, m1] @ cvec[m1]
    if y % 1000 == 0: print("  row %d / %d  (%.0fs)" % (y, ymax, time.time() - t0), flush=True)
print("sum done: %.0fs" % (time.time() - t0), flush=True)

res = {"m": m, "disc": -D, "X": X, "seed": SEED, "pairs": []}
for v, (name, *_r) in enumerate(VARIANTS):
    d_nu, d_cn, d_conv = [], [], []
    for i, pr in enumerate(pairs):
        fP, fQ = S[v, 2 * i], S[v, 2 * i + 1]
        d_nu.append(abs(fQ - pr["nu"] * fP) / abs(fP)); d_cn.append(abs(fQ - np.conj(pr["nu"]) * fP) / abs(fP))
        d_conv.append(max(abs(S[v, 2 * i] - S1[v, 2 * i]), abs(S[v, 2 * i + 1] - S1[v, 2 * i + 1])) / abs(fP))
    print("%-48s max rel defect  nu(d)=chi(Nd): %.1e   conj: %.1e   |sum(X) - sum(X/4)|: %.1e"
          % (name, max(d_nu), max(d_cn), max(d_conv)))
    res[name] = dict(defect_nu=d_nu, defect_conj=d_cn, conv=d_conv)
for i, pr in enumerate(pairs):
    res["pairs"].append(dict(d=pr["d"], gamma=[list(u) for u in pr["gam"]], nu=[pr["nu"].real, pr["nu"].imag],
                             P=[pr["P"][0].real, pr["P"][0].imag, pr["P"][1]], Q=[pr["Q"][0].real, pr["Q"][0].imag, pr["Q"][1]],
                             Pi_P=[S[0, 2 * i].real, S[0, 2 * i].imag], Pi_Q=[S[0, 2 * i + 1].real, S[0, 2 * i + 1].imag]))
json.dump(res, open("h1m%d_X%.0e_s%d.json" % (m, X, SEED), "w"), indent=1)
