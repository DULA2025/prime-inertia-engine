"""The Galois Fourier series of rho|G_E over E = Q(sqrt(-7)), as a function on hyperbolic 3-space.

  Pi(z, r) = sum_{0 != nu in O_E} c((nu)) * r * K_0(4 pi |nu| r / sqrt 7) * e(Tr(nu z / sqrt(-7)))

with c(n) = coefficient of N(n)^{-s} in L(rho|G_E, s) (an ideal function, multiplicative), mu = nu/sqrt(-7) running
over the inverse different, and Tr(mu z) = 2 Im(nu z)/sqrt 7.  Each term is an exact eigenfunction of the hyperbolic
Laplacian on H^3 with eigenvalue 1 (spectral parameter 0, the Artin case).  If rho|G_E is automorphic (H1 for E),
Pi is a Bianchi Maass cusp form for Gamma_0(1951 O_E) with nebentypus chi(N d).

O_E = Z[w], w = (1 + sqrt(-7))/2, w^2 = w - 2.  1951 is inert in E; 2 and 7 behave as split / ramified.
Ideal coefficients (rho unramified away from 1951, a_p = chi(p)^3 t_p, chi(p) = zeta5^{2 dl(p) mod 5}):
  p split   (p = q qbar): c(q^j) = h_j,  h_1 = a_p,  h_{j+1} = a_p h_j - chi(p) h_{j-1};  c(q^a qbar^b) = h_a h_b
  p inert   (q = (p)):    c(q^j) = g_j,  g_1 = a_p^2 - 2 chi(p),  g_{j+1} = g_1 g_j - chi(p)^2 g_{j-1}
  p = 7     (q^2 = (7)):  c(q^j) = h_j with a_7, chi(7)
  p = 1951  (inert, conductor exponent 1): c(q^j) = (a_1951^2)^j, a_1951 = zeta5^2.
"""
import json, numpy as np, numba as nb, time, os
from scipy.special import k0

HERE = "/home/claude/research/bianchi/"
N0 = 1951
PHI = (1 + 5 ** 0.5) / 2
T_OF_CODE = np.array([2, -2, -1, 1, 0, PHI - 1, -PHI, 1 - PHI, PHI], dtype=np.float64)
Z5 = np.exp(2j * np.pi * np.arange(5) / 5)
SQ7 = 7 ** 0.5
OMEGA = complex(0.5, SQ7 / 2)

# discrete log base 3 mod 1951, reduced mod 5 (same normalisation as galois_traces.py)
DL5 = np.full(N0, -1, dtype=np.int64)
_x = 1
for _k in range(N0 - 1):
    DL5[_x] = _k % 5
    _x = _x * 3 % N0

def chi(n):
    return Z5[(2 * DL5[n % N0]) % 5]

@nb.njit(cache=True)
def sieve_spf(X):
    spf = np.zeros(X + 1, dtype=np.int32)
    for i in range(2, X + 1):
        if spf[i] == 0:
            spf[i] = i
            if i <= X // i:
                for j in range(i * i, X + 1, i):
                    if spf[j] == 0:
                        spf[j] = i
    return spf

def load_codes(X):
    """code_by_p[p] = class code (int8) for primes p <= X; -1 elsewhere."""
    code = np.full(X + 1, -1, dtype=np.int8)
    for fn in sorted(os.listdir(HERE + "chunks")):
        d = np.load(HERE + "chunks/" + fn)
        ps, cs = d["p"], d["c"]
        m = ps <= X
        code[ps[m]] = cs[m]
    # primes of bad reduction for the auxiliary polynomials: take the class from the old table
    old = json.load(open("/mnt/user-data/outputs/galois1951/galois_traces_150000.json"))
    for p in (2, 3, 5, 7, 17, 71, 137, 139, 271, 40427):
        t = old["t"][str(p)]
        cands = [k for k in range(9) if abs(T_OF_CODE[k] - t) < 1e-9]
        if t == 2 or t == -2 or t == 0:
            code[p] = cands[0]
        else:  # order 3/6/5/10 ambiguity only matters through t, which is all we use
            code[p] = cands[0]
    return code

@nb.njit(cache=True)
def _hseq(a, w, j):
    h0 = 1.0 + 0j
    if j == 0:
        return h0
    h1 = a
    for _ in range(j - 1):
        h0, h1 = h1, a * h1 - w * h0
    return h1

@nb.njit(cache=True)
def _gcd(a, b):
    while b:
        a, b = b, a % b
    return a

@nb.njit(cache=True)
def row_coeffs(y, xs, spf, code, dl5, Tc, z5, a1951, flipcode, pert_p, pert_amt, twist):
    """c((x + y w)) for x in xs.  flipcode >= 0: use sqrt5-conjugate traces at every prime (control).  pert_p: if > 0, add pert_amt to a_p at that split prime.
    twist = 0: drop chi^3 (untwisted traces of rho0, trivial nebentypus; control)."""
    n = xs.shape[0]
    out = np.empty(n, dtype=np.complex128)
    for i in range(n):
        x = xs[i]
        N = x * x + x * y + 2 * y * y
        g = _gcd(abs(x), abs(y))
        c = 1.0 + 0j
        M = N
        while M > 1:
            p = spf[M]
            e = 0
            while M % p == 0:
                M //= p
                e += 1
            r7 = p % 7
            dlp = dl5[p % 1951] if p != 1951 else 0
            chip = z5[(2 * dlp) % 5] if twist == 1 else 1.0 + 0j
            if p == 1951:
                c *= a1951 ** e
                continue
            cd = code[p]
            if flipcode >= 0 and cd >= 5:          # sqrt5-conjugate traces (control): 5<->6, 7<->8
                if cd == 5:
                    cd = 6
                elif cd == 6:
                    cd = 5
                elif cd == 7:
                    cd = 8
                else:
                    cd = 7
            t = Tc[cd]
            ap = z5[dlp % 5] * t if twist == 1 else t + 0j
            if p == pert_p:
                ap = ap + pert_amt
            if p == 7:
                c *= _hseq(ap, chip, e)
            elif r7 == 1 or r7 == 2 or r7 == 4:      # split (2 = 7 - 5... 2 is a QR mod 7)
                kc = 0
                gg = g
                while gg % p == 0 and kc * 2 < e:
                    gg //= p
                    kc += 1
                c *= _hseq(ap, chip, e - kc) * _hseq(ap, chip, kc)
            else:                                    # inert: e is even
                A2 = ap * ap - 2.0 * chip
                c *= _hseq(A2, chip * chip, e // 2)
        out[i] = c
    return out
