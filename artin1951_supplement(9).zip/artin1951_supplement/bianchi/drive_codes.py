import sys, os, time, numpy as np
from fasttraces import run
part, nparts = int(sys.argv[1]), int(sys.argv[2])
STEP = 10**7
TOP = int(float(sys.argv[3])) if len(sys.argv) > 3 else 10**8
for k, a in enumerate(range(0, TOP, STEP)):
    if k % nparts != part: continue
    fn = "chunks/codes_%03d.npz" % k
    if os.path.exists(fn): continue
    t0 = time.time(); ps, cs = run(max(a, 2), a + STEP - 1)
    np.savez_compressed(fn, p=ps, c=cs)
    print("chunk %d [%d,%d): %d primes, %.0fs, unresolved %d" % (k, a, a + STEP, len(ps), time.time() - t0, int((cs < 0).sum())), flush=True)
