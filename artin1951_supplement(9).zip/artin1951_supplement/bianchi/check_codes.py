import json, numpy as np, time
from fasttraces import run, BAD
PHI = (1 + 5 ** 0.5) / 2
T = np.array([2, -2, -1, 1, 0, PHI - 1, -PHI, 1 - PHI, PHI])
D = json.load(open("/mnt/user-data/outputs/galois1951/galois_traces_150000.json"))
t0 = time.time(); ps, cs = run(2, 150000); dt = time.time() - t0
mism, unres = [], []
for p, c in zip(ps, cs):
    p = int(p)
    if p in BAD or str(p) not in D["t"]: continue
    if c < 0: unres.append(p); continue
    if abs(T[c] - D["t"][str(p)]) > 1e-9: mism.append(p)
print("primes", len(ps), "time %.2fs (%.1f us/prime)" % (dt, 1e6 * dt / len(ps)))
print("mismatches", len(mism), mism[:10], "unresolved", unres[:10])
t0 = time.time(); ps, cs = run(10**8, 10**8 + 200000); dt = time.time() - t0
print("near 1e8:", len(ps), "primes, %.1f us/prime; unresolved %d; code counts %s"
      % (1e6 * dt / len(ps), int((cs < 0).sum()), np.bincount(cs[cs >= 0], minlength=9).tolist()))
