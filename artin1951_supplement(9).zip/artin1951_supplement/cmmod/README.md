# Is the Klein curve E/F modular?  CM-field modularity hypotheses, checked  (Dula, 9 Oct 2026)

**Artin's conjecture for ρ remains open.** E is the curve over F = ℚ(i, √5) with j(E) = j₀ (moonshine/), whose
mod-5 representation is ρ₀ mod √5 restricted to G_F, up to a twist ψ.

| hypothesis | result | label |
|---|---|---|
| F imaginary CM, Galois over ℚ | F = ℚ[y]/(y⁴+3y²+1), signature (0,2), disc 400, 4 automorphisms | [T] PARI |
| ζ₅ ∉ F | x⁴+x³+x²+x+1 factors 2+2 over F (no root) | [T] |
| ζ₃ ∉ F | x²+x+1 stays irreducible | [T] |
| E non-CM | j₀ is not an algebraic integer (denominators 29, 41, …) | [T] |
| E[5]: ρ̄_{E,5}(G_{F(ζ₅)}) = SL₂(𝔽₅) | projective image A₅ = PSL₂(𝔽₅) (certify_iso.py, exact); PSL₂(𝔽₅) and SL₂(𝔽₅) are perfect, so [G,G] = SL₂(𝔽₅) = G ∩ SL₂ | [T given certify_iso] |
| E[5] decomposed generic | ℓ ≡ 1 mod 20 with Frob_ℓ ≠ 1 in A₅: 61, 101, 181, 241, …; the eigenvalue ratio is ≠ 1 = ℓ^{±1} mod 5 at every v \| ℓ | [T] |
| E[3]: Gal(ψ₃/F) = S₄ = PGL₂(𝔽₃) | 4-cycles and 3-cycles occur as Frobenius cycle types; frequencies over 5949 primes of F match S₄ (0.252 / 0.333 / 0.122 / 0.256 / 0.037). With ζ₃ ∉ F, the image contains SL₂(𝔽₃) | [T] (the cycle types are group elements) |
| E[3] decomposed generic | ℓ = 149 (and 1289, 2909, 2969): a_v ≢ ±(1+ℓ) mod 3 at all four v \| ℓ | [T] |

**Reading.**
- Caraiani–Newton (arXiv:2301.10509) prove modularity over an imaginary CM field F that is Galois over ℚ with ζ₅ ∉ F, under "a technical assumption on the image" of E[3] or E[5]. Their exceptions are curves for which both E[3] and E[5] are exceptional.
- I could not read their Section 6 verbatim here: the tools truncate the paper at about 70k characters.
- If "non-exceptional" means the standard condition (image of G_{F(ζ_p)} contains SL₂(𝔽_p), plus decomposed generic), then BOTH E[3] and E[5] qualify, and E/F is modular by their theorem.
- This needs confirmation against their Theorem 6.1.x and Definition 2.1.27.

**What it would give.** A cuspidal cohomological, parallel weight 2 automorphic representation of GL₂(𝔸_F) whose mod-5 Galois representation is (ρ₀ mod √5)|G_F ⊗ ψ. That is residual modularity of the even icosahedral ρ₀ mod √5 over F.

**What it would not give.** Artin for ρ.
- Descent from F to ℚ is NOT the obstacle: F/ℚ is biquadratic (solvable), so cyclic base change and descent (Langlands; Arthur–Clozel) apply, as in Langlands–Tunnell.
- The obstacle is weight. Automorphy of ρ|G_F itself would need a non-cohomological, Artin-weight form over the CM field F, and no modularity-lifting theorem reaches that weight.

Files: `cm_hyp.py`, `dg3.py`.
