"""CM-field modularity hypotheses for the Klein curve E/F, F = Q(i, sqrt5), j(E) = j0 (moonshine/j0_exact.txt).
(a) F imaginary CM, Galois over Q, zeta_5 not in F                                          [exact, PARI]
(b) rho_{E,5}: projective image A5 = PSL2(F5) over F (certify_iso.py, exact) => image contains SL2(F5), and
    rho_{E,5}(G_{F(zeta5)}) = SL2(F5)  (group theory: [G,G] = SL2(F5) since PSL2(F5) is perfect and SL2(F5) is perfect)
(c) decomposed generic for E[5]: a prime l splitting completely in F, E good at l, Frob of order 3 or 5 in A5
    (eigenvalue ratio != 1 = l mod 5 since l = 1 mod 5)
(d) E[3]: Galois group over F of the 3-division polynomial (degree 4) from factorisation patterns at split primes:
    S4 = PGL2(F3) with zeta_3 not in F => image contains SL2(F3); also a decomposed-generic prime for E[3].
Author: Dula."""
import pickle, collections, cypari2
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
# (a)
F = pari.nfinit(pari.subst(pari.polredabs(pari("polcompositum(x^2+1, x^2-5)[1]")), "x", "y"))
print("F =", F[0], " degree", pari.poldegree(F[0]), " signature", F[1], " disc", F[2])
print("Galois over Q:", len(pari.nfgaloisconj(F)) == 4)
print("zeta_5 in F?  factor of x^4+x^3+x^2+x+1 over F:", [int(pari.poldegree(f)) for f in pari.nffactor(F, "x^4+x^3+x^2+x+1")[0]])
print("zeta_3 in F?  factor of x^2+x+1 over F:", [int(pari.poldegree(f)) for f in pari.nffactor(F, "x^2+x+1")[0]])
# reductions of j0 at split primes (four conjugates), as in m4_supersingular_E.py
J = pickle.load(open("/home/claude/research/moonshine/j0_exact_600.pkl", "rb"))
ra, rd = [int(s) for s in J["Re alpha"]]; ia, idd = [int(s) for s in J["Im alpha"]]
rb, rbd = [int(s) for s in J["Re beta"]]; ib, ibd = [int(s) for s in J["Im beta"]]
f5 = pari("x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344"); K5 = pari.nfinit(f5)
BAD = {2, 3, 5, 29, 41, 348500149, 696201529, 1951}
def a5order(p):
    from math import lcm
    o = 1
    for P in pari.idealprimedec(K5, p): o = lcm(o, int(P[3]))
    return o
def jconj(p):
    i_p = int(pari.sqrt(pari.Mod(-1, p)).lift()); s_p = int(pari.sqrt(pari.Mod(5, p)).lift()); out = []
    for si in (1, -1):
        A = (ra * pow(rd, -1, p) + si * i_p * ia * pow(idd, -1, p)) % p
        B = (rb * pow(rbd, -1, p) + si * i_p * ib * pow(ibd, -1, p)) % p
        for ss in (1, -1): out.append((A + ss * s_p * B) % p)
    return out
# (c) decomposed generic for E[5]
cands = []
for p in map(int, pari.primes([7, 2000])):
    if p % 20 != 1 or p in BAD or any(d % p == 0 for d in (rd, idd, rbd, ibd)): continue
    cands.append((p, a5order(p)))
print("(c) primes l = 1 mod 20 (split completely in F) and the order of Frob_l in A5:", cands[:12])
good = [p for p, o in cands if o in (3, 5)]
print("    decomposed-generic witnesses for E[5] (order 3 or 5, eigenvalue ratio != 1 = l mod 5):", good[:8])
# (d) E[3]: factorisation of the 3-division polynomial at split primes (all four conjugates)
pat = collections.Counter(); n = 0; dg3 = []
for p in map(int, pari.primes([7, 60000])):
    if p % 20 not in (1, 9) or p in BAD or any(d % p == 0 for d in (rd, idd, rbd, ibd)): continue
    for j in jconj(p):
        if j in (0, 1728 % p): continue
        E = pari.ellinit(pari.ellfromj(pari.Mod(j, p)))
        if int(pari.ellcard(E)) == 0: continue
        psi = pari.elldivpol(E, 3)
        degs = tuple(sorted(int(pari.poldegree(f)) for f in pari.factormod(psi, p)[0] for _ in range(1)))
        mult = tuple(sorted(int(e) for e in pari.factormod(psi, p)[1]))
        if max(mult) > 1: continue
        pat[degs] += 1; n += 1
        if p % 3 == 1 and len(dg3) < 6:                       # l split in F and l = 1 mod 3: need distinct eigenvalues mod 3
            ap = int(pari.ellap(E)) % 3
            if (ap * ap - 4) % 3 != 0: dg3.append((p, ap))      # disc of x^2 - a x + 1 nonzero mod 3 -> distinct eigenvalues
print("(d) cycle types of psi_3 mod P over F (%d primes of F):" % n)
S4 = {(1, 1, 1, 1): 1, (1, 1, 2): 6, (2, 2): 3, (1, 3): 8, (4,): 6}
for k in sorted(pat, key=lambda t: (len(t), t)): print("   ", k, "%.4f" % (pat[k] / n), "  S4 prediction %.4f" % (S4.get(k, 0) / 24))
print("    decomposed-generic witnesses for E[3] (l = 1 mod 3, split in F, a_l^2 - 4 != 0 mod 3):", dg3)
