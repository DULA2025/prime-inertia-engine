"""Decomposed generic for rho_{E,3}: a prime l split completely in F, E with potentially good reduction at l (j0 integral),
and for ALL four places v | l:  a_v != +-(1 + l) mod 3   (alpha/beta = l^{+-1}  <=>  a^2 = (1+l)^2 det/l, det = l).
Quadratic twists change a_v by a sign only, so the condition is twist-invariant.  Author: Dula."""
import pickle, cypari2
pari = cypari2.Pari()
J = pickle.load(open("/home/claude/research/moonshine/j0_exact_600.pkl", "rb"))
ra, rd = [int(s) for s in J["Re alpha"]]; ia, idd = [int(s) for s in J["Im alpha"]]
rb, rbd = [int(s) for s in J["Re beta"]]; ib, ibd = [int(s) for s in J["Im beta"]]
def jconj(p):
    i_p = int(pari.sqrt(pari.Mod(-1, p)).lift()); s_p = int(pari.sqrt(pari.Mod(5, p)).lift()); out = []
    for si in (1, -1):
        A = (ra * pow(rd, -1, p) + si * i_p * ia * pow(idd, -1, p)) % p
        B = (rb * pow(rbd, -1, p) + si * i_p * ib * pow(ibd, -1, p)) % p
        for ss in (1, -1): out.append((A + ss * s_p * B) % p)
    return out
wit = []
for p in map(int, pari.primes([7, 3000])):
    if p % 20 not in (1, 9) or any(d % p == 0 for d in (rd, idd, rbd, ibd)): continue
    aps = []
    for j in jconj(p):
        E = pari.ellinit(pari.ellfromj(pari.Mod(j, p))); aps.append(int(pari.ellap(E)))
    ok = all(a % 3 not in ((1 + p) % 3, (-(1 + p)) % 3) for a in aps)
    if ok: wit.append((p, aps))
print("decomposed-generic witnesses for E[3] (all four places v | l):", wit[:6])
