"""The Klein curve E/F, F = Q(i, sqrt5) = Q[y]/(y^4+3y^2+1), made explicit from the exact j0, and the Caraiani-Newton
hypotheses checked one by one with exact arithmetic.
  i = y^3 + 2y,  sqrt5 = 2y^2 + 3   (checked below)
  model  E_j: Y^2 = X^3 + 3j(1728-j) X + 2j(1728-j)^2   (j-invariant j), scaled by u to an integral model over O_F
Outputs: integrality, the primes of potentially multiplicative reduction (v_P(j0) < 0) and their Kodaira types,
decomposed-generic witnesses for E[5] and E[3] with all four a_P, projective orders of rho_{E,5}(Frob_P) versus the
A5 class of Frob_l from the Galois data of rho.  Author: Dula."""
import pickle, json, cypari2
pari = cypari2.Pari(); pari.allocatemem(4 * 10**9)
J = pickle.load(open("/home/claude/research/moonshine/j0_exact_600.pkl", "rb"))
q = lambda k: pari(J[k][0]) / pari(J[k][1])
F = pari.nfinit("y^4+3*y^2+1")
I_ = pari("Mod(y^3+2*y, y^4+3*y^2+1)"); S5 = pari("Mod(2*y^2+3, y^4+3*y^2+1)")
assert I_ ** 2 == -1 and S5 ** 2 == 5
j0 = (q("Re alpha") + I_ * q("Im alpha")) + (q("Re beta") + I_ * q("Im beta")) * S5
den = pari.denominator(pari.content(pari.lift(j0)))
print("F: disc %s, class number %s" % (F[2], pari.bnfinit("y^4+3*y^2+1").bnf_get_no()))
print("denominator of j0 (rational):", pari.factor(den))
a4 = 3 * j0 * (1728 - j0); a6 = 2 * j0 * (1728 - j0) ** 2
u = pari(29 * 41 * 348500149 * 696201529) ** 3 * 1951
A4 = u ** 4 * a4; A6 = u ** 6 * a6
integral = all(pari.denominator(pari.content(pari.nfalgtobasis(F, pari.lift(c)))) == 1 for c in (A4, A6))
E = pari.ellinit([0, 0, 0, pari.lift(A4), pari.lift(A6)], F)
print("integral model over O_F:", integral, "; j(E) == j0:", pari.lift(pari("(E)->E.j")(E)) == pari.lift(j0))
out = dict(integral=bool(integral))
# potentially multiplicative primes
pm = []
for p in (29, 41, 1951, 348500149, 696201529):
    for P in pari.idealprimedec(F, p):
        v = int(pari.nfeltval(F, pari.lift(j0), P))
        if v < 0:
            r = pari.elllocalred(E, P)
            pm.append(dict(p=p, f=int(P[3]), v_j=v, kodaira=str(r[1]), cond_exp=int(r[0])))
print("places with v_P(j0) < 0 (potentially multiplicative):"); [print("  ", d) for d in pm]
out["pot_mult"] = pm
# decomposed generic witnesses and projective orders
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
ORD = {0: 2, 1: 3, 4: "1|5"}
rows = []
for l in map(int, pari.primes([7, 1200])):
    if l % 20 not in (1, 9) or l in (29, 41, 1951): continue
    Ps = pari.idealprimedec(F, l); assert len(Ps) == 4
    aps = []; skip = False
    for P in Ps:
        mp = pari.nfmodprinit(F, P); jb = pari.nfmodpr(F, pari.lift(j0), mp)
        if jb == 0 or jb == 1728: skip = True; break
        aps.append(int(pari.ellap(pari.ellinit(pari.ellfromj(jb)))))    # a_P of a good-reduction twist (twist-invariant data only)
    if skip: continue
    gen5 = all(a % 5 not in ((1 + l) % 5, (-(1 + l)) % 5) for a in aps)
    gen3 = all(a % 3 not in ((1 + l) % 3, (-(1 + l)) % 3) for a in aps)
    po = sorted(set((a * a * pow(l, -1, 5)) % 5 for a in aps))
    cls = D["cls"].get(str(l))
    rows.append(dict(l=l, a_P=aps, generic5=gen5, generic3=gen3, u5=po, cls=cls))
bad_u = [r for r in rows if not set(r["u5"]) <= {0, 1, 4}]
agree = 0
for r in rows:
    want = {"2B": 0, "2A": 0, "3A": 1, "5A": 4, "5B": 4, "1A": 4, "id": 4}.get(r["cls"])
    agree += (r["u5"] == [want])
print("split primes l < 1200 (l = 1, 9 mod 20): %d;  tr^2/det mod 5 always in {0,1,4} (projective image A5): %s" % (len(rows), not bad_u))
print("projective order of rho_{E,5}(Frob_P), all four P | l, equals that of rho(Frob_l) (A5 class from f5 data): %d / %d" % (agree, len(rows)))
w5 = [r["l"] for r in rows if r["generic5"]]; w3 = [r["l"] for r in rows if r["generic3"]]
print("decomposed-generic witnesses for E[5]:", w5[:12], "... (%d)" % len(w5))
print("decomposed-generic witnesses for E[3]:", w3[:12], "... (%d)" % len(w3))
for r in rows[:10]: print("   l=%d  a_P=%s  u=%s  class=%s  generic5=%s generic3=%s" % (r["l"], r["a_P"], r["u5"], r["cls"], r["generic5"], r["generic3"]))
out.update(rows=rows, witnesses5=w5, witnesses3=w3, proj_order_agree=[agree, len(rows)])
json.dump(out, open("/home/claude/research/cmmod/efg.json", "w"), indent=1)
