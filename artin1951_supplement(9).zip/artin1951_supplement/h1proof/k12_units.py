"""Units of K12 (polredabs model Q); real embeddings labelled by cosets gH, H = <(12345)> in A5 (polroots order of f5)."""
import json, time, cypari2
pari = cypari2.Pari(); pari.allocatemem(6 * 10**9); pari.set_real_precision(150)
K = json.load(open("k12.json"))
pari("Q = %s; a = %s;" % (K["Q"], K["a"]))
t0 = time.time()
pari("bnf = bnfinit(Q, 1);")
print("bnfinit: %.0f s" % (time.time() - t0), flush=True)
print("signature", pari("bnf.sign"), " class group", pari("bnf.cyc"), " regulator", pari("bnf.reg"), flush=True)
print("torsion units", pari("bnf.tu"))
pari("fu = bnf.fu;")
print("number of fundamental units", pari("#fu"), "; max coefficient size (digits):",
      pari('vecmax(apply(u -> vecmax(apply(c->#Str(abs(c)), Vec(lift(u)))), fu))'))
pari('write("k12_bnf_units.gp", [Q, a, apply(u -> lift(u), fu)])')
print('units written', flush=True)
t0 = time.time()
print("bnfcertify (unconditional class group and units):", pari("bnfcertify(bnf)"), " %.0f s" % (time.time() - t0))
