"""Build K12 = fixed field of C5 = <(12345)> in the A5-closure of K5 = Q[x]/(f5), with the 12 real embeddings labelled
by cosets gH (g in A5 acting on the polroots order of f5).  theta_g = sum_i x_{g(i)}^2 x_{g(i+1)}, i mod 5."""
import itertools, json, cypari2
pari = cypari2.Pari(); pari.allocatemem(4 * 10**9); pari.set_real_precision(250)
f5 = pari("x^5-x^4-780*x^3-1795*x^2+3106*x+344")
R = pari("polroots(x^5-x^4-780*x^3-1795*x^2+3106*x+344)")
xs = [pari.real(R[i]) for i in range(5)]
def sign(p):
    s, p = 1, list(p)
    for i in range(5):
        while p[i] != i:
            j = p[i]; p[i], p[j] = p[j], p[i]; s = -s
    return s
A5 = [g for g in itertools.permutations(range(5)) if sign(g) == 1]
def theta(g): return sum(xs[g[i]] ** 2 * xs[g[(i + 1) % 5]] for i in range(5))
vals, cos = [], []
for g in A5:
    t = theta(g)
    for k, v in enumerate(vals):
        if abs(v - t) < pari("1e-150"):
            cos[k].append(g); break
    else:
        vals.append(t); cos.append([g])
assert len(vals) == 12 and all(len(c) == 5 for c in cos), (len(vals), [len(c) for c in cos])
P = pari("1")
for v in vals: P *= pari("x") - v
P = pari.round(pari.real(P))
err = max(abs(pari.subst(P, "x", v)) / max(1, abs(v)) ** 11 for v in vals)
print("P irreducible:", pari.polisirreducible(P), " relative residual of roots: %.1e" % float(err))
print("poldisc factor:", pari.factor(pari.poldisc(P)))
nf = pari.nfinit(P)
print("field disc:", pari.factor(nf[2]))
red = pari.polredabs(P, 1)
Q, a = red[0], red[1]
print("polredabs:", Q)
json.dump({"P": str(P), "Q": str(Q), "a": str(a), "cosets": [[list(g) for g in c] for c in cos],
           "theta": [str(v) for v in vals]}, open("k12.json", "w"), indent=1)
