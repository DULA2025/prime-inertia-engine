"""Leopoldt's conjecture for K12 at p (default p = 2): rank of the p-adic logarithms of the 11 fundamental units.

K12 (C5-fixed field of the A5 closure M of f5) has 2 = P1 P2 P3 P4, each of residue degree 3.  Leopoldt for K12 at p
implies that the ad^0 rho - isotypic part of the units of M injects p-adically, hence
H^1(G_{Q,S}, ad^0 rho (x) Qbar_p) = 0 for every finite S (README, section 3).

Method: factorpadic(Q, p) gives the local factors g_j; in Q_p[y]/(g_j) each unit u is raised to the power
(p^f - 1) p^k so that it lies in 1 + p^(k+1) O, and log is summed as a series.  The 12 x 11 matrix of coordinates
is p-adically integral after scaling; a non-zero 11 x 11 minor with valuation below the working precision proves
rank 11.
"""
import sys, cypari2
pari = cypari2.Pari(); pari.allocatemem(6 * 10**9)
p = int(sys.argv[1]) if len(sys.argv) > 1 else 2
PREC = int(sys.argv[2]) if len(sys.argv) > 2 else 700
pari("V = read(\"k12_bnf_units.gp\"); Q = V[1]; fu = V[3];")
pari("p = %d; PREC = %d;" % (p, PREC))
pari("""F = factorpadic(Q, p, PREC); nloc = #F[,1];""")
print("p = %d: local factors of degrees" % p, pari("apply(poldegree, F[,1]~)"), "multiplicities", pari("F[,2]~"))
pari("plog(U, f) = my(W = (U^(p^f - 1))^(p^6), X = W - 1, S = 0, T = 1); for (n = 1, ceil(1.2 * PREC / 7) + 10, T = T * X; S += (-1)^(n + 1) * T / n); S / ((p^f - 1) * p^6)")
pari("coords(L, f) = my(v = Vec(lift(L))); concat(vector(f - #v, i, 0), v)")
pari("M = matrix(12, #fu); row = 0;")
pari("for (j = 1, nloc, g = F[j, 1]; f = poldegree(g); for (i = 1, #fu, c = coords(plog(Mod(fu[i], g), f), f); for (t = 1, f, M[row + t, i] = c[t])); row += f)")
print("matrix built; minimal valuation of entries:", pari("vecmin(apply(valuation, concat(Vec(M))))"),
      " minimal absolute precision of entries (padicprec):", pari("vecmin(apply(x -> padicprec(x, p), concat(Vec(M))))"))
pari("mins = vector(12, r, my(rr = setminus([1..12], [r])); matdet(matrix(11, 11, a, b, M[rr[a], b])))")
for r in range(1, 13):
    d = pari("mins[%d]" % r)
    print("minor without row %2d: valuation %s, known to absolute precision p^%s" %
          (r, pari("valuation(mins[%d])" % r), pari("padicprec(mins[%d], p)" % r)))
print("p-adic rank of the 12 x 11 log matrix (PARI matrank):", pari("matrank(M)"))
