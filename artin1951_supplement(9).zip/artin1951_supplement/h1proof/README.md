# Toward a proof of H1: what can be proved, what is missing (Dula, 19 Oct 2026)

Labels: [T] theorem (proof here or cited), [T|comp] theorem whose input is an exact or interval-safe computation,
[N] numerical, [C] conjecture, [S] speculation. H1 for a field E: ρ|G_E is automorphic (note, Hypothesis H1).

Nothing here proves H1 for any field, or Artin's conjecture for ρ. Four things are new:

1. **Two fields suffice for modularity (§1).** H1 for one quadratic field E together with H1 for one cyclic cubic
   field C implies that ρ is modular. This replaces the infinite family of Theorem A′. [T]
2. **Finitely many fields without real places never suffice (§2).** At the primes whose Frobenius is complex
   conjugation in the compositum, base change to such fields cannot see the sign that separates ρ from a twist of it
   by ±1. So a finite family needs a field with a real place, and over such a field ρ is even again. [T]
3. **First-order deformations of ρ|G_E are anti-invariant under Gal(E/Q), for p = 2, 3, 5, 7 (§3).** Leopoldt's conjecture holds for the
   degree-12 field K12 at these primes. Hence H¹(G_Q,S, ad⁰ρ ⊗ Q̄_p) = 0, and Gal(E/Q) acts by −1 on H¹(G_E,S, ad⁰ρ). [T|comp]
   **Correction (20 October 2026).** This version said that every first-order deformation therefore has anti-parallel
   weight derivative. That holds for nearly ordinary deformations whose ordinary lines at the two places above p
   correspond under Gal(E/Q), as for base change. With lines for different Frobenius eigenvalues at the two places,
   the nearly ordinary tangent space is one-dimensional with parallel weight. See Proposition 9.1 of the note of
   20 October.
4. **H1 holds numerically over Q(i) and Q(√−2) (§5)**, the two imaginary fields of the three-field variant in §1.
   With the earlier runs (q = 7, 23, 31), there are now five fields. [N]
   **Update (20 October 2026, afternoon).** The third field of the variant, the real field Q(√2), passes the analogous
   test for the Galois series on ℍ × ℍ; see `hilbert/README.md` and Remark 3.10 of the note. [N]

§4 records the numerical defect ℓ₀ = 3 of the lifting problem and what each known route would need.

---

## 1. Two fields suffice

Notation as in the note: Π_E corresponds to ρ|G_E (H1). The lemma "central character of the descent" (Lemma central)
gives a descent Π^E to GL₂(𝔸_Q) with central character χ and Π^E_p ≅ ρ_p ⊗ unr(s_p), s_p ∈ {±1}, s_p = 1 if p splits
in E. The lemma "compatibility at all places" (Lemma allplaces) makes Π_E correspond to ρ|G_E at every place.

**Lemma 1 (cyclic descent of odd prime degree)** [T]. Let C/Q be cyclic of odd prime degree ℓ and assume H1 for C.
(a) Π_C = BC_{C/Q}(π) for a unique cuspidal π with central character χ.
(b) Let p ≠ 1951 be unramified in C, with {a, b} the eigenvalues of ρ(Frob_p). If p splits in C, π_p ≅ ρ_p. Otherwise
π_p is unramified with Satake parameter {α, β}, αβ = ab and {α^ℓ, β^ℓ} = {a^ℓ, b^ℓ}.

*Proof.* (a) Π_C is Gal(C/Q)-invariant (strong multiplicity one), so by Langlands it is BC(π), π cuspidal and unique up to
⊗ψ^j, ψ a generator of the characters of Gal(C/Q). Its central character ω satisfies ω∘N = χ∘N, so ω = χψ^j; twisting by
ψ^i multiplies ω by ψ^{2i}; ℓ odd gives exactly one twist with ω = χ.
(b) At w | p of residue degree f, Π_{C,w} has Satake parameter the eigenvalues of ρ(Frob_p)^f (Lemma allplaces).
For f = 1, π_p ≅ Π_{C,w}. For f = ℓ, C_w/Q_p is unramified of degree ℓ. A Steinberg twist has Steinberg base change; an
irreducible 2-dimensional representation of W_{Q_p} stays irreducible on a normal subgroup of odd prime index (Clifford),
so supercuspidals have supercuspidal base change. Hence π_p = π(ν₁, ν₂) with ν_i∘N unramified, so ν_i unramified (N is
onto the units). The base change has parameter {α^ℓ, β^ℓ}, and αβ = χ(p) = ab. ∎

**Theorem A″** [T]. Let E be a quadratic field and C a cyclic field of odd prime degree ℓ (e.g. a cyclic cubic field).
If H1 holds for E and for C, then ρ is modular and L(ρ, s) is entire. Conversely, modularity gives H1 for E and C.

*Proof.* Let π be as in Lemma 1 and Π^E a descent of Π_E.
- *Step 1: π is a descent of Π_E.* K = EC is cyclic of degree 2ℓ, and K ∩ M = Q (A₅ is perfect), so ρ|G_K is
  irreducible. BC_{K/Q}(π) = BC_{K/C}(Π_C) and BC_{K/Q}(Π^E) = BC_{K/E}(Π_E) both correspond to ρ|G_K. Both are
  cuspidal: an isobaric sum of two Hecke characters has a Rankin–Selberg square with a pole of order ≥ 2 at s = 1,
  while L(s, ρ ⊗ ρ^∨|G_K) has a simple pole there. By strong multiplicity one they are isomorphic. Langlands' fibres for
  K/E and then E/Q give π ≅ Π^E ⊗ ψ^j ε_E^a. Central characters: ψ^{2j} = 1, so j = 0. So π ∈ {Π^E, Π^E ⊗ ε_E}, and
  π_p ≅ ρ_p ⊗ unr(s_p) for almost all p, with s_p = 1 if p splits in E.
- *Step 2: s_p = 1.* Take p outside a finite set, {a, b} the eigenvalues of ρ(Frob_p), a + b ≠ 0 (else the sign is
  irrelevant). If p splits in C, π_p ≅ ρ_p (Lemma 1). Otherwise {s_p a^ℓ, s_p b^ℓ} = {a^ℓ, b^ℓ} (ℓ odd). If s_p = −1 then
  b^ℓ = −a^ℓ, so b/a has order 2ℓ (it is not −1, as a + b ≠ 0). The order of b/a is the order of Frob_p in the
  projective image A₅, which has no element of order 2ℓ ≥ 6. So s_p = 1.

Hence π corresponds to ρ, and L(ρ, s) is entire as in the proof of Theorem A. ∎

*Remarks.*
- C is totally real (complex conjugation has odd order on it) and ρ|G_C is totally even: H1 for C is the even problem
  again. The quadratic field reduces the ambiguity at each prime to a sign (Lemma central); the odd residue degrees in C
  fix it, exactly as in the last step of the proof of Lemma "the sign is a character" (H2 over the quintic L₅).
- With E = Q(√−7), where H1 holds numerically, the remaining hypothesis is H1 for one cyclic cubic field, e.g. Q(ζ₇)⁺.
- The proof uses only: A₅ has no elements of order 2ℓ. It applies verbatim to cyclic fields of degree 5, 7, ….

**Normalised descents (three quadratic fields)** [T]. If a quadratic field E is ramified at a single prime q ≠ 1951,
exactly one descent of Π_E is unramified at q, hence at every prime ≠ 1951.
- At q the descent is not Steinberg or supercuspidal (its base change is unramified), so it is π(ν₁, ν₂) with ν_i trivial
  on norms from E_q, i.e. ν_i|Z_q^× ∈ {1, ε_{E,q}}. The central character χ is unramified at q, so ν₁ and ν₂ agree on
  Z_q^×: both trivial, or both ε_{E,q} (then the other descent, ⊗ε_E, is unramified).
- At other p ≠ 1951 every descent is unramified (unramified local base change along unramified or split extensions).
- Two such normalised descents (fields ramified at q, q′) differ by η ∈ ⟨ε_E, ε_E′⟩ (Step 1 of Theorem A′); every η ≠ 1
  there is ramified at q or q′, where both are unramified. So η = 1: **the normalised descent does not depend on E.**

Consequences:
- For families of fields with prime discriminant (such as 𝓕₇), Steps 2–3 of the proof of Theorem A′ collapse: the
  common normalised descent is ρ at every prime that splits in some field.
- **H1 for Q(i), Q(√−2), Q(√2) implies modularity**: all three are ramified only at 2, and every odd p splits in one of
  them because (−1/p)(2/p)(−2/p) = 1.
- This does not contradict item (1) of the remark after Theorem A′: there the real field Q(√(q q′)) is ramified at two
  primes, and each of its two descents can be ramified at one of them.
- Among finite families of quadratic fields each ramified at a single prime, covering almost all primes forces the three
  subfields of Q(ζ₈). Covering ⟺ the image of Gal in {±1}ⁿ avoids (−1,…,−1) ⟺ some odd number of the characters
  multiplies to 1. At an odd prime q only one quadratic field is ramified only at q, so a product over distinct fields
  that involves it is ramified at q. Hence the odd relation lives among ε₋₄, ε₈, ε₋₈, and must be their product.

## 2. Why one field with a real place is unavoidable

**Proposition (complex conjugation)** [T]. Let 𝓔 be a finite set of number fields without real places, L the Galois
closure of their compositum, and P the primes unramified in L whose Frobenius is conjugate to a complex conjugation.
P has density |c^G|/[L:Q] > 0. For p ∈ P, every prime above p in every E ∈ 𝓔 has residue degree 2. So the local base
changes of ρ_p and of ρ_p ⊗ unr(−1) to every completion of every E ∈ 𝓔 above p coincide.

*Proof.* Primes of E above p ↔ orbits of ⟨Frob_p⟩ on Hom(E, L). A complex conjugation has order 2 and fixes no
embedding (E has no real place), so all orbits have size 2; unramified quadratic base change sends {α, β} to
{α², β²}. Density: Chebotarev. ∎

So every argument that, like Theorems A′ and A″, uses H1 only through local components at unramified places,
cannot tell ρ_p from ρ_p ⊗ unr(−1) on a set of primes of positive density, if it uses finitely many fields without
real places. It needs infinitely many such fields (Theorem A′: every prime eventually splits), or a field with a real
place (Theorem A: the totally real quintic L₅; Theorem A″: the totally real cyclic field C; §1: Q(√2)).
Over a field with a real place, ρ is even. The sign problem of Lemma "the sign is a character" is the Chebotarev
trace of complex conjugation: the undetermined primes are those whose Frobenius looks like c in every field used.

## 3. Rigidity: no parallel-weight deformation of ρ|G_E (p = 2, 3, 5, 7)

**K12** (`k12_build.py`, `k12.json`): the fixed field of C₅ = ⟨(12345)⟩ in the A₅-closure M of f₅, built from the
resolvent θ = Σ x_i² x_{i+1}; polredabs model
  x¹² − 113x¹⁰ + 4482x⁸ − 72251x⁶ + 388968x⁴ − 48712x² + 1225,
field discriminant 1951⁸ (= f(3)·f(3′)·f(5) = 1951²·1951²·1951⁴, as predicted by Ind_{C₅}^{A₅}1 = 1 + 3 + 3′ + 5).
Totally real; bnfinit: class group trivial, regulator 8.8248·10⁹, 11 fundamental units (GRH-conditional;
certification stopped; not needed below, since any finite-index subgroup of units gives the same statement).
The 11 units are checked to be algebraic integers of norm 1 (`k12_units.py`, `k12_bnf_units.gp`).

**Leopoldt for K12 at p** (`k12_leopoldt.py`) [T|comp]. The p-adic logarithms of the 11 units, in the completions
(2: four places of degree 3; 3: degrees 1, 1, 5, 5; 5 and 7: six places of degree 2), form a 12 × 11 matrix over Q_p:
- p = 2: all twelve 11 × 11 minors are non-zero, valuations 16–17, known to 2⁶⁹⁷;
- p = 3: rank 11 (minor valuation 12, known to 3⁴⁰⁴);
- p = 5, 7: ten minors non-zero (valuation 10, known to p³⁹⁷ and p⁴⁰¹); the other two vanish because two local
  factors are even polynomials, which puts a zero coefficient in the norm relation.
So the logs have rank 11 and Leopoldt's conjecture holds for K12 at 2, 3, 5, 7.

**Consequence** [T|comp]. For p ∈ {2, 3, 5, 7} and every finite S: H¹(G_{Q,S}, ad⁰ρ ⊗ Q̄_p) = 0, and likewise for ad⁰ρ″.
- H¹(G_{Q,S}, V) = Hom_{A₅}(G_{M,S}^{ab} ⊗ Q_p, V) for V = ad⁰ρ (finite-group cohomology vanishes in characteristic 0).
- Unramified outside p: by class field theory this is Hom_{A₅}((U_p ⊗ Q_p)/(Ē ⊗ Q_p), V), with U_p ⊗ Q_p ≅ Q_p[A₅] and
  E ⊗ Q_p ≅ Q_p[A₅] − 1 (M totally real). V occurs three times in each, so H¹ = 0 iff the V-part of E injects p-adically.
  The kernel is an A₅-submodule; its V-part would have non-zero C₅-invariants, i.e. a kernel on E_{K12}, which Leopoldt
  for K12 excludes (V^{C₅} ≠ 0).
- Ramification at ℓ ≠ p adds nothing: where V is unramified, Frob_ℓ acts on V(−1) with eigenvalues ζℓ⁻¹ ≠ 1; at 1951,
  H¹(I, V) = V^I(−1) and Frobenius acts on it by 1951⁻¹ (Frobenius centralises the inertia image, as 1951 ≡ 1 mod 5).

Over E (any quadratic field), Shapiro gives H¹(G_{E,S}, ad⁰ρ) = H¹(G_{Q,S}, ad⁰ρ) ⊕ H¹(G_{Q,S}, ad⁰ρ ⊗ ε_E) = 0 ⊕ (dim ≥ 3).
So Gal(E/Q) acts by −1 on every first-order deformation of ρ|G_E, and the weight derivatives at the two embeddings
E → Q̄_p are opposite (anti-parallel, "anti-diagonal" in Calegari–Mazur). Cohomological Bianchi forms have parallel
weights, so **no parallel-weight p-adic family of Bianchi eigensystems is étale over weight space at ρ|G_E**.
[Correction, 20 October 2026: the last two sentences hold only for ordinary lines at v and v̄ that correspond under
Gal(E/Q). The Sen weights of a trace-zero deformation are {w, −w} at each embedding, so "opposite" needs labelled
lines. With lines for different Frobenius eigenvalues at v and v̄, the nearly ordinary tangent space is one-dimensional
with parallel infinitesimal weight (w, w), w ≠ 0 (note of 20 October, Proposition 9.1), so a parallel family étale over
weight space is not excluded at first order.] Over Q,
ρ_p has no first-order deformations with fixed determinant. This is the even case of Calegari–Mazur, Cor. 1.4 (there under a Strong
Leopoldt hypothesis), made unconditional for this ρ and these p; by Calegari (2011), under its hypotheses, G_E has no
irreducible ordinary 2-dimensional representations of non-parallel weight.

## 4. The defect, and what each route would need

Greenberg–Wiles for the minimal deformation problem of ρ̄|G_F with the Artin (unramified) condition at v | p:
the local terms at p vanish (dim L_v = h⁰(G_v, ad⁰)), so
  ℓ₀(F) = Σ_{v|∞} h⁰(G_{F_v}, ad⁰ρ) − Σ_{v|p}(dim L_v − h⁰) = 3(r₁ + r₂)   (ρ(c) = −I acts trivially on ad⁰).
This equals the rank of the ad⁰ρ-part of the units of MF. [T]

| setting | ℓ₀ | status |
|---|---|---|
| ρ over Q (even, Artin weight) | 3 | open |
| ρ\|G_E, E imaginary quadratic (H1) | 3 | open |
| ρ\|G_F, F real quadratic; C cyclic cubic | 6; 9 | open (even again) |
| odd weight one over Q | 1 | known (Khare–Wintenberger and Deligne–Serre; Calegari–Geraghty reprove lifting by patching coherent H⁰, H¹) |
| totally odd parallel weight one over totally real F, [F:Q] = d | d | known (families + geometry) |
| cohomological weight 2 over E | 3 − 2 = 1 | Calegari–Geraghty, Allen et al., Caraiani–Newton |
| regular odd over totally real F | 0 | Taylor–Wiles |

- Q and imaginary quadratic fields tie at the minimum ℓ₀ = 3. Moving to E removes the parity obstruction, not the
  defect; the adjoint units over E are the same as over Q (the ad⁰ρ ⊗ ε_E part has rank 0).
- *Route A, patching at the Artin point*: needs an automorphic complex for Artin weight with cohomology in ℓ₀ + 1 = 4
  consecutive degrees, on which a derived Hecke algebra would act through the three adjoint units (Venkatesh's picture).
  None exists over Q (Maass forms of eigenvalue 1/4) or over E (spectral parameter 0 on H³ is non-cohomological). [S]
- *Route B, families and classicality* (Buzzard–Taylor, Kassaei, Sasaki, Pilloni–Stroh for weight one): needs ρ in a
  p-adic family of classical forms and a geometric analytic continuation. Over Q, §3 removes the family for p ≤ 7.
  Over E it removes only families with the base-change choice of ordinary lines; with the other choice a parallel
  direction exists at first order (correction of 20 October, Proposition 9.1 of the note). Bianchi manifolds have no
  algebraic structure for the continuation step.
- *Route C, converse theorem over E*: needs L(s, ρ|G_E ⊗ ξ) entire for Hecke characters ξ of E, i.e. 4-dimensional
  Artin L-functions L(s, ρ ⊗ Ind ξ); not available.
- *Route D, descent*: cyclic towers never make A₅ solvable (note, Lemma "cyclic towers"); non-normal quintic base change (H2)
  is open.
- *Residual input* is in hand for every quadratic E: ρ̄₂|G_E is the reduction of the base change of the weight-2
  newforms of Theorem D(iii), which stays cuspidal (projective image A₅). At v | 2, ρ|G_{E_v} is unramified and ρ̄₂(Frob₂)
  has distinct eigenvalues x ≠ y. Over Q(i) and Q(√−2), 2 ramifies; over 𝓕₇ it splits.

## 5. H1 over Q(i) and Q(√−2) (numerical)

`../bianchi/bianchi_m.py`, `../bianchi/run_h1m.py`: O_E = Z[√−m], m = 1, 2; 2 ramified (c(𝔭₂ʲ) = h_j(a₂, χ(2))); 1951 inert
in both (1951 ≡ 7 mod 8); different (√d_E), so
  Π(z, r) = Σ_{ν≠0} c((ν)) r K₀(4π|ν|r/√|d|) e(2 Im(νz)/√|d|),  |d| = 4m.
The pairing (ν, β) ↦ 2 Im(νβ)/√|d| is unimodular on O_E. The coefficient kernel agrees with PARI ideal factorisation
(400 random ν per field, max difference 1.3·10⁻¹⁵).

| field | h | N(ν) ≤ X | largest defect for ρ | smallest defect of a control | gap (orders) | size of sum(X) − sum(X/4) |
|---|---|---|---|---|---|---|
| Q(√-7) | 1 | 1.0e+08 | 2.9e-10 | 3.3e-06 | 4.1 | 6.3e-05 |
| Q(√-23) | 3 | 3.3e+08 | 9.6e-10 | 5.3e-05 | 4.7 | 6.9e-05 |
| Q(√-31) | 3 | 4.4e+08 | 2.4e-09 | 1.5e-05 | 3.8 | 2.4e-05 |
| Q(i) | 1 | 1.0e+08 | 6.4e-11 | 5.0e-06 | 4.9 | 5.9e-07 |
| Q(√-2) | 1 | 2.0e+08 | 2.1e-10 | 1.2e-06 | 3.8 | 9.4e-07 |

Per control, Q(i) / Q(√−2): a₂ + 10⁻³: 5.3·10⁻³ / 7.5·10⁻³; a₁₉₅₁ = 1: 1.6·10⁻⁵ / 5.5·10⁻⁵; √5-conjugate traces: 6.6 / 6.5;
χ³ dropped: 11 / 3.6; conjugate nebentypus: 1.9 / 1.9 (largest over pairs). Run times 2120 s and 2388 s.
[N] The Galois series of ρ|G_E is invariant under Γ₀(1951 O_E) with nebentypus χ(N d) to 10 digits over Q(i) and
Q(√−2), and every control fails. As before this is a consistency check: H1 follows from modularity.
`../bianchi/h1_five_fields.png` shows all five fields (`plot_h1_five.py`); `h1_summary.py` → `h1_summary.json`.

## Files
- `k12_build.py` → `k12.json`; `k12_units.py` → `k12_units.log`, `k12_bnf_units.gp`; `k12_leopoldt.py` → `leopoldt_p*.log`.
- `../bianchi/bianchi_m.py`, `../bianchi/run_h1m.py` → `h1m1_X1e8_s6.log/.json`, `h1m2_X2e8_s7.log/.json`.
- `note_insert.tex`: the text added to the note on 19 Oct 2026. In the note: Lemma 3.7 (odd descent), Theorem A″,
  Remark 3.8 (normalised descents), Proposition 3.9 (complex conjugation), Remark 3.10 (the table above), and two
  items in Question 3 (defect, rigidity). The later remarks of §3 move from 3.7, 3.8 to 3.11, 3.12.
- `../note/check_note_claims.py`: 7 new exact checks (A₅ element orders, splitting in Q(i), Q(√±2), K12, Leopoldt at 2);
  49/49 pass.
