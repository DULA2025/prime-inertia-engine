"""E / F = Q(i, sqrt5) with j(E) = j0 (Klein's icosahedral resolvent of the A5 quintic of rho, rho-ruling).
Test: for primes P of F (good reduction, not above 2, 5, 1951), the projective order of Frob_P on E[5],
read from u = a_P^2 / N(P) mod 5  (0 -> 2, 1 -> 3, 4 -> 1 or 5, 2 -> 4, 3 -> 6),
must equal the order of Frob_P in Gal(A5 field / Q), i.e. the order of Frob_p^f, f = residue degree.
Exact arithmetic per prime."""
import pickle, cypari2
pari = cypari2.Pari(); pari.allocatemem(4*10**9)
J = pickle.load(open("j0_exact_600.pkl", "rb"))
q = lambda k: pari(J[k][0]) / pari(J[k][1])
P = pari.polredabs(pari.polcompositum("a^2+1", "a^2-5")[0])
F = pari.nfinit(P)
I_ = pari.nfroots(F, "x^2+1")[0]; S5 = pari.nfroots(F, "x^2-5")[0]
def nfe(c):  # rational -> nf element
    return pari.nfalgtobasis(F, c)
alpha = pari.nfeltadd(F, nfe(q("Re alpha")), pari.nfeltmul(F, I_, nfe(q("Im alpha"))))
beta = pari.nfeltadd(F, nfe(q("Re beta")), pari.nfeltmul(F, I_, nfe(q("Im beta"))))
candidates = {}
for s5sign in (1, -1):
    for isign in (1, -1):
        Ii = I_ if isign == 1 else pari.nfeltmul(F, -1, I_)
        Ss = S5 if s5sign == 1 else pari.nfeltmul(F, -1, S5)
        a = pari.nfeltadd(F, nfe(q("Re alpha")), pari.nfeltmul(F, Ii, nfe(q("Im alpha"))))
        b = pari.nfeltadd(F, nfe(q("Re beta")), pari.nfeltmul(F, Ii, nfe(q("Im beta"))))
        candidates[(s5sign, isign)] = pari.nfeltadd(F, a, pari.nfeltmul(F, b, Ss))
f5 = pari("x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344")
def a5_order(p):
    fa = pari.factormod(f5, p)
    degs = [int(pari.poldegree(fa[0][i])) for i in range(int(pari.matsize(fa)[0]))]
    from math import lcm
    o = 1
    for d in degs: o = lcm(o, d)
    return o, sorted(degs)
proj = {0: {2}, 1: {3}, 4: {1, 5}, 2: {4}, 3: {6}}
for key, j0 in candidates.items():
    jv = pari.nfbasistoalg(F, j0)
    E = pari.ellinit(pari.ellfromj(jv), F)
    ok = bad = tot = 0; mism = []
    for p in pari.primes(400):
        p = int(p)
        if p in (2, 5, 1951): continue
        for Pr in pari.idealprimedec(F, p):
            Np = int(pari.idealnorm(F, Pr)); fdeg = int(Pr[3])
            try:
                red = pari.elllocalred(E, Pr)
                if int(red[0]) != 0: continue                 # bad reduction
                ap = int(pari.ellap(E, Pr))
            except Exception as e:
                continue
            u = (ap * ap * pow(Np, -1, 5)) % 5 if Np % 5 else None
            if u is None: continue
            o, degs = a5_order(p)
            from math import gcd
            oP = o // gcd(o, fdeg)                             # order of Frob_p^f
            tot += 1
            if oP in proj[u]: ok += 1
            else: mism.append((p, fdeg, degs, oP, u))
    print("j0 conjugate (sqrt5 %+d, i %+d): %d primes tested, %d agree, %d disagree %s" % (key[0], key[1], tot, ok, len(mism), mism[:4]))
