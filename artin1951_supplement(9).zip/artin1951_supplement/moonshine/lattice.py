"""Trace form Q(y) = Tr(y^2) on the trace-zero part of O_K, K = Q[x]/(f5).  Search pairs u, v with
B(u, v) = 0 and Q(u) = d Q(v): then y = u + sqrt(-d) v has Tr y = Tr y^2 = 0 over Q(sqrt(-d))."""
import cypari2, itertools, math
from fractions import Fraction as Fr
pari = cypari2.Pari(); pari.allocatemem(10**9)
f = pari("x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344")
nf = pari.nfinit(f)
B = pari.nfbasis(f)            # integral basis as polynomials in x
print("field disc:", pari.factor(nf[2]), " integral basis:", B)
n = 5
Tr = lambda a: pari.nfelttrace(nf, pari.nfalgtobasis(nf, pari.Mod(a, f)))
G = [[int(Tr(B[i]*B[j])) for j in range(n)] for i in range(n)]
t = [int(Tr(B[i])) for i in range(n)]
print("traces of basis:", t)
# trace-zero sublattice: kernel of t (integer)
K0 = pari.matkerint(pari.matrix(1, n, t))   # integer kernel basis (5 x 4)
Gm = pari.matrix(n, n, [G[i][j] for i in range(n) for j in range(n)])
Q0 = pari.mattranspose(K0) * Gm * K0  # 4x4 Gram of the trace-zero lattice
print("Gram (trace-zero lattice):", Q0, " det:", pari.factor(pari.matdet(Q0)))
R = pari.qflllgram(Q0); Q1 = pari.mattranspose(R) * Q0 * R
print("LLL Gram:", Q1)
sv = pari.qfminim(Q1, 8000, 4000)
ncol = int(pari.matsize(sv[2])[1]); vecs = [[int(sv[2][i, k]) for i in range(4)] for k in range(ncol)]; vecs += [[-c for c in v] for v in vecs]
Qf = lambda a: sum(a[i]*a[j]*int(Q1[i, j]) for i in range(4) for j in range(4))
Bf = lambda a, b: sum(a[i]*b[j]*int(Q1[i, j]) for i in range(4) for j in range(4))
print("short vectors:", len(vecs), " minimum norm:", min(Qf(v) for v in vecs))
def sqfree(num):
    num = abs(num); s = 1; p = 2
    while p * p <= num:
        while num % (p*p) == 0: num //= p*p
        if num % p == 0: s *= p; num //= p
        p += 1
    return s * num
best = {}
for u, v in itertools.combinations(vecs, 2):
    if Bf(u, v) != 0: continue
    for (a, b) in ((u, v), (v, u)):
        r = Fr(Qf(a), Qf(b))
        d = sqfree(r.numerator * r.denominator)
        key = d
        if key not in best or Qf(a) + Qf(b) < sum(best[key][2]):
            best[key] = (a, b, (Qf(a), Qf(b)))
for d in sorted(best)[:12]:
    print("d =", d, " u, v =", best[d][0], best[d][1], " Q(u), Q(v) =", best[d][2])
import pickle; pickle.dump({"R": str(R), "K0": str(K0), "best": best, "B": [str(b) for b in B]}, open("lattice.pkl", "wb"))
