import pickle, cypari2, time
pari = cypari2.Pari(); pari.allocatemem(6*10**9); pari.default("parisizemax", 12*10**9)
J = pickle.load(open("j0_exact_600.pkl", "rb"))
q = lambda k: pari(J[k][0]) / pari(J[k][1])
P = pari.polredabs(pari.polcompositum("a^2+1", "a^2-5")[0]); F = pari.nfinit(P)
I_ = pari.nfroots(F, "x^2+1")[0]; S5 = pari.nfroots(F, "x^2-5")[0]
e = lambda c: pari.nfalgtobasis(F, c)
alpha = pari.nfeltadd(F, e(q("Re alpha")), pari.nfeltmul(F, I_, e(q("Im alpha"))))
beta = pari.nfeltadd(F, e(q("Re beta")), pari.nfeltmul(F, I_, e(q("Im beta"))))
j0 = pari.nfbasistoalg(F, pari.nfeltadd(F, alpha, pari.nfeltmul(F, beta, S5)))
fib = pari("(x^2+250*x+3125)^3") - j0 * pari("x^5")
g = pari("x^6 - 75*x^4 - 70*x^3 + 826*x^2 - 210*x - 625")
t = time.time()
# does the sextic resolvent g acquire a root over F(theta), theta a root of the fibre?  Test: factor g over the
# relative extension via nffactor on the absolute field of degree 24.
fibF = pari.lift(fib)
print("fibre irreducible over F:", pari.nfisincl if False else "", len(pari.nffactor(F, fibF)[0]) == 1 if True else "")
Rq = pari.rnfequation(F, fibF, 1)           # [abs poly, a-in-terms, k]
Pabs = Rq[0]
print("absolute degree:", pari.poldegree(Pabs), " size of coefficients (digits):", max(len(str(abs(int(c)))) for c in pari.Vec(Pabs)), flush=True)
Pred = pari.polredbest(Pabs)
print("polredbest done in %.0f s; coefficient digits now %d" % (time.time() - t, max(len(str(abs(int(c)))) for c in pari.Vec(Pred))), flush=True)
Gabs = pari.polredbest(pari.rnfequation(F, g))
r = pari.nfisincl(Gabs, Pred)
print("K6*F embeds in the isogeny field:", r != 0, " (%.0f s)" % (time.time() - t))
