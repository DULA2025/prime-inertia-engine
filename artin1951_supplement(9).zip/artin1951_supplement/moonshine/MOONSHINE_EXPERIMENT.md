# The icosahedral cover X(5) → X(1) and ρ: an explicit elliptic curve

*Dula, 4 Oct 2026.* **Artin's conjecture for ρ remains open.** This experiment produces a new explicit object
attached to ρ itself. It does not prove holomorphy of L(ρ).

## The link to moonshine

| fact | where it comes from | role here |
|---|---|---|
| The cover X(5) → X(1) has Galois group PSL₂(𝔽₅) ≅ A₅. | Klein | Every A₅ field is a fibre of it, possibly over a larger base. |
| The Hauptmodul of X(5) is the Rogers–Ramanujan continued fraction. | Klein, Rogers–Ramanujan | Klein's icosahedral function j(z) is written in it. |
| The Hauptmodul of X₀(5) is η(τ)⁶/η(5τ)⁶, the Monster's 5B McKay–Thompson series (up to a constant). | moonshine | It cuts out the field of 5-isogenies. |

The question was: over which base, and at which j₀, does the A₅ field of ρ appear?

## Results

1. **[T] The parity obstruction, concretely.**
   - For real j, the X₀(5) fibre (t²+250t+3125)³ − j t⁵ has exactly 2 real roots. Complex conjugation acts on E[5] with eigenvalues ±1, so it fixes exactly 2 of the 6 lines.
   - The sextic resolvent of ρ has all 6 roots real.
   - So no elliptic curve over ℚ, or over any field with a real place, has the A₅ field of ρ as its projective 5-torsion field. This is the evenness of ρ in elliptic-curve form.
2. **The obstruction reappears in Klein's resolvent.** Our quintic has 5 real roots, so the principal form Σy = Σy² = 0 needs an imaginary irrationality.
   - The trace form on the trace-zero integers of the quintic field is exactly **1951·A₄** (the A₄ root lattice).
   - Two orthogonal roots u, v of it give the isotropic vector u + i·v. So the smallest accessory irrationality is √−1.
3. **[T] Klein's invariant.** With that choice, Klein's icosahedral invariant of the ρ-ruling lies in the CM field F = ℚ(i, √5):
   - j₀ = α + β√5, with α, β ∈ ℚ(i). The exact values are in `j0_exact.txt`.
   - Common denominator: 29⁵·41⁵·348500149⁵·696201529⁵·1951².
   - The ρ′-ruling is its conjugate under √5 ↦ −√5.
4. **[T] The curve.** E/F with j(E) = j₀ has projective mod-5 representation equal to that of ρ over F.
   - Exact check (`certify_iso.py`): the field of 5-isogenies of E (degree 24) contains K₆·F (degree 24), so the two fields are equal.
   - Numerical check (`verify_E.py`): at 970 primes of F, the projective order of Frobenius on E[5] matches the order of Frobenius in the A₅ field. Control curves j₀+1, 1+i and 1951 fail at about 62% of primes.
   - The arithmetic fits Klein's picture. N(j₀) has cubes (j = H³/f⁵). N(j₀ − 1728) has squares (j − 1728 = T²/f⁵). Denominators are fifth powers, so the mod-5 representation is unramified at those primes. The one exception is 1951.
5. **[T] Restated.** ρ̄_{E,5} ≅ (ρ₀ mod √5)|_{G_F} ⊗ ψ for a character ψ of G_F. This is the even analogue of the Shepherd-Barron–Taylor and Buzzard–Stein constructions. Those exist over ℚ for odd icosahedral representations; for even ρ the base has to be a CM field.

## What it gives and what it does not

- **It passes the barrier test.** E is attached to ρ itself (its mod-5 reduction), not built from other irreducibles.
- **Next question.** If E is modular over F, then ρ₀ mod 5, restricted to F, is automorphic in cohomological weight. Results on elliptic curves over CM fields might cover E (Allen–Khare–Thorne 2023; Caraiani–Newton 2023 over imaginary quadratic fields). **I have not checked their hypotheses for E.** That is the next question [S].
- **The wall (route M2 of `NEW_METHODS.md`).** Getting from that to Artin for ρ|_F, and then by cyclic descent to Artin for ρ, needs a modularity-lifting step from weight 2 down to Artin weight over a CM field. That target is not cohomological. No known method does it.

## Files

`klein.py`, `klein2.py`, `klein3.py`, `klein4.py` (the construction), `lattice.py` (1951·A₄),
`verify_E.py` (Frobenius test), `certify_iso.py` (field equality), `j0_exact.txt`.
