"""Hejhal's method on Gamma0(N), N = 1951 prime, nebentypus chi (f(gamma z) = chi(d) f(z)), weight 0, lambda = 1/4 (r = 0).

Unknowns (no Frobenius input anywhere):
  f(z)      = sum_{n>=1} c_n sqrt(y) K_0(2 pi n y) (e(nx) + eps e(-nx))       expansion at the cusp oo
  g(w) := f(W w), W w = -1/(N w):  g(w) = sum_{n>=1} b_n sqrt(v) K_0(2 pi n v) (e(nu) + eps e(-nu))   cusp 0
(J f(z) = f(-zbar) preserves the chi-space, so eigenforms have a parity eps = +-1; g has the same eps.)
Pullback: z = M z1, z1 in the SL2(Z) fundamental domain, M = [[a,b],[c,d]].
  N | c  : f(z) = chi(d) f(z1)                                           (height y1 >= sqrt3/2)
  else   : M = delta tau_j, tau_j = [[0,-1],[1,j]], j = d c^{-1} mod N, delta in Gamma0(N) with lower-right c:
           f(z) = chi(c) g((z1 + j)/N)                                    (height y1/N >= sqrt3/(2N))
Equations: n-th Fourier coefficient on the horocycle Im = Y (Y < sqrt3/(2N)) of f (rows n of the c-block) and of g
(rows of the b-block), each computed by FFT from the pulled-back expansions.  Normalisation c_1 = 1.
Usage: python3 hejhal.py EPS Y M [conj]      (conj: use chi-bar as nebentypus, a control)
Author: Dula."""
import sys, time, json, math, numpy as np
from scipy.special import k0, kv
import os
R = float(os.environ.get("R", "0"))
def Kfun(x):
    """K_{ir}(x) for small r: K_0(x) - (r^2/2) d^2K_nu/dnu^2|_0 (+O(r^4)); second derivative by symmetric difference in nu."""
    if R == 0: return k0(x)
    h = 1e-2
    return k0(x) - (R * R / 2) * 2 * (kv(h, x) - k0(x)) / (h * h)
from scipy.linalg import solve
N = 1951
eps = int(sys.argv[1]); Y = float(sys.argv[2]); M = int(sys.argv[3]); conj = len(sys.argv) > 4 and sys.argv[4] == "conj"
tag = "eps%+d_Y%.2e_M%d%s" % (eps, Y, M, "_conj" if conj else "") + ("_k%s" % __import__("os").environ.get("KPOW", "1") if __import__("os").environ.get("KPOW", "1") != "1" else "") + (("_r%.3f" % float(__import__("os").environ.get("R", "0"))) if float(__import__("os").environ.get("R", "0")) else "")
dl = np.zeros(N, np.int64); xx = 1
for k in range(N - 1): dl[xx] = k; xx = xx * 3 % N
KPOW = int(__import__("os").environ.get("KPOW", "1"))                 # nebentypus chi^KPOW
CH = np.zeros(N, complex); CH[1:] = np.exp(2j * np.pi / 5) ** ((2 * KPOW * dl[1:]) % 5)
if conj: CH = np.conj(CH)
def chi(n): return CH[np.mod(n, N)]

def pullback(z):
    x, y = z.real.copy(), z.imag.copy()
    a = np.ones_like(x, np.int64); b = np.zeros_like(a); c = np.zeros_like(a); d = np.ones_like(a)
    for it in range(10000):
        k = np.floor(x + 0.5).astype(np.int64); x = x - k
        b, d = a * k + b, c * k + d                              # M <- M T^k
        r2 = x * x + y * y; s = r2 < 1 - 1e-13
        if not s.any(): break
        x[s], y[s] = -x[s] / r2[s], y[s] / r2[s]                 # z <- -1/z
        a[s], b[s], c[s], d[s] = -b[s], a[s], -d[s], c[s]        # M <- M S^{-1}
    z1 = x + 1j * y
    err = np.abs((a * z1 + b) / (c * z1 + d) - z).max()
    return z1, a, b, c, d, err

def classify(z):
    z1, a, b, c, d, err = pullback(z)
    inf = (c % N) == 0
    xs, ys, mult = z1.real.copy(), z1.imag.copy(), np.zeros(len(z), complex)
    mult[inf] = chi(d[inf])
    cz = c[~inf] % N
    j = (d[~inf] % N) * np.array([pow(int(v), -1, N) for v in cz]) % N
    w = (z1[~inf] + j) / N
    xs[~inf], ys[~inf] = w.real, w.imag
    mult[~inf] = chi(c[~inf])
    return xs, ys, mult, inf, err

Q = M + 20; P = 2 * Q
mm = np.arange(P); xm = (mm - Q + 0.5) / P
phase = np.exp(-2j * np.pi * np.arange(P) * (-Q + 0.5) / P)
t0 = time.time()
hor = {}
hor["c"] = classify(xm + 1j * Y)                                  # f on Im z = Y
wm = xm + 1j * Y; hor["b"] = classify(-1 / (N * wm))              # g on Im w = Y, i.e. f at W w
for h in "cb":
    xs, ys, mult, inf, err = hor[h]
    print("horocycle %s: pullback err %.1e, %d points to oo, %d to 0, min height %.3e (Y = %.2e, sqrt3/2N = %.3e)" %
          (h, err, inf.sum(), (~inf).sum(), ys.min(), Y, math.sqrt(3) / (2 * N)), flush=True)
    assert ys.min() > Y
V = np.zeros((2 * M, 2 * M), complex)
diag = np.sqrt(Y) * Kfun(2 * np.pi * np.arange(1, M + 1) * Y)
V[np.arange(M), np.arange(M)] = diag; V[M + np.arange(M), M + np.arange(M)] = diag
for hi, h in enumerate("cb"):
    xs, ys, mult, inf, err = hor[h]
    sq = np.sqrt(ys)
    for l in range(1, M + 1):
        base = mult * sq * Kfun(2 * np.pi * l * ys) * (np.exp(2j * np.pi * l * xs) + eps * np.exp(-2j * np.pi * l * xs))
        for ti, msk in ((0, inf), (1, ~inf)):
            v = np.where(msk, base, 0)
            col = (phase * np.fft.fft(v))[1:M + 1] / P
            V[hi * M:(hi + 1) * M, ti * M + l - 1] -= col
print("assembled %dx%d in %.0fs" % (2 * M, 2 * M, time.time() - t0), flush=True)
# normalise b_1 = 1 (the b-columns are strongly coupled; on the oo-horocycle every point pulls back to cusp 0, so the
# c_1 column is nearly free and c_1 = 1 would only fix an arbitrary scale); keep every c-row, drop b-row n = 1.
keep = np.r_[0:M, M + 1:2 * M]
rhs = -V[keep, M].copy()
A = V[np.ix_(keep, keep)]
del V
sol = solve(A, rhs, overwrite_a=True, overwrite_b=True, check_finite=False)
c = sol[:M]; bco = np.concatenate([[1.0 + 0j], sol[M:]])
s0 = c[0]; c = c / s0; bco = bco / s0
print("solved in %.0fs" % (time.time() - t0), flush=True)
json.dump(dict(eps=eps, Y=Y, M=M, conj=conj, c=[[v.real, v.imag] for v in c[:2000]], b=[[v.real, v.imag] for v in bco[:2000]]),
          open("/home/claude/research/maass/hejhal_%s.json" % tag, "w"))
ch = lambda n: CH[n % N]
print("c_2..c_7:", np.round(c[1:7], 6))
print("Hecke checks: |c4 - (c2^2 - chi(2))| = %.2e   |c6 - c2 c3| = %.2e   |c9 - (c3^2 - chi(3))| = %.2e   |c10 - c2 c5| = %.2e" %
      (abs(c[3] - (c[1] ** 2 - ch(2))), abs(c[5] - c[1] * c[2]), abs(c[8] - (c[2] ** 2 - ch(3))), abs(c[9] - c[1] * c[4])))
print("b_1..b_3:", np.round(bco[:3], 6), "  b_n / conj(c_n), n=1..5:", np.round(bco[:5] / np.conj(c[:5]), 6))
