"""H2/H3  Validate the Hejhal solutions and compare with rho.  Author: Dula.
Tests WITHOUT rho data:
  (i)   Y-consistency: solutions at Y = 4.0e-4 (M=5000) and 3.6e-4 (M=5500) agree;
  (ii)  Hecke multiplicativity  c_m c_n = sum_{d|(m,n)} chi(d) c_{mn/d^2};
  (iii) Ramanujan |c_p| <= 2;
  (iv)  Atkin-Lehner: b_n = eta * conj(c_n) with |eta| = 1 (Atkin-Li for newforms);
  (v)   icosahedral signature: u_p = c_p^2 / chi(p) is real and lies in {0, 1, phi^-2, phi^2, 4}
        (= tr^2/det of an element of projective order 2, 3, 5, 5, 1 in a 2-dim rep with det chi).
Then WITH rho data: c_p vs tr rho(Frob_p) = t_p chi(p)^3, and the projective orders vs the A5 class of Frob_p."""
import json, math, sys, numpy as np
sys.path.insert(0, "/home/claude/research/div"); from dcore import coeffs, traces
N = 1951; PHI = (1 + 5 ** .5) / 2
dl = np.zeros(N, np.int64); xx = 1
for k in range(N - 1): dl[xx] = k; xx = xx * 3 % N
CH = np.zeros(N, complex); CH[1:] = np.exp(2j * np.pi / 5) ** ((2 * dl[1:]) % 5)
ch = lambda n: CH[n % N]
def load(f):
    d = json.load(open(f)); return np.array([complex(*v) for v in d["c"]]), np.array([complex(*v) for v in d["b"]])
runs = {"main": "hejhal_eps-1_Y4.00e-04_M5000.json", "Y2": "hejhal_eps-1_Y3.60e-04_M5500.json",
        "parity+1": "hejhal_eps+1_Y4.00e-04_M5000.json", "conj": "hejhal_eps-1_Y4.00e-04_M5000_conj.json"}
C = {k: load(v) for k, v in runs.items()}
L = 800
a = coeffs("rho", 2000, a1951=np.exp(4j * np.pi / 5))[1:L + 1]
out = {}
def hecke_defect(c, chf, lim=800):
    worst = 0
    for m in range(2, 60):
        for n in range(m, lim // m + 1):
            g = math.gcd(m, n); s = sum(chf(dd) * c[m * n // dd ** 2 - 1] for dd in range(1, g + 1) if g % dd == 0)
            worst = max(worst, abs(c[m - 1] * c[n - 1] - s))
    return worst
primes = [p for p in range(2, L + 1) if all(p % q for q in range(2, int(p ** .5) + 1))]
for k, (c, b) in C.items():
    chf = (lambda n: np.conj(ch(n))) if k == "conj" else ch
    r = dict(hecke=hecke_defect(c, chf), ramanujan_max=float(max(abs(c[p - 1]) for p in primes if p != N)))
    eta = b[:200] / np.conj(c[:200]); nz = np.abs(c[:200]) > 0.1
    r["eta"] = [complex(np.median(eta[nz].real), np.median(eta[nz].imag)).real, float(np.median(eta[nz].imag))]
    r["eta_spread"] = float(np.abs(eta[nz] - complex(*r["eta"])).max())
    u = np.array([c[p - 1] ** 2 / chf(p) for p in primes if p != N])
    r["u_imag_max"] = float(np.abs(u.imag).max())
    targets = np.array([0, 1, PHI ** -2, PHI ** 2, 4])
    r["u_dist_max"] = float(np.min(np.abs(u.real[:, None] - targets[None, :]), axis=1).max())
    if k in ("main", "Y2"): r["vs_rho"] = float(np.abs(c[:L] - a).max())
    if k == "conj": r["vs_conj_rho"] = float(np.abs(c[:L] - np.conj(a)).max())
    if k == "parity+1": r["vs_rho"] = float(np.abs(c[:L] - a).max())
    out[k] = r
    print("%-9s Hecke defect %.1e | max|c_p| %.3f | eta = %.6f%+.6fi spread %.1e | u_p: max Im %.1e, max dist to {0,1,phi^-2,phi^2,4} %.1e | %s" %
          (k, r["hecke"], r["ramanujan_max"], r["eta"][0], r["eta"][1], r["eta_spread"], r["u_imag_max"], r["u_dist_max"],
           ("vs rho %.1e" % r["vs_rho"]) if "vs_rho" in r else ("vs conj(rho) %.1e" % r.get("vs_conj_rho", float("nan")))))
cm, cy = C["main"][0], C["Y2"][0]
out["Y_consistency"] = float(np.abs(cm[:L] - cy[:L]).max()); print("Y-consistency max |c(Y1) - c(Y2)|, n <= 800: %.1e" % out["Y_consistency"])
# projective order from u_p vs A5 class of Frob_p
D = traces(); cls = D["cls"]
order = {0: 2, 1: 3, 2: 5, 3: 5, 4: 1}; targets = np.array([0, 1, PHI ** -2, PHI ** 2, 4])
agree = tot = 0; table = {}
for p in primes:
    if p == N: continue
    u = (cm[p - 1] ** 2 / ch(p)).real; o = order[int(np.argmin(np.abs(targets - u)))]
    clsp = cls[str(p)]; oc = {"id": 1, "1A": 1, "2A": 2, "2B": 2, "3A": 3, "5A": 5, "5B": 5}.get(clsp, None)
    table.setdefault((clsp, o), 0); table[(clsp, o)] += 1
    tot += 1; agree += (oc == o)
print("projective order read from the Maass form vs A5 class of Frob_p (f5 data), p <= 800: %d/%d agree" % (agree, tot), table)
out["proj_order_agree"] = [agree, tot]; out["table"] = {"%s->%d" % k: v for k, v in table.items()}
out["c_main"] = [[v.real, v.imag] for v in cm[:L]]; out["a_rho"] = [[v.real, v.imag] for v in a]
out["c_Y2"] = [[v.real, v.imag] for v in cy[:L]]; out["c_par"] = [[v.real, v.imag] for v in C["parity+1"][0][:L]]
out["c_conj"] = [[v.real, v.imag] for v in C["conj"][0][:L]]
json.dump(out, open("h_compare.json", "w"))
