# The level-1951 Maass form from the Laplacian alone  (Dula, 9 Oct 2026)

**Artin's conjecture for ρ remains open.** This is numerical evidence [N]. It is not a construction of a Galois representation.

**Inputs to Hejhal's method:** level 1951, nebentypus χ (= det ρ), odd parity, λ = ¼ (r = 0). Nothing else. No Frobenius trace or coefficient of ρ enters.
**Unknowns:** c₁…c_M at the cusp ∞ and b₁…b_M at the cusp 0 (via the Fricke involution), with M = 5000 or 5500.
**Method:** pull each sample point back to SL₂(ℤ)\H and split by coset into the ∞ type or the 0 type, then assemble the linear system by FFT.
**Normalisation:** b₁ = 1. On the ∞ horocycle every sample point pulls back to the cusp 0, so the c₁ column is almost free. A first run with c₁ = 1 gave c_n = κ·a_n(ρ) with κ = 0.938·e^{0.06i}, uniformly to 4e−7.

| check | result |
|---|---|
| c_n vs a_n(ρ) = tr ρ(Frobₙ), all n ≤ 800 | max 3e−7 (Y = 4.0e−4, M = 5000); 3e−8 (Y = 3.6e−4, M = 5500) |
| Y-consistency, n ≤ 800 | 4e−7 |
| Hecke multiplicativity c_m c_n = Σ_{d\|(m,n)} χ(d) c_{mn/d²} | defect 5e−7 / 5e−8 |
| Ramanujan bound | max \|c_p\| = 2.000 |
| u_p = c_p²/χ(p) (computed with no ρ data) | real to 3e−7 and in {0, φ⁻², 1, φ², 4} to 4e−7, i.e. projective order 2, 5, 3, 5, 1 |
| projective order vs residue degrees of f₅ (maximal order, index primes included), p ≤ 800 | 139/139 |
| 5A vs 5B (the √5 sign, ρ vs ρ″): u_p = φ⁻² vs φ² against the degree-24 Frobenius labels (f₅ cannot tell 5A from 5B) | 24/24 and 23/23 |
| untwisted traces c_p·χ̄(p)³ | real to 2e−7 and in the SL(2,5) trace set ⊂ ℤ[φ] to 1e−7 |
| Atkin–Lehner, not imposed: b_n = η·conj(c_n) | η = 0.450140 + 0.892958i (spread 3e−7) = −W(ρ) from the theta FE fit |
| control: even parity | Hecke defect 6.6, \|c − a\| ~ 1: no form |
| control: nebentypus χ̄ | gives conj(tr ρ) to 3e−7 (the form of ρ̄) |
| control: r = 0.03, 0.1 (λ = 0.2509, 0.26) | Hecke defect 0.24 and 3.7; Y-drift 2e−3 and 2e−2: no eigenform. The K_{ir} kernel (Taylor in r) has relative error 1e−5 at r = 0.03 and 1.5e−3 at r = 0.1 against mpmath: the failure is real, not its third digit |

**What this is.**
- It is numerical evidence that a cuspidal Maass newform with λ = ¼, level 1951 and nebentypus χ exists, and that its Hecke eigenvalues are tr ρ(Frob_p).
- That is the "Maass to Galois" half seen in data: the Laplacian alone yields a form whose eigenvalues show an icosahedral signature, and those eigenvalues equal the traces of the known ρ.

**What it is not.**
- It is not a proof that the form exists. It is a truncated linear system solved in double precision.
- It does not attach a Galois representation to the form.
- It does not prove modularity, and so it does not prove Artin.
- On Booker's hypothesis: the c_p lie in ℤ[ζ₅], not ℤ[φ]. The twist f ⊗ χ̄³ (level 1951²) has the ℤ[φ] coefficients, and its √5-conjugate is a second form at level 1951², beyond this machine. So the note's hypotheses are not verified here.
- The relevant theory is Booker (arXiv:1712.06876). For a non-dihedral Hecke–Maass newform with coefficients in ℤ[φ] that satisfies a Galois-conjugacy condition, it proves icosahedral-type consequences (weak automorphy of symmetric powers, Chebotarev-type densities). It explicitly does not reach an associated Galois representation.

Files: `hejhal.py`, `h_compare.py`, `plot_hejhal.py`, `hejhal_maass.png`, `h_compare.json`, `h_rcontrol.json`, `hejhal_*.json`, `h_*.log`.

## The √5-conjugate partner at level 1951 and a splitting law for the quintic (quartet.py, reciprocity.py)
**Why level 1951 is enough.** On inertia at 1951, ρ₀ has eigenvalues χ^{∓3}. The automorphism σ (√5 ↦ −√5) squares them, so ρ₀″ has χ^{∓1}, and ρ₀″⊗χ has {1, χ²}. That is conductor 1951 with nebentypus χ². So the conjugate form needed for Booker's condition does not require level 1951². (Last round both Grok and I had said it did.)

**Results** [N]: odd forms, λ = ¼, inputs are only the level, the nebentypus and the parity.

| nebentypus | form found | check |
|---|---|---|
| χ | ρ = ρ₀⊗χ³ | Hecke defect 4e−8 |
| χ² | ρ₀″⊗χ | Hecke defect 1e−8; Y-consistency 2e−6 for n ≤ 2000 |
| χ³ | conjugate of the χ² form | agrees to 4e−12 |
| χ⁴ | ρ̄ | agrees to 3e−7 |
| χ², even parity (control) | none | Hecke defect 9.6 |

**Booker's conjugacy condition, with no ρ data.** The untwisted coefficients a_p(g) = c_p·χ̄(p)³ and a_p(g″) = c″_p·χ̄(p) are real, lie in ℤ[φ], and satisfy a_p(g″) = σ(a_p(g)) to 1.3e−7 at all 302 primes below 2000.

**Splitting law for the quintic.** #roots of f₅ mod p = 1 + c_p·c″_p·χ̄(p)⁴ holds exactly at all 302 primes below 2000; the largest numerical error is 5e−7.
- The left side comes from PARI's maximal order.
- The right side uses only the two Maass forms.
- Root counts observed: 0 roots at 119 primes, 1 at 74, 2 at 108, 5 at 1. Chebotarev predicts the proportions 24 : 15 : 20 : 1.

**Against the Frobenius data, n ≤ 2000:** max error 6e−7 (χ form) and 3e−7 (χ² form). The slow rise with n is truncation, as Grok predicted.

**Still not:**
- a rigorous existence proof;
- a verification of Booker's hypothesis for all p (no finite computation can do that);
- a Galois representation;
- Artin.
