"""Q  The icosahedral quartet at level 1951 and Booker's conjugacy condition, from the Laplacian alone.
Forms (odd, lambda = 1/4, level 1951): nebentypus chi^1 (f ~ rho = rho0 x chi^3), chi^4 (conj f),
chi^2 (f'' ~ rho0'' x chi, the sqrt5-conjugate twisted down to level 1951), chi^3 (conj f'').
Booker (arXiv:1712.06876) is about a Z[phi] newform whose Galois conjugate is also a Maass form.  Here:
  g = f x chibar^3 has a_p = c_p chibar(p)^3 (level 1951^2, trivial nebentypus), and
  g'' = f'' x chibar has a_p = c''_p chibar(p)  (level 1951^2).
Test, with NO rho data: a_p(g) and a_p(g'') are real, lie in Z[phi], and a_p(g'') = sigma(a_p(g)), sigma: sqrt5 -> -sqrt5.
Then compare with the Frobenius data.  Author: Dula.  [N]  Artin's conjecture for rho remains open."""
import json, math, sys, numpy as np
sys.path.insert(0, "/home/claude/research/div"); from dcore import coeffs
N = 1951; PHI = (1 + 5 ** .5) / 2
dl = np.zeros(N, np.int64); xx = 1
for k in range(N - 1): dl[xx] = k; xx = xx * 3 % N
chi = lambda n, k=1: np.exp(2j * np.pi / 5) ** ((2 * k * dl[n % N]) % 5)
def ld(f): return np.array([complex(*v) for v in json.load(open(f))["c"]])
f1 = ld("hejhal_eps-1_Y3.60e-04_M5500.json")
f2 = ld("hejhal_eps-1_Y3.60e-04_M5500_k2.json"); f2b = ld("hejhal_eps-1_Y4.00e-04_M5000_k2.json")
f3 = ld("hejhal_eps-1_Y3.60e-04_M5500_k3.json"); f2e = ld("hejhal_eps+1_Y3.60e-04_M5500_k2.json")
L = len(f1)
nn = np.arange(1, L + 1); cop = nn % N != 0
def hecke(c, k, lim=400):
    w = 0
    for m in range(2, 40):
        for n in range(m, lim // m + 1):
            g = math.gcd(m, n); s = sum(chi(e, k) * c[m * n // e ** 2 - 1] for e in range(1, g + 1) if g % e == 0); w = max(w, abs(c[m - 1] * c[n - 1] - s))
    return w
out = {}
for name, c, k in (("f (chi)", f1, 1), ("f'' (chi^2)", f2, 2), ("f'' (chi^2), Y1", f2b, 2), ("conj f'' (chi^3)", f3, 3), ("chi^2, EVEN control", f2e, 2)):
    out[name] = dict(hecke=hecke(c, k)); print("%-22s Hecke defect %.1e" % (name, out[name]["hecke"]))
print("f'' Y-consistency (n <= 2000): %.1e" % np.abs(f2[:2000] - f2b[:2000]).max())
print("chi^3 form vs conj(chi^2 form): %.1e" % np.abs(f3 - np.conj(f2)).max())
primes = [p for p in range(2, L + 1) if p != N and all(p % q for q in range(2, int(p ** .5) + 1))]
T = np.array([2, -2, 0, 1, -1, PHI, -PHI, PHI - 1, 1 - PHI]); S = np.array([2, -2, 0, 1, -1, 1 - PHI, PHI - 1, -PHI, PHI])   # sigma
ag, ag2, rows = [], [], []
for p in primes:
    x = f1[p - 1] * np.conj(chi(p)) ** 3; y = f2[p - 1] * np.conj(chi(p))
    i = int(np.argmin(np.abs(T - x.real)))
    rows.append((p, x.real, x.imag, y.real, y.imag, float(T[i]), float(S[i])))
rows = np.array(rows)
sig_err = np.abs(rows[:, 3] - rows[:, 6]); dist = np.abs(rows[:, 1] - rows[:, 5])
print("untwisted g = f x chibar^3: max |Im| %.1e, max distance to Z[phi] trace set %.1e  (%d primes < %d)" % (np.abs(rows[:, 2]).max(), dist.max(), len(primes), L))
print("untwisted g'' = f'' x chibar: max |Im| %.1e;  max |a_p(g'') - sigma(a_p(g))| = %.1e   <- Booker's conjugacy, no rho data" % (np.abs(rows[:, 4]).max(), sig_err.max()))
for lim in (800, 1500, 2000):
    m = rows[:, 0] < lim; print("   primes < %d: max sigma-error %.1e" % (lim, sig_err[m].max()))
# with rho data
a1 = coeffs("rho", L + 5, a1951=np.exp(4j * np.pi / 5))[1:L + 1]
app = coeffs("rho0pp", L + 5)[1:L + 1] * np.array([chi(n) if n % N else 0 for n in nn])
e1 = np.abs(f1 - a1)[cop]; e2 = np.abs(f2 - app)[cop]
for lim in (800, 1500, 2000):
    m = nn[cop] <= lim
    print("n <= %d (coprime to 1951): |f - a(rho)| max %.1e ;  |f'' - a(rho0'' x chi)| max %.1e" % (lim, e1[m].max(), e2[m].max()))
print("even-parity chi^2 control vs rho0'' x chi: max %.1e" % np.abs(f2e - app)[cop][:800].max())
out.update(dict(rows=rows.tolist(), err_f=e1.tolist(), err_f2=e2.tolist(), n_cop=nn[cop].tolist(), sigma_err_max=float(sig_err.max())))
json.dump(out, open("quartet.json", "w"))
