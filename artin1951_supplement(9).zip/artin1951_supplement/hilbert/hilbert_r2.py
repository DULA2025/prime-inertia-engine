"""H1 over the real quadratic field F = Q(sqrt2), numerically (Direction 4 of the relayed list; the third field of the
three-field variant in Remark 3.8(2) of the note; the test is reported in Remark 3.10).  Is the Galois series of
rho|G_F a Hilbert-Maass form for Gamma_0(1951 O_F) with nebentypus chi(N d)?

  f(z) = sum_{0 != alpha in O_F} c((alpha)) s(alpha) sqrt(y1 y2) K_0(2 pi |nu1| y1) K_0(2 pi |nu2| y2) e(nu1 x1 + nu2 x2),
  nu = alpha / (2 sqrt2) in the inverse different, nu1 = alpha1/(2 sqrt2), nu2 = -alpha2/(2 sqrt2),

on H x H, with alpha1 = x + y sqrt2, alpha2 = x - y sqrt2 the real embeddings of alpha = x + y sqrt2.  F has narrow class
number 1 (the unit 1 + sqrt2 has norm -1), so this is the expansion at the cusp infinity of the newform attached to
rho|G_F if H1 holds for F.  rho(c) = -I, so the archimedean type at both real places is pi(sgn, sgn), whose Whittaker
function is sgn(y) sqrt|y| K_0(2 pi |y|): s(alpha) = sgn(nu1) sgn(nu2) (variant "odd, odd"; the other parities are
controls).  Each term is an eigenfunction of both Laplacians with eigenvalue 1/4.
Ideal coefficients (rho unramified away from 1951; a_p = chi(p)^3 t_p):
  p = +-1 mod 8 (split): c(P^a Pbar^b) = h_a h_b, h_1 = a_p, h_{j+1} = a_p h_j - chi(p) h_{j-1}
  p = +-3 mod 8 (inert):  c((p)^j) = g_j, g_1 = a_p^2 - 2 chi(p), g_{j+1} = g_1 g_j - chi(p)^2 g_{j-1}
  2 = (sqrt2)^2:          c((sqrt2)^j) = h_j(a_2, chi(2))
  1951 = P Pbar (split):  c = a_1951^(a+b), a_1951 = zeta5^2 (conductor exponent 1 at each prime)
Test: gamma = (a b; 1951 d) in SL_2(O_F), z and gamma z at heights ~ 1/1951 in both factors; defect |f(gz) - chi(Nd) f(z)|/|f(z)|.
Usage: python3 hilbert_r2.py C NPAIRS SEED PART NPART   (terms with |nu_j| y_j <= C; rows y = PART mod NPART)
Author: Dula."""
import sys, json, time, math, numpy as np, numba as nb
from scipy.special import k0
sys.path.insert(0, "/home/claude/research/bianchi")
from bianchi import sieve_spf, load_codes, DL5, T_OF_CODE, Z5, chi, N0

C = float(sys.argv[1]); NPAIRS = int(sys.argv[2]); SEED = int(sys.argv[3])
PART = int(sys.argv[4]) if len(sys.argv) > 4 else 0; NPART = int(sys.argv[5]) if len(sys.argv) > 5 else 1
S2 = 2 ** 0.5
A1951 = Z5[2]
assert N0 % 8 in (1, 7), "1951 must split in Q(sqrt2)"

def mul(u, v): a, b = u; c, d = v; return (a * c + 2 * b * d, a * d + b * c)
def norm(u): a, b = u; return a * a - 2 * b * b
def conj(u): a, b = u; return (a, -b)
def emb(u): a, b = u; return (a + b * S2, a - b * S2)

def make_gamma(d):
    n = norm(d) % N0; inv = pow(n, -1, N0); cd = conj(d)
    a = ((cd[0] * inv) % N0, (cd[1] * inv) % N0)
    ad = mul(a, d)
    assert (ad[0] - 1) % N0 == 0 and ad[1] % N0 == 0
    b = ((ad[0] - 1) // N0, ad[1] // N0); c = (N0, 0)
    det = (mul(a, d)[0] - mul(b, c)[0], mul(a, d)[1] - mul(b, c)[1])
    assert det == (1, 0)
    return a, b, c, d

def act(g, z):                      # z = (z1, z2) complex in H x H; g in SL_2(O_F) acting through both embeddings
    a, b, c, d = (emb(u) for u in g)
    return tuple((a[j] * z[j] + b[j]) / (c[j] * z[j] + d[j]) for j in range(2))

rng = np.random.default_rng(SEED)
pairs = []
while len(pairs) < NPAIRS:
    d = (int(rng.integers(-N0, N0)), int(rng.integers(-N0, N0)))
    if norm(d) % N0 == 0: continue
    gam = make_gamma(d); de = emb(d)
    z = tuple(complex(-de[j] / N0 + rng.uniform(-0.3, 0.3) / N0, rng.uniform(0.9, 1.1) / N0) for j in range(2))
    pairs.append(dict(d=d, gam=gam, P=z, Q=act(gam, z), nu=chi(norm(d) % N0)))
pts = []
for pr in pairs: pts += [pr["P"], pr["Q"]]
X1 = np.array([p[0].real for p in pts]); Y1 = np.array([p[0].imag for p in pts])
X2 = np.array([p[1].real for p in pts]); Y2 = np.array([p[1].imag for p in pts])
R1 = 2 * S2 * C / Y1.min(); R2 = 2 * S2 * C / Y2.min()
NMAX = int(R1 * R2) + 10
print("C = %.2f, %d pairs, heights %.2e .. %.2e, |alpha_j| <= %.0f, %.0f, |N alpha| <= %.3e, part %d/%d"
      % (C, NPAIRS, min(Y1.min(), Y2.min()), max(Y1.max(), Y2.max()), R1, R2, NMAX, PART, NPART), flush=True)

@nb.njit(cache=True)
def _hseq(a, w, j):
    h0 = 1.0 + 0j
    if j == 0: return h0
    h1 = a
    for _ in range(j - 1): h0, h1 = h1, a * h1 - w * h0
    return h1

@nb.njit(cache=True)
def _gcd(a, b):
    while b: a, b = b, a % b
    return a

@nb.njit(cache=True)
def row_coeffs_r2(y, xs, spf, code, dl5, Tc, z5, a1951, flipcode, pert_p, pert_amt):
    n = xs.shape[0]; out = np.empty(n, dtype=np.complex128)
    for i in range(n):
        x = xs[i]
        N = x * x - 2 * y * y
        M = abs(N)
        g = _gcd(abs(x), abs(y))
        c = 1.0 + 0j
        while M > 1:
            p = spf[M]; e = 0
            while M % p == 0:
                M //= p; e += 1
            if p == 1951:
                c *= a1951 ** e; continue
            dlp = dl5[p % 1951]; chip = z5[(2 * dlp) % 5]
            cd = code[p]
            if flipcode >= 0 and cd >= 5:
                if cd == 5: cd = 6
                elif cd == 6: cd = 5
                elif cd == 7: cd = 8
                else: cd = 7
            ap = z5[dlp % 5] * Tc[cd]
            if p == pert_p: ap = ap + pert_amt
            if p == 2:
                c *= _hseq(ap, chip, e)
            elif p % 8 == 1 or p % 8 == 7:
                kc = 0; gg = g
                while gg % p == 0 and kc * 2 < e:
                    gg //= p; kc += 1
                c *= _hseq(ap, chip, e - kc) * _hseq(ap, chip, kc)
            else:
                A2 = ap * ap - 2.0 * chip
                c *= _hseq(A2, chip * chip, e // 2)
        out[i] = c
    return out

t0 = time.time()
spf = sieve_spf(NMAX); code = load_codes(NMAX)
print("sieve + codes to %.3e: %.0fs" % (NMAX, time.time() - t0), flush=True)
COEF = [("rho", -1, 0, 0.0), ("a_2 + 1e-3", -1, 2, 1e-3), ("sqrt5-conjugate traces", 0, 0, 0.0)]
SIGNS = ["odd,odd", "even,even", "odd,even"]
nv = len(COEF) * len(SIGNS); npt = len(pts)
S = np.zeros((nv, npt), dtype=np.complex128); S1 = np.zeros_like(S)
C1 = 0.8 * C
f1 = 2 * np.pi / (2 * S2)
ymax = int((R1 + R2) / (2 * S2)) + 2
t0 = time.time(); nterms = 0
rows = [yy for yy in range(-ymax, ymax + 1) if (yy % NPART) == PART]
for k, yy in enumerate(rows):
    lo = max(-R1 - yy * S2, -R2 + yy * S2); hi = min(R1 - yy * S2, R2 + yy * S2)
    if hi < lo: continue
    xs = np.arange(math.ceil(lo), math.floor(hi) + 1, dtype=np.int64)
    if yy == 0: xs = xs[xs != 0]
    if xs.size == 0: continue
    a1 = xs + yy * S2; a2 = xs - yy * S2
    nterms += xs.size
    u1 = f1 * np.abs(a1)[None, :] * Y1[:, None]; u2 = f1 * np.abs(a2)[None, :] * Y2[:, None]
    keep = (u1 <= 2 * np.pi * C) & (u2 <= 2 * np.pi * C)
    W = np.where(keep, np.sqrt(Y1 * Y2)[:, None] * k0(np.minimum(u1, 700)) * k0(np.minimum(u2, 700)), 0.0) \
        * np.exp(1j * f1 * (a1[None, :] * X1[:, None] - a2[None, :] * X2[:, None]))
    keep1 = (u1 <= 2 * np.pi * C1) & (u2 <= 2 * np.pi * C1)
    W1 = np.where(keep1, W, 0.0)
    sgn = {"odd,odd": np.sign(a1 * a2) * -1.0, "even,even": np.ones_like(a1), "odd,even": np.sign(a1)}
    v = 0
    for name, flip, pp, amt in COEF:
        cvec = row_coeffs_r2(yy, xs, spf, code, DL5, T_OF_CODE, Z5, A1951, flip, pp, amt)
        for sname in SIGNS:
            cv = cvec * sgn[sname]
            S[v] += W @ cv; S1[v] += W1 @ cv; v += 1
    if k % 500 == 0:
        print("  row %d / %d (y = %d), terms %d  (%.0fs)" % (k, len(rows), yy, nterms, time.time() - t0), flush=True)
print("part done: %d terms, %.0fs" % (nterms, time.time() - t0), flush=True)
names = ["%s | %s" % (cn[0], sn) for cn in COEF for sn in SIGNS]
np.savez("hr2_C%.2f_s%d_part%dof%d.npz" % (C, SEED, PART, NPART), S=S, S1=S1, names=np.array(names),
         nu=np.array([pr["nu"] for pr in pairs]), d=np.array([pr["d"] for pr in pairs]),
         P=np.array([[pr["P"][0], pr["P"][1]] for pr in pairs]), Q=np.array([[pr["Q"][0], pr["Q"][1]] for pr in pairs]),
         nterms=nterms)
