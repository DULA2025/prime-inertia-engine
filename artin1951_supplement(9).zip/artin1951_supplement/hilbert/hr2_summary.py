"""Summary of the Q(sqrt2) test for the note and the READMEs.  Usage: python3 hr2_summary.py hr2_C3.00_s2.json
Prints, for each variant, the largest relative defect over the gamma (nebentypus chi(N d) and its conjugate) and the
largest |sum(C) - sum(0.8C)| relative to |f(P)|; then the numbers quoted in Remark 3.10 of the note.
Author: Dula."""
import sys, json
R = json.load(open(sys.argv[1]))
V = R["variants"]
print("C = %.2f, seed %d, %d terms, %d gamma" % (R["C"], R["seed"], R["nterms"], len(V["rho | odd,odd"]["defect"])))
for k, v in V.items():
    print("%-40s chi(Nd) %.2e   conj chi %.2e   conv %.2e" % (k, max(v["defect"]), max(v["defect_conj"]), max(v["conv"])))
rho = max(V["rho | odd,odd"]["defect"])
a2 = max(V["a_2 + 1e-3 | odd,odd"]["defect"])
others = [max(v["defect"]) for k, v in V.items() if k not in ("rho | odd,odd", "a_2 + 1e-3 | odd,odd")]
others.append(max(V["rho | odd,odd"]["defect_conj"]))
print("quoted: rho %.1e; a_2 control %.1e (smallest over gamma %.1e); other controls >= %.1e; convergence of rho %.1e"
      % (rho, a2, min(V["a_2 + 1e-3 | odd,odd"]["defect"]), min(others), max(V["rho | odd,odd"]["conv"])))
