# Over ℚ(√2): the Galois series of ρ|G_F on ℍ × ℍ (20 October 2026)

Author: Dula.

F = ℚ(√2) is the real field of the three-field variant in Remark 3.8(2) of the note: H1 for ℚ(i), ℚ(√−2) and ℚ(√2) would give the modularity of ρ. Remark 3.10 tests H1 numerically over ℚ(i) and ℚ(√−2). This folder adds the same test over F. Computing the space of Hilbert–Maass forms of level 1951·O_F is out of reach here, so instead we test whether the Galois series of ρ|G_F is automorphic.

**The series.** Here 1951 = 𝔓𝔓̄ splits in F, the narrow class number of F is 1, and ρ(c) = −I at both real places. So, if H1 holds for F, the newform of ρ|G_F has the expansion

f(z₁, z₂) = Σ_{0 ≠ α ∈ ℤ[√2]} c((α)) sgn(Nα) √(y₁y₂) K₀(2π|α₁|y₁/2√2) K₀(2π|α₂|y₂/2√2) e((α₁x₁ − α₂x₂)/2√2).

- α₁ and α₂ are the two real embeddings of α.
- The Fourier index is ν = α/2√2, which runs over the inverse different.
- c is the Dirichlet coefficient of L(s, ρ|G_F), computed from the trace table:
  - split p (p ≡ ±1 mod 8): c(P^a P̄^b) = h_a h_b;
  - inert p (p ≡ ±3 mod 8): the recursion for Frob_p²;
  - 2 = (√2)²: c((√2)^j) = h_j(a₂);
  - 1951: c = a₁₉₅₁^{a+b}.
- The sign sgn(Nα) = sgn(ν₁)·sgn(ν₂) up to a constant: the archimedean type is π(sgn, sgn) at both places.
- Each term has eigenvalue 1/4 for both Laplacians.

**The test.** We compare f(γz) with χ(N(d)) f(z) for random γ = (a b; 1951 d) in SL₂(O_F), where z and γz have height about 1/1951 in both factors. The sum runs over |α_j|y_j ≤ 2√2·C, so the K₀ factors are cut below K₀(2πC); C = 3 gives K₀(6π) ≈ 2·10⁻⁹.

**Variants:**
- coefficients: ρ, a₂ + 10⁻³, or the √5-conjugate traces;
- signs: (odd, odd), (even, even) or (odd, even);
- nebentypus: χ(N d), or its complex conjugate.

**Convergence.** The same sum is also taken at 0.8C.

## Results [N]

Main run: C = 3, seed 2, 6 random γ, 468 212 404 terms (two parts of 234 106 202), points at heights 4.6·10⁻⁴ to 5.5·10⁻⁴, |α₁| ≤ 18417, |α₂| ≤ 17977. "Defect" is the largest of |f(γP) − ν f(P)| / |f(P)| over the six γ, where ν is the nebentypus value.

| Coefficients | Signs at the real places | Defect, χ(N d) | Defect, conjugate | Convergence (C vs 0.8C) |
|---|---|---|---|---|
| ρ | odd, odd | **5.6·10⁻⁹** | 1.9 | 3.9·10⁻⁷ |
| ρ | even, even | 2.6 | 2.0 | 1.4·10⁻⁷ |
| ρ | odd, even | 3.9 | 3.5 | 2.3·10⁻⁷ |
| a₂ + 10⁻³ | odd, odd | 1.8·10⁻² | 1.9 | 3.9·10⁻⁷ |
| a₂ + 10⁻³ | even, even | 2.6 | 2.0 | 1.4·10⁻⁷ |
| a₂ + 10⁻³ | odd, even | 3.9 | 3.5 | 2.3·10⁻⁷ |
| √5-conjugate traces | odd, odd | 5.0 | 3.2 | 1.5·10⁻⁷ |
| √5-conjugate traces | even, even | 1.6 | 2.1 | 1.3·10⁻⁷ |
| √5-conjugate traces | odd, even | 1.8 | 2.8 | 2.7·10⁻⁷ |

Per γ:
- For ρ with signs (odd, odd), the defect ranges from 4.3·10⁻¹⁰ to 5.6·10⁻⁹, and |f(P)| from 0.26 to 1.8.
- For a₂ + 10⁻³, the defect ranges from 1.9·10⁻³ to 1.8·10⁻².
- The six nebentypus values χ(N d) are all non-trivial fifth roots of unity.
- The defect for ρ is below the C-versus-0.8C difference, because the latter measures the truncation of the smaller sum (K₀(4.8π) ≈ 10⁻⁷).

So invariance holds only with the signs sgn(Nα) forced by ρ(c) = −I, with the traces of ρ, and with nebentypus χ(N d).

Pilot: C = 1, 4 γ, 5.1·10⁷ terms. It gave 1.2·10⁻³ for ρ and 2.8·10⁻³ for a₂ + 10⁻³; the parity controls and the √5-conjugate traces gave at least 1.8. At C = 1 the truncation K₀(2π) ≈ 10⁻³ dominates, which is why the main run uses C = 3.

## Files

| File | What it is |
|---|---|
| `hilbert_r2.py C NPAIRS SEED PART NPART` | builds the series and writes `hr2_C<C>_s<SEED>_part<PART>of<NPART>.npz`; rows y ≡ PART mod NPART |
| `hr2_combine.py C SEED NPART` | combines the parts and prints the defects; writes `hr2_C<C>_s<SEED>.json` |
| `hr2_summary.py hr2_C3.00_s2.json` | the numbers above (output `hr2_C3_s2_summary.log`) |
| `hr2_C1_s1.log`, `hr2_C1.00_s1.json` | pilot run, C = 1, 4 γ, seed 1 (one part) |
| `hr2_C3_s2_p0.log`, `hr2_C3_s2_p1.log`, `hr2_C3_s2_combine.log`, `hr2_C3.00_s2.json` | main run, C = 3, 6 γ, seed 2, two parts |

`hilbert_r2.py` imports `bianchi/bianchi.py` (sieve, class codes, χ). It also reads the class codes `bianchi/chunks/codes_*.npz`, which are not shipped; the top-level README says how to regenerate them. Each part of the main run took about an hour on one core (3515 s).

None of this proves H1 for F. If ρ is modular, then H1 holds for F by base change, so the test is a consistency check.
