"""Combine the parts written by hilbert_r2.py and print the automorphy defects.  Usage: python3 hr2_combine.py C SEED NPART
Author: Dula."""
import sys, json, glob, numpy as np
C = float(sys.argv[1]); SEED = int(sys.argv[2]); NPART = int(sys.argv[3])
parts = [np.load("hr2_C%.2f_s%d_part%dof%d.npz" % (C, SEED, k, NPART)) for k in range(NPART)]
S = sum(p["S"] for p in parts); S1 = sum(p["S1"] for p in parts); names = parts[0]["names"]; nu = parts[0]["nu"]
nterms = sum(int(p["nterms"]) for p in parts)
res = {"C": C, "seed": SEED, "nterms": nterms, "variants": {}}
print("C = %.2f, seed %d, %d terms" % (C, SEED, nterms))
for v, name in enumerate(names):
    dnu, dcn, dconv = [], [], []
    for i in range(len(nu)):
        fP, fQ = S[v, 2 * i], S[v, 2 * i + 1]
        dnu.append(abs(fQ - nu[i] * fP) / abs(fP)); dcn.append(abs(fQ - np.conj(nu[i]) * fP) / abs(fP))
        dconv.append(max(abs(S[v, 2 * i] - S1[v, 2 * i]), abs(S[v, 2 * i + 1] - S1[v, 2 * i + 1])) / abs(fP))
    print("%-40s max rel defect  chi(Nd): %.1e   conj chi: %.1e   |sum(C) - sum(0.8C)|: %.1e" % (name, max(dnu), max(dcn), max(dconv)))
    res["variants"][str(name)] = dict(defect=dnu, defect_conj=dcn, conv=dconv)
json.dump(res, open("hr2_C%.2f_s%d.json" % (C, SEED), "w"), indent=1)
