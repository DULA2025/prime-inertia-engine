"""Exact checks for the curve E1 over K = Q(sqrt5, sqrt-3) from Klein's resolvent with accessory irrationality sqrt(-3).
j1 = (ReA + sqrt-3 * ImA') + (ReB + sqrt-3 * ImB') * sqrt5   (ImA' = Im(alpha)/sqrt3, etc.; see klein_sqrt3.py).
(1) Frobenius test: for every prime P of K with N(P) | p <= 500 (good reduction, P not over 2, 3, 5, 1951), the projective
    order of Frob_P on E1[5] (from u = a_P^2 / N(P) mod 5) equals the order of Frob_p^f in the A5 field of f5.
    Run for all four Galois conjugates of j1.
(2) Integral model, places with v_P(j1) < 0, and decomposed-generic witnesses for E1[5] (and E1[3]).
Author: Dula."""
import json, pickle, cypari2
from math import gcd, lcm
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9)
J = pickle.load(open("/home/claude/research/klein3/j1_exact_600.pkl", "rb"))
q = lambda k: pari(J[k][0]) / pari(J[k][1])
Kpol = pari.polredabs(pari.polcompositum("a^2+3", "a^2-5")[0]); Kpol = pari.substpol(Kpol, "x", "y")
K = pari.nfinit(Kpol)
S3 = pari.nfroots(K, "x^2+3")[0]; S5 = pari.nfroots(K, "x^2-5")[0]
s3 = pari.Mod(pari.nfbasistoalg(K, S3).lift(), Kpol); s5 = pari.Mod(pari.nfbasistoalg(K, S5).lift(), Kpol)
assert s3 ** 2 == -3 and s5 ** 2 == 5
def j_of(e3, e5):
    return (q("Re alpha") + e3 * s3 * q("Im alpha / sqrt3")) + (q("Re beta") + e3 * s3 * q("Im beta / sqrt3")) * (e5 * s5)
f5 = pari("x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344")
def a5_order(p):
    fa = pari.factormod(f5, p)
    degs = [int(pari.poldegree(fa[0][i])) for i in range(int(pari.matsize(fa)[0]))]
    o = 1
    for d in degs: o = lcm(o, d)
    return o
proj = {0: {2}, 1: {3}, 4: {1, 5}, 2: {4}, 3: {6}}
out = {"K": str(Kpol), "frobenius": {}}
den = int(pari.denominator(pari.content(pari.lift(j_of(1, 1)))))
print("K =", Kpol, "; disc", K[2], "; class number", pari.bnfinit(Kpol).bnf_get_no(), "; denominator of j1:", pari.factor(den))
for e3 in (1, -1):
    for e5 in (1, -1):
        jv = j_of(e3, e5)
        E = pari.ellinit(pari.ellfromj(pari.lift(jv)), K)
        ok = tot = 0; mism = []
        for p in map(int, pari.primes(500)):
            if p in (2, 3, 5, 1951): continue
            for Pr in pari.idealprimedec(K, p):
                Np = int(pari.idealnorm(K, Pr)); fdeg = int(Pr[3])
                red = pari.elllocalred(E, Pr)
                if int(red[0]) != 0: continue
                ap = int(pari.ellap(E, Pr)); u = (ap * ap * pow(Np, -1, 5)) % 5
                o = a5_order(p); oP = o // gcd(o, fdeg)
                tot += 1
                if oP in proj[u]: ok += 1
                else: mism.append((p, fdeg, oP, u))
        out["frobenius"]["sqrt-3 %+d, sqrt5 %+d" % (e3, e5)] = [ok, tot, mism[:5]]
        print("conjugate (sqrt-3 %+d, sqrt5 %+d): %d of %d primes of K agree; mismatches %s" % (e3, e5, ok, tot, mism[:5]), flush=True)
# integral model and potentially multiplicative places for j1 = j_of(1, 1)
j1 = j_of(1, 1)
a4 = 3 * j1 * (1728 - j1); a6 = 2 * j1 * (1728 - j1) ** 2
u = pari(den)
A4 = u ** 4 * a4; A6 = u ** 6 * a6
integral = all(pari.denominator(pari.content(pari.nfalgtobasis(K, pari.lift(c)))) == 1 for c in (A4, A6))
E1 = pari.ellinit([0, 0, 0, pari.lift(A4), pari.lift(A6)], K)
print("integral model over O_K:", integral, "; j(E1) == j1:", pari.lift(pari("(E)->E.j")(E1)) == pari.lift(j1))
pm = []
for p in [int(r) for r in pari.factor(den)[0]]:
    for P in pari.idealprimedec(K, p):
        v = int(pari.nfeltval(K, pari.lift(j1), P))
        if v < 0: pm.append(dict(p=p, f=int(P[3]), v_j=v))
print("places with v_P(j1) < 0:", pm)
# decomposed-generic witnesses: l splits completely in K (l = 1, 4 mod 15), all four places good with j1 != 0, 1728
rows = []
for l in map(int, pari.primes([7, 1500])):
    if l % 15 not in (1, 4) or den % l == 0: continue
    Ps = pari.idealprimedec(K, l); assert len(Ps) == 4
    aps = []; skip = False
    for P in Ps:
        if int(pari.elllocalred(E1, P)[0]) != 0: skip = True; break
        aps.append(int(pari.ellap(E1, P)))
    if skip: continue
    rows.append(dict(l=l, a_P=aps, generic5=all(a % 5 not in ((1 + l) % 5, (-(1 + l)) % 5) for a in aps),
                     generic3=all(a % 3 not in ((1 + l) % 3, (-(1 + l)) % 3) for a in aps)))
w5 = [r["l"] for r in rows if r["generic5"]]; w3 = [r["l"] for r in rows if r["generic3"]]
print("split primes l < 1500 with good reduction at all four places: %d; E1[5] witnesses: %s ...(%d); E1[3] witnesses: %s" %
      (len(rows), w5[:10], len(w5), w3[:10]))
out.update(integral=bool(integral), pot_mult=pm, rows=rows, witnesses5=w5, witnesses3=w3, denominator=str(den))
json.dump(out, open("/home/claude/research/klein3/certify_K.json", "w"), indent=1)
