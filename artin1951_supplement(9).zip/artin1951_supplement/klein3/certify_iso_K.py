"""Exact certificate for E1 / K, K = Q(sqrt5, sqrt-3), as moonshine/certify_iso.py did over F:
(a) the 5-isogeny field of E1 (a root of (x^2+250x+3125)^3 - j1 x^5, degree 6 over K) contains K6*K, where K6 is the sextic
    resolvent field of f5 (x^6 - 75x^4 - 70x^3 + 826x^2 - 210x - 625).  Both have degree 24, so the fields are equal and
    the projective mod-5 representation of E1 equals that of rho over K.
(b) linear version up to the twist: at degree-1 primes P | p of K (p <= 3000), a_P(E1)^2 = N(P) * tbar_p^2 (mod 5), where
    tbar_p = tr rho0(Frob_p) mod sqrt5; i.e. psi(Frob_P)^2 = omega5(Frob_P).
Author: Dula."""
import json, pickle, time, cypari2
pari = cypari2.Pari(); pari.allocatemem(5 * 10**9); pari.default("parisizemax", 6 * 10**9)
J = pickle.load(open("/home/claude/research/klein3/j1_exact_600.pkl", "rb"))
q = lambda k: pari(J[k][0]) / pari(J[k][1])
Kpol = pari.polredabs(pari.polcompositum("a^2+3", "a^2-5")[0]); K = pari.nfinit(Kpol)
s3 = pari.Mod(pari.nfbasistoalg(K, pari.nfroots(K, "x^2+3")[0]).lift(), Kpol)
s5 = pari.Mod(pari.nfbasistoalg(K, pari.nfroots(K, "x^2-5")[0]).lift(), Kpol)
j1 = (q("Re alpha") + s3 * q("Im alpha / sqrt3")) + (q("Re beta") + s3 * q("Im beta / sqrt3")) * s5
res = {}
# (b) first (fast)
D = json.load(open("/home/claude/research/overnight/traces/galois_traces_3200000.json"))
PHI = (1 + 5 ** .5) / 2
def tbar(t):
    for val, r in ((2, 2), (-2, 3), (0, 0), (1, 1), (-1, 4), (PHI, 3), (-PHI, 2), (PHI - 1, 2), (1 - PHI, 3)):
        if abs(t - val) < 1e-9: return r
E = pari.ellinit(pari.ellfromj(pari.lift(j1)), K)
ok = bad = 0
for p in map(int, pari.primes([7, 3000])):
    if p == 1951: continue
    for P in pari.idealprimedec(K, p):
        if int(P[3]) != 1 or int(pari.elllocalred(E, P)[0]) != 0: continue
        a = int(pari.ellap(E, P)); tb = tbar(D["t"][str(p)])
        if (a * a - p * tb * tb) % 5 == 0: ok += 1
        else: bad += 1
res["linear_congruence"] = [ok, ok + bad]
print("a_P(E1)^2 = N(P) tbar_p^2 mod 5 at degree-1 primes, p < 3000: %d of %d" % (ok, ok + bad), flush=True)
# (a) field equality
t = time.time()
fib = pari.lift(pari("(x^2+250*x+3125)^3") - j1 * pari("x^5"))
nfac = len(pari.nffactor(K, fib)[0])
print("isogeny fibre over K: %d irreducible factor(s)" % nfac, flush=True)
Rq = pari.rnfequation(K, fib, 1); Pabs = Rq[0]
print("absolute degree %d, coefficient digits %d" % (int(pari.poldegree(Pabs)), max(len(str(abs(int(c)))) for c in pari.Vec(Pabs))), flush=True)
Pred = pari.polredbest(Pabs)
print("polredbest %.0fs, digits now %d" % (time.time() - t, max(len(str(abs(int(c)))) for c in pari.Vec(Pred))), flush=True)
g = pari("x^6 - 75*x^4 - 70*x^3 + 826*x^2 - 210*x - 625")
Gabs = pari.polredbest(pari.rnfequation(K, g))
r = pari.nfisincl(Gabs, Pred)
res["fibre_irreducible"] = (nfac == 1); res["K6K_in_isogeny_field"] = (r != 0); res["secs"] = round(time.time() - t)
print("K6*K embeds in the isogeny field of E1:", r != 0, " (%.0f s)" % (time.time() - t), flush=True)
json.dump(res, open("/home/claude/research/klein3/certify_iso_K.json", "w"), indent=1)
