"""Accessory irrationality sqrt(-d) for Klein's resolvent of f5: orthogonal u, v in the trace-zero lattice (= 1951*A4)
with Tr(u^2) = d Tr(v^2).  Then y = u + sqrt(-d) v has Tr y = Tr y^2 = 0 over Q(sqrt(-d)).  Search up to A4-norm 8.
Author: Dula."""
import cypari2, itertools, pickle
from fractions import Fraction as Fr
pari = cypari2.Pari(); pari.allocatemem(10**9)
f = pari("x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344")
nf = pari.nfinit(f); B = pari.nfbasis(f); n = 5
Tr = lambda a: pari.nfelttrace(nf, pari.nfalgtobasis(nf, pari.Mod(a, f)))
G = [[int(Tr(B[i] * B[j])) for j in range(n)] for i in range(n)]
t = [int(Tr(B[i])) for i in range(n)]
K0 = pari.matkerint(pari.matrix(1, n, t))
Gm = pari.matrix(n, n, [G[i][j] for i in range(n) for j in range(n)])
Q0 = pari.mattranspose(K0) * Gm * K0
R = pari.qflllgram(Q0); Q1 = pari.mattranspose(R) * Q0 * R
print("LLL Gram (should be 1951 * A4):", Q1)
sv = pari.qfminim(Q1, 1951 * 8, 10**6)
nc = int(pari.matsize(sv[2])[1]); vecs = [[int(sv[2][i, k]) for i in range(4)] for k in range(nc)]
Qf = lambda a: sum(a[i] * a[j] * int(Q1[i, j]) for i in range(4) for j in range(4))
Bf = lambda a, b: sum(a[i] * b[j] * int(Q1[i, j]) for i in range(4) for j in range(4))
print("vectors up to norm 8*1951 (up to sign):", nc)
best = {}
for u in vecs:
    for v in vecs:
        if Bf(u, v) != 0: continue
        r = Fr(Qf(u), Qf(v))
        if r.denominator != 1: continue
        d = r.numerator
        if d in (3, 7, 2, 1, 11) and (d not in best or Qf(u) + Qf(v) < best[d][2][0] + best[d][2][1]):
            best[d] = (u, v, (Qf(u), Qf(v)))
for d in sorted(best): print("d = %d:  u = %s  v = %s  Q(u), Q(v) = %s" % (d, best[d][0], best[d][1], best[d][2]))
pickle.dump({"R": str(R), "K0": str(K0), "best": best, "B": [str(b) for b in B]}, open("lattice3.pkl", "wb"))
