"""[sqrt(-3) version, Dula 13 Oct 2026] Klein's icosahedral invariant for f5 with the accessory irrationality sqrt(-3) (was sqrt(-1)):
y = u + i v, u, v orthogonal minimal vectors of the trace-zero lattice 1951*A4.  Then j0 = alpha + beta sqrt5,
alpha, beta in Q(i), recognised from the two rulings.   python3 klein4.py <dps>"""
import sys, itertools, pickle, cypari2, mpmath as mp
from fractions import Fraction as Fr
DPS = int(sys.argv[1]) if len(sys.argv) > 1 else 300
mp.mp.dps = DPS
pari = cypari2.Pari(); pari.allocatemem(10**9)
f = pari("x^5 - x^4 - 780*x^3 - 1795*x^2 + 3106*x + 344")
B = pari.nfbasis(f)
L = pickle.load(open("/home/claude/research/klein3/lattice3.pkl", "rb"))
K0, R = pari(L["K0"]), pari(L["R"])
u, v = L["best"][3][0], L["best"][3][1]
def elem(w):
    cvec = K0 * R * pari.matrix(4, 1, w)
    return sum(cvec[i, 0] * B[i] for i in range(5))
ue, ve = elem(u), elem(v)
print("u =", ue); print("v =", ve)
fco = [1, -1, -780, -1795, 3106, 344]
xs = sorted([mp.re(r) for r in mp.polyroots(fco, maxsteps=3000, extraprec=4*DPS)])
def ev(pol, x):
    co = [pari.polcoef(pol, k) for k in range(5)]
    return mp.fsum(mp.mpf(int(pari.numerator(c)))/mp.mpf(int(pari.denominator(c))) * x**k for k, c in enumerate(co))
U = [ev(ue, x) for x in xs]; V = [ev(ve, x) for x in xs]
print("Tr u^2, Tr v^2, Tr uv:", mp.nstr(mp.fsum(a*a for a in U), 12), mp.nstr(mp.fsum(b*b for b in V), 12), mp.nstr(mp.fsum(a*b for a, b in zip(U, V)), 5))
def sign(pm):
    s = 1
    for i in range(5):
        for j in range(i+1, 5):
            if pm[i] > pm[j]: s = -s
    return s
evens = [pm for pm in itertools.permutations(range(5)) if sign(pm) == 1]
def J_of(ys, k):
    Z = mp.exp(2j*mp.pi*k/5)
    def W(pm): return [[mp.fsum(Z**(-kk*nu + l*pm[nu]) for nu in range(5))/5 for l in range(1, 5)] for kk in range(1, 5)]
    def apply(Wm, c): return [mp.fsum(Wm[i][l]*c[l] for l in range(4)) for i in range(4)]
    def C_of(c): return mp.matrix([[c[0], c[1]], [-c[2], c[3]]])
    def c_of(C): return [C[0, 0], C[0, 1], -C[1, 0], C[1, 1]]
    def colA(Wm):
        def col(C):
            return mp.matrix([C[0, 0], C[1, 0]]) if abs(C[0, 0]) + abs(C[1, 0]) > abs(C[0, 1]) + abs(C[1, 1]) else mp.matrix([C[0, 1], C[1, 1]])
        mu0 = mp.matrix([1, mp.mpf(1)/3]); e1, e2 = mp.matrix([1, 0]), mp.matrix([0, 1])
        vv = [col(C_of(apply(Wm, c_of(l * mu0.T)))) for l in (e1, e2, e1 + e2)]
        M = mp.matrix([[vv[0][0], vv[1][0]], [vv[0][1], vv[1][1]]]); st = mp.lu_solve(M, vv[2])
        return mp.matrix([[vv[0][0]*st[0], vv[1][0]*st[1]], [vv[0][1]*st[0], vv[1][1]*st[1]]])
    G = [colA(W(pm)) for pm in evens]
    tol = mp.mpf(10)**(-DPS//2)
    def order(M):
        P = M
        for o in range(1, 7):
            if abs(P[0, 1]) < tol*abs(P[0, 0]) and abs(P[1, 0]) < tol*abs(P[0, 0]) and abs(P[0, 0] - P[1, 1]) < tol*abs(P[0, 0]): return o
            P = P*M
    def fixed(M):
        a_, b_, c_, d_ = M[0, 0], M[0, 1], M[1, 0], M[1, 1]
        if abs(c_) < tol*abs(a_): return [b_/(d_ - a_)]
        r = mp.sqrt((a_ - d_)**2 + 4*b_*c_)
        return [(a_ - d_ + r)/(2*c_), (a_ - d_ - r)/(2*c_)]
    def dedup(Lst):
        out = []
        for w in Lst:
            if all(abs(w - q) > tol*(1 + abs(w)) for q in out): out.append(w)
        return out
    ords = [order(M) for M in G]
    Vx = dedup([q for M, o in zip(G, ords) if o == 5 for q in fixed(M)])
    Fx = dedup([q for M, o in zip(G, ords) if o == 3 for q in fixed(M)])
    Ex = dedup([q for M, o in zip(G, ords) if o == 2 for q in fixed(M)])
    assert len(Fx) == 20 and len(Ex) == 30 and len(Vx) in (11, 12)
    fp = lambda w: mp.fprod(w - q for q in Vx); Hp = lambda w: mp.fprod(w - q for q in Fx)
    c = [mp.fsum(Z**(-kk*nu)*ys[nu] for nu in range(5)) for kk in range(1, 5)]
    z = c[1]/c[3]
    return 1728*(Hp(z)**3/fp(z)**5)/(Hp(Ex[0])**3/fp(Ex[0])**5)
S3 = mp.sqrt(3)
ys = [a + 1j*S3*b for a, b in zip(U, V)]
print("sum y, sum y^2:", mp.nstr(abs(mp.fsum(ys)), 3), mp.nstr(abs(mp.fsum(y*y for y in ys)), 3))
j1 = J_of(ys, 1); j2 = J_of(ys, 2)
ysc = [a - 1j*S3*b for a, b in zip(U, V)]
j1c = J_of(ysc, 1)
print("j(rho ruling)  =", mp.nstr(j1, 50)); print("j(rho' ruling) =", mp.nstr(j2, 50)); print("sqrt-3 -> -sqrt-3 conjugate:", mp.nstr(j1c, 30))
alpha = (j1 + j2)/2; beta = (j1 - j2)/(2*mp.sqrt(5))
def rat(x):
    q = Fr(mp.nstr(x, DPS - 10)).limit_denominator(10**(DPS//3))
    return q, abs(x - mp.mpf(q.numerator)/q.denominator)
out = {}
for name, val in (("Re alpha", mp.re(alpha)), ("Im alpha / sqrt3", mp.im(alpha)/S3), ("Re beta", mp.re(beta)), ("Im beta / sqrt3", mp.im(beta)/S3)):
    q, err = rat(val); out[name] = q
    print("%-8s = %s   (residual %s)" % (name, q, mp.nstr(err, 3)))
pickle.dump({k: (v.numerator, v.denominator) for k, v in out.items()}, open("/home/claude/research/klein3/j1_exact_%d.pkl" % DPS, "wb"))
