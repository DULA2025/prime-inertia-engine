"""Road A' (Theorem A' of the note) with the family E_q = Q(sqrt(-q)), q = 7 mod 8 prime (Dula, 16 Oct 2026).
(1) 2 splits in every E_q (-q = 1 mod 8);
(2) every odd prime p splits in some E_q (CRT + Dirichlet); check: for p < 10^6, the first q that works;
(3) E_q is disjoint from N (N has no quadratic subfield, G^ab = C5), so rho|G_E has projective image A5 and
    rhobar_2|G_E has image of order 300."""
from sympy import primerange, isprime, legendre_symbol
Q = [q for q in primerange(3, 200000) if q % 8 == 7]
assert all((-q) % 8 == 1 for q in Q)
worst, hist = (0, None), {}
for p in primerange(3, 10 ** 6):
    for i, q in enumerate(Q):
        if q != p and legendre_symbol((-q) % p, p) == 1:
            hist[i] = hist.get(i, 0) + 1
            if i > worst[0]: worst = (i, (p, q))
            break
    else:
        raise SystemExit("no field found for p = %d" % p)
print("2 splits in every Q(sqrt(-q)), q = 7 mod 8 (first fields: q = %s)" % Q[:8])
print("every odd prime p < 10^6 splits in one of the first %d fields; worst case p = %d needs q = %d"
      % (worst[0] + 1, worst[1][0], worst[1][1]))
print("number of primes first split in field #k (k = 1..):", [hist.get(k, 0) for k in range(worst[0] + 1)])
