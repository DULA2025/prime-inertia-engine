# brainstorm/ — Grok's five routes, made precise (14 Oct 2026)

Author: Dula. Labels: [T] theorem (with the cited inputs), [N] numerical, [C] conjecture, [S] speculation.

## What is here
| file | what it does |
|---|---|
| `q5.py` | exact arithmetic in Z[zeta5] (basis 1, z, z^2, z^3), Frobenius data of rho = rho0 x chi^3 and its three conjugates |
| `rootnum.py` → `rootnumbers.json` | root numbers W_k = -zeta5^{3k} tau(chi^k)/sqrt(1951) of the four conductor-1951 conjugates (unique among 40 Gauss-sum candidates) |
| `negvalues.py` → `neg[A-D].json`, `neg[A-D].log` | L(rho, 1-n) for odd n = 3 ... 1459 from the functional equation and the absolutely convergent Euler product of the dual at s = n (no holomorphy assumption); coordinates in Z[zeta5] |
| `padic.py` → `padic_report.json`, `padic.log` | p-adic analysis for p = 3, 5, 7, 11, 13: units, Kummer congruences, trivial zero at 11, limit to s = 0 |
| `padic_figure.py` → `padic_ladder.png` | the figure |
| `facts.py` → `facts.log` | E_p(1) = det(1 - rho(Frob_p)) for small p; primes with a trivial zero (11, 37, 97, ...) |
| `crosscheck.py` → `crosscheck.log` | PARI (assuming holomorphy) vs the exact values at s = 0 and s = -2 |

`primes30M.pkl` (cache of the 3e7 Frobenius table, 16 MB) is rebuilt by `negvalues.py` from
`overnight/traces/galois_traces_30000000.json` and is not shipped.

## Results
- [T | Greenberg 1983 + Wiles 1990; independently Ellerbrock–Nickel, arXiv 2203.12945, Thm 3] For every odd prime p, the p-adic Artin L-function L_p(s, rho.omega_p) is an Iwasawa
  function (no poles). rho(c) = -I, so rho.omega_p is of type S.
- [T] Siegel–Klingen: L(rho, 1-n) lies in Q(zeta5) for odd n >= 1; [N] for all 59 odd n tested (3 ... 1459) it lies in Z[zeta5].
  L(rho, -2) = 8612 - 23244 z - 8800 z^2 + 26804 z^3.
- [N] p = 3, 5, 7, 13: every value L*(rho, 1-n) is a p-adic unit and every Kummer congruence holds with exact equality
  (lambda = mu = 0 behaviour). p = 11: trivial zero at s = 0, simple with unit derivative at all four primes above 11
  (Gross's predicted order 1).
- [N] The p-adic limits of these unconditional values reproduce L(rho, 0) = -4(zeta5 + zeta5^2) modulo 3^7 5^4 7^3 13^2.
- [T] L(rho, s) has no poles (and no zeros) for sigma >= 1 - 1/(44547 + 5721 log|t|), |t| >= 1 (Lee's zero-free region for
  zeta_N, d_N = 1951^480, n_N = 600), and in the mirror strip.

Nothing here proves that L(rho, s) is entire: values at negative integers are fixed by the Euler product through the
functional equation and carry no information about the critical strip.

## Rerun
    python3 rootnum.py 4000
    python3 negvalues.py 3,5,7,...,501 negA.json     # any comma list of odd n; 1211 and 1459 take ~3-4 min each
    python3 padic.py; python3 padic_figure.py
