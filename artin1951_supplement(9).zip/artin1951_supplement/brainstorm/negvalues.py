"""Special values L(rho_k, 1-n), n odd >= 3, of the four conductor-1951 conjugates, WITHOUT any holomorphy assumption:
functional equation (unconditional for Artin L-functions, via Brauer + Hecke) + absolutely convergent Euler product of the
dual at s = n.  Author: Dula.

    Lambda(rho_k, s) = 1951^{s/2} Gamma_R(s+1)^2 L(rho_k, s) = W_k Lambda(conj rho_k, 1 - s),   Gamma_R(s) = pi^{-s/2} Gamma(s/2)
    => L(rho_k, 1-n) = W_k 1951^{n-1/2} [Gamma_R(n+1)/Gamma_R(2-n)]^2 L(rho_{5-k}, n)
    W_k = -zeta5^{3k} tau(chi^k)/sqrt(1951)   (rootnum.py: unique Gauss-sum candidate, gap 4e-15 vs 8.5e-3)

Siegel-Klingen (rho(c) = -I, rank-0 Stark) says L(rho, 1-n) lies in Q(zeta5) and tau_k L(rho, 1-n) = L(rho_k, 1-n).  So the
four complex numbers determine rational coordinates c_0..c_3 in the basis 1, z, z^2, z^3; this script reports them, the
imaginary-part residue (an equivariance test) and the least common denominator found.

Euler product: classes (t_p label, dl(p) mod 5) carry identical exact coefficients; for p^-n below 10^(-digits/2) only the
first-order term a_p p^-n of log L survives, summed per class (real arithmetic).  Small p get the full local factor."""
import sys, json, math, pickle, time
sys.set_int_max_str_digits(0)
import mpmath
from mpmath import mp, mpf, mpc
from fractions import Fraction
from q5 import *

TR30 = "/home/claude/research/overnight/traces/galois_traces_30000000.json"
_cache = {}
def primes_data(Pmax):
    """sorted list of (p, class index) for p <= Pmax from the 3e7 trace table, plus the 45 exact class vectors"""
    if "all" not in _cache:
        try:
            _cache["all"] = pickle.load(open("primes30M.pkl", "rb"))
        except FileNotFoundError:
            D = json.load(open(TR30))
            cls = {}; lst = []
            for ps, t in D["t"].items():
                p = int(ps); key = (label(t), dl[p % N] % 5)
                if key not in cls: cls[key] = len(cls)
                lst.append((p, cls[key]))
            lst.sort()
            _cache["all"] = (lst, cls, int(D["P"]))
            pickle.dump(_cache["all"], open("primes30M.pkl", "wb"))
    lst, cls, P = _cache["all"]
    assert Pmax <= P, (Pmax, P)
    import bisect
    i = bisect.bisect_right(lst, (Pmax, 10**9))
    return lst[:i], cls

def gauss(m, prec_dps):
    with mp.workdps(prec_dps + 20):
        z = mpmath.expjpi(mpf(2) / N); zp = mpc(1); s = mpc(0)
        zs = [mpmath.expjpi(mpf(2 * j) / 5) for j in range(5)]
        for x in range(1, N):
            zp *= z
            s += zs[(m * chi_exp(x)) % 5] * zp
        return s

def values(n, extra=40, Pcap=3 * 10**7, p0=2000):
    """returns dict with the four embedded values v^(k) = L(rho_k, 1-n), coordinates, error estimates"""
    assert n % 2 == 1 and n >= 3
    mp.dps = 30
    GR = lambda s: mp.pi ** (-s / 2) * mp.gamma(s / 2)
    G = (GR(mpf(n + 1)) / GR(mpf(2 - n))) ** 2
    lg = float(mpmath.log10(abs(G))) + (n - 1) * math.log10(N)            # log10 |L(rho, 1-n)| roughly
    want = max(int(lg), 0) + extra                                          # digits wanted (absolute 10^-extra)
    Pn = int(10 ** ((want + 6) / (n - 1))) + 10
    trunc_ok = Pn <= Pcap
    Pn = min(Pn, Pcap)
    log10_tail = math.log10(2.2) + (1 - n) * math.log10(Pn) - math.log10(n - 1) - math.log10(math.log(Pn))   # relative bound
    mp.dps = want + 15
    lst, cls = primes_data(Pn)
    inv = {v: k for k, v in cls.items()}
    cvec = {i: mul(TRACE[inv[i][0]], zpow(inv[i][1])) for i in inv}          # exact a_p(rho) per class
    cdet = {i: zpow(2 * inv[i][1]) for i in inv}                             # det rho(Frob_p) = chi(p) = zeta5^{2 dl}
    zs = [mpmath.expjpi(mpf(2 * j) / 5) for j in range(5)]
    def E(a, k):
        return a[0] + a[1] * zs[k % 5] + a[2] * zs[(2 * k) % 5] + a[3] * zs[(3 * k) % 5]
    eps = mpf(10) ** (-(want + 12))
    Mmax = 1
    while mpf(p0) ** (-n * (Mmax + 1)) > eps: Mmax += 1
    S = [[mpf(0)] * (Mmax + 1) for _ in range(len(cls))]
    logL = {k: mpc(0) for k in (1, 2, 3, 4)}
    nsmall = 0
    for p, ci in lst:
        x = mpf(p) ** (-n)
        if p <= p0:
            nsmall += 1
            a = cvec[ci]; d = zpow(chi_exp(p))
            for k in (1, 2, 3, 4):
                logL[k] -= mpmath.log(1 - E(a, k) * x + E(d, k) * x * x)
        else:
            row = S[ci]; xm = x; m = 1
            while True:
                row[m] += xm
                m += 1
                if m > Mmax: break
                xm *= x
                if xm < eps: break
    # exact power sums P_m = alpha^m + beta^m per class
    for ci in range(len(cls)):
        a, d = cvec[ci], cdet[ci]
        Pm = [None, a, sub(mul(a, a), scal(2, d))]
        for m in range(3, Mmax + 1): Pm.append(sub(mul(a, Pm[-1]), mul(d, Pm[-2])))
        for k in (1, 2, 3, 4):
            for m in range(1, Mmax + 1):
                if S[ci][m]: logL[k] += E(Pm[m], k) * S[ci][m] / m
    for k in (1, 2, 3, 4):
        logL[k] -= mpmath.log(1 - zs[(2 * k) % 5] * mpf(N) ** (-n))          # p = 1951
    v = {}
    G = (GR(mpf(n + 1)) / GR(mpf(2 - n))) ** 2
    for k in (1, 2, 3, 4):
        Wsq = -zs[(3 * k) % 5] * gauss(k, mp.dps) * mpf(N) ** (n - 1)       # W_k * 1951^{n-1/2}
        v[k] = Wsq * G * mpmath.exp(logL[5 - k])                              # L(rho_k, 1-n) uses L(rho_{5-k}, n)
    Ssum = -sum(zs[(-4 * k) % 5] * v[k] for k in (1, 2, 3, 4))
    c = [(sum(zs[(-i * k) % 5] * v[k] for k in (1, 2, 3, 4)) + Ssum) / 5 for i in range(4)]
    im = max(abs(x.imag) for x in c)
    size = max(abs(x.real) for x in c)
    ls = float(mpmath.log10(size)) if size else 0.0
    log_abs_err = ls + max(log10_tail, -(want + 15))                          # truncation or working precision
    Dfound = None; coords = None
    if log_abs_err < -8:
        tol = mpf(10) ** (log_abs_err / 2)                                    # demand half the available digits
        cands = sorted(set(list(range(1, 2001)) + [2**a * 3**b * 5**cc * 7**e * 11**dd for a in range(14) for b in range(9)
                                                   for cc in range(7) for e in range(4) for dd in range(4)]))
        for Dd in cands:
            if mpf(Dd) * tol > 0.01: break
            if all(abs(Dd * x.real - mpmath.nint(Dd * x.real)) < tol * Dd for x in c):
                Dfound = Dd; break
        if Dfound:
            coords = [Fraction(int(mpmath.nint(Dfound * x.real)), Dfound) for x in c]
    return {"n": n, "want_digits": want, "Pn": Pn, "trunc_ok": trunc_ok, "p0": p0, "Mmax": Mmax, "nprimes": len(lst),
            "log10_tail_rel": log10_tail, "log10_abs_err": log_abs_err, "log10_size": float(mpmath.log10(size)) if size else None,
            "imag_resid": float(mpmath.log10(im)) if im else -9999.0,
            "denominator": Dfound, "coords": [str(f) for f in coords] if coords else None,
            "v1": [mpmath.nstr(v[1].real, 30), mpmath.nstr(v[1].imag, 30)]}

if __name__ == "__main__":
    ns = [int(x) for x in sys.argv[1].split(",")]
    out = sys.argv[2] if len(sys.argv) > 2 else "negvalues.json"
    res = {}
    try:
        res = json.load(open(out))
    except FileNotFoundError:
        pass
    for n in ns:
        t0 = time.time()
        o = values(n)
        o["secs"] = round(time.time() - t0, 1)
        res[str(n)] = o
        cs = o["coords"]
        print("n=%-5d s=%-6d want=%-6d P=%-9d ok=%s err~1e%.0f |c|~1e%.0f Im-resid 1e%.0f D=%s coords=%s (%.0fs)" %
              (n, 1 - n, o["want_digits"], o["Pn"], o["trunc_ok"], o["log10_abs_err"], o["log10_size"], o["imag_resid"], o["denominator"],
               (cs if cs and sum(len(x) for x in cs) < 160 else (str(cs)[:150] + "...") if cs else None), o["secs"]), flush=True)
        json.dump(res, open(out, "w"), indent=0)
