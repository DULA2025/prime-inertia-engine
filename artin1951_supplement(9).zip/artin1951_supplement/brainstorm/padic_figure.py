"""Figure: p-adic L-functions of rho (Dula).  Left: Kummer ladder, v_P(L*(n) - L*(1)) against e_P (v_p(n-1)+1) for
p = 3, 5, 7, 13 (L*(1) = E_p(1) * (-4)(z + z^2) from PARI); right: the trivial zero at p = 11, v_P(L*(n)) against
v_11(n-1)+1 at the four primes above 11.  Every point on the diagonal = congruence exactly as tight as an integral power
series with unit linear coefficient allows."""
import json, sys
sys.set_int_max_str_digits(0)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
R = json.load(open("padic_report.json"))
fig, ax = plt.subplots(1, 2, figsize=(11, 4.6))
marks = {"3": ("o", "#1f77b4"), "5": ("s", "#2ca02c"), "7": ("^", "#d62728"), "13": ("D", "#9467bd")}
mx = 0
for p, (m, c) in marks.items():
    xs, ys = [], []
    for n, k, vs in R[p]["limit"]:
        for nm, v, pred in vs:
            xs.append(pred); ys.append(v)
    mx = max(mx, max(xs + ys))
    ax[0].scatter(xs, ys, marker=m, s=60, facecolors="none", edgecolors=c, label="p = %s (%d values)" % (p, len(R[p]["ns"])))
ax[0].plot([0, mx + 1], [0, mx + 1], color="0.6", lw=1, zorder=0)
ax[0].set_xlabel("predicted  e·(v_p(n−1)+1)   [integral L_p, i.e. G in O[[T]]]")
ax[0].set_ylabel("observed  v_P( L*(ρ,1−n) − E_p(1)·L(ρ,0) )")
ax[0].set_title("Values deep in the left half-plane converge p-adically\nto E_p(1)·L(ρ,0), L(ρ,0) = −4(ζ₅+ζ₅²)", fontsize=10)
ax[0].legend(fontsize=8, loc="upper left")
xs, ys = [], []
for n, vs in R["11"]["units"]:
    v11 = 0; m = n - 1
    while m % 11 == 0: m //= 11; v11 += 1
    for nm, v in vs:
        xs.append(v11 + 1); ys.append(v)
ax[1].scatter(xs, ys, s=80, facecolors="none", edgecolors="#ff7f0e", label="4 primes above 11, %d values n ≡ 1 mod 10" % len(R["11"]["ns"]))
ax[1].plot([0, max(xs) + 1], [0, max(xs) + 1], color="0.6", lw=1, zorder=0)
ax[1].set_xlabel("v_11(n−1) + 1   (= v(T_n), T = (1+11)^s − 1)")
ax[1].set_ylabel("observed  v_P( L*(ρ,1−n) )")
ax[1].set_title("p = 11: ρ(Frob₁₁) has eigenvalue 1, so L₁₁(ρω,0) = 0;\npoints on the diagonal = simple zero, unit derivative", fontsize=10)
ax[1].legend(fontsize=8, loc="upper left")
for a in ax:
    a.set_xlim(0, None); a.set_ylim(0, None); a.grid(alpha=0.3)
fig.suptitle("p-adic Artin L-functions of ρ = ρ₀⊗χ³ (conductor 1951): exact values L(ρ,1−n) ∈ Z[ζ₅], n odd ≤ 1459", fontsize=11)
fig.tight_layout()
fig.savefig("padic_ladder.png", dpi=150)
print("saved padic_ladder.png")
