"""Cross-check of conventions: PARI's L(rho, s) (computed assuming holomorphy, exact root number) at s = 0 and s = -2
against -4(z + z^2) and the exact Euler-product value of L(rho,-2) from negvalues.py."""
import json, cypari2, mpmath
from q5 import *
from rootnum import coeffs
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9); pari.set_real_precision(50)
mpmath.mp.dps = 60
M = 3000
z = pari("exp(2*Pi*I/5)")
a = coeffs(1, M)
v = pari.vector(M, [x[0] + x[1] * z + x[2] * z ** 2 + x[3] * z ** 3 for x in a[1:]])
# exact W = -z^3 tau(chi)/sqrt(1951)
tau = sum(pari("exp(2*Pi*I*%d/5)" % ((chi_exp(x)) % 5)) * pari("exp(2*Pi*I*%d/1951)" % x) for x in range(1, N))
W = -z ** 3 * tau / pari("sqrt(1951)")
L = pari.lfuncreate([v, 1, [1, 1], 1, N, W])
print("FE check (bits):", pari.lfuncheckfeq(L))
L0 = pari.lfun(L, 0); Lm2 = pari.lfun(L, -2)
def ev(c): return c[0] + c[1] * z + c[2] * z ** 2 + c[3] * z ** 3
print("L(rho,0)  PARI          :", L0)
print("          -4(z+z^2)     :", ev((0, -4, -4, 0)), " diff:", pari.abs(L0 - ev((0, -4, -4, 0))))
neg = json.load(open("negA.json"))["3"]["coords"]
c = [int(x) for x in neg]
print("L(rho,-2) PARI          :", Lm2)
print("          Euler+FE exact:", ev(c), " coords", c, " diff:", pari.abs(Lm2 - ev(c)))
