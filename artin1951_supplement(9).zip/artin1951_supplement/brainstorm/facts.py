"""Small exact facts used below: E_p(1) = det(1 - rho(Frob_p)) for small p, primes with a trivial zero
(eigenvalue 1 of rho(Frob_p)), and the norm of L(rho,0) = -4(z+z^2)."""
from q5 import *
T, D = load()
ps = sorted(T)
print("first primes: p, label t_p, dl mod 5, a_p, det, E_p(1)=1-a_p+det, Norm(E_p(1))")
for p in ps[:16]:
    a = ap(1, p, T); d = detp(1, p); E = add(sub(ONE, a), d)
    print(p, T[p], dl[p] % 5, a, d, E, norm(E))
triv = [p for p in ps if add(sub(ONE, ap(1, p, T)), detp(1, p)) == ZERO]
print("primes < 3.2e6 with eigenvalue 1 (trivial zero of L_p(rho omega, s) at s = 0):", len(triv), "of", len(ps), "; first:", triv[:12])
dbl = [p for p in triv if T[p] == "2"]
print("  of which rho(Frob_p) = I (double eigenvalue 1):", dbl[:8], len(dbl))
L0 = scal(-4, add(zpow(1), zpow(2)))
print("L(rho,0) = -4(z+z^2) =", L0, " norm =", norm(L0), " (z+z^2 unit? norm(z+z^2) =", norm(add(zpow(1), zpow(2))), ")")
