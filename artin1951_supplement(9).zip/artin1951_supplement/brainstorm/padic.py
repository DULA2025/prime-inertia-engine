"""p-adic analysis of the exact values L(rho, 1-n) in Z[zeta5] (negvalues.py) for rho = rho0 (x) chi^3.  Author: Dula.

Greenberg (Nagoya 1983): for an Artin representation of type S (field totally real) the p-adic Artin L-function exists
(Brauer + Deligne-Ribet) and the Iwasawa main conjecture implies it is an Iwasawa function (the p-adic Artin conjecture);
Wiles (Ann. 1990) proved the main conjecture for p odd.  rho(c) = -I, so rho.omega (omega = Teichmueller, odd) is of type S.
Interpolation:  L_p(1-n, rho.omega) = L(rho.omega^{1-n}, 1-n) * det(1 - rho.omega^{1-n}(Frob_p) p^{n-1}),  n >= 1.
For n = 1 mod (p-1): omega^{1-n} = 1, so the values used are  L*(n) := E_p(n) L(rho, 1-n),
E_p(n) = 1 - a_p p^{n-1} + chi(p) p^{2n-2}, and L*(1) = det(1 - rho(Frob_p)) L(rho, 0).

Checks (all exact integer arithmetic in Z[zeta5]):
 (K) Kummer congruences: n = n' = 1 mod (p-1)  =>  v_P(L*(n) - L*(n')) >= e_P (v_p(n - n') + 1)   (G in O[[T]], T = (1+p)^s - 1);
 (U) units: v_P(L*(n)) = 0 when rho(Frob_p) has no eigenvalue 1 (then G(0) = L*(1) is a unit: lambda = mu = 0);
 (Z) trivial zero (rho(Frob_p) has eigenvalue 1, e.g. p = 11): v_P(L*(n)) >= v_p(n - 1) + 1, with equality for all n iff
     the zero of L_p at s = 0 is simple with unit derivative (Gross's order-of-vanishing prediction: order 1);
 (L) the p-adic limit n -> 1 recovers L*(1) mod p^{k+1} from values deep in the left half-plane, an independent check of
     L(rho, 0) = -4(zeta5 + zeta5^2) (that value was computed by PARI assuming holomorphy)."""
import json, sys
sys.set_int_max_str_digits(0)
from fractions import Fraction
from q5 import *

vals = {}
import glob
for f in sorted(glob.glob("neg[A-Z].json")):
    for k, o in json.load(open(f)).items():
        assert o["denominator"] == 1, (k, o["denominator"])
        vals[int(k)] = tuple(int(Fraction(c)) for c in o["coords"])
L0 = (0, -4, -4, 0)                                   # L(rho, 0), PARI (assuming holomorphy), recognised
T, D = load()

def vp_int(x, p):
    if x == 0: return 10**9
    v = 0
    while x % p == 0: x //= p; v += 1
    return v
# --- valuations at the primes above p -----------------------------------------------------------------------------
def roots_mod(p, K):
    """Hensel-lift the roots of x^4+x^3+x^2+x+1 mod p (p = 1 mod 5) to Z/p^K"""
    out = []
    mod = p ** K
    for r in range(2, p):
        if pow(r, 5, p) == 1:
            x = r
            for _ in range(K + 2):                 # Newton for x^5 - 1 (simple root mod p)
                x = (x - (pow(x, 5, mod) - 1) * pow(5 * pow(x, 4, mod), -1, mod)) % mod
            out.append(x)
    return out
def valuations(x, p, K=200):
    """list of (name, valuation) at the primes above p; e = ramification index"""
    if p == 5:
        return [("lambda", vp_int(norm(x), 5), 4)]          # v_lambda(x) = v_5(N(x)); 5 = unit * lambda^4
    if p % 5 == 1:
        out = []
        for r in roots_mod(p, K):
            val = (x[0] + x[1] * r + x[2] * r * r + x[3] * r ** 3) % (p ** K)
            out.append(("P(z->%d)" % (r % p), vp_int(val, p) if val else K, 1))
        return out
    return [("(%d)" % p, min(vp_int(c, p) for c in x), 1)]   # inert (p = 2, 3 mod 5) or p = 4 mod 5 (two primes, f=2)

def Ep(p, n):
    a = ap(1, p, T); d = detp(1, p)
    return add(sub(ONE, scal(p ** (n - 1), a)), scal(p ** (2 * n - 2), d))

report = {}
for p in (3, 5, 7, 11, 13):
    if p % 5 == 4: continue
    ns = sorted(n for n in vals if (n - 1) % (p - 1) == 0)
    Ls = {n: mul(Ep(p, n), vals[n]) for n in ns}
    Lstar1 = mul(Ep(p, 1), L0)
    E1 = Ep(p, 1)
    triv = (E1 == ZERO)
    lines = []
    # (U)/(Z)
    unit_rows = []
    for n in ns:
        vs = valuations(Ls[n], p)
        unit_rows.append((n, [(nm, v) for nm, v, e in vs]))
    # (K) all pairs
    worst = None; npairs = 0; tight = 0
    for i, n in enumerate(ns):
        for n2 in ns[i + 1:]:
            pred = vp_int(n2 - n, p) + 1
            for nm, v, e in valuations(sub(Ls[n], Ls[n2]), p):
                npairs += 1
                margin = v - e * pred
                if v == e * pred: tight += 1
                if worst is None or margin < worst[0]: worst = (margin, n, n2, nm, v, e * pred)
    # (L) limit
    lim = []
    for n in ns:
        k = vp_int(n - 1, p)
        if k >= 1:
            vs = valuations(sub(Ls[n], Lstar1), p)
            lim.append((n, k, [(nm, v, e * (k + 1)) for nm, v, e in vs]))
    report[p] = {"trivial_zero": triv, "ns": ns, "units": unit_rows, "kummer_pairs": npairs, "kummer_tight": tight,
                 "kummer_worst_margin": worst, "limit": lim, "E_p(1)": E1, "norm E_p(1)": norm(E1)}
    print("p = %d  (E_p(1) = %s, norm %d, trivial zero: %s), %d values n = 1 mod %d: %s" %
          (p, E1, norm(E1), triv, len(ns), p - 1, ns))
    if triv:
        print("  (Z) valuations v_P(L*(n)) vs predicted lower bound v_p(n-1)+1 (equality = simple zero, unit derivative):")
        for n, vs in unit_rows:
            print("     n=%-5d v_p(n-1)+1=%d  %s" % (n, vp_int(n - 1, p) + 1, vs))
    else:
        nonunit = [(n, vs) for n, vs in unit_rows if any(v for nm, v in vs)]
        print("  (U) L*(n) a p-adic unit at every prime above p for all %d n: %s%s" %
              (len(ns), not nonunit, "" if not nonunit else "  exceptions: %s" % nonunit[:6]))
    print("  (K) Kummer: %d prime-pair checks, worst margin (observed - predicted valuation) = %s; equality in %d" %
          (npairs, worst[0] if worst else None, tight), worst)
    print("  (L) limit to s = 0:", [(n, k, vs) for n, k, vs in lim])
json.dump({str(p): {k: (v if not isinstance(v, tuple) else list(v)) for k, v in r.items()} for p, r in report.items()},
          open("padic_report.json", "w"), indent=1, default=str)
