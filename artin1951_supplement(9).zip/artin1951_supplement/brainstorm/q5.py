"""Shared helpers for the brainstorm experiments (Dula).

Q(zeta5) arithmetic in the basis 1, z, z^2, z^3 (z^4 = -1 - z - z^2 - z^3), the Frobenius data of
rho = rho0 (x) chi^3 (conductor 1951) and of its three Gal(Q(zeta5)/Q)-conjugates
    rho_1 = rho = rho0 x chi^3,  rho_4 = conj(rho) = rho0 x chi^2,  rho_2 = rho0'' x chi,  rho_3 = rho0'' x chi^4,
all of conductor 1951 (tau_k: zeta5 -> zeta5^k; tau_2 restricted to Q(sqrt5) is sigma: sqrt5 -> -sqrt5).
a_p(rho) = t_p * zeta5^{dl(p)}, t_p = tr rho0(Frob_p) in Z[phi], dl = log_3 mod 1951 (chi^3(p) = zeta5^{6 dl} = zeta5^{dl});
a_1951(rho) = zeta5^2 (overnight/traces/local1951.json, t30M.log)."""
import json, math
from fractions import Fraction
N = 1951
PHI = (1 + 5 ** .5) / 2
# --- Q(zeta5) as 4-vectors -------------------------------------------------------------------------------------------
def red(v):
    """reduce a coefficient list of any length modulo 1 + z + z^2 + z^3 + z^4 (z^5 = 1 first)"""
    w = [0] * 5
    for i, c in enumerate(v): w[i % 5] += c
    return tuple(w[i] - w[4] for i in range(4))
def mul(a, b):
    w = [0] * 7
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b):
                if y: w[i + j] += x * y
    return red(w)
def add(a, b): return tuple(x + y for x, y in zip(a, b))
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def scal(c, a): return tuple(c * x for x in a)
ONE = (1, 0, 0, 0); ZERO = (0, 0, 0, 0)
def zpow(j): return red([0] * (j % 5) + [1])
def tau(k, a):
    """Galois automorphism z -> z^k"""
    w = [0] * 25
    for i, c in enumerate(a): w[(i * k) % 5] += c
    return red(w)
def norm(a):
    r = ONE
    for k in (1, 2, 3, 4): r = mul(r, tau(k, a))
    assert r[1] == r[2] == r[3] == 0
    return r[0]
# phi = 1 + z + z^4 = -z^2 - z^3 ;  phi - 1 = z + z^4 = -1 - z^2 - z^3
PHIV = (0, 0, -1, -1)
TRACE = {"2": (2, 0, 0, 0), "-2": (-2, 0, 0, 0), "0": ZERO, "1": ONE, "-1": (-1, 0, 0, 0),
         "phi": PHIV, "-phi": scal(-1, PHIV), "phi-1": sub(PHIV, ONE), "1-phi": sub(ONE, PHIV)}
def label(t):
    for val, s in ((PHI, "phi"), (-PHI, "-phi"), (PHI - 1, "phi-1"), (1 - PHI, "1-phi")):
        if abs(t - val) < 1e-9: return s
    return str(int(round(t)))
dl = {}
_t = 1
for _k in range(N - 1): dl[_t] = _k; _t = _t * 3 % N
assert len(dl) == N - 1
def chi_exp(n): return (2 * dl[n % N]) % 5          # chi(n) = zeta5^{chi_exp(n)}, chi of order 5, conductor 1951
def load(path="/home/claude/research/overnight/traces/galois_traces_3200000.json"):
    D = json.load(open(path))
    return {int(p): label(t) for p, t in D["t"].items()}, D
def ap(k, p, T):
    """exact a_p of rho_k = tau_k(rho) as a 4-vector; p = 1951 gives the inertia-invariant eigenvalue"""
    if p == N: return zpow(2 * k)
    return tau(k, mul(TRACE[T[p]], zpow(dl[p % N])))
def detp(k, p):
    """det rho_k(Frob_p) = tau_k(chi(p)) = zeta5^{k * chi_exp(p)}  (det rho = det rho0 * chi^6 = chi)"""
    return zpow(k * chi_exp(p))
def emb(a, k, ctx):
    """complex embedding z -> exp(2 pi i k/5) using an mpmath-like context"""
    z = ctx.expjpi(ctx.mpf(2 * k) / 5)
    return a[0] + a[1] * z + a[2] * z ** 2 + a[3] * z ** 3
