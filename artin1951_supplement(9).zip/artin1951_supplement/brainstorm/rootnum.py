"""Exact root numbers of the four conductor-1951 conjugates rho_k (k = 1, 2, 3, 4).
1) PARI lfunrootres at 80 digits with exact coefficients (no holomorphy needed for the FE itself, but lfunrootres
   assumes no poles: it is only used to SELECT among exact candidates);
2) candidates W = eps * zeta5^j * tau(chi^m)/sqrt(1951) (Gauss sums of the order-5 characters mod 1951);
3) the unique candidate within 1e-60 is taken as exact.  Local reason: W = W_inf * W_1951 with W_inf = i^2 = -1
   (rho(c) = -I) and W_1951 = epsilon factor of the tamely ramified order-5 summand of rho|D_1951 (a Gauss sum times its
   value at the uniformiser)."""
import sys, json, cypari2, mpmath
from q5 import *
pari = cypari2.Pari(); pari.allocatemem(2 * 10**9); pari.set_real_precision(80)
mpmath.mp.dps = 90
T, D = load()
def coeffs(k, M):
    """exact a_n (4-vectors) of rho_k for n <= M"""
    a = [None, ONE] + [None] * (M - 1)
    for p in sorted(x for x in list(T) + [N] if x <= M):
        if p == N: A = [ONE]; q = 1
        else: A = [ONE]; q = 1
        apk = ap(k, p, T); dk = detp(k, p) if p != N else ZERO
        while q * p <= M:
            if len(A) == 1: A.append(apk)
            else: A.append(sub(mul(apk, A[-1]), mul(dk, A[-2])) if p != N else mul(apk, A[-1]))
            q *= p
        pk = 1; e = 0
        while pk * p <= M:
            pk *= p; e += 1
            for m in range(1, M // pk + 1):
                if m % p and a[m] is not None and a[m * pk] is None: a[m * pk] = mul(a[m], A[e])
    return a
if __name__ == "__main__":
    M = int(sys.argv[1]) if len(sys.argv) > 1 else 4000
    z = pari("exp(2*Pi*I/5)")
    res = {}
    gs = {}
    for m in (1, 2, 3, 4):
        s = mpmath.mpc(0)
        for x in range(1, N):
            s += mpmath.expjpi(mpmath.mpf(2 * ((m * chi_exp(x)) % 5)) / 5) * mpmath.expjpi(mpmath.mpf(2 * x) / N)
        gs[m] = s / mpmath.sqrt(N)
    for k in (1, 2, 3, 4):
        a = coeffs(k, M)
        v = pari.vector(M, [x[0] + x[1] * z + x[2] * z ** 2 + x[3] * z ** 3 for x in a[1:]])
        L = pari.lfuncreate([v, 1, [1, 1], 1, N, 0])
        need = pari.lfunthetacost(L)
        w = pari.lfunrootres(L)[2]
        L2 = pari.lfuncreate([v, 1, [1, 1], 1, N, w])
        fe = pari.lfuncheckfeq(L2)
        wc = mpmath.mpc(str(pari.real(w)), str(pari.imag(w)))
        best = []
        for eps in (1, -1):
            for j in range(5):
                for m in (1, 2, 3, 4):
                    c = eps * mpmath.expjpi(mpmath.mpf(2 * j) / 5) * gs[m]
                    best.append((abs(c - wc), eps, j, m))
        best.sort()
        print("rho_%d: thetacost %s (have %d)  FE defect %s  W = %s" % (k, need, M, fe, mpmath.nstr(wc, 25)))
        print("   best candidates:", [(mpmath.nstr(b[0], 3), b[1:]) for b in best[:3]])
        res[k] = {"eps": best[0][1], "j": best[0][2], "m": best[0][3], "dist": float(best[0][0]), "dist2": float(best[1][0]),
                  "W": [str(wc.real), str(wc.imag)], "fe": int(fe)}
    json.dump(res, open("rootnumbers.json", "w"), indent=1)
