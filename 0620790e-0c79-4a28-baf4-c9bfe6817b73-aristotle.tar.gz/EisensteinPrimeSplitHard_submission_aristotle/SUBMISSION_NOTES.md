# Piece 4b submission — EisensteinPrimeSplitHard.lean

## Target theorem
`split_prime (p : ℕ) (hp : p.Prime) (hmod : p % 3 = 1) : ∃ z : Eisenstein, norm z = (p : ℤ)`

Every rational prime p ≡ 1 (mod 3) is the norm of an Eisenstein integer.

## Route: Thue's lemma (NOT Zagier's involution)
Chosen to avoid the buggy 10-region piecewise involution in arXiv:2511.19763.

Four declarations:
1. `exists_cube_root_of_unity` — ∃ζ:ZMod p, ζ²+ζ+1=0, via Cauchy's theorem
   (`exists_prime_order_of_dvd_card 3`, since 3 ∣ p-1 = card (ZMod p)ˣ).
2. `thue` — pigeonhole on the grid [0,⌊√p⌋]² → ZMod p gives small (u,v)≠0
   with (u:ZMod p) = ζ·v. Built from `Finset.exists_ne_map_eq_of_card_lt_of_maps_to`.
3. `quadForm_zmod_three` — (u²+uv+v² : ZMod 3) ≠ 2, by `decide`. The parity
   obstruction that excludes Q=2p.
4. `split_prime` — assembles: p∣Q, Q>0, Q<3p ⟹ Q∈{p,2p}; mod-3 kills 2p; Q=p;
   then z=⟨u,-v⟩ has norm u²+uv+v² = p.

## Numerically verified (Python, all primes p≡1 mod3 < 5000)
- cube root + Thue gives u²+uv+v² = p exactly (ratio Q/p always = 1.0)
- u²+uv+v² mod 3 ∈ {0,1}, never 2 (the exclusion is airtight)

## Anti-stub note for Aristotle
EisensteinIntegers.lean is the previously-verified base (norm z = a²-ab+b²).
Please build against it as-is; do not regenerate it as a stub. Only
EisensteinPrimeSplitHard.lean is new. 0 sorries in both.

## Mathlib pin: v4.28.0
