import Mathlib
import EisensteinIntegers

/-!
# Eisenstein theta function (stub)

Placeholder for the theta function `r(n) = #{z ∈ ℤ[ω] | N(z) = n}`.
-/
