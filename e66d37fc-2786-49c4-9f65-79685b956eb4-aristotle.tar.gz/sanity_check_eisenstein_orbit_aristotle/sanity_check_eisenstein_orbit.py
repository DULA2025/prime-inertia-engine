#!/usr/bin/env python3
"""
sanity_check_eisenstein_orbit.py
================================

Numerical verification of the claims in EisensteinOrbit.lean:

  1. norm(z) = 0 ⟺ z = 0
  2. Z[ω] has no zero divisors (z·w = 0 ⟹ z = 0 or w = 0)
  3. For nonzero z, the orbit {u·z : u ∈ unitSet} has exactly 6 elements
"""


def mul(p, q):
    """(a+bω)(c+dω) = (ac-bd) + (ad+bc-bd)ω"""
    a, b = p
    c, d = q
    return (a*c - b*d, a*d + b*c - b*d)


def norm(z):
    """N(a + bω) = a² - ab + b²"""
    a, b = z
    return a*a - a*b + b*b


UNITS = [(1, 0), (-1, 0), (0, 1), (0, -1), (-1, -1), (1, 1)]


def main():
    print("=" * 72)
    print(" Sanity check: EisensteinOrbit.lean")
    print("=" * 72)

    # --- Check 1: norm = 0 iff z = 0 ---
    print("\nCheck 1: norm(z) = 0 ⟺ z = 0")
    test_pairs = [(0, 0), (1, 0), (0, 1), (1, 1), (-1, -1), (2, 0),
                  (0, 2), (3, 5), (-7, 11), (-3, -3)]
    fails = []
    for z in test_pairs:
        n = norm(z)
        is_zero_z = (z == (0, 0))
        is_zero_n = (n == 0)
        ok = (is_zero_z == is_zero_n)
        if not ok:
            fails.append((z, n))
        print(f"  z = ({z[0]:>2}, {z[1]:>2}): norm = {n:>5}, "
              f"z=0: {is_zero_z}, norm=0: {is_zero_n}  {'✓' if ok else '✗'}")
    if fails:
        print(f"  FAILED on {fails}")

    # Exhaustive search: are there any nonzero z with norm = 0?
    print("\n  Exhaustive search for nonzero z with norm = 0 in [-20, 20]²:")
    found_nz_zero = []
    for a in range(-20, 21):
        for b in range(-20, 21):
            if (a, b) != (0, 0) and norm((a, b)) == 0:
                found_nz_zero.append((a, b))
    print(f"  Found {len(found_nz_zero)} (should be 0)")

    # --- Check 2: no zero divisors ---
    print("\nCheck 2: z · w = 0 ⟹ z = 0 or w = 0")
    test_zws = [
        ((1, 0), (1, 0)),
        ((1, 1), (-1, -1)),  # = -ω² · ω² = -1
        ((0, 1), (0, 1)),    # = ω² = ⟨-1, -1⟩
        ((2, 3), (5, -1)),
        ((0, 0), (3, 7)),    # zero × nonzero = 0
        ((-5, 11), (0, 0)),  # nonzero × zero = 0
    ]
    for z, w in test_zws:
        prod = mul(z, w)
        z_is_zero = (z == (0, 0))
        w_is_zero = (w == (0, 0))
        prod_is_zero = (prod == (0, 0))
        if prod_is_zero:
            # Should have z=0 or w=0
            ok = (z_is_zero or w_is_zero)
            print(f"  ({z}) · ({w}) = {prod} (zero): "
                  f"z=0 or w=0: {z_is_zero or w_is_zero}  {'✓' if ok else '✗'}")
        else:
            print(f"  ({z}) · ({w}) = {prod} (nonzero)")

    # --- Check 3: orbit size = 6 for all nonzero z ---
    print("\nCheck 3: for nonzero z, |orbit z| = 6")
    test_zs = [(1, 0), (2, 0), (1, 1), (0, 1), (3, 5), (-2, 1),
               (0, 7), (5, -2), (-1, -1), (1, -1), (7, 11)]
    all_pass = True
    for z in test_zs:
        orbit = [mul(u, z) for u in UNITS]
        unique = set(orbit)
        ok = (len(unique) == 6)
        if not ok:
            all_pass = False
        print(f"  z = ({z[0]:>2}, {z[1]:>2}): |orbit| = {len(unique)}  "
              f"{'✓' if ok else '✗'}")

    print(f"\n  All {len(test_zs)} test cases pass: {'✓' if all_pass else '✗'}")

    # --- Check 4: orbit of 0 collapses to {0} ---
    print("\nCheck 4: orbit of 0 = {0}")
    orbit_zero = set(mul(u, (0, 0)) for u in UNITS)
    print(f"  orbit(0) = {orbit_zero}")
    print(f"  size = {len(orbit_zero)} (should be 1)  "
          f"{'✓' if len(orbit_zero) == 1 else '✗'}")

    # --- Check 5: large-range orbit-size check ---
    print("\nCheck 5: orbit-size-6 for ALL nonzero z in [-10, 10]²")
    fails = 0
    total = 0
    for a in range(-10, 11):
        for b in range(-10, 11):
            if (a, b) == (0, 0):
                continue
            total += 1
            orbit = [mul(u, (a, b)) for u in UNITS]
            if len(set(orbit)) != 6:
                fails += 1
                if fails <= 3:
                    print(f"  FAIL at z=({a},{b}): "
                          f"orbit has {len(set(orbit))} elements")
    print(f"  Tested {total} nonzero z's, {fails} fails  "
          f"{'✓' if fails == 0 else '✗'}")

    print()
    print("=" * 72)
    print(" Sanity check complete")
    print("=" * 72)


if __name__ == '__main__':
    main()
