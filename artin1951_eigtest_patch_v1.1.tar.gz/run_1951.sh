#!/usr/bin/env bash
# The test at level 1951 (section 8 of the paper): depth of tr rho on the four refinements of
# H^1(Gamma_0(1951 O_E), V_{3,3} / 16), E = Q(sqrt-7).  Prediction: depth exactly 3 at the mixed refinements.
#
# Resources: about 40-50 GB of RAM (projected from the level-633 run, 5.8 GB at index 449 440; 1951 has index
# 3 806 402), of the order of a day on 8-16 cores.  Every stage is cached in $ARTIN_OUT/cache_p2/N1951, so a run that is
# stopped (or killed) resumes from the last completed stage when started again with the same settings.
#
# Usage:  bash run_1951.sh main       the test itself
#         bash run_1951.sh control    the same with one eigenvalue shifted by 2 (must give depth 1)
#         (for Sage: PY="sage -python" bash run_1951.sh main)
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="${PY:-python3}"
WHAT="${1:-main}"
export ARTIN_ROOT="$HERE"
export ARTIN_OUT="${ARTIN_OUT:-$HERE/out_1951}"
export NUMBA_NUM_THREADS="${NUMBA_NUM_THREADS:-$(nproc)}"
# Lanczos block / 64 for the first solve.  If it is too small the solver widens it by itself and repeats the solve
# (costs time, not correctness).  40 = 2560 vectors.
export P2_LW="${P2_LW:-40}"
# Lanczos checkpoints: a solve that is interrupted resumes from its last checkpoint (saved every 10 minutes).
export P2_LCACHE="${P2_LCACHE:-$ARTIN_OUT/cache_p2/N1951/lanczos}"
mkdir -p "$ARTIN_OUT"; cd "$ARTIN_OUT"
case "$WHAT" in
  main)    EXTRA=() ;;
  control) EXTRA=(P2_ESHIFT=q11:2) ;;
  *) echo "usage: run_1951.sh main|control"; exit 2 ;;
esac
LOG="$ARTIN_OUT/eigtest_1951_${WHAT}_$(date +%Y%m%d_%H%M%S).log"
echo "log: $LOG"
( set -x; env ${EXTRA[@]+"${EXTRA[@]}"} P2_S=4 P2_EIGTEST=1 $PY -I "$HERE/families/p2_mod8.py" 1951 ) > "$LOG" 2>&1 || {
  code=$?; echo "run ended with exit code $code (137 = killed for memory: start the same command again to resume)"; tail -30 "$LOG"; exit $code; }
grep -E "^## (case|mod 2|eigenvalue|conjugates|K =|mod [0-9]+:|depth|done)|^   u = " "$LOG"
echo "result file: $ARTIN_OUT/p2_eigtest_N1951_mod16*.json"
