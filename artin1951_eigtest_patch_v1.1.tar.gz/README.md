# The test at level 1951: code for a local run

Author: Dula. Companion to the paper "The even icosahedral representation of conductor 1951" (section 8).

**What it computes.** The depth of the eigensystem tr ρ(Frob_q) of the even icosahedral representation ρ of conductor 1951, at 13 Hecke operators away from 2, on each of the four refinements u = (T_v, T_v̄) of H¹(Γ₀(1951·𝒪_E), V₃,₃ / 16), E = ℚ(√−7). Depth s means that a class whose reduction is the residual eigenvector of u lifts to a cocycle mod 2^s that is an eigenvector of the system mod 2^s. The computation is exact: every lift is verified on every relation, and every solve has a certified kernel.

**Prediction (Conjecture 8.2 of the paper): depth exactly 3 at both mixed refinements, (6,9) and (9,6).**

| Result at the mixed refinements | Meaning |
|---|---|
| depth 3 | as predicted; evidence for AW1, proves nothing |
| depth below 3 | contradicts Artin for ρ together with C2 and ordinary local–global compatibility at 2 |
| depth 4 | contradicts ordinary local–global compatibility at 2 for these torsion classes |
| control (`run_1951.sh control`) not at depth 1 | the test has no power; the main result does not count |

## 1. Requirements

- Linux or WSL2, 64 GB RAM (projected need 40–50 GB), 8 or more cores, about 30 GB free disk for the caches.
- Python ≥ 3.10 with numpy, numba and cypari2. Versions used for the validation: Python 3.13.16, numpy 2.5.3, numba 0.68.0, cypari2 2.2.4 (PARI 2.17.2).

Option A, plain Python (recommended):
```
python3 -m venv ~/artin-venv && source ~/artin-venv/bin/activate
pip install numpy numba cypari2
```
If `pip install cypari2` tries to compile and fails, install PARI first (`sudo apt install pari-gp libpari-dev`) and repeat.

Option B, Sage: Sage ships numpy and cypari2. Add numba with `sage -pip install numba` and run every script with `PY="sage -python"` in front, e.g. `PY="sage -python" bash run_validation.sh`.

**WSL2 memory.** By default WSL2 gets only half of the machine's RAM. Put this in `C:\Users\<you>\.wslconfig`, then run `wsl --shutdown` in PowerShell and reopen the terminal:
```
[wsl2]
memory=60GB
swap=16GB
```
Check with `free -g` inside WSL.

## 2. Validate first (about 4 minutes)

```
bash run_validation.sh
```
It runs the same algorithm on the even tetrahedral representation of conductor 163, which is automorphic, so the answer is known. It then runs three controls and a check of the 1951 eigenvalue conventions. The script prints the expected lines next to the actual ones. They must match exactly:

```
t163_main   : depth {'1,12': 3, '12,1': 3, '1,1': 3, '12,12': 3}
t163_shift2 : depth 1 at all four
t163_shift4 : depth 2 at all four
t163_conj   : depth 0 at all four
conjugate 1 differs at 0 primes; conjugates 2, 3, 4 differ at 29, 29, 26
```
If they do not match, stop and send me the logs in `out_validation/`.

## 3. Run 1951

```
tmux new -s artin            # or screen; the run takes about a day
bash run_1951.sh main
```
- Output folder: `out_1951/`, or whatever `ARTIN_OUT` is set to. Use a fast disk with about 30 GB free.
- Result: `out_1951/p2_eigtest_N1951_mod16.json` (`"depth"`), plus the log `out_1951/eigtest_1951_main_<date>.log`.
- **Resuming.** The first solve (A1.npz), the Hecke matrices (TM.npz, TE.npz) and the Lanczos checkpoints are cached in `out_1951/cache_p2/N1951/`. If the run stops (exit 137 = killed for memory, or a reboot), start the same command again; it continues from the last completed stage.
- **Lanczos checkpoints (version 1.1).** `P2_LCACHE` (set by `run_1951.sh`) saves the state of each Lanczos solve every 10 minutes in `out_1951/cache_p2/N1951/lanczos/`, so an interrupted solve resumes where it stopped instead of starting over. Version 1.0 had no checkpoints inside a solve. The elimination before each solve (about 1.5 h at 1951) is not cached and is redone on restart.
- Threads: `NUMBA_NUM_THREADS` defaults to all cores. Lower it if the machine must stay usable.
- Block size: `P2_LW=40` (2560 Lanczos vectors) for the first solve. If the kernel is larger, the solver widens the block and repeats that solve by itself; the log says `block widened to ...`.

Then run the control:
```
bash run_1951.sh control     # one eigenvalue shifted by 2; expected depth 1; reuses the caches, much faster
```

What the log shows, in order:
1. `## case N1951 ...`, the level and the residual data.
2. `## mod 2: dim Z^1 = ..., dim H^1 = ...`, the first solve.
3. `## eigenvalue test ...`, the Hecke matrices for the 13 operators.
4. `## conjugates of rho whose reduction is ...: [1]`.
5. `## K = ... dimension ...`.
6. One line per modulus, `## mod 4: ...`, `## mod 8: ...`, `## mod 16: ...`.
7. `## depth ...`, the result.

## 4. Send back

`out_1951/*.json`, `out_1951/*.log` and `out_1951/cache_p2/N1951/lanczos_runs.json`, if present. Do not send the `.npz` caches: they are large and can be regenerated.

## Contents

| Path | What |
|---|---|
| `families/p2_mod8.py` | the driver; stage E (`P2_EIGTEST=1`) is the test |
| `families/p2lift.py`, `p2big.py`, `p2_cases.py`, `vdec.py`, `vbock.py`, `t6lib.py`, `bianchi4.py` | level construction, coefficients, solvers, cases |
| `bianchi2/*.py`, `twins/fp_hecke.py` | presentation of PGL₂(𝒪_E), coset graph, Hecke operators, F₁₆ block Lanczos |
| `families/check_lam1951.py` | check of the characteristic-0 eigenvalues of ρ against the residual system |
| `data/classes_1951.json` | Frobenius classes in A₅ (residual system) |
| `data/galois_traces_1951.json` | t_p for p < 100 000, with tr ρ(Frob_p) = χ(p)³ t_p |
| `families/t163_traces.json` | traces of the tetrahedral validation case |

Environment variables: `ARTIN_ROOT` (this folder; found automatically), `ARTIN_OUT` (output and caches), `P2_S` (precision 2^S; 4 for the test), `P2_LW`, `P2_EOPS` (operator list), `P2_ESHIFT=op:amount` and `P2_ECONJ=j` (controls), `NUMBA_NUM_THREADS`.

The code is research code, written for this computation. A smoke test of the 1951 path on an 8 GB machine built the level correctly (2.8 GB, (x, y) = (6, 9)) and stopped for memory at the first row construction, as expected.
