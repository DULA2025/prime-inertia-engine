#!/usr/bin/env python3
"""
sanity_check_eisenstein_units.py
================================

Numerical verification of the claims in EisensteinUnits.lean:

  1. The six elements {1, -1, ω, -ω, ω², -ω²} of Z[ω] all have norm 1.
  2. Every Z[ω] element with norm 1 is one of these six.
  3. An Eisenstein element is a unit iff its norm is 1.
"""


def norm(a, b):
    """N(a + bω) = a² - ab + b²"""
    return a*a - a*b + b*b


def mul(p, q):
    """(a+bω)(c+dω) = (ac-bd) + (ad+bc-bd)ω"""
    a, b = p
    c, d = q
    return (a*c - b*d, a*d + b*c - b*d)


def main():
    print("=" * 70)
    print(" Sanity check: 6 units of Z[ω]")
    print("=" * 70)

    # The six expected units, in Lean's convention:
    units_named = {
        "1":   (1, 0),
        "-1":  (-1, 0),
        "ω":   (0, 1),
        "-ω":  (0, -1),
        "ω²":  (-1, -1),
        "-ω²": (1, 1),
    }

    # Check 1: all have norm 1
    print("\nCheck 1: all six expected units have norm 1")
    all_norm_one = True
    for name, (a, b) in units_named.items():
        n = norm(a, b)
        print(f"  N({name}) = N(⟨{a:>2}, {b:>2}⟩) = {n}  {'✓' if n == 1 else '✗'}")
        if n != 1:
            all_norm_one = False
    print(f"  {'All have norm 1: ✓' if all_norm_one else 'FAILED'}")

    # Check 2: enumerate all (a, b) with norm = 1
    print("\nCheck 2: enumerate all (a, b) ∈ ℤ² with norm(a, b) = 1")
    found = []
    for a in range(-3, 4):
        for b in range(-3, 4):
            if norm(a, b) == 1:
                found.append((a, b))
    print(f"  Found {len(found)} solutions: {found}")
    expected = set(units_named.values())
    found_set = set(found)
    matches = (found_set == expected)
    print(f"  Matches expected set: {'✓' if matches else '✗'}")

    # Check 3: verify the multiplicative structure (group)
    print("\nCheck 3: the 6 units form a cyclic group of order 6")
    # Start at -ω² = ⟨1, 1⟩ (a primitive 6th root of unity in Z[ω])
    # Powers: ζ = ⟨1, 1⟩, ζ² = ?, ..., ζ⁶ should = ⟨1, 0⟩
    primitive = (1, 1)  # this is -ω²; let's check it's order 6
    powers = [primitive]
    cur = primitive
    for k in range(2, 8):
        cur = mul(cur, primitive)
        powers.append(cur)
        if cur == (1, 0):
            break
    print(f"  Powers of -ω² = ⟨1, 1⟩:")
    for k, p in enumerate(powers, 1):
        # Look up which named unit this is
        names_by_pair = {v: k for k, v in units_named.items()}
        label = names_by_pair.get(p, "?")
        print(f"    (-ω²)^{k} = ⟨{p[0]:>2}, {p[1]:>2}⟩ = {label}")
    cyclic_6 = (len(powers) == 6 and powers[-1] == (1, 0))
    print(f"  Cyclic of order 6: {'✓' if cyclic_6 else '✗'}")

    # Check 4: explicit conjugate-inverse pairing
    print("\nCheck 4: conj(z) is the inverse of z for each unit")
    # conj(⟨a, b⟩) = ⟨a - b, -b⟩
    def conj(p):
        a, b = p
        return (a - b, -b)
    for name, z in units_named.items():
        cz = conj(z)
        prod = mul(z, cz)
        # Look up
        prod_name = next((k for k, v in units_named.items() if v == prod), "?")
        is_one = (prod == (1, 0))
        print(f"  conj({name}) · {name} = {prod_name}  {'✓' if is_one else '✗'}")

    # Check 5: any element with non-unit norm is NOT a unit
    print("\nCheck 5: spot-check non-units (norm ≠ 1)")
    non_unit_examples = [(2, 0), (1, -1), (1, 2), (3, 1), (5, 0)]
    for (a, b) in non_unit_examples:
        n = norm(a, b)
        # Is there any (c, d) with (a, b) · (c, d) = (1, 0)?
        is_unit = False
        for c in range(-10, 11):
            for d in range(-10, 11):
                if mul((a, b), (c, d)) == (1, 0):
                    is_unit = True
                    break
            if is_unit: break
        # Theoretical: unit iff norm = 1
        theory_is_unit = (n == 1)
        match = (is_unit == theory_is_unit)
        print(f"  ⟨{a:>2}, {b:>2}⟩: norm = {n}, "
              f"unit (by search) = {is_unit}, theory = {theory_is_unit}, "
              f"{'✓' if match else '✗'}")

    print()
    print("=" * 70)
    print(" All checks complete")
    print("=" * 70)


if __name__ == '__main__':
    main()
