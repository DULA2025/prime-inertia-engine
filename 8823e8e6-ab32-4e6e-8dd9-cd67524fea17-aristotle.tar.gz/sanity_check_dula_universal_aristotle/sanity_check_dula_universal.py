#!/usr/bin/env python3
"""
sanity_check_dula_universal.py
==============================

Numerical sanity check for DULAUniversal.lean.

The universal pattern: for any modulus k and subgroup H ≤ (Z/kZ)*, the map
  toQuotient_H : { n > 0, gcd(n, k) = 1 } → (Z/kZ)* / H
sending n ↦ [n mod k] is a monoid homomorphism.

This checks the property exhaustively across several (k, H) instances,
including the two we've formalized as specific cases:
  - (k=6, H=trivial): the quadratic DULAGradedMonoid instance
  - (k=9, H=cubes={1,8}): the cubic DULACubic instance
plus additional instances to validate the abstraction.
"""

import sys
import math
from itertools import product


def units_mod(k):
    return [n for n in range(k) if math.gcd(n, k) == 1]


def coset(n, H, k):
    """Coset n·H in (Z/kZ)*"""
    return frozenset((n * h) % k for h in H)


def quotient_classes(k, H):
    """List of distinct cosets of H in (Z/kZ)*"""
    U = units_mod(k)
    seen = []
    for u in U:
        c = coset(u, H, k)
        if c not in seen:
            seen.append(c)
    return seen


def banner(t):
    print(f"\n{'─'*76}\n  {t}\n{'─'*76}")


def check_instance(name, k, H, prime_limit=200):
    """Verify universal homomorphism for one (k, H) instance."""
    banner(f"Instance: {name}  (k={k}, H={sorted(H)})")
    classes = quotient_classes(k, H)
    cls_index = {c: i for i, c in enumerate(classes)}
    print(f"  Quotient has {len(classes)} classes:")
    for i, c in enumerate(classes):
        print(f"    class {i}: {sorted(c)}")
    
    # Verify: for all a, b coprime to k, toQuotient(a*b) = toQuotient(a) · toQuotient(b)
    # In the quotient, multiplication is well-defined; this is the homomorphism check.
    ok = True
    n_pairs = 0
    for a in range(1, prime_limit):
        if math.gcd(a, k) != 1: continue
        for b in range(1, prime_limit):
            if math.gcd(b, k) != 1: continue
            n_pairs += 1
            class_a = cls_index[coset(a, H, k)]
            class_b = cls_index[coset(b, H, k)]
            class_ab = cls_index[coset((a*b) % k, H, k)]
            # In the quotient, the product class is the coset of a*b:
            # We check that this is consistent with multiplication of class representatives.
            class_a_rep = min(classes[class_a])
            class_b_rep = min(classes[class_b])
            expected_class = cls_index[coset((class_a_rep * class_b_rep) % k, H, k)]
            if class_ab != expected_class:
                print(f"  a={a}, b={b}: class(a*b)={class_ab}, expected {expected_class}  FAIL")
                ok = False
    print(f"  Checked {n_pairs} (a,b) pairs: {'OK' if ok else 'FAIL'}")
    return ok


def check_one_maps_to_identity(name, k, H):
    """Verify toQuotient(1) = identity of the quotient group."""
    print(f"  {name}: toQuotient(1) = identity?")
    classes = quotient_classes(k, H)
    cls_index = {c: i for i, c in enumerate(classes)}
    # The identity class is the one containing 1, which is H itself.
    identity_class = cls_index[coset(1, H, k)]
    expected_identity = cls_index[frozenset(H)]
    ok = (identity_class == expected_identity == 0)
    # Actually, by our `quotient_classes` ordering, class 0 contains 1, so this should pass.
    print(f"    class of 1 = {identity_class} (should be 0 = {sorted(classes[0])}): {'OK' if ok else 'FAIL'}")
    return ok


def consistency_with_dula_graded_monoid():
    """For k=6, H trivial, the laneIndex matches DULAGradedMonoid."""
    banner("Consistency with DULAGradedMonoid (quadratic case)")
    k = 6
    H = [1]
    classes = quotient_classes(k, H)
    # In DULAGradedMonoid: lane 0 = residue 1, lane 1 = residue 5
    # In universal: classes are [{1}] and [{5}]
    print(f"  Universal classes: {[sorted(c) for c in classes]}")
    expected = [{1}, {5}]
    actual = [set(c) for c in classes]
    ok = (actual == expected)
    print(f"  Matches DULAGradedMonoid: {'OK' if ok else 'FAIL'}")
    return ok


def consistency_with_dula_cubic():
    """For k=9, H=cubes={1,8}, the lanes match DULACubic."""
    banner("Consistency with DULACubic (cubic case)")
    k = 9
    H = [1, 8]
    classes = quotient_classes(k, H)
    # In DULACubic: Lane0={1,8}, Lane1={2,7}, Lane2={4,5}
    print(f"  Universal classes: {[sorted(c) for c in classes]}")
    expected = [{1, 8}, {2, 7}, {4, 5}]
    actual = [set(c) for c in classes]
    ok = (actual == expected)
    print(f"  Matches DULACubic: {'OK' if ok else 'FAIL'}")
    return ok


CHECKS = [
    # Specific instances we've formalized
    ("k=6, H=trivial (quadratic DULA)",          6,  [1]),
    ("k=9, H=cubes={1,8} (cubic DULA)",          9,  [1, 8]),
    # Additional instances to validate the abstraction
    ("k=12, H=trivial",                          12, [1]),
    ("k=24, H=trivial",                          24, [1]),
    ("k=8, H=trivial",                           8,  [1]),
    ("k=15, H=trivial",                          15, [1]),
    ("k=30, H=trivial",                          30, [1]),
    # Non-trivial subgroup at composite k
    ("k=12, H={1, 11} = ±1",                     12, [1, 11]),
    ("k=15, H={1, 4} (squares ∩ {1,4})",         15, [1, 4]),
]


def main():
    print("=" * 78)
    print("  DULAUniversal.lean — numerical sanity check")
    print("=" * 78)
    
    results = []
    for name, k, H in CHECKS:
        ok = check_instance(name, k, H, prime_limit=100)
        results.append((name, ok))
    
    # Cross-checks with existing instances
    results.append(("DULAGradedMonoid consistency", consistency_with_dula_graded_monoid()))
    results.append(("DULACubic consistency", consistency_with_dula_cubic()))
    
    print("\n" + "=" * 78)
    print("  SUMMARY")
    print("=" * 78)
    n_fail = sum(1 for _, ok in results if not ok)
    for name, ok in results:
        flag = "" if ok else "  ⚠"
        print(f"  [{'PASS' if ok else 'FAIL'}]  {name}{flag}")
    print()
    if n_fail == 0:
        print(f"  ✓ All {len(results)} universal-pattern checks pass.")
        return 0
    print(f"  ⚠ {n_fail} check(s) failed.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
