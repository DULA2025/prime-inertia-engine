#!/usr/bin/env python3
"""Exploratory quadrature for the pairwise (Bost-Charles) energy.

    BC(f) = (1/4 pi^2) \\int\\int log|f(e^{i theta}) - f(e^{i psi})| d psi d theta

for f = phi = t o psi (Hauptmodul composition) and for its reciprocal 1/phi.

*** THIS IS NOT A PROOF. ***  It is a floating-point trapezoidal quadrature with
no error control, used only to identify which normalisation the draft's value
1.0355 refers to.  Nothing computed here is asserted in the Lean development;
see Zeta5/BostCharlesEnergy.lean, where the pairwise energy is defined but never
evaluated or bounded.

Output (N = 512):
    BC(phi)    ~ 2.0981     (mean of log|g|, with the diagonal singularity
                             removed by the divided-difference factorisation)
    BC(1/phi)  ~ 2.0981 - 2*0.531289158 = 1.0355   (the draft's number)
"""

import cmath
import math

# The 41 published coefficients (Zeta5/PublishedTemplate.lean, pubC).
PUB_C = [
    -531289158, -225379074, -127598877, -1824369, -27735780, -41418343,
    51444137, 26087140, -10853938, 1314954, -3547849, -23294126, 125751,
    20158067, -1454440, -4262361, 7019143, -198726, -7684408, -6339902,
    5397468, 1260337, 134428, 14051878, -11391873, -5386029, -202917,
    1464054, -123972, 8670335, -51833, -6877094, -1450246, -1060183,
    2930635, 2103211, 1750273, -2516914, -2244428, 524421, 1281738,
]
C = [x / 1e9 for x in PUB_C]


def psi(z):
    return z * cmath.exp(sum(C[k] * z ** k for k in range(41)))


def hauptmodul(q, terms=300):
    p = 1 + 0j
    for n in range(1, terms):
        p *= ((1 - q ** n) / (1 - q ** (5 * n))) ** 6
    return p / q


def phi(z):
    return hauptmodul(psi(z))


def main(N=512):
    zs = [cmath.exp(2j * math.pi * j / N) for j in range(N)]
    ph = [phi(z) for z in zs]
    h = 1e-6
    dph = [(phi(z * cmath.exp(1j * h)) - phi(z)) / (z * cmath.exp(1j * h) - z)
           for z in zs]
    # phi(z) - phi(w) = (z - w) * g(z,w) / (z w);  mean of log|z - w| is 0.
    total = 0.0
    for j in range(N):
        for k in range(N):
            if j == k:
                g = zs[j] ** 2 * dph[j]
            else:
                g = zs[j] * zs[k] * (ph[j] - ph[k]) / (zs[j] - zs[k])
            total += math.log(abs(g))
    bc = total / (N * N)
    c0 = C[0]
    print("BC(phi)   ~", bc)
    print("BC(1/phi) ~", bc + 2 * c0, "   (exact relation: BC(1/F) = BC(F) + 2 c0)")
    print("cost      ~", bc + 2 * c0 - 4 * c0)
    print("budget     =", 3 * (3 * math.log(5) - 4 + 0.25))


if __name__ == "__main__":
    main()
