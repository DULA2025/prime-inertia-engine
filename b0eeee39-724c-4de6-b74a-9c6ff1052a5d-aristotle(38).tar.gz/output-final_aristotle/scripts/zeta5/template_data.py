"""Regenerate the data of the Zeta5 certificate (exact integer / rational arithmetic).

Prints
  * the 41 template coefficient numerators C(40,k)*C(40+k,k),
  * their sum and the exact comparison with 5^45,
  * the exact maximum of |psi| on the unit circle,
  * the interval data used for BC(phi) = 2 log 5.

Nothing here is a proof; the proofs are the Lean theorems in Zeta5/.
This script only reproduces the numbers that appear in those statements.
"""
from fractions import Fraction as F
from math import comb, factorial, log

N = 40
nums = [comb(N, k) * comb(N + k, k) for k in range(N + 1)]
S = sum(nums)
D = 5 ** 45

print("number of coefficients:", len(nums))
print("coefficient numerators:")
for k, a in enumerate(nums):
    print(f"  k={k:2d}  {a}")
print("sum of numerators      :", S)
print("normalisation 5^45     :", D)
print("sum < 5^45             :", S < D)
print("max_{|z|=1} |psi(z)|   =", F(S, D), "=", S / D)
print("max_{|z|=1} log|psi(z)|=", log(S) - 45 * log(5))

# certified log-5 enclosure: partial sums / tail bound of the exponential series
def expsum(x, n):
    return sum(F(x) ** i / factorial(i) for i in range(n))

x = F(8047, 10000)
tail = x ** 10 * F(11, factorial(10) * 10)
print("exp(0.8047)  <=", float(expsum(x, 10) + tail), " -> exp(1.6094) <", float((expsum(x, 10) + tail) ** 2), "< 5")
y = F(80475, 100000)
print("exp(0.80475) >=", float(expsum(y, 10)), " -> exp(1.6095) >", float(expsum(y, 10) ** 2), "> 5")
print("so 1.6094 < log 5 < 1.6095 and 3.2188 < BC(phi) = 2 log 5 < 3.219")
print("budget 3.23494 - BC(phi) >", 3.23494 - 3.219)
