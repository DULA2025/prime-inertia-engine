#!/usr/bin/env python3
"""Where does the L^p family (1/p) log E|g|^p cross the threshold 1.10944?

Companion to `bc_sup.py`.  With F = (1/t) o psi and

    g(z, w) = (F(z) - F(w)) / (z - w),      BC(F) = E log|g|,

Jensen gives, for every p > 0,

    BC(F) <= M(p) := (1/p) log E |g|^p,

and M is increasing in p with M(p) -> BC(F) as p -> 0+.  The threshold needed by
`paperCostInv_lt_paperBudget_of_energy_bound` is 1.10944, while BC(F) ~ 1.0356,
so the family *does* clear the threshold -- but only for very small p.  This
script locates the crossing p* with M(p*) = 1.10944 by bisection on a uniform
N x N grid of the torus.

*** THIS IS NOT A PROOF. *** Floating-point quadrature, no error control.

Output (N = 256):

    BC(F) = E log|g|  ~ 1.0356
    M(1/4) ~ 1.9755,  M(0.1) ~ 1.4381,  M(0.03) ~ 1.1591,  M(0.01) ~ 1.0771
    crossing M(p*) = 1.10944 at p* ~ 0.0179  (0.01787 at N = 256,
                                              0.01793 at N = 512)

At p ~ 0.018 the integrand |g|^p is within a few percent of 1 over almost the
whole torus, so certifying the moment E|g|^p to the required accuracy is as hard
as certifying the mean E log|g| itself.  The obstruction is quantitative, not
structural.
"""

import cmath
import math

from bc_sup import F, psi  # same 41 published coefficients

THRESHOLD = 1.10944


def log_abs_g_grid(N):
    zs = [cmath.exp(2j * math.pi * j / N) for j in range(N)]
    fs = [F(z) for z in zs]
    h = 1e-6
    diag = [(F(z * cmath.exp(1j * h)) - F(z)) / (z * cmath.exp(1j * h) - z)
            for z in zs]
    out = []
    for j in range(N):
        fj, zj = fs[j], zs[j]
        for k in range(N):
            g = abs(diag[j]) if j == k else abs((fj - fs[k]) / (zj - zs[k]))
            out.append(math.log(g))
    return out


def moment(logs, p):
    """(1/p) log mean exp(p * log|g|), computed stably."""
    m = max(logs)
    s = sum(math.exp(p * (L - m)) for L in logs)
    return (p * m + math.log(s / len(logs))) / p


def main(N=256):
    logs = log_abs_g_grid(N)
    bc = sum(logs) / len(logs)
    print(f"N = {N}")
    print(f"BC(F) = mean log|g| : {bc:.6f}")
    for p in (2.0, 1.0, 0.5, 0.25, 0.1, 0.05, 0.03, 0.02, 0.015, 0.01, 0.005):
        print(f"  M({p:<6}) = {moment(logs, p):.6f}")
    lo, hi = 1e-4, 1.0
    for _ in range(60):
        mid = math.sqrt(lo * hi)
        if moment(logs, mid) > THRESHOLD:
            hi = mid
        else:
            lo = mid
    print(f"crossing M(p*) = {THRESHOLD} at p* = {math.sqrt(lo * hi):.5f}")


if __name__ == "__main__":
    main()
