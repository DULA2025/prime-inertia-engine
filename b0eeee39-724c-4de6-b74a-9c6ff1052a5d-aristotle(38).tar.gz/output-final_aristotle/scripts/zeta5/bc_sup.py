#!/usr/bin/env python3
"""How lossy is a supremum bound for the Bost-Charles pairwise energy?

For F = x o psi with x = 1/t = (eta(5 tau)/eta(tau))^6 (the *reciprocal*
normalisation, the one the draft's 1.0355 refers to) this script measures, on a
uniform N x N grid of the torus:

  * the mean of log|g|, i.e. BC(F) itself, where g(z,w) = (F(z)-F(w))/(z-w);
  * max |F| on the unit circle, hence the best conceivable bound of the form
    BC <= log sup|F(z)-F(w)|;
  * max |g| on the torus, hence the best conceivable bound of the form
    BC <= log sup|g|;
  * the L^p means (1/p) log (mean |g|^p) for p = 2, 1, 1/2, 1/4, which bound
    BC from above by Jensen's inequality and decrease to BC as p -> 0.

*** THIS IS NOT A PROOF. *** It is a floating-point quadrature with no error
control.  The only certified statement about these quantities in the Lean
development is `pairwiseEnergy_phi_inv_le_crude` in Zeta5/EnergyBounds.lean,
namely BC(F) <= 5178.

Output (N = 512):

    mean log|g| = BC(F)      ~ 1.0356      (the draft's 1.0355)
    max |F| on the circle    ~ 52.4        -> log sup|F(z)-F(w)| ~ 3.96
    max |g| on the torus     ~ 1.45e3      -> log sup|g|         ~ 7.28
    p = 2   : (1/p) log mean|g|^p ~ 4.35
    p = 1   : ~ 3.45
    p = 1/2 : ~ 2.65
    p = 1/4 : ~ 1.98

Every one of these exceeds the budget threshold 1.10944 of
`paperCostInv_lt_paperBudget_of_energy_bound`, so no supremum-type or
low-order-moment bound can discharge it.
"""

import cmath
import math

# The 41 published coefficients (Zeta5/PublishedTemplate.lean, pubC).
PUB_C = [
    -531289158, -225379074, -127598877, -1824369, -27735780, -41418343,
    51444137, 26087140, -10853938, 1314954, -3547849, -23294126, 125751,
    20158067, -1454440, -4262361, 7019143, -198726, -7684408, -6339902,
    5397468, 1260337, 134428, 14051878, -11391873, -5386029, -202917,
    1464054, -123972, 8670335, -51833, -6877094, -1450246, -1060183,
    2930635, 2103211, 1750273, -2516914, -2244428, 524421, 1281738,
]
C = [x / 1e9 for x in PUB_C]


def psi(z):
    return z * cmath.exp(sum(C[k] * z ** k for k in range(41)))


def x_of_q(q, terms=300):
    """x(q) = 1/t(q) = q * prod ((1-q^{5n})/(1-q^n))^6."""
    p = 1 + 0j
    for n in range(1, terms):
        p *= ((1 - q ** (5 * n)) / (1 - q ** n)) ** 6
    return q * p


def F(z):
    return x_of_q(psi(z))


def main(N=512):
    zs = [cmath.exp(2j * math.pi * j / N) for j in range(N)]
    fs = [F(z) for z in zs]
    h = 1e-6
    diag = [(F(z * cmath.exp(1j * h)) - F(z)) / (z * cmath.exp(1j * h) - z)
            for z in zs]
    print("max |psi| on the circle :", max(abs(psi(z)) for z in zs))
    print("max |F|   on the circle :", max(abs(f) for f in fs))
    print("min |F|   on the circle :", min(abs(f) for f in fs))

    ps = (2.0, 1.0, 0.5, 0.25)
    moments = {p: 0.0 for p in ps}
    total_log = 0.0
    gmax = 0.0
    for j in range(N):
        fj, zj = fs[j], zs[j]
        for k in range(N):
            g = abs(diag[j]) if j == k else abs((fj - fs[k]) / (zj - zs[k]))
            total_log += math.log(g)
            gmax = max(gmax, g)
            for p in ps:
                moments[p] += g ** p
    M = N * N
    print("mean log|g| = BC(F)     :", total_log / M)
    print("max |g| on the torus    :", gmax, "  log =", math.log(gmax))
    for p in ps:
        v = moments[p] / M
        print(f"  p = {p}: (1/p) log mean|g|^p = {math.log(v) / p:.6f}")
    print("budget threshold        : 1.10944")


if __name__ == "__main__":
    main()
