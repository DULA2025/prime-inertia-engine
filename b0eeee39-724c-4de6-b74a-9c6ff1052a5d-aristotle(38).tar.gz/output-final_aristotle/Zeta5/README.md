# `Zeta5` — arithmetic-holonomy certificate for `ζ_5(3)` (companion effort)

A self-contained, `sorry`-free Lean library, isolated from the rest of the
repository (it imports nothing from it and is registered as its own `lean_lib`
in `lakefile.toml`).

| module | contents |
|---|---|
| `Zeta5/LogBounds.lean` | validated numerics: `1.6094 < log 5 < 1.6095` from the exponential series |
| `Zeta5/Template.lean` | the 41-coefficient template `ψ`; its maximum on the unit circle, computed exactly; admissibility `max log\|ψ\| < -4 < 0` |
| `Zeta5/BostCharles.lean` | zero-freeness of diagonally dominant polynomials on the closed disc; Jensen's formula gives `BC(φ) = log\|a₀\|`; `BC(φ) = log 25`, enclosed in `(3.2188, 3.219)` |
| `Zeta5/Coefficients.lean` | the coefficient sequence `bₙ = 5^{3n}/Dₙ` and its exact denominator |
| `Zeta5/Radius.lean` | the `5`-adic overconvergence radius is exactly `R₅ = 5³` (unconditional) |
| `Zeta5/DenomType.lean` | the denominator type `τ(b) = 45/16`, given the stated Chebyshev/PNT hypothesis |
| `Zeta5/PublishedTemplate.lean` | the *published* 41-coefficient template `ψ(z) = z·exp(Σ_{k≤40} c_k z^k)`, encoded as exact rationals with a stated rounding bound `10⁻⁹`; a certified admissibility bound `max_{\|z\|=1} log‖ψ‖ ≤ -0.0482 < 0`, rounding propagated; the exact circle average (energy) of `log‖ψ‖`, namely the constant term `c₀` |
| `Zeta5/Hauptmodul.lean` | the Hauptmodul of `X₀(5)` in the nome, `t(q) = q⁻¹ ∏ (1−qⁿ)^6/(1−q^{5n})^6`, as an absolutely convergent product; `log‖t(q)‖` as a convergent series; the maximum-modulus bound `‖ψ(z)‖ ≤ 0.9530 < 1` on the closed disc, which makes the composition `φ = t ∘ ψ` well defined |
| `Zeta5/HauptmodulBC.lean` | the exact Bost–Charles integral of the composition: Jensen kills every factor `1 − ψⁿ`, the series is integrated term by term against a summable majorant, and `BC(φ) = −c₀`, i.e. `0.53128915 < BC(φ) < 0.53128917`; also `BC(1/φ) = +c₀` |
| `Zeta5/EtaQuotient.lean` | the Dedekind eta function (absent from Mathlib) defined by its product expansion, and the identity `(η(τ)/η(5τ))^6 = t(e^{2πiτ})` on the upper half plane |
| `Zeta5/Certificate.lean` | the bundled certificate: the five established ingredients (exact template max-modulus, Jensen evaluation of `BC(φ)` for the placeholder `(5−z)²`, `τ = 45/16` given the PNT hypothesis, `R₅ = 5³`, and the exact `BC` of the genuine Hauptmodul composition).  Also the *demoted* comparison `archCostGuess < budgetInput = 3.23494`, explicitly **not** claimed to be the paper's criterion |
| `Zeta5/BostCharlesEnergy.lean` | the paper's functionals: the pairwise energy `BC(f) = (1/4π²)∬ log‖f(e^{iθ}) − f(e^{iψ})‖`, `cost = BC − 4c₀` and `budget = 9 log 5 − 45/4 ∈ (3.2346, 3.2355)`; the reciprocal relation `BC(1/F) = BC(F) − 2·(Jensen mean)`, which identifies the draft's `1.0355` as the reciprocal normalisation `(1/t) ∘ ψ`; `BC(id) = 0` |
| `Zeta5/EnergyBounds.lean` | how lossy a supremum bound for that energy is: the divided-difference form `BC(F) = (1/4π²)∬ log‖g‖`, and the crude certified majorant giving `BC((1/t) ∘ ψ) ≤ 5178` — against the `1.10944` the budget comparison needs.  The conclusion (§5c of the status report) is that sup-norm and moderate-`p` moment bounds **do not usefully reach** that threshold — the `L^p` family only clears it near `p ≈ 0.015`, where certifying the moment is as hard as certifying the mean |
| `Zeta5/DividedDifference.lean` | the regular integrand after splitting the diagonal: `x = 1/t` as the everywhere-defined `q·exp(−Σ …)`, an explicit Lipschitz bound for it on `‖q‖ ≤ ρ`, the published template as a `40`-Lipschitz map of the closed unit disc, hence `F = (1/t) ∘ ψ` Lipschitz with the (crude) constant `exp 5200`; the divided difference `g(z,w) = (F(z)−F(w))/(z−w)`, its factorisation identity, its global bound `‖g‖ ≤ exp 5200` on the closed bidisc, its continuity off the diagonal, and an explicit modulus of continuity off a diagonal strip (`d = 2 sin(δ/2)` for `|θ−ψ| ≥ δ`) |
| `Zeta5/AxiomAudit.lean` | `#print axioms` for every headline result |

Build with `lake build Zeta5.AxiomAudit`.

`archCostGuess = BC(φ) + max log‖ψ‖` is *not* the published cost functional (the
denominator type never enters it, and the template term has the wrong scaling);
it is kept only as a record, and is not part of `zeta5_certificate`.  Nothing
here claims `ζ_5(3) ∉ ℚ`: the arithmetic holonomicity theorem is not formalised.

**Normalisation discrepancy (a diagnostic).**  The placeholder `φ(z) = (5 − z)²`
gives `BC = 2 log 5 ≈ 3.2189`, close to the quoted budget `3.23494`; the genuine
Hauptmodul composition gives `BC ≈ ±0.5313` (`+` for `t ∘ ψ`, `−` for
`(1/t) ∘ ψ`), which is not close to it.  This is recorded, not explained, and no
fudge factor is introduced; see §5b of `docs/zeta5_holonomy.md`.  The fifth
conjunct of `zeta5_certificate` is an evaluated integral about `φ` alone, never a
comparison.

**No `cost < budget` claim.**  The two lemmas that would deduce one
(`paperCost_lt_paperBudget_of_energy_bound` and its `Inv` variant) keep the
certified energy bound as an open hypothesis, and the non-reciprocal variant is
a dead branch in any case (`BC(t ∘ ψ) ≈ 2.098` violates its numerical
hypothesis).  The only certified bound on the live quantity is
`BC((1/t) ∘ ψ) ≤ 5178`.

The full status report — including exactly which ingredients are rigorous and
which are external inputs — is `docs/zeta5_holonomy.md`.
