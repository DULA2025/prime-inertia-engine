# Instructions for Aristotle — Full Project Build Verification

## Task

Verify that the entire DULA Lean 4 project builds cleanly with the
expected sorry count.

```sh
lake build
```

## Expected result

- ✓ Build succeeds.
- ✓ Exactly **6 sorrys** remain across the 9 project files:
  - `Main.lean`: 2 sorrys (lines 106, 111)
  - `ContinuityHelpers.lean`: 2 sorrys (~lines 117, 125)
  - `WeilTestFunction.lean`: 2 sorrys (lines 239, 240 inside `autocorrelation_WTF`)
  - All other files: 0 sorrys
- ✓ All proved declarations remain proved.

## DO NOT

- ✗ DO NOT modify ANY of the 9 source files. They are at their canonical,
  verified versions.
- ✗ DO NOT attempt to fill any of the 6 sorrys. Each represents
  identifiable mathematical content that is either deep (`Main.lean`'s
  Weil 1952 sub-lemmas) or requires careful concrete analysis
  (`ContinuityHelpers.lean` and `WeilTestFunction.lean` sorrys) that
  is out of scope for this verification run.
- ✗ DO NOT add new files or new imports to existing files.

## If the build fails

Report the exact error message. Likely causes:

1. **Mathlib version drift**: a lemma name has changed between Mathlib
   versions. Report the missing name; do NOT rewrite the proof.
2. **`open` directive collision**: a name resolution conflict between
   files. Report the conflicting names; do NOT silently modify code.
3. **Type instance mismatch**: a structure field or instance has
   changed. Report the mismatch; do NOT regenerate definitions.

In all failure cases: report the precise error and stop. The previous
verification rounds confirmed each subset of these files compiles in
its respective dependency closure; this is the first end-to-end
integration check.

## Dependency graph (for reference)

```
Mathlib
  ├── AutocorrSmooth
  │     │
  │     └── Main
  │           │
  │           ├── HermiteBiehler  (also imports ZetaConj)
  │           ├── ContinuityHelpers
  │           │     │
  │           │     └── ConjectureA
  │           │
  │           └── WeilTestFunction
  │
  ├── ZetaConj           (standalone, imported by HermiteBiehler)
  ├── ConvolutionContinuity (standalone)
  └── DulaTheorem        (standalone)
```

No circular dependencies. All imports are within the project
or to Mathlib.
