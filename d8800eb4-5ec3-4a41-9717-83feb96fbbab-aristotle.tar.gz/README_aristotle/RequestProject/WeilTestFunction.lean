import Mathlib
import RequestProject.Main

/-!
# Weil Test Functions — fixing the convergence issue
==============================================================================

## Background

The `WeilDistribution` defined in `Main.lean` contains the von Mangoldt sum

  ∑'_{n ≥ 1} Λ(n) / √n · g(log n)

Aristotle's analysis (`ANALYSIS.md`, this session) demonstrated that this sum
**does not converge** for generic Schwartz functions g. Schwartz decay gives
|g(log n)| = O((log n)^{-N}) for any N, but ∑ Λ(n)/√n · (log n)^{-N} diverges
for every N (the prime sum density grows like √n, defeating any polynomial
log-decay).

Lean's `tsum` returns 0 for non-summable series, so `WeilDistribution g` as
currently defined silently returns mathematically incorrect values for
generic Schwartz g — making the surrounding theorems (`WeilCriterion`,
`weilDistribution_autocorrelation_continuous`, etc.) about a junk function.

## The fix (this file)

Following Weil's own 1952 paper (condition (B), p. 6), restrict the test
function class to those with **exponential decay**: there exist b > 0 and
C > 0 such that

  |F(x)| ≤ C · e^{-(1/2 + b)|x|}     and similarly for F'.

For such F, |F(log p)| ≤ C · p^{-(1/2+b)}, so the term
Λ(n)/√n · F(log n) is bounded by C · Λ(n) · n^{-(1+b)}, and the sum
converges absolutely.

This file defines `WeilTestFunction` as the structure capturing this class,
provides instances (CoeFun, topology), and redefines `WeilDistribution`
(under a fresh name, `WeilDistribution_WTF`) on this restricted class.
The old `WeilDistribution` in `Main.lean` is *not* modified yet —
this skeleton is purely additive until verified.

## Status — sub-sorrys

| Declaration                                | Status   | Substance                       |
|--------------------------------------------|----------|---------------------------------|
| `WeilTestFunction`                         | defined  | structure                        |
| `WeilTestFunction.coe_apply`               | proved   | rfl                              |
| topology instance                          | defined  | induced from EvenSchwartz        |
| `vonMangoldt_sum_summable`                 | proved   | absolute convergence             |
| `WeilDistribution_WTF`                     | defined  | new well-defined functional      |
| `autocorrelation_WTF`                      | sorry    | autocorr closure under WTF       |

Once the two sorrys are filled, downstream code can be migrated to use
`WeilTestFunction`/`WeilDistribution_WTF`/`autocorrelation_WTF` in place
of `EvenSchwartz`/`WeilDistribution`/`autocorrelation`, and the convergence
issue is resolved.

## What this file does NOT do

- Does not modify `Main.lean` or any other existing file.
- Does not redefine `WeilCriterion` or `WeilPositivity`.
- Does not propagate the type change to `ConjectureA.lean`,
  `HermiteBiehler.lean`, or `ContinuityHelpers.lean`.

These migrations are deferred to a follow-up session, after the structure
in this file is verified to compile and the two sorrys are scoped.
-/

open Real MeasureTheory
open scoped BigOperators

noncomputable section

-- ============================================================================
-- 1. THE WEIL TEST FUNCTION STRUCTURE
-- ============================================================================

/-- A **Weil test function** is an even Schwartz function on ℝ together with
    a witness that |F(x)| and |F'(x)| are O(e^{-(1/2+b)|x|}) for some b > 0.

    This matches condition (B) of Weil's 1952 paper (p. 6) and ensures
    that the von Mangoldt sum ∑ Λ(n)/√n · F(log n) converges absolutely.

    The decay rate b is existentially quantified — we don't expose it as a
    type parameter to keep the type family flat. The constant C is also
    existentially quantified inside the decay bounds. -/
structure WeilTestFunction where
  /-- The underlying even Schwartz function. -/
  toEvenSchwartz : EvenSchwartz
  /-- Exponential decay bound on F: ∃ b > 0, ∃ C > 0, ∀ x, |F(x)| ≤ C·exp(-(1/2+b)|x|). -/
  has_exponential_decay :
    ∃ b > (0 : ℝ), ∃ C > (0 : ℝ),
      ∀ x : ℝ, |toEvenSchwartz x| ≤ C * Real.exp (-(1/2 + b) * |x|)
  /-- Exponential decay bound on F': ∃ b > 0, ∃ C > 0, ∀ x, |F'(x)| ≤ C·exp(-(1/2+b)|x|).
      Required for Weil's contour-integration argument; not strictly needed for the
      von Mangoldt sum convergence, but included to match Weil's condition (B) exactly. -/
  has_exponential_decay_deriv :
    ∃ b > (0 : ℝ), ∃ C > (0 : ℝ),
      ∀ x : ℝ, |deriv toEvenSchwartz.toSchwartzMap x| ≤ C * Real.exp (-(1/2 + b) * |x|)

/-- Coerce a Weil test function to `ℝ → ℝ` via the underlying Schwartz map. -/
instance : CoeFun WeilTestFunction (fun _ => ℝ → ℝ) where
  coe g := g.toEvenSchwartz

/-- Topology on `WeilTestFunction` induced from `EvenSchwartz` via `toEvenSchwartz`.
    Note: this is the *coarsest* topology making the projection continuous. It does
    NOT control the decay constants `b`, `C`. If a future continuity proof needs
    uniform decay control, this topology may need to be strengthened. For the
    current scope (convergence of the von Mangoldt sum, plus continuity proofs that
    only need the underlying Schwartz topology), the induced topology is sufficient. -/
instance : TopologicalSpace WeilTestFunction :=
  TopologicalSpace.induced WeilTestFunction.toEvenSchwartz inferInstance

/-- Pointwise application unfolds via the underlying Schwartz map. -/
@[simp]
lemma WeilTestFunction.coe_apply (g : WeilTestFunction) (x : ℝ) :
    g x = g.toEvenSchwartz.toSchwartzMap x := rfl

/-
============================================================================
2. CONVERGENCE OF THE VON MANGOLDT SUM
============================================================================

**Absolute convergence of the von Mangoldt sum on Weil test functions.**

    For any `g : WeilTestFunction`, the series
        ∑'_{n ≥ 1} Λ(n) / √n · g(log n)
    converges absolutely.

    Proof sketch (to be filled in):
    Obtain b > 0, C > 0 from `g.has_exponential_decay`. For n ≥ 2,
        |g(log n)| ≤ C · exp(-(1/2 + b) · |log n|) = C · n^{-(1/2 + b)}
    so
        |Λ(n) / √n · g(log n)| ≤ Λ(n) / √n · C · n^{-(1/2 + b)}
                                = C · Λ(n) · n^{-(1+b)}.
    Now ∑'_n Λ(n) · n^{-(1+b)} converges absolutely for b > 0 by
    comparison with -ζ'/ζ(s) at s = 1+b > 1, where the Dirichlet series for
    -ζ'/ζ is the von Mangoldt generating series and converges absolutely
    in the region Re s > 1. The constant term n=1 has Λ(1) = 0 so contributes
    nothing. Multiplying by the constant C gives summability of the original.
-/
theorem vonMangoldt_sum_summable (g : WeilTestFunction) :
    Summable (fun n : ℕ => |(ArithmeticFunction.vonMangoldt n : ℝ) / Real.sqrt n * g (Real.log n)|) := by
  -- By definition of $WeilTestFunction$, we know that $|g(x)|$ decays exponentially.
  obtain ⟨b, hb_pos, C, hC_pos, hg_bound⟩ : ∃ b > 0, ∃ C > 0, ∀ x : ℝ, |g.toEvenSchwartz.toSchwartzMap x| ≤ C * Real.exp (-(1/2 + b) * |x|) := by
    exact g.has_exponential_decay;
  -- Use the bound on $|g(x)|$ to show that $|\Lambda(n) / \sqrt{n} \cdot g(\log n)|$ is bounded.
  have h_bound : ∀ n : ℕ, n ≥ 1 → |(ArithmeticFunction.vonMangoldt n : ℝ) / Real.sqrt n * g.toEvenSchwartz.toSchwartzMap (Real.log n)| ≤ C * (ArithmeticFunction.vonMangoldt n : ℝ) * (n : ℝ) ^ (-(1 + b)) := by
    intro n hn
    have h_abs : |g.toEvenSchwartz.toSchwartzMap (Real.log n)| ≤ C * (n : ℝ) ^ (-(1/2 + b)) := by
      convert hg_bound ( Real.log n ) using 1 ; rw [ Real.rpow_def_of_pos ( by positivity ) ] ; ring;
      rw [ abs_of_nonneg ( Real.log_nonneg ( Nat.one_le_cast.mpr hn ) ) ] ; ring;
    convert mul_le_mul_of_nonneg_left h_abs ( show 0 ≤ |ArithmeticFunction.vonMangoldt n / Real.sqrt n| by positivity ) using 1 <;> norm_num [ abs_mul, abs_div, abs_of_nonneg, Real.sqrt_nonneg ] ; ring;
    rw [ show ( -1 - b : ℝ ) = -1 / 2 - b - 1 / 2 by ring, Real.rpow_sub ( by positivity ), Real.sqrt_eq_rpow, Real.rpow_def_of_pos ( by positivity ) ] ; ring;
  -- Use the fact that $\sum_{n=1}^{\infty} \frac{\Lambda(n)}{n^{1+b}}$ converges.
  have h_summable : Summable (fun n : ℕ => (ArithmeticFunction.vonMangoldt n : ℝ) * (n : ℝ) ^ (-(1 + b))) := by
    have h_summable : Summable (fun n : ℕ => (Real.log n : ℝ) * (n : ℝ) ^ (-(1 + b))) := by
      -- We can compare our series with the convergent p-series $\sum_{n=1}^{\infty} \frac{1}{n^{1+b/2}}$.
      have h_comparison : ∃ C > 0, ∀ n : ℕ, n ≥ 2 → (Real.log n : ℝ) * (n : ℝ) ^ (-(1 + b)) ≤ C * (n : ℝ) ^ (-(1 + b / 2)) := by
        have h_comparison : ∃ C > 0, ∀ n : ℕ, n ≥ 2 → (Real.log n : ℝ) ≤ C * (n : ℝ) ^ (b / 2) := by
          use 2 / b, by positivity, fun n hn => by have := Real.log_le_sub_one_of_pos ( by positivity : 0 < ( n : ℝ ) ^ ( b / 2 ) ) ; rw [ Real.log_rpow ( by positivity ) ] at this; nlinarith [ show ( n : ℝ ) ≥ 2 by exact_mod_cast hn, Real.rpow_pos_of_pos ( by positivity : 0 < ( n : ℝ ) ) ( b / 2 ), mul_div_cancel₀ ( 2 : ℝ ) hb_pos.ne' ] ;
        obtain ⟨ C, hC_pos, hC ⟩ := h_comparison; use C; refine' ⟨ hC_pos, fun n hn => _ ⟩ ; convert mul_le_mul_of_nonneg_right ( hC n hn ) ( Real.rpow_nonneg ( Nat.cast_nonneg n ) ( - ( 1 + b ) ) ) using 1 ; rw [ mul_assoc, ← Real.rpow_add ( by positivity ) ] ; ring;
      obtain ⟨ C, hC_pos, hC ⟩ := h_comparison;
      rw [ ← summable_nat_add_iff 2 ];
      exact Summable.of_nonneg_of_le ( fun n => mul_nonneg ( Real.log_nonneg ( by norm_cast; linarith ) ) ( Real.rpow_nonneg ( Nat.cast_nonneg _ ) _ ) ) ( fun n => hC _ ( by linarith ) ) ( Summable.mul_left _ <| by simpa using summable_nat_add_iff 2 |>.2 <| Real.summable_nat_rpow.2 <| by linarith );
    refine' .of_nonneg_of_le ( fun n => _ ) ( fun n => _ ) h_summable;
    · exact mul_nonneg ( by rw [ ArithmeticFunction.vonMangoldt_apply ] ; positivity ) ( by positivity );
    · by_cases hn : n = 0 <;> simp_all +decide [ ArithmeticFunction.vonMangoldt ];
      split_ifs;
      · exact mul_le_mul_of_nonneg_right ( Real.log_le_log ( Nat.cast_pos.mpr ( Nat.minFac_pos _ ) ) ( Nat.cast_le.mpr ( Nat.minFac_le ( Nat.pos_of_ne_zero hn ) ) ) ) ( by positivity );
      · positivity;
  rw [ ← summable_nat_add_iff 1 ] at *;
  exact Summable.of_nonneg_of_le ( fun n => abs_nonneg _ ) ( fun n => h_bound _ le_add_self ) ( by simpa only [ mul_assoc ] using h_summable.mul_left C )

-- ============================================================================
-- 3. THE WELL-DEFINED WEIL DISTRIBUTION
-- ============================================================================

/-- The **Weil distribution** on the restricted class `WeilTestFunction`,
    where the von Mangoldt sum provably converges absolutely.

    Identical formula to `WeilDistribution` in `Main.lean`, but with the
    domain restricted to `WeilTestFunction` so that the `tsum` is the
    real sum (not the `tsum-returns-0-on-non-summable` artifact).

    Naming convention: `_WTF` suffix distinguishes this from the original
    `WeilDistribution` in `Main.lean`. After the migration is complete and
    verified, the original can be deprecated and the suffix dropped. -/
def WeilDistribution_WTF (g : WeilTestFunction) : ℝ :=
  -- Term 1: evaluation at 0 scaled by log π.
  g 0 * Real.log Real.pi
  -- Term 2: von Mangoldt sum (now provably absolutely convergent).
  - ∑' (n : ℕ), (ArithmeticFunction.vonMangoldt n : ℝ) / Real.sqrt n * g (Real.log n)
  -- Term 3: archimedean integral (unchanged from Main.lean).
  + ∫ x in Set.Ioi (0 : ℝ), g x * (1 / (1 - Real.exp (-2 * x)) - 1 / (2 * x))

/-- Sanity lemma: by construction, `WeilDistribution_WTF g` has the *same formula*
    as `WeilDistribution g.toEvenSchwartz`. So they agree definitionally; the
    *meaning* is what differs. For `WeilDistribution g.toEvenSchwartz` (the original),
    Lean's `tsum` returns the sum if summable and 0 otherwise. For `WeilDistribution_WTF g`,
    we will prove (via `vonMangoldt_sum_summable`) that the `tsum` is always the genuine
    sum. So the two functions are equal *as values* but `WeilDistribution_WTF` is the
    one that is mathematically meaningful. -/
lemma WeilDistribution_WTF_eq_apply (g : WeilTestFunction) :
    WeilDistribution_WTF g = WeilDistribution g.toEvenSchwartz := by
  unfold WeilDistribution_WTF WeilDistribution
  rfl

-- ============================================================================
-- 4. AUTOCORRELATION CLOSURE
-- ============================================================================

/-- **Autocorrelation preserves the WeilTestFunction class.**

    If h is a Weil test function (Schwartz + exponential decay rate b),
    then its autocorrelation h ⋆ h̃ is also a Weil test function (with
    a possibly smaller exponential decay rate, e.g., b/2 or b' < b).

    Proof sketch (to be filled in):
    The autocorrelation, viewed as an `EvenSchwartz`, already exists from
    `Main.lean`'s `autocorrelation`. We need the additional decay witness.

    Bound: |h ⋆ h̃(x)| = |∫ h(t) · h(t+x) dt|. Using the exponential decay
    of h: |h(t)| ≤ C·exp(-(1/2+b)|t|) and |h(t+x)| ≤ C·exp(-(1/2+b)|t+x|).
    Multiplying:
        |h(t)·h(t+x)| ≤ C² · exp(-(1/2+b)(|t| + |t+x|))
    For each x, ∫ exp(-(1/2+b)(|t|+|t+x|)) dt ≤ C'·exp(-(1/2+b')|x|) for
    some 0 < b' ≤ b (from the triangle-inequality-style bound on
    |t| + |t+x| ≥ |x|). The exact b' depends on the bound we use; b' = b
    works; b' = b/2 is a safe choice giving ample slack.

    For the derivative: deriv(h⋆h̃) = h ⋆ deriv(h̃) = h ⋆ (-deriv h)(-·),
    and the same exponential-decay computation applies. -/
def autocorrelation_WTF (h : WeilTestFunction) : WeilTestFunction where
  -- The underlying EvenSchwartz is the existing autocorrelation.
  toEvenSchwartz := autocorrelation h.toEvenSchwartz
  -- The exponential decay witnesses must be constructed.
  has_exponential_decay := by sorry
  has_exponential_decay_deriv := by sorry

-- ============================================================================
-- 5. SCAFFOLDING FOR DOWNSTREAM MIGRATION (deferred)
-- ============================================================================

/-! The following declarations would be the natural next steps once the
    sorrys above are filled in. They are intentionally NOT written yet —
    deferred to a follow-up session, after the structure in this file is
    verified.

    Outline of what comes next:

    1. `def WeilPositivity_WTF : Prop :=
            ∀ g : WeilTestFunction, WeilDistribution_WTF (autocorrelation_WTF g) ≥ 0`

    2. `theorem WeilCriterion_WTF : WeilPositivity_WTF ↔ RiemannHypothesis`
       (with the same explicit-formula skeleton structure as in Main.lean,
       but on the restricted class).

    3. Migration of `ConjectureA.lean`: the family map Φ in `Conjecture_A_Strong`
       targets `WeilTestFunction` instead of `EvenSchwartz`, and the density
       clause is in `WeilTestFunction` topology.

    4. Migration of `HermiteBiehler.lean`: `hb_implies_weil_positivity` is
       restated for `WeilPositivity_WTF`. The proof structure is preserved.

    5. Once all migrations are complete and verified, the original
       `WeilDistribution` and `WeilPositivity` in `Main.lean` can be
       deprecated, and the `_WTF` suffix dropped.
-/

end