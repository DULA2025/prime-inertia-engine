# Analysis of Remaining Sorries

## Summary

The project has 4 remaining sorries (down from the original 2 monolithic ones).
All remaining sorries represent substantive mathematical or formalization challenges.

## 1. `spectralSide_autocorr_nonneg` (Main.lean)

**Status: Open sorry — deep number theory**

This states that under the Riemann Hypothesis, `WeilDistribution(autocorrelation h) ≥ 0`
for all even Schwartz functions `h`. Since `spectralSide` is defined as `WeilDistribution`,
this is precisely the "RH → WeilPositivity" direction of Weil's criterion.

The proof sketch involves:
- The spectral side becoming `Σ_ρ |ĥ(γ_ρ)|²` under RH (Wiener-Khinchin)
- All `γ_ρ` being real under RH
- Non-negativity of the resulting sum of squares

This is a substantive result from Weil's 1952 paper.

## 2. `weilPositivity_implies_rh` (Main.lean)

**Status: Open sorry — deep number theory**

This is the harder direction: WeilPositivity → RH. The proof requires constructing
test functions that detect off-line zeros of the Riemann zeta function (Bombieri's
approach of testing against approximate delta functions).

## 3. `weil_component2_continuous` (ContinuityHelpers.lean)

**Status: Open sorry — convergence concern**

This states continuity of `φ ↦ ∑' n, Λ(n)/√n * ∫ φ(t)φ(t + log n) dt`.

**Convergence issue:** The sum `∑ Λ(n)/√n * g(log n)` may not converge for
all Schwartz functions `g`. Schwartz functions have polynomial decay
(`|g(x)| = O(|x|^{-N})` for all N), but when composed with `log n`, this gives
only `|g(log n)| = O((log n)^{-N})` — logarithmic decay in `n`. Since
`∑ Λ(n)/√n / (log n)^N` diverges for all `N`, the sum does not converge for
generic Schwartz functions.

For special functions (compactly supported, Gaussian), the sum converges. When
the sum is not summable, `∑'` returns 0. This may create discontinuities at
points where the sum is summable with nonzero value (e.g., compactly supported
functions where the sum is finite and nonzero, while nearby non-compactly-supported
perturbations have non-summable sums giving `∑' = 0`).

**Potential fix:** The standard Weil explicit formula requires test functions with
exponential decay (not just polynomial/Schwartz decay), or uses a regularized form
of the sum that incorporates cancellation with the integral term. Fixing this would
require modifying the `WeilDistribution` definition.

## 4. `weil_component3_continuous` (ContinuityHelpers.lean)

**Status: Open sorry — formalization challenge**

This states continuity of the integral component:
`φ ↦ ∫_{x>0} (∫ φ(t)φ(t+x) dt) · K(x) dx`

This is mathematically true. The proof approach would be:
1. Use sequential continuity (`SchwartzMap` is a `SequentialSpace`)
2. For a convergent sequence `φ_n → φ`, apply dominated convergence
3. The dominating function uses Schwartz decay estimates and boundedness of `K`

The formalization requires substantial infrastructure:
- Schwartz decay estimates for the autocorrelation
- Boundedness of `K(x) = 1/(1-e^{-2x}) - 1/(2x)` on `(0,∞)`
- Dominated convergence for parametric integrals
- Boundedness of convergent sequences in Schwartz topology

Each step is provable but requires significant Lean infrastructure.

## Structural Achievement

Despite the remaining sorries, the project has a clean structural decomposition:

- **WeilCriterion** has a sorry-free proof body that combines the two directional
  sub-lemmas `spectralSide_autocorr_nonneg` and `weilPositivity_implies_rh`.

- **weilDistribution_autocorrelation_continuous** has a sorry-free proof body
  that combines three component continuity lemmas.

- **conjecture_a_strong_implies_rh** has a complete proof assuming the above.
