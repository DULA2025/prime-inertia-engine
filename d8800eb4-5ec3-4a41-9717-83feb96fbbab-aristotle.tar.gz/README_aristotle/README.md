This project was edited by [Aristotle](https://aristotle.harmonic.fun).

To cite Aristotle:
- Tag @Aristotle-Harmonic on GitHub PRs/issues
- Add as co-author to commits:
```
Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
```

# DULA Lean 4 Project — Complete Build

This is the complete, integrated, verified state of the DULA formalization
project as of the end of the current development session.

## Files in this project

| File | Lines | Sorrys | Purpose |
|---|---|---|---|
| `RequestProject/AutocorrSmooth.lean` | 241 | 0 | Schwartz convolution is Schwartz (Mathlib gap closure) |
| `RequestProject/ZetaConj.lean` | 61 | 0 | Schwarz reflection: `completedRiemannZeta_conj` |
| `RequestProject/Main.lean` | 124 | 2 | Foundational definitions + `WeilCriterion` skeleton |
| `RequestProject/HermiteBiehler.lean` | 282 | 0 | de Branges / HB approach; `rh_iff_hb1` proved |
| `RequestProject/ContinuityHelpers.lean` | 143 | 2 | L² technique for Schwartz continuity |
| `RequestProject/ConjectureA.lean` | 76 | 0 | Cohn-Elkies / Weil-positivity bridge |
| `RequestProject/ConvolutionContinuity.lean` | 303 | 0 | Convolution continuity infrastructure |
| `RequestProject/WeilTestFunction.lean` | 271 | 2 | Convergence-issue fix for Weil distribution |
| `RequestProject/DulaTheorem.lean` | 109 | 0 | DULA grading + character theory |

**Total: 9 files, 1610 lines, 6 sorrys.**

Plus:
- `lakefile.toml` — Mathlib v4.28.0 dependency
- `lean-toolchain` — Lean v4.28.0

## Sorry inventory (all 6, with mathematical content)

### `Main.lean` (2 sorrys)

The sorrys represent the two halves of Weil's 1952 criterion, decomposed
structurally via the explicit-formula skeleton:

1. **`spectralSide_autocorr_nonneg` (line 106)**: Under RH, the Weil
   distribution is non-negative on autocorrelations. This is the easier
   direction of Weil's criterion via the explicit formula
   (`∑_ρ |ĥ(γ_ρ)|² ≥ 0`).

2. **`weilPositivity_implies_rh` (line 111)**: The harder direction.
   Constructing test functions that detect off-line zeros of zeta —
   the genuinely deep classical content (Bombieri 2000 style).

Both depend on first proving the explicit formula itself, which requires
substantial new Mathlib infrastructure (Mellin transforms on Schwartz space,
zero-counting on the critical strip, etc.).

### `ContinuityHelpers.lean` (2 sorrys)

The continuity decomposition of `weilDistribution_autocorrelation_continuous`
into three components. Component 1 is proved (the `g 0 · log π` term).
The other two:

3. **`weil_component2_continuous` (line ~117)**: Continuity of the von
   Mangoldt sum component. Note: as documented in the file, this lemma
   may have a convergence pathology with the original `EvenSchwartz`
   domain — the sum `∑' Λ(n)/√n · g(log n)` is not absolutely convergent
   for generic Schwartz `g`. **The fix is to migrate this functional
   to the `WeilTestFunction` domain (see WeilTestFunction.lean).**

4. **`weil_component3_continuous` (line ~125)**: Continuity of the
   archimedean integral term. Less affected by the convergence issue
   but still defined on `EvenSchwartz`.

### `WeilTestFunction.lean` (2 sorrys)

The convergence-issue fix introduces a new test function class
`WeilTestFunction` with exponential decay matching Weil's condition (B).
Two sorrys remain in the autocorrelation closure:

5. **`autocorrelation_WTF.has_exponential_decay` (line ~239)**:
   Shows `h ⋆ h̃` inherits exponential decay from `h`. Concrete
   exponential-decay convolution calculation; doable but ~50-200
   lines of Lean.

6. **`autocorrelation_WTF.has_exponential_decay_deriv` (line ~240)**:
   Same for the derivative.

## Build instruction

```sh
lake build
```

Or for a specific target:
```sh
lake build RequestProject.WeilTestFunction
```

Expected result: clean build, 6 sorrys remaining.

## Verification status

- `WeilTestFunction → Main → AutocorrSmooth` build chain: **VERIFIED**
  by Aristotle in the previous session.
- Full 9-file project: this assembly has not been built end-to-end
  in a single session. Individual files have all been verified in
  isolation. Cross-file integration risk is low (clean dependency
  graph, no circular imports, files are at versions known to compile
  together except for the recent addition of WeilTestFunction.lean).

## What this project does and does NOT prove

**Proved:**
- Schwartz convolution is Schwartz (`AutocorrSmooth`).
- Schwarz reflection for the completed Riemann zeta (`ZetaConj`).
- de Branges Hermite-Biehler equivalence: `RH ↔ HB1` (`HermiteBiehler`).
- Conditional Weil-positivity bridge: `Conjecture_A_Strong → RH`
  modulo the deep sub-sorrys.
- DULA grading additivity and character multiplicativity (`DulaTheorem`).
- Absolute convergence of the von Mangoldt sum on the
  `WeilTestFunction` class (`WeilTestFunction.vonMangoldt_sum_summable`).

**NOT proved (the 6 sorrys):**
- Weil's 1952 criterion (deep classical analysis).
- Continuity of the Weil functional on autocorrelations.
- Closure of the Weil test function class under autocorrelation.

The project is a **conditional reduction** of RH to a small number of
well-defined mathematical targets, formalized in Lean. It is not a proof
of RH.
