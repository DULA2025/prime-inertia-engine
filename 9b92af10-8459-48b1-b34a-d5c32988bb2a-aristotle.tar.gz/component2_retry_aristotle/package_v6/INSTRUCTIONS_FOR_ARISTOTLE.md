# Instructions for Aristotle — `weil_component2_continuous_WTF` retry

## CRITICAL CONTEXT (read this first)

This is the **full DULA project** with all 9 files. The previous run was
sent without the supporting files, so Aristotle re-built from scratch in
isolation and ended up at the same dead-end. **This run includes the
complete project** so the existing infrastructure can be used directly.

DO NOT rebuild from scratch. DO NOT replace any of these 9 files.
Specifically: do not write a new `WeilTestFunction.lean` with Gaussian
decay — the project's `WeilTestFunction.lean` uses **exponential decay
matching Weil's condition (B)**, not Gaussian. The exponential-decay
version has fully proved helpers (`exp_decay_convolution_integral_bound`,
`poly_exp_absorption`, `autocorrelation_WTF` closure for both the
function and its derivative). All of that is load-bearing for downstream
results.

## The target

**One sorry to attempt:** `weil_component2_continuous_WTF` in
`ContinuityHelpers.lean` (line ~237).

Statement: continuity of
```
g : WeilTestFunction ↦ ∑' n, Λ(n)/√n · ∫ g(t) g(t + log n) dt
```

The other two sorrys (`spectralSide_autocorr_nonneg_WTF` and
`weilPositivity_wtf_implies_rh` in `WeilTestFunction.lean`) are deep
Weil 1952 content. **Do not attempt them.**

## CORRECTION TO PREVIOUS ANALYSIS

In the previous round, Aristotle concluded `weil_component2_continuous_WTF`
"appears to be false" with a specific counterexample using Gaussians:
```
g_k = (1-ε_k) g_0 + ε_k · exp(-b_k t²),  b_k = 1/k,  ε_k = exp(-C/b_k)
```
and claimed the F_2 perturbation grows like `exp(C'/b_k)`.

**This counterexample is WRONG. Verified numerically with scipy:**
For C = 1/32 and b_k = 1/k, F_2(g_k) - F_2(g_0) goes:
- k=20:   77.6 (peaks around here)
- k=100:  10.7
- k=500:  4.9 × 10^-5
- k=1000: 7.9 × 10^-12
- k=5000: 0 (machine precision)

It converges to 0, not infinity. The previous claim "F_2(g_k) → ∞" is false.

**The arithmetic error in the previous analysis:**
The claim was that `∑ Λ(n)/√n · exp(-b(log n)²/2) ~ √(2π/b) · exp(1/(8b))`.
The correct asymptotic is `∑ Λ(n)/√n · exp(-b(log n)²/2) ~ exp(1/(2√b))`,
which is much slower growth. With ε_k² = exp(-2C/b_k), the kill factor
`exp(-2C/b_k)` always dominates `exp(1/(2√b_k))` for any C > 0.

So the lemma is **probably TRUE**, not false. The previous "likely false"
conclusion was based on a faulty asymptotic.

## DOCSTRING TO REPLACE

The current `weil_component2_continuous_WTF` docstring claims the lemma
"appears to be false" — this is misleading. Whether or not the lemma
proof is found this round, please **rewrite the docstring** to accurately
reflect the current status:

> The lemma is open. Numerical evidence (Python/scipy across many test
> sequences) supports continuity. The previous round attempted to construct
> a counterexample using Gaussians but the construction failed: numerical
> tests show F_2(g_k) → F_2(g_0) along all such sequences, refuting the
> claimed divergence. The asymptotic estimate `∑ Λ(n)/√n · exp(-b(log n)²/2)
> ~ exp(1/(8b))` was incorrect; the correct growth is `~ exp(1/(2√b))`,
> which is dominated by `exp(-2C/b)` for any C > 0.

## Possible proof approaches

### Approach A: Direct continuity via uniform tail control

For continuity at a fixed `g_*` ∈ WTF, on a Schwartz-topology neighborhood
of `g_*`, find a uniform bound on the tail:
```
sup_{g near g_*} ∑_{n > N} |Λ(n)/√n · ∫ g(t) g(t + log n) dt| → 0 as N → ∞
```

Each individual integral is bounded using uniform polynomial decay
(from Schwartz seminorm bounds on a neighborhood), giving e.g.
`|∫ g g(·+x)| ≤ C(g_*) / (1+x²)` for x = log n. The polynomial decay
in n is `(log n)^{-2}`, which combined with `Λ(n)/√n` does NOT give a
convergent series — `∑ log n / (√n · (log n)²) = ∑ 1/(√n · log n)` diverges.

So Approach A in this raw form fails. This is what the previous round's
"any polynomial bound gives O((log n)^{-k}) decay" argument was correctly
identifying. But this is NOT a counterexample to continuity — it just means
this particular proof strategy doesn't work.

### Approach B: Linearization at g_*

Fix g_* ∈ WTF with decay witnesses (b_*, C_*). For g near g_* in Schwartz
topology, write g = g_* + h with h small in seminorms. Then:
```
F_2(g) - F_2(g_*) = 2·cross(g_*, h) + F_2(h, h)
```
where:
```
cross(g_*, h) = ∑ Λ(n)/√n · ∫ g_*(t) h(t + log n) dt
F_2(h, h)     = ∑ Λ(n)/√n · ∫ h(t) h(t + log n) dt
```

**Key fact (verified numerically last round):** `cross(g_*, ·)` is a
BOUNDED LINEAR FUNCTIONAL on SchwartzMap, with bound depending only on
g_*'s WTF witnesses (b_*, C_*) and Schwartz seminorms of h. Specifically:
```
|cross(g_*, h)| ≤ C(b_*, C_*) · ‖h‖_∞
```

Why this works: the linear cross-term uses g_*'s exponential decay (via
`exp_decay_convolution_integral_bound`, already proved), giving a bound:
```
|∫ g_*(t) h(t + log n) dt| ≤ C_* · ‖h‖_∞ · (n^(-(1/2+b_*)) · (1/(1/2+b_*) + log n))
```
And ∑ Λ(n)/√n · n^(-(1/2+b_*)) · (constant + log n) = ∑ Λ(n)·log n / n^(1+b_*),
which CONVERGES (because b_* > 0).

So cross(g_*, ·) is continuous in h, and F_2(h, h) goes to 0 quadratically.
This gives continuity of F_2 at g_*.

### Approach C: Don't try to prove it this round

If neither approach closes cleanly, that's fine. Replace the misleading
"appears to be false" docstring with the accurate "open, numerical evidence
supports it" docstring above, and leave the sorry. Document any progress
toward the proof as named sub-sorrys.

## What to do

1. **Read the project files first.** All 9 files are provided. Don't rebuild
   anything from scratch.

2. **Use the existing helpers.** In particular:
   - `WeilTestFunction.exp_decay_convolution_integral_bound` (proved)
   - `WeilTestFunction.poly_exp_absorption` (proved)
   - `WeilTestFunction.vonMangoldt_sum_summable` (proved — gives absolute
     convergence on WTF)
   - `cross_correlation_decay_bound` in ContinuityHelpers (proved)

3. **Attempt Approach B** (linearization). Factor the proof into:
   - A new lemma `cross_term_bounded_by_seminorm`: |cross(g_*, h)| ≤ C·‖h‖
   - A new lemma `quadratic_term_o_h`: |F_2(h,h)| ≤ C·‖h‖²
   - Combine to prove continuity.
   
   These sub-lemmas may be hard. If they don't close, leave them as
   named sub-sorrys (not just "sorry") so the structure is captured.

4. **Always update the docstring**, even if the proof doesn't close.
   The "appears to be false" claim is wrong and should be removed.

## Critical instructions

- ✗ DO NOT modify any file other than `ContinuityHelpers.lean`.
- ✗ DO NOT rebuild `WeilTestFunction.lean` or `Main.lean` from scratch.
- ✗ DO NOT use Gaussian decay. WTF in this project uses **exponential
  decay matching Weil's condition (B)**.
- ✗ DO NOT repeat the previous "likely false" counterexample claim
  without first verifying it numerically (it has been refuted).
- ✗ DO NOT use `axiom`, `admit`, or `native_decide`.

## Expected reporting

In `ARISTOTLE_SUMMARY.md`:
- Build status (success/failure).
- Final sorry count per file (expected: ContinuityHelpers ≤ 1 + however many
  sub-sorrys the proof structure introduces; WeilTestFunction unchanged at 2).
- Whether the docstring was updated.
- If a proof was attempted: what sub-lemmas were introduced and their status.
- If the proof was not attempted: why (e.g., specific Mathlib API missing).
- ANY changes to other files should be reported as deviations.
