/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license.

Axiom audit of the four headline results of the project.

Elaborating this file prints, for each of the four theorems, the list of axioms its proof
depends on.  The expected — and observed — output is

  'ConnesConsani.WeilPositivity.fourierSide_nonneg' depends on axioms:
    [propext, Classical.choice, Quot.sound]

and likewise for the three others, i.e. only the three standard axioms of Lean/Mathlib
(no `sorryAx`, no `Lean.ofReduceBool`, no project-specific axiom).  The verbatim output is
recorded in `RequestProject/VERIFICATION.md`.
-/
import RequestProject.ArchimedeanPositivity
import RequestProject.NormalizedPositivity

namespace ConnesConsani.WeilPositivity

#print axioms fourierSide_nonneg
#print axioms two_thetaDeriv_add_deltaFourier_nonneg
#print axioms LfunNorm_re_nonneg_convLog_starLog
#print axioms LfunNorm_re_nonneg_contDiff_four
#print axioms LPositivityNorm_holds

end ConnesConsani.WeilPositivity
