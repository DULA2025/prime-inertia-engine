/-
Top-level import file for the formalization of

  Alain Connes & Caterina Consani,
  "Weil positivity and Trace formula – the archimedean place", arXiv:2006.13771.

Every module of the project is imported here, so that `lake build` of this file
elaborates the whole development.

See `RequestProject/Skeleton.lean` for a summary of what is formalized and what is not,
including the record of the modules that were removed in the clean-up of the repository.
-/
import RequestProject.Basic
import RequestProject.SineIntegral
import RequestProject.SiPositivity
import RequestProject.SiSmooth
import RequestProject.TraceRemainder
import RequestProject.Sonin
import RequestProject.Scaling
import RequestProject.WeilDistribution
import RequestProject.Mellin
import RequestProject.JumpFormula
import RequestProject.DeltaSmooth
import RequestProject.RemainderBound
import RequestProject.Positivity
import RequestProject.KernelBound
import RequestProject.Effective
import RequestProject.FourierSide
import RequestProject.Parseval
import RequestProject.Digamma
import RequestProject.DigammaAsymptotic
import RequestProject.ArchimedeanKernel
import RequestProject.ArchimedeanExplicit
import RequestProject.DeltaDecay
import RequestProject.ThetaGrowth
import RequestProject.DeltaDecaySharp
import RequestProject.DeltaVariation
import RequestProject.FourierSideAnalysis
import RequestProject.SiAsymptotic
import RequestProject.TaylorBounds
import RequestProject.CompactInterval
import RequestProject.DeltaFourierZero
import RequestProject.GammaBound
import RequestProject.NearOrigin
import RequestProject.MidThreshold
import RequestProject.Skeleton
import RequestProject.PolyaThreshold
import RequestProject.PolyaOscThreshold
import RequestProject.PolyaLinThreshold
import RequestProject.PolyaLowThreshold
import RequestProject.FourierDecay
import RequestProject.ArchimedeanPositivity
import RequestProject.QuarticDecay
import RequestProject.NormalizedPositivity
-- Operator-theoretic infrastructure for the one remaining `sorry` (`L_positive`):
-- the integrated scaling representation, the convolution algebra of test functions,
-- the Sonin sandwich and the trace-class groundwork.
import RequestProject.ScalingIntegrated
import RequestProject.TestConvolution
import RequestProject.SoninJoin
import RequestProject.TraceClass
import RequestProject.TraceProperty
import RequestProject.TraceBasisIndep
import RequestProject.TraceScaling
import RequestProject.TracePositivity
import RequestProject.SoninSandwich
