# Verification note

Two verification tasks were carried out on the finished analytic part of the project:

1. an **axiom audit** of the four headline theorems, and
2. a **normalization check** of the `∆^{1/2}` convention used by `LfunNorm` /
   `LPositivityNorm` against the convention of Connes–Consani, *Weil positivity and Trace
   formula – the archimedean place*, arXiv:2006.13771.

Both checks succeed.  Details follow.

---

## 1. Axiom audit

The audit is reproducible: `RequestProject/AxiomAudit.lean` contains the five
`#print axioms` commands, so the output below is regenerated on every build of that
module.  Verbatim output (Lean 4.28.0, Mathlib `v4.28.0`):

```
info: RequestProject/AxiomAudit.lean:22:0: 'ConnesConsani.WeilPositivity.fourierSide_nonneg' depends on axioms: [propext, Classical.choice, Quot.sound]
info: RequestProject/AxiomAudit.lean:23:0: 'ConnesConsani.WeilPositivity.two_thetaDeriv_add_deltaFourier_nonneg' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
info: RequestProject/AxiomAudit.lean:24:0: 'ConnesConsani.WeilPositivity.LfunNorm_re_nonneg_convLog_starLog' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
info: RequestProject/AxiomAudit.lean:25:0: 'ConnesConsani.WeilPositivity.LfunNorm_re_nonneg_contDiff_four' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
info: RequestProject/AxiomAudit.lean:26:0: 'ConnesConsani.WeilPositivity.LPositivityNorm_holds' depends on axioms: [propext, Classical.choice, Quot.sound]
```

(The line breaks inside the second, third and fourth lists are only Lean's pretty-printer
wrapping the output; the three axioms are the same in all five cases.)

**Result: PASS.**  Each of the four headline results (five declarations: the two names of
the Fourier-side inequality, the convolution-square form of Corollary 2.3 (i), and the two
names of its `C⁴` form) depends on exactly the three standard axioms `propext`,
`Classical.choice`, `Quot.sound`.  In particular `sorryAx` does **not** appear, so none of
them uses, directly or transitively, the single remaining `sorry` of the project
(`L_positive`, `RequestProject/Positivity.lean`); neither does `Lean.ofReduceBool` appear,
so no `native_decide` is involved, and there is no project-specific axiom (the project
declares none).

Supporting facts checked at the same time:

* a full `lake build` of all project modules (8287 jobs) completes with no errors; the
  only warnings are `declaration uses 'sorry'` at `RequestProject/Positivity.lean:245`
  (`L_positive`) and Lake's `manifest out of date` notice about the local checkout of
  Mathlib;
* a search over the sources finds no other live `sorry`: the two occurrences in
  `FourierSide.lean` (lines 397 and 440) are inside `/- ... -/` comment blocks, and the
  ones in `Skeleton.lean` belong to the transcription of the original informal skeleton.

---

## 2. Normalization check: the `∆^{1/2}` convention

### 2.1 What the paper prescribes

*Introduction, p. 2* (definition of the convention):

> In order to reflect the unitarity of the scaling action it is convenient to use the
> automorphism of `C_c^∞(ℝ*₊)`, `f ↦ ∆^{1/2} f`, `∆^{1/2} f(x) := x^{1/2} f(x)` which
> replaces the involution `f ↦ f̄^♯` by the involution `f ↦ f*` of the convolution
> `C*`-algebra and the restriction of the Mellin transform to the critical line by the
> Fourier transform (see Appendix A).  **We let, for any place `v`,
> `W_v(f) := W_v(∆^{-1/2} f)`, `∀ f ∈ C_c^∞(ℝ*₊)`.**

(In the paper the left-hand side carries the decorated symbol of the normalized
distribution; the right-hand side is the unnormalized one of Appendix B.)

*Appendix A, formula (145)*: `k ↦ ∆^{1/2}(k) = f`, `f(x) := x^{1/2} k(x)`.

*Appendix B, formula (150)* (the unnormalized archimedean distribution):

> `W_ℝ(f) := (log 4π + γ) f(1) + ∫₁^∞ ( f(x) + f^♯(x) − 2 f(1)/x ) dx/(x − x^{-1})`.

*§1, after formula (39), p. 11* (the coherence computation, which is the paper's own check
of the convention):

> One checks that (39) is coherent with the equality `W_ℝ(f) = W_ℝ(∆^{-1/2} f)`, we
> compare with (150) of Appendix B.  One has (assuming for simplicity `f(1) = 0`)
> `W_ℝ(f) = ∫₀^∞ f(ρ^{-1}) τ(ρ) d*ρ = ∫₀^∞ τ(ρ) f(ρ) d*ρ`.
> For `ρ > 1` one has `τ(ρ) = ρ^{3/2}/(ρ² − 1)` by (39) and with `k = ∆^{-1/2} f`,
> `k(u) = u^{-1/2} f(u)`,
> `∫₁^∞ ρ^{3/2}/(ρ²−1) f(ρ) d*ρ = ∫₁^∞ ρ^{1/2}/(ρ²−1) f(ρ) dρ = ∫₁^∞ k(x) dx/(x − x^{-1})`.

Here `(39)` is `τ(ρ) = (ρ^{1/2}/2) ( 1/(1+ρ) + 1/|1−ρ| )`.

*§2, Corollary 2.3* (the statement that is formalized):

> (i) The following functional is positive on the convolution algebra `C_c^∞(ℝ*₊)`:
> `L(f) = ∫ f(ρ^{-1}) (δ(ρ) − τ(ρ)) d*ρ`  (51).
> (ii) The function `2θ'(t) + δ̂(t)` is non-negative, where
> `δ̂(t) := ∫_{ℝ*₊} δ(ρ) ρ^{-it} d*ρ`.

with, in the proof, the Parseval identity

> `L(f) = ∫ f̂(t) ( 2∂_t θ(t) + δ̂(t) ) dt/(2π)`  (52).

So in the paper the *same* function `f` — the one that is positive definite for the
Fourier transform, i.e. the one in the `∆^{1/2}` picture — is paired with `δ` directly and
with `τ`, and `∫ f(ρ^{-1}) τ(ρ) d*ρ` is precisely formula (150) evaluated at `∆^{-1/2} f`.

### 2.2 What the formalization defines

`RequestProject/WeilDistribution.lean`:

```lean
/-- The involution `f ↦ f♯`, `f♯(x) = x⁻¹ f(x⁻¹)`, of the introduction of the paper. -/
def sharp (f : ℝ → ℂ) : ℝ → ℂ := fun x => (x : ℂ)⁻¹ * f x⁻¹

/-- The archimedean Weil distribution `W_ℝ`, formula (150) of arXiv:2006.13771:
`W_ℝ(f) = (log 4π + γ) f(1) + ∫₁^∞ (f(x) + f♯(x) - 2f(1)/x) dx/(x - x⁻¹)`. -/
def WeilR (f : ℝ → ℂ) : ℂ :=
  ((Real.log (4 * π) + Real.eulerMascheroniConstant : ℝ) : ℂ) * f 1 +
    ∫ x in Ioi (1:ℝ), (f x + sharp f x - 2 * f 1 / (x : ℂ)) / ((x : ℂ) - (x : ℂ)⁻¹)

/-- The archimedean term of the Weil explicit formula with the sign convention of the
paper: `W_∞ = -W_ℝ`. -/
def Winfty (f : ℝ → ℂ) : ℂ := -WeilR f

/-- The operator `∆^{-1/2} : f ↦ (x ↦ x^{-1/2} f(x))` used in the paper to make the
scaling action unitary. -/
def deltaHalfInv (f : ℝ → ℂ) : ℝ → ℂ := fun x => ((Real.sqrt x : ℝ) : ℂ)⁻¹ * f x
```

`RequestProject/Positivity.lean`:

```lean
/-- A function of the logarithmic variable `t`, read as a function of `ρ = e^t` on
`(0,∞)` (and extended by zero to the rest of the line). -/
def ofLog (G : ℝ → ℂ) : ℝ → ℂ := fun x => if 0 < x then G (Real.log x) else 0

/-- The functional `D` of the paper, `D(f) = ∫ f(ρ⁻¹) δ(ρ) d*ρ`, for complex valued test
functions on `ℝ⋆₊`. -/
def Dcomplex (f : ℝ → ℂ) : ℂ :=
  ∫ ρ : Rplus, f ((ρ : ℝ)⁻¹) * ((delta ρ : ℝ) : ℂ) ∂(Rplus.haar)
```

`RequestProject/ArchimedeanExplicit.lean`:

```lean
/-- **The functional `L = D + W_∞`** of §2 of the paper, in the logarithmic coordinate and
in the `∆^{1/2}` normalization: the archimedean term is the distribution (150) applied to
`∆^{-1/2} f`, as the paper prescribes. -/
def LfunNorm (G : ℝ → ℂ) : ℂ := Dcomplex (ofLog G) + Winfty (deltaHalfInv (ofLog G))
```

`RequestProject/NormalizedPositivity.lean`:

```lean
def LPositivityNorm : Prop :=
  ∀ G : ℝ → ℂ, ContDiff ℝ 4 G → HasCompactSupport G → PositiveDefiniteLog G →
    0 ≤ (LfunNorm G).re
```

### 2.3 Term-by-term comparison

| paper | formalization |
|---|---|
| `∆^{1/2}f(x) = x^{1/2}f(x)`, so `∆^{-1/2}f(x) = x^{-1/2}f(x)` (intro, (145)) | `deltaHalfInv f x = (√x)⁻¹ * f x` |
| `f^♯(x) = x^{-1} f(x^{-1})` | `sharp f x = x⁻¹ * f x⁻¹` |
| `W_ℝ(f)` of (150) | `WeilR` (transcribed symbol for symbol) |
| `W_v(f) := W_v(∆^{-1/2}f)` (intro) | `Winfty (deltaHalfInv ·)` in `LfunNorm` |
| `− ∫ f(ρ^{-1}) τ(ρ) d*ρ`, the `τ`-half of (51) | `Winfty (deltaHalfInv (ofLog G))`, since `Winfty = −WeilR` |
| `∫ f(ρ^{-1}) δ(ρ) d*ρ`, the `δ`-half of (51), applied to the *same* `f` | `Dcomplex (ofLog G)` — no `∆` factor, as in the paper |
| `L(f)` of (51) | `LfunNorm G` (with `f = G ∘ log`, i.e. `f(ρ) = G(log ρ)`) |
| `L(f) = ∫ f̂(t)(2θ'(t)+δ̂(t)) dt/2π`, (52) | `LfunNorm_parseval` |
| `W_ℝ(∆^{-1/2}f) = (2π)^{-1}∫ f̂(t)·2θ'(t)dt` (the `W`-half of (52)) | `WinftyParsevalNorm` / `Winfty_deltaHalfInv_ofLog` |
| Corollary 2.3 (i): `L ≥ 0` on positive definite `f` | `LfunNorm_re_nonneg_contDiff_four`, `LPositivityNorm_holds` |

The decisive point — that `WeilR ∘ deltaHalfInv` reproduces the `τ`-pairing of (51), and
not some other pairing — is checked in the formalization itself and can be read off two
theorems.

* `WeilR_explicit` (`RequestProject/WeilDistribution.lean`): for `f(1) = 0`,
  `W_ℝ(f) = ∫₁^∞ f(x)·x/(x²−1) dx + ∫₀¹ f(x)/(1−x²) dx`.
  Substituting `f := ∆^{-1/2}F` and passing to `d*x = dx/x` turns the first integral into
  `∫₁^∞ F(x)·x^{3/2}/(x²−1) d*x` and the second into `∫₀¹ F(x)·x^{1/2}/(1−x²) d*x`; by
  formula (39) of the paper these weights are exactly `τ(x)` for `x > 1` and for `x ≤ 1`
  respectively.  This is the paper's own coherence computation quoted in §2.1 above.
* `WeilR_deltaHalfInv_ofLog` (`RequestProject/ArchimedeanExplicit.lean`) states the same
  identity in the logarithmic coordinate `x = e^u`:
  `W_ℝ(∆^{-1/2}(G∘log)) = (log 4π + γ)G(0) + ∫₀^∞ (e^{u/2}(G(u)+G(−u)) − 2G(0)) du/(e^u−e^{-u})`,
  which is the paper's `∫₁^∞ k(x) dx/(x − x^{-1})` with `k = ∆^{-1/2}f`, written out with
  the `f^♯`-term (`G(−u)`) and the `f(1)`-subtraction restored.

Two harmless conventions are worth recording explicitly, since they are the only places
where the formalization is not a literal transcription:

* **Direction of the transform.**  The paper uses `f̂(s) = ∫₀^∞ f(u) u^{-is} d*u`
  (Appendix A), whereas `fourierLog G t = mellinLog G (I·t) = ∫_ℝ G(u) e^{iut} du`, i.e.
  `f̂(−t)`.  Since `2θ'` and `δ̂` are even (`thetaDeriv_even`, `deltaFourier_even`) and the
  `t`-integral in (52) runs over all of `ℝ`, the two conventions give the same value of
  `L`, and positive definiteness (`PositiveDefiniteLog`: `Re f̂ ≥ 0` on the unitary line)
  is likewise insensitive to it.
* **`δ̂` as a cosine transform.**  `deltaFourier t = ∫_ℝ δ(e^u) cos(tu) du` rather than
  `∫ δ(ρ)ρ^{-it}d*ρ`; the two agree because `δ(ρ^{-1}) = δ(ρ)` (`delta_symmetric`), which
  is Proposition 2.2 (ii) of the paper and a theorem here.

### 2.4 Conclusion

**Result: PASS — the conventions agree.**  `LfunNorm` (and hence `LPositivityNorm`) is the
functional `L` of formula (51)/(52) of Connes–Consani in the paper's own `∆^{1/2}`
normalization: the archimedean distribution (150) is applied to `∆^{-1/2}f`, exactly as the
introduction prescribes (`W_v(f) := W_v(∆^{-1/2}f)`), while the trace-remainder term pairs
`δ` with `f` itself.  Consequently `LfunNorm_re_nonneg_convLog_starLog`,
`LfunNorm_re_nonneg_contDiff_four` and `LPositivityNorm_holds` are statements of
Corollary 2.3 (i), and not of a differently normalized variant.

By contrast the older predicate `LPositivity` (`RequestProject/Positivity.lean`), built on
`Lfun f = Dcomplex f + Winfty f`, applies `W_ℝ` to `f` rather than to `∆^{-1/2}f`; it is
therefore *not* the statement of Corollary 2.3, which is why its `sorry` (`L_positive`) is
not needed by anything above and why the docstrings of `LPositivity` and `L_positive`
carry a normalization warning.

---

## 3. Status after the two checks

The analytic part of the archimedean place is **finished and frozen**:

* the Fourier-side inequality `2θ'(t) + δ̂(t) ≥ 0` holds for every real `t`
  (`fourierSide_nonneg`, `two_thetaDeriv_add_deltaFourier_nonneg`);
* Corollary 2.3 (i) holds unconditionally, both for convolution squares of `C²` test
  functions (`LfunNorm_re_nonneg_convLog_starLog`) and for all `C⁴` compactly supported
  positive definite test functions (`LfunNorm_re_nonneg_contDiff_four`,
  `LPositivityNorm_holds`);
* all of this rests on `propext`, `Classical.choice`, `Quot.sound` only.

The single remaining `sorry` of the project, `L_positive`, concerns the **unnormalized**
statement `Lfun = Dcomplex + Winfty` discussed in §2.4.  It is not the statement of the
paper, nothing in the results above depends on it, and it is not required by the paper's
subsequent arguments (§3 and later use the normalized functional, and the corresponding
consequences are already available unconditionally as
`Winfty_deltaHalfInv_nonneg_of_D_Qlog_nonpos_Icc`, `small_support_Winfty_deltaHalfInv_ge`
and `Winfty_deltaHalfInv_ge_effective`).  Closing it would require the operator trace
identity `L(f) = Tr(ϑ(f) P P̂ P)`, i.e. the operator-theoretic development listed in
`RequestProject/Skeleton.lean`.
