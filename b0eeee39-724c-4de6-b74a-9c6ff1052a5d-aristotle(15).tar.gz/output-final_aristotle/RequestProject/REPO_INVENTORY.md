# Repository inventory

Snapshot of the Lean sources of this project.  No mathematical content was added or changed
while writing it; the four modules listed in §7 were removed in the clean-up of the
repository, none of them being used by any live theorem.

* Toolchain: Lean 4.28.0, Mathlib as pinned by `lean-toolchain` / `lake-manifest.json`.
* Build state at the time of writing: `lake build` completes successfully (8287 jobs);
  the only warning is the single `declaration uses 'sorry'` warning listed in §2.
* This snapshot was taken after the clean-up recorded in §7.

## Conventions used in the tables

* **Declarations** counts *top-level* declarations, i.e. lines that begin in column 0 with
  `def`, `theorem`, `lemma`, `instance`, `abbrev`, `structure`, `class`, `inductive`
  (optionally preceded by attributes and by modifiers such as `noncomputable`/`private`).
  Declarations occurring inside comments are **not** counted.
* **Sorries** counts occurrences of the token `sorry` in *code* only; occurrences inside
  comments and docstrings are excluded (this matters for `RequestProject/Skeleton.lean`,
  which reproduces the original informal skeleton inside a comment, and for the commented
  historical statement in `RequestProject/FourierSide.lean`).
* Machine-generated families of files (the certified-quadrature pieces, blocks and
  frequency bands of the Pólya-model argument) are grouped into a single row.

## 1. Per-file inventory

| File | Lines | Declarations | Breakdown | Sorries |
|---|---:|---:|---|---:|
| `RequestProject/ArchimedeanExplicit.lean` | 860 | 41 | def 6, theorem 35 | 0 |
| `RequestProject/ArchimedeanKernel.lean` | 397 | 24 | def 4, theorem 20 | 0 |
| `RequestProject/ArchimedeanPositivity.lean` | 58 | 2 | theorem 2 | 0 |
| `RequestProject/Basic.lean` | 140 | 18 | abbrev 1, def 3, instance 7, lemma 7 | 0 |
| `RequestProject/CompactInterval.lean` | 224 | 7 | theorem 7 | 0 |
| `RequestProject/DeltaDecay.lean` | 470 | 14 | theorem 14 | 0 |
| `RequestProject/DeltaDecaySharp.lean` | 282 | 16 | theorem 16 | 0 |
| `RequestProject/DeltaFourierZero.lean` | 1194 | 62 | def 7, theorem 55 | 0 |
| `RequestProject/DeltaSmooth.lean` | 153 | 15 | def 3, theorem 12 | 0 |
| `RequestProject/DeltaVariation.lean` | 593 | 27 | def 1, theorem 26 | 0 |
| `RequestProject/Digamma.lean` | 571 | 34 | def 3, theorem 31 | 0 |
| `RequestProject/DigammaAsymptotic.lean` | 397 | 17 | def 3, theorem 14 | 0 |
| `RequestProject/Effective.lean` | 264 | 12 | theorem 12 | 0 |
| `RequestProject/FourierDecay.lean` | 293 | 16 | theorem 16 | 0 |
| `RequestProject/FourierSide.lean` | 443 | 25 | def 3, theorem 22 | 0 |
| `RequestProject/FourierSideAnalysis.lean` | 184 | 16 | def 3, theorem 13 | 0 |
| `RequestProject/GammaBound.lean` | 179 | 11 | def 1, theorem 10 | 0 |
| `RequestProject/JumpFormula.lean` | 370 | 11 | def 1, theorem 10 | 0 |
| `RequestProject/KernelBound.lean` | 439 | 32 | def 8, theorem 24 | 0 |
| `RequestProject/Main.lean` | 66 | 0 | — | 0 |
| `RequestProject/Mellin.lean` | 333 | 28 | def 5, theorem 23 | 0 |
| `RequestProject/MidThreshold.lean` | 739 | 49 | def 7, theorem 42 | 0 |
| `RequestProject/NearOrigin.lean` | 884 | 49 | def 5, theorem 44 | 0 |
| `RequestProject/NormalizedPositivity.lean` | 217 | 17 | def 2, theorem 15 | 0 |
| `RequestProject/Parseval.lean` | 245 | 12 | def 2, theorem 10 | 0 |
| `RequestProject/PolyaError.lean` | 492 | 21 | def 1, theorem 20 | 0 |
| `RequestProject/PolyaErrorSharp.lean` | 381 | 17 | def 6, theorem 11 | 0 |
| `RequestProject/PolyaLinBand*.lean` (128 files) | 123264 | 4864 | theorem 4864 | 0 |
| `RequestProject/PolyaLinBlocks*.lean` (4 files) | 3080 | 37 | theorem 37 | 0 |
| `RequestProject/PolyaLinPieces*.lean` (8 files) | 7395 | 560 | theorem 560 | 0 |
| `RequestProject/PolyaLinThreshold.lean` | 927 | 1 | theorem 1 | 0 |
| `RequestProject/PolyaLinVbp*.lean` (4 files) | 2887 | 561 | theorem 561 | 0 |
| `RequestProject/PolyaLowBand*.lean` (11 files) | 7557 | 297 | theorem 297 | 0 |
| `RequestProject/PolyaLowBase.lean` | 126 | 4 | theorem 4 | 0 |
| `RequestProject/PolyaLowBlocks*.lean` (4 files) | 4003 | 66 | theorem 66 | 0 |
| `RequestProject/PolyaLowPieces*.lean` (4 files) | 1586 | 166 | theorem 166 | 0 |
| `RequestProject/PolyaLowTail.lean` | 95 | 6 | theorem 6 | 0 |
| `RequestProject/PolyaLowThreshold.lean` | 117 | 3 | theorem 3 | 0 |
| `RequestProject/PolyaLowVbp*.lean` (2 files) | 874 | 166 | theorem 166 | 0 |
| `RequestProject/PolyaModel.lean` | 274 | 16 | def 2, theorem 14 | 0 |
| `RequestProject/PolyaOscBand*.lean` (27 files) | 30537 | 1998 | theorem 1998 | 0 |
| `RequestProject/PolyaOscBase.lean` | 522 | 36 | def 5, theorem 31 | 0 |
| `RequestProject/PolyaOscBlocks*.lean` (4 files) | 1945 | 147 | theorem 147 | 0 |
| `RequestProject/PolyaOscLin.lean` | 612 | 31 | def 4, theorem 27 | 0 |
| `RequestProject/PolyaOscTail.lean` | 37 | 1 | theorem 1 | 0 |
| `RequestProject/PolyaOscThreshold.lean` | 268 | 5 | theorem 5 | 0 |
| `RequestProject/PolyaPartition*.lean` (3 files) | 3059 | 61 | theorem 61 | 0 |
| `RequestProject/PolyaThreshold.lean` | 185 | 8 | theorem 8 | 0 |
| `RequestProject/Positivity.lean` | 673 | 66 | def 15, theorem 51 | 1 |
| `RequestProject/QuarticDecay.lean` | 176 | 11 | theorem 11 | 0 |
| `RequestProject/RemainderBound.lean` | 258 | 7 | theorem 7 | 0 |
| `RequestProject/Scaling.lean` | 81 | 10 | abbrev 1, def 3, lemma 4, theorem 2 | 0 |
| `RequestProject/ScalingIntegrated.lean` | 183 | 23 | def 4, theorem 19 | 0 |
| `RequestProject/SiAsymptotic.lean` | 345 | 20 | def 2, theorem 18 | 0 |
| `RequestProject/SiDivMono.lean` | 123 | 9 | def 1, theorem 8 | 0 |
| `RequestProject/SiPositivity.lean` | 474 | 24 | def 1, lemma 18, theorem 5 | 0 |
| `RequestProject/SiSharp.lean` | 231 | 10 | theorem 10 | 0 |
| `RequestProject/SiSmooth.lean` | 184 | 14 | def 2, theorem 12 | 0 |
| `RequestProject/SineIntegral.lean` | 312 | 21 | def 2, lemma 18, theorem 1 | 0 |
| `RequestProject/Skeleton.lean` | 1225 | 0 | — | 0 |
| `RequestProject/Sonin.lean` | 233 | 28 | abbrev 1, def 9, instance 1, lemma 4, theorem 13 | 0 |
| `RequestProject/SoninJoin.lean` | 158 | 27 | def 2, instance 2, theorem 23 | 0 |
| `RequestProject/SoninSandwich.lean` | 49 | 3 | theorem 3 | 0 |
| `RequestProject/TaylorBounds.lean` | 262 | 23 | def 5, theorem 18 | 0 |
| `RequestProject/TestConvolution.lean` | 190 | 18 | def 4, theorem 14 | 0 |
| `RequestProject/ThetaGrowth.lean` | 374 | 21 | theorem 21 | 0 |
| `RequestProject/TraceBasisIndep.lean` | 136 | 9 | def 1, theorem 8 | 0 |
| `RequestProject/TraceClass.lean` | 236 | 22 | def 5, theorem 17 | 0 |
| `RequestProject/TracePositivity.lean` | 113 | 6 | theorem 6 | 0 |
| `RequestProject/TraceProperty.lean` | 85 | 4 | theorem 4 | 0 |
| `RequestProject/TraceRemainder.lean` | 343 | 25 | def 4, lemma 5, theorem 16 | 0 |
| `RequestProject/TraceScaling.lean` | 67 | 3 | theorem 3 | 0 |
| `RequestProject/WeilDistribution.lean` | 160 | 11 | def 5, theorem 6 | 0 |

### Totals

| Quantity | Value |
|---|---:|
| Modules (`.lean` files under `RequestProject/`) | **262** |
| Total lines | 206 917 |
| Total top-level declarations | **10 042** |
| Total `sorry`s in code | **1** |
| Modules containing a `sorry` | 1 (`Positivity`) |

## 2. Global summary — the complete list of remaining sorries

| # | File | Declaration | Statement | Why it is open |
|---:|---|---|---|---|
| 1 | `RequestProject/Positivity.lean` | `L_positive` | `LPositivity` | needs the operator trace identity `L(f) = Tr(ϑ(f) P P̂ P)`, i.e. the integrated representation `ϑ(f)` and trace-class operators |

The single sorried declaration is not referred to by any other declaration in the project:
every downstream statement that needs it carries it as an explicit hypothesis instead.
(`LPositivity_of_fourierSide_nonneg`, which used to be the second `sorry`, is kept in
`RequestProject/FourierSide.lean` as a commented-out block together with the explanation of
why it is not provable as stated.)

`#print axioms` on the main results — `fourierSide_nonneg`,
`two_thetaDeriv_add_deltaFourier_nonneg`, `LfunNorm_re_nonneg_convLog_starLog`,
`LfunNorm_re_nonneg`, `LfunNorm_re_nonneg_convLog_starLog_self`,
`integrable_fourierLog_convLog_starLog_self` — reports only
`propext, Classical.choice, Quot.sound`.  For the four headline theorems this audit is now
reproducible as the module `RequestProject/AxiomAudit.lean` (28 lines, no declarations: it
only elaborates the five `#print axioms` commands), and its verbatim output, together with
the check of the `∆^{1/2}` normalization against the paper, is recorded in
`RequestProject/VERIFICATION.md`.

## 3. Status of the Fourier-side inequality

Throughout, `thetaDeriv t = θ'(t)`, `deltaFourier t = δ̂(t)` and
`fourierSide t = 2 * thetaDeriv t + deltaFourier t` (definitions in
`RequestProject/FourierSide.lean`).

**The inequality is proved for every real `t`:**

```
RequestProject/PolyaLowThreshold.lean
theorem fourierSide_nonneg (t : ℝ) : 0 ≤ fourierSide t
theorem two_thetaDeriv_add_deltaFourier_nonneg (t : ℝ) : 0 ≤ 2 * thetaDeriv t + deltaFourier t
```

It is assembled from three ranges, each `sorry`-free:

| Range | Theorem | File | Mechanism |
|---|---|---|---|
| `\|t\| ≤ 0.18` | `fourierSide_nonneg_of_abs_le` | `NearOrigin.lean` | spread comparison `Δ(t) ≤ Θ(t) + t²/5` with the certified value `δ̂(0) ≥ 5.3795` |
| `0.18 ≤ \|t\| ≤ 1.8` | `fourierSide_nonneg_of_low_threshold` | `PolyaLowThreshold.lean` | band criterion with the first digamma/model poles cancelled, on eleven bands |
| `\|t\| ≥ 1.8` | `fourierSide_nonneg_of_lin_threshold` | `PolyaLinThreshold.lean` | linear-phase block bounds on 128 bands, then the earlier thresholds `5.5`, `8`, `12`, … |

The historical chain of thresholds (all still present and `sorry`-free) is
`2π e^{17π+20}` (`ThetaGrowth.lean`), `60` (`ThetaGrowth.lean`), `38`
(`DeltaDecaySharp.lean`), `34` (`MidThreshold.lean`), `23`
(`DeltaVariation.lean`), `12` and `8` (`PolyaThreshold.lean`), `7`, `6.5`, `6`, `5.5`
(`PolyaOscThreshold.lean`), `1.8` (`PolyaLinThreshold.lean`).

The two conditional routes to the inequality that used to be recorded — each depending on
an unproved `Prop`-valued hypothesis (`TailEnergyIdentity`, resp. `BandEnergyBound` and
`TraceLimitIdentity`) — were removed in the clean-up of the repository, the inequality
being now proved unconditionally.

## 4. Status of Corollary 2.3 (i) — the positivity of `L`

```
RequestProject/ArchimedeanPositivity.lean
theorem LfunNorm_re_nonneg_convLog_starLog {F : ℝ → ℂ} (hF : ContDiff ℝ 2 F)
    (hsF : HasCompactSupport F) : 0 ≤ (LfunNorm (convLog F (starLog F))).re
```

`LfunNorm` is `L = D + W_∞` in the `∆^{1/2}` normalization of the paper.  The statement is
unconditional; its three ingredients are

* the Parseval identity (52), both halves proved (`Dcomplex_parseval` in `Parseval.lean`,
  the archimedean explicit formula `Winfty_deltaHalfInv_ofLog` in
  `ArchimedeanExplicit.lean`, itself resting on the two digamma facts proved in
  `Digamma.lean`);
* the Fourier-side inequality above;
* the analytic side conditions on the transform of `F ⋆ F*`, proved in `FourierDecay.lean`.

What is *not* proved is the same statement for an arbitrary continuous compactly supported
positive definite test function (`LPositivity`), which needs the general Bochner theorem,
and the operator-trace route of the paper (`L_positive`).
## 5. What each module contributes (one sentence each)

* **`RequestProject/ArchimedeanExplicit.lean`** — The archimedean explicit formula `W_∞(f) = (2π)⁻¹ ∫ f̂(t)·2θ'(t) dt` in the corrected normalization (`WinftyParsevalNorm`), together with the conditional Corollary 2.3 (i) `LfunNorm_re_nonneg_of_fourierSide_nonneg` and the exact value `fourierSide_zero_eq`.
* **`RequestProject/ArchimedeanKernel.lean`** — The elementary analysis behind the explicit formula: the kernel `κ(u) = e^{|u|/2}/(e^u − e^{−u})`, its expansion into Poisson kernels, their Fourier transforms `2b/(b²+t²)` and the constant `(log 2)/2 + π/4`.
* **`RequestProject/Basic.lean`** — The multiplicative group `ℝ⋆₊`, its Haar measure `d*ρ = dρ/ρ` and the exponential homeomorphism `ℝ ≃ ℝ⋆₊`.
* **`RequestProject/CompactInterval.lean`** — Reduces the inequality at the origin to `δ̂(0) ≥ 5.3765` (`fourierSide_threshold_lt`, `fourierSide_zero_nonneg_of_deltaFourier_zero_ge`), and documents why the two elementary routes on the remaining compact interval do not close it.
* **`RequestProject/DeltaDecay.lean`** — First decaying bound for the transform of the trace remainder, `|δ̂(t)| ≤ 32π e^{π/(2|t|)}/|t|` (hence `≤ 104/|t|` for `|t| ≥ 60`), by the half-period shift device.
* **`RequestProject/DeltaDecaySharp.lean`** — The same input used through an integration by parts instead: `|δ̂(t)| ≤ 64/|t|`, which lowers the large-`|t|` threshold from 60 to 38 (`fourierSide_nonneg_of_thirtyeight_le_abs`).
* **`RequestProject/DeltaFourierZero.lean`** — The certified numerical lower bound `δ̂(0) ≥ 5.3795` (`deltaFourier_zero_ge_d4`), its rounded form `deltaFourier_zero_ge : 5.3765 ≤ δ̂(0)`, and hence `fourierSide_zero_nonneg`.
* **`RequestProject/DeltaSmooth.lean`** — The trace remainder in logarithmic coordinates: smoothness on each side of `ρ = 1` and the jump `2` of its derivative there.
* **`RequestProject/DeltaVariation.lean`** — A certified total-variation bound `∫₀^∞ |(d/dv)δ(e^v)| dv ≤ 12`, giving `|δ̂(t)| ≤ 24/|t|` and the threshold `fourierSide_nonneg_of_twentythree_le_abs` (`|t| ≥ 23`).
* **`RequestProject/Digamma.lean`** — Gauss' partial-fraction expansion of `ψ` and the value `ψ(1/4) = -γ - 3 log 2 - π/2`.
* **`RequestProject/DigammaAsymptotic.lean`** — `Re ψ(a+ib) = ½ log(a²+b²) − E(a,b)` with `|E| ≤ 1/(a²+b²) + π/(2b)`, hence `Re ψ(a+ib) − log b → 0`.
* **`RequestProject/Effective.lean`** — Effective form of Corollary 3.8: `Re D(Qf) ≤ -(2−M) f(1)` under the kernel criterion `∫|Qδ| ≤ M`, discharged unconditionally for `s = 1/15` (`u = e^{1/15}`).
* **`RequestProject/FourierDecay.lean`** — Decay of the Fourier–Mellin transform: `‖f̂‖ = O(1/(1+t²))` for a `C²` compactly supported test function, the identity `|(F ⋆ F*)^| = |F̂|²`, the quadratic bound on the digamma increment and the Lipschitz bound at the origin — i.e. the three analytic side conditions of the Parseval identity — and hence Corollary 2.3 (i) for convolution squares, granted only the Fourier-side inequality.
* **`RequestProject/FourierSide.lean`** — Definitions of `thetaDeriv`, `deltaFourier` and `fourierSide = 2θ' + δ̂`, evenness/continuity, the crude bound `|δ̂(t)| ≤ δ̂(0)`, the reductions `fourierSide_nonneg_of_monotoneOn` and `fourierSide_zero_nonneg_iff`, and the one remaining `sorry` (the transfer of the inequality to the unnormalized `LPositivity`).
* **`RequestProject/FourierSideAnalysis.lean`** — The exact nonnegative series for `Θ(t) = 2θ'(t) − 2θ'(0)`, `thetaDeriv_monotoneOn`, the spread `Δ(t) = δ̂(0) − δ̂(t)` and the equivalence `fourierSide_nonneg_iff : 0 ≤ f(t) ↔ Δ(t) ≤ Θ(t) + f(0)`.
* **`RequestProject/GammaBound.lean`** — Sharper constants at the origin (`γ < 0.5772287`, `log π < 1.14474`), giving the quantitative margin `fourierSide_zero_ge : f(0) ≥ 0.0072`.
* **`RequestProject/JumpFormula.lean`** — Integration by parts against a function with a corner, producing the `-2‖ξ‖²` term of the essential negativity statements.
* **`RequestProject/KernelBound.lean`** — Closed form of the kernel `Qδ(e^t)` through sine/cosine moments and the explicit bound `|Qδ(e^t)| ≤ 14` for `|t| ≤ 1/15`.
* **`RequestProject/Main.lean`** — Top-level import file (imports every module); contains no declarations.
* **`RequestProject/Mellin.lean`** — The convolution `*`-algebra of `ℝ⋆₊` in logarithmic coordinates, the Fourier–Mellin transform and the operator `Qlog = -(d/dt)² + 1/4`.
* **`RequestProject/MidThreshold.lean`** — Lowers the large-`|t|` threshold from 38 to 34 (`fourierSide_nonneg_of_thirtyfour_le_abs`) by comparing the spread of `δ̂` directly with the partial sums of the series for `Θ`; also contains the alternating Taylor *upper* bounds for `sin`/`sinc`/`Si`.
* **`RequestProject/NearOrigin.lean`** — The inequality on a neighbourhood of the origin: the spread comparison `Δ(t) ≤ Θ(t) + t²/5`, hence `fourierSide_nonneg_of_sq_le` (`t² ≤ 5 f(0)`) and `fourierSide_nonneg_of_abs_le` (`|t| ≤ 0.18`).
* **`RequestProject/Parseval.lean`** — The logarithmic-coordinate transform `fourierLog`, the `D`-half of Parseval (52) (`Dcomplex_parseval`), the full identity `L_parseval` under the hypothesis `WinftyParseval`, and `L_real_nonneg_of_fourierSide_nonneg`.
* **`RequestProject/Positivity.lean`** — The functional `L = D + W_∞` in logarithmic coordinates, the vanishing conditions at `±i/2`, the Green potential/division property for `Q`, and the definition `LPositivity`; contains the `sorry` of `L_positive`.
* **`RequestProject/RemainderBound.lean`** — Boundedness of the remainder in the essential negativity identity, `|⟨ξ, Kξ⟩| ≤ C‖ξ‖²` with `C` depending only on the support.
* **`RequestProject/Scaling.lean`** — The scaling representation `ϑ` of `ℝ⋆₊` on `L²(ℝ⋆₊, d*ρ)` as a family of linear isometries.
* **`RequestProject/SiAsymptotic.lean`** — The classical asymptotic expansion of `Si` via Laplace integrals, including `∫₀^∞ sin t/t = π/2` and `|Si x − π/2| ≤ 1/x + 1/x²`.
* **`RequestProject/SiPositivity.lean`** — `Si x > 0` for `x > 0`.
* **`RequestProject/SiSmooth.lean`** — Smoothness of `siDiv a = Si a / a` and the cosine/sine moments `∫₀¹ tᵏ cos(at)(−log t) dt`.
* **`RequestProject/SineIntegral.lean`** — The definition of `Si` and the identity `∫₀¹ cos(at)(−log t) dt = Si(a)/a`.
* **`RequestProject/Skeleton.lean`** — Documentation only (no declarations): the running status record of the project, plus the original informal skeleton reproduced verbatim inside a comment.
* **`RequestProject/Sonin.lean`** — Sonin's space and the associated orthogonal projection, and the cutoff projections `P₁`, `P̂₁`.
* **`RequestProject/TaylorBounds.lean`** — Alternating Taylor bounds for `sin`, `cos` and `Si` (the general bracketing statement, proved by simultaneous induction).
* **`RequestProject/ThetaGrowth.lean`** — Growth of `2θ'`: `thetaDeriv_monotoneOn`, `abs_two_thetaDeriv_sub_log_le`, `two_thetaDeriv_ge : 2θ'(t) ≥ log(t/2π) − 4/t² − π/t`, and the thresholds `fourierSide_nonneg_of_le_abs`, `..._of_exp_le_abs`, `..._of_explicit_le_abs`, `..._of_sixty_le_abs`.
* **`RequestProject/TraceRemainder.lean`** — The trace remainder `δ`, its closed form `δ(ρ) = 2√ρ(Si(2π(1+ρ))/(2π(1+ρ)) + Si(2π(ρ−1))/(2π(ρ−1)))` for `ρ ≥ 1`, the symmetry `δ(ρ⁻¹) = δ(ρ)` and the decay bound.
* **`RequestProject/WeilDistribution.lean`** — The archimedean Weil distribution `W_ℝ` (formula (150)) and the normalization `∆^{1/2}`.

The families of generated files, and the modules added after the original snapshot:

* **`RequestProject/ArchimedeanPositivity.lean`** — The two halves combined: `LfunNorm_re_nonneg_convLog_starLog`, the unconditional positivity of `L = D + W_∞` on convolution squares of `C²` compactly supported test functions, and `LfunNorm_re_nonneg` for a general positive definite test function with integrable transform.
* **`RequestProject/PolyaModel.lean`** — The Pólya-type model `h(v) = e^{-v/2} + 2.11 e^{-3v}` for `g(v) = δ(e^v)`, its exact cosine transform, and the lower bounds `δ̂(t) ≥ -2ε`, `δ̂(t) ≥ 2ĥ(t) - 2ε`, uniform in `t`.
* **`RequestProject/PolyaError.lean`, `RequestProject/PolyaErrorSharp.lean`** — Pointwise brackets for the rescaled model error `Φ(v) = e^{v/2}(δ(e^v) - h(v))` and their integration over a piece, in Taylor and in asymptotic form.
* **`RequestProject/PolyaPartition1–3.lean`** — The 601-breakpoint partition, giving `integral_Ioi_abs_errFun_le : ε ≤ 0.21088`.
* **`RequestProject/PolyaThreshold.lean`** — `two_thetaDeriv_ge_series`, the band criterion `fourierSide_nonneg_band`, and the thresholds `|t| ≥ 12` and `|t| ≥ 8`.
* **`RequestProject/PolyaOscBase.lean`, `PolyaOscBlocks1–4.lean`, `PolyaOscTail.lean`, `PolyaOscBand0–26.lean`, `PolyaOscThreshold.lean`** — Signed block bounds for the oscillatory integral `∫₀^∞ err(v) cos(tv) dv`, giving the threshold `|t| ≥ 5.5`.
* **`RequestProject/PolyaOscLin.lean`, `PolyaLinVbp1–4.lean`, `PolyaLinPieces1–8.lean`, `PolyaLinBlocks1–4.lean`, `PolyaLinBand0–127.lean`, `PolyaLinThreshold.lean`** — The same with the phase linearised on each block, which makes the block error quadratic in the block width and lowers the threshold to `|t| ≥ 1.8`.
* **`RequestProject/PolyaLowBase.lean`, `PolyaLowVbp1–2.lean`, `PolyaLowPieces1–4.lean`, `PolyaLowTail.lean`, `PolyaLowBlocks1–4.lean`, `PolyaLowBand0–10.lean`, `PolyaLowThreshold.lean`** — The low-frequency range: the band criterion with the first digamma/model poles cancelled exactly, the partition extended to `q = 5` (tail `≤ 0.0022`), the eleven bands covering `0.18 ≤ |t| ≤ 1.8`, and hence `fourierSide_nonneg` for every real `t`.
* **`RequestProject/SiDivMono.lean`, `RequestProject/SiSharp.lean`** — Monotonicity and rational brackets for `Si` and `Si(x)/x`, used by the certified quadratures.

## 6. Operator-theoretic infrastructure for `L_positive`

These modules are the groundwork for the one remaining `sorry`; they are not used by the
Fourier-side results, and they were not imported by `RequestProject/Main.lean` until the
clean-up.  They are now imported there, so `lake build` of `Main` covers the whole project.

* **`RequestProject/ScalingIntegrated.lean`** — Strong continuity of the scaling representation and the integrated operators `ϑ(f) ξ = ∫ f(λ) ϑ(λ) ξ d*λ`, with `‖ϑ(f)‖ ≤ ‖f‖₁` and `ϑ(f)* = ϑ(f^♯)`.
* **`RequestProject/TestConvolution.lean`** — The convolution algebra `C_c(ℝ⋆₊)` and the multiplicativity `ϑ(f ∗ g) = ϑ(f) ϑ(g)`, hence `ϑ(g ∗ g^♯) = ϑ(g) ϑ(g)*`.
* **`RequestProject/SoninJoin.lean`** — The lattice description `S = 1 - (P₁ ∨ P̂₁)` of Sonin's space and the identities `S* = S = S² ≥ 0`.
* **`RequestProject/SoninSandwich.lean`** — The Sonin sandwich `P₁ P̂₁ P₁` written as `B* B` with `B = P̂₁ P₁`.
* **`RequestProject/TraceClass.lean`** — Hilbert–Schmidt and trace-class language: `hsNormSq`, its basis independence, `IsHilbertSchmidt`, `IsTraceClass`, `traceAlong` and `traceAlongRe`.
* **`RequestProject/TraceProperty.lean`** — The trace property `Tr(AB) = Tr(BA)` for Hilbert–Schmidt operators.
* **`RequestProject/TraceBasisIndep.lean`** — Basis independence of the trace of a trace-class operator, through the Hilbert–Schmidt pairing.
* **`RequestProject/TraceScaling.lean`** — `Tr(ϑ(f)^♯ A ϑ(f)) ≥ 0` for positive `A`, the positivity mechanism in the form in which it will be used.
* **`RequestProject/TracePositivity.lean`** — `Re Tr((T T*)(B* B)) ≥ 0` for Hilbert–Schmidt `B`, and its specialization to `ϑ(g ∗ g^♯)`.

## 7. Clean-up record

Four modules were removed from the repository; the reasons, and the audit that identified
them (a transitive closure over the *constants* used by the live theorems, not over the
imports), are recorded in the section *Clean-up of the repository (module inventory)* of
`RequestProject/Skeleton.lean`.  In summary:

| Module | Reason |
|---|---|
| `RequestProject/MidThreshold25.lean` | superseded intermediate threshold (`\|t\| ≥ 25`, between the `34` of `MidThreshold.lean` and the `23` of `DeltaVariation.lean`); no constant of it was used anywhere |
| `RequestProject/NearOriginSharp.lean` | unused sharpening of the near-origin range from `0.18` to `0.28` |
| `RequestProject/BandEnergy.lean` | conditional route resting on the unproved `BandEnergyBound` and `TraceLimitIdentity`; no longer needed |
| `RequestProject/TailEnergy.lean` | conditional route resting on the unproved `TailEnergyIdentity`; no longer needed |

No other module could be removed: every band file of the `PolyaOscBand*`, `PolyaLinBand*`
and `PolyaLowBand*` families certifies one frequency band of the covering used by
`fourierSide_nonneg`, and each step of the historical threshold chain is used by its
successor.  Consolidating consecutive band files into fewer modules was considered and
rejected (it would serialize work that is currently elaborated in parallel, without
reducing it).  The stale byte-compiled Python cache under `scripts/` was also deleted and
is now ignored by `git`.
