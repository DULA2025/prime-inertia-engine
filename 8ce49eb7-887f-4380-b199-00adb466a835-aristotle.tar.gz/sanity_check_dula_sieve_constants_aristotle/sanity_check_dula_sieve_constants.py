#!/usr/bin/env python3
"""
sanity_check_dula_sieve_constants.py
====================================

Numerical sanity check for DULASieveConstants.lean. Verifies:

  1. localFactor k = 1 - 1/k² is positive and < 1 for k ≥ 2.
  2. localFactor 2 = 3/4.
  3. Integer product ∏_{k=2}^{N+2} (1 - 1/k²) = (N+3) / (2(N+2)).
  4. twinPrimePartialProduct(N) is positive, ≤ 1, antitone.
  5. twinPrimePartialProduct(N) ≥ 1/2 for N ≥ 2.
  6. twinPrimePartialProduct converges to C_2 ≈ 0.660 ≥ 1/2.
  7. (Optional) twinPrimePartialProduct stays in the gap (1/2, 1).
"""
import sympy

def banner(t):
    print(f"\n{'─'*72}\n  {t}\n{'─'*72}")


def local_factor(k):
    return 1 - 1/k**2


def is_prime_offset(k):
    """k is a prime offset iff k ≥ 2 and k+1 is prime."""
    return k >= 2 and sympy.isprime(k + 1)


def prime_offsets_up_to(N):
    return [k for k in range(N + 1) if is_prime_offset(k)]


def twin_partial(N):
    result = 1.0
    for k in prime_offsets_up_to(N):
        result *= local_factor(k)
    return result


def integer_partial(low, high):
    """∏_{k=low}^{high} (1 - 1/k²)"""
    result = 1.0
    for k in range(low, high + 1):
        result *= local_factor(k)
    return result


ok = True

# Check 1: localFactor positivity/upper bound for k ≥ 2
banner("Check 1: localFactor k ∈ (0, 1) for k ≥ 2")
for k in [2, 3, 4, 5, 10, 100]:
    lf = local_factor(k)
    valid = 0 < lf < 1
    if not valid:
        print(f"  k={k}: localFactor = {lf}  FAIL")
        ok = False
    else:
        print(f"  k={k}: localFactor = {lf:.10f}  ✓")

# Check 2: localFactor 2 = 3/4
banner("Check 2: localFactor 2 = 3/4")
val = local_factor(2)
target = 0.75
if abs(val - target) > 1e-15:
    print(f"  FAIL: {val} ≠ {target}"); ok = False
else:
    print(f"  ✓ localFactor 2 = {val}")

# Check 3: Telescoping identity
banner("Check 3: ∏_{k=2}^{N+2} (1 - 1/k²) = (N+3)/(2(N+2))")
for N in range(0, 10):
    actual = integer_partial(2, N + 2)
    predicted = (N + 3) / (2 * (N + 2))
    err = abs(actual - predicted)
    status = "✓" if err < 1e-12 else "✗"
    print(f"  N={N}: actual = {actual:.10f}, predicted = {predicted:.10f}  {status}")
    if err >= 1e-12: ok = False

# Check 4: partial product properties
banner("Check 4: twinPrimePartialProduct(N) ∈ (0, 1], antitone")
prev = float('inf')
for N in [0, 1, 2, 3, 5, 10, 20, 50, 100, 1000, 10000]:
    val = twin_partial(N)
    if not (0 < val <= 1):
        print(f"  N={N}: value = {val} not in (0, 1]"); ok = False
    if val > prev + 1e-15:
        print(f"  N={N}: NOT antitone (was {prev:.10f}, now {val:.10f})"); ok = False
    print(f"  N={N:>6}: partial = {val:.12f}  (antitone: {val <= prev + 1e-15})")
    prev = val

# Check 5: Lower bound 1/2
banner("Check 5: twinPrimePartialProduct(N) ≥ 1/2 for all N ≥ 2")
for N in [2, 3, 5, 10, 50, 100, 1000, 10000]:
    val = twin_partial(N)
    if val < 0.5:
        print(f"  N={N}: {val} < 1/2  FAIL"); ok = False
    else:
        print(f"  N={N:>6}: {val:.12f} ≥ 0.5  ✓")

# Check 6: Convergence to C_2 ≈ 0.660
banner("Check 6: limit value approaches Wrench's C_2 = 0.6601618158...")
for N in [100, 1000, 10000, 100000]:
    val = twin_partial(N)
    print(f"  N={N:>7}: partial = {val:.15f}")
print(f"  Reference C_2 = 0.660161815846869573...")

# Check 7: integer partial ≤ prime partial (the key subset inequality)
banner("Check 7: integerPartial ≤ twinPrimePartialProduct (subset inequality)")
for N in [10, 50, 100, 500, 1000]:
    int_prod = integer_partial(2, N)
    twin_prod = twin_partial(N)
    if int_prod > twin_prod + 1e-12:
        print(f"  N={N}: int={int_prod} > twin={twin_prod}  FAIL"); ok = False
    else:
        print(f"  N={N:>5}: int_prod={int_prod:.10f}, twin_prod={twin_prod:.10f}  ✓")

# Summary
print()
print("=" * 72)
if ok:
    print("  ✓ All sanity checks pass. DULASieveConstants.lean theorems are correct.")
else:
    print("  ⚠ Some checks failed.")
print("=" * 72)
