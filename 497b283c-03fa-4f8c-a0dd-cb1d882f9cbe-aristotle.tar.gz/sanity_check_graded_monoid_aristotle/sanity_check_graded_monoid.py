#!/usr/bin/env python3
"""
sanity_check_graded_monoid.py
=============================

Numerical sanity checks for theorems in `DULAGradedMonoid.lean`.

Same philosophy as `sanity_check_chartwistedeta.py`: for each theorem,
evaluate both sides on many test instances and assert agreement. This
catches statement bugs (wrong sign, off-by-one, wrong predicate) before
anyone invests proving them in Lean.

Run before submitting Aristotle requests, and re-run after any edit to
the Lean definitions.

Exit 0 = all checks behaved as expected; 1 = at least one drifted.
"""

from __future__ import annotations
import sys
import sympy


# =============================================================================
#  Mirror the Lean definitions
# =============================================================================

def chi(n: int) -> int:
    """Mirror of `chi : ℕ → ℤ` in CharTwistedEta.lean."""
    n = int(n)
    if n % 2 == 0 or n % 3 == 0:
        return 0
    return 1 if n % 6 == 1 else -1


def is_coprime_six(n: int) -> bool:
    """Mirror of `isCoprimeSix`."""
    return n > 0 and sympy.gcd(n, 6) == 1


def lane_index(n: int) -> int:
    """Mirror of `laneIndex`: 0 if chi=+1, 1 if chi=-1. (Undefined when chi=0.)"""
    return 0 if chi(n) == 1 else 1


def in_lane_plus(n: int) -> bool:
    return is_coprime_six(n) and chi(n) == 1


def in_lane_minus(n: int) -> bool:
    return is_coprime_six(n) and chi(n) == -1


# =============================================================================
#  Checks
# =============================================================================

def banner(t):
    print(f"\n{'─'*76}\n  {t}\n{'─'*76}")


def check_mem_coprimeSixSet_iff_mod():
    name = "mem_coprimeSixSet_iff_mod: n ∈ M ↔ n > 0 ∧ n%6 ∈ {1,5}"
    banner(name)
    ok = True
    for n in range(0, 60):
        lhs = is_coprime_six(n)
        rhs = (n > 0 and n % 6 in (1, 5))
        if lhs != rhs:
            print(f"  n={n}: lhs={lhs} rhs={rhs}  FAIL")
            ok = False
    print(f"  Checked n ∈ 0..59: {'OK' if ok else 'FAIL'}")
    return name, ok


def check_mem_lanePlus_iff():
    name = "mem_lanePlus_iff: n ∈ M_+ ↔ n > 0 ∧ n%6 = 1"
    banner(name)
    ok = True
    for n in range(0, 100):
        lhs = in_lane_plus(n)
        rhs = (n > 0 and n % 6 == 1)
        if lhs != rhs:
            print(f"  n={n}: FAIL ({lhs} vs {rhs})")
            ok = False
    print(f"  Checked n ∈ 0..99: {'OK' if ok else 'FAIL'}")
    return name, ok


def check_mem_laneMinus_iff():
    name = "mem_laneMinus_iff: n ∈ M_- ↔ n > 0 ∧ n%6 = 5"
    banner(name)
    ok = True
    for n in range(0, 100):
        lhs = in_lane_minus(n)
        rhs = (n > 0 and n % 6 == 5)
        if lhs != rhs:
            print(f"  n={n}: FAIL ({lhs} vs {rhs})")
            ok = False
    print(f"  Checked n ∈ 0..99: {'OK' if ok else 'FAIL'}")
    return name, ok


def check_partition():
    name = "coprimeSixSet = lanePlus ⊔ laneMinus (partition)"
    banner(name)
    ok = True
    for n in range(1, 200):
        in_M = is_coprime_six(n)
        in_plus = in_lane_plus(n)
        in_minus = in_lane_minus(n)
        # Should be: in_M ↔ (in_plus xor in_minus), and never both
        if in_plus and in_minus:
            print(f"  n={n}: in BOTH lanes  FAIL"); ok = False
        if in_M != (in_plus or in_minus):
            print(f"  n={n}: in_M={in_M} but in_plus|in_minus={in_plus or in_minus}  FAIL"); ok = False
    print(f"  Checked n ∈ 1..199: {'OK' if ok else 'FAIL'}")
    return name, ok


def check_laneIndex_mul():
    name = "laneIndex_mul: laneIndex(a*b) = (laneIndex a + laneIndex b) mod 2"
    banner(name)
    ok = True
    pairs = [(a, b) for a in range(1, 30) for b in range(1, 30)
             if is_coprime_six(a) and is_coprime_six(b)]
    for (a, b) in pairs:
        lhs = lane_index(a * b)
        rhs = (lane_index(a) + lane_index(b)) % 2
        if lhs != rhs:
            print(f"  (a={a}, b={b}): lhs={lhs} rhs={rhs}  FAIL"); ok = False
    print(f"  Checked {len(pairs)} pairs: {'OK' if ok else 'FAIL'}")
    return name, ok


def check_prime_mod_six():
    name = "Nat.Prime.mod_six_of_three_lt: primes > 3 have residue ∈ {1, 5} mod 6"
    banner(name)
    ok = True
    primes = list(sympy.primerange(5, 5000))
    for p in primes:
        if p % 6 not in (1, 5):
            print(f"  p={p}: p%6={p%6}  FAIL"); ok = False
    print(f"  Checked {len(primes)} primes in (3, 5000): {'OK' if ok else 'FAIL'}")
    return name, ok


def check_twin_prime_lane_crossing():
    name = "twin_prime_lane_crossing: (p, p+2) prime, p>3 ⇒ p ∈ M_-, p+2 ∈ M_+"
    banner(name)
    ok = True
    twins = [(p, p+2) for p in sympy.primerange(5, 100000)
             if sympy.isprime(p+2)]
    for (p, q) in twins:
        if not in_lane_minus(p):
            print(f"  twin ({p},{q}): p not in M_-  FAIL"); ok = False
        if not in_lane_plus(q):
            print(f"  twin ({p},{q}): p+2 not in M_+  FAIL"); ok = False
    print(f"  Checked {len(twins)} twin pairs up to 10⁵: {'OK' if ok else 'FAIL'}")
    return name, ok


def check_chi_twin_prime_sign():
    name = "chi_twin_prime_sign: χ(p) · χ(p+2) = -1 for twins (p, p+2), p>3"
    banner(name)
    ok = True
    twins = [(p, p+2) for p in sympy.primerange(5, 100000)
             if sympy.isprime(p+2)]
    for (p, q) in twins:
        if chi(p) * chi(q) != -1:
            print(f"  twin ({p},{q}): χ(p)·χ(q) = {chi(p)*chi(q)}  FAIL"); ok = False
    print(f"  Checked {len(twins)} twin pairs up to 10⁵: {'OK' if ok else 'FAIL'}")
    return name, ok


def check_chiDir_eq_chi_on_coprimeSix():
    name = "chiDir_eq_chi_on_coprimeSix: (chi n : ℂ) = (-1)^(laneIndex n).val for n ∈ M"
    banner(name)
    ok = True
    tested = 0
    for n in range(1, 200):
        if is_coprime_six(n):
            lhs = chi(n)
            rhs = (-1) ** lane_index(n)
            if lhs != rhs:
                print(f"  n={n}: lhs={lhs} rhs={rhs}  FAIL"); ok = False
            tested += 1
    print(f"  Checked {tested} values in M ∩ [1, 200]: {'OK' if ok else 'FAIL'}")
    return name, ok


# =============================================================================
#  Main
# =============================================================================

CHECKS = [
    check_mem_coprimeSixSet_iff_mod,
    check_mem_lanePlus_iff,
    check_mem_laneMinus_iff,
    check_partition,
    check_laneIndex_mul,
    check_prime_mod_six,
    check_twin_prime_lane_crossing,
    check_chi_twin_prime_sign,
    check_chiDir_eq_chi_on_coprimeSix,
]


def main() -> int:
    print("=" * 78)
    print("  DULAGradedMonoid.lean — numerical sanity check")
    print("=" * 78)
    results = []
    for fn in CHECKS:
        try:
            name, ok = fn()
        except Exception as e:
            name, ok = fn.__name__, False
            print(f"  EXCEPTION: {e}")
        results.append((name, ok))
    print("\n" + "=" * 78)
    print("  SUMMARY")
    print("=" * 78)
    n_fail = 0
    for name, ok in results:
        flag = "" if ok else "  ⚠"
        print(f"  [{'PASS' if ok else 'FAIL'}]  {name}{flag}")
        if not ok: n_fail += 1
    print()
    if n_fail == 0:
        print("  ✓ All 9 statement checks pass numerically.")
        print("    Statements in DULAGradedMonoid.lean are consistent with definitions.")
        return 0
    print(f"  ⚠ {n_fail} check(s) failed.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
