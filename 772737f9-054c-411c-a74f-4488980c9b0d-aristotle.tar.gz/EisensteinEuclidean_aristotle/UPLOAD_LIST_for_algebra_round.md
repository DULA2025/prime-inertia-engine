# Files to upload INDIVIDUALLY for the next Aristotle round

Based on the finding that Aristotle reads uploaded files directly (not from
tarballs), upload each of the following .lean files INDIVIDUALLY to ensure
Aristotle has the full canonical project base and doesn't need to create stubs.

## Files to upload (in dependency order)

1. `EisensteinIntegers.lean`        279 lines    [base ring]
2. `EisensteinTheta.lean`           259 lines    [Ramanujan, divSum]
3. `EisensteinThetaBridge.lean`     112 lines    [(a,b)↔Eisenstein]
4. `EisensteinUnits.lean`           132 lines    [the 6 units]
5. `EisensteinOrbit.lean`           243 lines    [IsDomain, orbit count]
6. `EisensteinPrimeSplit.lean`       92 lines    [Piece 4a]
7. `EisensteinPrimeSplitHard.lean`  220 lines    [Piece 4b]
8. `EisensteinEuclidean.lean`       166 lines    [EuclideanDomain]
9. `EisensteinAlgebra.lean`         148 lines    [NEW: Module.Free + algebra norm]

All files are in /mnt/user-data/outputs/.

## What to ask Aristotle to do

"Build all .lean files together as a single Lean project. Verify that
EisensteinAlgebra.lean compiles with 0 sorries against the canonical base files
(do not modify any of files 1-8; only check that file 9 compiles in this context)."

## What this round will tell us

If EisensteinAlgebra.lean compiles:
  - basis (1, ω) is established
  - Module.Free ℤ Eisenstein, Module.Finite ℤ Eisenstein are instances
  - Algebra.norm ℤ z = norm z (the bridge to Mathlib's algebra norm)
  - Ideal.absNorm (Ideal.span {z}) = (norm z).natAbs (the bridge to ideal norm)

This unlocks:
  - Piece 4c (prime-power counts): use Mathlib's ideal-norm machinery + 
                                   "ideals of given norm in a Dedekind domain"
  - Piece 4d (multiplicativity): immediate from Ideal.absNorm.map_mul on coprime ideals

If Aristotle flags errors:
  - Most likely culprit: Mathlib API names for Algebra.norm computation
  - Send me the error message; the math is verified, the fix is name lookup

## Honest risk assessment

The basis construction (lines 33-95): high confidence, robust tactics
The Module.Free/Finite instances (lines 89-91): medium confidence
The Algebra.norm = norm theorem (lines 101-134): low-medium confidence
The bridge theorems (lines 136-148): high confidence

Expected outcome: green or a single Aristotle round fix on Algebra.norm computation.
