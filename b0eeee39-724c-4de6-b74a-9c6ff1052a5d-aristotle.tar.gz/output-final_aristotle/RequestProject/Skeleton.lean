/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license.
-/
import RequestProject.WeilDistribution

/-!
# Weil positivity – archimedean place: status of the formalization

This file records the original informal skeleton of arXiv:2006.13771 that this project
started from, and maps each of its items to what is now actually formalized (and proved)
in the other files of the project.

## What is formalized and proved

* `RequestProject/Basic.lean`
  - `Rplus`, the multiplicative group `ℝ⋆₊ = (0,∞)`, with its topological group,
    measurable and locally compact structures;
  - `Rplus.expHomeo`, the homeomorphism `ℝ ≃ₜ ℝ⋆₊`, and `Rplus.expMulEquiv`;
  - `Rplus.haar`, the Haar measure `d*ρ = dρ/ρ`, with proofs that it is left invariant,
    σ-finite and a Haar measure, the integration formula
    `∫ f(ρ) d*ρ = ∫ f(e^t) dt` and the inversion invariance `∫ f(ρ⁻¹) d*ρ = ∫ f(ρ) d*ρ`.

* `RequestProject/SineIntegral.lean`
  - `Si`, the sine integral, its oddness, differentiability and continuity;
  - `siDiv`, the normalized sine integral `a ↦ Si(a)/a` (extended by `1` at `0`), its
    integral representation, its continuity and its differentiability (including at `0`,
    where the derivative vanishes);
  - `integral_cos_mul_neg_log`: `∫₀¹ cos(a t)(-log t) dt = Si(a)/a`, the analytic
    identity behind formula (49) of the paper.

* `RequestProject/SiPositivity.lean`
  - `Si_pos`: the sine integral is strictly positive on `(0,∞)` (proved through the
    alternating half-arch decomposition `Si((k+1)π) - Si(kπ) = (-1)^k ∫₀^π sin u/(kπ+u) du`),
    together with `Si_nonneg` and `siDiv_pos`.

* `RequestProject/TraceRemainder.lean`
  - `delta`, the trace-remainder function `δ` of §2, defined by the integral formula (48)
    on `[1,∞)` and extended by the symmetry `δ(ρ) = δ(ρ⁻¹)`;
  - `delta_symmetric` (Proposition 2.2 (ii)), `delta_explicit` (formula (49)),
    `delta_one` (the constant term of the expansion (50)) and `delta_continuous`;
  - `delta_pos`: `δ(ρ) > 0` for every `ρ`, the positivity asserted in §2 of the paper as a
    consequence of the positivity of the sine integral;
  - `deltaReal_hasDerivWithinAt_Ici_one` and `deltaReal_hasDerivWithinAt_Iic_one`: the
    one-sided derivatives of `δ` at `ρ = 1` are `+1` and `-1`, so that `δ'` jumps by `2`
    there — the linear term of the expansion (50) and the source of the negativity
    statements of §4;
  - `D`, the functional `D(f) = ∫ f(ρ⁻¹) δ(ρ) d*ρ` of (9), and `D_eq`.

* `RequestProject/Sonin.lean`
  - `cutoff`, multiplication by the indicator function of a measurable set, as a bounded
    operator of `L²(ℝ)`, with proofs that it is an idempotent self-adjoint operator;
  - `P1` and `P1hat`, the cutoff projections in space and in frequency (the latter is the
    conjugate of the former by the `L²` Fourier transform);
  - `SoninSpace`, Sonin's space, with `mem_SoninSpace_iff` identifying it with the space
    of `ξ` such that `ξ` and its Fourier transform vanish a.e. on `[-1,1]`, and
    `SoninSpace_eq_orthogonal`, the identity `S = 1 - (P₁ ∨ P̂₁)` in the form
    `SoninSpace = (range P₁ ⊔ range P̂₁)ᗮ`;
  - `SoninProjection`, the orthogonal projection `S`, shown to be self-adjoint,
    idempotent and positive.

* `RequestProject/Scaling.lean`
  - `scaling`, the unitary scaling representation `ϑ` of `ℝ⋆₊`, realized as the regular
    representation on `L²(ℝ⋆₊, d*ρ)`, with the representation law `ϑ(ab) = ϑ(a)ϑ(b)`;
  - `logCoordinates`, the isometry onto `L²(ℝ, dt)` given by `ρ = e^t`.

* `RequestProject/WeilDistribution.lean`
  - `sharp`, the involution `f♯(x) = x⁻¹f(x⁻¹)`, and `sharp_sharp`;
  - `WeilR`, the archimedean Weil distribution of formula (150), and `Winfty = -WeilR`;
  - `WeilR_explicit`, the locally rational form of the distribution away from `ρ = 1`:
    for a test function vanishing at `1` (and with the resulting integrals absolutely
    convergent) `W_ℝ` is the integral of `f` against the rational weight `x/(x²-1)` on
    `(1,∞)` and `1/(1-x²)` on `(0,1)`, together with the change of variables `u = x⁻¹`
    `integral_Ioo_zero_one_eq_integral_Ioi_one` used to prove it;
  - `deltaHalfInv_starInvolution`, the compatibility of the `∆^{1/2}` normalization with
    the two involutions.

* `RequestProject/Mellin.lean`
  - `mellinMul` and `mellinLog`, the Fourier–Mellin transform of a test function on
    `ℝ⋆₊` in multiplicative and in logarithmic coordinates, and their agreement;
  - `Qlog`, the operator `Q = -(ρ∂_ρ)² + 1/4` in logarithmic coordinates, with
    `support_Qlog_subset` (it preserves the support), `mellinLog_Qlog`
    (`Q` multiplies the transform by `1/4 - z²`) and `mellinLog_Qlog_half` (the image of
    `Q` lies in the ideal of functions whose transform vanishes at `±i/2`);
  - `convLog` and `starLog`, the convolution product and the involution, with
    `convLog_comm`, `convLog_assoc` and `starLog_convLog` (the `*`-algebra laws),
    `mellinLog_convLog`, `mellinLog_starLog`, and the positive definiteness
    `mellinLog_convLog_starLog_self` (the transform of `f ∗ f*` is `|f̂|²`);
  - `mellinLog_Qlog_convLog_starLog`, i.e. `Q` preserves positive definiteness.

* `RequestProject/JumpFormula.lean`
  - `corner`, the function built from two smooth pieces glued at `t = 0`;
  - `integral_deriv2_mul_corner` and `integral_Qlog_mul_corner`, integration by parts
    against a function with a corner, the extra term being the jump of the derivative;
  - `integral_Qlog_convLog_starLog_mul_corner`, the elementary form of the essential
    negativity: pairing `Q(ξ ∗ ξ*)` with a corner function whose derivative jumps by `2`
    gives `-2‖ξ‖²` plus the pairing of `ξ ∗ ξ*` with the smooth kernel `Qg`.

* `RequestProject/SiSmooth.lean`
  - `contDiff_siDiv`, the smoothness of the normalized sine integral, obtained by
    differentiating under the integral sign in the representation of `siDiv`.

* `RequestProject/DeltaSmooth.lean`
  - `deltaPieceR`, `deltaPieceL`, the two smooth pieces of `δ` in the logarithmic
    coordinate, with `contDiff_deltaPieceR`/`contDiff_deltaPieceL`, `deltaPiece_jump`
    (the derivative jumps by `2` at `ρ = 1`) and `corner_deltaPiece`;
  - `essential_negativity_delta` and `essential_negativity_delta_haar`, the essential
    negativity identity `D(Q(ξ ∗ ξ*)) = -2‖ξ‖² + ⟨ξ ∗ ξ*, Qδ⟩` of §4 and §6.

* `RequestProject/RemainderBound.lean`
  - `norm_convLog_starLog_self_le`, the bound `‖(ξ ∗ ξ*)(t)‖ ≤ ‖ξ‖²`, and
    `convLog_starLog_self_eq_zero`, the support bound for `ξ ∗ ξ*`;
  - `essential_negativity_quantitative`: for test functions supported in a fixed compact
    subset of `ℝ⋆₊`, the remainder in the identity above is bounded by a constant
    multiple of `‖ξ‖²`, so `D ∘ Q` is `-2‖ξ‖²` up to a bounded term;
  - `essential_negativity_strict`: consequently there is an `a > 0` such that
    `Re D(Q(ξ ∗ ξ*)) ≤ -‖ξ‖²` for every test function supported in `|log ρ| ≤ a`.

## What is *not* formalized

The deep statements of the paper (the local trace formula, the essential negativity of
`E ∘ Q`, the prolate spheroidal expansion of the remainder `ε`, the Toeplitz argument of
§6, Theorem 1, Theorem 6.11 and Corollary 2) are *not* formalized: they are not stated
here even as `sorry`, because a faithful statement of any of them requires
infrastructure that neither Mathlib nor this project currently provides, namely

* the integrated representation `f ↦ ϑ(f) = ∫ f(λ) ϑ(λ) d*λ` of the convolution algebra
  (a strongly, but not norm, continuous integral);
* trace-class operators and the operator trace `Tr` on a Hilbert space;
* the Riemann–Siegel angular function `θ` and its derivative;
* prolate spheroidal wave functions and the associated differential operator;
* the spectral theory of a pair of projections, and the *compactness* (as opposed to the
  boundedness proved here) of the integral operators with the kernels `Qδ` of §3–§4;
* Toeplitz operators on `ℓ²(ℤ)` and their continuous analogues.

Stating those results with placeholder definitions would produce statements that do not
say what the paper says, so the honest record is the list above: the objects that could
be defined faithfully have been defined, and the results about them that could be proved
have been proved.

## The original skeleton

The informal skeleton that this project started from is reproduced verbatim below, inside
a comment (it is pseudo-Lean and does not elaborate).

/-
import Mathlib.Analysis.Fourier.FourierTransform
import Mathlib.Analysis.SpecialFunctions.Gaussian
import Mathlib.MeasureTheory.Integral.Bochner
import Mathlib.MeasureTheory.Group.Convolution
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Topology.ContinuousFunction.CompactlySupported
import Mathlib.Analysis.Distribution.SchwartzSpace

noncomputable section

open scoped Real InnerProductSpace
open MeasureTheory Filter Topology

namespace ConnesConsani.WeilPositivity

/-! ## 0. Basic multiplicative group and convolution algebra -/

/-- The multiplicative group \(\mathbb{R}_+^*\). -/
abbrev Rplus := {x : ℝ // 0 < x}

instance : CommGroup Rplus := by
  -- standard instance via `Units` or explicit construction
  sorry

/-- Haar measure \(d^*\rho = d\rho/\rho\). -/
def haar : Measure Rplus := sorry

instance : IsHaarMeasure haar := sorry
instance : SigmaFinite haar := sorry

/-- Smooth compactly supported functions on \(\mathbb{R}_+^*\). -/
def Cc∞ (U : Set Rplus := Set.univ) : Type :=
  {f : C(Rplus, ℂ) // HasCompactSupport f ∧ ContDiff ℝ ⊤ f ∧ support f ⊆ U}

instance : AddCommGroup (Cc∞ U) := sorry
instance : Module ℂ (Cc∞ U) := sorry

/-- Convolution product making \(C_c^\infty(\mathbb{R}_+^*)\) into a *-algebra. -/
def conv (f g : Cc∞) : Cc∞ := sorry

infixr:70 " ∗ " => conv

/-- Involution \(f^*(\rho) = \overline{f(\rho^{-1})}\). -/
def involution (f : Cc∞) : Cc∞ := sorry
postfix:max "^*" => involution

/-- The ideal of functions whose Fourier/Mellin transform vanishes at \(\pm i/2\). -/
def vanishingIdeal : Ideal (Cc∞) := sorry

/-! ## 1. Scaling representation and Sonin projection -/

/-- Hilbert space \(L^2(\mathbb{R})_{\mathrm{ev}}\) of even square-integrable functions. -/
def L2ev : Type :=
  {ξ : ℝ → ℂ // (∀ x, ξ (-x) = ξ x) ∧ Memℒp ξ 2 volume}
  -- better: closed subspace of L²(ℝ)

instance : NormedAddCommGroup L2ev := sorry
instance : InnerProductSpace ℂ L2ev := sorry
instance : CompleteSpace L2ev := sorry

/-- Unitary scaling representation \(\vartheta : \mathbb{R}_+^* \to U(L^2_{\mathrm{ev}})\). -/
def scaling (λ : Rplus) : L2ev ≃ₗᵢ[ℂ] L2ev := sorry

/-- Integrated form \(\vartheta(f) = \int f(\lambda)\,\vartheta(\lambda)\,d^*\lambda\). -/
def scalingOp (f : Cc∞) : L2ev →L[ℂ] L2ev := sorry

/-- Orthogonal projection onto the Sonin space
    (functions that, together with their Fourier transform, vanish on \([-1,1]\)). -/
def SoninProjection : L2ev →L[ℂ] L2ev := sorry

lemma SoninProjection_isProjection : IsProjection SoninProjection := sorry
lemma SoninProjection_selfAdjoint : IsSelfAdjoint SoninProjection := sorry

/-! ## 2. The Weil distribution at the archimedean place -/

/-- The distribution \(W_\infty\) (principal-value form of the local archimedean term). -/
def WeilDistribution (f : Cc∞) : ℂ := sorry

/-- Explicit formula for the distribution outside \(\{1\}\) (locally rational). -/
lemma WeilDistribution_explicit (f : Cc∞)
    (hf : 1 ∉ support f) :
    WeilDistribution f =
      ∫ ρ, f ρ * (ρ^{1/2} / |1 - ρ|) ∂haar := sorry

/-! ## 3. Geometric side – Schwartz kernels and the two squares Δ, Σ -/

/-- Schwartz kernel of an operator on \(L^2(\mathbb{R}_+^*)\). -/
def SchwartzKernel (T : (ℝ → ℂ) →L[ℂ] (ℝ → ℂ)) : Rplus → Rplus → ℂ := sorry

/-- The unitary \(u_\infty\) associated with the Fourier transform composed with inversion. -/
def u∞ : L2ev ≃ₗᵢ[ℂ] L2ev := sorry

/-- Quantized differential \(\overline{d}u_\infty\). -/
def quantizedDifferential : L2ev →L[ℂ] L2ev := sorry

/-- Geometric identity (local trace formula at ∞). -/
theorem geometric_trace_formula (f : Cc∞) :
    WeilDistribution f =
      (1/2 : ℂ) * Trace (scalingOp f * (u∞⁻¹ * quantizedDifferential)) := sorry

/-! ## 4. Trace-remainder δ(ρ) and the positive functional L -/

/-- The trace-remainder function δ(ρ). -/
def delta (ρ : Rplus) : ℝ := sorry

lemma delta_symmetric (ρ : Rplus) : delta ρ = delta (ρ⁻¹) := sorry

lemma delta_explicit (ρ : Rplus) (h : 1 ≤ ρ) :
    delta ρ = 2 * ρ^{1/2} *
      (Si (2 * π * (1 + ρ)) / (2 * π * (1 + ρ)) +
       Si (2 * π * (ρ - 1)) / (2 * π * (ρ - 1))) := sorry

/-- The positive functional \(L(f) = D(f) + W_\infty(f)\). -/
def L (f : Cc∞) : ℂ :=
  ∫ ρ, f (ρ⁻¹) * (delta ρ - WeilDistribution (dirac ρ)) ∂haar  -- schematic
  -- more precisely: L(f) := Tr(ϑ(f) P P̂ P)

theorem L_positive (f : Cc∞) (hf : ∃ g, f = g ∗ g^*) :
    0 ≤ (L f).re := sorry

/-! ## 5. Differential operator Q implementing the vanishing conditions -/

/-- The operator \(Q = -(\rho\partial_\rho)^2 + 1/4\). -/
def Q : Cc∞ → Cc∞ := sorry

lemma Q_preserves_support (f : Cc∞) (I : Set Rplus) :
    support f ⊆ I → support (Q f) ⊆ I := sorry

lemma Q_implements_vanishing (f : Cc∞) :
    Q f ∈ vanishingIdeal ↔ True := sorry   -- always lands in the ideal

lemma Q_and_positive_definiteness (f : Cc∞) :
    (∀ χ, 0 ≤ (f ∗ f^*).Fourier χ) ↔
    (∀ χ, 0 ≤ ((Q f) ∗ (Q f)^*).Fourier χ) := sorry

/-! ## 6. Essential negativity of D ∘ Q -/

/-- Compact operator arising from the jump of δ' at 1. -/
def K_I (I : Set Rplus) : (L2 (√I) haar) →L[ℂ] (L2 (√I) haar) := sorry

theorem essential_negativity (I : Set Rplus) (hI : IsCompact I) :
    ∃ K : (L2 (√I) haar) →L[ℂ] (L2 (√I) haar),
      IsCompactOperator K ∧
      ∀ ξ, D (Q (ξ ∗ ξ^*)) = -2 * ‖ξ‖^2 + ⟪ξ, K ξ⟫ := sorry

/-! ## 7. Moving Δ inside Σ via pairs of projections and prolate functions -/

/-- Cut-off projections \(P_1,\widehat{P}_1\). -/
def P1 : L2ev →L[ℂ] L2ev := sorry
def P1hat : L2ev →L[ℂ] L2ev := sorry

lemma P1_and_P1hat_relation :
    SoninProjection = 1 - (P1 ⊔ P1hat) := sorry

/-- Prolate spheroidal wave functions (eigenvectors of the prolate differential operator). -/
def prolate (n : ℕ) : L2ev := sorry

/-- Coefficient appearing in the expansion of the remainder ε(ρ). -/
def epsilon (ρ : Rplus) : ℝ := sorry

lemma epsilon_expansion (ρ : Rplus) (h : 1 ≤ ρ) :
    epsilon ρ =
      ∑' n, (λ n / √(1 - (λ n)^2)) * ⟪prolate n, scaling ρ⁻¹ (prolate n)⟫ := sorry

/-! ## 8. The refined decomposition W_∞ = S – E -/

/-- The positive Sonin trace functional. -/
def SoninTrace (f : Cc∞) : ℂ :=
  Trace (scalingOp f * SoninProjection)

theorem SoninTrace_positive (f : Cc∞) (hf : ∃ g, f = g ∗ g^*) :
    0 ≤ (SoninTrace f).re := sorry

/-- Remainder functional E. -/
def E (f : Cc∞) : ℂ := sorry

theorem refined_decomposition (f : Cc∞) :
    WeilDistribution f = SoninTrace f - E f := sorry

/-! ## 9. Essential negativity of E ∘ Q on the interval [1/2,2] -/

/-- The critical compact operator on L²([2^{-1/2},2^{1/2}]). -/
def K_half : (L2 ({ρ // 2⁻¹ ≤ ρ ∧ ρ ≤ 2}) haar) →L[ℂ] _ := sorry

theorem spectrum_of_K_half :
    ∃ (λ_max : ℝ) (v : _),
      λ_max > 1 ∧
      IsEigenvalue K_half λ_max v ∧
      (∀ μ ∈ spectrum K_half, μ ≠ λ_max → μ ≤ 1) := sorry

/-- After conditioning on the single dangerous eigenvector one obtains strict negativity. -/
theorem conditioned_negativity :
    ∃ (c : ℝ) (h : 13 < c ∧ c < 17),
      ∀ g : Cc∞,
        support g ⊆ {ρ // 2⁻¹ ≤ ρ ∧ ρ ≤ 2} →
        (Q g).Fourier (I/2) = 0 →
        WeilDistribution (g ∗ g^*) ≥
          SoninTrace (g ∗ g^*) - c * |g.Fourier 0|^2 := sorry

/-! ## 10. Main theorems -/

/-- Theorem 1 of the paper (support in [2^{-1/2},2^{1/2}], vanishing at i/2 and 0). -/
theorem main_positivity
    (g : Cc∞)
    (hsupp : support g ⊆ {ρ // 2⁻¹ ≤ ρ ∧ ρ ≤ 2})
    (hvan : g.Fourier (I/2) = 0 ∧ g.Fourier 0 = 0) :
    WeilDistribution (g ∗ g^*) ≥ SoninTrace (g ∗ g^*) := by
  sorry

/-- Stronger quantitative form (Theorem 6.11). -/
theorem main_positivity_quantitative
    (g : Cc∞)
    (hsupp : support g ⊆ {ρ // 2⁻¹ ≤ ρ ∧ ρ ≤ 2})
    (hvan : g.Fourier (I/2) = 0) :
    ∃ (c : ℝ), 13 < c ∧ c < 17 ∧
      WeilDistribution (g ∗ g^*) ≥
        SoninTrace (g ∗ g^*) - c * |g.Fourier 0|^2 := by
  sorry

/-- Corollary relating the inequality to the zeros of ζ. -/
theorem corollary_zeros
    (g : Cc∞)
    (hsupp : support g ⊆ {ρ // 2⁻¹ ≤ ρ ∧ ρ ≤ 2})
    (hvan : g.Fourier (I/2) = 0) :
    ∃ (c : ℝ), 13 < c ∧ c < 17 ∧
      c * |g.Fourier 0|^2 +
        ∑' ρ : nontrivialZeros,
          g.Fourier (ρ - 1/2) * (starRingEnd ℂ (g.Fourier (ρ - 1/2))) ≥
      SoninTrace (g ∗ g^*) := by
  sorry

end ConnesConsani.WeilPositivity
-/
-/
