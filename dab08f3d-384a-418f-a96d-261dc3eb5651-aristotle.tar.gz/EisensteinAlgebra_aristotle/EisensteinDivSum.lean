import Mathlib
import EisensteinIntegers
import EisensteinOrbit
import EisensteinEuclidean
import EisensteinAlgebra
import EisensteinUnits
import EisensteinThetaBridge
import EisensteinTheta
import EisensteinPrimeSplit
import EisensteinPrimeSplitHard

/-!
# idealCount equals divSum
-/

noncomputable section

open scoped Classical

namespace Eisenstein

open EisensteinTheta

def iCount (n : ℕ) : ℕ :=
  (Ideal.finite_setOf_absNorm_eq (S := Eisenstein) n).toFinset.card

theorem chi3_mul' (m n : ℕ) : chi3 (m * n) = chi3 m * chi3 n :=
  chi3_mul m n

theorem divSum_multiplicative (m n : ℕ) (hm : 0 < m) (hn : 0 < n)
    (hcop : Nat.Coprime m n) :
    divSum (m * n) = divSum m * divSum n := by
  unfold divSum;
  -- Apply the bijection between the divisors of mn and the pairs (d1, d2) to rewrite the sum.
  have h_bij : (m * n).divisors = Finset.image (fun (p : ℕ × ℕ) => p.1 * p.2) (m.divisors ×ˢ n.divisors) := by
    exact Nat.divisors_mul _ _;
  rw [ h_bij, Finset.sum_image, Finset.sum_product ];
  · simp +decide only [chi3_mul', Finset.sum_mul_sum];
  · intros p hp q hq h_eq; simp_all +decide [ Nat.coprime_iff_gcd_eq_one ] ;
    -- Since $p.1 \mid m$ and $q.1 \mid m$, and $\gcd(m, n) = 1$, it follows that $p.1 = q.1$.
    have hp1_eq_q1 : p.1 = q.1 := by
      exact Nat.dvd_antisymm ( by exact Nat.Coprime.dvd_of_dvd_mul_right ( Nat.Coprime.coprime_dvd_left hp.1.1 <| Nat.Coprime.coprime_dvd_right hq.2 hcop ) <| h_eq.symm ▸ dvd_mul_right _ _ ) ( by exact Nat.Coprime.dvd_of_dvd_mul_right ( Nat.Coprime.coprime_dvd_left hq.1 <| Nat.Coprime.coprime_dvd_right hp.2.1 hcop ) <| h_eq.symm ▸ dvd_mul_right _ _ );
    aesop

theorem divSum_prime_pow (p k : ℕ) (hp : Nat.Prime p) :
    divSum (p ^ k) = ∑ i ∈ Finset.range (k + 1), chi3 p ^ i := by
  unfold divSum; simp +decide [ Nat.divisors_prime_pow hp ] ;
  refine' Finset.sum_congr rfl fun i hi => _;
  induction i <;> simp_all +decide [ pow_succ' ];
  rw [ ← ‹ ( _ : ℕ ) ≤ k → chi3 ( p ^ _ ) = chi3 p ^ _ › ( Nat.le_of_lt hi ), chi3_mul' ]

theorem iCount_one : iCount 1 = 1 := by
  refine' Finset.card_eq_one.mpr _;
  use ⊤; ext; aesop;

/-- No element of Eisenstein has norm ≡ 2 mod 3. -/
theorem no_norm_two_mod_three (n : ℕ) (hn : n % 3 = 2) :
    ∀ z : Eisenstein, Eisenstein.norm z ≠ (n : ℤ) :=
  EisensteinPrimeSplit.no_norm_eq_of_two_mod_three_nat n hn

/-- For p ≡ 2 mod 3 and k odd, p^k ≡ 2 mod 3. -/
theorem pow_mod_three_of_inert (p k : ℕ) (hmod : p % 3 = 2) (hk : Odd k) :
    (p ^ k) % 3 = 2 := by
  obtain ⟨j, rfl⟩ := hk
  rw [Nat.pow_mod]; simp [hmod]
  induction j with
  | zero => norm_num
  | succ j ih =>
    rw [show 2 * (j + 1) + 1 = (2 * j + 1) + 2 from by ring, pow_add]
    simp [Nat.mul_mod, ih]

/-
If no element has a given norm, then iCount is 0.
-/
theorem iCount_zero_of_no_norm (n : ℕ) (h : ∀ z : Eisenstein, Eisenstein.norm z ≠ (n : ℤ)) :
    iCount n = 0 := by
  -- If no element has norm n, then no ideal has absNorm n (since in a PID every ideal is principal, I = span{z}, and absNorm(span{z}) = (norm z).natAbs).
  have h_no_ideal : ∀ I : Ideal Eisenstein, I.absNorm = n → False := by
    intro I hI
    obtain ⟨z, hz⟩ : ∃ z : Eisenstein, I = Ideal.span {z} := by
      exact?;
    grind +suggestions;
  unfold iCount; aesop;

/-
iCount = 1 when there is a unique ideal of given absNorm.
-/
theorem iCount_eq_one_of_unique_ideal (n : ℕ) (I₀ : Ideal Eisenstein)
    (hI₀ : Ideal.absNorm I₀ = n)
    (huniq : ∀ I : Ideal Eisenstein, Ideal.absNorm I = n → I = I₀) :
    iCount n = 1 := by
  exact Finset.card_eq_one.mpr ⟨ I₀, by aesop ⟩

theorem iCount_multiplicative (m n : ℕ) (hm : 1 < m) (hn : 1 < n)
    (hcop : Nat.Coprime m n) :
    iCount (m * n) = iCount m * iCount n := by
  sorry

/-
θ divides z whenever 3 divides norm z.
-/
theorem theta_dvd_of_three_dvd_norm (z : Eisenstein) (h : (3 : ℤ) ∣ Eisenstein.norm z) :
    ∃ w : Eisenstein, z = θ * w := by
  -- Since $3 \mid � z�.norm$, we have that $z.a + z.b \equiv 0 \pmod{3}$.
  have h_mod : (z.a + z.b) % 3 = 0 := by
    unfold Eisenstein.norm at h;
    rw [ Int.dvd_iff_emod_eq_zero ] at *; norm_num [ Int.add_emod, Int.sub_emod, Int.mul_emod, sq ] at *; have := Int.emod_nonneg z.a three_pos.ne'; have := Int.emod_nonneg z.b three_pos.ne'; have := Int.emod_lt_of_pos z.a three_pos; have := Int.emod_lt_of_pos z.b three_pos; interval_cases z.a % 3 <;> interval_cases z.b % 3 <;> trivial;
  -- Let $w = \frac{2z.a - z.b}{3} + \frac{z.a + z.b}{3} \theta$.
  use ⟨(2 * z.a - z.b) / 3, (z.a + z.b) / 3⟩;
  ext <;> norm_num [ ]; all_goals omega

/-
Every element of norm 3^k is an associate of θ^k.
-/
theorem norm_three_pow_associate (k : ℕ) (z : Eisenstein) (hz : Eisenstein.norm z = (3 : ℤ) ^ k) :
    Associated z (θ ^ k) := by
  induction' k with k ih generalizing z;
  · simp +zetaDelta at *;
    exact?;
  · -- If norm z = 3^( �k�+1), then 3 | norm � z�, so by theta_dvd_of_three_dvd_norm, z = θ * w for some w.
    obtain ⟨w, hw⟩ : ∃ w : Eisenstein, z = θ * w := by
      apply theta_dvd_of_three_dvd_norm;
      grind;
    rw [ hw, pow_succ' ];
    -- By the induction hypothesis, since norm w = 3^k, we have that w is associated to θ^k.
    have h_ind : Associated w (θ ^ k) := by
      grind +suggestions;
    exact?

/-
The Eisenstein integer ⟨p, 0⟩ is irreducible when p is an inert prime (p ≡ 2 mod 3).
-/
theorem irreducible_int_of_inert (p : ℕ) (hp : Nat.Prime p) (hmod : p % 3 = 2) :
    Irreducible (⟨(p : ℤ), 0⟩ : Eisenstein) := by
  constructor;
  · rw [ isUnit_iff_exists_inv ];
    rintro ⟨ b, hb ⟩ ; have := congr_arg ( fun z : Eisenstein => z.a ) hb ; norm_num at this ; have := congr_arg ( fun z : Eisenstein => z.b ) hb ; norm_num at this ; nlinarith [ hp.two_le, show b.a = 0 by nlinarith [ hp.two_le ] ] ;
  · intro a b hab
    have h_norm : norm a * norm b = p ^ 2 := by
      convert congr_arg Eisenstein.norm hab.symm using 1 ; norm_num [ Eisenstein.norm ] ; ring
    have h_cases : norm a = 1 ∨ norm b = 1 := by
      -- Since $p$ is prime �,� the only divisors of $p^ �2�$ are $1$, $p$, and $p^2$.
      have h_divisors : ∀ {d : ℤ}, d ∣ p^2 → d = 1 ∨ d = -1 ∨ d = p ∨ d = -p ∨ d = p^2 ∨ d = -p^2 := by
        intro d hd; have := Int.natAbs_dvd_natAbs.mpr hd; simp_all +decide [ Int.natAbs_pow, Nat.dvd_prime_pow ] ;
        rcases this with ⟨ k, hk₁, hk₂ ⟩ ; interval_cases k <;> simp_all +decide [ Int.natAbs_eq_iff ] ;
        · tauto;
        · grind;
      obtain ha | ha | ha | ha | ha | ha := @h_divisors _ ( dvd_of_mul_right_eq _ h_norm ) <;> obtain hb | hb | hb | hb | hb | hb := @h_divisors _ ( dvd_of_mul_left_eq _ h_norm ) <;> simp_all +decide only ;
      any_goals nlinarith [ hp.two_le, pow_pos hp.pos 3 ];
      grind +splitImp;
      · exact absurd ha ( by linarith [ Eisenstein.norm_nonneg a ] );
      · exact absurd ( no_norm_two_mod_three p hmod a ) ( by aesop );
      · linarith [ hp.two_le, Eisenstein.norm_nonneg a, Eisenstein.norm_nonneg b ];
      · grind +suggestions;
      · exact absurd ha ( by nlinarith [ hp.two_le, show 0 ≤ a.norm from Eisenstein.norm_nonneg a ] )
    have h_unit : IsUnit a ∨ IsUnit b := by
      exact Or.imp ( fun h => Eisenstein.isUnit_of_norm_one a h ) ( fun h => Eisenstein.isUnit_of_norm_one b h ) h_cases
    exact h_unit

/-
Every element of norm p^(2j) (p inert) is an associate of ⟨p^j, 0⟩.
-/
theorem norm_inert_pow_associate (p j : ℕ) (hp : Nat.Prime p) (hmod : p % 3 = 2)
    (z : Eisenstein) (hz : Eisenstein.norm z = ((p : ℤ) ^ j) ^ 2) :
    Associated z ⟨(p : ℤ) ^ j, 0⟩ := by
  revert z;
  -- By definition of irreducibility, if p divides z, then z is an associate of p.
  have h_irred_div : ∀ z : Eisenstein, (p : ℤ) ∣ Eisenstein.norm z → (⟨p, 0⟩ : Eisenstein) ∣ z := by
    intro z hz
    have h_div : (⟨p, 0⟩ : Eisenstein) ∣ z * Eisenstein.conj z := by
      obtain ⟨ k, hk ⟩ := hz;
      use ⟨k, 0⟩;
      ext <;> simp +decide [ *, mul_comm ];
      · convert hk using 1 ; ring!;
        · exact Eq.symm ( by unfold Eisenstein.norm; ring );
        · ring;
      · ring;
    have h_irred : Irreducible (⟨p, 0⟩ : Eisenstein) := by
      convert irreducible_int_of_inert p hp hmod using 1;
    have h_prime : Prime (⟨p, 0⟩ : Eisenstein) := by
      rwa [ ← UniqueFactorizationMonoid.irreducible_iff_prime ];
    have h_div_z : (⟨p, 0⟩ : Eisenstein) ∣ z ∨ (⟨p, 0⟩ : Eisenstein) ∣ Eisenstein.conj z := by
      exact h_prime.dvd_or_dvd h_div;
    have h_div_conj : ∀ z : Eisenstein, (⟨p, 0⟩ : Eisenstein) ∣ Eisenstein.conj z → (⟨p, 0⟩ : Eisenstein) ∣ z := by
      intros z h_div_conj
      obtain ⟨w, hw⟩ := h_div_conj
      use Eisenstein.conj w;
      convert congr_arg Eisenstein.conj hw using 1 <;> simp +decide [ Eisenstein.conj ];
      ext <;> simp +decide [ mul_sub ];
    exact h_div_z.elim id fun h => h_div_conj z h;
  intro z hz
  induction' j with j ih generalizing z;
  · have h_unit : IsUnit z := by
      exact Eisenstein.isUnit_of_norm_one z hz;
    obtain ⟨ u, hu ⟩ := h_unit.exists_left_inv;
    use Units.mkOfMulEqOne u z hu;
    convert mul_comm z u using 1;
    exact hu.symm;
  · -- By definition of irreducibility, if � p� divides z, then z is an associate of p. Hence, we can write z as p times some element w.
    obtain ⟨w, hw⟩ : ∃ w : Eisenstein, z = ⟨p, 0⟩ * w := by
      exact h_irred_div z ( hz.symm ▸ dvd_pow ( dvd_pow_self _ ( Nat.succ_ne_zero _ ) ) two_ne_zero );
    have hw_norm : w.norm = (p ^ j) ^ 2 := by
      have := Eisenstein.norm_mul ⟨ p, 0 ⟩ w; simp_all +decide [ pow_succ, mul_assoc ] ;
      simp_all +decide [ Eisenstein.norm ];
      exact mul_left_cancel₀ ( pow_ne_zero 2 ( Nat.cast_ne_zero.mpr hp.ne_zero ) ) ( by linarith );
    obtain ⟨ u, hu ⟩ := ih w hw_norm;
    use u;
    simp_all +decide [ pow_succ', mul_assoc ];
    ext <;> simp +decide [ mul_assoc, pow_succ' ]

theorem iCount_prime_pow_split (p k : ℕ) (hp : Nat.Prime p) (hmod : p % 3 = 1) :
    iCount (p ^ k) = k + 1 := by
  sorry

theorem iCount_prime_pow_inert (p k : ℕ) (hp : Nat.Prime p) (hmod : p % 3 = 2) :
    iCount (p ^ k) = if Even k then 1 else 0 := by
  split_ifs with h_even;
  · obtain ⟨ j, rfl ⟩ := even_iff_two_dvd.mp h_even;
    have h_unique : ∀ I : Ideal Eisenstein, Ideal.absNorm I = p ^ (2 * j) → I = Ideal.span {⟨(p :) ^ j, 0⟩} := by
      intro I hI
      obtain ⟨z, hz⟩ : ∃ z : Eisenstein, I = Ideal.span {z} := by
        exact ⟨ _, Eq.symm <| Ideal.span_singleton_generator _ ⟩;
      have h_norm : Eisenstein.norm z = (p ^ j :) ^ 2 := by
        have h_norm : Ideal.absNorm (Ideal.span {z}) = (Eisenstein.norm z).natAbs := by
          convert Eisenstein.absNorm_span_singleton z;
        rw [ ← Int.natAbs_of_nonneg ( Eisenstein.norm_nonneg z ) ] ; simp_all +decide [ pow_mul' ];
      have h_associated : Associated z ⟨(p :) ^ j, 0⟩ := by
        convert norm_inert_pow_associate p j hp hmod z _;
        aesop;
      obtain ⟨ u, hu ⟩ := h_associated;
      rw [ ← hu, hz, Ideal.span_singleton_mul_right_unit ] ; aesop;
    convert iCount_eq_one_of_unique_ideal ( p ^ ( 2 * j ) ) ( Ideal.span { ⟨ ( p : ℤ ) ^ j, 0 ⟩ } ) _ _ <;> norm_num;
    · erw [ algebraNorm_eq_norm ] ; norm_num [ pow_mul', norm ];
    · assumption;
  · apply iCount_zero_of_no_norm;
    convert no_norm_two_mod_three ( p ^ k ) _ using 1;
    rw [ ← Nat.mod_add_div k 2 ] ; norm_num [ Nat.pow_add, Nat.pow_mul, Nat.odd_iff.mp ( Nat.odd_iff.mpr ( Nat.mod_two_ne_zero.mp fun h => h_even <| even_iff_two_dvd.mpr <| Nat.dvd_of_mod_eq_zero h ) ), Nat.mul_mod, Nat.pow_mod, hmod ] ;

theorem iCount_prime_pow_ramified (k : ℕ) :
    iCount (3 ^ k) = 1 := by
  refine' iCount_eq_one_of_unique_ideal ( 3 ^ k ) ( Ideal.span { θ ^ k } ) _ _ <;> norm_num [ Ideal.absNorm_span_singleton ];
  · exact congr_arg ( · ^ k ) ( by rw [ algebraNorm_eq_norm ] ; exact by rw [ norm_θ ] ; rfl );
  · intro I hI
    obtain ⟨z, hz⟩ : ∃ z : Eisenstein, I = Ideal.span {z} := by
      have h_principal : ∀ I : Ideal Eisenstein, I.IsPrincipal := by
        grind +suggestions;
      obtain ⟨ z, hz ⟩ := h_principal I; use z; aesop;
    have hz_norm : Eisenstein.norm z = (3 : ℤ) ^ k := by
      have hz_norm : (Eisenstein.norm z).natAbs = 3 ^ k := by
        rw [ ← hI, hz, absNorm_span_singleton ];
      rw [ ← Int.natAbs_of_nonneg ( norm_nonneg z ), hz_norm ] ; norm_cast
    have hz_associate : Associated z (θ ^ k) := by
      convert norm_three_pow_associate k z hz_norm using 1
    exact (by
    rw [ hz, Ideal.span_singleton_eq_span_singleton ];
    exact hz_associate)

theorem iCount_eq_divSum_prime_pow_split (p k : ℕ) (hp : Nat.Prime p) (hmod : p % 3 = 1) :
    (iCount (p ^ k) : ℤ) = divSum (p ^ k) := by
  rw [iCount_prime_pow_split p k hp hmod, divSum_prime_pow p k hp]
  have hchi : chi3 p = 1 := by simp [chi3, hmod]
  simp [hchi]

theorem iCount_eq_divSum_prime_pow_inert (p k : ℕ) (hp : Nat.Prime p) (hmod : p % 3 = 2) :
    (iCount (p ^ k) : ℤ) = divSum (p ^ k) := by
  have hchi3_p : chi3 p = -1 := by
    unfold chi3; aesop;
  rw [ iCount_prime_pow_inert p k hp hmod, divSum_prime_pow p k hp ];
  split_ifs <;> simp_all +decide [ Nat.even_add_one ]

theorem iCount_eq_divSum_prime_pow_ramified (k : ℕ) :
    (iCount (3 ^ k) : ℤ) = divSum (3 ^ k) := by
  rw [iCount_prime_pow_ramified k, divSum_prime_pow 3 k (by norm_num)]
  simp [chi3]

theorem iCount_eq_divSum_prime_pow (p k : ℕ) (hp : Nat.Prime p) :
    (iCount (p ^ k) : ℤ) = divSum (p ^ k) := by
  have hp3 : p % 3 = 0 ∨ p % 3 = 1 ∨ p % 3 = 2 := by omega
  rcases hp3 with h0 | h1 | h2
  · have hp3 : p = 3 := by
      have h3 : 3 ∣ p := Nat.dvd_of_mod_eq_zero h0
      rcases hp.eq_one_or_self_of_dvd 3 h3 with h | h
      · exact absurd h (by omega)
      · exact h.symm
    rw [hp3]; exact iCount_eq_divSum_prime_pow_ramified k
  · exact iCount_eq_divSum_prime_pow_split p k hp h1
  · exact iCount_eq_divSum_prime_pow_inert p k hp h2

theorem iCount_eq_divSum (n : ℕ) (hn : 0 < n) :
    (iCount n : ℤ) = divSum n := by
  have h_mul : ∀ {m n : ℕ}, 0 < m → 0 < n → Nat.Coprime m n → iCount (m * n) = iCount m * iCount n ∧ divSum (m * n) = divSum m * divSum n := by
    intros m n hm hn hcop
    constructor;
    · by_cases hm1 : m = 1;
      · have := iCount_one; aesop;
      · by_cases hn1 : n = 1;
        · simp +decide [ hn1, iCount_one ];
        · exact iCount_multiplicative m n ( lt_of_le_of_ne hm ( Ne.symm hm1 ) ) ( lt_of_le_of_ne hn ( Ne.symm hn1 ) ) hcop;
    · convert divSum_multiplicative m n hm hn hcop using 1;
  -- By induction on the prime factors of $n$, we can show that $iCount(n) = divSum(n)$ for any $n$.
  have h_ind : ∀ {S : Finset ℕ} (f : ℕ → ℕ), (∀ p ∈ S, Nat.Prime p) → (∀ p ∈ S, ∀ k : ℕ, iCount (p ^ k) = divSum (p ^ k)) → iCount (∏ p ∈ S, p ^ f p) = divSum (∏ p ∈ S, p ^ f p) := by
    intro S f hf_prime hf_eq
    induction' S using Finset.induction with p S hpS ih;
    · norm_num [ iCount_one, divSum_one ];
    · rw [ Finset.prod_insert hpS, h_mul ( pow_pos ( Nat.Prime.pos ( hf_prime p ( Finset.mem_insert_self p S ) ) ) _ ) ( Finset.prod_pos fun q hq => pow_pos ( Nat.Prime.pos ( hf_prime q ( Finset.mem_insert_of_mem hq ) ) ) _ ) ( Nat.Coprime.prod_right fun q hq => Nat.Coprime.pow _ _ <| hf_prime p ( Finset.mem_insert_self p S ) |> Nat.Prime.coprime_iff_not_dvd |>.2 <| fun h => hpS <| by have := Nat.prime_dvd_prime_iff_eq ( hf_prime p ( Finset.mem_insert_self p S ) ) ( hf_prime q ( Finset.mem_insert_of_mem hq ) ) ; aesop ) |>.1, h_mul ( pow_pos ( Nat.Prime.pos ( hf_prime p ( Finset.mem_insert_self p S ) ) ) _ ) ( Finset.prod_pos fun q hq => pow_pos ( Nat.Prime.pos ( hf_prime q ( Finset.mem_insert_of_mem hq ) ) ) _ ) ( Nat.Coprime.prod_right fun q hq => Nat.Coprime.pow _ _ <| hf_prime p ( Finset.mem_insert_self p S ) |> Nat.Prime.coprime_iff_not_dvd |>.2 <| fun h => hpS <| by have := Nat.prime_dvd_prime_iff_eq ( hf_prime p ( Finset.mem_insert_self p S ) ) ( hf_prime q ( Finset.mem_insert_of_mem hq ) ) ; aesop ) |>.2 ] ; norm_cast at * ; aesop;
  convert h_ind ( fun p => Nat.factorization n p ) ( fun p hp => Nat.prime_of_mem_primeFactors hp ) ( fun p hp k => iCount_eq_divSum_prime_pow p k ( Nat.prime_of_mem_primeFactors hp ) ) using 1;
  any_goals exact n;
  · exact congr_arg _ ( congr_arg _ ( Eq.symm <| Nat.factorization_prod_pow_eq_self hn.ne' ) );
  · exact congr_arg _ ( Eq.symm <| Nat.factorization_prod_pow_eq_self hn.ne' )

end Eisenstein