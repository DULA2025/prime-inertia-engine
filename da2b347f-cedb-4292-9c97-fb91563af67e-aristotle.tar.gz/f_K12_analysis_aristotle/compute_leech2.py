#!/usr/bin/env python3
"""
Part 2: Compute LDL^T factorization and output Lean code.
"""
from fractions import Fraction as Fr
import copy

# The Gram matrix from Part 1
G = [
  [6, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5],
  [3, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 1, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2],
  [3, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 3, 1, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 2],
  [3, 2, 2, 4, 2, 2, 2, 2, 2, 2, 2, 3, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 2],
  [3, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 3, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 2, 2],
  [3, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 3, 2, 1, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2],
  [3, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 3, 1, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2],
  [3, 2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 3, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 1, 2],
  [3, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2, 3, 1, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2],
  [3, 2, 2, 2, 2, 2, 2, 2, 2, 4, 2, 3, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 2],
  [3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 3, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 2, 2],
  [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
  [3, 2, 1, 2, 2, 2, 1, 1, 1, 2, 1, 1, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4],
  [3, 1, 2, 2, 2, 1, 1, 1, 2, 1, 2, 1, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4],
  [3, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 2, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 4],
  [3, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 1, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 2, 4],
  [3, 2, 1, 1, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 4],
  [3, 1, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 4],
  [3, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 4],
  [3, 1, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 4],
  [3, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2, 4],
  [3, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 2, 4],
  [3, 2, 2, 1, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4],
  [5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8],
]

n = 24

# =====================================================================
# LDL^T factorization over rationals
# =====================================================================
# G = L D L^T where L is lower-triangular with 1s on diagonal, D is diagonal
# Then G = L D L^T iff G = (L D^{1/2}) (L D^{1/2})^T = U^T D U where U = L^T (upper triangular)
# We want: cden * G = Umat^T * diag(dvec) * Umat where Umat, dvec, cden are integer.

# Compute rational LDL^T
GF = [[Fr(G[i][j]) for j in range(n)] for i in range(n)]
L = [[Fr(0)]*n for _ in range(n)]
D = [Fr(0)]*n

for i in range(n):
    # D[i] = G[i][i] - sum_j L[i][j]^2 * D[j]
    D[i] = GF[i][i]
    for j in range(i):
        D[i] -= L[i][j]**2 * D[j]
    
    L[i][i] = Fr(1)
    
    for k in range(i+1, n):
        # L[k][i] = (G[k][i] - sum_j L[k][j]*L[i][j]*D[j]) / D[i]
        val = GF[k][i]
        for j in range(i):
            val -= L[k][j] * L[i][j] * D[j]
        L[k][i] = val / D[i]

print("Diagonal D of LDL^T:")
for i in range(n):
    print(f"  D[{i}] = {D[i]}")

# Verify
def mat_mul_frac(A, B):
    n = len(A)
    m = len(B[0])
    k = len(B)
    return [[sum(A[i][l]*B[l][j] for l in range(k)) for j in range(m)] for i in range(n)]

def transpose_frac(M):
    n = len(M)
    m = len(M[0])
    return [[M[i][j] for i in range(n)] for j in range(m)]

D_mat = [[Fr(0)]*n for _ in range(n)]
for i in range(n):
    D_mat[i][i] = D[i]

LT = transpose_frac(L)
LDLt = mat_mul_frac(mat_mul_frac(L, D_mat), LT)
assert all(LDLt[i][j] == GF[i][j] for i in range(n) for j in range(n)), "LDL^T verification failed!"
print("\nLDL^T factorization verified ✓")

# =====================================================================
# Clear denominators to get integer matrices
# =====================================================================
# We want: cden * G = U^T * diag(dvec) * U
# where U = L^T scaled appropriately.
# L^T is upper triangular with 1s on diagonal.
# G = L * D * L^T
# cden * G = cden * L * D * L^T = (L * sqrt(cden))^T won't work...
# Actually: G = L D L^T. Let's clear denominators from L.
# L has entries L[i][j] which are rationals. Let c be the LCM of all denominators in L.
# Then c*L is integer. c*G = c*L * D * (c*L)^T / c = (c*L) * (D/c) * (c*L)^T.
# Hmm, this gives cden*G = (cL)^T * (D/c) * (cL). Not integer in general.

# Better approach: L * D * L^T = G.
# Let U = L^T (upper triangular, 1s on diagonal, rational entries).
# G = U^T * D * U.
# Clear denominators of U: let c = lcm of denominators of all U entries.
# c*U is integer. c² * G = (cU)^T * D * (cU). Hmm, we want cden*G = Umat^T * diag(dvec) * Umat.
# So cden = c², Umat = c*U, dvec = D. But D may be non-integer.

# Actually: G = U^T diag(D) U where U = L^T.
# Multiply both sides by c²: c²G = (cU)^T diag(D) (cU).
# This gives cden = c², Umat = cU, dvec = D.
# For dvec to be integer, D must be integer. D is rational, so we need extra clearing.

# General approach: 
# G = U^T diag(D) U
# Let c = lcm of all denominators in U and D.
# Then: c² G = (cU)^T * c² diag(D/c²) ... no.

# Let me think differently. We need integer Umat, dvec, cden with:
# cden * G = Umat^T * diag(dvec) * Umat
#
# From G = L D L^T = U^T D U (U = L^T):
# Let c1 = lcm of denominators of U entries.
# Let c2 = lcm of denominators of D entries.
# Then: (c1² * c2) * G = (c1*U)^T * (c2*diag(D)) * (c1*U)
# So: cden = c1² * c2, Umat = c1*U, dvec_i = c2*D[i].

from math import gcd
def lcm(a, b):
    return a * b // gcd(a, b)

def lcm_list(lst):
    result = 1
    for x in lst:
        result = lcm(result, x)
    return result

# Collect all denominators from U = L^T
U = transpose_frac(L)  # U[i][j] = L[j][i]
u_denoms = []
for i in range(n):
    for j in range(n):
        u_denoms.append(U[i][j].denominator)
c1 = lcm_list(u_denoms)
print(f"\nc1 (LCM of U denominators) = {c1}")

d_denoms = [D[i].denominator for i in range(n)]
c2 = lcm_list(d_denoms)
print(f"c2 (LCM of D denominators) = {c2}")

cden = c1 * c1 * c2
print(f"cden = c1² * c2 = {cden}")

Umat = [[int(c1 * U[i][j]) for j in range(n)] for i in range(n)]
dvec = [int(c2 * D[i]) for i in range(n)]

print(f"\ndvec = {dvec}")
print(f"All dvec > 0: {all(d > 0 for d in dvec)}")

# Verify: cden * G = Umat^T * diag(dvec) * Umat
def verify_factor(cden, G, Umat, dvec, n):
    for i in range(n):
        for j in range(n):
            lhs = cden * G[i][j]
            rhs = sum(Umat[k][i] * dvec[k] * Umat[k][j] for k in range(n))
            if lhs != rhs:
                print(f"  MISMATCH at [{i}][{j}]: lhs={lhs}, rhs={rhs}")
                return False
    return True

ok = verify_factor(cden, G, Umat, dvec, n)
print(f"Factorization verified: {ok}")

if not ok:
    import sys; sys.exit(1)

# =====================================================================
# Output Lean code
# =====================================================================
def lean_matrix(name, mat, n):
    lines = [f"def {name} : Matrix (Fin {n}) (Fin {n}) ℤ :="]
    lines.append("  !![")
    for i in range(n):
        row_str = ", ".join(str(x) for x in mat[i])
        if i < n-1:
            lines.append(f"    {row_str};")
        else:
            lines.append(f"    {row_str}")
    lines.append("  ]")
    return "\n".join(lines)

def lean_vec(name, vec, n):
    lines = [f"def {name} : Fin {n} → ℤ :="]
    lines.append(f"  ![{', '.join(str(x) for x in vec)}]")
    return "\n".join(lines)

print("\n" + "="*60)
print("LEAN CODE")
print("="*60)

print(lean_matrix("gram", G, n))
print()
print(lean_matrix("Umat", Umat, n))
print()
print(lean_vec("dvec", dvec, n))
print()
print(f"def cden : ℤ := {cden}")
print()

# Also print some facts for verification
print(f"\n-- Verification data:")
print(f"-- det(G) = {Fr(1)}")
print(f"-- cden = {cden}")
print(f"-- All dvec entries positive: {all(d > 0 for d in dvec)}")

# Compute det(Umat)
def det_int(mat):
    n = len(mat)
    M = [[Fr(mat[i][j]) for j in range(n)] for i in range(n)]
    sign = 1
    for col in range(n):
        pivot = -1
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot == -1:
            return Fr(0)
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
            sign *= -1
        for r in range(col+1, n):
            if M[r][col] != 0:
                f = M[r][col] / M[col][col]
                for j in range(col, n):
                    M[r][j] -= f * M[col][j]
    d = Fr(sign)
    for i in range(n):
        d *= M[i][i]
    return d

det_U = det_int(Umat)
print(f"-- det(Umat) = {det_U}")
print(f"-- det(Umat)^2 * prod(dvec) = {det_U**2 * Fr(1)}", end="")
prod_d = Fr(1)
for d in dvec:
    prod_d *= Fr(d)
print(f" * {prod_d} = {det_U**2 * prod_d}")
print(f"-- cden^24 * det(G) = {Fr(cden)**24}")
print(f"-- Should equal: det(Umat)^2 * prod(dvec) = {det_U**2 * prod_d}")
print(f"-- Check: {Fr(cden)**24 == det_U**2 * prod_d}")
