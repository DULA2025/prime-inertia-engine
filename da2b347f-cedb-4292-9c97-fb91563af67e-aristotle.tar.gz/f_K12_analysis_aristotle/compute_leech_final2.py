#!/usr/bin/env python3
"""
Find 24 minimal vectors that generate the full Leech lattice (det(Gram) = 1).
Strategy: start with the HNF basis (det=1) and replace each vector with a
nearby minimal vector while maintaining det = ±1.
"""
from fractions import Fraction as Fr
from math import gcd
import random
random.seed(42)

# =====================================================================
# Golay code setup (same as before)
# =====================================================================
B_rows = [
    [1,1,0,1,1,1,0,0,0,1,0,1], [1,0,1,1,1,0,0,0,1,0,1,1],
    [0,1,1,1,0,0,0,1,0,1,1,1], [1,1,1,0,0,0,1,0,1,1,0,1],
    [1,1,0,0,0,1,0,1,1,0,1,1], [1,0,0,0,1,0,1,1,0,1,1,1],
    [0,0,0,1,0,1,1,0,1,1,1,1], [0,0,1,0,1,1,0,1,1,1,0,1],
    [0,1,0,1,1,0,1,1,1,0,0,1], [1,0,1,1,0,1,1,1,0,0,0,1],
    [0,1,1,0,1,1,1,0,0,0,1,1], [1,1,1,1,1,1,1,1,1,1,1,0],
]

def golay_gen_row(i):
    row = [0]*24
    row[i] = 1
    for j in range(12):
        row[12+j] = B_rows[i][j]
    return row

def generate_golay_code():
    code = set()
    for mask in range(4096):
        cw = [0]*24
        for bit in range(12):
            if mask & (1 << bit):
                g = golay_gen_row(bit)
                for j in range(24):
                    cw[j] ^= g[j]
        code.add(tuple(cw))
    return code

golay_code = generate_golay_code()
octads = [c for c in golay_code if sum(c) == 8]

def check_L_int(a):
    parity = a[0] % 2
    if not all(x % 2 == parity for x in a):
        return False
    s = sum(a)
    if parity == 0:
        if s % 8 != 0: return False
        char_vec = tuple(1 if a[i] % 4 == 2 else 0 for i in range(24))
    else:
        if s % 8 != 4: return False
        char_vec = tuple(1 if a[i] % 4 == 1 else 0 for i in range(24))
    return char_vec in golay_code

def dot(a, b):
    return sum(x*y for x,y in zip(a,b))

# =====================================================================
# Generate minimal vectors (just a sample for searching)
# =====================================================================
min_vecs = []

# Type 3
for i in range(24):
    for j in range(i+1, 24):
        for si in [1,-1]:
            for sj in [1,-1]:
                v = [0]*24; v[i] = 4*si; v[j] = 4*sj
                if check_L_int(v): min_vecs.append(v)

# Type 1 (subset)
for oct_cw in octads:
    supp = [i for i in range(24) if oct_cw[i] == 1]
    for mask in range(256):
        p = bin(mask).count('1')
        if p % 2 != 0: continue
        v = [0]*24
        for idx, pos in enumerate(supp):
            v[pos] = 2 if (mask & (1 << idx)) else -2
        if check_L_int(v): min_vecs.append(v)

# Type 2 (a sample: a_j = 3 with S=empty, i.e., (3, -1^23) for each j)
for j in range(24):
    v = [-1]*24; v[j] = 3
    if check_L_int(v): min_vecs.append(v)

# Type 2 with octad S: a_j = 3, S = octad (j not in octad)
for oct_cw in octads[:100]:
    supp = [i for i in range(24) if oct_cw[i] == 1]
    for j in range(24):
        if j not in supp:
            v = [-1]*24; v[j] = 3
            for s in supp: v[s] = 1
            if check_L_int(v): min_vecs.append(v)
            break

# Type 2 with octad S: a_j = -3, S contains j
for oct_cw in octads[:100]:
    supp = [i for i in range(24) if oct_cw[i] == 1]
    for j in supp:
        v = [-1]*24; v[j] = -3
        for s in supp:
            if s != j: v[s] = 1
        if check_L_int(v): min_vecs.append(v)
        break

print(f"Total sample minimal vectors: {len(min_vecs)}")

# =====================================================================
# det computation
# =====================================================================
def det_exact(mat):
    n = len(mat)
    M = [[Fr(mat[i][j]) for j in range(n)] for i in range(n)]
    sign = 1
    for col in range(n):
        pivot = -1
        for r in range(col, n):
            if M[r][col] != 0: pivot = r; break
        if pivot == -1: return Fr(0)
        if pivot != col: M[col], M[pivot] = M[pivot], M[col]; sign *= -1
        for r in range(col+1, n):
            if M[r][col] != 0:
                f = M[r][col] / M[col][col]
                for j in range(col, n): M[r][j] -= f * M[col][j]
    d = Fr(sign)
    for i in range(n): d *= M[i][i]
    return d

def gram_det(basis):
    n = len(basis)
    G = [[Fr(dot(basis[i], basis[j])) // 8 for j in range(n)] for i in range(n)]
    return det_exact(G)

# =====================================================================
# Start with greedy selection, then improve
# =====================================================================
# Sort by "richness" — prefer vectors that touch more coordinates
sorted_mins = sorted(min_vecs, key=lambda v: -sum(1 for x in v if x != 0))

def rank_check(vectors):
    if not vectors: return 0
    n = len(vectors[0])
    M = [[Fr(v[j]) for j in range(n)] for v in vectors]
    m = len(M)
    r = 0
    for col in range(n):
        pivot = -1
        for row in range(r, m):
            if M[row][col] != 0: pivot = row; break
        if pivot == -1: continue
        M[r], M[pivot] = M[pivot], M[r]
        for row in range(m):
            if row != r and M[row][col] != 0:
                f = M[row][col] / M[r][col]
                for j in range(n): M[row][j] -= f * M[r][j]
        r += 1
    return r

# Pick 24 linearly independent vectors, preferring type 2 (dense) first
basis = []
for v in sorted_mins:
    test = basis + [v]
    if rank_check(test) > len(basis):
        basis.append(v)
        if len(basis) == 24:
            break

print(f"Initial basis: {len(basis)} vectors")
d = gram_det(basis)
print(f"det(G) = {d}")

# Try random swaps to reduce |det|
best_det = abs(d)
best_basis = [row[:] for row in basis]

for trial in range(10000):
    i = random.randint(0, 23)
    new_v = random.choice(min_vecs)
    test = [row[:] for row in best_basis]
    test[i] = new_v
    if rank_check(test) == 24:
        d = abs(gram_det(test))
        if d > 0 and d < best_det:
            best_det = d
            best_basis = test
            print(f"  Trial {trial}: det = {d}")
            if d == 1:
                break

print(f"\nBest det = {best_det}")
basis = best_basis

if best_det != 1:
    print("Did not find det=1 basis. Trying more aggressively...")
    # Try harder with more type 2 vectors
    # Generate ALL type 2 vectors with S = ∅ (i.e., (3, -1^23) for each position)
    type2_empty = []
    for j in range(24):
        for sign in [1, -1]:
            v = [-1]*24
            v[j] = 3 * sign
            # a_j = ±3. For sign=1: a_j=3≡3 mod4, j∉S. S=∅∈C. sum=-20≡4 mod8 ✓
            # For sign=-1: a_j=-3≡1 mod4, j∈S. S={j}, wt=1, NOT in C ✗
            if check_L_int(v):
                type2_empty.append(v)
    
    # Also generate type 2 with various octads
    more_type2 = []
    for oct_cw in octads:
        supp = [i for i in range(24) if oct_cw[i] == 1]
        for j in range(24):
            if j not in supp:
                v = [-1]*24; v[j] = 3
                for s in supp: v[s] = 1
                if check_L_int(v): more_type2.append(v)
        # Also with -3
        for j in supp:
            v = [-1]*24; v[j] = -3
            for s in supp:
                if s != j: v[s] = 1
            if check_L_int(v): more_type2.append(v)
    
    all_candidates = min_vecs + type2_empty + more_type2
    print(f"Total candidates: {len(all_candidates)}")
    
    for trial in range(50000):
        i = random.randint(0, 23)
        new_v = random.choice(all_candidates)
        test = [row[:] for row in best_basis]
        test[i] = new_v
        if rank_check(test) == 24:
            d = abs(gram_det(test))
            if d > 0 and d < best_det:
                best_det = d
                best_basis = test
                if trial % 1000 == 0 or d == 1:
                    print(f"  Trial {trial}: det = {d}")
                if d == 1:
                    break

basis = best_basis
print(f"\nFinal best det = {best_det}")

# =====================================================================
# Output
# =====================================================================
G = [[dot(basis[i], basis[j]) // 8 for j in range(24)] for i in range(24)]
print("\nGram matrix:")
for row in G:
    print(f"  {row}")
print(f"Diagonal: {[G[i][i] for i in range(24)]}")
max_offdiag = max(abs(G[i][j]) for i in range(24) for j in range(24) if i != j)
print(f"Max off-diagonal: {max_offdiag}")
