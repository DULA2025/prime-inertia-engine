#!/usr/bin/env python3
"""Generate the complete Lean code from the LLL-reduced Leech lattice basis."""
from fractions import Fraction as Fr
from math import gcd
import itertools, random
random.seed(42)

# =====================================================================
# Golay code (same as before)
# =====================================================================
B_rows = [
    [1,1,0,1,1,1,0,0,0,1,0,1], [1,0,1,1,1,0,0,0,1,0,1,1],
    [0,1,1,1,0,0,0,1,0,1,1,1], [1,1,1,0,0,0,1,0,1,1,0,1],
    [1,1,0,0,0,1,0,1,1,0,1,1], [1,0,0,0,1,0,1,1,0,1,1,1],
    [0,0,0,1,0,1,1,0,1,1,1,1], [0,0,1,0,1,1,0,1,1,1,0,1],
    [0,1,0,1,1,0,1,1,1,0,0,1], [1,0,1,1,0,1,1,1,0,0,0,1],
    [0,1,1,0,1,1,1,0,0,0,1,1], [1,1,1,1,1,1,1,1,1,1,1,0],
]

def golay_gen_row(i):
    row = [0]*24
    row[i] = 1
    for j in range(12): row[12+j] = B_rows[i][j]
    return row

def generate_golay_code():
    code = set()
    for mask in range(4096):
        cw = [0]*24
        for bit in range(12):
            if mask & (1 << bit):
                g = golay_gen_row(bit)
                for j in range(24): cw[j] ^= g[j]
        code.add(tuple(cw))
    return code

golay_code = generate_golay_code()

def check_L_int(a):
    parity = a[0] % 2
    if not all(x % 2 == parity for x in a): return False
    s = sum(a)
    if parity == 0:
        if s % 8 != 0: return False
        cv = tuple(1 if a[i] % 4 == 2 else 0 for i in range(24))
    else:
        if s % 8 != 4: return False
        cv = tuple(1 if a[i] % 4 == 1 else 0 for i in range(24))
    return cv in golay_code

def dot(a, b): return sum(x*y for x,y in zip(a,b))

# =====================================================================
# Build the HNF basis, then LLL-reduce
# =====================================================================
def row_hnf(mat):
    M = [row[:] for row in mat]
    m, n = len(M), len(M[0])
    pr = 0
    for pc in range(n):
        nz = [r for r in range(pr, m) if M[r][pc] != 0]
        if not nz: continue
        while len(nz) > 1:
            nz.sort(key=lambda r: abs(M[r][pc]))
            s = nz[0]
            for r in nz[1:]:
                q = M[r][pc] // M[s][pc]
                if q: M[r] = [M[r][j] - q*M[s][j] for j in range(n)]
            nz = [r for r in range(pr, m) if M[r][pc] != 0]
        if not nz: continue
        M[pr], M[nz[0]] = M[nz[0]], M[pr]
        if M[pr][pc] < 0: M[pr] = [-x for x in M[pr]]
        for r in range(m):
            if r != pr and M[r][pc]:
                q = M[r][pc] // M[pr][pc]
                M[r] = [M[r][j] - q*M[pr][j] for j in range(n)]
        pr += 1
    return [row for row in M if any(x != 0 for x in row)]

def lll_reduce(basis, delta=Fr(3,4)):
    n, m = len(basis), len(basis[0])
    B = [list(b) for b in basis]
    def gs():
        mu = [[Fr(0)]*n for _ in range(n)]
        Bs = [Fr(0)]*n
        for i in range(n):
            Bs[i] = Fr(dot(B[i], B[i]))
            for j in range(i):
                mu[i][j] = Fr(dot(B[i], B[j]))
                for k in range(j): mu[i][j] -= mu[i][k]*mu[j][k]*Bs[k]
                if Bs[j]: mu[i][j] /= Bs[j]
            for j in range(i): Bs[i] -= mu[i][j]**2 * Bs[j]
        return mu, Bs
    def sr(k, mu):
        for j in range(k-1,-1,-1):
            if abs(mu[k][j]) > Fr(1,2):
                r = int(round(float(mu[k][j])))
                for l in range(m): B[k][l] -= r*B[j][l]
                for i in range(j+1): mu[k][i] -= Fr(r)*mu[j][i]
    k = 1; mu, Bs = gs()
    while k < n:
        sr(k, mu)
        if Bs[k] >= (delta - mu[k][k-1]**2)*Bs[k-1]:
            k += 1
        else:
            B[k], B[k-1] = B[k-1], B[k]; mu, Bs = gs(); k = max(k-1,1)
    return B

# Generate L_int generators
gens = []
for i in range(12): gens.append([2*x for x in golay_gen_row(i)])
for j in range(24):
    v = [0]*24; v[j] = 8; gens.append(v)
for i in range(24):
    for j in range(i+1,24):
        v = [0]*24; v[i]=4; v[j]=4; gens.append(v)
        v = [0]*24; v[i]=4; v[j]=-4; gens.append(v)
gens.append([3]+[-1]*23)
for pos in range(24):
    v = [-1]*24; v[pos]=3; gens.append(v)
octads = [c for c in golay_code if sum(c) == 8]
for oct_cw in octads[:30]:
    supp = [i for i in range(24) if oct_cw[i]==1]
    for j in range(24):
        if j not in supp:
            v = [-1]*24; v[j]=3
            for s in supp: v[s]=1
            gens.append(v); break
for oct_cw in octads[:30]:
    supp = [i for i in range(24) if oct_cw[i]==1]
    j = supp[0]; v = [-1]*24; v[j]=-3
    for s in supp[1:]: v[s]=1
    gens.append(v)

print("Computing HNF...")
basis = row_hnf(gens)
assert len(basis) == 24

print("LLL reducing...")
rb = lll_reduce(basis)
for v in rb: assert check_L_int(v)

MtM = [[dot(rb[i],rb[j]) for j in range(24)] for i in range(24)]
assert all(MtM[i][j]%8==0 for i in range(24) for j in range(24))
G = [[MtM[i][j]//8 for j in range(24)] for i in range(24)]

def det_exact(mat):
    nn = len(mat)
    M = [[Fr(mat[i][j]) for j in range(nn)] for i in range(nn)]
    sign = 1
    for col in range(nn):
        pv = -1
        for r in range(col, nn):
            if M[r][col]: pv = r; break
        if pv == -1: return Fr(0)
        if pv != col: M[col], M[pv] = M[pv], M[col]; sign *= -1
        for r in range(col+1, nn):
            if M[r][col]:
                f = M[r][col]/M[col][col]
                for j in range(col, nn): M[r][j] -= f*M[col][j]
    d = Fr(sign)
    for i in range(nn): d *= M[i][i]
    return d

assert det_exact(G) == 1
assert all(G[i][j]==G[j][i] for i in range(24) for j in range(24))
assert all(G[i][i]%2==0 for i in range(24))
print(f"Gram OK: det=1, symmetric, even diagonal")
print(f"Diagonal: {[G[i][i] for i in range(24)]}")

# LDL^T
n = 24
GF = [[Fr(G[i][j]) for j in range(n)] for i in range(n)]
L = [[Fr(0)]*n for _ in range(n)]
D = [Fr(0)]*n
for i in range(n):
    D[i] = GF[i][i]
    for j in range(i): D[i] -= L[i][j]**2 * D[j]
    L[i][i] = Fr(1)
    for k in range(i+1, n):
        val = GF[k][i]
        for j in range(i): val -= L[k][j]*L[i][j]*D[j]
        L[k][i] = val / D[i]

assert all(D[i] > 0 for i in range(n))
U = [[L[j][i] for j in range(n)] for i in range(n)]

def lcm(a,b): return a*b//gcd(a,b)
def lcm_list(lst):
    r = 1
    for x in lst: r = lcm(r,x)
    return r

c1 = lcm_list(set(U[i][j].denominator for i in range(n) for j in range(n)))
c2 = lcm_list(set(D[i].denominator for i in range(n)))
cden_val = c1*c1*c2
Umat_int = [[int(c1*U[i][j]) for j in range(n)] for i in range(n)]
dvec_int = [int(c2*D[i]) for i in range(n)]

for i in range(n):
    for j in range(n):
        lhs = cden_val * G[i][j]
        rhs = sum(Umat_int[k][i]*dvec_int[k]*Umat_int[k][j] for k in range(n))
        assert lhs == rhs

print(f"c1={c1}, c2={c2}, cden={cden_val}")
print(f"Max |Umat|={max(abs(Umat_int[i][j]) for i in range(n) for j in range(n))}")
print(f"Max |dvec|={max(abs(d) for d in dvec_int)}")
assert all(d > 0 for d in dvec_int)

# Output Lean
print("\n--- LEAN OUTPUT ---\n")

# Gram
rows_g = []
for i in range(n):
    rows_g.append("    " + ", ".join(str(x) for x in G[i]))
print("def gram : Matrix (Fin 24) (Fin 24) ℤ :=")
print("  !![")
print(";\n".join(rows_g))
print("  ]")

# Umat
rows_u = []
for i in range(n):
    rows_u.append("    " + ", ".join(str(x) for x in Umat_int[i]))
print("\ndef Umat : Matrix (Fin 24) (Fin 24) ℤ :=")
print("  !![")
print(";\n".join(rows_u))
print("  ]")

# dvec
print(f"\ndef dvec : Fin 24 → ℤ :=")
print(f"  ![{', '.join(str(d) for d in dvec_int)}]")

# cden
print(f"\ndef cden : ℤ := {cden_val}")
