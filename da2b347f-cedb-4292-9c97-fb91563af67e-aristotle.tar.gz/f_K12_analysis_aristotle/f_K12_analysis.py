#!/usr/bin/env python3
"""
f_K12 = the unique newform in S_6(Gamma_0(3))  =  LMFDB 3.6.a.a  =  (eta(t) eta(3t))^6
        = the cuspidal shadow of the Coxeter-Todd K_12 theta series.

This script:
  TASK 1 : tests Sato-Tate (SU(2)) equidistribution of its Hecke eigenvalues.
  TASK 2 : shows the mod-13 Eisenstein reducibility of f_K12 is the integrality
           mechanism of the K_12 theta series, forcing 252 | r_K12(m).

It also renders a 4-panel figure (f_K12_analysis.png).

Dependencies: numpy, matplotlib.
"""
import numpy as np
import math
from math import comb
from fractions import Fraction as Fr
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

N = 8000  # q-expansion order

# ----------------------------------------------------------------------
# Build f_K12 = q * prod(1-q^n)^6 * prod(1-q^{3n})^6  to order N.
# prod(1-q^{step n}) is sparse (Euler pentagonal number theorem); raise to
# the 6th power by sparse-times-dense convolution, then convolve the two halves.
# ----------------------------------------------------------------------
def pentagonal_terms(N, step):
    """Nonzero terms (idx, sign) of prod_{n>=1}(1 - q^{step n}), excluding the constant 1."""
    terms, k = [], 1
    while True:
        added = False
        for g in (k * (3 * k - 1) // 2, k * (3 * k + 1) // 2):
            if step * g <= N:
                terms.append((step * g, (-1) ** k)); added = True
        if not added:
            break
        k += 1
    return terms

def eta_power6(terms, N):
    """(prod (1 - q^{...}))^6 as a dense int64 array of length N+1."""
    A = np.zeros(N + 1, dtype=np.int64); A[0] = 1
    for _ in range(6):
        R = A.copy()                                 # constant (j=0) term
        for j, v in terms:                           # j >= 1 terms
            R[j:N + 1] += v * A[0:N + 1 - j]
        A = R
    return A

A = eta_power6(pentagonal_terms(N, 1), N)
B = eta_power6(pentagonal_terms(N, 3), N)
a = np.zeros(N + 1, dtype=np.int64)
a[1:] = np.convolve(A, B)[:N]                         # a[n] = coeff of q^n in f_K12
assert [int(a[i]) for i in range(1, 9)] == [1, -6, 9, 4, 6, -54, -40, 168]

# ======================================================================
# TASK 1 : Sato-Tate equidistribution
# ======================================================================
def primes_up_to(N):
    s = np.ones(N + 1, bool); s[:2] = False
    for i in range(2, int(N ** 0.5) + 1):
        if s[i]:
            s[i * i::i] = False
    return np.nonzero(s)[0]

primes = [int(p) for p in primes_up_to(N) if p != 3]   # drop ramified prime
x = np.array([a[p] / p ** 2.5 for p in primes])        # x_p = a_p / p^{5/2} = 2 cos(theta_p)
theta = np.arccos(np.clip(x, -2, 2) / 2)
catalan = lambda m: comb(2 * m, m) // (m + 1)

print(f"=== TASK 1: Sato-Tate SU(2), {len(primes)} primes p < {N} ===")
print("  Deligne bound |a_p| <= 2 p^(5/2) holds for all p:", bool(np.all(np.abs(x) <= 2 + 1e-9)))
print("  even moments <x^(2m)> vs Catalan C_m (semicircle):")
for m in range(1, 5):
    print(f"    <x^{2*m}> = {np.mean(x**(2*m)):.4f}    C_{m} = {catalan(m)}")
print("  odd moments (-> 0):", [round(float(np.mean(x**k)), 4) for k in (1, 3, 5)])

# ======================================================================
# TASK 2 : mod-13 reducibility -> K_12 theta-coefficient divisibility
# ======================================================================
def sigma5(m):
    return sum(d ** 5 for d in range(1, m + 1) if m % d == 0)

# Eisenstein series coefficient:  E6 = 1 - 504 sum sigma_5(n) q^n
def E6_coeff(step, n):
    if n == 0:
        return 1
    return -504 * sigma5(n // step) if n % step == 0 else 0

# Theta_K12 = alpha E6(t) + beta E6(3t) + lambda f_K12  inside M_6(Gamma0(3))
ALPHA, BETA, LAMBDA = Fr(-1, 26), Fr(27, 26), Fr(-252, 13)
def r_K12(m):
    return ALPHA * E6_coeff(1, m) + BETA * E6_coeff(3, m) + LAMBDA * Fr(int(a[m]))

known = {0: 1, 2: 756, 3: 4032, 4: 20412, 5: 60480, 6: 139860}
print("\n=== TASK 2: mod-13 reducibility and K_12 theta coefficients ===")
print(f"  Theta_K12 = ({ALPHA}) E6(t) + ({BETA}) E6(3t) + ({LAMBDA}) f_K12   [cusp coeff -252/13]")
bad = [m for m in range(1, 500) if m % 3 and (sigma5(m) - int(a[m])) % 13]
print("  a_f(m) = sigma_5(m) (mod 13) for all m<500 coprime to 3:", not bad)
print("  formula reproduces all known r_K12 and predicts the rest:")
for m in range(9):
    v = r_K12(m); ri = int(v)
    flag = f"= known {known[m]}" if m in known else "(prediction)"
    print(f"    m={m}: r_K12={ri:>7}  {flag}   {'252 | r' if m and ri % 252 == 0 else ''}")
print("  252 | r_K12(m) for all m = 1..299:",
      all(r_K12(m).denominator == 1 and int(r_K12(m)) % 252 == 0 for m in range(1, 300)))

# ======================================================================
# FIGURE
# ======================================================================
plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(2, 2, figsize=(13, 9))
TEAL, GOLD, GREY = "#0F6E56", "#C8881C", "#888888"

# (a) Sato-Tate angle histogram + semicircle
ax0 = ax[0, 0]
ax0.hist(theta, bins=24, range=(0, math.pi), density=True, color=TEAL, alpha=0.55,
         edgecolor="white", label=f"{len(primes)} primes")
tt = np.linspace(0, math.pi, 400)
ax0.plot(tt, (2 / math.pi) * np.sin(tt) ** 2, color=GOLD, lw=2.5, label=r"$\frac{2}{\pi}\sin^2\theta$")
ax0.set_xlabel(r"$\theta_p$  where  $a_p = 2p^{5/2}\cos\theta_p$")
ax0.set_ylabel("density")
ax0.set_title("(a) Sato–Tate angles vs SU(2) measure", fontweight="bold")
ax0.legend(frameon=False)

# (b) eigenvalue histogram x_p = 2 cos(theta) + Wigner semicircle (1/2pi)sqrt(4-x^2)
ax1 = ax[0, 1]
ax1.hist(x, bins=24, range=(-2, 2), density=True, color=TEAL, alpha=0.55,
         edgecolor="white")
xx = np.linspace(-2, 2, 400)
ax1.plot(xx, np.sqrt(4 - xx ** 2) / (2 * math.pi), color=GOLD, lw=2.5,
         label=r"$\frac{1}{2\pi}\sqrt{4-x^2}$")
ax1.set_xlabel(r"$x_p = a_p / p^{5/2}$")
ax1.set_ylabel("density")
ax1.set_title("(b) Normalized eigenvalues vs semicircle", fontweight="bold")
ax1.legend(frameon=False)

# (c) moments: observed vs Catalan
ax2 = ax[1, 0]
ms = [1, 2, 3, 4]
obs = [np.mean(x ** (2 * m)) for m in ms]
cat = [catalan(m) for m in ms]
w = 0.38
ax2.bar([m - w / 2 for m in ms], obs, w, color=TEAL, label="observed")
ax2.bar([m + w / 2 for m in ms], cat, w, color=GOLD, label=r"Catalan $C_m$")
ax2.set_xticks(ms); ax2.set_xticklabels([f"$\\langle x^{{{2*m}}}\\rangle$" for m in ms])
ax2.set_title("(c) Even moments vs semicircle (Catalan)", fontweight="bold")
ax2.legend(frameon=False)
for m, o, c in zip(ms, obs, cat):
    ax2.text(m - w / 2, o + 0.1, f"{o:.2f}", ha="center", fontsize=9)
    ax2.text(m + w / 2, c + 0.1, f"{c}", ha="center", fontsize=9)

# (d) the mod-13 fingerprint:  (sigma_5(m) - a_f(m)) mod l  for l=13 (all zero) vs l=11 (control)
ax3 = ax[1, 1]
ms2 = [m for m in range(1, 120) if m % 3]
d13 = [(sigma5(m) - int(a[m])) % 13 for m in ms2]
d11 = [(sigma5(m) - int(a[m])) % 11 for m in ms2]
ax3.scatter(ms2, d11, s=18, color=GREY, alpha=0.7, label=r"mod 11 (control)")
ax3.scatter(ms2, d13, s=34, color=TEAL, label=r"mod 13: $\equiv 0$ always")
ax3.axhline(0, color=GOLD, lw=1.5)
ax3.set_xlabel(r"$m$  (coprime to 3)")
ax3.set_ylabel(r"$(\sigma_5(m) - a_f(m)) \;\mathrm{mod}\; \ell$")
ax3.set_title("(d) Eisenstein congruence: 13 is special", fontweight="bold")
ax3.legend(frameon=False, loc="upper right")

fig.suptitle("f$_{K_{12}}$ = LMFDB 3.6.a.a = (η(τ)η(3τ))⁶  —  Sato–Tate equidistribution and the mod-13 reducibility",
             fontsize=13, fontweight="bold")
fig.tight_layout(rect=[0, 0, 1, 0.97])
fig.savefig("f_K12_analysis.png", dpi=150)
print("\nsaved figure -> f_K12_analysis.png")
