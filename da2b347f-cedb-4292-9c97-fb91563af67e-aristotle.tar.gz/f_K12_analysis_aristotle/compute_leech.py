#!/usr/bin/env python3
"""
Construct the Leech lattice Gram matrix and its LDL^T factorization.
Uses exact arithmetic (fractions) throughout.

The EVEN Leech lattice Λ₂₄ has:
  L_int = {a ∈ Z^24 : (L1) all same parity,
                        (L2) code condition on mod 4,
                        (L3_even) Σa_i ≡ 0 mod 8 for even vectors,
                        (L3_odd)  Σa_i ≡ 4 mod 8 for odd vectors}
  Λ = (1/√8) · L_int
"""
from fractions import Fraction as Fr

# =====================================================================
# Extended binary Golay code
# =====================================================================
B_rows = [
    [1,1,0,1,1,1,0,0,0,1,0,1],
    [1,0,1,1,1,0,0,0,1,0,1,1],
    [0,1,1,1,0,0,0,1,0,1,1,1],
    [1,1,1,0,0,0,1,0,1,1,0,1],
    [1,1,0,0,0,1,0,1,1,0,1,1],
    [1,0,0,0,1,0,1,1,0,1,1,1],
    [0,0,0,1,0,1,1,0,1,1,1,1],
    [0,0,1,0,1,1,0,1,1,1,0,1],
    [0,1,0,1,1,0,1,1,1,0,0,1],
    [1,0,1,1,0,1,1,1,0,0,0,1],
    [0,1,1,0,1,1,1,0,0,0,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,0],
]

def golay_gen_row(i):
    row = [0]*24
    row[i] = 1
    for j in range(12):
        row[12+j] = B_rows[i][j]
    return row

def generate_golay_code():
    code = set()
    for mask in range(4096):
        cw = [0]*24
        for bit in range(12):
            if mask & (1 << bit):
                g = golay_gen_row(bit)
                for j in range(24):
                    cw[j] ^= g[j]
        code.add(tuple(cw))
    return code

golay_code = generate_golay_code()
assert len(golay_code) == 4096

# =====================================================================
# L_int membership check
# =====================================================================
def check_L_int(a):
    """Check if integer vector a is in L_int (the even Leech lattice construction)."""
    parity = a[0] % 2
    if not all(x % 2 == parity for x in a):
        return False
    s = sum(a)
    if parity == 0:
        # Even: sum ≡ 0 mod 8
        if s % 8 != 0:
            return False
        # {i : a_i/2 is odd} = {i : a_i ≡ 2 mod 4}
        char_vec = tuple(1 if a[i] % 4 == 2 else 0 for i in range(24))
    else:
        # Odd: sum ≡ 4 mod 8
        if s % 8 != 4:
            return False
        # {i : a_i ≡ 1 mod 4}
        char_vec = tuple(1 if a[i] % 4 == 1 else 0 for i in range(24))
    if char_vec not in golay_code:
        return False
    return True

# Quick sanity checks
assert not check_L_int([1]*24), "(1,...,1) should NOT be in even Leech lattice"
assert check_L_int([3] + [-1]*23), "(3,-1^23) should be in even Leech lattice"
assert check_L_int([0]*24), "0 should be in lattice"
# Type 3 minimal vector: (4,4,0,...,0)
assert check_L_int([4,4]+[0]*22), "(4,4,0^22) should be in lattice"
# Type 1 minimal vector: octad with even number of minus signs
print("Sanity checks passed")

# =====================================================================
# Row HNF
# =====================================================================
def row_hnf(mat):
    M = [row[:] for row in mat]
    m = len(M)
    n = len(M[0])
    
    pivot_col = 0
    pivot_row_idx = 0
    
    for pivot_col in range(n):
        # Find all nonzero entries in this column at or below pivot_row_idx
        nonzero = [r for r in range(pivot_row_idx, m) if M[r][pivot_col] != 0]
        if not nonzero:
            continue
        
        # Use extended Euclidean to reduce to a single nonzero entry
        while len(nonzero) > 1:
            nonzero.sort(key=lambda r: abs(M[r][pivot_col]))
            smallest = nonzero[0]
            for r in nonzero[1:]:
                q = M[r][pivot_col] // M[smallest][pivot_col]
                if q != 0:
                    for j in range(n):
                        M[r][j] -= q * M[smallest][j]
            nonzero = [r for r in range(pivot_row_idx, m) if M[r][pivot_col] != 0]
        
        if not nonzero:
            continue
        
        r = nonzero[0]
        M[pivot_row_idx], M[r] = M[r], M[pivot_row_idx]
        
        if M[pivot_row_idx][pivot_col] < 0:
            M[pivot_row_idx] = [-x for x in M[pivot_row_idx]]
        
        # Reduce all other rows
        for r in range(m):
            if r != pivot_row_idx and M[r][pivot_col] != 0:
                q = M[r][pivot_col] // M[pivot_row_idx][pivot_col]
                for j in range(n):
                    M[r][j] -= q * M[pivot_row_idx][j]
        
        pivot_row_idx += 1
    
    return [row for row in M if any(x != 0 for x in row)]

# =====================================================================
# Generate L_int vectors
# =====================================================================
generators = []

# Even type: 2 * golay generators
for i in range(12):
    g = [2*x for x in golay_gen_row(i)]
    assert check_L_int(g)
    generators.append(g)

# Even type: 8*e_j
for j in range(24):
    v = [0]*24; v[j] = 8
    assert check_L_int(v)
    generators.append(v)

# Even type: 4*e_i + 4*e_j
for i in range(24):
    for j in range(i+1, 24):
        v = [0]*24; v[i] = 4; v[j] = 4
        assert check_L_int(v)
        generators.append(v)

# Even type: 4*e_i - 4*e_j
for i in range(24):
    for j in range(i+1, 24):
        v = [0]*24; v[i] = 4; v[j] = -4
        assert check_L_int(v)
        generators.append(v)

# Odd type: (3, -1, -1, ..., -1) — a known type 2 minimal vector
odd_vec = [3] + [-1]*23
assert check_L_int(odd_vec)
generators.append(odd_vec)

# More odd type vectors: for each octad, construct vectors with octad support
# Vector: -1 everywhere, then set 8 positions (octad) to 3.
# Sum = -24 + 8*4 = 8. Need sum ≡ 4 mod 8. 8 ≡ 0 ≠ 4. ✗
# Try: -1 everywhere, set SOME positions to 3.
# Sum = -24 + 4k where k = number of positions changed from -1 to 3.
# Need -24 + 4k ≡ 4 mod 8: 4k ≡ 28 mod 8: 4k ≡ 4 mod 8: k ≡ 1 mod 2.
# So k must be odd: 1, 3, 5, 7, ...

# k=1: one position changed to 3. That's our (3,-1^23) type.
# For different positions:
for pos in range(24):
    v = [-1]*24
    v[pos] = 3
    # Sum = -24 + 4 = -20 ≡ 4 mod 8. ✓
    # S = {i : a_i ≡ 1 mod 4}: -1 ≡ 3, 3 ≡ 3. S = ∅ ∈ C ✓
    assert check_L_int(v)
    generators.append(v)

# k=3: three positions changed to 3.
# S = {i : a_i ≡ 1 mod 4} = ∅ still (since 3 ≡ 3, -1 ≡ 3). ∈ C ✓
# Sum = -24 + 12 = -12 ≡ 4 mod 8. ✓
import itertools
for combo in list(itertools.combinations(range(24), 3))[:100]:
    v = [-1]*24
    for p in combo:
        v[p] = 3
    assert check_L_int(v)
    generators.append(v)

# k=5: five positions to 3
for combo in list(itertools.combinations(range(24), 5))[:20]:
    v = [-1]*24
    for p in combo:
        v[p] = 3
    assert check_L_int(v)
    generators.append(v)

# Odd vectors with mixed signs: (1,...,1,-1,...,-1) with code constraint
# {i : a_i ≡ 1 mod 4} = {i : a_i = 1}. Need this set ∈ C.
# Try to use octads: set 8 positions to 1 and 16 to -1.
# Sum = 8 - 16 = -8 ≡ 0 mod 8. Need ≡ 4. ✗

# Try: 12 positions to 1 and 12 to -1.
# Sum = 12 - 12 = 0 ≡ 0 mod 8. ✗

# Try: 8 positions to 1 and 16 to 3 (wait, this changes wt condition)
# All ≡ 1 or 3 mod 4. S = positions with value 1. Weight 8, an octad.
# Sum = 8 + 48 = 56 ≡ 0 mod 8. ✗

# Hmm. Let me think about odd vectors with S ≠ ∅.
# Need S ∈ C (weight 0,8,12,16,24), sum ≡ 4 mod 8.
# For S with weight w (values ≡ 1 mod 4) and complement with weight 24-w (values ≡ 3 mod 4):
# Minimum norm: entries are ±1 mostly. The simplest case: all entries are ±1.
# Entry ≡ 1 mod 4: entry = 1 or -3, -7, ... Simplest: 1.
# Entry ≡ 3 mod 4: entry = -1 or 3, -5, ... Simplest: -1.
# So a = 1 at S, -1 at complement. Sum = w - (24-w) = 2w - 24.
# Need 2w - 24 ≡ 4 mod 8: 2w ≡ 28 mod 8: 2w ≡ 4 mod 8: w ≡ 2 mod 4.
# w ∈ {0,8,12,16,24} → w ≡ 2 mod 4: NONE of {0,0,0,0,0}. ✗!

# For all w in {0,8,12,16,24}: w mod 4 = {0,0,0,0,0}. So w ≡ 0 mod 4 always.
# And 2w ≡ 0 mod 8 always. So sum = 2w-24 ≡ -24 ≡ 0 mod 8 always.
# Cannot get sum ≡ 4 mod 8 with ±1 entries!

# So to get odd vectors with S ≠ ∅ and sum ≡ 4 mod 8, I need entries other than ±1.
# E.g., one entry = ±3 and rest ±1.
# Let position j have value ±3 and all others ±1. 
# If a_j ≡ 1 mod 4: a_j = -3 (since (-3) mod 4 = 1). Then j ∈ S.
# If a_j ≡ 3 mod 4: a_j = 3 (since 3 mod 4 = 3). Then j ∉ S.
# For the simple case: a_j = 3 (so j ∉ S), rest = ±1.
# S = {i ≠ j : a_i = 1}. Need S ∈ C, wt(S) ∈ {0,8,12,16,24}.
# But S doesn't include j, so wt(S) ≤ 23.

# Case 1: a_j = 3, all others = -1. S = ∅ ∈ C. Sum = 3-23 = -20 ≡ 4 mod 8 ✓.
# These are the generators I already added.

# Case 2: a_j = 3, exactly 8 others = 1, rest = -1.
# S = 8 positions (an octad). Sum = 3 + 8 - 15 = -4 ≡ 4 mod 8 ✓!
# Need the 8 positions (NOT including j) to form an octad ∈ C.
octads = [c for c in golay_code if sum(c) == 8]
print(f"Number of octads: {len(octads)}")
count = 0
for oct in octads[:30]:
    supp = [i for i in range(24) if oct[i] == 1]
    # Choose j not in the octad
    for j in range(24):
        if j not in supp:
            v = [-1]*24
            v[j] = 3
            for s in supp:
                v[s] = 1
            if check_L_int(v):
                generators.append(v)
                count += 1
            break  # just one per octad
print(f"Added {count} type-2 vectors with octad S")

# Case 3: a_j = -3, exactly 8 others = 1, rest = -1.
# a_j = -3 ≡ 1 mod 4, so j ∈ S. S = {j} ∪ (8 positions). wt = 9. Not in C. ✗.

# Case 4: a_j = -3, exactly 12 others = 1, rest = -1.  
# S = {j} ∪ 12 positions. wt = 13. Not in C. ✗.

# Case 5: a_j = -3, exactly 7 others = 1, rest = -1.
# S = {j} ∪ 7 = 8 positions. Need this to be an octad.
# Sum = -3 + 7 - 16 = -12 ≡ 4 mod 8 ✓.
count2 = 0
for oct in octads[:30]:
    supp = [i for i in range(24) if oct[i] == 1]
    j = supp[0]  # put -3 at first octad position
    v = [-1]*24
    v[j] = -3
    for s in supp[1:]:
        v[s] = 1
    if check_L_int(v):
        generators.append(v)
        count2 += 1
print(f"Added {count2} type-2 vectors with -3 in octad")

print(f"\nTotal generators: {len(generators)}")

# Verify all generators
for i, g in enumerate(generators):
    ok = check_L_int(g)
    if not ok:
        print(f"ERROR: Generator {i} fails L_int check: {g}")
        import sys; sys.exit(1)

# Compute basis
print("Computing row HNF...")
basis = row_hnf(generators)
print(f"Basis size: {len(basis)}")

def dot(a, b):
    return sum(x*y for x,y in zip(a,b))

MtM = [[dot(basis[i], basis[j]) for j in range(24)] for i in range(24)]
all_div_8 = all(MtM[i][j] % 8 == 0 for i in range(24) for j in range(24))
print(f"All M^T M entries divisible by 8: {all_div_8}")

if not all_div_8:
    print("ERROR: entries not divisible by 8")
    import sys; sys.exit(1)

G = [[MtM[i][j] // 8 for j in range(24)] for i in range(24)]

def det_exact(mat):
    n = len(mat)
    M = [[Fr(mat[i][j]) for j in range(n)] for i in range(n)]
    sign = 1
    for col in range(n):
        pivot = -1
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot == -1:
            return Fr(0)
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
            sign *= -1
        for r in range(col+1, n):
            if M[r][col] != 0:
                f = M[r][col] / M[col][col]
                for j in range(col, n):
                    M[r][j] -= f * M[col][j]
    d = Fr(sign)
    for i in range(n):
        d *= M[i][i]
    return d

det_G = det_exact(G)
symm = all(G[i][j] == G[j][i] for i in range(24) for j in range(24))
even_diag = all(G[i][i] % 2 == 0 for i in range(24))

print(f"\ndet(G) = {det_G}")
print(f"Symmetric: {symm}")
print(f"Even diagonal: {even_diag}")
print(f"Diagonal: {[G[i][i] for i in range(24)]}")

if det_G == 1 and symm and even_diag:
    print("\n=== SUCCESS: Even unimodular Gram matrix! ===")
    print("\nGram matrix G (24x24):")
    for row in G:
        print(f"  {row}")
else:
    print(f"\nNot quite right yet. det={det_G}, symm={symm}, even_diag={even_diag}")
