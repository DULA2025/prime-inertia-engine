#!/usr/bin/env python3
"""Output Lean code for the Leech lattice Gram matrix and LDL^T factorization."""
from fractions import Fraction as Fr
from math import gcd

G = [
  [4, 1, -1, 0, -2, 1, -2, 0, 0, 0, -1, 0, -1, 0, 0, -1, 0, 0, -1, -1, 0, -1, 0, -1],
  [1, 4, -1, -1, 1, 0, 0, -1, 1, -1, 0, 0, -1, -1, 1, 0, 1, 0, 0, -1, 1, 0, -1, 0],
  [-1, -1, 4, 1, 2, 0, 2, -1, 1, 0, 2, 2, 2, 0, -1, 2, 2, 2, 2, -1, 0, 2, 0, 2],
  [0, -1, 1, 4, 0, 0, 0, 0, 0, -1, 0, -1, 0, 1, -1, 0, -1, 1, 0, 0, 0, -1, -1, 0],
  [-2, 1, 2, 0, 4, -2, 2, -2, 1, 0, 2, 2, 2, 0, 0, 2, 2, 2, 2, -1, 1, 2, 0, 2],
  [1, 0, 0, 0, -2, 4, 0, 1, -1, 1, -1, -1, -1, 1, 0, 0, 0, -1, -2, 0, 0, -1, -1, -1],
  [-2, 0, 2, 0, 2, 0, 4, 0, 1, 0, 2, 2, 2, 0, 0, 2, 2, 2, 2, 0, 1, 2, 0, 2],
  [0, -1, -1, 0, -2, 1, 0, 4, -1, 1, -2, -1, 0, 0, 0, -1, -1, -1, 0, 1, 0, -1, 0, -1],
  [0, 1, 1, 0, 1, -1, 1, -1, 4, -1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, 0, 1, 0, 1],
  [0, -1, 0, -1, 0, 1, 0, 1, -1, 4, -1, 1, 1, 2, 0, 0, 0, 0, -1, 0, 0, 0, 0, -1],
  [-1, 0, 2, 0, 2, -1, 2, -2, 1, -1, 4, 2, 2, -1, 1, 2, 2, 2, 2, -1, 0, 2, 0, 2],
  [0, 0, 2, -1, 2, -1, 2, -1, 1, 1, 2, 4, 2, 0, 0, 2, 2, 2, 2, -1, 0, 2, 1, 2],
  [-1, -1, 2, 0, 2, -1, 2, 0, -1, 1, 2, 2, 4, 0, 1, 2, 2, 2, 2, -2, 1, 2, 0, 2],
  [0, -1, 0, 1, 0, 1, 0, 0, -1, 2, -1, 0, 0, 4, -1, 1, 0, 0, -1, 1, 0, -1, 0, -1],
  [0, 1, -1, -1, 0, 0, 0, 0, -1, 0, 1, 0, 1, -1, 4, 0, 1, 0, 0, -1, 1, -1, -1, 1],
  [-1, 0, 2, 0, 2, 0, 2, -1, -1, 0, 2, 2, 2, 1, 0, 4, 2, 2, 2, -1, 1, 2, 0, 2],
  [0, 1, 2, -1, 2, 0, 2, -1, 1, 0, 2, 2, 2, 0, 1, 2, 4, 2, 2, -1, 2, 2, 0, 2],
  [0, 0, 2, 1, 2, -1, 2, -1, 1, 0, 2, 2, 2, 0, 0, 2, 2, 4, 2, -1, 2, 2, 0, 2],
  [-1, 0, 2, 0, 2, -2, 2, 0, 1, -1, 2, 2, 2, -1, 0, 2, 2, 2, 4, -1, 1, 2, 0, 2],
  [-1, -1, -1, 0, -1, 0, 0, 1, 1, 0, -1, -1, -2, 1, -1, -1, -1, -1, -1, 4, -1, -1, 1, -1],
  [0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 2, 2, 1, -1, 4, 1, -1, 1],
  [-1, 0, 2, -1, 2, -1, 2, -1, 1, 0, 2, 2, 2, -1, -1, 2, 2, 2, 2, -1, 1, 4, 1, 2],
  [0, -1, 0, -1, 0, -1, 0, 0, 0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 0, 1, -1, 1, 4, 0],
  [-1, 0, 2, 0, 2, -1, 2, -1, 1, -1, 2, 2, 2, -1, 1, 2, 2, 2, 2, -1, 1, 2, 0, 4],
]

n = 24

# Verify properties
assert all(G[i][j] == G[j][i] for i in range(n) for j in range(n)), "Not symmetric"
assert all(G[i][i] % 2 == 0 for i in range(n)), "Diagonal not even"
assert all(G[i][i] == 4 for i in range(n)), "Diagonal not all 4"

def det_exact(mat):
    nn = len(mat)
    M = [[Fr(mat[i][j]) for j in range(nn)] for i in range(nn)]
    sign = 1
    for col in range(nn):
        pivot = -1
        for r in range(col, nn):
            if M[r][col] != 0: pivot = r; break
        if pivot == -1: return Fr(0)
        if pivot != col: M[col], M[pivot] = M[pivot], M[col]; sign *= -1
        for r in range(col+1, nn):
            if M[r][col] != 0:
                f = M[r][col] / M[col][col]
                for j in range(col, nn): M[r][j] -= f * M[col][j]
    d = Fr(sign)
    for i in range(nn): d *= M[i][i]
    return d

assert det_exact(G) == 1, f"det = {det_exact(G)}"
print("Gram matrix verified: symmetric, even diagonal, det = 1")

# LDL^T
GF = [[Fr(G[i][j]) for j in range(n)] for i in range(n)]
L = [[Fr(0)]*n for _ in range(n)]
D = [Fr(0)]*n

for i in range(n):
    D[i] = GF[i][i]
    for j in range(i):
        D[i] -= L[i][j]**2 * D[j]
    L[i][i] = Fr(1)
    for k in range(i+1, n):
        val = GF[k][i]
        for j in range(i):
            val -= L[k][j] * L[i][j] * D[j]
        L[k][i] = val / D[i]

print("\nD diagonal:")
for i in range(n):
    print(f"  D[{i}] = {D[i]}")

assert all(D[i] > 0 for i in range(n))
U = [[L[j][i] for j in range(n)] for i in range(n)]

def lcm(a, b):
    return a * b // gcd(a, b)

def lcm_list(lst):
    r = 1
    for x in lst:
        r = lcm(r, x)
    return r

u_denoms = set()
for i in range(n):
    for j in range(n):
        u_denoms.add(U[i][j].denominator)
c1 = lcm_list(u_denoms)

d_denoms = set()
for i in range(n):
    d_denoms.add(D[i].denominator)
c2 = lcm_list(d_denoms)

cden_val = c1 * c1 * c2
Umat_int = [[int(c1 * U[i][j]) for j in range(n)] for i in range(n)]
dvec_int = [int(c2 * D[i]) for i in range(n)]

# Verify
for i in range(n):
    for j in range(n):
        lhs = cden_val * G[i][j]
        rhs = sum(Umat_int[k][i] * dvec_int[k] * Umat_int[k][j] for k in range(n))
        assert lhs == rhs

print(f"\nc1 = {c1}")
print(f"c2 = {c2}")
print(f"cden = {cden_val}")
print(f"Max |Umat| = {max(abs(Umat_int[i][j]) for i in range(n) for j in range(n))}")
print(f"Max |dvec| = {max(abs(d) for d in dvec_int)}")
print(f"dvec = {dvec_int}")
print("Factorization verified ✓")

# =====================================================================
# Output Lean
# =====================================================================
print("\n" + "="*70)
print("LEAN CODE")
print("="*70)

# Gram matrix
print("/-- The Leech lattice Gram matrix (minimal-vector basis). -/")
print("def gram : Matrix (Fin 24) (Fin 24) ℤ :=")
print("  !![")
for i in range(n):
    row_str = ", ".join(f"{x:3d}" for x in G[i])
    sep = ";" if i < n-1 else ""
    print(f"    {row_str}{sep}")
print("  ]")

print()

# Umat
print("def Umat : Matrix (Fin 24) (Fin 24) ℤ :=")
print("  !![")
for i in range(n):
    row_str = ", ".join(str(x) for x in Umat_int[i])
    sep = ";" if i < n-1 else ""
    print(f"    {row_str}{sep}")
print("  ]")

print()

# dvec
print(f"def dvec : Fin 24 → ℤ :=")
dvec_str = ", ".join(str(d) for d in dvec_int)
print(f"  ![{dvec_str}]")

print()

# cden
print(f"def cden : ℤ := {cden_val}")
