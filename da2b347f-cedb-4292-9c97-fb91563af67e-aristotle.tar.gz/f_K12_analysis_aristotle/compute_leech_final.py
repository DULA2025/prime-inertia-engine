#!/usr/bin/env python3
"""
Construct the Leech lattice Gram matrix using a minimal-vector basis.
Minimal vectors have norm 4, giving Gram diagonal = 4 and off-diagonal in {-2,...,2}.
Then compute LDL^T factorization.
"""
from fractions import Fraction as Fr
from math import gcd

# =====================================================================
# Golay code
# =====================================================================
B_rows = [
    [1,1,0,1,1,1,0,0,0,1,0,1],
    [1,0,1,1,1,0,0,0,1,0,1,1],
    [0,1,1,1,0,0,0,1,0,1,1,1],
    [1,1,1,0,0,0,1,0,1,1,0,1],
    [1,1,0,0,0,1,0,1,1,0,1,1],
    [1,0,0,0,1,0,1,1,0,1,1,1],
    [0,0,0,1,0,1,1,0,1,1,1,1],
    [0,0,1,0,1,1,0,1,1,1,0,1],
    [0,1,0,1,1,0,1,1,1,0,0,1],
    [1,0,1,1,0,1,1,1,0,0,0,1],
    [0,1,1,0,1,1,1,0,0,0,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,0],
]

def golay_gen_row(i):
    row = [0]*24
    row[i] = 1
    for j in range(12):
        row[12+j] = B_rows[i][j]
    return row

def generate_golay_code():
    code = set()
    for mask in range(4096):
        cw = [0]*24
        for bit in range(12):
            if mask & (1 << bit):
                g = golay_gen_row(bit)
                for j in range(24):
                    cw[j] ^= g[j]
        code.add(tuple(cw))
    return code

golay_code = generate_golay_code()
octads = [c for c in golay_code if sum(c) == 8]
print(f"Golay code: {len(golay_code)} codewords, {len(octads)} octads")

# =====================================================================
# Generate ALL minimal vectors of the Leech lattice
# =====================================================================
# Minimal vectors have |a|^2 = 32 in integer coords (norm 4 after /sqrt(8))
# Types: 2^8 0^16 (type1), 3 1^23 (type2), 4^2 0^22 (type3)

def check_L_int(a):
    parity = a[0] % 2
    if not all(x % 2 == parity for x in a):
        return False
    s = sum(a)
    if parity == 0:
        if s % 8 != 0:
            return False
        char_vec = tuple(1 if a[i] % 4 == 2 else 0 for i in range(24))
    else:
        if s % 8 != 4:
            return False
        char_vec = tuple(1 if a[i] % 4 == 1 else 0 for i in range(24))
    return char_vec in golay_code

minimal_vectors = []

# Type 3: 4^2 0^22
for i in range(24):
    for j in range(i+1, 24):
        for si in [1, -1]:
            for sj in [1, -1]:
                v = [0]*24
                v[i] = 4*si
                v[j] = 4*sj
                if check_L_int(v):
                    minimal_vectors.append(tuple(v))

print(f"Type 3 vectors: {len(minimal_vectors)}")

# Type 1: 2^8 0^16
for oct_cw in octads:
    supp = [i for i in range(24) if oct_cw[i] == 1]
    # Even number of minus signs among 8 positions
    # p = number of +2, q = number of -2, p+q=8, p even
    for mask in range(256):  # 2^8 sign patterns
        p = bin(mask).count('1')  # number of +2 positions
        if p % 2 != 0:
            continue
        v = [0]*24
        for idx, pos in enumerate(supp):
            if mask & (1 << idx):
                v[pos] = 2
            else:
                v[pos] = -2
        if check_L_int(v):
            minimal_vectors.append(tuple(v))

print(f"After type 1: {len(minimal_vectors)} vectors")

# Type 2: one ±3, rest ±1 (all odd)
# Case A: a_j = 3, rest ±1. S = {i≠j : a_i=1}. |S| ∈ {0,8,12,16}, p ≡ 0 mod 4.
# Case B: a_j = -3, rest ±1. S = {j} ∪ {i≠j : a_i=1}. |S| ∈ {8,12,16,24}, p ≡ 3 mod 4.

for j in range(24):
    # Case A: a_j = 3
    for cw in golay_code:
        wt = sum(cw)
        if wt not in {0, 8, 12, 16}:
            continue
        if cw[j] != 0:  # j should NOT be in S (since a_j=3 ≡ 3 mod 4)
            continue
        # S is the support of cw (positions with a_i = 1, i.e., a_i ≡ 1 mod 4)
        p = wt  # number of positions with a_i = 1 (excluding j)
        if p % 4 != 0:
            continue
        v = [-1]*24
        v[j] = 3
        for i in range(24):
            if cw[i] == 1:
                v[i] = 1
        if sum(v) % 8 == 4 and sum(x*x for x in v) == 32:
            minimal_vectors.append(tuple(v))
    
    # Case B: a_j = -3
    for cw in golay_code:
        wt = sum(cw)
        if wt not in {8, 12, 16, 24}:
            continue
        if cw[j] != 1:  # j MUST be in S (since a_j=-3 ≡ 1 mod 4)
            continue
        p = sum(1 for i in range(24) if i != j and cw[i] == 1)
        # |S| = 1 + p = wt
        # Need p ≡ 3 mod 4 (so that sum ≡ 4 mod 8)
        if p % 4 != 3:
            continue
        v = [-1]*24
        v[j] = -3
        for i in range(24):
            if i != j and cw[i] == 1:
                v[i] = 1
        if sum(v) % 8 == 4 and sum(x*x for x in v) == 32:
            minimal_vectors.append(tuple(v))

print(f"Total minimal vectors: {len(minimal_vectors)}")
print(f"Expected: 196560")

# Remove duplicates
minimal_set = set(minimal_vectors)
print(f"Unique minimal vectors: {len(minimal_set)}")

# =====================================================================
# Find 24 linearly independent minimal vectors
# =====================================================================
def dot(a, b):
    return sum(x*y for x,y in zip(a,b))

def rank(vectors):
    """Compute rank using fraction-based Gaussian elimination."""
    if not vectors:
        return 0
    n = len(vectors[0])
    M = [[Fr(v[j]) for j in range(n)] for v in vectors]
    m = len(M)
    r = 0
    for col in range(n):
        pivot = -1
        for row in range(r, m):
            if M[row][col] != 0:
                pivot = row
                break
        if pivot == -1:
            continue
        M[r], M[pivot] = M[pivot], M[r]
        for row in range(m):
            if row != r and M[row][col] != 0:
                f = M[row][col] / M[r][col]
                for j in range(n):
                    M[row][j] -= f * M[r][j]
        r += 1
    return r

# Greedily select linearly independent vectors, preferring simpler ones
# Sort by number of nonzero entries (sparsest first)
sorted_mins = sorted(minimal_set, key=lambda v: sum(1 for x in v if x != 0))

basis = []
for v in sorted_mins:
    test = basis + [list(v)]
    if rank(test) > len(basis):
        basis.append(list(v))
        if len(basis) == 24:
            break

print(f"\nFound {len(basis)} linearly independent minimal vectors")

# Compute Gram matrix
MtM = [[dot(basis[i], basis[j]) for j in range(24)] for i in range(24)]
all_div_8 = all(MtM[i][j] % 8 == 0 for i in range(24) for j in range(24))
print(f"All M^T M divisible by 8: {all_div_8}")

G = [[MtM[i][j] // 8 for j in range(24)] for i in range(24)]

def det_exact(mat):
    n = len(mat)
    M = [[Fr(mat[i][j]) for j in range(n)] for i in range(n)]
    sign = 1
    for col in range(n):
        pivot = -1
        for r in range(col, n):
            if M[r][col] != 0: pivot = r; break
        if pivot == -1: return Fr(0)
        if pivot != col: M[col], M[pivot] = M[pivot], M[col]; sign *= -1
        for r in range(col+1, n):
            if M[r][col] != 0:
                f = M[r][col] / M[col][col]
                for j in range(col, n): M[r][j] -= f * M[col][j]
    d = Fr(sign)
    for i in range(n): d *= M[i][i]
    return d

det_G = det_exact(G)
symm = all(G[i][j] == G[j][i] for i in range(24) for j in range(24))
even_diag = all(G[i][i] % 2 == 0 for i in range(24))

print(f"det(G) = {det_G}")
print(f"Symmetric: {symm}")
print(f"Even diagonal: {even_diag}")
print(f"Diagonal: {[G[i][i] for i in range(24)]}")
max_offdiag = max(abs(G[i][j]) for i in range(24) for j in range(24) if i != j)
print(f"Max |off-diagonal| = {max_offdiag}")

print("\nGram matrix:")
for row in G:
    print(f"  {row}")

# =====================================================================
# LDL^T factorization
# =====================================================================
n = 24
GF = [[Fr(G[i][j]) for j in range(n)] for i in range(n)]
L = [[Fr(0)]*n for _ in range(n)]
D = [Fr(0)]*n

for i in range(n):
    D[i] = GF[i][i]
    for j in range(i):
        D[i] -= L[i][j]**2 * D[j]
    L[i][i] = Fr(1)
    for k in range(i+1, n):
        val = GF[k][i]
        for j in range(i):
            val -= L[k][j] * L[i][j] * D[j]
        L[k][i] = val / D[i]

print("\nD diagonal:")
for i in range(n):
    print(f"  D[{i}] = {D[i]}")

all_pos = all(D[i] > 0 for i in range(n))
print(f"All D > 0: {all_pos}")

# Clear denominators
U = [[L[j][i] for j in range(n)] for i in range(n)]

def lcm(a, b):
    return a * b // gcd(a, b)

def lcm_list(lst):
    result = 1
    for x in lst:
        result = lcm(result, x)
    return result

u_denoms = set()
for i in range(n):
    for j in range(n):
        u_denoms.add(U[i][j].denominator)
c1 = lcm_list(u_denoms)

d_denoms = set()
for i in range(n):
    d_denoms.add(D[i].denominator)
c2 = lcm_list(d_denoms)

cden_val = c1 * c1 * c2
Umat_int = [[int(c1 * U[i][j]) for j in range(n)] for i in range(n)]
dvec_int = [int(c2 * D[i]) for i in range(n)]

# Verify
for i in range(n):
    for j in range(n):
        lhs = cden_val * G[i][j]
        rhs = sum(Umat_int[k][i] * dvec_int[k] * Umat_int[k][j] for k in range(n))
        assert lhs == rhs

print(f"\nc1 = {c1} ({len(str(c1))} digits)")
print(f"c2 = {c2} ({len(str(c2))} digits)")
print(f"cden = {cden_val} ({len(str(cden_val))} digits)")

max_umat = max(abs(Umat_int[i][j]) for i in range(n) for j in range(n))
max_dvec = max(abs(d) for d in dvec_int)
print(f"Max |Umat| = {max_umat} ({len(str(max_umat))} digits)")
print(f"Max |dvec| = {max_dvec} ({len(str(max_dvec))} digits)")
print(f"dvec = {dvec_int}")
print("Factorization verified ✓")
