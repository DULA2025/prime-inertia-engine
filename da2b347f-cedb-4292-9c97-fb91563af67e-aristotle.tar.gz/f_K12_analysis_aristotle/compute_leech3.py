#!/usr/bin/env python3
"""
LLL-reduce the Leech lattice basis to get a nicer Gram matrix,
then compute LDL^T factorization with smaller numbers.
"""
from fractions import Fraction as Fr
from math import gcd

# =====================================================================
# The basis vectors from Part 1 (before computing Gram matrix)
# Re-derive by running compute_leech.py mentally, or just paste them.
# Actually, let me re-run the construction to get the integer basis M.
# =====================================================================

B_rows = [
    [1,1,0,1,1,1,0,0,0,1,0,1],
    [1,0,1,1,1,0,0,0,1,0,1,1],
    [0,1,1,1,0,0,0,1,0,1,1,1],
    [1,1,1,0,0,0,1,0,1,1,0,1],
    [1,1,0,0,0,1,0,1,1,0,1,1],
    [1,0,0,0,1,0,1,1,0,1,1,1],
    [0,0,0,1,0,1,1,0,1,1,1,1],
    [0,0,1,0,1,1,0,1,1,1,0,1],
    [0,1,0,1,1,0,1,1,1,0,0,1],
    [1,0,1,1,0,1,1,1,0,0,0,1],
    [0,1,1,0,1,1,1,0,0,0,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,0],
]

def golay_gen_row(i):
    row = [0]*24
    row[i] = 1
    for j in range(12):
        row[12+j] = B_rows[i][j]
    return row

def generate_golay_code():
    code = set()
    for mask in range(4096):
        cw = [0]*24
        for bit in range(12):
            if mask & (1 << bit):
                g = golay_gen_row(bit)
                for j in range(24):
                    cw[j] ^= g[j]
        code.add(tuple(cw))
    return code

golay_code = generate_golay_code()

def check_L_int(a):
    parity = a[0] % 2
    if not all(x % 2 == parity for x in a):
        return False
    s = sum(a)
    if parity == 0:
        if s % 8 != 0:
            return False
        char_vec = tuple(1 if a[i] % 4 == 2 else 0 for i in range(24))
    else:
        if s % 8 != 4:
            return False
        char_vec = tuple(1 if a[i] % 4 == 1 else 0 for i in range(24))
    if char_vec not in golay_code:
        return False
    return True

# =====================================================================
# LLL reduction over Z with exact Gram-Schmidt
# =====================================================================
def dot(a, b):
    return sum(x*y for x,y in zip(a,b))

def lll_reduce(basis, delta=Fr(3,4)):
    """LLL-reduce a list of integer basis vectors. Returns reduced basis."""
    n = len(basis)
    m = len(basis[0])
    B = [list(b) for b in basis]
    
    def gram_schmidt():
        """Compute mu[i][j] and B_star_norm_sq[i] using exact fractions."""
        mu = [[Fr(0)]*n for _ in range(n)]
        Bs = [Fr(0)]*n  # ||b*_i||^2
        
        for i in range(n):
            Bs[i] = Fr(dot(B[i], B[i]))
            for j in range(i):
                mu[i][j] = Fr(dot(B[i], B[j]))
                for k in range(j):
                    mu[i][j] -= mu[i][k] * mu[j][k] * Bs[k]
                if Bs[j] != 0:
                    mu[i][j] /= Bs[j]
            
            for j in range(i):
                Bs[i] -= mu[i][j]**2 * Bs[j]
        
        return mu, Bs
    
    def size_reduce(k, mu):
        for j in range(k-1, -1, -1):
            if abs(mu[k][j]) > Fr(1,2):
                r = int(round(float(mu[k][j])))
                for l in range(m):
                    B[k][l] -= r * B[j][l]
                # Update mu
                for i in range(j+1):
                    mu[k][i] -= Fr(r) * mu[j][i]
    
    k = 1
    mu, Bs = gram_schmidt()
    
    while k < n:
        size_reduce(k, mu)
        
        if Bs[k] >= (delta - mu[k][k-1]**2) * Bs[k-1]:
            k += 1
        else:
            B[k], B[k-1] = B[k-1], B[k]
            mu, Bs = gram_schmidt()  # Recompute (lazy but correct)
            k = max(k-1, 1)
    
    return B

# =====================================================================
# Generate basis (same as compute_leech.py)
# =====================================================================
import itertools

def row_hnf(mat):
    M = [row[:] for row in mat]
    m = len(M)
    n = len(M[0])
    pivot_row_idx = 0
    
    for pivot_col in range(n):
        nonzero = [r for r in range(pivot_row_idx, m) if M[r][pivot_col] != 0]
        if not nonzero:
            continue
        while len(nonzero) > 1:
            nonzero.sort(key=lambda r: abs(M[r][pivot_col]))
            smallest = nonzero[0]
            for r in nonzero[1:]:
                q = M[r][pivot_col] // M[smallest][pivot_col]
                if q != 0:
                    for j in range(n):
                        M[r][j] -= q * M[smallest][j]
            nonzero = [r for r in range(pivot_row_idx, m) if M[r][pivot_col] != 0]
        if not nonzero:
            continue
        r = nonzero[0]
        M[pivot_row_idx], M[r] = M[r], M[pivot_row_idx]
        if M[pivot_row_idx][pivot_col] < 0:
            M[pivot_row_idx] = [-x for x in M[pivot_row_idx]]
        for r in range(m):
            if r != pivot_row_idx and M[r][pivot_col] != 0:
                q = M[r][pivot_col] // M[pivot_row_idx][pivot_col]
                for j in range(n):
                    M[r][j] -= q * M[pivot_row_idx][j]
        pivot_row_idx += 1
    
    return [row for row in M if any(x != 0 for x in row)]

generators = []
for i in range(12):
    generators.append([2*x for x in golay_gen_row(i)])
for j in range(24):
    v = [0]*24; v[j] = 8; generators.append(v)
for i in range(24):
    for j in range(i+1, 24):
        v = [0]*24; v[i] = 4; v[j] = 4; generators.append(v)
for i in range(24):
    for j in range(i+1, 24):
        v = [0]*24; v[i] = 4; v[j] = -4; generators.append(v)
generators.append([3] + [-1]*23)
for pos in range(24):
    v = [-1]*24; v[pos] = 3; generators.append(v)
octads = [c for c in golay_code if sum(c) == 8]
for oct in octads[:30]:
    supp = [i for i in range(24) if oct[i] == 1]
    for j in range(24):
        if j not in supp:
            v = [-1]*24; v[j] = 3
            for s in supp: v[s] = 1
            generators.append(v); break
for oct in octads[:30]:
    supp = [i for i in range(24) if oct[i] == 1]
    j = supp[0]; v = [-1]*24; v[j] = -3
    for s in supp[1:]: v[s] = 1
    generators.append(v)

for g in generators:
    assert check_L_int(g)

print("Computing HNF basis...")
basis = row_hnf(generators)
assert len(basis) == 24
print(f"HNF basis has {len(basis)} vectors")

# =====================================================================
# LLL reduce
# =====================================================================
print("LLL reducing...")
reduced_basis = lll_reduce(basis)
print("LLL reduction done")

# Verify all reduced vectors are in L_int
for v in reduced_basis:
    assert check_L_int(v), f"Reduced vector not in L_int: {v}"

# Compute Gram matrix
MtM = [[dot(reduced_basis[i], reduced_basis[j]) for j in range(24)] for i in range(24)]
all_div_8 = all(MtM[i][j] % 8 == 0 for i in range(24) for j in range(24))
print(f"All M^T M divisible by 8: {all_div_8}")

G = [[MtM[i][j] // 8 for j in range(24)] for i in range(24)]

def det_exact(mat):
    n = len(mat)
    M = [[Fr(mat[i][j]) for j in range(n)] for i in range(n)]
    sign = 1
    for col in range(n):
        pivot = -1
        for r in range(col, n):
            if M[r][col] != 0: pivot = r; break
        if pivot == -1: return Fr(0)
        if pivot != col: M[col], M[pivot] = M[pivot], M[col]; sign *= -1
        for r in range(col+1, n):
            if M[r][col] != 0:
                f = M[r][col] / M[col][col]
                for j in range(col, n): M[r][j] -= f * M[col][j]
    d = Fr(sign)
    for i in range(n): d *= M[i][i]
    return d

det_G = det_exact(G)
symm = all(G[i][j] == G[j][i] for i in range(24) for j in range(24))
even_diag = all(G[i][i] % 2 == 0 for i in range(24))

print(f"det(G) = {det_G}, Symmetric: {symm}, Even diagonal: {even_diag}")
print(f"Diagonal: {[G[i][i] for i in range(24)]}")

if det_G == 1 and symm and even_diag:
    print("\n=== SUCCESS ===")

print("\nGram matrix:")
for row in G:
    print(f"  {row}")

# =====================================================================
# LDL^T factorization
# =====================================================================
n = 24
GF = [[Fr(G[i][j]) for j in range(n)] for i in range(n)]
L = [[Fr(0)]*n for _ in range(n)]
D = [Fr(0)]*n

for i in range(n):
    D[i] = GF[i][i]
    for j in range(i):
        D[i] -= L[i][j]**2 * D[j]
    L[i][i] = Fr(1)
    for k in range(i+1, n):
        val = GF[k][i]
        for j in range(i):
            val -= L[k][j] * L[i][j] * D[j]
        L[k][i] = val / D[i]

print("\nLDL^T diagonal D:")
for i in range(n):
    print(f"  D[{i}] = {D[i]} = {float(D[i]):.6f}")

# Check all D > 0
all_pos = all(D[i] > 0 for i in range(n))
print(f"All D > 0: {all_pos}")

# L^T = U (upper triangular)
U = [[L[j][i] for j in range(n)] for i in range(n)]

# Clear denominators
def lcm(a, b):
    return a * b // gcd(a, b)

def lcm_list(lst):
    result = 1
    for x in lst:
        result = lcm(result, x)
    return result

u_denoms = set()
for i in range(n):
    for j in range(n):
        u_denoms.add(U[i][j].denominator)
c1 = lcm_list(u_denoms)

d_denoms = set()
for i in range(n):
    d_denoms.add(D[i].denominator)
c2 = lcm_list(d_denoms)

cden = c1 * c1 * c2
print(f"\nc1 = {c1}")
print(f"c2 = {c2}")
print(f"cden = {cden}")
print(f"cden has {len(str(cden))} digits")

Umat_int = [[int(c1 * U[i][j]) for j in range(n)] for i in range(n)]
dvec_int = [int(c2 * D[i]) for i in range(n)]

# Verify
for i in range(n):
    for j in range(n):
        lhs = cden * G[i][j]
        rhs = sum(Umat_int[k][i] * dvec_int[k] * Umat_int[k][j] for k in range(n))
        assert lhs == rhs, f"Mismatch at [{i}][{j}]"
print("Factorization verified ✓")

# Find max absolute value in Umat for sizing
max_umat = max(abs(Umat_int[i][j]) for i in range(n) for j in range(n))
max_dvec = max(abs(d) for d in dvec_int)
print(f"Max |Umat entry| = {max_umat} ({len(str(max_umat))} digits)")
print(f"Max |dvec entry| = {max_dvec} ({len(str(max_dvec))} digits)")
print(f"dvec = {dvec_int}")
