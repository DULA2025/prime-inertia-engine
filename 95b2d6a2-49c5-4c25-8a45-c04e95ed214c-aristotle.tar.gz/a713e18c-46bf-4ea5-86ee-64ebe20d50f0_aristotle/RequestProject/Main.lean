import Mathlib

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 20000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

set_option pp.fullNames true
set_option pp.structureInstances true
set_option pp.coercions.types true
set_option pp.funBinderTypes true
set_option pp.letVarTypes true
set_option pp.piBinderTypes true

set_option grind.warning false

open Nat

namespace DulaChi3

set_option linter.unusedVariables false

/-- Primes ≡ 1 mod 3 (where χ₃ = +1) -/
def P₁ : Set ℕ := {p | Nat.Prime p ∧ p ≡ 1 [MOD 3]}

/-- Primes ≡ 2 mod 3 (where χ₃ = -1) -/
def P₂ : Set ℕ := {p | Nat.Prime p ∧ p ≡ 2 [MOD 3]}

/-- All primes that are not 3 -/
def P : Set ℕ := P₁ ∪ P₂

/-- Positive integers whose prime factors all lie in P
    (i.e. not divisible by 3) -/
structure S where
  val     : ℕ
  pos     : val > 0
  factors : ∀ {p : ℕ}, Nat.Prime p → p ∣ val → p ∈ P

instance : Mul S where
  mul a b := {
    val := a.val * b.val
    pos := Nat.mul_pos a.pos b.pos
    factors := by
      intro p hp hpdvd
      rcases hp.dvd_mul.mp hpdvd with ha | hb
      · exact a.factors hp ha
      · exact b.factors hp hb
  }

instance : One S where
  one := {
    val := 1
    pos := Nat.one_pos
    factors := by
      intro p hp hpdvd
      exact absurd (Nat.eq_one_of_dvd_one hpdvd) hp.ne_one
  }

@[simp] lemma val_mul (a b : S) : (a * b).val = a.val * b.val := rfl
@[simp] lemma val_one : (1 : S).val = 1 := rfl

@[ext] lemma S.ext {a b : S} (h : a.val = b.val) : a = b := by
  cases a; cases b; simp at h; subst h; rfl

instance : Monoid S where
  mul_one a := S.ext (Nat.mul_one a.val)
  one_mul a := S.ext (Nat.one_mul a.val)
  mul_assoc a b c := S.ext (Nat.mul_assoc a.val b.val c.val)

/-- Total exponent of primes ≡ 2 mod 3 -/
noncomputable def m (n : S) : ℕ :=
  n.val.factorization.sum fun p k =>
    if (Nat.Prime p ∧ p ≡ 2 [MOD 3]) then k else 0

/-- The sign character (±1) -/
def negOneUnit : Units ℤ := -1

abbrev MulZ₂ := Units ℤ

/-- φ : S → Multiplicative (ZMod 2)  (additive version of the exponent mod 2) -/
noncomputable def phi (n : S) : Multiplicative (ZMod 2) :=
  Multiplicative.ofAdd (m n : ZMod 2)

/-- ψ : S → {±1}  (the actual Dirichlet character value) -/
noncomputable def psi (n : S) : MulZ₂ :=
  negOneUnit ^ m n

lemma m_mul (a b : S) : m (a * b) = m a + m b := by
  simp [m, Nat.factorization_mul a.pos.ne' b.pos.ne']
  rw [Finsupp.sum_add_index'] <;> aesop

/-- φ is a monoid homomorphism -/
noncomputable def phiHom : S →* Multiplicative (ZMod 2) where
  toFun := phi
  map_one' := by simp [phi, m, Nat.factorization_one]
  map_mul' a b := by
    simp only [phi, m_mul, Nat.cast_add]
    rfl

/-- ψ is a monoid homomorphism (this is χ₃ on the units) -/
noncomputable def psiHom : S →* MulZ₂ where
  toFun := psi
  map_one' := by simp [psi, m, Nat.factorization_one]
  map_mul' a b := by simp [psi, m_mul, pow_add]

/-- The isomorphism Multiplicative (ZMod 2) ≃ {±1} -/
noncomputable def theta : Multiplicative (ZMod 2) →* MulZ₂ where
  toFun z := negOneUnit ^ (Multiplicative.toAdd z).val
  map_one' := by simp
  map_mul' x y := by fin_cases x <;> fin_cases y <;> rfl

/-- The fundamental commutation: ψ = θ ∘ φ -/
theorem dula_theorem_commutes (n : S) : psi n = theta (phi n) := by
  unfold theta phi psi
  have : negOneUnit ^ (m n) = negOneUnit ^ (m n % 2) := by
    rw [← Nat.mod_add_div (m n) 2, pow_add, pow_mul]
    norm_num [negOneUnit]
  cases Nat.mod_two_eq_zero_or_one (m n) <;> simp_all

/-- Any positive integer coprime to 3 has only prime factors in P -/
lemma coprime_three_factors {n : ℕ} (hn : n ≠ 0) (hc : n.Coprime 3) :
    ∀ {p : ℕ}, Nat.Prime p → p ∣ n → p ∈ P := by
  intro p hp hpn
  have h_coprime : Nat.gcd p 3 = 1 :=
    Nat.Coprime.coprime_dvd_left hpn hc
  have h_mod : p % 3 = 1 ∨ p % 3 = 2 := by
    have h0 : p % 3 ≠ 0 := by
      intro h0
      have : (3 : ℕ) ∣ p := Nat.dvd_of_mod_eq_zero h0
      have : (3 : ℕ) ∣ Nat.gcd p 3 := Nat.dvd_gcd this dvd_rfl
      rw [h_coprime] at this
      omega
    have := Nat.mod_lt p (by decide : 3 > 0)
    omega
  exact h_mod.elim (fun h => Or.inl ⟨hp, h⟩) (fun h => Or.inr ⟨hp, h⟩)

open ArithmeticFunction

/-- The arithmetic function that is exactly χ₃
    (0 at multiples of 3, ±1 elsewhere according to the exponent of primes ≡ 2 mod 3) -/
noncomputable def chi3 : ArithmeticFunction ℤ where
  toFun n :=
    if h : n = 0 then 0
    else if h_coprime : n.Coprime 3 then
      (psi ⟨n, Nat.pos_of_ne_zero h, coprime_three_factors h h_coprime⟩ : ℤ)
    else 0
  map_zero' := dif_pos rfl

/-- χ₃ * id  (the sum-of-divisors function twisted by χ₃) -/
noncomputable def chi3Sigma : ArithmeticFunction ℤ :=
  chi3 * ArithmeticFunction.id

/-- χ₃ * Λ  (von Mangoldt twisted by χ₃) -/
noncomputable def chi3VonMangoldt : ArithmeticFunction ℝ :=
  (↑chi3 : ArithmeticFunction ℝ) * ArithmeticFunction.vonMangoldt

/-- The fundamental identity that links the twisted von Mangoldt
    to the logarithmic derivative of L(s, χ₃) -/
theorem chi3_vonMangoldt_conv_zeta :
    chi3VonMangoldt * (↑(ArithmeticFunction.zeta) : ArithmeticFunction ℝ) =
    (↑chi3 : ArithmeticFunction ℝ) * ArithmeticFunction.log := by
  unfold chi3VonMangoldt
  ext
  simp [mul_assoc]

/-- The non-trivial Dirichlet character modulo `3`, realized as the quadratic
    character of the field `ZMod 3`.  It sends `n` to `0`, `1`, `-1` according as
    `n ≡ 0, 1, 2 [MOD 3]`. -/
noncomputable def χ₃ : DirichletCharacter ℤ 3 := quadraticChar (ZMod 3)

/-- Explicit description of `χ₃` on the three residue classes. -/
lemma chi3Char_apply (x : ZMod 3) :
    χ₃ x = if x = 0 then 0 else if x = 1 then 1 else -1 := by
  revert x; decide

/-- The `ZMod 3` reduction of an element of `S` is `(-1) ^ m n`. -/
lemma val_cast_zmod_three (n : S) : ((n.val : ℕ) : ZMod 3) = (-1 : ZMod 3) ^ m n := by
  conv_lhs => rw [← Nat.factorization_prod_pow_eq_self n.pos.ne']
  rw [Finsupp.prod, Nat.cast_prod, m, Finsupp.sum,
    ← Finset.prod_pow_eq_pow_sum]
  refine Finset.prod_congr rfl ?_
  intro p hp
  rw [Nat.support_factorization] at hp
  have hpp : Nat.Prime p := Nat.prime_of_mem_primeFactors hp
  have hpd : p ∣ n.val := Nat.dvd_of_mem_primeFactors hp
  have hmem := n.factors hpp hpd
  push_cast
  rcases hmem with h1 | h2
  · have : p % 3 = 1 := h1.2
    have hcast : (p : ZMod 3) = 1 := by
      rw [← ZMod.natCast_mod, this]; rfl
    rw [hcast, if_neg, one_pow, pow_zero]
    rintro ⟨-, h⟩
    rw [Nat.ModEq] at h
    omega
  · have : p % 3 = 2 := h2.2
    have hcast : (p : ZMod 3) = -1 := by
      rw [← ZMod.natCast_mod, this]; decide
    rw [hcast, if_pos ⟨hpp, h2.2⟩]

/-- The value of `psi` as an integer is `(-1) ^ m n`. -/
lemma psi_val (n : S) : ((psi n : ℤ)) = (-1 : ℤ) ^ m n := by
  simp [psi, negOneUnit, Units.val_pow_eq_pow_val]

/-- `chi3` really is the Dirichlet character `χ₃` modulo 3. -/
theorem chi3_is_the_character :
    ∀ n > 0, (chi3 n : ℤ) = χ₃ n := by
  intro n hn
  have hn0 : n ≠ 0 := hn.ne'
  show (if h : n = 0 then (0:ℤ) else if h_coprime : n.Coprime 3 then
      (psi ⟨n, Nat.pos_of_ne_zero h, coprime_three_factors h h_coprime⟩ : ℤ)
    else 0) = _
  rw [dif_neg hn0]
  by_cases hc : n.Coprime 3
  · rw [dif_pos hc]
    set s : S := ⟨n, Nat.pos_of_ne_zero hn0, coprime_three_factors hn0 hc⟩ with hs
    have hcast : ((n : ℕ) : ZMod 3) = (-1 : ZMod 3) ^ m s := val_cast_zmod_three s
    rw [psi_val, chi3Char_apply, hcast]
    rcases Nat.even_or_odd (m s) with he | ho
    · rw [he.neg_one_pow, he.neg_one_pow]
      norm_num
    · rw [ho.neg_one_pow, ho.neg_one_pow]
      rw [if_neg (by decide), if_neg (by decide)]
  · rw [dif_neg hc]
    have hdvd : (3:ℕ) ∣ n := by
      by_contra h
      exact hc ((Nat.Prime.coprime_iff_not_dvd (by norm_num)).mpr h).symm
    have : ((n : ℕ) : ZMod 3) = 0 := by
      exact (ZMod.natCast_eq_zero_iff n 3).mpr hdvd
    rw [chi3Char_apply, this, if_pos rfl]

end DulaChi3
