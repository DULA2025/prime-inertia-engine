# Instructions for Aristotle — Closing autocorrelation_WTF sorrys

## Context

This package is the full DULA project (verified to build cleanly in the previous
session — `lake build` succeeded with 6 sorrys total). The file
`WeilTestFunction.lean` has been modified to factor `autocorrelation_WTF`'s
two field sorrys into a structured proof using **three new helper lemmas**.

## What's new in WeilTestFunction.lean

Three helper lemmas were inserted before `autocorrelation_WTF`:

1. **`exp_decay_pointwise_product`** (PROVED, no sorry) — pointwise bound on
   the autocorrelation integrand.

2. **`exp_decay_convolution_integral_bound`** (sorry) — the integral
   computation: `∫ exp(-α|t|) · exp(-α|t+x|) dt ≤ (1/α + |x|) · exp(-α|x|)`.
   Region-splitting integration. Mathematical content in the lemma's docstring.

3. **`poly_exp_absorption`** (sorry) — for `0 < β < α`, there exists `K > 0`
   with `(1/α + |x|) · exp(-α|x|) ≤ K · exp(-β|x|)`. Standard polynomial-times-
   exponential absorption.

`autocorrelation_WTF` itself was rewritten to:
- Provide explicit witnesses: `b' = b/2`, `C' = C * C * K`.
- Have a clean assembly proof outline (currently sorry — combine the three helpers).
- The derivative version (`has_exponential_decay_deriv`) remains sorry, deferred
  to a follow-up session after the non-derivative case is verified.

## Sorry count

**Expected after this run:**
- `Main.lean`: 2 sorrys (unchanged — Weil 1952 sub-lemmas)
- `ContinuityHelpers.lean`: 2 sorrys (unchanged)
- `WeilTestFunction.lean`: 4 sorrys
  - `exp_decay_convolution_integral_bound` (line ~285)
  - `poly_exp_absorption` (line ~304)
  - `autocorrelation_WTF.has_exponential_decay` assembly (line ~343)
  - `autocorrelation_WTF.has_exponential_decay_deriv` (line ~346)
- **Total: 8 sorrys** (was 6 in the previous build).

The increase from 6 to 8 is due to factoring 2 monolithic sorrys into 4
granular targets. This is a deliberate tradeoff: each new sorry is concrete
and independently attackable.

## Task

**Primary task:** verify the project builds cleanly with the 4 sorrys in
`WeilTestFunction.lean`. The build SHOULD succeed; the sorrys are explicit
deferrals, not type errors.

**Secondary task (if you have capacity and confidence):** attempt to fill any
of the 4 sorrys. They are listed in approximate increasing order of difficulty:

1. `poly_exp_absorption` (probably easiest) — pure real analysis, ~30-50 lines.
   The function `(1/α + y) · exp(-(α-β)y)` is bounded on `[0, ∞)` because it's
   continuous and goes to 0 at infinity. Take the supremum.

2. `autocorrelation_WTF.has_exponential_decay` — assembly proof. Uses
   `MeasureTheory.norm_integral_le_integral_norm` to get the inequality from
   the absolute value of the integral. Then bounds via `exp_decay_pointwise_product`.
   Then applies `exp_decay_convolution_integral_bound` and `poly_exp_absorption`.
   Mostly bookkeeping if the helper lemmas are available.

3. `exp_decay_convolution_integral_bound` (probably hardest) — region-splitting
   integration. Three regions: `t ≥ 0`, `-x ≤ t ≤ 0`, `t ≤ -x` (for `x ≥ 0`,
   with symmetric treatment for `x < 0`). Each region's integral is computable
   via `Real.exp_neg`, `integral_exp_neg_eq`, etc. ~50-150 lines.

4. `autocorrelation_WTF.has_exponential_decay_deriv` — DO NOT ATTEMPT in this
   round. It requires identifying `deriv (autocorrelation h) x = ∫ h(t) · h'(t+x) dt`
   via `AutocorrSmooth.lean`'s differentiation-under-the-integral lemma. Save for
   a future session.

## Critical instructions

✗ **DO NOT modify any file other than `WeilTestFunction.lean`.** All other
  files (Main.lean, AutocorrSmooth.lean, etc.) are at their canonical, verified
  versions.

✗ **DO NOT attempt the 2 sorrys in `Main.lean` or the 2 in `ContinuityHelpers.lean`.**
  They are deep mathematical content out of scope for this round.

✗ **DO NOT attempt `has_exponential_decay_deriv`.** Defer to a future session.

✗ **DO NOT remove the proof of `exp_decay_pointwise_product`.** It's already
  proved (no sorry) and provides the pointwise bound the assembly proof needs.

✗ **DO NOT remove the proof of `vonMangoldt_sum_summable`.** Already verified
  in a previous session.

✓ **DO** report which (if any) of the 4 WeilTestFunction sorrys you closed,
  and which (if any) you attempted but couldn't close. Granular feedback is
  valuable.

## If the build fails

The build SHOULD succeed (the new sorrys are placeholders, not type errors).
If it fails, the most likely cause is a syntactic issue in my modifications:

- `refine ⟨b/2, by linarith, C * C * K, by positivity, ?_⟩` may need explicit
  nested anonymous constructors `⟨b/2, ⟨by linarith, ⟨C * C * K, ⟨by positivity, ?_⟩⟩⟩⟩`
  if Lean's flat constructor doesn't unify with `∃ b > 0, ∃ C > 0, P` shape.

- `exp_decay_pointwise_product`'s `mul_le_mul` argument order or
  `abs_mul`/`abs_nonneg` resolution may need adjustment.

If you get a syntactic error in these, please report the exact error message.
Small fixes are expected, but rewriting from scratch is not.

## Expected response format

In `ARISTOTLE_SUMMARY.md`, please report:

- Build status (success/failure).
- Final sorry count per file.
- Which sorrys were attempted, and the outcome (closed / failed / not attempted).
- Any non-blocking warnings (cosmetic linting OK to ignore, but list them).
