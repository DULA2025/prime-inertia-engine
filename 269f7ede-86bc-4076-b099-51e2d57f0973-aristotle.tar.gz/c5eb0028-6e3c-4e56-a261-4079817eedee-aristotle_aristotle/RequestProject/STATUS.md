# Project Status — Weil Positivity Framework

## Summary of Completed Work

This project formalizes a conditional approach to the Riemann Hypothesis
through Weil's positivity criterion, Hermite-Biehler theory, and
Cohn-Elkies sphere-packing functions in Lean 4 / Mathlib.

### Fully Proved (no sorry)

| File | Key Results |
|------|-------------|
| `Main.lean` | `EvenSchwartz`, `WeilDistribution` (formula only), `autocorrelation` |
| `AutocorrSmooth.lean` | `schwartz_conv_hasDerivAt`, `autocorrelation_smooth` |
| `ZetaConj.lean` | `completedRiemannZeta_conj` (Schwarz reflection) |
| `DulaTheorem.lean` | `dulaPhi_additive`, `dulaChar_mul`, `key_identity_general` |
| `ConvolutionContinuity.lean` | `autocorrelation_continuous` in Schwartz space |
| `HermiteBiehler.lean` | `rh_iff_hb1`, `hb1_implies_rh`, `rh_implies_hb1` |
| `WeilTestFunction.lean` | `WeilTestFunction` structure, `vonMangoldt_sum_summable`, `autocorrelation_WTF` |
| `IndBanach.lean` | `weilFunctional_continuous_on_Eb` ✨, `weilFunctional_continuous_indBanach`, `conjecture_a_strong_indBanach_implies_rh` |
| `ContinuityHelpers.lean` | Components 1 & 3 continuity, `weil_kernel_bounded` |

### Key Achievement: Continuity of the Weil Functional on E_b

The main new result proved in this session is:

```
lemma weilFunctional_continuous_on_Eb (b : ℝ) (hb : 0 < b) :
    Continuous (weilFunctional ∘ toWeilTestFunction hb)
```

This establishes that the Weil distribution, applied to autocorrelations,
is continuous when restricted to each exponential decay class E_b.
The proof decomposes into three components:

1. **Component 1** (h(0)·log(π)): Continuous via `autocorr_at_continuous_Eb'`.
2. **Component 2** (von Mangoldt sum): Continuous via the Weierstrass M-test.
   On E_b, all functions decay as exp(-(1/2+b)|t|), giving uniform
   bounds |h(log n)| ≤ C·‖g‖²_b · n^{-(1/2+b/2)}, so the sum
   ∑ Λ(n)/√n · |h(log n)| converges uniformly on bounded subsets.
3. **Component 3** (archimedean integral): Continuous via dominated convergence.

This directly yields `weilFunctional_continuous_indBanach`, proving
continuity in the ind-Banach topology. Combined with `WeilCriterion_WTF`,
this gives:

```
theorem conjecture_a_strong_indBanach_implies_rh :
    Conjecture_A_Strong_WTF_indBanach → RiemannHypothesis
```

### Remaining Sorry's

| Location | Statement | Status | Reason |
|----------|-----------|--------|--------|
| `ContinuityHelpers.lean:235` | `weil_component2_continuous_WTF` | **FALSE** | Rigorous counterexample documented |
| `WeilTestFunction.lean:679` | `spectralSide_autocorr_nonneg_WTF` | Open | Requires Weil explicit formula |
| `WeilTestFunction.lean:688` | `weilPositivity_wtf_implies_rh` | Open | Requires Weil explicit formula |
| `IndBanach.lean:345` | `CompleteSpace (ExpDecayClass b)` | Open | Norm doesn't control derivatives |
| `IndBanach.lean:411` | `indBanach_finer_than_schwartz` | Open | Direction questionable; needs derivative control |
| `IndBanach.lean:434` | `tendsto_indBanach_iff` (forward) | Open | LF-space regularity |

#### Why these cannot be closed with current infrastructure:

**Weil Explicit Formula** (items 2-3): Both directions of Weil's criterion
require the explicit formula connecting the concrete Weil distribution
(defined by the von Mangoldt sum) to the spectral side (sum over zeros
of ζ). This fundamental theorem of analytic number theory is not
formalized in Mathlib.

**CompleteSpace** (item 4): The `decayNorm` on `ExpDecayClass b` only
controls function values via the weighted sup norm `sup_t |g(t)| exp((1/2+b)|t|)`.
It does NOT control derivatives. A Cauchy sequence in this norm converges
uniformly to a continuous function with exponential decay, but this limit
need not be smooth (Schwartz). Proving completeness would require either
extending the norm to include derivative control or showing the limit
preserves Schwartz regularity, both of which are substantial.

**LF-space regularity** (item 6): The forward direction of `tendsto_indBanach_iff`
asserts that convergence in the ind-Banach topology implies the sequence
eventually lives in a single E_b. This is the "regularity" property of
LF-spaces, which requires the family {E_b} to be a strict inductive system.
No Mathlib infrastructure for LF-spaces exists.

### Architecture Overview

```
Main.lean ──────────── WeilTestFunction.lean ──── ContinuityHelpers.lean
    │                       │                          │
    │                       │                    ConjectureA.lean
    │                       │                          │
AutocorrSmooth.lean    IndBanach.lean ◄────────────────┘
                            │
ZetaConj.lean          HermiteBiehler.lean
                            
DulaTheorem.lean       ConvolutionContinuity.lean
```

### Two Routes to RH

1. **Schwartz topology route** (ConjectureA.lean):
   `Conjecture_A_Strong_WTF → RH` via continuity in Schwartz topology.
   **BLOCKED**: Component 2 continuity is false in this topology.

2. **Ind-Banach topology route** (IndBanach.lean):
   `Conjecture_A_Strong_WTF_indBanach → RH` via continuity in ind-Banach topology.
   **PARTIALLY RESOLVED**: Continuity is proved! Remaining dependency
   is `WeilCriterion_WTF` (the explicit formula).
