import Mathlib
import RequestProject.Main
import RequestProject.ContinuityHelpers

open Real MeasureTheory Filter Topology
open scoped BigOperators

noncomputable section

-- ============================================================================
-- 1. THE COHN–ELKIES CONDITION
-- ============================================================================

/-- A radial auxiliary function satisfying the Cohn–Elkies conditions. -/
structure CohnElkiesFunction (n : ℕ) where
  h : ℝ → ℝ
  h_hat : ℝ → ℝ
  pos_at_origin : h 0 > 0
  nonpos_beyond : ∀ r : ℝ, r ≥ Real.sqrt (2 * n / (n - 1) : ℝ) → h r ≤ 0
  fourier_nonneg : ∀ t : ℝ, h_hat t ≥ 0
  root_at_contact : h (Real.sqrt (2 * n / (n - 1) : ℝ)) = 0
  deriv_root_at_contact : deriv h (Real.sqrt (2 * n / (n - 1) : ℝ)) = 0

-- ============================================================================
-- 2. THE WEAK FORM
-- ============================================================================

def Conjecture_A_Weak : Prop :=
  ∃ Φ : CohnElkiesFunction 24 → EvenSchwartz,
    ∀ f : CohnElkiesFunction 24,
      WeilDistribution (autocorrelation (Φ f)) ≥ 0

-- ============================================================================
-- 3. THE STRONG FORM
-- ============================================================================

def Conjecture_A_Strong : Prop :=
  ∃ (Φ : CohnElkiesFunction 24 → ℕ → EvenSchwartz)
    (f₂₄ : CohnElkiesFunction 24),
    (∀ n : ℕ, WeilDistribution (autocorrelation (Φ f₂₄ n)) ≥ 0) ∧
    (∀ g : EvenSchwartz, ∃ φ : ℕ → ℕ,
      Filter.Tendsto (fun k => Φ f₂₄ (φ k)) Filter.atTop
        (nhds g))

-- ============================================================================
-- 4. THE CONTINUITY LEMMA
-- ============================================================================

/-- Continuity of the Weil functional on autocorrelations. -/
theorem weilDistribution_autocorrelation_continuous :
    Continuous (fun g : EvenSchwartz => WeilDistribution (autocorrelation g)) :=
  weilDistribution_autocorrelation_continuous'

-- ============================================================================
-- 5. THE CONDITIONAL MAIN THEOREM
-- ============================================================================

/-- If Conjecture A (strong form) holds, then RH follows. -/
theorem conjecture_a_strong_implies_rh :
    Conjecture_A_Strong → RiemannHypothesis := by
  intro hA
  rw [← WeilCriterion]
  intro g
  obtain ⟨Φ, f₂₄, hPos, hDense⟩ := hA
  obtain ⟨φ, hφ⟩ := hDense g
  set F : EvenSchwartz → ℝ :=
    fun h => WeilDistribution (autocorrelation h) with hF_def
  have h_seq_nonneg : ∀ k : ℕ, 0 ≤ F (Φ f₂₄ (φ k)) := by
    intro k; simp only [hF_def]; exact hPos (φ k)
  have hF_cont : Continuous F := weilDistribution_autocorrelation_continuous
  have h_lim : Filter.Tendsto (fun k => F (Φ f₂₄ (φ k)))
      Filter.atTop (nhds (F g)) :=
    (hF_cont.tendsto g).comp hφ
  exact ge_of_tendsto' h_lim h_seq_nonneg

end
