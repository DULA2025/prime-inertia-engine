# DULA Project Status

## Sorry inventory (3 total)

1. `spectralSide_autocorr_nonneg_WTF` (WeilTestFunction.lean) — Deep Weil 1952
2. `weilPositivity_wtf_implies_rh` (WeilTestFunction.lean) — Deep Weil 1952
3. `weil_component2_continuous_WTF` (ContinuityHelpers.lean) — KNOWN FALSE

## Honest assessment

- Sorrys 1–2 are research-frontier (Weil's 1952 explicit-formula directions).
- Sorry 3 is provably false in the current Schwartz-subspace topology on WTF
  (counterexample documented in the docstring of `weil_component2_continuous_WTF`).
  The conditional reduction `Conjecture_A_Strong_WTF → RH` is therefore not
  formally valid, despite Lean accepting the proof (which uses sorry 3 as a premise).

## Required fix

Strengthen the WTF topology to include uniform decay-witness control,
then re-verify that the Cohn–Elkies density argument in
`Conjecture_A_Strong_WTF` works in the stronger topology. This is
non-trivial off-Lean math research.
