import Mathlib

set_option maxHeartbeats 800000

/-- The complete baryon octet. -/
inductive Baryon where
  | Neutron | SigmaMinus | XiMinus | XiZero | SigmaPlus | Proton
  | SigmaZero | Lambda
deriving Repr, DecidableEq

/-- Quantum numbers (I₃, S, Q) attached to each baryon. -/
def baryonQuantumNumbers : Baryon → Rat × Int × Int
  | Baryon.Neutron    => (-1/2, 0, 0)
  | Baryon.SigmaMinus => (-1, -1, -1)
  | Baryon.XiMinus    => (-1/2, -2, -1)
  | Baryon.XiZero     => (1/2, -2, 0)
  | Baryon.SigmaPlus  => (1, -1, 1)
  | Baryon.Proton     => (1/2, 0, 1)
  | Baryon.SigmaZero  => (0, -1, 0)
  | Baryon.Lambda     => (0, -1, 0)

/-- Standalone recursive helper: accumulates net phase along Collatz orbit. -/
def netPhase.go (m : Nat) (acc : Int) (fuel : Nat) : Int :=
  if fuel = 0 ∨ m = 1 then acc
  else if m % 2 = 0 then netPhase.go (m / 2) (acc - 1) (fuel - 1)
  else netPhase.go (3 * m + 1) (acc + 1) (fuel - 1)
termination_by fuel

/-- Standalone recursive helper: counts orbit length with bounded fuel. -/
def orbitLength.go (m : Nat) (fuel : Nat) : Nat :=
  if fuel = 0 ∨ m = 1 then 0
  else if m % 2 = 0 then 1 + orbitLength.go (m / 2) (fuel - 1)
  else 1 + orbitLength.go (3 * m + 1) (fuel - 1)
termination_by fuel

/-- Standalone recursive helper: 2-adic valuation with bounded fuel. -/
def twoAdicVal.go (m : Nat) (acc : Nat) (fuel : Nat) : Nat :=
  if fuel = 0 ∨ m = 0 ∨ m % 2 ≠ 0 then acc
  else twoAdicVal.go (m / 2) (acc + 1) (fuel - 1)
termination_by fuel

/-- True orbit length of the Collatz sequence from n to 1.
    Uses the Collatz-recursive structure; termination is assumed (Collatz conjecture). -/
def trueOrbitLength : Nat → Nat
  | 0 => 0
  | 1 => 0
  | m => if m % 2 = 0 then 1 + trueOrbitLength (m / 2)
         else 1 + trueOrbitLength (3 * m + 1)
decreasing_by all_goals sorry

/-- Sum of Collatz signs (+1 for odd step, -1 for even step) along the orbit from n to 1.
    Uses the Collatz-recursive structure; termination is assumed (Collatz conjecture). -/
def collatzSignSum : Nat → Int
  | 0 => 0
  | 1 => 0
  | m => if m % 2 = 0 then collatzSignSum (m / 2) - 1
         else collatzSignSum (3 * m + 1) + 1
decreasing_by all_goals sorry

/-- Convert an integer to Fin 6 via Euclidean mod. -/
def Int.toFin6 (x : Int) : Fin 6 :=
  ⟨(x % 6).toNat, by
    have h1 := Int.emod_nonneg x (by norm_num : (6 : Int) ≠ 0)
    have h2 := Int.emod_lt_of_pos x (by norm_num : (6 : Int) > 0)
    omega⟩

/-- Net phase of n in the baryon octet, computed from the Collatz orbit. -/
def netPhase (n : Nat) : Fin 6 :=
  Int.toFin6 (netPhase.go n 0 (trueOrbitLength n))

/-- Map from phase index (Fin 6) to the corresponding outer baryon. -/
def baryonFromPhase : Fin 6 → Baryon
  | 0 => Baryon.Neutron
  | 1 => Baryon.SigmaMinus
  | 2 => Baryon.XiMinus
  | 3 => Baryon.XiZero
  | 4 => Baryon.SigmaPlus
  | 5 => Baryon.Proton

/-- Expected quantum-number weights for each phase index. -/
def expectedWeights : Fin 6 → Rat × Int × Int
  | 0 => (-1/2, 0, 0)
  | 1 => (-1, -1, -1)
  | 2 => (-1/2, -2, -1)
  | 3 => (1/2, -2, 0)
  | 4 => (1, -1, 1)
  | 5 => (1/2, 0, 1)

/-- Whether the input triggers the central (Σ⁰/Λ) branch. -/
def dropTrigger (n : Nat) : Bool := twoAdicVal.go n 0 64 ≥ 2

/-- Isospin tag used to distinguish Σ⁰ from Λ in the central branch. -/
def isospinTag (n : Nat) : Bool := Nat.Prime n

/-- Full projection: maps n to a baryon via the outer (phase) or central branch. -/
def primeInertiaProjection (n : Nat) : Baryon :=
  if dropTrigger n then
    if isospinTag n then Baryon.SigmaZero else Baryon.Lambda
  else
    baryonFromPhase (netPhase n)

/-! ## Helper unfolding lemmas -/

/-- Unfolding trueOrbitLength for m ≥ 2. -/
lemma trueOrbitLength_unfold (m : Nat) (hm0 : m ≠ 0) (hm1 : m ≠ 1) :
    trueOrbitLength m = if m % 2 = 0 then 1 + trueOrbitLength (m / 2)
      else 1 + trueOrbitLength (3 * m + 1) :=
  trueOrbitLength.eq_3 m (fun h => hm0 h) (fun h => hm1 h)

/-- Unfolding collatzSignSum for m ≥ 2. -/
lemma collatzSignSum_unfold (m : Nat) (hm0 : m ≠ 0) (hm1 : m ≠ 1) :
    collatzSignSum m = if m % 2 = 0 then collatzSignSum (m / 2) - 1
      else collatzSignSum (3 * m + 1) + 1 :=
  collatzSignSum.eq_3 m (fun h => hm0 h) (fun h => hm1 h)

/-- trueOrbitLength m > 0 when m ≥ 2. -/
lemma trueOrbitLength_pos (m : Nat) (hm0 : m ≠ 0) (hm1 : m ≠ 1) :
    trueOrbitLength m > 0 := by
  rw [trueOrbitLength_unfold m hm0 hm1]; split <;> omega

/-- Unfolding trueOrbitLength for m ≥ 2 (even case). -/
lemma trueOrbitLength_even (m : Nat) (hm0 : m ≠ 0) (hm1 : m ≠ 1) (heven : m % 2 = 0) :
    trueOrbitLength m = 1 + trueOrbitLength (m / 2) := by
  rw [trueOrbitLength_unfold m hm0 hm1, if_pos heven]

/-- Unfolding trueOrbitLength for m ≥ 2 (odd case). -/
lemma trueOrbitLength_odd (m : Nat) (hm0 : m ≠ 0) (hm1 : m ≠ 1) (hodd : m % 2 ≠ 0) :
    trueOrbitLength m = 1 + trueOrbitLength (3 * m + 1) := by
  rw [trueOrbitLength_unfold m hm0 hm1, if_neg hodd]

/-- Unfolding collatzSignSum for m ≥ 2 (even case). -/
lemma collatzSignSum_even (m : Nat) (hm0 : m ≠ 0) (hm1 : m ≠ 1) (heven : m % 2 = 0) :
    collatzSignSum m = collatzSignSum (m / 2) - 1 := by
  rw [collatzSignSum_unfold m hm0 hm1, if_pos heven]

/-- Unfolding collatzSignSum for m ≥ 2 (odd case). -/
lemma collatzSignSum_odd (m : Nat) (hm0 : m ≠ 0) (hm1 : m ≠ 1) (hodd : m % 2 ≠ 0) :
    collatzSignSum m = collatzSignSum (3 * m + 1) + 1 := by
  rw [collatzSignSum_unfold m hm0 hm1, if_neg hodd]

/-! ## Main lemmas -/

/-
Helper: `netPhase.go m acc f = acc + collatzSignSum m` when fuel is sufficient.
-/
lemma netPhase_go_eq_signSum (m : Nat) (acc : Int) (f : Nat)
    (hm : m ≠ 0) (hf : f ≥ trueOrbitLength m) :
    netPhase.go m acc f = acc + collatzSignSum m := by
  -- We'll use induction on $f$ to prove the equality.
  induction' f with k ih generalizing m acc;
  · contrapose! hf;
    exact trueOrbitLength_pos m hm ( by rintro rfl; exact hf <| by unfold netPhase.go collatzSignSum; simp +decide );
  · by_cases hm1 : m = 1;
    · unfold netPhase.go collatzSignSum; aesop;
    · by_cases heven : m % 2 = 0;
      · rw [ netPhase.go.eq_def ];
        have := trueOrbitLength_even m hm hm1 heven; simp_all +decide ;
        rw [ ih _ _ ( Nat.ne_of_gt ( Nat.div_pos ( Nat.le_of_dvd ( Nat.pos_of_ne_zero hm ) ( Nat.dvd_of_mod_eq_zero heven ) ) zero_lt_two ) ) ( by linarith ) ] ; rw [ collatzSignSum_even _ hm hm1 heven ] ; ring;
      · rw [ netPhase.go.eq_def ] ; simp +decide [ heven ];
        rw [ if_neg hm1, ih ];
        · rw [ collatzSignSum_odd m hm hm1 heven ] ; ring;
        · positivity;
        · rw [ trueOrbitLength_odd ] at hf <;> omega

/-- Lemma 1: Phase Correctness – `netPhase n` equals the sign-sum mod 6. -/
lemma netPhase_correct (n : Nat) (h : n > 0) :
    netPhase n = Int.toFin6 (collatzSignSum n) := by
  unfold netPhase
  congr 1
  have hn : n ≠ 0 := by omega
  exact netPhase_go_eq_signSum n 0 (trueOrbitLength n) hn le_rfl |>.trans (by ring)

/-- Lemma 2: Weight Fidelity (Outer Vertices) -/
lemma weight_fidelity_outer (φ : Fin 6) :
    baryonQuantumNumbers (baryonFromPhase φ) = expectedWeights φ := by
  fin_cases φ <;> rfl

/-- Lemma 3: Central Population Correctness -/
lemma central_population (n : Nat) (h : dropTrigger n = true) :
    let b := primeInertiaProjection n
    (b = Baryon.SigmaZero → isospinTag n = true) ∧
    (b = Baryon.Lambda → isospinTag n = false) := by
  simp only [primeInertiaProjection, h, ite_true]
  split <;> simp_all

/-- Lemma 4: Fuel Independence (Invariance) -/
/- Note: n > 0 is required because `netPhase.go` does not halt at m = 0;
   for m = 0 the result depends on fuel (netPhase.go 0 0 f = -f). -/
lemma projection_invariance (n : Nat) (f1 f2 : Nat)
    (hn : n > 0)
    (h1 : f1 ≥ trueOrbitLength n) (h2 : f2 ≥ trueOrbitLength n) :
    netPhase.go n 0 f1 = netPhase.go n 0 f2 := by
  have hne : n ≠ 0 := by omega
  rw [netPhase_go_eq_signSum n 0 f1 hne h1, netPhase_go_eq_signSum n 0 f2 hne h2]