# Verification of the unnormalized statement `LPositivity`

**Conclusion: `LPositivity` is false.**  It has been refuted in Lean
(`not_LPositivity`, `RequestProject/UnnormalizedCounterexample.lean`), and the numerical
evaluation requested below agrees with the refutation.

## 1. What was evaluated

Using the project's own definitions — `Dcomplex`, `WeilR` / `Winfty`, `ofLog`, `convLog`,
`starLog`, `deltaHalfInv`, `delta` — two functionals were evaluated on the same inputs:

* the **unnormalized** functional of `LPositivity`,
  `Lfun (ofLog f) = Dcomplex (ofLog f) + Winfty (ofLog f)`, i.e. both terms paired with the
  same test function;
* the **normalized** functional of the paper,
  `LfunNorm f = Dcomplex (ofLog f) + Winfty (deltaHalfInv (ofLog f))`.

The test functions are the convolution squares `f = G ⋆ G̃` (in the logarithmic
coordinate, `convLog G (starLog G)`) of the triangular bump `G(t) = max(0, 1 - |t|/w)` of
half width `w`.  These `f` are exactly the `convLog G (starLog G)` of the project: real,
even, nonnegative, supported in `[-2w, 2w]`, with the closed form
`f(t) = w g(|t|/w)`, `g(u) = 2/3 - u² + u³/2` on `[0,1]` and `g(u) = (2-u)³/6` on `[1,2]`.

With `f` real and even the two functionals reduce (change of variables `x = e^t`) to

```
D              = ∫_ℝ f(t) δ(e^t) dt
W_ℝ(unnorm)    = (log 4π + γ) f(0) + ∫₀^∞ [(1+e^{-t}) f(t) - 2 e^{-t} f(0)]/(1-e^{-2t}) dt
W_ℝ(norm)      = (log 4π + γ) f(0) + ∫₀^∞ [2 e^{-t/2} f(t) - 2 e^{-t} f(0)]/(1-e^{-2t}) dt
L              = D - W_ℝ ,
```

so that, for `f ≥ 0`,

```
L(unnormalized) = L(normalized) - ∫₀^∞ f(t) (1-e^{-t/2})²/(1-e^{-2t}) dt  ≤  L(normalized).
```

The subtracted term is the **deficit**; it is the object proved (in Lean, in general form)
in `WeilR_ofLog_eq_add_deficit`.

## 2. Numerical values

Computed by `scripts/unnormalized_check.py` (pure-Python composite 10-point
Gauss–Legendre quadrature; `Si` from its power series for `x ≤ 4` and from the standard
rational approximations of the auxiliary functions beyond).  These values are a *numerical*
check, not a machine-checked computation; the machine-checked statement is
`not_LPositivity`.  The last column is the residual of the deficit identity above and
confirms the internal consistency of the three integrals to ~1e-13.

```
   w      f(0)       D          W_∞(unnorm)   L(unnorm)     W_∞(norm)    L(norm)     deficit    check
 0.25   0.1667     0.140388     -0.112889     0.027499     -0.112393     0.027995   0.000496  -1.1e-15
 0.50   0.3333     0.508246     -0.489893     0.018353     -0.485623     0.022623   0.004270  -9.7e-17
 1.00   0.6667     1.578247     -1.581281    -0.003033     -1.542933     0.035314   0.038348  -1.2e-15
 2.00   1.3333     4.417194     -4.697881    -0.280688     -4.350610     0.066584   0.347271  -1.7e-15
 3.00   2.0000     7.755524     -8.867667    -1.112143     -7.656644     0.098880   1.211023  -8.7e-15
 4.00   2.6667    11.339052    -14.037591    -2.698539    -11.207655     0.131397   2.829936  -4.4e-16
 6.00   4.0000    18.793393    -27.349604    -8.556210    -18.596757     0.196636   8.752846  -1.2e-14
 8.00   5.3333    26.338379    -44.630693   -18.292315    -26.076406     0.261972  18.554287   1.1e-13
```

Reading of the table, for the four requested half widths `w ∈ {0.5, 1, 2, 3}` (and beyond):

* the **unnormalized** functional is `+0.0184` at `w = 0.5`, already **negative** at
  `w = 1` (`-0.0030`), and then decisively negative: `-0.28` at `w = 2`, `-1.11` at
  `w = 3`, `-18.3` at `w = 8`.  It behaves like `-w²/2` for large `w`, because the deficit
  is asymptotically `∫₀^∞ f = w²/2` while `D` and the normalized term only grow linearly.
* the **normalized** functional `LfunNorm` is positive throughout (`0.0226`, `0.0353`,
  `0.0666`, `0.0989`, …), exactly as the proved theorem `LPositivityNorm_holds` requires,
  and grows linearly in `w`.

So the unnormalized functional takes clearly negative values, and `LPositivity` is false.

## 3. The Lean refutation

`RequestProject/UnnormalizedCounterexample.lean` contains a `sorry`-free proof.  Rather
than certifying the numerical integrals above, it uses crude but rigorous bounds, which
force a larger (explicit) width:

* `WeilR_ofLog` — the distribution (150) applied to `f = G ∘ log` itself, in the
  logarithmic coordinate (the counterpart of the existing `WeilR_deltaHalfInv_ofLog`);
* `WeilR_ofLog_eq_add_deficit` — the exact deficit identity recalled above;
* `deficitKernel_ge` — the deficit kernel is `≥ 1/8` on `[1,∞)`;
* `Dcomplex_ofLog_re_le` — `Re D ≤ 16 Si π + 16` for test functions with values in `[0,1]`
  (from `δ(e^t) ≤ (4 Si π + 4) e^{-|t|/2}`);
* `WeilR_deltaHalfInv_ofLog_value` and `norm_integral_sub_mul_sinhKernel_le` — the
  normalized archimedean term equals `c₀ f(0) - S` with `‖S‖ ≤ 40 C` for a `C`-Lipschitz
  test function;
* `positiveDefiniteLog_triC` — the triangular bump is positive definite (its Fourier
  transform is the Fejér kernel `2(1 - cos wx)/(w x²) ≥ 0`, computed in
  `integral_triReal_mul_cos_eq`);
* `L_real_triC_neg` and `not_LPositivity` — the conclusion.

The triangular bump itself is used as the test function (it is positive definite, so it is
admissible for `LPositivity` without having to exhibit it as a convolution square).

## 4. Consequences for the rest of the project

None of the proved results changes.  `LPositivity` is not the statement of the paper: the
paper applies the archimedean distribution to `∆^{-1/2} f`, and the corresponding
positivity (Corollary 2.3 (i)) is proved unconditionally in
`RequestProject/NormalizedPositivity.lean` (`LPositivityNorm_holds`).  The results of
`RequestProject/Positivity.lean` that carry `LPositivity` as an explicit hypothesis are now
known to be vacuous as stated; each has an unconditional counterpart, in the normalization
of the paper, in `RequestProject/NormalizedPositivity.lean`.
