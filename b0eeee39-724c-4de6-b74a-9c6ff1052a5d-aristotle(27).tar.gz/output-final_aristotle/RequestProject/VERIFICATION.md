# Verification note

Two verification tasks were carried out on the finished analytic part of the project:

1. an **axiom audit** of the four headline theorems, and
2. a **normalization check** of the `∆^{1/2}` convention used by `LfunNorm` /
   `LPositivityNorm` against the convention of Connes–Consani, *Weil positivity and Trace
   formula – the archimedean place*, arXiv:2006.13771.

Both checks succeed.  The audit was subsequently extended, in three further passes, to the
operator-theoretic modules (§4), the trace-density modules (§5) and the renormalized-trace
programme (§6); all of them pass as well.  Details follow.

*Reading note.*  Sections §1–§5 were written as the corresponding parts of the project were
finished, and a few of their remarks were overtaken by later work; each such place is
marked, and §6 gives the current state.  In particular the project now contains **no live
`sorry` at all** — the statement `L_positive` mentioned in §1 and §3 was withdrawn and
refuted — and the *renormalized* trace formula, described in §5 as not formalized, has
since been proved in the full-line model (§6).

---

## 1. Axiom audit

The audit is reproducible: `RequestProject/AxiomAudit.lean` contains the five
`#print axioms` commands, so the output below is regenerated on every build of that
module.  Verbatim output (Lean 4.28.0, Mathlib `v4.28.0`):

```
info: RequestProject/AxiomAudit.lean:22:0: 'ConnesConsani.WeilPositivity.fourierSide_nonneg' depends on axioms: [propext, Classical.choice, Quot.sound]
info: RequestProject/AxiomAudit.lean:23:0: 'ConnesConsani.WeilPositivity.two_thetaDeriv_add_deltaFourier_nonneg' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
info: RequestProject/AxiomAudit.lean:24:0: 'ConnesConsani.WeilPositivity.LfunNorm_re_nonneg_convLog_starLog' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
info: RequestProject/AxiomAudit.lean:25:0: 'ConnesConsani.WeilPositivity.LfunNorm_re_nonneg_contDiff_four' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
info: RequestProject/AxiomAudit.lean:26:0: 'ConnesConsani.WeilPositivity.LPositivityNorm_holds' depends on axioms: [propext, Classical.choice, Quot.sound]
```

(The line breaks inside the second, third and fourth lists are only Lean's pretty-printer
wrapping the output; the three axioms are the same in all five cases.)

**Result: PASS.**  Each of the four headline results (five declarations: the two names of
the Fourier-side inequality, the convolution-square form of Corollary 2.3 (i), and the two
names of its `C⁴` form) depends on exactly the three standard axioms `propext`,
`Classical.choice`, `Quot.sound`.  In particular `sorryAx` does **not** appear, so none of
them uses, directly or transitively, the statement `L_positive` that was still open at the
time of this audit (`RequestProject/Positivity.lean`; it has since been withdrawn and
refuted, see §2.4 and §6); neither does `Lean.ofReduceBool` appear, so no `native_decide`
is involved, and there is no project-specific axiom (the project declares none).

Supporting facts checked at the same time:

* a full `lake build` of all project modules (8287 jobs at the time) completes with no
  errors; the only warnings were `declaration uses 'sorry'` at
  `RequestProject/Positivity.lean` (`L_positive`) and Lake's `manifest out of date` notice
  about the local checkout of Mathlib.  That last `sorry` has since disappeared: see §6;
* a search over the sources finds no other live `sorry`: the occurrences in
  `FourierSide.lean` are inside `/- ... -/` comment blocks, and the ones in
  `Skeleton.lean` belong to the transcription of the original informal skeleton.

---

## 2. Normalization check: the `∆^{1/2}` convention

### 2.1 What the paper prescribes

*Introduction, p. 2* (definition of the convention):

> In order to reflect the unitarity of the scaling action it is convenient to use the
> automorphism of `C_c^∞(ℝ*₊)`, `f ↦ ∆^{1/2} f`, `∆^{1/2} f(x) := x^{1/2} f(x)` which
> replaces the involution `f ↦ f̄^♯` by the involution `f ↦ f*` of the convolution
> `C*`-algebra and the restriction of the Mellin transform to the critical line by the
> Fourier transform (see Appendix A).  **We let, for any place `v`,
> `W_v(f) := W_v(∆^{-1/2} f)`, `∀ f ∈ C_c^∞(ℝ*₊)`.**

(In the paper the left-hand side carries the decorated symbol of the normalized
distribution; the right-hand side is the unnormalized one of Appendix B.)

*Appendix A, formula (145)*: `k ↦ ∆^{1/2}(k) = f`, `f(x) := x^{1/2} k(x)`.

*Appendix B, formula (150)* (the unnormalized archimedean distribution):

> `W_ℝ(f) := (log 4π + γ) f(1) + ∫₁^∞ ( f(x) + f^♯(x) − 2 f(1)/x ) dx/(x − x^{-1})`.

*§1, after formula (39), p. 11* (the coherence computation, which is the paper's own check
of the convention):

> One checks that (39) is coherent with the equality `W_ℝ(f) = W_ℝ(∆^{-1/2} f)`, we
> compare with (150) of Appendix B.  One has (assuming for simplicity `f(1) = 0`)
> `W_ℝ(f) = ∫₀^∞ f(ρ^{-1}) τ(ρ) d*ρ = ∫₀^∞ τ(ρ) f(ρ) d*ρ`.
> For `ρ > 1` one has `τ(ρ) = ρ^{3/2}/(ρ² − 1)` by (39) and with `k = ∆^{-1/2} f`,
> `k(u) = u^{-1/2} f(u)`,
> `∫₁^∞ ρ^{3/2}/(ρ²−1) f(ρ) d*ρ = ∫₁^∞ ρ^{1/2}/(ρ²−1) f(ρ) dρ = ∫₁^∞ k(x) dx/(x − x^{-1})`.

Here `(39)` is `τ(ρ) = (ρ^{1/2}/2) ( 1/(1+ρ) + 1/|1−ρ| )`.

*§2, Corollary 2.3* (the statement that is formalized):

> (i) The following functional is positive on the convolution algebra `C_c^∞(ℝ*₊)`:
> `L(f) = ∫ f(ρ^{-1}) (δ(ρ) − τ(ρ)) d*ρ`  (51).
> (ii) The function `2θ'(t) + δ̂(t)` is non-negative, where
> `δ̂(t) := ∫_{ℝ*₊} δ(ρ) ρ^{-it} d*ρ`.

with, in the proof, the Parseval identity

> `L(f) = ∫ f̂(t) ( 2∂_t θ(t) + δ̂(t) ) dt/(2π)`  (52).

So in the paper the *same* function `f` — the one that is positive definite for the
Fourier transform, i.e. the one in the `∆^{1/2}` picture — is paired with `δ` directly and
with `τ`, and `∫ f(ρ^{-1}) τ(ρ) d*ρ` is precisely formula (150) evaluated at `∆^{-1/2} f`.

### 2.2 What the formalization defines

`RequestProject/WeilDistribution.lean`:

```lean
/-- The involution `f ↦ f♯`, `f♯(x) = x⁻¹ f(x⁻¹)`, of the introduction of the paper. -/
def sharp (f : ℝ → ℂ) : ℝ → ℂ := fun x => (x : ℂ)⁻¹ * f x⁻¹

/-- The archimedean Weil distribution `W_ℝ`, formula (150) of arXiv:2006.13771:
`W_ℝ(f) = (log 4π + γ) f(1) + ∫₁^∞ (f(x) + f♯(x) - 2f(1)/x) dx/(x - x⁻¹)`. -/
def WeilR (f : ℝ → ℂ) : ℂ :=
  ((Real.log (4 * π) + Real.eulerMascheroniConstant : ℝ) : ℂ) * f 1 +
    ∫ x in Ioi (1:ℝ), (f x + sharp f x - 2 * f 1 / (x : ℂ)) / ((x : ℂ) - (x : ℂ)⁻¹)

/-- The archimedean term of the Weil explicit formula with the sign convention of the
paper: `W_∞ = -W_ℝ`. -/
def Winfty (f : ℝ → ℂ) : ℂ := -WeilR f

/-- The operator `∆^{-1/2} : f ↦ (x ↦ x^{-1/2} f(x))` used in the paper to make the
scaling action unitary. -/
def deltaHalfInv (f : ℝ → ℂ) : ℝ → ℂ := fun x => ((Real.sqrt x : ℝ) : ℂ)⁻¹ * f x
```

`RequestProject/Positivity.lean`:

```lean
/-- A function of the logarithmic variable `t`, read as a function of `ρ = e^t` on
`(0,∞)` (and extended by zero to the rest of the line). -/
def ofLog (G : ℝ → ℂ) : ℝ → ℂ := fun x => if 0 < x then G (Real.log x) else 0

/-- The functional `D` of the paper, `D(f) = ∫ f(ρ⁻¹) δ(ρ) d*ρ`, for complex valued test
functions on `ℝ⋆₊`. -/
def Dcomplex (f : ℝ → ℂ) : ℂ :=
  ∫ ρ : Rplus, f ((ρ : ℝ)⁻¹) * ((delta ρ : ℝ) : ℂ) ∂(Rplus.haar)
```

`RequestProject/ArchimedeanExplicit.lean`:

```lean
/-- **The functional `L = D + W_∞`** of §2 of the paper, in the logarithmic coordinate and
in the `∆^{1/2}` normalization: the archimedean term is the distribution (150) applied to
`∆^{-1/2} f`, as the paper prescribes. -/
def LfunNorm (G : ℝ → ℂ) : ℂ := Dcomplex (ofLog G) + Winfty (deltaHalfInv (ofLog G))
```

`RequestProject/NormalizedPositivity.lean`:

```lean
def LPositivityNorm : Prop :=
  ∀ G : ℝ → ℂ, ContDiff ℝ 4 G → HasCompactSupport G → PositiveDefiniteLog G →
    0 ≤ (LfunNorm G).re
```

### 2.3 Term-by-term comparison

| paper | formalization |
|---|---|
| `∆^{1/2}f(x) = x^{1/2}f(x)`, so `∆^{-1/2}f(x) = x^{-1/2}f(x)` (intro, (145)) | `deltaHalfInv f x = (√x)⁻¹ * f x` |
| `f^♯(x) = x^{-1} f(x^{-1})` | `sharp f x = x⁻¹ * f x⁻¹` |
| `W_ℝ(f)` of (150) | `WeilR` (transcribed symbol for symbol) |
| `W_v(f) := W_v(∆^{-1/2}f)` (intro) | `Winfty (deltaHalfInv ·)` in `LfunNorm` |
| `− ∫ f(ρ^{-1}) τ(ρ) d*ρ`, the `τ`-half of (51) | `Winfty (deltaHalfInv (ofLog G))`, since `Winfty = −WeilR` |
| `∫ f(ρ^{-1}) δ(ρ) d*ρ`, the `δ`-half of (51), applied to the *same* `f` | `Dcomplex (ofLog G)` — no `∆` factor, as in the paper |
| `L(f)` of (51) | `LfunNorm G` (with `f = G ∘ log`, i.e. `f(ρ) = G(log ρ)`) |
| `L(f) = ∫ f̂(t)(2θ'(t)+δ̂(t)) dt/2π`, (52) | `LfunNorm_parseval` |
| `W_ℝ(∆^{-1/2}f) = (2π)^{-1}∫ f̂(t)·2θ'(t)dt` (the `W`-half of (52)) | `WinftyParsevalNorm` / `Winfty_deltaHalfInv_ofLog` |
| Corollary 2.3 (i): `L ≥ 0` on positive definite `f` | `LfunNorm_re_nonneg_contDiff_four`, `LPositivityNorm_holds` |

The decisive point — that `WeilR ∘ deltaHalfInv` reproduces the `τ`-pairing of (51), and
not some other pairing — is checked in the formalization itself and can be read off two
theorems.

* `WeilR_explicit` (`RequestProject/WeilDistribution.lean`): for `f(1) = 0`,
  `W_ℝ(f) = ∫₁^∞ f(x)·x/(x²−1) dx + ∫₀¹ f(x)/(1−x²) dx`.
  Substituting `f := ∆^{-1/2}F` and passing to `d*x = dx/x` turns the first integral into
  `∫₁^∞ F(x)·x^{3/2}/(x²−1) d*x` and the second into `∫₀¹ F(x)·x^{1/2}/(1−x²) d*x`; by
  formula (39) of the paper these weights are exactly `τ(x)` for `x > 1` and for `x ≤ 1`
  respectively.  This is the paper's own coherence computation quoted in §2.1 above.
* `WeilR_deltaHalfInv_ofLog` (`RequestProject/ArchimedeanExplicit.lean`) states the same
  identity in the logarithmic coordinate `x = e^u`:
  `W_ℝ(∆^{-1/2}(G∘log)) = (log 4π + γ)G(0) + ∫₀^∞ (e^{u/2}(G(u)+G(−u)) − 2G(0)) du/(e^u−e^{-u})`,
  which is the paper's `∫₁^∞ k(x) dx/(x − x^{-1})` with `k = ∆^{-1/2}f`, written out with
  the `f^♯`-term (`G(−u)`) and the `f(1)`-subtraction restored.

Two harmless conventions are worth recording explicitly, since they are the only places
where the formalization is not a literal transcription:

* **Direction of the transform.**  The paper uses `f̂(s) = ∫₀^∞ f(u) u^{-is} d*u`
  (Appendix A), whereas `fourierLog G t = mellinLog G (I·t) = ∫_ℝ G(u) e^{iut} du`, i.e.
  `f̂(−t)`.  Since `2θ'` and `δ̂` are even (`thetaDeriv_even`, `deltaFourier_even`) and the
  `t`-integral in (52) runs over all of `ℝ`, the two conventions give the same value of
  `L`, and positive definiteness (`PositiveDefiniteLog`: `Re f̂ ≥ 0` on the unitary line)
  is likewise insensitive to it.
* **`δ̂` as a cosine transform.**  `deltaFourier t = ∫_ℝ δ(e^u) cos(tu) du` rather than
  `∫ δ(ρ)ρ^{-it}d*ρ`; the two agree because `δ(ρ^{-1}) = δ(ρ)` (`delta_symmetric`), which
  is Proposition 2.2 (ii) of the paper and a theorem here.

### 2.4 Conclusion

**Result: PASS — the conventions agree.**  `LfunNorm` (and hence `LPositivityNorm`) is the
functional `L` of formula (51)/(52) of Connes–Consani in the paper's own `∆^{1/2}`
normalization: the archimedean distribution (150) is applied to `∆^{-1/2}f`, exactly as the
introduction prescribes (`W_v(f) := W_v(∆^{-1/2}f)`), while the trace-remainder term pairs
`δ` with `f` itself.  Consequently `LfunNorm_re_nonneg_convLog_starLog`,
`LfunNorm_re_nonneg_contDiff_four` and `LPositivityNorm_holds` are statements of
Corollary 2.3 (i), and not of a differently normalized variant.

By contrast the older predicate `LPositivity` (`RequestProject/Positivity.lean`), built on
`Lfun f = Dcomplex f + Winfty f`, applies `W_ℝ` to `f` rather than to `∆^{-1/2}f`; it is
therefore *not* the statement of Corollary 2.3, which is why its `sorry` (`L_positive`) is
not needed by anything above and why the docstrings of `LPositivity` and `L_positive`
carry a normalization warning.

---

## 3. Status after the two checks (as of the freeze of the analytic part)

The analytic part of the archimedean place is **finished and frozen**:

* the Fourier-side inequality `2θ'(t) + δ̂(t) ≥ 0` holds for every real `t`
  (`fourierSide_nonneg`, `two_thetaDeriv_add_deltaFourier_nonneg`);
* Corollary 2.3 (i) holds unconditionally, both for convolution squares of `C²` test
  functions (`LfunNorm_re_nonneg_convLog_starLog`) and for all `C⁴` compactly supported
  positive definite test functions (`LfunNorm_re_nonneg_contDiff_four`,
  `LPositivityNorm_holds`);
* all of this rests on `propext`, `Classical.choice`, `Quot.sound` only.

The `sorry` that was still open at that point, `L_positive`, concerns the **unnormalized**
statement `Lfun = Dcomplex + Winfty` discussed in §2.4.  It is not the statement of the
paper, nothing in the results above depends on it, and it is not required by the paper's
subsequent arguments (§3 and later use the normalized functional, and the corresponding
consequences are already available unconditionally as
`Winfty_deltaHalfInv_nonneg_of_D_Qlog_nonpos_Icc`, `small_support_Winfty_deltaHalfInv_ge`
and `Winfty_deltaHalfInv_ge_effective`).  **Update.**  It has since been *disproved*
(`not_LPositivity`, `RequestProject/UnnormalizedCounterexample.lean`) and withdrawn, so the
project contains no live `sorry`.

---

## 4. Axiom audit of the operator-theoretic modules

`RequestProject/AxiomAudit.lean` was extended to cover the operator-theoretic results
added after the analytic part was frozen.  Each of

* `coeFn_fourierL2_of_integrable` (`RequestProject/FourierL2Integral.lean`),
* `hsNormSq_le_of_kernel` (`RequestProject/HilbertSchmidtKernel.lean`),
* `isHilbertSchmidt_P1hat_comp_P1` (`RequestProject/CutoffHilbertSchmidt.lean`),
* `thetaOpOf_testConv`, `adjoint_thetaOpOf`, `thetaOpOf_testConv_starTest_isPositive`
  (`RequestProject/LogPicture.lean`),
* `soninSandwich_isPositive`, `isTraceClass_soninSandwich`,
  `isTraceClass_thetaOp_soninSandwich`,
  `re_traceAlong_thetaOp_convSquare_soninSandwich_nonneg`,
  `LfunNorm_re_nonneg_of_normalizedTraceIdentity` (`RequestProject/TraceIdentityNorm.lean`)

depends on exactly `[propext, Classical.choice, Quot.sound]`; the output is regenerated on
every build of the audit module.  **Result: PASS.**

Two remarks on the last item.  `LfunNorm_re_nonneg_of_normalizedTraceIdentity` is a
*conditional* statement: it takes the trace identity `NormalizedTraceIdentity U` as an
explicit hypothesis (a `Prop`, not an axiom), so no unproved claim enters the environment.
And the paragraph closing §3 above is superseded: `L_positive` has since been **disproved**
(`not_LPositivity`, `RequestProject/UnnormalizedCounterexample.lean`) and removed, so the
project now contains no live `sorry` at all; the operator-theoretic development recorded
here targets the *normalized* identity, which is the one compatible with the paper.

---

## 5. Axiom audit of the trace-density modules, and the fixed-cut-off trace identity

`RequestProject/AxiomAudit.lean` was extended once more, to cover the modules that carry
out the identification of the trace functional:

* `range_weilMap`, `coeFn_weilMap_scaling` (`RequestProject/EvenPicture.lean`) — the
  paper's unitary `L²(ℝ⋆₊, d*ρ) ≃ L²(ℝ)_ev` and its intertwining property;
* `traceAlong_thetaOpOf_soninSandwich_eq_integral`,
  `normalizedTraceIdentity_iff_traceDensity` (`RequestProject/TraceDensity.lean`) — the
  local trace formula in kernel form, `Tr(ϑ(f) P₁P̂₁P₁) = ∫ f(λ) κ(λ) d*λ`, and the
  resulting reduction of the normalized trace identity to an identity of functions;
* `traceDensity_eq_hsInner`, `conj_traceDensity`, `continuous_traceDensity`
  (`RequestProject/TraceDensitySymmetry.lean`) — the Hilbert–Schmidt formula
  `κ(λ) = ⟪B, ϑ(λ)B⟫_HS`, the symmetry `κ(λ⁻¹) = conj κ(λ)` and the continuity of `κ`;
* `not_normalizedTraceIdentity` (`RequestProject/TraceIdentityObstruction.lean`).

Verbatim output (Lean 4.28.0, Mathlib `v4.28.0`), with the pretty-printer's line wrapping
removed:

```
'ConnesConsani.WeilPositivity.range_weilMap' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.coeFn_weilMap_scaling' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.traceAlong_thetaOpOf_soninSandwich_eq_integral' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.normalizedTraceIdentity_iff_traceDensity' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.traceDensity_eq_hsInner' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.conj_traceDensity' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.continuous_traceDensity' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.not_normalizedTraceIdentity' depends on axioms: [propext, Classical.choice, Quot.sound]
```

**Result: PASS.**  `lake build` of `RequestProject/Main.lean` completes successfully
(8296 jobs) with no `declaration uses 'sorry'` warning, and every audited declaration
depends on exactly `[propext, Classical.choice, Quot.sound]`.

The mathematical outcome of these modules is recorded in `RequestProject/Skeleton.lean`
("The trace identity with a fixed cutoff: resolution").  In brief: the trace functional of
the Sonin sandwich is integration against a *bounded continuous* trace density, hence is
continuous for the `L¹(d*λ)` norm, while the archimedean functional `L_Norm` is a
distribution of order one; the identity `L_Norm(f) = Tr(ϑ(f) P₁P̂₁P₁)` is therefore false
for every unitary identification of the two pictures.  It is the *renormalized* trace
formula — with the cutoff `Λ → ∞` and the `log Λ` subtraction — that is at stake in the
paper; it was not formalized at the time of this audit, and it is the subject of §6 below.
Accordingly the conditional statement
`LfunNorm_re_nonneg_of_normalizedTraceIdentity` of §4 is vacuous (its hypothesis is
unsatisfiable); it is superseded by the unconditional analytic positivity
`LfunNorm_re_nonneg_convLog_starLog` and `LPositivityNorm_holds`.

---

## 6. Axiom audit of the renormalized-trace programme, and the current build state

`RequestProject/AxiomAudit.lean` now also covers the results of the renormalized-trace
programme: the refutation of the pure-diagonal logarithmic hypothesis, the closed form and
the off-diagonal limit of the semi-local density, and the unconditional finite part of the
renormalized cut-off trace.  Verbatim output (Lean 4.28.0, Mathlib as pinned by
`lake-manifest.json`), with the pretty-printer's line wrapping removed:

```
'ConnesConsani.WeilPositivity.diagDensity_ge_quadratic' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.diagDensity_le_four_mul_sq' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.not_diagLogUpperBound' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.semiLocalDensity_eq_Si' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.tendsto_semiLocalDensity_scaling' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.weilPairing_eq_weilR_add_reflectionPairing' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.tendsto_modelCutTrace_LfunNorm' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.exists_hasCutoffLogProfile_refBump' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.exists_universal_finitePart_unconditional' depends on axioms: [propext, Classical.choice, Quot.sound]
'ConnesConsani.WeilPositivity.exists_universal_finitePart_LfunNorm' depends on axioms: [propext, Classical.choice, Quot.sound]
```

**Result: PASS.**  The audit module elaborates 55 `#print axioms` commands in total, and
every one of them reports exactly `[propext, Classical.choice, Quot.sound]`: no `sorryAx`,
no `Lean.ofReduceBool`, no project-specific axiom (the project declares none).

### Build state

A full `lake build` of the library — every module matched by the glob `RequestProject.+`,
i.e. `RequestProject/Main.lean` together with `RequestProject/AxiomAudit.lean` and
`RequestProject/A5Artin.lean` — reports

```
Build completed successfully (8321 jobs).
```

with **zero errors** and **zero `declaration uses 'sorry'` warnings**; the only warning
emitted is Lake's `manifest out of date` notice about the local checkout of Mathlib.  A
search over the sources finds the token `sorry` only inside comment blocks (see §2 of
`RequestProject/REPO_INVENTORY.md`).

### What the audited statements say

The mathematical content is recorded in `RequestProject/Skeleton.lean`, section *Status:
the renormalized-trace programme*.  In brief:

* the diagonal of the semi-local kernel satisfies `(8/π²)Λ² − 4/π² ≤ d(Λ) ≤ 4Λ²`, so the
  hypothesis `DiagLogUpperBound` (`d(Λ) ≤ 2 log Λ + O(1)`) is **false**: the logarithmic
  divergence of the cut-off trace is an averaged, not a diagonal, phenomenon;
* the semi-local density has the closed form
  `κ_Λ(a) = √a·(2/(π(a−1)))·Si(2π(a−1)Λ²/max(1,a))` and converges off the diagonal to the
  archimedean Weil kernel `λ^{1/2}/|1−λ|`;
* consequently, for every continuous compactly supported test function `f` that is
  Lipschitz at `λ = 1`, `Tr(ϑ(f) S^{(Λ)}) − 4 f(1) log Λ` converges, with limit
  `D(F) − L_Norm(F) + E(F) + f(1) z₁` (`F = logTest f`), for a universal constant `z₁`.

Two caveats are part of the statement, not of its proof: the coefficient of `log Λ` is
`4 f(1)` and not the paper's `2 f(1)`, and the odd-part term `E(F)` is present, both
because the model is the full line `L²(ℝ)` rather than the even (Sonin) subspace on which
the paper works.  The constant `z₁` multiplies only `f(1)` and is not evaluated in closed
form.
