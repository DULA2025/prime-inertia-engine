# Repository inventory

Snapshot of the Lean sources of this project, regenerated in the documentation and hygiene
pass.  No mathematical content was added or changed while writing it.

* Toolchain: Lean 4.28.0, Mathlib as pinned by `lean-toolchain` / `lake-manifest.json`.
* Build state at the time of writing: `lake build` (the whole library, i.e. every module
  matched by the glob `RequestProject.+`) reports `Build completed successfully (8321
  jobs)`, with no error and no `declaration uses 'sorry'` warning.
* The figures below are produced by `scripts/inventory.py`, which implements the counting
  conventions stated next; re-run it with `python3 scripts/inventory.py --table` to
  regenerate the table and the totals.

## Conventions used in the tables

* **Declarations** counts *top-level* declarations, i.e. lines that begin in column 0 with
  `def`, `theorem`, `lemma`, `instance`, `abbrev`, `structure`, `class`, `inductive`
  (optionally preceded by attributes and by modifiers such as `noncomputable`/`private`).
  Declarations occurring inside comments are **not** counted.
* **Sorries** counts occurrences of the token `sorry` in *code* only; occurrences inside
  comments and docstrings are excluded.  This matters for `RequestProject/Skeleton.lean`
  (which reproduces the original informal skeleton inside a comment), for
  `RequestProject/Positivity.lean` and for `RequestProject/FourierSide.lean` (which keep
  withdrawn statements inside comment blocks).
* Machine-generated families of files (the certified-quadrature pieces, blocks and
  frequency bands of the Pólya-model argument) are grouped into a single row.

## 1. Per-file inventory

| File | Lines | Declarations | Breakdown | Sorries |
|---|---:|---|---|---:|
| `RequestProject/A5Artin.lean` | 363 | 42 | abbrev 2, def 18, inductive 1, lemma 6, theorem 15 | 0 |
| `RequestProject/ArchimedeanExplicit.lean` | 860 | 41 | def 6, theorem 35 | 0 |
| `RequestProject/ArchimedeanKernel.lean` | 397 | 24 | def 4, theorem 20 | 0 |
| `RequestProject/ArchimedeanPositivity.lean` | 58 | 2 | theorem 2 | 0 |
| `RequestProject/AxiomAudit.lean` | 105 | 0 | — | 0 |
| `RequestProject/Basic.lean` | 140 | 18 | abbrev 1, def 3, instance 7, lemma 7 | 0 |
| `RequestProject/CompactInterval.lean` | 224 | 7 | theorem 7 | 0 |
| `RequestProject/CutoffExhaustion.lean` | 158 | 9 | def 1, theorem 8 | 0 |
| `RequestProject/CutoffFamily.lean` | 236 | 37 | def 5, theorem 32 | 0 |
| `RequestProject/CutoffFamilyHS.lean` | 220 | 15 | def 2, theorem 13 | 0 |
| `RequestProject/CutoffHilbertSchmidt.lean` | 193 | 15 | def 4, theorem 11 | 0 |
| `RequestProject/CutoffLogProfile.lean` | 736 | 42 | def 8, theorem 34 | 0 |
| `RequestProject/CutoffLogProfileAux.lean` | 233 | 18 | def 1, theorem 17 | 0 |
| `RequestProject/DeltaDecay.lean` | 470 | 14 | theorem 14 | 0 |
| `RequestProject/DeltaDecaySharp.lean` | 282 | 16 | theorem 16 | 0 |
| `RequestProject/DeltaFourierZero.lean` | 1194 | 62 | def 7, theorem 55 | 0 |
| `RequestProject/DeltaSmooth.lean` | 153 | 15 | def 3, theorem 12 | 0 |
| `RequestProject/DeltaVariation.lean` | 593 | 27 | def 1, theorem 26 | 0 |
| `RequestProject/DiagonalExact.lean` | 197 | 8 | theorem 8 | 0 |
| `RequestProject/DiagonalQuadraticGrowth.lean` | 574 | 31 | def 3, theorem 28 | 0 |
| `RequestProject/Digamma.lean` | 571 | 34 | def 3, theorem 31 | 0 |
| `RequestProject/DigammaAsymptotic.lean` | 397 | 17 | def 3, theorem 14 | 0 |
| `RequestProject/Dilation.lean` | 239 | 31 | def 4, theorem 27 | 0 |
| `RequestProject/Effective.lean` | 264 | 12 | theorem 12 | 0 |
| `RequestProject/EvenPicture.lean` | 471 | 34 | def 7, theorem 27 | 0 |
| `RequestProject/FourierDecay.lean` | 293 | 16 | theorem 16 | 0 |
| `RequestProject/FourierL2Integral.lean` | 153 | 6 | theorem 6 | 0 |
| `RequestProject/FourierSide.lean` | 443 | 25 | def 3, theorem 22 | 0 |
| `RequestProject/FourierSideAnalysis.lean` | 184 | 16 | def 3, theorem 13 | 0 |
| `RequestProject/GammaBound.lean` | 179 | 11 | def 1, theorem 10 | 0 |
| `RequestProject/HilbertSchmidtKernel.lean` | 91 | 3 | theorem 3 | 0 |
| `RequestProject/HilbertSchmidtPairing.lean` | 147 | 4 | theorem 4 | 0 |
| `RequestProject/JumpFormula.lean` | 370 | 11 | def 1, theorem 10 | 0 |
| `RequestProject/KernelBound.lean` | 439 | 32 | def 8, theorem 24 | 0 |
| `RequestProject/LogPicture.lean` | 197 | 23 | abbrev 1, def 3, theorem 19 | 0 |
| `RequestProject/Main.lean` | 120 | 0 | — | 0 |
| `RequestProject/Mellin.lean` | 333 | 28 | def 5, theorem 23 | 0 |
| `RequestProject/MidThreshold.lean` | 739 | 49 | def 7, theorem 42 | 0 |
| `RequestProject/NearDiagonalKernel.lean` | 629 | 44 | def 7, structure 1, theorem 36 | 0 |
| `RequestProject/NearOrigin.lean` | 884 | 49 | def 5, theorem 44 | 0 |
| `RequestProject/NormalizedPositivity.lean` | 217 | 17 | def 2, theorem 15 | 0 |
| `RequestProject/Parseval.lean` | 245 | 12 | def 2, theorem 10 | 0 |
| `RequestProject/PolyaError.lean` | 492 | 21 | def 1, theorem 20 | 0 |
| `RequestProject/PolyaErrorSharp.lean` | 381 | 17 | def 6, theorem 11 | 0 |
| `RequestProject/PolyaLinBand*.lean (128 files)` | 123264 | 4864 | theorem 4864 | 0 |
| `RequestProject/PolyaLinBlocks*.lean (4 files)` | 3080 | 37 | theorem 37 | 0 |
| `RequestProject/PolyaLinPieces*.lean (8 files)` | 7395 | 560 | theorem 560 | 0 |
| `RequestProject/PolyaLinThreshold.lean` | 927 | 1 | theorem 1 | 0 |
| `RequestProject/PolyaLinVbp*.lean (4 files)` | 2887 | 561 | theorem 561 | 0 |
| `RequestProject/PolyaLowBand*.lean (11 files)` | 7557 | 297 | theorem 297 | 0 |
| `RequestProject/PolyaLowBase.lean` | 126 | 4 | theorem 4 | 0 |
| `RequestProject/PolyaLowBlocks*.lean (4 files)` | 4003 | 66 | theorem 66 | 0 |
| `RequestProject/PolyaLowPieces*.lean (4 files)` | 1586 | 166 | theorem 166 | 0 |
| `RequestProject/PolyaLowTail.lean` | 95 | 6 | theorem 6 | 0 |
| `RequestProject/PolyaLowThreshold.lean` | 117 | 3 | theorem 3 | 0 |
| `RequestProject/PolyaLowVbp*.lean (2 files)` | 874 | 166 | theorem 166 | 0 |
| `RequestProject/PolyaModel.lean` | 274 | 16 | def 2, theorem 14 | 0 |
| `RequestProject/PolyaOscBand*.lean (27 files)` | 30537 | 1998 | theorem 1998 | 0 |
| `RequestProject/PolyaOscBase.lean` | 522 | 36 | def 5, theorem 31 | 0 |
| `RequestProject/PolyaOscBlocks*.lean (4 files)` | 1945 | 147 | theorem 147 | 0 |
| `RequestProject/PolyaOscLin.lean` | 612 | 31 | def 4, theorem 27 | 0 |
| `RequestProject/PolyaOscTail.lean` | 37 | 1 | theorem 1 | 0 |
| `RequestProject/PolyaOscThreshold.lean` | 268 | 5 | theorem 5 | 0 |
| `RequestProject/PolyaPartition*.lean (3 files)` | 3059 | 61 | theorem 61 | 0 |
| `RequestProject/PolyaThreshold.lean` | 185 | 8 | theorem 8 | 0 |
| `RequestProject/Positivity.lean` | 693 | 65 | def 15, theorem 50 | 0 |
| `RequestProject/QuarticDecay.lean` | 176 | 11 | theorem 11 | 0 |
| `RequestProject/RemainderBound.lean` | 258 | 7 | theorem 7 | 0 |
| `RequestProject/RenormalizedAsymptotics.lean` | 254 | 8 | def 1, theorem 7 | 0 |
| `RequestProject/RenormalizedDensityBound.lean` | 266 | 18 | theorem 18 | 0 |
| `RequestProject/RenormalizedDensitySymmetry.lean` | 120 | 7 | def 1, theorem 6 | 0 |
| `RequestProject/RenormalizedFinitePart.lean` | 445 | 26 | def 6, theorem 20 | 0 |
| `RequestProject/RenormalizedTrace.lean` | 258 | 26 | def 5, theorem 21 | 0 |
| `RequestProject/RenormalizedTraceDensity.lean` | 203 | 14 | def 3, theorem 11 | 0 |
| `RequestProject/RenormalizedTraceUniqueness.lean` | 171 | 9 | def 1, theorem 8 | 0 |
| `RequestProject/Scaling.lean` | 81 | 10 | abbrev 1, def 3, lemma 4, theorem 2 | 0 |
| `RequestProject/ScalingIntegrated.lean` | 183 | 23 | def 4, theorem 19 | 0 |
| `RequestProject/SemiLocalDiagonal.lean` | 284 | 19 | def 4, theorem 15 | 0 |
| `RequestProject/SemiLocalKernel.lean` | 266 | 21 | def 5, theorem 16 | 0 |
| `RequestProject/SemiLocalSi.lean` | 338 | 10 | theorem 10 | 0 |
| `RequestProject/SiAsymptotic.lean` | 345 | 20 | def 2, theorem 18 | 0 |
| `RequestProject/SiDivMono.lean` | 123 | 9 | def 1, theorem 8 | 0 |
| `RequestProject/SiPositivity.lean` | 474 | 24 | def 1, lemma 18, theorem 5 | 0 |
| `RequestProject/SiSharp.lean` | 231 | 10 | theorem 10 | 0 |
| `RequestProject/SiSmooth.lean` | 184 | 14 | def 2, theorem 12 | 0 |
| `RequestProject/SineIntegral.lean` | 312 | 21 | def 2, lemma 18, theorem 1 | 0 |
| `RequestProject/Skeleton.lean` | 2039 | 0 | — | 0 |
| `RequestProject/Sonin.lean` | 233 | 28 | abbrev 1, def 9, instance 1, lemma 4, theorem 13 | 0 |
| `RequestProject/SoninJoin.lean` | 158 | 27 | def 2, instance 2, theorem 23 | 0 |
| `RequestProject/SoninSandwich.lean` | 49 | 3 | theorem 3 | 0 |
| `RequestProject/TaylorBounds.lean` | 262 | 23 | def 5, theorem 18 | 0 |
| `RequestProject/TestConvolution.lean` | 190 | 18 | def 4, theorem 14 | 0 |
| `RequestProject/ThetaGrowth.lean` | 374 | 21 | theorem 21 | 0 |
| `RequestProject/TraceBasisIndep.lean` | 136 | 9 | def 1, theorem 8 | 0 |
| `RequestProject/TraceClass.lean` | 236 | 22 | def 5, theorem 17 | 0 |
| `RequestProject/TraceDensity.lean` | 366 | 26 | def 6, instance 3, theorem 17 | 0 |
| `RequestProject/TraceDensitySymmetry.lean` | 182 | 12 | def 1, theorem 11 | 0 |
| `RequestProject/TraceDivergence.lean` | 152 | 15 | def 2, theorem 13 | 0 |
| `RequestProject/TraceIdentityNorm.lean` | 220 | 21 | def 2, theorem 19 | 0 |
| `RequestProject/TraceIdentityObstruction.lean` | 380 | 19 | def 3, theorem 16 | 0 |
| `RequestProject/TracePositivity.lean` | 113 | 6 | theorem 6 | 0 |
| `RequestProject/TraceProperty.lean` | 85 | 4 | theorem 4 | 0 |
| `RequestProject/TraceRemainder.lean` | 343 | 25 | def 4, lemma 5, theorem 16 | 0 |
| `RequestProject/TraceScaling.lean` | 74 | 3 | theorem 3 | 0 |
| `RequestProject/UnnormalizedCounterexample.lean` | 677 | 38 | def 5, theorem 33 | 0 |
| `RequestProject/WeilDistribution.lean` | 160 | 11 | def 5, theorem 6 | 0 |
| `RequestProject/WeilKernelComparison.lean` | 341 | 19 | def 2, theorem 17 | 0 |

### Totals

| Quantity | Value |
|---|---:|
| Modules (`.lean` files under `RequestProject/`) | **295** |
| Total lines | **217649** |
| Total top-level declarations | **10711** |
| Total `sorry`s in code | **0** |

## 2. Sorries: there are none

The project contains **no `sorry` in code**.  The token occurs only inside comment blocks,
which record statements that were withdrawn or that are reproduced for historical reasons:

| Location | What the comment records |
|---|---|
| `RequestProject/Positivity.lean` | the withdrawn `L_positive : LPositivity`.  That statement is **false**: it is refuted in `RequestProject/UnnormalizedCounterexample.lean` (`not_LPositivity`, `L_real_triC_neg`) by an explicit triangular (Fejér) bump.  The definition `LPositivity` itself is kept, with the warning that it is not the pairing of Corollary 2.3 |
| `RequestProject/FourierSide.lean` | two commented-out statements: the transfer of the Fourier-side inequality to the unnormalized `LPositivity`, and the copy of `two_thetaDeriv_add_deltaFourier_nonneg` that used to live there before it was proved in `RequestProject/PolyaLowThreshold.lean` |
| `RequestProject/Skeleton.lean` | the original informal skeleton of the paper, reproduced verbatim inside a comment (it is pseudo-Lean and does not elaborate) |

The paper's statement (Corollary 2.3 (i)) is the positivity of the *normalized* functional
`LfunNorm`, proved unconditionally in `RequestProject/NormalizedPositivity.lean`
(`LPositivityNorm_holds`).  The numerical evaluation accompanying the refutation of the
unnormalized statement is recorded in `RequestProject/UNNORMALIZED_CHECK.md`.

`#print axioms` on the headline results — `fourierSide_nonneg`,
`two_thetaDeriv_add_deltaFourier_nonneg`, `LfunNorm_re_nonneg_convLog_starLog`,
`LfunNorm_re_nonneg_contDiff_four`, `LPositivityNorm_holds` — reports only
`propext, Classical.choice, Quot.sound`.  The audit is reproducible as the module
`RequestProject/AxiomAudit.lean`, and its verbatim output, together with the check of the
`∆^{1/2}` normalization against the paper, is recorded in `RequestProject/VERIFICATION.md`.

## 3. Status of the Fourier-side inequality

Throughout, `thetaDeriv t = θ'(t)`, `deltaFourier t = δ̂(t)` and
`fourierSide t = 2 * thetaDeriv t + deltaFourier t` (definitions in
`RequestProject/FourierSide.lean`).

**The inequality is proved for every real `t`:**

```
RequestProject/PolyaLowThreshold.lean
theorem fourierSide_nonneg (t : ℝ) : 0 ≤ fourierSide t
theorem two_thetaDeriv_add_deltaFourier_nonneg (t : ℝ) : 0 ≤ 2 * thetaDeriv t + deltaFourier t
```

It is assembled from three ranges, each `sorry`-free:

| Range | Theorem | File | Mechanism |
|---|---|---|---|
| `\|t\| ≤ 0.18` | `fourierSide_nonneg_of_abs_le` | `NearOrigin.lean` | spread comparison `Δ(t) ≤ Θ(t) + t²/5` with the certified value `δ̂(0) ≥ 5.3795` |
| `0.18 ≤ \|t\| ≤ 1.8` | `fourierSide_nonneg_of_low_threshold` | `PolyaLowThreshold.lean` | band criterion with the first digamma/model poles cancelled, on eleven bands |
| `\|t\| ≥ 1.8` | `fourierSide_nonneg_of_lin_threshold` | `PolyaLinThreshold.lean` | linear-phase block bounds on 128 bands, then the earlier thresholds `5.5`, `8`, `12`, … |

The historical chain of thresholds (all still present and `sorry`-free) is
`2π e^{17π+20}` (`ThetaGrowth.lean`), `60` (`ThetaGrowth.lean`), `38`
(`DeltaDecaySharp.lean`), `34` (`MidThreshold.lean`), `23`
(`DeltaVariation.lean`), `12` and `8` (`PolyaThreshold.lean`), `7`, `6.5`, `6`, `5.5`
(`PolyaOscThreshold.lean`), `1.8` (`PolyaLinThreshold.lean`).

The two conditional routes to the inequality that used to be recorded — each depending on
an unproved `Prop`-valued hypothesis (`TailEnergyIdentity`, resp. `BandEnergyBound` and
`TraceLimitIdentity`) — were removed in the clean-up of the repository, the inequality
being now proved unconditionally.

## 4. Status of Corollary 2.3 (i) — the positivity of `L`

```
RequestProject/ArchimedeanPositivity.lean
theorem LfunNorm_re_nonneg_convLog_starLog {F : ℝ → ℂ} (hF : ContDiff ℝ 2 F)
    (hsF : HasCompactSupport F) : 0 ≤ (LfunNorm (convLog F (starLog F))).re
```

`LfunNorm` is `L = D + W_∞` in the `∆^{1/2}` normalization of the paper.  The statement is
unconditional; its three ingredients are

* the Parseval identity (52), both halves proved (`Dcomplex_parseval` in `Parseval.lean`,
  the archimedean explicit formula `Winfty_deltaHalfInv_ofLog` in
  `ArchimedeanExplicit.lean`, itself resting on the two digamma facts proved in
  `Digamma.lean`);
* the Fourier-side inequality above;
* the analytic side conditions on the transform of `F ⋆ F*`, proved in `FourierDecay.lean`.

What is *not* proved is the same statement for an arbitrary continuous compactly supported
positive definite test function (`LPositivity`), which needs the general Bochner theorem,
and the operator-trace route of the paper (`L_positive`).
## 5. Status of the geometric side — the renormalized cut-off trace

```
RequestProject/CutoffLogProfile.lean
theorem exists_universal_finitePart_LfunNorm [Countable ι] (b : HilbertBasis ι ℂ L2R) :
    ∃ z₁ : ℂ, ∀ (f : C_c(Rplus, ℂ)) (C : ℝ),
      (∀ lam : Rplus, ‖f lam - f 1‖ ≤ C * |1 - (lam : ℝ)|) →
      Tendsto (fun cut : ℝ => modelCutTrace b cut f - f 1 * 4 * (Real.log cut : ℂ)) atTop
        (𝓝 (Dcomplex (ofLog (logTest f)) - LfunNorm (logTest f)
              + reflectionPairingReg (logTest f) + f 1 * z₁))
```

With `S^{(Λ)} = P^{(Λ)} P̂^{(Λ)} P^{(Λ)}` the cut-off Sonin sandwich on `L²(ℝ)`, the four
components of this statement are:

* **off-diagonal recovery of the Weil kernel** — `semiLocalDensity_eq_Si`,
  `tendsto_semiLocalDensity_scaling` (`SemiLocalKernel.lean`, `SemiLocalSi.lean`):
  `Tr(ϑ(λ) S^{(Λ)}) → λ^{1/2}/|1-λ|`, with a uniform dominating function;
* **unconditional finite part** — `exists_hasCutoffLogProfile_refBump`,
  `exists_universal_finitePart_unconditional` (`CutoffLogProfileAux.lean`,
  `CutoffLogProfile.lean`): `Tr(ϑ(f) S^{(Λ)}) - 4 f(1) log Λ` converges for every
  continuous compactly supported `f` that is Lipschitz at `λ = 1`;
* **identification with `L_Norm`** — `weilPairing_eq_weilR_add_reflectionPairing`,
  `tendsto_modelCutTrace_LfunNorm` (`WeilKernelComparison.lean`,
  `RenormalizedFinitePart.lean`, `RenormalizedAsymptotics.lean`): the limit is
  `D(F) - L_Norm(F) + E(F) + f(1) z₁`, i.e. the normalised archimedean functional up to
  the local terms `E(F)` (odd part) and `f(1) z₁`;
* **the coefficient is `4`, not the paper's `2`** — the model computes on the full line
  `L²(ℝ)`, whose natural phase-space scale is `Λ²` (`4 log Λ = 2 log Λ²`), whereas the
  paper works on the even (Sonin) subspace.  The same discrepancy is the source of the
  odd-part term `E(F)`.  Passing to `evenSubspace` (`EvenPicture.lean`) and evaluating
  `z₁` are the two items left open on this side.

Two negative results delimit the programme: with a **fixed** cut-off the identity
`L_Norm(f) = Tr(ϑ(f) P₁P̂₁P₁)` is false (`not_normalizedTraceIdentity`,
`TraceIdentityObstruction.lean`), and the diagonal of the semi-local kernel grows like `Λ²`
(`diagDensity_ge_quadratic`, `diagDensity_le_four_mul_sq`), which refutes the
pure-diagonal logarithmic hypothesis `DiagLogUpperBound` (`not_diagLogUpperBound`,
`DiagonalQuadraticGrowth.lean`).  The narrative is in the section *Status: the
renormalized-trace programme* of `RequestProject/Skeleton.lean`.

## 6. What each module contributes (one sentence each)

### 6.1 The analytic side

* **`RequestProject/ArchimedeanExplicit.lean`** — The archimedean explicit formula `W_∞(f) = (2π)⁻¹ ∫ f̂(t)·2θ'(t) dt` in the corrected normalization (`WinftyParsevalNorm`), together with the conditional Corollary 2.3 (i) `LfunNorm_re_nonneg_of_fourierSide_nonneg` and the exact value `fourierSide_zero_eq`.
* **`RequestProject/ArchimedeanKernel.lean`** — The elementary analysis behind the explicit formula: the kernel `κ(u) = e^{|u|/2}/(e^u − e^{−u})`, its expansion into Poisson kernels, their Fourier transforms `2b/(b²+t²)` and the constant `(log 2)/2 + π/4`.
* **`RequestProject/Basic.lean`** — The multiplicative group `ℝ⋆₊`, its Haar measure `d*ρ = dρ/ρ` and the exponential homeomorphism `ℝ ≃ ℝ⋆₊`.
* **`RequestProject/CompactInterval.lean`** — Reduces the inequality at the origin to `δ̂(0) ≥ 5.3765` (`fourierSide_threshold_lt`, `fourierSide_zero_nonneg_of_deltaFourier_zero_ge`), and documents why the two elementary routes on the remaining compact interval do not close it.
* **`RequestProject/DeltaDecay.lean`** — First decaying bound for the transform of the trace remainder, `|δ̂(t)| ≤ 32π e^{π/(2|t|)}/|t|` (hence `≤ 104/|t|` for `|t| ≥ 60`), by the half-period shift device.
* **`RequestProject/DeltaDecaySharp.lean`** — The same input used through an integration by parts instead: `|δ̂(t)| ≤ 64/|t|`, which lowers the large-`|t|` threshold from 60 to 38 (`fourierSide_nonneg_of_thirtyeight_le_abs`).
* **`RequestProject/DeltaFourierZero.lean`** — The certified numerical lower bound `δ̂(0) ≥ 5.3795` (`deltaFourier_zero_ge_d4`), its rounded form `deltaFourier_zero_ge : 5.3765 ≤ δ̂(0)`, and hence `fourierSide_zero_nonneg`.
* **`RequestProject/DeltaSmooth.lean`** — The trace remainder in logarithmic coordinates: smoothness on each side of `ρ = 1` and the jump `2` of its derivative there.
* **`RequestProject/DeltaVariation.lean`** — A certified total-variation bound `∫₀^∞ |(d/dv)δ(e^v)| dv ≤ 12`, giving `|δ̂(t)| ≤ 24/|t|` and the threshold `fourierSide_nonneg_of_twentythree_le_abs` (`|t| ≥ 23`).
* **`RequestProject/Digamma.lean`** — Gauss' partial-fraction expansion of `ψ` and the value `ψ(1/4) = -γ - 3 log 2 - π/2`.
* **`RequestProject/DigammaAsymptotic.lean`** — `Re ψ(a+ib) = ½ log(a²+b²) − E(a,b)` with `|E| ≤ 1/(a²+b²) + π/(2b)`, hence `Re ψ(a+ib) − log b → 0`.
* **`RequestProject/Effective.lean`** — Effective form of Corollary 3.8: `Re D(Qf) ≤ -(2−M) f(1)` under the kernel criterion `∫|Qδ| ≤ M`, discharged unconditionally for `s = 1/15` (`u = e^{1/15}`).
* **`RequestProject/FourierDecay.lean`** — Decay of the Fourier–Mellin transform: `‖f̂‖ = O(1/(1+t²))` for a `C²` compactly supported test function, the identity `|(F ⋆ F*)^| = |F̂|²`, the quadratic bound on the digamma increment and the Lipschitz bound at the origin — i.e. the three analytic side conditions of the Parseval identity — and hence Corollary 2.3 (i) for convolution squares, granted only the Fourier-side inequality.
* **`RequestProject/FourierSide.lean`** — Definitions of `thetaDeriv`, `deltaFourier` and `fourierSide = 2θ' + δ̂`, evenness/continuity, the crude bound `|δ̂(t)| ≤ δ̂(0)`, the reductions `fourierSide_nonneg_of_monotoneOn` and `fourierSide_zero_nonneg_iff`, and the commented-out transfer of the inequality to the unnormalized `LPositivity`.
* **`RequestProject/FourierSideAnalysis.lean`** — The exact nonnegative series for `Θ(t) = 2θ'(t) − 2θ'(0)`, `thetaDeriv_monotoneOn`, the spread `Δ(t) = δ̂(0) − δ̂(t)` and the equivalence `fourierSide_nonneg_iff : 0 ≤ f(t) ↔ Δ(t) ≤ Θ(t) + f(0)`.
* **`RequestProject/GammaBound.lean`** — Sharper constants at the origin (`γ < 0.5772287`, `log π < 1.14474`), giving the quantitative margin `fourierSide_zero_ge : f(0) ≥ 0.0072`.
* **`RequestProject/JumpFormula.lean`** — Integration by parts against a function with a corner, producing the `-2‖ξ‖²` term of the essential negativity statements.
* **`RequestProject/KernelBound.lean`** — Closed form of the kernel `Qδ(e^t)` through sine/cosine moments and the explicit bound `|Qδ(e^t)| ≤ 14` for `|t| ≤ 1/15`.
* **`RequestProject/Main.lean`** — Top-level import file (imports every module); contains no declarations.
* **`RequestProject/Mellin.lean`** — The convolution `*`-algebra of `ℝ⋆₊` in logarithmic coordinates, the Fourier–Mellin transform and the operator `Qlog = -(d/dt)² + 1/4`.
* **`RequestProject/MidThreshold.lean`** — Lowers the large-`|t|` threshold from 38 to 34 (`fourierSide_nonneg_of_thirtyfour_le_abs`) by comparing the spread of `δ̂` directly with the partial sums of the series for `Θ`; also contains the alternating Taylor *upper* bounds for `sin`/`sinc`/`Si`.
* **`RequestProject/NearOrigin.lean`** — The inequality on a neighbourhood of the origin: the spread comparison `Δ(t) ≤ Θ(t) + t²/5`, hence `fourierSide_nonneg_of_sq_le` (`t² ≤ 5 f(0)`) and `fourierSide_nonneg_of_abs_le` (`|t| ≤ 0.18`).
* **`RequestProject/Parseval.lean`** — The logarithmic-coordinate transform `fourierLog`, the `D`-half of Parseval (52) (`Dcomplex_parseval`), the full identity `L_parseval` under the hypothesis `WinftyParseval`, and `L_real_nonneg_of_fourierSide_nonneg`.
* **`RequestProject/Positivity.lean`** — The functional `L = D + W_∞` in logarithmic coordinates, the vanishing conditions at `±i/2`, the Green potential/division property for `Q`, and the definition `LPositivity`; the statement `L_positive` was withdrawn (it is false, see `RequestProject/UnnormalizedCounterexample.lean`) and is kept only as a comment block.
* **`RequestProject/RemainderBound.lean`** — Boundedness of the remainder in the essential negativity identity, `|⟨ξ, Kξ⟩| ≤ C‖ξ‖²` with `C` depending only on the support.
* **`RequestProject/Scaling.lean`** — The scaling representation `ϑ` of `ℝ⋆₊` on `L²(ℝ⋆₊, d*ρ)` as a family of linear isometries.
* **`RequestProject/SiAsymptotic.lean`** — The classical asymptotic expansion of `Si` via Laplace integrals, including `∫₀^∞ sin t/t = π/2` and `|Si x − π/2| ≤ 1/x + 1/x²`.
* **`RequestProject/SiPositivity.lean`** — `Si x > 0` for `x > 0`.
* **`RequestProject/SiSmooth.lean`** — Smoothness of `siDiv a = Si a / a` and the cosine/sine moments `∫₀¹ tᵏ cos(at)(−log t) dt`.
* **`RequestProject/SineIntegral.lean`** — The definition of `Si` and the identity `∫₀¹ cos(at)(−log t) dt = Si(a)/a`.
* **`RequestProject/Skeleton.lean`** — Documentation only (no declarations): the running status record of the project, plus the original informal skeleton reproduced verbatim inside a comment.
* **`RequestProject/Sonin.lean`** — Sonin's space and the associated orthogonal projection, and the cutoff projections `P₁`, `P̂₁`.
* **`RequestProject/TaylorBounds.lean`** — Alternating Taylor bounds for `sin`, `cos` and `Si` (the general bracketing statement, proved by simultaneous induction).
* **`RequestProject/ThetaGrowth.lean`** — Growth of `2θ'`: `thetaDeriv_monotoneOn`, `abs_two_thetaDeriv_sub_log_le`, `two_thetaDeriv_ge : 2θ'(t) ≥ log(t/2π) − 4/t² − π/t`, and the thresholds `fourierSide_nonneg_of_le_abs`, `..._of_exp_le_abs`, `..._of_explicit_le_abs`, `..._of_sixty_le_abs`.
* **`RequestProject/TraceRemainder.lean`** — The trace remainder `δ`, its closed form `δ(ρ) = 2√ρ(Si(2π(1+ρ))/(2π(1+ρ)) + Si(2π(ρ−1))/(2π(ρ−1)))` for `ρ ≥ 1`, the symmetry `δ(ρ⁻¹) = δ(ρ)` and the decay bound.
* **`RequestProject/UnnormalizedCounterexample.lean`** — The refutation of the unnormalized statement `LPositivity`: the triangular (Fejér) bump and its positive definiteness, the value of `W_ℝ` applied to the test function itself, the deficit identity `WeilR_ofLog_eq_add_deficit`, the bounds on `D` and on the normalized archimedean term, and the conclusions `L_real_triC_neg` and `not_LPositivity`.
* **`RequestProject/WeilDistribution.lean`** — The archimedean Weil distribution `W_ℝ` (formula (150)) and the normalization `∆^{1/2}`.

The families of generated files, and the modules added after the original snapshot:

* **`RequestProject/ArchimedeanPositivity.lean`** — The two halves combined: `LfunNorm_re_nonneg_convLog_starLog`, the unconditional positivity of `L = D + W_∞` on convolution squares of `C²` compactly supported test functions, and `LfunNorm_re_nonneg` for a general positive definite test function with integrable transform.
* **`RequestProject/QuarticDecay.lean`** — Integrability of the Fourier–Mellin transform of an arbitrary `C⁴` compactly supported test function, which removes the last analytic side condition from the positivity statement.
* **`RequestProject/PolyaModel.lean`** — The Pólya-type model `h(v) = e^{-v/2} + 2.11 e^{-3v}` for `g(v) = δ(e^v)`, its exact cosine transform, and the lower bounds `δ̂(t) ≥ -2ε`, `δ̂(t) ≥ 2ĥ(t) - 2ε`, uniform in `t`.
* **`RequestProject/PolyaError.lean`, `RequestProject/PolyaErrorSharp.lean`** — Pointwise brackets for the rescaled model error `Φ(v) = e^{v/2}(δ(e^v) - h(v))` and their integration over a piece, in Taylor and in asymptotic form.
* **`RequestProject/PolyaPartition1–3.lean`** — The 601-breakpoint partition, giving `integral_Ioi_abs_errFun_le : ε ≤ 0.21088`.
* **`RequestProject/PolyaThreshold.lean`** — `two_thetaDeriv_ge_series`, the band criterion `fourierSide_nonneg_band`, and the thresholds `|t| ≥ 12` and `|t| ≥ 8`.
* **`RequestProject/PolyaOscBase.lean`, `PolyaOscBlocks1–4.lean`, `PolyaOscTail.lean`, `PolyaOscBand0–26.lean`, `PolyaOscThreshold.lean`** — Signed block bounds for the oscillatory integral `∫₀^∞ err(v) cos(tv) dv`, giving the threshold `|t| ≥ 5.5`.
* **`RequestProject/PolyaOscLin.lean`, `PolyaLinVbp1–4.lean`, `PolyaLinPieces1–8.lean`, `PolyaLinBlocks1–4.lean`, `PolyaLinBand0–127.lean`, `PolyaLinThreshold.lean`** — The same with the phase linearised on each block, which makes the block error quadratic in the block width and lowers the threshold to `|t| ≥ 1.8`.
* **`RequestProject/PolyaLowBase.lean`, `PolyaLowVbp1–2.lean`, `PolyaLowPieces1–4.lean`, `PolyaLowTail.lean`, `PolyaLowBlocks1–4.lean`, `PolyaLowBand0–10.lean`, `PolyaLowThreshold.lean`** — The low-frequency range: the band criterion with the first digamma/model poles cancelled exactly, the partition extended to `q = 5` (tail `≤ 0.0022`), the eleven bands covering `0.18 ≤ |t| ≤ 1.8`, and hence `fourierSide_nonneg` for every real `t`.
* **`RequestProject/SiDivMono.lean`, `RequestProject/SiSharp.lean`** — Monotonicity and rational brackets for `Si` and `Si(x)/x`, used by the certified quadratures.

### 6.2 Operator-theoretic infrastructure originally aimed at `L_positive`

These modules were the groundwork for the (now withdrawn) `L_positive`; they are not used by the
Fourier-side results, and they were not imported by `RequestProject/Main.lean` until the
clean-up.  They are now imported there, so `lake build` of `Main` covers the whole project.

* **`RequestProject/ScalingIntegrated.lean`** — Strong continuity of the scaling representation and the integrated operators `ϑ(f) ξ = ∫ f(λ) ϑ(λ) ξ d*λ`, with `‖ϑ(f)‖ ≤ ‖f‖₁` and `ϑ(f)* = ϑ(f^♯)`.
* **`RequestProject/TestConvolution.lean`** — The convolution algebra `C_c(ℝ⋆₊)` and the multiplicativity `ϑ(f ∗ g) = ϑ(f) ϑ(g)`, hence `ϑ(g ∗ g^♯) = ϑ(g) ϑ(g)*`.
* **`RequestProject/SoninJoin.lean`** — The lattice description `S = 1 - (P₁ ∨ P̂₁)` of Sonin's space and the identities `S* = S = S² ≥ 0`.
* **`RequestProject/SoninSandwich.lean`** — The Sonin sandwich `P₁ P̂₁ P₁` written as `B* B` with `B = P̂₁ P₁`.
* **`RequestProject/TraceClass.lean`** — Hilbert–Schmidt and trace-class language: `hsNormSq`, its basis independence, `IsHilbertSchmidt`, `IsTraceClass`, `traceAlong` and `traceAlongRe`.
* **`RequestProject/TraceProperty.lean`** — The trace property `Tr(AB) = Tr(BA)` for Hilbert–Schmidt operators.
* **`RequestProject/TraceBasisIndep.lean`** — Basis independence of the trace of a trace-class operator, through the Hilbert–Schmidt pairing.
* **`RequestProject/TraceScaling.lean`** — `Tr(ϑ(f)^♯ A ϑ(f)) ≥ 0` for positive `A`, the positivity mechanism in the form in which it will be used.
* **`RequestProject/TracePositivity.lean`** — `Re Tr((T T*)(B* B)) ≥ 0` for Hilbert–Schmidt `B`, and its specialization to `ϑ(g ∗ g^♯)`.

### 6.3 The normalized trace identity and the renormalized-trace programme

* **`RequestProject/HilbertSchmidtKernel.lean`** — A Hilbert–Schmidt criterion for kernel operators: `hsNormSq b T ≤ ∫⁻ ‖k x‖ₑ² dμ` when `(T ξ)(x) = ⟪k x, ξ⟫` a.e.
* **`RequestProject/FourierL2Integral.lean`** — The `L²` (Plancherel) Fourier transform of an integrable `L²` function agrees a.e. with its Fourier integral.
* **`RequestProject/CutoffHilbertSchmidt.lean`** — `isHilbertSchmidt_P1hat_comp_P1`: `B = P̂₁P₁` is Hilbert–Schmidt, by computing the kernel of `P₁ 𝓕 P₁`.
* **`RequestProject/LogPicture.lean`** — The integrated scaling representation transported to `L²(ℝ)` along an arbitrary unitary `U`: `‖ϑ(f)‖ ≤ ‖f‖₁`, multiplicativity, `ϑ(f)* = ϑ(f^♯)`, positivity on convolution squares.
* **`RequestProject/TraceIdentityNorm.lean`** — The Sonin sandwich `P₁P̂₁P₁` as a positive trace-class operator, the linear functional `f ↦ Tr(ϑ(f) P₁P̂₁P₁)`, its nonnegativity on convolution squares, and the statement `NormalizedTraceIdentity` (a hypothesis, never an axiom).
* **`RequestProject/EvenPicture.lean`** — The paper's unitary `w : L²(ℝ⋆₊, d*ρ) ≃ L²(ℝ)_ev`, `(w ξ)(x) = (2|x|)^{-1/2} ξ(|x|)`, with `range_weilMap` and the intertwining `coeFn_weilMap_scaling`.
* **`RequestProject/TraceDensity.lean`** — The local trace formula in kernel form, `Tr(ϑ(f) P₁P̂₁P₁) = ∫ f(λ) κ(λ) d*λ`, and the equivalence of the normalized trace identity with the corresponding identity of functions.
* **`RequestProject/TraceDensitySymmetry.lean`** — `κ(λ) = ⟪B, ϑ(λ)B⟫_HS`, the symmetry `κ(λ⁻¹) = conj κ(λ)`, continuity of `κ`, and `κ(1) = ‖B‖²_HS`.
* **`RequestProject/TraceIdentityObstruction.lean`** — `not_normalizedTraceIdentity`: with the cut-off frozen at `1` the trace identity is false, the trace functional being `L¹(d*λ)`-continuous while the archimedean functional is a distribution of order one.
* **`RequestProject/CutoffFamily.lean`** — The one-parameter family `Pcut Λ`, `PcutHat Λ` (equal to `P₁`, `P̂₁` at `Λ = 1`), the renormalized sandwich `S^{(Λ)}`, and its algebraic properties: self-adjoint idempotent contractions, monotonicity in `Λ`, `S^{(Λ)} = B_Λ^* B_Λ ≥ 0`.
* **`RequestProject/CutoffFamilyHS.lean`** — `B_Λ = P̂^{(Λ)}P^{(Λ)}` is Hilbert–Schmidt at every scale, hence `ϑ(f) S^{(Λ)}` is trace class with a basis-independent trace, nonnegative on convolution squares.
* **`RequestProject/CutoffExhaustion.lean`** — Strong convergence `P^{(Λ)}ξ → ξ`, `P̂^{(Λ)}ξ → ξ`, `S^{(Λ)}ξ → ξ` and `⟪ξ, S^{(Λ)}ξ⟫ → ‖ξ‖²`.
* **`RequestProject/TraceDivergence.lean`** — `Tr(S^{(Λ)}) → ∞`, with the infinite-dimensionality of `L²(ℝ)` proved from the indicators of the unit blocks `[n, n+1)`.
* **`RequestProject/RenormalizedTrace.lean`** — The renormalized trace functional, the logarithmic counter-term, the finite part and its uniqueness, and the statement `RenormalizedTraceIdentity`; no *fixed* scale can compute `L_Norm`.
* **`RequestProject/RenormalizedTraceDensity.lean`** — The finite-scale trace in kernel form, `Tr(ϑ(f) S^{(Λ)}) = ∫ f(λ) κ_Λ(λ) d*λ`, and the equivalence of the renormalized identity with the convergence of the regularized integrals.
* **`RequestProject/RenormalizedDensitySymmetry.lean`** — `κ_Λ(λ) = ⟪B_Λ^*, ϑ(λ)B_Λ^*⟫_HS`, the symmetry `κ_Λ(λ⁻¹) = conj κ_Λ(λ)`, continuity, and `κ_Λ(1) = ‖B_Λ‖²_HS = Tr(S^{(Λ)})`.
* **`RequestProject/RenormalizedDensityBound.lean`** — `|κ_Λ(λ)| ≤ κ_Λ(1)`, monotonicity of `κ_Λ(1)` in `Λ`, positive-definiteness of `κ_Λ`, and the absence of a counter-term for test functions vanishing at `1`.
* **`RequestProject/RenormalizedTraceUniqueness.lean`** — Both the counter-term coefficient and the finite part are determined by the family `Λ ↦ Tr(ϑ(f) S^{(Λ)})`; existence of the finite part forces the divergence rate.
* **`RequestProject/SemiLocalDiagonal.lean`** — The diagonal density `d(Λ) = Tr(S^{(Λ)})`: nonnegative, basis-independent, monotone, divergent, dominating the whole cut-off trace; the `o(1)` formulations of the target statement and their equivalences.
* **`RequestProject/NearDiagonalKernel.lean`** — The two-variable kernel `K_Λ(μ,ν) = κ_Λ(μ⁻¹ν)`, its near-diagonal defect `ε_Λ`, the averaging identity `Re Tr(ϑ(g) S^{(Λ)}) = ‖g‖_{L¹} d(Λ) - ∫ g ε_Λ`, and the two `Prop`-valued hypotheses `DiagLogUpperBound`, `ShortDistanceModulus` of the diagonal route.
* **`RequestProject/DiagonalQuadraticGrowth.lean`** — `(8/π²)Λ² - 4/π² ≤ d(Λ) ≤ 4Λ²`, hence `not_diagLogUpperBound`: the diagonal route is refuted, the divergence being an averaged and not a diagonal phenomenon.
* **`RequestProject/DiagonalExact.lean`** — The exact diagonal density `d(Λ) = 4Λ²` (the equality case of the Hilbert–Schmidt kernel bound): the trace of the cut-off Sonin sandwich is the phase-space area of the box `[-Λ,Λ] × [-Λ,Λ]`.
* **`RequestProject/HilbertSchmidtPairing.lean`** — The sesquilinear companion of that computation, `⟪ A, C ⟫_HS = ∫ ⟪ k_C x, k_A x ⟫ dx`, which turns a trace into an explicit integral.
* **`RequestProject/Dilation.lean`** — The concrete dilation representation `(D_a F)(x) = √a · F(a x)` of `ℝ⋆₊` on `L²(ℝ, dx)`, i.e. `ϑ(λ) = D_{λ⁻¹}`, replacing the arbitrary unitary identification of `LogPicture.lean` where the kernel of the operators is needed.
* **`RequestProject/SemiLocalKernel.lean`**, **`RequestProject/SemiLocalSi.lean`** — The closed form `κ_Λ(a) = √a·(2/(π(a-1)))·Si(2π(a-1)Λ²/max(1,a))` of the semi-local density, its uniform domination, and the off-diagonal limit `κ_Λ(a) → √a/|a-1|` (the archimedean Weil kernel).
* **`RequestProject/RenormalizedFinitePart.lean`** — The concrete model trace `modelCutTrace`, the pairing `weilPairing`, the convergence `modelCutTrace b Λ f → weilPairing f` for `f` Lipschitz at `1` (dominated convergence), and the reduction of the general case to a single reference function (`HasCutoffLogProfile`).
* **`RequestProject/WeilKernelComparison.lean`** — `√λ/|1-λ| = sinhKernel + sinhKernelRefl` in the logarithmic coordinate, hence `weilPairing f = W_ℝ(∆^{-1/2}F) + E(F)`: the limiting kernel is the kernel of the explicit formula plus the reflected (odd-part) term.
* **`RequestProject/RenormalizedAsymptotics.lean`** — The regularized reflected pairing, linearity of both regularized pairings, and `exists_universal_finitePart`: one reference function with a logarithmic profile gives the expansion for every admissible test function.
* **`RequestProject/CutoffLogProfileAux.lean`** — Elementary estimates: `|Si x - Si y| ≤ |x-y|/min(x,y)`, `|ψ(u) - u| ≤ u²` for the compression `ψ(u) = (e^u-1)/max(1,e^u)`, and the uniform bound `|Si(Tψ(u)) - Si(Tu)| ≤ 2|u|`.
* **`RequestProject/CutoffLogProfile.lean`** — The logarithmic profile `Tr(ϑ(refBump) S^{(Λ)}) = 4 log Λ + z₀ + o(1)` of the triangular reference bump, and hence the unconditional finite-part asymptotics `exists_universal_finitePart_unconditional` / `exists_universal_finitePart_LfunNorm`.
* **`RequestProject/AxiomAudit.lean`** — Documentation only (no declarations): the `#print axioms` commands whose output is recorded in `RequestProject/VERIFICATION.md`.
* **`RequestProject/A5Artin.lean`** — A separate, self-contained development, unrelated to the Weil-positivity chain: the local Artin factorisation for `A₅` (Euler factors of the four nontrivial irreducible representations and the four factorisation identities) backing `docs/A5_even_Artin.md` and `scripts/a5`.

## 7. Clean-up record

**First pass (constant-level audit).**  Four modules were removed; the audit that
identified them (a transitive closure over the *constants* used by the live theorems, not
over the imports) is recorded in the section *Clean-up of the repository (module
inventory)* of `RequestProject/Skeleton.lean`.

| Module | Reason |
|---|---|
| `RequestProject/MidThreshold25.lean` | superseded intermediate threshold (`\|t\| ≥ 25`, between the `34` of `MidThreshold.lean` and the `23` of `DeltaVariation.lean`); no constant of it was used anywhere |
| `RequestProject/NearOriginSharp.lean` | unused sharpening of the near-origin range from `0.18` to `0.28` |
| `RequestProject/BandEnergy.lean` | conditional route resting on the unproved `BandEnergyBound` and `TraceLimitIdentity`; no longer needed |
| `RequestProject/TailEnergy.lean` | conditional route resting on the unproved `TailEnergyIdentity`; no longer needed |

**Second pass (import-level audit, documentation and hygiene).**  The transitive import
closure of the modules declaring the live results — `PolyaLowThreshold`,
`ArchimedeanPositivity`, `NormalizedPositivity`, `UnnormalizedCounterexample`,
`TraceIdentityObstruction`, `DiagonalQuadraticGrowth`, `CutoffLogProfile`, `A5Artin`,
`AxiomAudit`, `Skeleton` — was compared with the modules on disk.  Result: **no module was
removed**, because all but one are in that closure.

| Module | Status | Action |
|---|---|---|
| `RequestProject/TraceScaling.lean` | off the live proof path: its three theorems (the positivity mechanism `Tr(ϑ(f)* A ϑ(f)) ≥ 0` on `L²(ℝ⋆₊)`) are superseded by `RequestProject/TracePositivity.lean`, and no module refers to them | kept (it is `sorry`-free, self-contained and cheap to elaborate; deleting it would delete proved statements) and marked as such in its header, in the module list of `Skeleton.lean` and here |
| `RequestProject/AxiomAudit.lean` | not imported by `Main.lean`, deliberately | kept; extended to cover the new headline results of the renormalized-trace programme |
| `RequestProject/A5Artin.lean` | not imported by `Main.lean`, deliberately: a separate development | kept; the exception is now documented in the header of `Main.lean` |

Everything else is load-bearing: every band file of the `PolyaOscBand*`, `PolyaLinBand*`
and `PolyaLowBand*` families certifies one frequency band of the covering used by
`fourierSide_nonneg`, each step of the historical threshold chain is used by its successor,
and every module of the operator side is imported by a live result or by this
documentation.  Consolidating consecutive band files into fewer modules was considered and
rejected (it would serialize work that is currently elaborated in parallel, without
reducing it).

The script `scripts/inventory.py` was added in this pass so that the figures of §1 can be
regenerated mechanically.
