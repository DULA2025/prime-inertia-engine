/-
Top-level import file for the formalization of

  Alain Connes & Caterina Consani,
  "Weil positivity and Trace formula – the archimedean place", arXiv:2006.13771.

Every module of the project is imported here, so that `lake build` of this file
elaborates the whole development, with two deliberate exceptions:

* `RequestProject.AxiomAudit`, which only runs `#print axioms` on the headline theorems
  (its output is the audit recorded in `RequestProject/VERIFICATION.md`), and
* `RequestProject.A5Artin`, a separate self-contained development (local Artin
  factorisation for `A₅`, backing `docs/A5_even_Artin.md` and `scripts/a5`) that is
  unrelated to the Weil-positivity chain.

Both are matched by the library glob `RequestProject.+`, so a plain `lake build`
elaborates them as well.

See `RequestProject/Skeleton.lean` for a summary of what is formalized and what is not,
including the record of the modules that were removed in the clean-up of the repository.
-/
import RequestProject.Basic
import RequestProject.SineIntegral
import RequestProject.SiPositivity
import RequestProject.SiSmooth
import RequestProject.TraceRemainder
import RequestProject.Sonin
import RequestProject.Scaling
import RequestProject.WeilDistribution
import RequestProject.Mellin
import RequestProject.JumpFormula
import RequestProject.DeltaSmooth
import RequestProject.RemainderBound
import RequestProject.Positivity
import RequestProject.KernelBound
import RequestProject.Effective
import RequestProject.FourierSide
import RequestProject.Parseval
import RequestProject.Digamma
import RequestProject.DigammaAsymptotic
import RequestProject.ArchimedeanKernel
import RequestProject.ArchimedeanExplicit
import RequestProject.DeltaDecay
import RequestProject.ThetaGrowth
import RequestProject.DeltaDecaySharp
import RequestProject.DeltaVariation
import RequestProject.FourierSideAnalysis
import RequestProject.SiAsymptotic
import RequestProject.TaylorBounds
import RequestProject.CompactInterval
import RequestProject.DeltaFourierZero
import RequestProject.GammaBound
import RequestProject.NearOrigin
import RequestProject.MidThreshold
import RequestProject.Skeleton
import RequestProject.PolyaThreshold
import RequestProject.PolyaOscThreshold
import RequestProject.PolyaLinThreshold
import RequestProject.PolyaLowThreshold
import RequestProject.FourierDecay
import RequestProject.ArchimedeanPositivity
import RequestProject.QuarticDecay
import RequestProject.NormalizedPositivity
-- The refutation of the unnormalized positivity statement `LPositivity`.
import RequestProject.UnnormalizedCounterexample
-- Operator-theoretic infrastructure originally intended for `L_positive`
-- (a statement now known to be false, see `RequestProject.UnnormalizedCounterexample`):
-- the integrated scaling representation, the convolution algebra of test functions,
-- the Sonin sandwich and the trace-class groundwork.
import RequestProject.ScalingIntegrated
import RequestProject.TestConvolution
import RequestProject.SoninJoin
import RequestProject.TraceClass
import RequestProject.TraceProperty
import RequestProject.TraceBasisIndep
import RequestProject.TraceScaling
import RequestProject.TracePositivity
import RequestProject.SoninSandwich
-- Operator-theoretic infrastructure aimed at the *normalized* trace identity
-- `L_Norm(f) = Tr(ϑ(f) P P̂ P)`: the Hilbert–Schmidt criterion for kernel operators,
-- the identification of the `L²` Fourier transform with the Fourier integral, the
-- Hilbert–Schmidt property of `P̂₁ P₁` (hence trace-classness of the Sonin sandwich),
-- the logarithmic picture of the integrated scaling representation, and the statement of
-- the trace identity together with the positivity it yields.
import RequestProject.HilbertSchmidtKernel
import RequestProject.FourierL2Integral
import RequestProject.CutoffHilbertSchmidt
import RequestProject.LogPicture
import RequestProject.TraceIdentityNorm
-- The paper's unitary identification of the two pictures (the "log picture" of §1),
-- the kernel form of the local trace formula, the structure of the trace density, and
-- the resulting refutation of the normalized trace identity with a fixed cutoff.
import RequestProject.EvenPicture
import RequestProject.TraceDensity
import RequestProject.TraceDensitySymmetry
import RequestProject.TraceIdentityObstruction
-- The renormalized-trace programme: the one-parameter family of cut-offs `P^{(Λ)}`,
-- `P̂^{(Λ)}`, the renormalized Sonin sandwich `S^{(Λ)} = P^{(Λ)} P̂^{(Λ)} P^{(Λ)}`, its
-- trace-classness, the strong exhaustion `S^{(Λ)} → 1`, the divergence of `Tr(S^{(Λ)})`,
-- and the renormalized trace functional with its logarithmic counter-term.
import RequestProject.CutoffFamily
import RequestProject.CutoffFamilyHS
import RequestProject.CutoffExhaustion
import RequestProject.TraceDivergence
import RequestProject.RenormalizedTrace
import RequestProject.RenormalizedTraceDensity
import RequestProject.RenormalizedDensitySymmetry
import RequestProject.RenormalizedDensityBound
import RequestProject.RenormalizedTraceUniqueness
import RequestProject.SemiLocalDiagonal
import RequestProject.NearDiagonalKernel
-- The semi-local kernel in closed form, its off-diagonal limit (the archimedean Weil
-- kernel), and the extraction of the finite part of the renormalized cut-off trace.
import RequestProject.SemiLocalKernel
import RequestProject.SemiLocalSi
import RequestProject.RenormalizedFinitePart
import RequestProject.WeilKernelComparison
import RequestProject.RenormalizedAsymptotics
import RequestProject.CutoffLogProfileAux
import RequestProject.CutoffLogProfile
-- The same analysis restricted to the even (Sonin) subspace: the even semi-local density,
-- the even cut-off trace with logarithmic coefficient exactly `2 f(1)`, and the value of
-- the remaining universal constant.
import RequestProject.EvenSemiLocalKernel
import RequestProject.EvenCutoffTrace
import RequestProject.EvenConstantAux
import RequestProject.EvenConstant
