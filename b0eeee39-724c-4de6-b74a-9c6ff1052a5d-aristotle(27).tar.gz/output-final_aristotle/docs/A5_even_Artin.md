# Even `A₅` Artin representations in dimensions 3, 3′, 4 and 5

*Report produced by `scripts/a5/make_report.py`; all numbers below are read off
the JSON files in `data/a5/`.*

## 0. What this report contains

Let `K/ℚ` be a totally real quintic field whose Galois closure `N/ℚ` has
`Gal(N/ℚ) ≃ A₅`.  The four nontrivial irreducible complex representations of
`A₅`, of dimensions 3, 3, 4 and 5, give **even** Artin representations
`ρ : Gal(ℚ̄/ℚ) → GLₙ(ℂ)`, `n ∈ {3,4,5}`.  Artin's holomorphy conjecture for
these is open.

This report

* enumerates the smallest totally real `A₅` quintic fields and computes, for
  each, the exact field discriminant, the ramification data and the Artin
  conductors of `ρ₃, ρ₃′, ρ₄, ρ₅` (Section 2, Section 3);
* explains exactly which parts of the picture are theorems and which are
  numerics (Section 1);
* reports high-precision numerical tests of the **holomorphy** of the completed
  L-functions, of their zeros on the critical line and of the absence of real
  zeros in `(0,1)` (Sections 4–6);
* gives a status table and identifies the most promising fields for a future
  rigorous verification (Section 7);
* records theoretical observations and the obstacles specific to the even
  higher-dimensional setting (Sections 8–9).

Everything is reproducible from the scripts in `scripts/a5/` using nothing but
a standard Python 3 interpreter; the representation-theoretic identities that
the computation relies on are proved in Lean in `RequestProject/A5Artin.lean`.

## 1. What is a theorem and what is numerics

**1.1 Evenness.**  If `K` is totally real then all five roots of a defining
polynomial are real, so complex conjugation fixes them all, hence acts
trivially on `N`: `N` is totally real and *every* Artin representation of
`Gal(N/ℚ)` is even.  Consequently the completed L-function of an
`n`-dimensional such `ρ` is

>  `Λ(ρ,s) = N(ρ)^{s/2} · (π^{-s/2} Γ(s/2))ⁿ · L(ρ,s)`,

with `n` copies of the *same* archimedean factor `Γ_ℝ(s)` — there is no
`Γ_ℝ(s+1)` factor, which is what makes the even case harder: the gamma factor
has a pole of order `n` at `s = 0`, and the "trivial zero" structure that in the
odd case forces some vanishing is absent.

**1.2 Brauer.**  By Brauer induction each `L(ρ,s)` extends to a meromorphic
function on `ℂ` and satisfies the functional equation
`Λ(ρ,s) = ε(ρ) Λ(ρ̄,1−s)`.  All four representations here are self-dual with
real character, so `ρ̄ = ρ`.  *The functional equation is therefore a theorem;
what is open is holomorphy* (absence of poles).

**1.3 The Aramata–Brauer constraint.**  `ζ_N(s)/ζ(s)` is entire.  Combined with
the factorisation

>  `ζ_N = ζ · L(ρ₃)³ L(ρ₃′)³ L(ρ₄)⁴ L(ρ₅)⁵`

(proved class-by-class in Lean as `A5Artin.regPoly_eq`) this says that any pole
of one of the four L-functions must be cancelled by zeros of the others.  In
particular a *simple* pole of, say, `L(ρ₅)` would force a zero of order ≥ 5 of
the remaining product at the same point.

**1.4 What the numerical test actually tests.**  We evaluate

>  `Λ(s) = G(s,u) + ε·G(1−s,1/u)`,  `G(w,u) = Σ_k a_k ∫_{u·k/Q}^∞ Φ(t) t^{w-1} dt`,
>  `Q = √N`, `Φ =` inverse Mellin transform of `(π^{-s/2}Γ(s/2))ⁿ`.

`G(w,u) = ∫_u^∞ θ(v) v^{w−1} dv` for the theta series `θ(v) = Σ_k a_k Φ(kv/Q)`,
so the displayed identity is *equivalent* to `Λ` being entire and satisfying the
functional equation: if `Λ` had a pole, the formula would acquire extra terms
depending on the split point `u`.  Hence

>  **the `u`-independence of the computed `Λ(s)` is a numerical test of
>  holomorphy**, the functional equation itself being known (1.2).

The tables below report `max_u |Λ(s,u) − Λ(s,1)| / |Λ(1/2)|` over
`u ∈ {0.75, 1, 1.35}` and `s ∈ {1/2, 1/2+2i, 1/2+6i, 1}`.  For calibration the
same quantity is recomputed with the wrong sign `ε = −1` and with a wrong
conductor; those variants come out `O(10¹)`–`O(10³)`, i.e. some 15 orders of
magnitude worse.

## 2. The smallest totally real `A₅` quintic fields

The enumeration (`scripts/a5/search.py`) uses Hunter's theorem: every quintic
field contains a generator `θ ∉ ℤ` with `|Tr θ| ≤ 2` and
`T₂(θ) ≤ (Tr θ)²/5 + √2·(d_K/5)^{1/4}`.  Total reality is imposed level by level
on the derivatives, so only totally real polynomials are visited.  Galois group
`A₅` is certified by a square discriminant together with a prime whose
factorisation type is `1+1+3` (only `A₅` among `C₅, D₅, A₅` contains 3-cycles),
and irreducibility by a prime modulo which the polynomial is inert.

The run used `T₂ ≤ 60` and kept polynomial discriminants up to `10¹¹`; it is
therefore **complete for `d_K ≤ 1.53·10⁷`** (the Hunter bound with `T₂ = 60`),
subject only to the mild proviso that the Hunter generator has polynomial
discriminant below the cutoff `10¹¹`.  It produced 458 distinct fields.

Field discriminants are computed *exactly* with a Pohst–Zassenhaus round-2
`p`-maximal order algorithm (`scripts/a5/round2.py`), not merely by Dedekind's
criterion; this matters, because the smallest field in the list is only visible
after removing an index `2²` from the polynomial discriminant.

| # | d_K | defining polynomial | ramification | N(ρ₃)=N(ρ₃′)=N(ρ₄) | N(ρ₅) |
|---|---|---|---|---|---|
| 1 | 3104644 | `x^5 + 1x^4 - 11x^3 - 1x^2 + 12x^1 + 4` | 2(|I|=3) 881(|I|=3) | 3104644 | 9638814366736 |
| 2 | 5184729 | `x^5 + 2x^4 - 7x^3 - 11x^2 + 11x^1 + 11` | 3(|I|=3,wild) 11(|I|=3) 23(|I|=2) | 5184729 | 50815528929 |
| 3 | 6160324 | `x^5 + 1x^4 - 15x^3 + 15x^2 + 6x^1 - 4` | 2(|I|=3) 17(|I|=3) 73(|I|=3) | 6160324 | 37949591784976 |
| 4 | 6180196 | `x^5 + 2x^4 - 15x^3 - 12x^2 + 2x^1 + 2` | 2(|I|=3) 11(|I|=3) 113(|I|=3) | 6180196 | 38194822598416 |
| 5 | 7017201 | `x^5 - 17x^3 + 30x^2 - 4x^1 - 7` | 3(|I|=2) 883(|I|=3) | 7017201 | 5471234430489 |
| 6 | 7409284 | `x^5 + 1x^4 - 15x^3 - 6x^2 + 58x^1 - 10` | 2(|I|=3) 1361(|I|=3) | 7409284 | 54897489392656 |
| 7 | 8305924 | `x^5 + 1x^4 - 9x^3 - 8x^2 + 8x^1 + 4` | 2(|I|=3) 11(|I|=3) 131(|I|=3) | 8305924 | 68988373493776 |
| 8 | 10791225 | `x^5 + 1x^4 - 14x^3 + 1x^2 + 49x^1 - 41` | 3(|I|=6,wild) 5(|I|=2) 73(|I|=3) | 10791225 | 517557942225 |
| 9 | 11744329 | `x^5 + 1x^4 - 26x^3 - 31x^2 + 163x^1 + 212` | 23(|I|=3) 149(|I|=3) | 11744329 | 137929263660241 |
| 10 | 11812969 | `x^5 + 1x^4 - 21x^3 - 57x^2 - 28x^1 + 17` | 7(|I|=2) 491(|I|=3) | 11812969 | 2847882379489 |
| 11 | 12271009 | `x^5 + 2x^4 - 27x^3 + 11x^2 + 105x^1 - 82` | 31(|I|=2) 113(|I|=3) | 12271009 | 156688513921 |
| 12 | 13060996 | `x^5 + 1x^4 - 21x^3 - 48x^2 - 2x^1 + 38` | 2(|I|=3) 13(|I|=3) 139(|I|=2) | 13060996 | 8829233296 |
| 13 | 14584761 | `x^5 + 2x^4 - 13x^3 - 2x^2 + 34x^1 - 19` | 3(|I|=2) 19(|I|=3) 67(|I|=3) | 14584761 | 23635028158569 |
| 14 | 15784729 | `x^5 + 2x^4 - 9x^3 - 13x^2 + 13x^1 + 7` | 29(|I|=3) 137(|I|=3) | 15784729 | 249157669603441 |
| 15 | 16386304 | `x^5 + 1x^4 - 24x^3 - 8x^2 + 64x^1 - 32` | 2(|I|=4,wild) 11(|I|=3) 23(|I|=3) | 16386304 | 1048870932736 |
| 16 | 16662724 | `x^5 + 1x^4 - 17x^3 - 13x^2 + 52x^1 + 52` | 2(|I|=3) 13(|I|=3) 157(|I|=3) | 16662724 | 277646371100176 |
| 17 | 18088009 | `x^5 + 2x^4 - 10x^3 - 23x^2 - 6x^1 + 4` | 4253(|I|=3) | 18088009 | 327176069584081 |
| 18 | 19096900 | `x^5 + 2x^4 - 19x^3 - 39x^2 + 62x^1 + 101` | 2(|I|=3) 5(|I|=3) 19(|I|=3) 23(|I|=3) | 19096900 | 364691589610000 |
| 19 | 20566225 | `x^5 - 22x^3 + 37x^2 - 14x^1 - 1` | 5(|I|=3) 907(|I|=3) | 20566225 | 422969610750625 |
| 20 | 20884900 | `x^5 + 2x^4 - 15x^3 - 42x^2 - 24x^1 - 2` | 2(|I|=3) 5(|I|=3) 457(|I|=3) | 20884900 | 436179048010000 |

`|I|` is the order of the inertia group; "wild" means `p` divides `|I|`.

## 3. Arithmetic input to the L-functions

**3.1 Conductors.**  For `p` with inertia `I` and higher ramification groups
`G₀ = I ⊇ G₁ ⊇ …` (lower numbering) the Artin conductor exponent is
`a(ρ) = Σ_{i≥0} |G_i|/|G₀| · codim V^{G_i}`.  We know `a(ρ₄) = v_p(d_K)`
(conductor–discriminant, using `ζ_K = ζ·L(ρ₄)`), and `G₁` is the `p`-Sylow
subgroup of `I`; enumerating the possible jump sequences and keeping those
compatible with `v_p(d_K)` determines the exponents of all four
representations (`artin.conductor_exponents`).  In every case in the table the
jump data was pinned down uniquely.

Because `dim V^I` is the same for `ρ₃, ρ₃′, ρ₄` for all the inertia groups that
occur (cyclic of order 2, 3, 5, or the Klein four group), one always has
`N(ρ₃) = N(ρ₃′) = N(ρ₄) = d_K`, whereas `N(ρ₅)` is usually much larger — it
equals `d_K` only when every inertia group is of order 2.  This single fact
governs which dimension-5 L-functions are computationally reachable.

**3.2 Frobenius classes and the two classes of 5-cycles.**  For unramified `p`
the factorisation type of `f mod p` gives the cycle type of `Frob_p`.  Cycle
type `(5)` splits into the two `A₅`-classes `5A`, `5B`, which is what
distinguishes `ρ₃` from `ρ₃′`.  They are separated as follows: with the roots
labelled by increasing size, `D = ∏_{i<j}(r_j − r_i) = +√(disc f)` is a positive
integer; in `𝔽_p[x]/(f)` put `s_1 = x`, `s_{i+1} = s_i^p` and
`Δ = ∏_{i<j}(s_i − s_j)`.  Then `Frob_p` lies in the class of `(1 2 3 4 5)` iff
`Δ ≡ D`.

*This test must be done modulo `p²`, not modulo `p`.*  Modulo 2 one has
`+D ≡ −D`, so the mod-`p` test returns an arbitrary answer at `p = 2` and the
resulting `L(ρ₃,s)` is simply a different (and wrong) Dirichlet series.  We
therefore lift the Frobenius to `(ℤ/p²)[x]/(f)` by one Newton step and compare
`Δ` with `±D` there (`artin.A5Field.five_cycle_is_5A`).  The effect is not
subtle: for `d_K = 69072721` the holomorphy residual for `ρ₃` was `1.4·10⁻⁴`
with the mod-`p` test and is `1.3·10⁻¹⁴` with the mod-`p²` test.

**3.3 Local data at ramified primes, and a genuine ambiguity.**  At a ramified
prime the pair (inertia `I`, Frobenius `F`) is reconstructed from the `(e,f)`
data of `p` in `K`.  Occasionally two different pairs give the same `(e,f)` data
but different Euler factors — the standard example is `I = V₄` at `p = 2` with
decomposition group `V₄` or `A₄`.  These are separated by the residue degrees of
`p` in the degree-10 resolvent algebra (the étale algebra of unordered pairs of
roots), which are `1,1,1,1` in the first case and `3,1` in the second.  The
resolvent is computed in floating point and then *certified exactly* by
verifying the polynomial identity
`Res_y(f(y), f(x−y)) = ∏_i(x − 2r_i) · R₁₀(x)²` at 26 integer points
(`scripts/a5/resolvent.py`).

One ambiguity survives this: at a prime with cyclic inertia of order 5 the
decomposition group can be `C₅` or `D₁₀`, and neither the quintic nor the
degree-10 resolvent sees the difference (it would need the degree-12 resolvent).
Fields with that behaviour are flagged and excluded from the table.

**3.4 Consistency with the factorisation of `ζ_K`.**  For every field we verify
`(1−T)·E₄(T) = ∏_{P|p}(1 − T^{f_P})` at the first 300 primes, i.e. the Euler
factors of `ζ(s)·L(ρ₄,s)` agree with those of `ζ_K(s)`, ramified primes
included.  No failures occurred for any field in the table.  The corresponding
class-by-class polynomial identity is proved in Lean
(`A5Artin.permPoly5_eq`), as is the full regular-representation factorisation
(`A5Artin.regPoly_eq`), so the consistency of our Euler factors with the
factorisation of `ζ_N` is automatic once the local data is right.

## 4. Numerical method

`Φ(t)`, the inverse Mellin transform of `(π^{-s/2}Γ(s/2))ⁿ`, is tabulated on a
uniform grid in `log t` by saddle-point contour integration; the table is
validated against the closed forms `Φ₁(t) = 2e^{−πt²}` and `Φ₂(t) = 4K₀(2πt)`
(agreement `≈ 2·10⁻¹³`).  The incomplete Mellin integrals are obtained by
fourth-order cumulative integration and six-point Lagrange interpolation.  The
whole pipeline reproduces `L(χ₅,s)` and its powers `L(χ₅,s)ⁿ` to `10⁻¹³`.

Everything is double precision, so the *absolute* accuracy of `Λ` is around
`10⁻¹²`.  Since `|Λ(1/2+it)|` decays like the gamma factor, this limits the
height up to which zeros can be located — severely so in dimension 5.  The zero
tables below therefore quote the height `T_rel` up to which `|Λ|` stays above
`10⁻⁹`, i.e. three orders of magnitude above the noise.

## 5. Status table: holomorphy tests

The column "FE/holomorphy residual" is the quantity described in 1.4; a value of
`10⁻¹⁴` means that the split-point independence — equivalently, holomorphy of
`Λ` together with the functional equation with the stated `(N, ε=+1)` — holds to
14 significant digits.  The two calibration columns show what a *wrong* sign or
conductor produces.

| d_K | ρ | dim | conductor N | Dirichlet terms | FE/holomorphy residual | with ε = −1 | with wrong N | Λ(1/2) |
|---|---|---|---|---|---|---|---|---|
| 3104644 | ρ₃ | 3 | 3104644 | 27146 | 3.0e-14 | 5.5e+01 | 1.0e-03 | 574.292 |
| 3104644 | ρ₃′ | 3 | 3104644 | 27146 | 1.1e-14 | 6.8e+01 | 1.2e-03 | 682.811 |
| 3104644 | ρ₄ | 4 | 3104644 | 33734 | 6.7e-15 | 1.3e+02 | 2.1e-03 | 1014.25 |
| 3104644 | ρ₅ | 5 | 9638814366736 | – | not attempted (needs 26611239 coefficients (> 6000000)) | | | |
| 5184729 | ρ₃ | 3 | 5184729 | 35079 | 1.8e-14 | 5.3e+01 | 1.6e-03 | 1108.67 |
| 5184729 | ρ₃′ | 3 | 5184729 | 35079 | 9.4e-15 | 5.6e+01 | 6.6e-04 | 802.353 |
| 5184729 | ρ₄ | 4 | 5184729 | 43592 | 1.1e-14 | 7.3e+01 | 1.2e-03 | 673.879 |
| 5184729 | ρ₅ | 5 | 50815528929 | 1932202 | 1.4e-13 | 9.3e+03 | 6.4e-03 | nan |
| 6160324 | ρ₃ | 3 | 6160324 | 38237 | 1.5e-14 | 1.3e+02 | 6.8e-04 | 1378.61 |
| 6160324 | ρ₃′ | 3 | 6160324 | 38237 | 1.6e-14 | 5.1e+01 | 5.6e-04 | 600.876 |
| 6160324 | ρ₄ | 4 | 6160324 | 47516 | 7.9e-15 | 9.3e+01 | 3.0e-04 | 954.083 |
| 6160324 | ρ₅ | 5 | 37949591784976 | – | not attempted (needs 52802782 coefficients (> 6000000)) | | | |
| 6180196 | ρ₃ | 3 | 6180196 | 38299 | 8.8e-15 | 2.9e+01 | 6.5e-04 | 517.713 |
| 6180196 | ρ₃′ | 3 | 6180196 | 38299 | 1.4e-14 | 1.3e+02 | 9.2e-04 | 1374.28 |
| 6180196 | ρ₄ | 4 | 6180196 | 47593 | 7.9e-15 | 1.8e+02 | 2.1e-03 | 1491.08 |
| 6180196 | ρ₅ | 5 | 38194822598416 | – | not attempted (needs 52973113 coefficients (> 6000000)) | | | |
| 7017201 | ρ₃ | 3 | 7017201 | 40810 | 1.0e-14 | 1.2e+02 | 3.1e-04 | 1550.49 |
| 7017201 | ρ₃′ | 3 | 7017201 | 40810 | 1.9e-14 | 8.5e+01 | 2.9e-04 | 944.54 |
| 7017201 | ρ₄ | 4 | 7017201 | 50713 | 1.2e-14 | 7.7e+01 | 6.9e-04 | 773.755 |
| 7017201 | ρ₅ | 5 | 5471234430489 | – | not attempted (needs 20049150 coefficients (> 6000000)) | | | |
| 7409284 | ρ₃ | 3 | 7409284 | 41934 | 7.5e-15 | 9.5e+01 | 7.4e-04 | 1027.17 |
| 7409284 | ρ₃′ | 3 | 7409284 | 41934 | 3.0e-14 | 7.9e+01 | 5.8e-04 | 1142.52 |
| 7409284 | ρ₄ | 4 | 7409284 | 52110 | 6.8e-15 | 1.5e+02 | 1.4e-03 | 1345.02 |
| 7409284 | ρ₅ | 5 | 54897489392656 | – | not attempted (needs 63508153 coefficients (> 6000000)) | | | |
| 8305924 | ρ₃ | 3 | 8305924 | 44399 | 1.6e-14 | 8.3e+01 | 4.6e-04 | 985.062 |
| 8305924 | ρ₃′ | 3 | 8305924 | 44399 | 1.4e-14 | 3.4e+01 | 1.6e-03 | 736.183 |
| 8305924 | ρ₄ | 4 | 8305924 | 55173 | 1.2e-14 | 2.5e+02 | 1.8e-03 | 2083.92 |
| 8305924 | ρ₅ | 5 | 68988373493776 | – | not attempted (needs 71193639 coefficients (> 6000000)) | | | |
| 10791225 | ρ₃ | 3 | 10791225 | 50606 | 1.7e-14 | 2.3e+02 | 1.6e-03 | 2545.85 |
| 10791225 | ρ₃′ | 3 | 10791225 | 50606 | 6.0e-15 | 1.1e+02 | 1.9e-04 | 1392.78 |
| 10791225 | ρ₄ | 4 | 10791225 | 62888 | 8.8e-15 | 8.7e+01 | 9.1e-05 | 993.744 |
| 10791225 | ρ₅ | 5 | 517557942225 | – | not attempted (needs 6166419 coefficients (> 6000000)) | | | |
| 11744329 | ρ₃ | 3 | 11744329 | 52794 | 1.1e-14 | 1.3e+02 | 2.2e-05 | 1685.26 |
| 11744329 | ρ₃′ | 3 | 11744329 | 52794 | 4.9e-15 | 1.1e+02 | 7.6e-04 | 1292.77 |
| 11744329 | ρ₄ | 4 | 11744329 | 65606 | 9.8e-15 | 2.0e+02 | 1.4e-03 | 1851.55 |
| 11744329 | ρ₅ | 5 | 137929263660241 | – | not attempted (needs 100665682 coefficients (> 6000000)) | | | |
| 11812969 | ρ₃ | 3 | 11812969 | 52948 | 1.4e-14 | 1.3e+02 | 1.0e-03 | 1399.76 |
| 11812969 | ρ₃′ | 3 | 11812969 | 52948 | 1.3e-14 | 2.7e+02 | 5.7e-04 | 2924.36 |
| 11812969 | ρ₄ | 4 | 11812969 | 65797 | 2.0e-14 | 7.2e+01 | 6.0e-04 | 798.713 |
| 11812969 | ρ₅ | 5 | 2847882379489 | – | not attempted (needs 14464865 coefficients (> 6000000)) | | | |
| 13060996 | ρ₃ | 3 | 13060996 | 55674 | 2.9e-14 | 1.4e+02 | 3.3e-04 | 1727.87 |
| 13060996 | ρ₃′ | 3 | 13060996 | 55674 | 5.7e-15 | 1.7e+02 | 1.0e-03 | 1755.92 |
| 13060996 | ρ₄ | 4 | 13060996 | 69185 | 7.5e-15 | 1.3e+02 | 1.1e-03 | 1339.86 |
| 13060996 | ρ₅ | 5 | 8829233296 | 805410 | 4.8e-14 | 6.3e+03 | 7.7e-04 | nan |
| 30991489 | ρ₃ | 3 | 30991489 | 85758 | 4.9e-15 | 7.1e+02 | 1.0e-03 | 7431.72 |
| 30991489 | ρ₃′ | 3 | 30991489 | 85758 | 2.2e-14 | 2.1e+02 | 4.9e-06 | 2899.4 |
| 30991489 | ρ₄ | 4 | 30991489 | 106571 | 1.1e-14 | 6.7e+01 | 9.9e-04 | 813.755 |
| 30991489 | ρ₅ | 5 | 30991489 | 116717 | 6.7e-15 | 3.1e+02 | 2.3e-03 | 2459.99 |
| 37124649 | ρ₃ | 3 | 37124649 | 93861 | 1.1e-14 | 2.1e+02 | 2.8e-04 | 2777.75 |
| 37124649 | ρ₃′ | 3 | 37124649 | 93861 | 2.3e-14 | 4.4e+02 | 5.2e-04 | 5431.26 |
| 37124649 | ρ₄ | 4 | 37124649 | 116640 | 2.2e-14 | 2.8e+02 | 1.3e-03 | 2731.39 |
| 37124649 | ρ₅ | 5 | 334121841 | 383225 | 1.1e-14 | 9.5e+02 | 1.1e-03 | 9223.6 |
| 69072721 | ρ₃ | 3 | 69072721 | 128027 | 1.3e-14 | 2.3e+02 | 3.9e-04 | 3005.64 |
| 69072721 | ρ₃′ | 3 | 69072721 | 128027 | 1.8e-14 | 8.5e+02 | 4.4e-05 | 11366.8 |
| 69072721 | ρ₄ | 4 | 69072721 | 159098 | 1.1e-14 | 9.8e+01 | 4.6e-04 | 1478.23 |
| 69072721 | ρ₅ | 5 | 69072721 | 174245 | 5.2e-15 | 3.2e+02 | 1.1e-03 | 2976.73 |
| 119486761 | ρ₃ | 3 | 119486761 | 168385 | 1.6e-14 | 4.6e+02 | 5.0e-06 | 6838.8 |
| 119486761 | ρ₃′ | 3 | 119486761 | 168385 | 5.1e-14 | 7.1e+02 | 4.8e-04 | 8831.19 |
| 119486761 | ρ₄ | 4 | 119486761 | 209251 | 2.6e-14 | 4.3e+01 | 4.5e-04 | 962.377 |
| 119486761 | ρ₅ | 5 | 119486761 | 229174 | 6.4e-15 | 5.4e+02 | 1.6e-03 | 4828.52 |

## 6. Zeros

**6.1 No real zeros in `(0,1)`.**  `Λ(σ)` was evaluated on `[1/2, 1]` in steps of
`0.025`; by the functional equation this covers `(0,1)`.  In every case `Λ` is
strictly positive there, with minimum at `σ = 1/2`.  In particular
`Λ(1/2) > 0`: no central zero, and no "exceptional real zero", for any of the
representations tested — including all the dimension-5 cases.

| d_K | ρ | min |Λ(σ)| on [1/2,1] | sign change on (0,1)? |
|---|---|---|---|
| 3104644 | ρ₃ | 574.292 | no |
| 3104644 | ρ₃′ | 682.811 | no |
| 3104644 | ρ₄ | 1014.25 | no |
| 5184729 | ρ₃ | 1108.67 | no |
| 5184729 | ρ₃′ | 802.353 | no |
| 5184729 | ρ₄ | 673.879 | no |
| 6160324 | ρ₃ | 1378.61 | no |
| 6160324 | ρ₃′ | 600.876 | no |
| 6160324 | ρ₄ | 954.083 | no |
| 6180196 | ρ₃ | 517.713 | no |
| 6180196 | ρ₃′ | 1374.28 | no |
| 6180196 | ρ₄ | 1491.08 | no |
| 7017201 | ρ₃ | 1550.49 | no |
| 7017201 | ρ₃′ | 944.54 | no |
| 7017201 | ρ₄ | 773.755 | no |
| 7409284 | ρ₃ | 1027.17 | no |
| 7409284 | ρ₃′ | 1142.52 | no |
| 7409284 | ρ₄ | 1345.02 | no |
| 8305924 | ρ₃ | 985.062 | no |
| 8305924 | ρ₃′ | 736.183 | no |
| 8305924 | ρ₄ | 2083.92 | no |
| 10791225 | ρ₃ | 2545.85 | no |
| 10791225 | ρ₃′ | 1392.78 | no |
| 10791225 | ρ₄ | 993.744 | no |
| 11744329 | ρ₃ | 1685.26 | no |
| 11744329 | ρ₃′ | 1292.77 | no |
| 11744329 | ρ₄ | 1851.55 | no |
| 11812969 | ρ₃ | 1399.76 | no |
| 11812969 | ρ₃′ | 2924.36 | no |
| 11812969 | ρ₄ | 798.713 | no |
| 13060996 | ρ₃ | 1727.87 | no |
| 13060996 | ρ₃′ | 1755.92 | no |
| 13060996 | ρ₄ | 1339.86 | no |
| 30991489 | ρ₃ | 7431.72 | no |
| 30991489 | ρ₃′ | 2899.4 | no |
| 30991489 | ρ₄ | 813.755 | no |
| 30991489 | ρ₅ | 2459.99 | no |
| 37124649 | ρ₃ | 2777.75 | no |
| 37124649 | ρ₃′ | 5431.26 | no |
| 37124649 | ρ₄ | 2731.39 | no |
| 37124649 | ρ₅ | 9223.6 | no |
| 69072721 | ρ₃ | 3005.64 | no |
| 69072721 | ρ₃′ | 11366.8 | no |
| 69072721 | ρ₄ | 1478.23 | no |
| 69072721 | ρ₅ | 2976.73 | no |
| 119486761 | ρ₃ | 6838.8 | no |
| 119486761 | ρ₃′ | 8831.19 | no |
| 119486761 | ρ₄ | 962.377 | no |
| 119486761 | ρ₅ | 4828.52 | no |

**6.2 Zeros on the critical line.**  Sign changes of `Λ(1/2+it)` were located on
a grid of step `0.02`.

| d_K | ρ | dim | N | T_rel | zeros in (0,T_rel] | RvM prediction | first zero |
|---|---|---|---|---|---|---|---|
| 3104644 | ρ₃ | 3 | 3104644 | 9.64 | 20 | 20.9 | 0.9361 |
| 3104644 | ρ₃′ | 3 | 3104644 | 9.66 | 20 | 21.0 | 0.9981 |
| 3104644 | ρ₄ | 4 | 3104644 | 8.74 | 17 | 17.6 | 1.3580 |
| 5184729 | ρ₃ | 3 | 5184729 | 9.82 | 21 | 22.2 | 0.6101 |
| 5184729 | ρ₃′ | 3 | 5184729 | 9.84 | 21 | 22.2 | 0.7113 |
| 5184729 | ρ₄ | 4 | 5184729 | 7.92 | 15 | 16.1 | 1.0773 |
| 30991489 | ρ₃ | 3 | 30991489 | 9.88 | 24 | 25.2 | 1.0249 |
| 30991489 | ρ₃′ | 3 | 30991489 | 9.70 | 24 | 24.6 | 0.6907 |
| 30991489 | ρ₄ | 4 | 30991489 | 7.82 | 17 | 18.1 | 0.7330 |
| 30991489 | ρ₅ | 5 | 30991489 | 6.34 | 12 | 12.8 | 1.4948 |
| 69072721 | ρ₃ | 3 | 69072721 | 9.68 | 25 | 25.8 | 0.7224 |
| 69072721 | ρ₃′ | 3 | 69072721 | 9.66 | 25 | 25.8 | 0.7302 |
| 69072721 | ρ₄ | 4 | 69072721 | 7.92 | 18 | 19.4 | 0.6729 |
| 69072721 | ρ₅ | 5 | 69072721 | 6.82 | 14 | 15.0 | 1.0850 |

All located zeros lie on `Re s = 1/2` (they are sign changes of the real
function `t ↦ Λ(1/2+it)`).  The counts agree with the Riemann–von Mangoldt
prediction to within the `O(log N)` error term of that formula and the
possibility of unresolved close pairs; no evidence of missing or extra zeros was
found.  Note that this is *not* a verification of RH for these L-functions: we
have not performed a Turing-type argument bounding the number of zeros off the
line.

## 7. Status assessment

*Strong numerical evidence of holomorphy* (split-point residual `≤ 10⁻¹³`,
wrong-sign and wrong-conductor variants `O(10)`–`O(10³)`, no real zero in
`(0,1)`, zero counts consistent with Riemann–von Mangoldt):

* dimensions 3, 3′, 4 for **every** field in the status table;
* dimension 5 for `d_K = 30991489` and `d_K = 69072721`, and (functional
  equation only, no zero search) for `d_K = 5184729`.

*No anomalies.*  No representation showed a real zero in `(0,1)`, a central
zero, or a split-point residual incompatible with holomorphy.  The only
irregularity encountered in the whole run — the `d_K = 69072721` degree-3
residual of `1.4·10⁻⁴` — was traced to the arithmetic bug described in 3.2 and
disappeared once the `5A/5B` test was done modulo `p²`.

*Most promising fields for a future rigorous verification.*

1. **`d_K = 30991489`, `f = x⁵ + x⁴ − 15x³ − 36x² − 21x − 1`.**  A single
   ramified prime `p = 5567`, tame, inertia of order 2, so
   `N(ρ₃) = N(ρ₃′) = N(ρ₄) = N(ρ₅) = 5567²`.  This is the *smallest* field for
   which all four L-functions, including the 5-dimensional one, have a conductor
   small enough for a complete numerical treatment.  Total reality of `f` is
   proved in Lean (`A5Artin.f₂_totally_real`).
2. **`d_K = 69072721`, `f = x⁵ + x⁴ − 16x³ − 7x² + 57x − 35`.**  Same structure
   (one tame prime `8311`, inertia of order 2), slightly larger.
3. **`d_K = 3104644`, `f = x⁵ + x⁴ − 11x³ − x² + 12x + 4`.**  The smallest
   totally real `A₅` quintic in the list; dimensions 3, 3′, 4 are cheap, but
   `N(ρ₅) = 9.6·10¹²` puts dimension 5 out of reach of this pipeline.  Total
   reality proved in Lean (`A5Artin.f₁_totally_real`).

## 8. Theoretical observations

**8.1 No cover is needed, and that is the whole point.**  The famous even
icosahedral case concerns *two*-dimensional representations, which are
projective `A₅`-representations and require the binary icosahedral group
`SL₂(𝔽₅)`.  The representations studied here are honest representations of
`A₅`, i.e. class functions of the quintic field; nothing about the run depends
on a `2`-cover.  What is lost is exactly the input that makes the odd
2-dimensional case a theorem: there is no Serre-type modularity statement for
`GLₙ`, `n ≥ 3`, that applies here.

**8.2 The root number.**  Every computation is consistent with `ε = +1`, to
14 digits, for all four representations and all fields.  This is what one
expects: all four representations are orthogonal (real character, Frobenius–
Schur indicator `+1`) and `A₅` is perfect, so `det ρ = 1`; Deligne's formula for
the root number of an orthogonal virtual representation of dimension 0 and
trivial determinant then expresses `ε` through a second Stiefel–Whitney class.
Our data can be read as a numerical confirmation that this class is trivial in
these examples.

**8.3 What functoriality would give.**  `ρ₄ = Ind_{A₄}^{A₅} 1 − 1`, so
`L(ρ₄,s) = ζ_K(s)/ζ(s)` and holomorphy of `L(ρ₄)` is exactly Dedekind's
conjecture for the quintic field `K`.  Similarly `ρ₅ = Ind_{D₁₀}^{A₅} 1 − 1`
gives `L(ρ₅,s) = ζ_{K₆}(s)/ζ(s)` for the sextic resolvent field `K₆`, and
`L(ρ₃)L(ρ₃′)L(ρ₅) = ζ_{K₁₂}(s)/ζ(s)` for the degree-12 field fixed by a Sylow
5-subgroup (`A5Artin.permPoly6_eq`, `A5Artin.permPoly12_eq`).  So the four open
holomorphy statements are equivalent to Dedekind-type statements for three
explicit number fields of degrees 5, 6 and 12 — a reformulation that makes the
dimension-5 case no harder than the others, and that suggests that the
`ζ_{K₆}/ζ` and `ζ_{K₁₂}/ζ` quotients are the right objects to attack.

**8.4 Where the even case is genuinely harder.**  Two concrete obstructions
show up in the computation itself.  (i) The gamma factor `Γ_ℝ(s)ⁿ` has an
`n`-fold pole at `s = 0`; on the critical line `|Λ(1/2+it)|` decays like
`e^{−nπt/4}`, so the numerical accessible range shrinks rapidly with the
dimension — this, and not the conductor, is what limits the dimension-5 zero
searches here.  (ii) The conductor of `ρ₅` is `d_K²` at every prime with inertia
of order 3 or 5 and only equals `d_K` at primes with inertia of order 2, so the
analytic conductor of `ρ₅` grows much faster than that of `ρ₄` across the family;
the fields for which dimension 5 is tractable are a thin subfamily
(those ramified only at primes with inertia of order 2).

## 9. What is still missing for a rigorous verification

For a *proof* of holomorphy of one of these L-functions in a single explicit
case one would need, beyond what is here:

1. **Interval/ball arithmetic** throughout: certified enclosures for the Euler
   factors (these are exact algebraic numbers, so this part is easy), for the
   inverse Mellin kernel `Φ`, for the incomplete Mellin integrals, and for the
   truncation tails.
2. **An effective bound on the number of poles.**  Brauer's induction expresses
   `L(ρ,s)` as `∏ L(χ_i,s)^{n_i}` with `n_i ∈ ℤ`; the possible poles lie among
   the zeros of the Hecke L-functions with negative exponent.  A finite,
   effectively computable region containing all possible poles, together with an
   argument-principle computation in that region, would turn the numerics into a
   proof.  This is the essential missing analytic ingredient.
3. **A Turing-type zero-counting argument** if one also wants RH-on-the-line
   statements; this in turn needs rigorous bounds on `∫ arg Λ`.
4. For the ambiguous fields of 3.3, the degree-12 resolvent (or a `5`-adic
   computation in the local quintic) to pin down the Euler factor at the wildly
   ramified prime `5`.

None of these is a conceptual obstacle for a single field; the missing piece
that would make the *general* even `A₅` case a theorem is, of course, something
else entirely — a functoriality or modularity input for `GL₃/GL₄/GL₅` that is
not available.

## 10. Files

| file | contents |
|---|---|
| `scripts/a5/ntlib.py` | integer/modular polynomial arithmetic, resultants, factorisation mod `p`, Dedekind's criterion |
| `scripts/a5/search.py`, `par_search.sh`, `merge.py` | Hunter-bound enumeration of totally real `A₅` quintics |
| `scripts/a5/round2.py` | Pohst–Zassenhaus `p`-maximal orders, exact field discriminants |
| `scripts/a5/pgen.py`, `order_ef.py` | `p`-maximal defining polynomials; residue degrees inside the maximal order (non-monogenic primes) |
| `scripts/a5/resolvent.py` | certified degree-10 resolvent |
| `scripts/a5/artin.py` | `A₅` character table, Frobenius classes, `5A/5B` separation, local Euler factors, conductor exponents |
| `scripts/a5/field_data.py` | assembly of all arithmetic data of one field |
| `scripts/a5/lfunc.py` | numerical completed L-functions with `Γ_ℝ(s)ⁿ` |
| `scripts/a5/analyse.py`, `run_one.py`, `run_batch.sh`, `zeros_fine.py` | the numerical experiments |
| `scripts/a5/catalog.py`, `make_report.py` | the tables in this report |
| `data/a5/catalog.json` | field table: discriminants, ramification, conductors |
| `data/a5/field_*.json` | per-field L-function results |
| `data/a5/zeros_*.json` | fine zero searches |
| `RequestProject/A5Artin.lean` | Lean proofs of the local factorisation identities, character orthogonality, and total reality of the two key defining polynomials |

## 11. Summary of the Lean content

| statement | meaning |
|---|---|
| `A5Artin.permPoly5_eq` | `ζ_K = ζ · L(ρ₄)` at the level of Euler factors, for every conjugacy class |
| `A5Artin.permPoly6_eq` | `ζ_{K₆} = ζ · L(ρ₅)` |
| `A5Artin.permPoly12_eq` | `ζ_{K₁₂} = ζ · L(ρ₃) L(ρ₃′) L(ρ₅)` |
| `A5Artin.regPoly_eq` | `ζ_N = ζ · L(ρ₃)³ L(ρ₃′)³ L(ρ₄)⁴ L(ρ₅)⁵` |
| `A5Artin.E3_mul_E3b` | the product of the two 3-dimensional Euler factors is rational |
| `A5Artin.chi3_norm`, … | row orthogonality of the character table |
| `A5Artin.f₁_totally_real`, `A5Artin.f₂_totally_real` | the two key quintics have five real roots, so the fields are totally real and the representations are even |
