import re, math
txt=''.join(open('/workspace/request-project/RequestProject/PolyaOscBlocks%d.lean'%i).read() for i in (1,2,3,4))
hdr=re.compile(r'theorem oscBlock(\d+) : errIntBracket \(vBP ([0-9.]+)\) \(vBP ([0-9.]+)\) \(?(-?[0-9.]+)\)? \(?(-?[0-9.]+)\)? ([0-9.]+) :=')
pc=re.compile(r'errPiece_(taylor|asymp) \(q0 := ([0-9.]+)\) \(q1 := ([0-9.]+)\) \(Lo := \(?(-?[0-9.]+)\)?\) \(Hi := \(?(-?[0-9.]+)\)?\) \(M := ([0-9.]+)\)')
ms=list(hdr.finditer(txt))
pieces=[]
for k,m in enumerate(ms):
    body=txt[m.end(): ms[k+1].start() if k+1<len(ms) else len(txt)]
    for p in pc.finditer(body):
        q0=float(p.group(2)); q1=float(p.group(3)); Lo=float(p.group(4)); Hi=float(p.group(5)); M=float(p.group(6))
        w=1/q0-1/q1
        pieces.append(dict(kind=p.group(1),q0=q0,q1=q1,Lo=Lo,Hi=Hi,M=M,P0=2*Lo*w,P1=2*Hi*w,S=2*M*w))
blocks_cur=[(float(m.group(2)),float(m.group(3))) for m in ms]
def vBP(q): return 2*math.log(q)

def cosbracket(lo,hi):
    mx=max(math.cos(lo),math.cos(hi)); mn=min(math.cos(lo),math.cos(hi))
    k0=math.ceil(lo/math.pi)
    while k0*math.pi<=hi:
        if k0%2==0: mx=1.0
        else: mn=-1.0
        k0+=1
    return (mx+mn)/2,(mx-mn)/2

def group(t0,t1,phimax):
    """greedy grouping of pieces into blocks with phase width <= phimax"""
    groups=[]; cur=[]
    for p in pieces:
        trial=cur+[p]
        a=vBP(trial[0]['q0']); b=vBP(trial[-1]['q1'])
        if t1*b-t0*a>phimax and cur:
            groups.append(cur); cur=[p]
        else:
            cur=trial
    if cur: groups.append(cur)
    return groups

def eta(t0,t1,phimax,tail=0.013709):
    gs=group(t0,t1,phimax); tot=0.0
    for g in gs:
        a=vBP(g[0]['q0']); b=vBP(g[-1]['q1'])
        P0=sum(x['P0'] for x in g); P1=sum(x['P1'] for x in g); S=sum(x['S'] for x in g)
        C,h=cosbracket(t0*a,t1*b)
        tot+=min(C*P0,C*P1)-h*S
    return tot-tail, len(gs)

def theta(t): return sum((t*t/4)/((n+0.25)*((n+0.25)**2+t*t/4)) for n in range(80))
def req(a,b): return -( theta(a)-5.37221 + 1/(0.25+b*b)+12.66/(9+b*b) )/2

if __name__=='__main__':
    # reproduce current bands
    for (t0,t1) in [(7.0,7.25),(5.5,5.53125)]:
        gs=[]
        tot=0
        for (q0,q1) in blocks_cur:
            g=[p for p in pieces if p['q0']>=q0-1e-12 and p['q1']<=q1+1e-12]
            a=vBP(q0); b=vBP(q1)
            P0=sum(x['P0'] for x in g); P1=sum(x['P1'] for x in g); S=sum(x['S'] for x in g)
            C,h=cosbracket(t0*a,t1*b)
            tot+=min(C*P0,C*P1)-h*S
        print('current grouping band [%.4f,%.4f]: eta=%.5f  req=%.5f margin=%.5f'%(t0,t1,tot-0.013709,req(t0,t1),tot-0.013709-req(t0,t1)))
    print()
    for t0 in [4.0,4.25,4.5,4.75,5.0,5.25,5.5]:
        for dt in [0.03125,0.0625]:
            t1=t0+dt
            for phimax in [0.05,0.08,0.12,0.2]:
                e,n=eta(t0,t1,phimax)
                print('t0=%.4f dt=%.5f phimax=%.2f nblk=%3d eta=%.5f req=%.5f margin=%+.5f'%(t0,dt,phimax,n,e,req(t0,t1),e-req(t0,t1)))
        print()
