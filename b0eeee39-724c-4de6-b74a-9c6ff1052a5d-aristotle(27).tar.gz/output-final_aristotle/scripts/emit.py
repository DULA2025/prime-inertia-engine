"""Emit the Lean files of the linear-phase oscillatory estimate.

Produces
  RequestProject/PolyaLinVbp<i>.lean      -- rational brackets for the 561 breakpoints
  RequestProject/PolyaLinPieces<i>.lean   -- pointwise brackets for the 560 pieces
  RequestProject/PolyaLinBlocks.lean      -- the block data (integral + first moment)
  RequestProject/PolyaLinBand<b>.lean     -- one file per frequency band
  RequestProject/PolyaLinThreshold.lean   -- the resulting threshold theorem
"""
import sys, os
sys.path.insert(0, '/workspace/request-project/scripts')
from fractions import Fraction as F
import plan6
from plan6 import (PIECES, VBR, QS, make_blocks, band_block, eta, req, TAIL, mn4, mx4)
from gen import lit, dec, rd, ru
from plan8 import bands

ROOT = '/workspace/request-project/RequestProject'

HEAD = """/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license.
-/
%s

/-!
%s
-/

set_option maxHeartbeats 1000000

noncomputable section

open MeasureTheory Set Real

namespace ConnesConsani.WeilPositivity

"""

FOOT = "\nend ConnesConsani.WeilPositivity\n"


def write(name, imports, doc, body):
    with open(os.path.join(ROOT, name + '.lean'), 'w') as f:
        f.write(HEAD % ('\n'.join('import ' + i for i in imports)
                        if isinstance(imports, list) else imports, doc))
        f.write(body)
        f.write(FOOT)


# ---------------------------------------------------------------- 1. vBP brackets
def emit_vbp(nfiles=4):
    idx = {q: i for i, q in enumerate(QS)}
    lines = []
    for i, q in enumerate(QS):
        if q == 1:
            lines.append('theorem vbpP%d : (0:ℝ) ≤ vBP 1 ∧ vBP 1 ≤ 0 := by\n'
                         '  rw [vBP_one]; norm_num\n' % i)
        else:
            lo, hi = VBR[q]
            lines.append(
                'theorem vbpP%d : (%s:ℝ) ≤ vBP %s ∧ vBP %s ≤ %s := by\n'
                '  have h := vBP_bracket 12 (q := %s) (by norm_num)\n'
                '  norm_num [Finset.sum_range_succ, abs_le] at h\n'
                '  constructor <;> linarith [h.1, h.2]\n'
                % (i, dec(lo), dec(q), dec(q), dec(hi), dec(q)))
    names = []
    per = (len(lines) + nfiles - 1) // nfiles
    for k in range(nfiles):
        chunk = lines[k * per:(k + 1) * per]
        if not chunk:
            continue
        nm = 'PolyaLinVbp%d' % (k + 1)
        imports = ['RequestProject.PolyaOscLin']
        write(nm, imports,
              '# Rational brackets for the breakpoints `vBP q = 2 log q` (part %d)\n\n'
              'Each bracket comes from the logarithmic series `vBP_bracket 12`.' % (k + 1),
              '\n'.join(chunk))
        names.append(nm)
    return names, idx


# ---------------------------------------------------------------- 2. piece brackets
def piece_proof(i, p):
    q0, q1, Lo, Hi = p['q0'], p['q1'], p['Lo'], p['Hi']
    head = 'theorem errPt%d : errPtBracket %s %s %s %s :=\n' % (i, dec(q0), dec(q1),
                                                                lit(Lo), lit(Hi))
    if p['trig'] is None:
        if p['kind'] == 'taylor':
            return head + ('  errPiece_crude_taylor (by norm_num) (by norm_num)\n'
                           '    (by norm_num [taylorQup, siDivPart, Finset.sum_range_succ])\n'
                           '    (by norm_num [taylorQ, siDivPart, Finset.sum_range_succ])\n')
        return head + ('  errPiece_crude_asymp (by norm_num) (by norm_num) (by norm_num)\n'
                       '    (by norm_num) (by norm_num)\n')
    K, j, u0, u1, Cr = p['trig']
    C0, C1, S0, S1 = Cr
    trig = ('    (fun r hr0 hr1 => trigBracket%d (u0 := %s) (u1 := %s) (j := (%d:ℤ))\n'
            '      (by norm_num) (by norm_num)\n'
            '      (by push_cast; linarith) (by push_cast; linarith)\n'
            '      (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])'
            ' (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])\n'
            '      (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])'
            ' (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP]))\n'
            % (K, dec(u0), dec(u1), j))
    named = ('    (C0 := %s) (C1 := %s) (S0 := %s) (S1 := %s)\n'
             % (lit(C0), lit(C1), lit(S0), lit(S1)))
    if p['kind'] == 'taylor':
        return (head + '  errPiece_sharp_taylor\n' + named
                + '    (by norm_num) (by norm_num)\n' + trig
                + '    (by norm_num) (by norm_num) (by norm_num [siLoSharp])\n'
                + '    (by norm_num [aLoSharp, siLoSharp, taylorQ, siDivPart,'
                  ' Finset.sum_range_succ])\n'
                + '    (by norm_num [aHiSharp, siHiSharp, taylorQup, siDivPart,'
                  ' Finset.sum_range_succ])\n')
    return (head + '  errPiece_sharp_asymp\n' + named
            + '    (by norm_num) (by norm_num)\n' + trig
            + '    (by norm_num) (by norm_num) (by norm_num [siLoSharp])\n'
            + '    (by norm_num) (by norm_num) (by norm_num [siLoSharp])\n'
            + '    (by norm_num [aLoSharp, bLoSharp, siLoSharp])\n'
            + '    (by norm_num [aHiSharp, bHiSharp, siHiSharp])\n')


def emit_pieces(nfiles=8):
    lines = [piece_proof(i, p) for i, p in enumerate(PIECES)]
    names = []
    per = (len(lines) + nfiles - 1) // nfiles
    for k in range(nfiles):
        chunk = lines[k * per:(k + 1) * per]
        if not chunk:
            continue
        nm = 'PolyaLinPieces%d' % (k + 1)
        imports = ['RequestProject.PolyaOscLin']
        write(nm, imports,
              '# Sharpened pointwise brackets on the pieces of the partition (part %d)' % (k + 1),
              '\n'.join(chunk))
        names.append(nm)
    return names


# ---------------------------------------------------------------- 3. block data
def emit_blocks(deps, blocks, idx, nfiles=4):
    out = []
    for k, B in enumerate(blocks):
        im = idx[B['qm']]
        hs = []
        for n, i in enumerate(B['g']):
            p = PIECES[i]
            A0, A1 = VBR[p['q0']]
            B0, B1 = VBR[p['q1']]
            m0, m1 = B['m0'], B['m1']
            Klo = rd(2 * (A0 + 2 - m1) / p['q0'] - 2 * (B1 + 2 - m0) / p['q1'], 12)
            Khi = ru(2 * (A1 + 2 - m0) / p['q0'] - 2 * (B0 + 2 - m1) / p['q1'], 12)
            sgn = ('Or.inl' if B['qm'] <= p['q0'] else 'Or.inr')
            hs.append(
                '  have h%d := errBlockLin_of_piece (q0 := %s) (q1 := %s) (m := vBP %s)\n'
                '    (Lo := %s) (Hi := %s) (Klo := %s) (Khi := %s)\n'
                '    (by norm_num) (by norm_num) (by norm_num) errPt%d\n'
                '    vbpP%d.1 vbpP%d.2 vbpP%d.1 vbpP%d.2 vbpP%d.1 vbpP%d.2\n'
                '    (%s (vBP_mono (by norm_num) (by norm_num))) (by norm_num) (by norm_num)\n'
                % (n, dec(p['q0']), dec(p['q1']), dec(B['qm']), lit(p['Lo']), lit(p['Hi']),
                   lit(Klo), lit(Khi), i, idx[p['q0']], idx[p['q0']], idx[p['q1']],
                   idx[p['q1']], im, im, sgn))
        chain = 'h0'
        for n in range(1, len(B['g'])):
            chain = '(%s.add h%d)' % (chain, n)
        out.append(
            'theorem blkLin%d : errBlockLin (vBP %s) (vBP %s) (vBP %s) %s %s %s %s %s := by\n'
            % (k, dec(B['qa']), dec(B['qb']), dec(B['qm']), lit(B['P0']), lit(B['P1']),
               lit(B['R0']), lit(B['R1']), lit(B['S']))
            + ''.join(hs)
            + '  exact %s.mono (by norm_num) (by norm_num) (by norm_num [mn4])\n'
              '    (by norm_num [mx4]) (by norm_num)\n' % chain)
    names = []
    tot = sum(len(x.split('\n')) for x in out)
    chunks, cur, curn = [], [], 0
    for x in out:
        cur.append(x); curn += len(x.split('\n'))
        if curn >= tot / nfiles and len(chunks) < nfiles - 1:
            chunks.append(cur); cur, curn = [], 0
    if cur:
        chunks.append(cur)
    for k, chunk in enumerate(chunks):
        nm = 'PolyaLinBlocks%d' % (k + 1)
        write(nm, ['RequestProject.' + d for d in deps],
              '# The block data: integral, first moment and absolute integral of `err`'
              ' (part %d)\n\n'
              'Each block groups consecutive pieces of the partition; the base point `vBP qm` is'
              ' a\nbreakpoint near the middle of the block.' % (k + 1),
              '\n'.join(chunk))
        names.append(nm)
    return names


# ---------------------------------------------------------------- 4. bands
def emit_band(b, deps, blocks, t0, t1, idx):
    data = [band_block(B, t0, t1) for B in blocks]
    assert all(d is not None for d in data)
    tot = sum(d['L'] for d in data)
    out = []
    for k, (B, d) in enumerate(zip(blocks, data)):
        ia, ib, im = idx[B['qa']], idx[B['qb']], idx[B['qm']]
        K = d['K']
        out.append(
            'theorem cosLB%d_%d {t : ℝ} (ht0 : (%s:ℝ) ≤ t) (ht1 : t ≤ %s) :\n'
            '    (%s:ℝ) ≤ ∫ v in (vBP %s)..(vBP %s), errFun v * Real.cos (t * v) := by\n'
            '  have hp := trigPoint%d (X := %s) (ylo := %s) (yhi := %s) (j := (%d:ℤ))\n'
            '    (c0 := %s) (c1 := %s) (s0 := %s) (s1 := %s)\n'
            '    (by norm_num) (by linarith [Real.pi_gt_d20])\n'
            '    (by push_cast; linarith [Real.pi_gt_d20, Real.pi_lt_d20])\n'
            '    (by push_cast; linarith [Real.pi_gt_d20, Real.pi_lt_d20])\n'
            '    (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])'
            ' (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])\n'
            '    (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])'
            ' (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])\n'
            '  have hm := mul_mem_of_bracket (t0 := %s) (t1 := %s) (X0 := %s) (W := %s)\n'
            '    ht0 ht1 vbpP%d.1 vbpP%d.2 (by norm_num) (by norm_num) (by norm_num)'
            ' (by norm_num)\n'
            '  have hs := trig_shift_bracket (W := %s) (by norm_num) (by norm_num) hm.1 hm.2\n'
            '    hp.1 hp.2.1 hp.2.2.1 hp.2.2.2\n'
            '  exact errCos_block_ge_lin (t0 := %s) (t1 := %s) (d := %s)\n'
            '    (ulo := %s) (uhi := %s) (vlo := %s) (vhi := %s)\n'
            '    (vBP_mono (by norm_num) (by norm_num)) (by norm_num)\n'
            '    (by linarith [vbpP%d.1, vbpP%d.2]) (by linarith [vbpP%d.2, vbpP%d.1])\n'
            '    ht0 ht1 (by norm_num) blkLin%d\n'
            '    (le_trans (by norm_num [mn4, mx4, cosLoP, sinHiP]) hs.1)\n'
            '    (le_trans hs.2.1 (by norm_num [mn4, mx4, cosLoP, sinHiP]))\n'
            '    (le_trans (by norm_num [mn4, mx4, cosLoP, sinHiP]) hs.2.2.1)\n'
            '    (le_trans hs.2.2.2 (by norm_num [mn4, mx4, cosLoP, sinHiP]))\n'
            '    (by norm_num [mn4, mx4])\n'
            % (b, k, dec(t0), dec(t1), lit(d['L']), dec(B['qa']), dec(B['qb']),
               K, dec(d['X0']), dec(d['ylo']), dec(d['yhi']), d['j'],
               lit(d['c0']), lit(d['c1']), lit(d['s0']), lit(d['s1']),
               dec(t0), dec(t1), dec(d['X0']), dec(d['W']), im, im,
               dec(d['W']), dec(t0), dec(t1), dec(B['d']),
               lit(d['ulo']), lit(d['uhi']), lit(d['vlo']), lit(d['vhi']),
               ia, im, ib, im, k))
    n = len(blocks)
    chain = ('(errCos_add_ge ' * (n - 1)) + '(cosLB%d_0 ht0 ht1)\n' % b
    for k in range(1, n):
        chain += '    (cosLB%d_%d ht0 ht1))' % (b, k) + ('\n' if k < n - 1 else '')
    eta_val = rd(tot - TAIL, 10)
    out.append(
        '/-- Lower bound for `∫₀^∞ err(v) cos(tv) dv` on the band `%s ≤ t ≤ %s`. -/\n'
        'theorem oscLinBand%d {t : ℝ} (ht0 : (%s:ℝ) ≤ t) (ht1 : t ≤ %s) :\n'
        '    (%s:ℝ) ≤ ∫ v in Ioi (0:ℝ), errFun v * Real.cos (t * v) := by\n'
        '  have hsum := %s\n'
        '  rw [vBP_one] at hsum\n'
        '  have hsplit := integral_Ioi_errFun_cos_split t (c := vBP 2.094)'
        ' (vBP_nonneg (by norm_num))\n'
        '  have htail := abs_integral_Ioi_errFun_cos_le (t := t) (c := vBP 2.094)'
        ' (S := 0.013709)\n'
        '    (vBP_nonneg (by norm_num)) integral_Ioi_abs_errFun_tail_cut\n'
        '  rw [abs_le] at htail\n'
        '  rw [hsplit]\n'
        '  linarith [hsum, htail.1]\n'
        % (dec(t0), dec(t1), b, dec(t0), dec(t1), lit(eta_val), chain))
    nm = 'PolyaLinBand%d' % b
    write(nm, ['RequestProject.PolyaOscTail'] + ['RequestProject.' + d for d in deps],
          '# Oscillatory lower bound on the band `%s ≤ t ≤ %s`\n\n'
          'On each block the phase `t v` is linearised at the base point, so that the error is\n'
          'quadratic in the block width; the signed contributions are then summed and the\n'
          'unresolved tail beyond `q = 2.094` is estimated in absolute value.'
          % (dec(t0), dec(t1)),
          '\n'.join(out))
    return nm, eta_val


def emit_threshold(bandlist, deps, tstart):
    """bandlist : list of (b, t0, t1, eta)"""
    body = []
    body.append(
        '/-- **The Fourier-side inequality for `|t| ≥ %s`.**  This lowers the threshold `5.5`\n'
        'of `fourierSide_nonneg_of_five_and_half_le_abs`; the gain comes from linearising the\n'
        'phase of `cos(tv)` on each block, which makes the block error quadratic rather than\n'
        'linear in the block width. -/\n'
        'theorem fourierSide_nonneg_of_lin_threshold {t : ℝ} (ht : (%s:ℝ) ≤ |t|) :\n'
        '    0 ≤ fourierSide t := by\n'
        '  rcases le_or_gt 5.5 |t| with hb | hb\n'
        '  · exact fourierSide_nonneg_of_five_and_half_le_abs hb\n'
        '  rw [← fourierSide_abs t]\n' % (dec(tstart), dec(tstart)))
    rev = list(reversed(bandlist))
    prevname = 'hb'
    for n, (b, t0, t1, _) in enumerate(rev):
        last = (n == len(rev) - 1)
        if last:
            body.append(
                '  · refine fourierSide_nonneg_band_osc (a := %s) (b := %s) (by norm_num) ht %s.le\n'
                '      (oscLinBand%d ht %s.le) ?_\n'
                '    rw [Finset.range_eq_Ico]\n'
                '    simp only [thetaSeriesTerm, poleAbscissa]\n'
                '    norm_num [Finset.sum_Ico_succ_top]\n' % (dec(t0), dec(t1), prevname, b,
                                                              prevname))
        else:
            nm = 'g%d' % n
            body.append(
                '  rcases le_or_gt %s |t| with %s | %s\n'
                '  · refine fourierSide_nonneg_band_osc (a := %s) (b := %s) (by norm_num) %s %s.le\n'
                '      (oscLinBand%d %s %s.le) ?_\n'
                '    rw [Finset.range_eq_Ico]\n'
                '    simp only [thetaSeriesTerm, poleAbscissa]\n'
                '    norm_num [Finset.sum_Ico_succ_top]\n'
                % (dec(t0), nm, nm, dec(t0), dec(t1), nm, prevname, b, nm, prevname))
            prevname = nm
    write('PolyaLinThreshold', ['RequestProject.PolyaOscThreshold'] + deps,
          '# The linear-phase oscillatory threshold\n\n'
          'The bands of `RequestProject/PolyaLinBand*.lean` push the large-frequency threshold\n'
          'for `f(t) = 2θ\'(t) + δ̂(t) ≥ 0` from `5.5` down to `%s`.' % dec(tstart),
          ''.join(body))
    return 'PolyaLinThreshold'


if __name__ == '__main__':
    tstart = F(sys.argv[1]) if len(sys.argv) > 1 else F('3.0')
    phimax = F(sys.argv[2]) if len(sys.argv) > 2 else F('0.25')
    blocks = make_blocks(phimax)
    ok, lst, stuck = bands(blocks, tstart)
    assert ok, 'greedy fails at %s' % stuck
    print('%d blocks, %d bands from %s' % (len(blocks), len(lst), tstart))
    vbpnames, idx = emit_vbp()
    piecenames = emit_pieces()
    blknames = emit_blocks(vbpnames + piecenames, blocks, idx)
    bandlist = []
    deps = []
    for b, (t0, t1, m) in enumerate(lst):
        nm, ev = emit_band(b, blknames, blocks, t0, t1, idx)
        deps.append('RequestProject.' + nm)
        bandlist.append((b, t0, t1, ev))
    emit_threshold(bandlist, deps, tstart)
    print('emitted', len(vbpnames) + len(piecenames) + len(blknames)
          + len(bandlist) + 1, 'files')
