import math, sys
sys.path.insert(0,'/workspace/request-project/scripts')
from sharp import piece_bracket_sharp, PILO, PIHI
from analyze2 import req, cosbracket
def vBP(q): return 2*math.log(q)

def make_partition(q_end=4.0, phase_max=0.06):
    """adaptive partition of [1,q_end]; step limited by phase 2*pi*dr and by relative size"""
    pts=[1.0]; q=1.0
    while q<q_end:
        r=q*q
        # dr <= phase_max/(2pi)
        dr = phase_max/(2*math.pi)
        dq = dr/(2*q)
        dq = min(dq, 0.02*q)
        q2=min(q+dq,q_end)
        pts.append(q2); q=q2
    return list(zip(pts[:-1],pts[1:]))

def build(partition):
    ps=[]
    for q0,q1 in partition:
        Lo,Hi,bm=piece_bracket_sharp(q0,q1)
        w=1/q0-1/q1; M=max(abs(Lo),abs(Hi))
        ps.append(dict(q0=q0,q1=q1,Lo=Lo,Hi=Hi,P0=2*Lo*w,P1=2*Hi*w,S=2*M*w,bmode=bm))
    return ps

def tail_bound(qc, qmax=30.0):
    """bound for int_{q>qc} |err| : use sharp pieces up to qmax then analytic"""
    part=make_partition(qmax,0.06)
    part=[(a,b) for a,b in part if a>=qc-1e-12]
    ps=build(part)
    s=sum(p['S'] for p in ps)
    # beyond qmax: |Phi| <= M
    Lo,Hi,_=piece_bracket_sharp(qmax,qmax*1.0000001)
    M=max(abs(Lo),abs(Hi))+0.02
    return s+2*M/qmax

def group(pieces,t0,t1,phimax):
    groups=[];cur=[]
    for p in pieces:
        trial=cur+[p]
        a=vBP(trial[0]['q0']); b=vBP(trial[-1]['q1'])
        if t1*b-t0*a>phimax and cur: groups.append(cur); cur=[p]
        else: cur=trial
    if cur: groups.append(cur)
    return groups

def eta(pieces,t0,t1,phimax,tail):
    gs=group(pieces,t0,t1,phimax); tot=0; main=spread=cosl=0
    for g in gs:
        a=vBP(g[0]['q0']); b=vBP(g[-1]['q1'])
        P0=sum(x['P0'] for x in g); P1=sum(x['P1'] for x in g); S=sum(x['S'] for x in g)
        C,h=cosbracket(t0*a,t1*b)
        tot+=min(C*P0,C*P1)-h*S
        main+=C*(P0+P1)/2; spread+=abs(C)*(P1-P0)/2; cosl+=h*S
    return tot-tail,len(gs),main,spread,cosl

if __name__=='__main__':
    for qc in [2.094,3.0,4.0,5.0]:
        print('cut q=%.3f  tail bound %.5f'%(qc,tail_bound(qc)))
    print()
    for qc,phase in [(3.0,0.06),(4.0,0.06)]:
        part=make_partition(qc,phase); ps=build(part); tl=tail_bound(qc)
        print('=== cut %.2f npieces %d  tail %.5f'%(qc,len(ps),tl))
        for t0 in [1.0,1.5,2.0,2.5,3.0,3.5,4.0,4.5,5.0,5.5]:
            t1=t0+0.03125
            for phimax in [0.06,0.12]:
                e,n,main,sp,cl=eta(ps,t0,t1,phimax,tl)
                print('  t0=%.3f phimax=%.2f nblk=%3d eta=%+.5f req=%+.5f margin=%+.5f (main %+.5f spread %.5f cos %.5f)'%(t0,phimax,n,e,req(t0,t1),e-req(t0,t1),main,sp,cl))
