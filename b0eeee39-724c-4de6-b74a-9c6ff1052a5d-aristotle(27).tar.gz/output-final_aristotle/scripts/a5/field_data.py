"""Assemble all arithmetic data of an A5-quintic: conductors, Euler factors,
Dirichlet coefficients of the Artin L-functions of dimensions 1,3,3',4,5."""

import json
import math
import os
from math import isqrt

from ntlib import ramified_pattern, dedekind_maximal, factor_pattern, disc, real_roots
from artin import (A5Field, euler_poly_unramified, DIM, sign,
                   conductor_exponents)
from search import sieve, galois_a5
from round2 import p_maximal
from pgen import find_pmaximal_poly
from order_ef import residue_degrees

REPS = ("1", "3", "3b", "4", "5")


def _n_monic_irreducibles(d, p):
    """number of monic irreducible polynomials of degree d over F_p"""
    tot = 0
    for e in range(1, d + 1):
        if d % e == 0:
            mu = 1
            m = d // e
            q = m
            i = 2
            while i * i <= q:
                if q % i == 0:
                    q //= i
                    if q % i == 0:
                        mu = 0
                        break
                    mu = -mu
                i += 1
            if mu and q > 1:
                mu = -mu
            tot += mu * p ** e
    return tot // d


def _monogenic_possible(fdegs, p):
    """Necessary condition for K to be monogenic at p: distinct primes with the
    same residue degree d need distinct monic irreducibles of degree d."""
    from collections import Counter
    for d, c in Counter(fdegs).items():
        if c > _n_monic_irreducibles(d, p):
            return False
    return True


def _sort_permutation_sign(vals):
    """sign of the permutation that sorts `vals` increasingly."""
    n = len(vals)
    s = 1
    for i in range(n):
        for j in range(i + 1, n):
            if vals[i] > vals[j]:
                s = -s
    return s


def build_aux(f, verbose=False):
    """For every prime p with p^2 | disc(f), make sure we have a defining
    polynomial of the field whose order is p-maximal.  Returns a pair
    (aux, nonmono) where aux = {p: {'poly': h, 'swap': bool, 'vp_dK': e}} for
    the primes where a p-maximal generator was found, and
    nonmono = {p: {'vp_dK': e, 'fdegs': [...]}} for the primes where none
    exists (K not monogenic at p); there the residue degrees are computed
    inside the p-maximal order instead."""
    D = disc(f)
    aux = {}
    nonmono = {}
    tmp = abs(D)
    p = 2
    sqprimes = []
    while p * p <= tmp:
        if tmp % p == 0:
            e = 0
            while tmp % p == 0:
                tmp //= p
                e += 1
            if e >= 2:
                sqprimes.append((p, e))
        p += 1 if p == 2 else 2
    for p, e in sqprimes:
        _, idx = p_maximal(f, p)
        if idx == 1:
            continue
        k = 0
        m = idx
        while m % p == 0:
            m //= p
            k += 1
        assert m == 1
        vp = e - 2 * k
        fdegs = residue_degrees(f, p)
        if _monogenic_possible(fdegs, p):
            h, Dh, x = find_pmaximal_poly(f, p, tries=3000)
        else:
            h = None
        if h is None:
            nonmono[p] = {"vp_dK": vp, "fdegs": fdegs}
            if verbose:
                print(f"  p={p}: not monogenic, v_p(d_K)={vp}, "
                      f"residue degrees {nonmono[p]['fdegs']}")
            continue
        rts = real_roots(f)
        assert len(rts) == 5
        vals = [sum(float(c) * r ** j for j, c in enumerate(x)) for r in rts]
        swap = _sort_permutation_sign(vals) == -1
        aux[p] = {"poly": h, "swap": swap, "vp_dK": vp}
        if verbose:
            print(f"  aux at p={p}: index p^{k}, v_p(d_K)={vp}, swap={swap}")
    return aux, nonmono


class FieldAnalysis:
    def __init__(self, f, X=60000, verbose=False, aux=None):
        self.f = f
        if aux is None:
            self.aux, self.nonmono = build_aux(f, verbose)
        else:
            self.aux, self.nonmono = aux
        self.K = A5Field(f, self.aux)
        self.K.nonmono = self.nonmono
        self.X = X
        self.verbose = verbose
        self.primes = sieve(X)
        self.ram = {}
        self.dK = None
        self._analyse_ramification()
        self._frob = {}

    # ------------------------------------------------------------ local data
    def _analyse_ramification(self):
        rp = self.K.ramified_primes()
        dK = 1
        self.cond_exp = {r: {} for r in REPS}
        for p, v in rp.items():
            la = self.K.local_analysis(
                p, vp=v, fdegs=self.nonmono.get(p, {}).get("fdegs"))
            if "euler" not in la:
                la["error"] = "ambiguous local data"
                self.ram[p] = la
                raise ValueError(
                    f"local data at p={p} is not determined by the quintic "
                    f"and its degree-10 resolvent "
                    f"({la.get('n_candidates')} possibilities)")
            la["v_p_disc_poly"] = v
            exps = None
            for I in la.pop("_inertia"):
                e, nsol = conductor_exponents(I, p, v)
                la["filtration_solutions"] = nsol
                if exps is None:
                    exps = e
                else:
                    assert exps == e, (p, exps, e)
            for r in REPS:
                self.cond_exp[r][p] = exps[r]
            dK *= p ** v
            self.ram[p] = la
        self.dK = dK
        self.conductor = {r: 1 for r in REPS}
        for r in REPS:
            for p, e in self.cond_exp[r].items():
                self.conductor[r] *= p ** e
        assert self.conductor["4"] == self.dK
        assert self.conductor["1"] == 1

    # ------------------------------------------------------------- Frobenius
    def frobenius_classes(self):
        if self._frob:
            return self._frob
        for p in self.primes:
            if p in self.ram:
                continue
            self._frob[p] = self.K.frobenius_class(p)
        return self._frob

    def euler_factor(self, rep, p):
        """List of float coefficients of det(1 - rho(Frob_p) T | V^{I_p})."""
        if p in self.ram:
            return self.ram[p]["euler"][rep]
        cl = self._frob.get(p) or self.K.frobenius_class(p)
        self._frob[p] = cl
        return [c.float() for c in euler_poly_unramified(rep, cl)]

    def zeta_K_local(self, p):
        """prod_{P|p} (1 - T^{f_P}) as a coefficient list."""
        g, _ = self.K.poly_at(p)
        if p in self.nonmono:
            fs = self.nonmono[p]["fdegs"]
        elif p in self.ram:
            ef = ramified_pattern(g, p)
            fs = [fp for (e, fp) in ef]
        else:
            fs = factor_pattern(g, p)
        poly = [1.0]
        for fp in fs:
            q = [0.0] * (len(poly) + fp)
            for i, c in enumerate(poly):
                q[i] += c
                q[i + fp] -= c
            poly = q
        return poly

    def check_dedekind_factorisation(self, nprimes=400):
        """(1 - T) * E_4(T) == prod_{P|p}(1 - T^{f_P}) for all p: the identity
        zeta_K(s) = zeta(s) L(rho_4, s) at the level of Euler factors."""
        bad = []
        for p in self.primes[:nprimes]:
            e4 = self.euler_factor("4", p)
            lhs = [0.0] * (len(e4) + 1)
            for i, c in enumerate(e4):
                lhs[i] += c
                lhs[i + 1] -= c
            rhs = self.zeta_K_local(p)
            n = max(len(lhs), len(rhs))
            lhs += [0.0] * (n - len(lhs))
            rhs += [0.0] * (n - len(rhs))
            err = max(abs(a - b) for a, b in zip(lhs, rhs))
            if err > 1e-9:
                bad.append((p, lhs, rhs))
        return bad

    # ---------------------------------------------------------- coefficients
    def coefficients(self, rep, X=None):
        X = X or self.X
        spf = list(range(X + 1))
        for i in range(2, isqrt(X) + 1):
            if spf[i] == i:
                for j in range(i * i, X + 1, i):
                    if spf[j] == j:
                        spf[j] = i
        a = [0.0] * (X + 1)
        a[1] = 1.0
        local = {}
        for n in range(2, X + 1):
            p = spf[n]
            m = n
            k = 0
            while m % p == 0:
                m //= p
                k += 1
            if p not in local:
                E = self.euler_factor(rep, p)
                jmax = 1
                while p ** (jmax + 1) <= X:
                    jmax += 1
                c = [0.0] * (jmax + 1)
                c[0] = 1.0
                for j in range(1, jmax + 1):
                    s = 0.0
                    for i in range(1, min(j, len(E) - 1) + 1):
                        s -= E[i] * c[j - i]
                    c[j] = s
                local[p] = c
            a[n] = local[p][k] * a[m]
        return a

    def summary(self):
        return {
            "poly": self.f,
            "disc_poly": self.K.discf,
            "aux_polys": {str(p): a["poly"] for p, a in self.aux.items()},
            "non_monogenic_primes": {str(p): a for p, a in self.nonmono.items()},
            "dK": self.dK,
            "sqrt_dK": isqrt(self.dK),
            "ramification": {str(p): {"ef": la.get("ef"), "tame": la.get("tame"),
                                      "inertia_order": la.get("inertia_order"),
                                      "filtration_solutions":
                                          la.get("filtration_solutions"),
                                      "v_p": la.get("v_p_disc_poly"),
                                      "cond_exp": {r: self.cond_exp[r].get(p)
                                                   for r in REPS}}
                             for p, la in self.ram.items()},
            "conductors": {r: self.conductor[r] for r in REPS},
        }
