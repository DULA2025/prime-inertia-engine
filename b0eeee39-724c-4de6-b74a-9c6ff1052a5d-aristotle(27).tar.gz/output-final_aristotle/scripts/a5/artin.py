"""Artin representations attached to an A5-quintic field.

Everything is keyed on the quintic polynomial f (monic, integral, totally real,
Galois group A5 acting on the 5 roots).  The Galois group of the Galois closure
N/Q is *canonically* the group of even permutations of the five real roots of f,
labelled in increasing order; this labelling is what makes the two classes of
5-cycles ("5A" and "5B") well defined, and hence makes the two 3-dimensional
representations well defined individually.

Frobenius classes
-----------------
For p unramified the factorisation type of f mod p gives the cycle type of
Frob_p.  For cycle type (5) there are two A5-classes.  They are separated as
follows.  Let D = prod_{i<j} (r_i - r_j) with r_1 < ... < r_5 the real roots;
D = +sqrt(disc f) is a positive integer.  If f is irreducible mod p, put
s_1 = x, s_{i+1} = s_i^p in F_p[x]/(f); then Frobenius is the 5-cycle
i -> i+1 in this labelling, and the labelling is compatible with the real one
(up to an even permutation) iff  prod_{i<j}(s_i - s_j) = D  in F_p.
So Frob_p is in the class of (1 2 3 4 5) iff that product equals D mod p.
"""

from fractions import Fraction
from itertools import permutations
from math import isqrt

from ntlib import (pdeg, ptrim, pmod_p, polymod, mulmod, ppow, powmod_x,
                   factor_mod_p, disc, factor_pattern)

# --------------------------------------------------------------- Q(sqrt 5)

SQRT5 = 5 ** 0.5


class QF:
    """a + b*sqrt(5) with rational a,b."""
    __slots__ = ("a", "b")

    def __init__(self, a=0, b=0):
        self.a = Fraction(a)
        self.b = Fraction(b)

    def __add__(self, o):
        o = qf(o)
        return QF(self.a + o.a, self.b + o.b)

    __radd__ = __add__

    def __neg__(self):
        return QF(-self.a, -self.b)

    def __sub__(self, o):
        return self + (-qf(o))

    def __rsub__(self, o):
        return qf(o) + (-self)

    def __mul__(self, o):
        o = qf(o)
        return QF(self.a * o.a + 5 * self.b * o.b, self.a * o.b + self.b * o.a)

    __rmul__ = __mul__

    def __truediv__(self, o):
        if isinstance(o, QF):
            d = o.a * o.a - 5 * o.b * o.b
            return self * QF(o.a / d, -o.b / d)
        return QF(self.a / Fraction(o), self.b / Fraction(o))

    def __eq__(self, o):
        o = qf(o)
        return self.a == o.a and self.b == o.b

    def __repr__(self):
        if self.b == 0:
            return str(self.a)
        return f"({self.a}+{self.b}*sqrt5)"

    def float(self):
        return float(self.a) + float(self.b) * SQRT5

    def conj(self):
        return QF(self.a, -self.b)


def qf(x):
    return x if isinstance(x, QF) else QF(x)


# ------------------------------------------------------------------- A5

def compose(a, b):
    return tuple(a[b[i]] for i in range(5))


def inverse(a):
    r = [0] * 5
    for i, x in enumerate(a):
        r[x] = i
    return tuple(r)


def sign(p):
    s = 1
    for i in range(5):
        for j in range(i + 1, 5):
            if p[i] > p[j]:
                s = -s
    return s


A5 = [p for p in permutations(range(5)) if sign(p) == 1]
IDP = tuple(range(5))
C5A_REP = (1, 2, 3, 4, 0)          # the 5-cycle 1->2->3->4->5->1


def cycle_type(p):
    seen = [False] * 5
    ct = []
    for i in range(5):
        if not seen[i]:
            l = 0
            j = i
            while not seen[j]:
                seen[j] = True
                j = p[j]
                l += 1
            ct.append(l)
    return tuple(sorted(ct, reverse=True))


CLASS_5A = set()
for q in A5:
    CLASS_5A.add(compose(compose(q, C5A_REP), inverse(q)))


def class_of(p):
    ct = cycle_type(p)
    if ct == (1, 1, 1, 1, 1):
        return "1A"
    if ct == (2, 2, 1):
        return "2A"
    if ct == (3, 1, 1):
        return "3A"
    if ct == (5,):
        return "5A" if p in CLASS_5A else "5B"
    raise ValueError("odd permutation")


CLASSES = ["1A", "2A", "3A", "5A", "5B"]

PHI = QF(Fraction(1, 2), Fraction(1, 2))         # (1+sqrt5)/2
PHIC = QF(Fraction(1, 2), Fraction(-1, 2))       # (1-sqrt5)/2

CHAR = {
    "1": {"1A": qf(1), "2A": qf(1), "3A": qf(1), "5A": qf(1), "5B": qf(1)},
    "3": {"1A": qf(3), "2A": qf(-1), "3A": qf(0), "5A": PHI, "5B": PHIC},
    "3b": {"1A": qf(3), "2A": qf(-1), "3A": qf(0), "5A": PHIC, "5B": PHI},
    "4": {"1A": qf(4), "2A": qf(0), "3A": qf(1), "5A": qf(-1), "5B": qf(-1)},
    "5": {"1A": qf(5), "2A": qf(1), "3A": qf(-1), "5A": qf(0), "5B": qf(0)},
}
DIM = {"1": 1, "3": 3, "3b": 3, "4": 4, "5": 5}

# representative permutations of each class
REPS = {}
for p in A5:
    REPS.setdefault(class_of(p), p)


def power_class(cl, k):
    p = REPS[cl]
    q = IDP
    for _ in range(k % 60):
        q = compose(q, p)
    return class_of(q)


def newton_charpoly(powersums, dim):
    """det(1 - g T) from p_k = trace(g^k), k=1..dim.  Returns list of QF,
    coefficient of T^m at index m."""
    e = [qf(1)]
    for m in range(1, dim + 1):
        acc = qf(0)
        for i in range(1, m + 1):
            term = e[m - i] * powersums[i - 1]
            acc = acc + (term if i % 2 == 1 else -term)
        e.append(acc / m)
    return [e[m] * ((-1) ** m) for m in range(dim + 1)]


def euler_poly_unramified(rep, cl):
    """The polynomial det(1 - rho(Frob) T) for an unramified Frobenius class."""
    d = DIM[rep]
    ps = [CHAR[rep][power_class(cl, k)] for k in range(1, d + 1)]
    return newton_charpoly(ps, d)


# --------------------------------------------------- ramified local factors

def subgroup_generated(gens):
    S = {IDP}
    frontier = [IDP]
    while frontier:
        x = frontier.pop()
        for g in gens:
            y = compose(x, g)
            if y not in S:
                S.add(y)
                frontier.append(y)
    return frozenset(S)


ALL_SUBGROUPS = set()
for g in A5:
    for h in A5:
        ALL_SUBGROUPS.add(subgroup_generated([g, h]))
ALL_SUBGROUPS = sorted(ALL_SUBGROUPS, key=lambda S: (len(S), sorted(S)))


def orbits(S, pts=range(5)):
    seen = set()
    out = []
    for i in pts:
        if i in seen:
            continue
        orb = {i}
        frontier = [i]
        while frontier:
            x = frontier.pop()
            for g in S:
                y = g[x]
                if y not in orb:
                    orb.add(y)
                    frontier.append(y)
        seen |= orb
        out.append(sorted(orb))
    return out


PAIRS = [(i, j) for i in range(5) for j in range(i + 1, 5)]


def _act_pair(g, pr):
    return tuple(sorted((g[pr[0]], g[pr[1]])))


def _orbits_gen(gens, points, act):
    pts = list(points)
    seen = set()
    out = []
    for x in pts:
        if x in seen:
            continue
        orb = {x}
        front = [x]
        while front:
            y = front.pop()
            for g in gens:
                z = act(g, y)
                if z not in orb:
                    orb.add(z)
                    front.append(z)
        seen |= orb
        out.append(orb)
    return out


def ef_data_pairs(I, F):
    """(e,f) data of the degree-10 resolvent algebra (unordered pairs of the
    five points) for inertia I and Frobenius F."""
    Il = list(I)
    out = []
    for orb in _orbits_gen(Il + [F], PAIRS, _act_pair):
        Iorb = _orbits_gen(Il, sorted(orb), _act_pair)
        e = len(Iorb[0])
        assert all(len(o) == e for o in Iorb)
        out.append((e, len(orb) // e))
    return sorted(out)


def _evalmod(poly, val, modulus, m):
    """Evaluate `poly` at the ring element `val` inside (Z/m)[x]/(modulus)."""
    res = []
    for c in reversed(poly):
        res = mulmod(res, val, modulus, m) if res else []
        c = c % m
        if c:
            if not res:
                res = [c]
            else:
                res = list(res)
                res[0] = (res[0] + c) % m
                res = ptrim(res)
    return res


def ef_data(I, F):
    """(e,f) data of the primes of the quintic field for inertia I and
    Frobenius F: orbits of D = <I,F> on the 5 points, each split into I-orbits."""
    D = subgroup_generated(list(I) + [F])
    out = []
    for orb in orbits(D):
        Iorb = orbits(I, orb)
        e = len(Iorb[0])
        assert all(len(o) == e for o in Iorb)
        out.append((e, len(orb) // e))
    return sorted(out)


def local_charpoly(rep, I, F):
    """det(1 - Frob T | V^I) via the averaged character."""
    d = DIM[rep]
    n = len(I)
    dimfix = qf(0)
    for h in I:
        dimfix = dimfix + CHAR[rep][class_of(h)]
    dimfix = dimfix / n
    assert dimfix.b == 0 and dimfix.a.denominator == 1, dimfix
    dimfix = int(dimfix.a)
    if dimfix == 0:
        return [qf(1)]
    ps = []
    Fk = IDP
    for k in range(1, dimfix + 1):
        Fk = compose(Fk, F)
        acc = qf(0)
        for h in I:
            acc = acc + CHAR[rep][class_of(compose(Fk, h))]
        ps.append(acc / n)
    return newton_charpoly(ps, dimfix)


def tame_conductor_exponent(rep, I):
    n = len(I)
    dimfix = qf(0)
    for h in I:
        dimfix = dimfix + CHAR[rep][class_of(h)]
    dimfix = dimfix / n
    return DIM[rep] - int(dimfix.a)


def codim_fixed(rep, H):
    n = len(H)
    dimfix = qf(0)
    for h in H:
        dimfix = dimfix + CHAR[rep][class_of(h)]
    dimfix = dimfix / n
    return DIM[rep] - int(dimfix.a)


def _normal_subgroups_of(G):
    """All subgroups of G that are normal in G (G a frozenset of permutations)."""
    out = set()
    Gl = list(G)
    for g in Gl:
        for h in Gl:
            S = subgroup_generated([g, h])
            if not S <= set(G):
                continue
            if all(frozenset(compose(compose(x, s), inverse(x)) for s in S) == S
                   for x in Gl):
                out.add(S)
    out.add(frozenset([IDP]))
    return sorted(out, key=len)


def conductor_exponents(I, p, vp):
    """Artin conductor exponents of all five representations at a prime whose
    inertia group is I, given v_p(d_K) = a(rho_4).

    Uses the higher ramification filtration G_0 = I ⊇ G_1 ⊇ ... in lower
    numbering: a(rho) = sum_{i>=0} |G_i|/|G_0| * codim V^{G_i}.  G_1 is the
    (normal, unique) p-Sylow subgroup of I.  The lengths of the jumps are
    determined -- or at least constrained -- by the known value a(rho_4)=v_p(d_K).

    Returns (exponents, n_solutions).  n_solutions > 1 means the filtration is
    not pinned down by v_p(d_K) alone but all solutions gave the same answer
    only if n_solutions == 1.
    """
    G0 = frozenset(I)
    wild = frozenset(g for g in G0 if _order(g) % p == 0 or g == IDP)
    # wild inertia = p-Sylow of G_0 (elements of p-power order)
    wild = frozenset(g for g in G0 if _is_ppower_order(g, p))
    e0 = len(G0)
    if len(wild) == 1:
        # tame: single step
        exps = {r: codim_fixed(r, G0) for r in DIM}
        assert exps["4"] == vp, (exps, vp)
        return exps, 1
    # enumerate chains G_1 = H_1 ⊋ H_2 ⊋ ... ⊋ 1 of subgroups normal in G_0,
    # with multiplicities t_j >= 1 (t_1 >= 1), matching a(rho_4) = vp.
    normals = [H for H in _normal_subgroups_of(G0) if H <= wild]
    sols = []

    def rec(chain, cur):
        # chain: list of (H, t)
        if chain:
            a4 = codim_fixed("4", G0) + sum(
                t * len(H) * codim_fixed("4", H) for H, t in chain) / e0
            if abs(a4 - vp) < 1e-9:
                sols.append(list(chain))
            if a4 > vp:
                return
        for H in normals:
            if len(H) == 1:
                continue
            if chain and len(H) >= len(chain[-1][0]):
                continue
            if not chain and H != wild:
                continue      # G_1 is the whole wild inertia
            for t in range(1, 40):
                rec(chain + [(H, t)], None)

    rec([], None)
    if not sols:
        raise ValueError(f"no ramification filtration matches v_p(d_K)={vp}")
    answers = set()
    for ch in sols:
        exps = {}
        for r in DIM:
            a = codim_fixed(r, G0) + sum(
                t * len(H) * codim_fixed(r, H) for H, t in ch) / e0
            assert abs(a - round(a)) < 1e-9, (r, a)
            exps[r] = int(round(a))
        answers.add(tuple(sorted(exps.items())))
    return dict(sorted(answers)[0]), len(answers)


def _order(g):
    k = 1
    x = g
    while x != IDP:
        x = compose(x, g)
        k += 1
    return k


def _is_ppower_order(g, p):
    o = _order(g)
    while o % p == 0:
        o //= p
    return o == 1


# ------------------------------------------------------- field level data

class A5Field:
    def __init__(self, f, aux=None):
        self.f = f
        self.discf = disc(f)
        self.D = isqrt(self.discf)
        assert self.D * self.D == self.discf, "discriminant is not a square"
        self.ram = {}         # p -> dict of local data
        self.frob_cache = {}
        # aux: p -> {"poly": h, "swap": bool, "vp_dK": e}
        # h defines the same field, Z[theta_h] is p-maximal, and "swap" says
        # whether the increasing-real-root labelling of h differs from that of
        # f by an odd permutation (in which case 5A and 5B are interchanged).
        self.aux = aux or {}
        # primes where K is not monogenic: p -> {'vp_dK': e, 'fdegs': [...]}
        self.nonmono = {}

    def poly_at(self, p):
        a = self.aux.get(p)
        return (a["poly"], a["swap"]) if a else (self.f, False)

    def frobenius_class(self, p):
        """Class label of Frob_p, or None if p is ramified."""
        if p in self.frob_cache:
            return self.frob_cache[p]
        if p in self.nonmono:
            pat = self.nonmono[p]["fdegs"]
            if pat == [5]:
                raise NotImplementedError(
                    f"cannot separate 5A/5B at the non-monogenic prime {p}")
            cl = {(1, 1, 1, 1, 1): "1A", (1, 2, 2): "2A",
                  (1, 1, 3): "3A"}[tuple(sorted(pat))]
            self.frob_cache[p] = cl
            return cl
        g, swap = self.poly_at(p)
        if disc(g) % p == 0:
            self.frob_cache[p] = None
            return None
        pat = factor_pattern(g, p)
        if pat is None:
            self.frob_cache[p] = None
            return None
        if pat == [1, 1, 1, 1, 1]:
            cl = "1A"
        elif pat == [1, 2, 2]:
            cl = "2A"
        elif pat == [1, 1, 3]:
            cl = "3A"
        elif pat == [5]:
            is5A = self.five_cycle_is_5A(p, g)
            cl = ("5B" if is5A else "5A") if swap else ("5A" if is5A else "5B")
        else:
            raise ValueError(f"pattern {pat} at p={p} is not an even cycle type")
        self.frob_cache[p] = cl
        return cl

    def five_cycle_is_5A(self, p, g=None):
        """Decide whether `Frob_p` lies in the class of `(1 2 3 4 5)`.

        The computation is carried out modulo `p^2` in the unramified ring
        `R = (Z/p^2)[x]/(g)`.  Working modulo `p` alone would be wrong for
        `p = 2`, where `+D` and `-D` are congruent, and the test would then
        return an arbitrary answer.
        """
        g = self.f if g is None else g
        D = isqrt(disc(g))
        q = p * p
        gq = [c % q for c in g]
        gp = pmod_p(g, p)
        n = pdeg(g)

        def mulq(a, b):
            return mulmod(a, b, gq, q)

        # Frobenius lift: the unique root y of g in R with y = x^p mod p
        y0 = powmod_x(p, gq, q)
        dg = [(i * c) % q for i, c in enumerate(g)][1:]
        # inverse of g'(y0) modulo p
        dgy = _evalmod(dg, pmod_p(y0, p), gp, p)
        u = ppow(dgy, p ** n - 2, gp, p)
        gy = _evalmod(gq, y0, gq, q)
        corr = mulq(gy, [c % q for c in u])
        y = [(a - b) % q for a, b in zip(y0 + [0] * (n - len(y0)),
                                        corr + [0] * (n - len(corr)))]
        s = [[0, 1]]
        for _ in range(4):
            s.append(_evalmod(s[-1], y, gq, q))
        prod = [1]
        for i in range(5):
            for j in range(i + 1, 5):
                a = s[i] + [0] * (n - len(s[i]))
                b = s[j] + [0] * (n - len(s[j]))
                prod = mulq(prod, [(x - z) % q for x, z in zip(a, b)])
        assert pdeg(prod) <= 0, "Delta is not in Z/p^2"
        val = (prod[0] if prod else 0) % q
        assert (val - D) % q == 0 or (val + D) % q == 0, \
            f"Delta = {val} is not +-D = {D % q} mod {q}"
        return (val - D) % q == 0

    # ------------------------------------------------------- ramification

    def ramified_primes(self):
        """p -> v_p(d_K).  Uses the auxiliary p-maximal data when present."""
        m = self.discf
        out = {}
        p = 2
        while p * p <= m:
            if m % p == 0:
                e = 0
                while m % p == 0:
                    m //= p
                    e += 1
                out[p] = e
            p += 1
        if m > 1:
            out[m] = out.get(m, 0) + 1
        for p, a in self.aux.items():
            out[p] = a["vp_dK"]
        for p, a in self.nonmono.items():
            out[p] = a["vp_dK"]
        return {p: e for p, e in out.items() if e > 0}

    def local_analysis(self, p, vp=None, fdegs=None):
        """Determine the pair (inertia I, Frobenius F) at a ramified prime p
        from the splitting type of p in the quintic field.

        If a p-maximal defining polynomial is available the full (e,f) data is
        used.  Otherwise (field not monogenic at p) only the residue degrees
        `fdegs`, computed inside the p-maximal order, together with
        v_p(d_K) = vp, are used to cut down the candidates.

        Returns a dict with the candidates (up to conjugacy) and, when they all
        agree, the local Euler factors and tame conductor exponents."""
        from ntlib import dedekind_maximal, ramified_pattern
        g, swap = self.poly_at(p)
        have_poly = (p in self.aux) or dedekind_maximal(g, p)
        if have_poly:
            ef = ramified_pattern(g, p)
            fdegs = sorted(fp for (_, fp) in ef)
        else:
            if fdegs is None:
                from order_ef import residue_degrees
                fdegs = residue_degrees(self.f, p)
            ef = None
        tame = None if ef is None else all(e % p != 0 for (e, _) in ef)
        cands = []
        for I in ALL_SUBGROUPS:
            if len(I) == 1:
                continue
            if tame is True:
                # tame inertia is cyclic
                gens = [g for g in I if subgroup_generated([g]) == I]
                if not gens:
                    continue
            for F in A5:
                Finv = inverse(F)
                if frozenset(compose(compose(F, h), Finv) for h in I) != I:
                    continue
                if tame is True:
                    ok = False
                    for g in gens:
                        gp = IDP
                        for _ in range(p % len(I)):
                            gp = compose(gp, g)
                        if compose(compose(F, g), Finv) == gp:
                            ok = True
                            break
                    if not ok:
                        continue
                efIF = ef_data(I, F)
                if ef is not None:
                    if efIF != ef:
                        continue
                else:
                    if sorted(fp for (_, fp) in efIF) != sorted(fdegs):
                        continue
                    try:
                        conductor_exponents(I, p, vp)
                    except (ValueError, AssertionError):
                        continue
                data = {}
                for rep in ("1", "3", "3b", "4", "5"):
                    data[rep] = ([c.float() for c in local_charpoly(rep, I, F)],
                                 tame_conductor_exponent(rep, I))
                key = repr(sorted((k, [round(x, 12) for x in v[0]], v[1])
                                  for k, v in data.items()))
                cands.append((key, I, F, data))
        keys = sorted(set(c[0] for c in cands))
        used10 = False
        if len(keys) > 1:
            # the quintic alone does not determine the local data: use the
            # residue degrees of the degree-10 resolvent algebra
            from resolvent import resolvent10
            from order_ef import residue_degrees
            fd10 = sorted(residue_degrees(resolvent10(self.f), p))
            cands = [c for c in cands
                     if sorted(fp for (_, fp) in ef_data_pairs(c[1], c[2]))
                     == fd10]
            keys = sorted(set(c[0] for c in cands))
            used10 = True
        out = {"p": p, "ef": ef, "tame": tame, "n_candidates": len(keys),
               "used_degree10_resolvent": used10,
               "inertia_order": len(cands[0][1]) if cands else None}
        out["_inertia"] = sorted(set(c[1] for c in cands), key=len)
        if len(keys) == 1 and cands:
            d = cands[0][3]
            eul = {k: v[0] for k, v in d.items()}
            cex = {k: v[1] for k, v in d.items()}
            if swap:
                eul["3"], eul["3b"] = eul["3b"], eul["3"]
                cex["3"], cex["3b"] = cex["3b"], cex["3"]
            out["euler"] = eul
            out["cond_exp_tame"] = cex
        elif cands:
            out["candidates"] = [{"inertia_order": len(c[1]),
                                  "euler": {k: v[0] for k, v in c[3].items()},
                                  "cond_exp_tame": {k: v[1] for k, v in c[3].items()}}
                                 for c in cands if c[0] in keys[:1] or True][:6]
        return out

    def analyse(self):
        """Full local data: ramified primes, Euler factors, conductors."""
        info = {"poly": self.f, "disc_poly": self.discf, "ram": {}}
        dK_exp = {}
        for p, e in self.ramified_primes().items():
            la = self.local_analysis(p)
            info["ram"][p] = la
            dK_exp[p] = e
        return info
