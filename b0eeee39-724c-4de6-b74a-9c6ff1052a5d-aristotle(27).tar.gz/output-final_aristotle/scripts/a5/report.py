"""Collect the per-field JSON results into a compact status table."""
import glob
import json
import os
import sys

DATA = os.path.join(os.path.dirname(__file__), "..", "..", "data", "a5")


def rows():
    out = []
    for fn in sorted(glob.glob(os.path.join(DATA, "field_*.json"))):
        d = json.load(open(fn))
        for r in d["reps"]:
            fe = r.get("functional_equation", {})
            out.append({
                "dK": d["dK"],
                "poly": d["poly"],
                "rep": r["rep"],
                "dim": r["dim"],
                "N": r["conductor"],
                "terms": r.get("terms"),
                "skipped": r.get("skipped"),
                "fe": fe.get("worst_spread_over_Lambda_half"),
                "sens_eps": min([s["worst_spread_over_Lambda_half"]
                                 for s in r.get("sensitivity", [])
                                 if s["variant"] == "eps=-1"] or [None],
                                key=lambda x: 1),
                "sens_N": min([s["worst_spread_over_Lambda_half"]
                               for s in r.get("sensitivity", [])
                               if s["variant"] != "eps=-1"] or [None],
                              key=lambda x: (x is None, x)),
                "zeros": r.get("zeros_found_in_0_T"),
                "expected": r.get("expected_zero_count_2T"),
                "real_zero": r.get("real_zero_in_(0,1)"),
                "Lambda_half": r.get("Lambda_half"),
                "min_abs_real": r.get("min_abs_Lambda_real"),
                "dedekind_fail": d.get("dedekind_factorisation_failures"),
            })
    out.sort(key=lambda r: (r["dK"], r["dim"], r["rep"]))
    return out


def fmt(x, n=2):
    if x is None:
        return "--"
    if isinstance(x, float):
        return f"{x:.{n}e}"
    return str(x)


def main():
    rs = rows()
    print("| d_K | rep | dim | conductor N | terms | FE spread | eps=-1 | wrong N |"
          " zeros in [0,10] | RvM/2 | real zero in (0,1) |")
    print("|---|---|---|---|---|---|---|---|---|---|---|")
    for r in rs:
        if r["skipped"]:
            print(f"| {r['dK']} | rho_{r['rep']} | {r['dim']} | {r['N']} | -- |"
                  f" not attempted | | | | | |")
            continue
        exp = r["expected"] / 2 if r["expected"] else None
        print(f"| {r['dK']} | rho_{r['rep']} | {r['dim']} | {r['N']} |"
              f" {r['terms']} | {fmt(r['fe'])} | {fmt(r['sens_eps'])} |"
              f" {fmt(r['sens_N'])} | {r['zeros']} |"
              f" {exp:.1f} | {'YES' if r['real_zero'] else 'no'} |"
              if exp else "")
    json.dump(rs, open(os.path.join(DATA, "status_table.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
