"""Find, for a number field K = Q[x]/(f) and a prime p, a defining polynomial h
of K such that Z[theta_h] is p-maximal.

We work inside the p-maximal order O_p computed by round 2, take small integral
combinations of its basis, and compute their characteristic polynomials.
"""
import itertools
import json
import random
import sys
from fractions import Fraction

from ntlib import disc, pdeg
from round2 import p_maximal, polmulmod, solve_rows


def charpoly_of(x_pow, W, f):
    """x given in power-basis coords; W a basis of an order containing x.
    Return the characteristic polynomial of multiplication by x (integer list)."""
    n = len(W)
    fr = [Fraction(c) for c in f]
    rows = []
    for w in W:
        prod = polmulmod(list(x_pow), list(w), fr)
        c = solve_rows(W, prod)
        rows.append([Fraction(t) for t in c])
    # Faddeev-LeVerrier on the n x n rational matrix `rows` (acting on coords)
    A = rows
    M = [[Fraction(1 if i == j else 0) for j in range(n)] for i in range(n)]
    coeffs = [Fraction(1)]
    for k in range(1, n + 1):
        AM = [[sum(A[i][t] * M[t][j] for t in range(n)) for j in range(n)]
              for i in range(n)]
        tr = sum(AM[i][i] for i in range(n))
        ck = -tr / k
        coeffs.append(ck)
        M = [[AM[i][j] + (ck if i == j else 0) for j in range(n)] for i in range(n)]
    # char poly = x^n + c1 x^{n-1} + ... ; return ascending list
    out = []
    for i in range(n + 1):
        c = coeffs[n - i]
        assert c.denominator == 1, c
        out.append(int(c))
    return out


def find_pmaximal_poly(f, p, tries=12000, seed=1):
    n = len(f) - 1
    W, idx = p_maximal(f, p)
    if idx == 1:
        return f, disc(f), [Fraction(0), Fraction(1)] + [Fraction(0)] * (n - 2)
    rnd = random.Random(seed)
    seen = set()
    best = None
    for t in range(tries):
        if t < 400:
            c = [rnd.randint(-2, 2) for _ in range(n)]
        else:
            c = [rnd.randint(-5, 5) for _ in range(n)]
        if tuple(c) in seen or not any(c[1:]):
            continue
        seen.add(tuple(c))
        x = [Fraction(0)] * n
        for i in range(n):
            if c[i]:
                for j in range(n):
                    x[j] += c[i] * W[i][j]
        h = charpoly_of(x, W, [Fraction(a) for a in f])
        if pdeg(h) != n:
            continue
        D = disc(h)
        if D == 0:
            continue
        # is it a generator?  disc != 0 <=> separable <=> generator
        _, i2 = p_maximal(h, p)
        if i2 == 1:
            if best is None or abs(D) < abs(best[0]):
                best = (D, h, [Fraction(t) for t in x])
            if t > 600:
                break
    if best is None:
        return None, None, None
    return best[1], best[0], best[2]


if __name__ == "__main__":
    f = json.loads(sys.argv[1])
    ps = [int(x) for x in sys.argv[2].split(",")]
    for p in ps:
        h, D, x = find_pmaximal_poly(f, p)
        print(p, h, D, x)
