"""Recompute d_K rigorously for every field in fields_B60.json using round 2."""
import json, sys, math
from ntlib import disc
from round2 import p_maximal

IN = "../../data/a5/fields_B60.json"
OUT = "../../data/a5/fields_B60_exact.json"


def square_part_primes(m):
    """primes p with p^2 | m  (m may be large; trial division)."""
    ps = []
    tmp = abs(m)
    i = 2
    while i * i <= tmp:
        if tmp % i == 0:
            e = 0
            while tmp % i == 0:
                tmp //= i
                e += 1
            if e >= 2:
                ps.append(i)
        i += 1 if i == 2 else 2
    return ps


def main():
    d = json.load(open(IN))
    out = []
    for k, fld in enumerate(d["fields"]):
        polys = sorted(fld["polys"], key=lambda q: abs(q["disc"]))
        p0 = polys[0]
        f = p0["poly"]
        D = disc(f)
        dK = D
        idxs = {}
        for p in square_part_primes(D):
            _, idx = p_maximal(f, p)
            if idx > 1:
                idxs[p] = idx
                dK //= idx * idx
        rec = {
            "dK": dK,
            "sqrt_dK": math.isqrt(dK) if math.isqrt(dK) ** 2 == dK else None,
            "poly": f,
            "disc_poly": D,
            "index": idxs,
            "n_polys": len(fld["polys"]),
        }
        out.append(rec)
        print(k, dK, f, idxs, flush=True)
    out.sort(key=lambda r: r["dK"])
    json.dump({"B": d["B"], "fields": out}, open(OUT, "w"), indent=1)
    print("wrote", OUT, len(out))


if __name__ == "__main__":
    main()
