#!/bin/bash
# parallel enumeration: one job per (a4, a3)
B=${1:-60}
CAP=${2:-1e11}
OUT=${3:-/workspace/request-project/data/a5/parts}
mkdir -p $OUT
for a4 in 0 1 2; do
  amin=$(( ( $a4*$a4 - $B ) / 2 - 1 ))
  amax=$(( a4*a4*2/5 ))
  for a3 in $(seq $amin $amax); do
    echo "$a4 $a3"
  done
done | xargs -P 7 -n 2 bash -c 'python3 /workspace/request-project/scripts/a5/search.py '"$B"' '"$CAP"' $0 $1 > '"$OUT"'/part_$0_$1.json 2>/dev/null'
echo ALLDONE
