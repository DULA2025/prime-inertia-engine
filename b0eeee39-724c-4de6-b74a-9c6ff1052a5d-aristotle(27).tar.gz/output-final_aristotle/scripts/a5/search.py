"""Enumerate totally real quintic fields with Galois group A5.

Method
------
Hunter's theorem: every quintic field K contains a generator theta with
  Tr(theta) = -a4 in {-2,...,2}   and   T2(theta) = sum |r_i|^2 <= a4^2/5 + gamma_4 (|d_K|/5)^(1/4),
with gamma_4 = sqrt(2) the Hermite constant.  We therefore enumerate monic
integral quintics x^5 + a4 x^4 + ... + a0 with a4 in {0,1,2} (the sign of a4 is
normalised by x -> -x) and T2 = a4^2 - 2 a3 <= B.

Total real-rootedness is imposed level by level: f is totally real  =>  every
derivative is totally real.  Knowing the critical points of f^(k+1) turns the
condition "f^(k) has all roots real" into an explicit interval for the constant
coefficient of f^(k), so the enumeration only visits totally real polynomials.

For each totally real quintic we then check: squarefree, irreducible, square
discriminant, and the presence of a 3-cycle Frobenius (which forces the Galois
group of an irreducible quintic with square discriminant to be A5).
"""

import json
import sys
from math import isqrt

from ntlib import (disc, is_square, factor_pattern, dedekind_maximal, pdeg,
                   peval_f, real_roots)

PRIMES = []


def sieve(n):
    bs = bytearray([1]) * (n + 1)
    bs[0] = bs[1] = 0
    for i in range(2, isqrt(n) + 1):
        if bs[i]:
            bs[i * i::i] = bytearray(len(bs[i * i::i]))
    return [i for i in range(n + 1) if bs[i]]


PRIMES = sieve(2000)


def roots_bracketed(c, crit):
    """Real roots of polynomial c (little endian, positive leading coeff),
    given the sorted list of its critical points."""
    d = len(c) - 1
    M = 1.0 + max(abs(x / c[d]) for x in c[:-1])
    pts = [-M] + list(crit) + [M]
    ev = [peval_f(c, x) for x in pts]
    out = []
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        fa, fb = ev[i], ev[i + 1]
        if fa == 0.0:
            out.append(a)
            continue
        if fa * fb < 0.0:
            for _ in range(60):
                m = 0.5 * (a + b)
                fm = peval_f(c, m)
                if fa * fm <= 0.0:
                    b, fb = m, fm
                else:
                    a, fa = m, fm
                if b - a < 1e-13 * max(1.0, abs(a)):
                    break
            out.append(0.5 * (a + b))
    if ev[-1] == 0.0:
        out.append(pts[-1])
    return out


def enumerate_quintics(B, disc_cap, a4_list=(0, 1, 2), a3_list=None):
    """Yield (poly, disc) for totally real irreducible quintics with square
    discriminant <= disc_cap and T2 <= B."""
    for a4 in a4_list:
        a3max = int((0.4 * a4 * a4) // 1)
        a3min = -((B - a4 * a4) // 2)
        rng = range(int(a3min) - 1, a3max + 1) if a3_list is None else a3_list
        for a3 in rng:
            if a4 * a4 - 2 * a3 > B:
                continue
            # f''' = 60x^2 + 24 a4 x + 6 a3 ; roots
            D3 = (24.0 * a4) ** 2 - 4 * 60 * 6 * a3
            if D3 < 0:
                continue
            s = D3 ** 0.5
            c1 = (-24.0 * a4 - s) / 120.0
            c2 = (-24.0 * a4 + s) / 120.0
            # f'' = 20x^3 + 12 a4 x^2 + 6 a3 x + 2 a2 ; need f''(c1) >= 0 >= f''(c2)
            def h2(x):
                return 20 * x ** 3 + 12 * a4 * x ** 2 + 6 * a3 * x
            lo = -h2(c1) / 2.0
            hi = -h2(c2) / 2.0
            if hi < lo:
                continue
            for a2 in range(int(lo // 1) - 1, int(hi // 1) + 2):
                if a4 == 0 and a2 < 0:
                    continue
                cub = [2.0 * a2, 6.0 * a3, 12.0 * a4, 20.0]
                d = roots_bracketed(cub, [c1, c2])
                if len(d) != 3:
                    continue
                d1, d2, d3 = d
                # f' = 5x^4+4a4x^3+3a3x^2+2a2x + a1
                def h1(x):
                    return 5 * x ** 4 + 4 * a4 * x ** 3 + 3 * a3 * x ** 2 + 2 * a2 * x
                alo = -h1(d2)
                ahi = min(-h1(d1), -h1(d3))
                if ahi < alo:
                    continue
                for a1 in range(int(alo // 1) - 1, int(ahi // 1) + 2):
                    quart = [float(a1), 2.0 * a2, 3.0 * a3, 4.0 * a4, 5.0]
                    e = roots_bracketed(quart, [d1, d2, d3])
                    if len(e) != 4:
                        continue
                    e1, e2, e3, e4 = e

                    def h0(x):
                        return x ** 5 + a4 * x ** 4 + a3 * x ** 3 + a2 * x ** 2 + a1 * x
                    blo = max(-h0(e1), -h0(e3))
                    bhi = min(-h0(e2), -h0(e4))
                    if bhi < blo:
                        continue
                    for a0 in range(int(blo // 1) - 1, int(bhi // 1) + 2):
                        if a4 == 0 and a2 == 0 and a0 < 0:
                            continue
                        f = [a0, a1, a2, a3, a4, 1]
                        r = roots_bracketed([float(x) for x in f], e)
                        if len(r) != 5:
                            continue
                        # numeric discriminant filter
                        dn = 1.0
                        ok = True
                        for i in range(5):
                            for j in range(i + 1, 5):
                                dn *= (r[i] - r[j]) ** 2
                                if dn > 10.0 * disc_cap:
                                    ok = False
                                    break
                            if not ok:
                                break
                        if not ok:
                            continue
                        D = disc(f)
                        if D <= 0 or D > disc_cap:
                            continue
                        if not is_square(D):
                            continue
                        yield f, D


def galois_a5(f, D):
    """Return (is_A5, pattern_data).  Requires D = disc(f) a nonzero square.

    An irreducible quintic with square discriminant has Galois group C5, D5
    or A5; only A5 contains 3-cycles, so a factorisation pattern 1+1+3 modulo
    an unramified prime certifies A5.  Irreducibility is certified by a prime
    modulo which f is irreducible (pattern [5])."""
    irred = False
    three = False
    for p in PRIMES:
        if D % p == 0:
            continue
        pat = factor_pattern(f, p)
        if pat is None:
            continue
        if pat == [5]:
            irred = True
        if pat == [1, 1, 3]:
            three = True
        if pat not in ([5], [1, 1, 3], [1, 2, 2], [1, 1, 1, 1, 1]):
            return False, pat          # odd permutation: not inside A5
        if irred and three:
            return True, None
    return False, None


def field_disc(f, D):
    """Return (d_K, certified) using Dedekind's criterion at every prime whose
    square divides disc(f)."""
    d = D
    certified = True
    n = D
    p = 2
    sq = {}
    m = D
    for p in PRIMES:
        if p * p > m:
            break
        while m % p == 0:
            sq[p] = sq.get(p, 0) + 1
            m //= p
    if m > 1:
        sq[m] = sq.get(m, 0) + 1
    for p, e in sq.items():
        if e >= 2:
            if not dedekind_maximal(f, p):
                certified = False
    return (D if certified else None), sq


def fingerprint(f, D, nprimes=40):
    out = []
    cnt = 0
    for p in PRIMES:
        if D % p == 0:
            continue
        pat = factor_pattern(f, p)
        out.append((p, tuple(pat)))
        cnt += 1
        if cnt >= nprimes:
            break
    return tuple(out)


def main():
    B = int(sys.argv[1]) if len(sys.argv) > 1 else 53
    cap = int(float(sys.argv[2])) if len(sys.argv) > 2 else 10 ** 11
    a4_list = [int(sys.argv[3])] if len(sys.argv) > 3 else (0, 1, 2)
    a3_list = [int(sys.argv[4])] if len(sys.argv) > 4 else None
    out = {}
    n = 0
    for f, D in enumerate_quintics(B, cap, a4_list, a3_list):
        n += 1
        ok, _ = galois_a5(f, D)
        if not ok:
            continue
        dK, sq = field_disc(f, D)
        key = None
        fp = fingerprint(f, D)
        rec = out.get(fp)
        if rec is None:
            rec = {"polys": [], "disc_poly_min": None, "dK": None}
            out[fp] = rec
        rec["polys"].append([f, D, dK is not None])
        if dK is not None and (rec["dK"] is None or dK < rec["dK"]):
            rec["dK"] = dK
        if rec["disc_poly_min"] is None or D < rec["disc_poly_min"]:
            rec["disc_poly_min"] = D
    res = []
    for fp, rec in out.items():
        rec["polys"].sort(key=lambda t: t[1])
        res.append({"dK": rec["dK"], "disc_poly_min": rec["disc_poly_min"],
                    "polys": rec["polys"][:6]})
    res.sort(key=lambda r: (r["dK"] if r["dK"] else r["disc_poly_min"]))
    print(json.dumps({"B": B, "cap": cap, "n_totally_real_sq_disc": n,
                      "fields": res}, indent=1))


if __name__ == "__main__":
    main()
