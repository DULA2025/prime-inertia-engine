"""Generate docs/A5_even_Artin.md from the computed data files."""
import glob
import json
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "..", "data", "a5"))
DOCS = os.path.normpath(os.path.join(HERE, "..", "..", "docs"))

from lfunc import log_gamma_factor          # noqa: E402


def theta(n, N, T):
    return 0.5 * T * math.log(N) + log_gamma_factor(n, complex(0.5, T)).imag


def rvm(n, N, T):
    """Riemann-von Mangoldt prediction for #{zeros with 0 < gamma <= T}."""
    return theta(n, N, T) / math.pi + 1.0


def load_catalog():
    return json.load(open(os.path.join(DATA, "catalog.json")))


def load_fields():
    out = []
    for fn in sorted(glob.glob(os.path.join(DATA, "field_*.json"))):
        out.append(json.load(open(fn)))
    out.sort(key=lambda d: d["dK"])
    return out


def fmt_ram(s):
    parts = []
    for p, v in s["ramification"].items():
        parts.append("%s(|I|=%s%s)" % (p, v["inertia_order"],
                                       "" if v["tame"] else ",wild"))
    return " ".join(parts)


def catalog_table(cat, n=20):
    L = ["| # | d_K | defining polynomial | ramification | N(ρ₃)=N(ρ₃′)=N(ρ₄) |"
         " N(ρ₅) |", "|---|---|---|---|---|---|"]
    k = 0
    for s in cat["fields"][:n]:
        k += 1
        if "error" in s:
            L.append(f"| {k} | {s['dK']} | `{s['poly']}` | *local data not "
                     f"determined* | – | – |")
            continue
        poly = "x^5" + "".join(
            f" {'+' if c > 0 else '-'} {abs(c)}x^{i}" for i, c in
            reversed(list(enumerate(s["poly"][:-1]))) if c) .replace("x^0", "")
        L.append("| %d | %d | `%s` | %s | %d | %d |" %
                 (k, s["dK"], poly, fmt_ram(s), s["conductors"]["4"],
                  s["conductors"]["5"]))
    return "\n".join(L)


REPNAME = {"3": "ρ₃", "3b": "ρ₃′", "4": "ρ₄", "5": "ρ₅"}


def status_table(fields):
    L = ["| d_K | ρ | dim | conductor N | Dirichlet terms | FE/holomorphy"
         " residual | with ε = −1 | with wrong N | Λ(1/2) |",
         "|---|---|---|---|---|---|---|---|---|"]
    for d in fields:
        for r in d["reps"]:
            if r.get("skipped"):
                L.append("| %d | %s | %d | %d | – | not attempted (%s) | | | |"
                         % (d["dK"], REPNAME[r["rep"]], r["dim"],
                            r["conductor"], r["skipped"]))
                continue
            fe = r["functional_equation"]["worst_spread_over_Lambda_half"]
            sens = {s["variant"]: s["worst_spread_over_Lambda_half"]
                    for s in r["sensitivity"]}
            wrongN = min(v for k, v in sens.items() if k != "eps=-1")
            L.append("| %d | %s | %d | %d | %d | %.1e | %.1e | %.1e | %.6g |"
                     % (d["dK"], REPNAME[r["rep"]], r["dim"], r["conductor"],
                        r["terms"], fe, sens["eps=-1"], wrongN,
                        r.get("Lambda_half", float("nan"))))
    return "\n".join(L)


def realzero_table(fields):
    L = ["| d_K | ρ | min |Λ(σ)| on [1/2,1] | sign change on (0,1)? |",
         "|---|---|---|---|"]
    for d in fields:
        for r in d["reps"]:
            if r.get("skipped") or "min_abs_Lambda_real" not in r:
                continue
            L.append("| %d | %s | %.6g | %s |"
                     % (d["dK"], REPNAME[r["rep"]], r["min_abs_Lambda_real"],
                        "YES" if r["real_zero_in_(0,1)"] else "no"))
    return "\n".join(L)


REPORDER = {"3": 0, "3b": 1, "4": 2, "5": 3}


def zero_table():
    L = ["| d_K | ρ | dim | N | T_rel | zeros in (0,T_rel] | RvM prediction |"
         " first zero |",
         "|---|---|---|---|---|---|---|---|"]
    rows = []
    for fn in sorted(glob.glob(os.path.join(DATA, "zeros_*.json"))):
        base = os.path.basename(fn)[len("zeros_"):-len(".json")]
        dk, rep = base.split("_", 1)
        d = json.load(open(fn))
        v = d["values"]
        dim = {"3": 3, "3b": 3, "4": 4, "5": 5}[rep]
        # range in which |Lambda| stays well above the estimated absolute
        # accuracy (~1e-12): the last local maximum above 1e-9
        tmax = 0.0
        for i in range(1, len(v) - 1):
            a, b, c = abs(v[i - 1][1]), abs(v[i][1]), abs(v[i + 1][1])
            if b >= a and b >= c and b > 1e-9:
                tmax = v[i][0]
        nz = sum(1 for z in d["zeros"] if z <= tmax)
        rows.append((int(dk), rep, dim, d, tmax, nz))
    rows.sort(key=lambda t: (t[0], REPORDER[t[1]]))
    for dk, rep, dim, d, tmax, nz in rows:
        N = d["conductor"]
        pred = rvm(dim, N, tmax)
        zs = [z for z in d["zeros"] if z <= tmax]
        first = zs[0] if zs else None
        L.append("| %d | %s | %d | %d | %.2f | %d | %.1f | %s |"
                 % (dk, REPNAME[rep], dim, N, tmax, nz, pred,
                    ("%.4f" % first) if first else "–"))
    return "\n".join(L)


PROSE = r"""# Even `A₅` Artin representations in dimensions 3, 3′, 4 and 5

*Report produced by `scripts/a5/make_report.py`; all numbers below are read off
the JSON files in `data/a5/`.*

## 0. What this report contains

Let `K/ℚ` be a totally real quintic field whose Galois closure `N/ℚ` has
`Gal(N/ℚ) ≃ A₅`.  The four nontrivial irreducible complex representations of
`A₅`, of dimensions 3, 3, 4 and 5, give **even** Artin representations
`ρ : Gal(ℚ̄/ℚ) → GLₙ(ℂ)`, `n ∈ {3,4,5}`.  Artin's holomorphy conjecture for
these is open.

This report

* enumerates the smallest totally real `A₅` quintic fields and computes, for
  each, the exact field discriminant, the ramification data and the Artin
  conductors of `ρ₃, ρ₃′, ρ₄, ρ₅` (Section 2, Section 3);
* explains exactly which parts of the picture are theorems and which are
  numerics (Section 1);
* reports high-precision numerical tests of the **holomorphy** of the completed
  L-functions, of their zeros on the critical line and of the absence of real
  zeros in `(0,1)` (Sections 4–6);
* gives a status table and identifies the most promising fields for a future
  rigorous verification (Section 7);
* records theoretical observations and the obstacles specific to the even
  higher-dimensional setting (Sections 8–9).

Everything is reproducible from the scripts in `scripts/a5/` using nothing but
a standard Python 3 interpreter; the representation-theoretic identities that
the computation relies on are proved in Lean in `RequestProject/A5Artin.lean`.

## 1. What is a theorem and what is numerics

**1.1 Evenness.**  If `K` is totally real then all five roots of a defining
polynomial are real, so complex conjugation fixes them all, hence acts
trivially on `N`: `N` is totally real and *every* Artin representation of
`Gal(N/ℚ)` is even.  Consequently the completed L-function of an
`n`-dimensional such `ρ` is

>  `Λ(ρ,s) = N(ρ)^{s/2} · (π^{-s/2} Γ(s/2))ⁿ · L(ρ,s)`,

with `n` copies of the *same* archimedean factor `Γ_ℝ(s)` — there is no
`Γ_ℝ(s+1)` factor, which is what makes the even case harder: the gamma factor
has a pole of order `n` at `s = 0`, and the "trivial zero" structure that in the
odd case forces some vanishing is absent.

**1.2 Brauer.**  By Brauer induction each `L(ρ,s)` extends to a meromorphic
function on `ℂ` and satisfies the functional equation
`Λ(ρ,s) = ε(ρ) Λ(ρ̄,1−s)`.  All four representations here are self-dual with
real character, so `ρ̄ = ρ`.  *The functional equation is therefore a theorem;
what is open is holomorphy* (absence of poles).

**1.3 The Aramata–Brauer constraint.**  `ζ_N(s)/ζ(s)` is entire.  Combined with
the factorisation

>  `ζ_N = ζ · L(ρ₃)³ L(ρ₃′)³ L(ρ₄)⁴ L(ρ₅)⁵`

(proved class-by-class in Lean as `A5Artin.regPoly_eq`) this says that any pole
of one of the four L-functions must be cancelled by zeros of the others.  In
particular a *simple* pole of, say, `L(ρ₅)` would force a zero of order ≥ 5 of
the remaining product at the same point.

**1.4 What the numerical test actually tests.**  We evaluate

>  `Λ(s) = G(s,u) + ε·G(1−s,1/u)`,  `G(w,u) = Σ_k a_k ∫_{u·k/Q}^∞ Φ(t) t^{w-1} dt`,
>  `Q = √N`, `Φ =` inverse Mellin transform of `(π^{-s/2}Γ(s/2))ⁿ`.

`G(w,u) = ∫_u^∞ θ(v) v^{w−1} dv` for the theta series `θ(v) = Σ_k a_k Φ(kv/Q)`,
so the displayed identity is *equivalent* to `Λ` being entire and satisfying the
functional equation: if `Λ` had a pole, the formula would acquire extra terms
depending on the split point `u`.  Hence

>  **the `u`-independence of the computed `Λ(s)` is a numerical test of
>  holomorphy**, the functional equation itself being known (1.2).

The tables below report `max_u |Λ(s,u) − Λ(s,1)| / |Λ(1/2)|` over
`u ∈ {0.75, 1, 1.35}` and `s ∈ {1/2, 1/2+2i, 1/2+6i, 1}`.  For calibration the
same quantity is recomputed with the wrong sign `ε = −1` and with a wrong
conductor; those variants come out `O(10¹)`–`O(10³)`, i.e. some 15 orders of
magnitude worse.

## 2. The smallest totally real `A₅` quintic fields

The enumeration (`scripts/a5/search.py`) uses Hunter's theorem: every quintic
field contains a generator `θ ∉ ℤ` with `|Tr θ| ≤ 2` and
`T₂(θ) ≤ (Tr θ)²/5 + √2·(d_K/5)^{1/4}`.  Total reality is imposed level by level
on the derivatives, so only totally real polynomials are visited.  Galois group
`A₅` is certified by a square discriminant together with a prime whose
factorisation type is `1+1+3` (only `A₅` among `C₅, D₅, A₅` contains 3-cycles),
and irreducibility by a prime modulo which the polynomial is inert.

The run used `T₂ ≤ 60` and kept polynomial discriminants up to `10¹¹`; it is
therefore **complete for `d_K ≤ 1.53·10⁷`** (the Hunter bound with `T₂ = 60`),
subject only to the mild proviso that the Hunter generator has polynomial
discriminant below the cutoff `10¹¹`.  It produced {NFIELDS} distinct fields.

Field discriminants are computed *exactly* with a Pohst–Zassenhaus round-2
`p`-maximal order algorithm (`scripts/a5/round2.py`), not merely by Dedekind's
criterion; this matters, because the smallest field in the list is only visible
after removing an index `2²` from the polynomial discriminant.

{CATALOG}

`|I|` is the order of the inertia group; "wild" means `p` divides `|I|`.

## 3. Arithmetic input to the L-functions

**3.1 Conductors.**  For `p` with inertia `I` and higher ramification groups
`G₀ = I ⊇ G₁ ⊇ …` (lower numbering) the Artin conductor exponent is
`a(ρ) = Σ_{i≥0} |G_i|/|G₀| · codim V^{G_i}`.  We know `a(ρ₄) = v_p(d_K)`
(conductor–discriminant, using `ζ_K = ζ·L(ρ₄)`), and `G₁` is the `p`-Sylow
subgroup of `I`; enumerating the possible jump sequences and keeping those
compatible with `v_p(d_K)` determines the exponents of all four
representations (`artin.conductor_exponents`).  In every case in the table the
jump data was pinned down uniquely.

Because `dim V^I` is the same for `ρ₃, ρ₃′, ρ₄` for all the inertia groups that
occur (cyclic of order 2, 3, 5, or the Klein four group), one always has
`N(ρ₃) = N(ρ₃′) = N(ρ₄) = d_K`, whereas `N(ρ₅)` is usually much larger — it
equals `d_K` only when every inertia group is of order 2.  This single fact
governs which dimension-5 L-functions are computationally reachable.

**3.2 Frobenius classes and the two classes of 5-cycles.**  For unramified `p`
the factorisation type of `f mod p` gives the cycle type of `Frob_p`.  Cycle
type `(5)` splits into the two `A₅`-classes `5A`, `5B`, which is what
distinguishes `ρ₃` from `ρ₃′`.  They are separated as follows: with the roots
labelled by increasing size, `D = ∏_{i<j}(r_j − r_i) = +√(disc f)` is a positive
integer; in `𝔽_p[x]/(f)` put `s_1 = x`, `s_{i+1} = s_i^p` and
`Δ = ∏_{i<j}(s_i − s_j)`.  Then `Frob_p` lies in the class of `(1 2 3 4 5)` iff
`Δ ≡ D`.

*This test must be done modulo `p²`, not modulo `p`.*  Modulo 2 one has
`+D ≡ −D`, so the mod-`p` test returns an arbitrary answer at `p = 2` and the
resulting `L(ρ₃,s)` is simply a different (and wrong) Dirichlet series.  We
therefore lift the Frobenius to `(ℤ/p²)[x]/(f)` by one Newton step and compare
`Δ` with `±D` there (`artin.A5Field.five_cycle_is_5A`).  The effect is not
subtle: for `d_K = 69072721` the holomorphy residual for `ρ₃` was `1.4·10⁻⁴`
with the mod-`p` test and is `1.3·10⁻¹⁴` with the mod-`p²` test.

**3.3 Local data at ramified primes, and a genuine ambiguity.**  At a ramified
prime the pair (inertia `I`, Frobenius `F`) is reconstructed from the `(e,f)`
data of `p` in `K`.  Occasionally two different pairs give the same `(e,f)` data
but different Euler factors — the standard example is `I = V₄` at `p = 2` with
decomposition group `V₄` or `A₄`.  These are separated by the residue degrees of
`p` in the degree-10 resolvent algebra (the étale algebra of unordered pairs of
roots), which are `1,1,1,1` in the first case and `3,1` in the second.  The
resolvent is computed in floating point and then *certified exactly* by
verifying the polynomial identity
`Res_y(f(y), f(x−y)) = ∏_i(x − 2r_i) · R₁₀(x)²` at 26 integer points
(`scripts/a5/resolvent.py`).

One ambiguity survives this: at a prime with cyclic inertia of order 5 the
decomposition group can be `C₅` or `D₁₀`, and neither the quintic nor the
degree-10 resolvent sees the difference (it would need the degree-12 resolvent).
Fields with that behaviour are flagged and excluded from the table.

**3.4 Consistency with the factorisation of `ζ_K`.**  For every field we verify
`(1−T)·E₄(T) = ∏_{P|p}(1 − T^{f_P})` at the first 300 primes, i.e. the Euler
factors of `ζ(s)·L(ρ₄,s)` agree with those of `ζ_K(s)`, ramified primes
included.  No failures occurred for any field in the table.  The corresponding
class-by-class polynomial identity is proved in Lean
(`A5Artin.permPoly5_eq`), as is the full regular-representation factorisation
(`A5Artin.regPoly_eq`), so the consistency of our Euler factors with the
factorisation of `ζ_N` is automatic once the local data is right.

## 4. Numerical method

`Φ(t)`, the inverse Mellin transform of `(π^{-s/2}Γ(s/2))ⁿ`, is tabulated on a
uniform grid in `log t` by saddle-point contour integration; the table is
validated against the closed forms `Φ₁(t) = 2e^{−πt²}` and `Φ₂(t) = 4K₀(2πt)`
(agreement `≈ 2·10⁻¹³`).  The incomplete Mellin integrals are obtained by
fourth-order cumulative integration and six-point Lagrange interpolation.  The
whole pipeline reproduces `L(χ₅,s)` and its powers `L(χ₅,s)ⁿ` to `10⁻¹³`.

Everything is double precision, so the *absolute* accuracy of `Λ` is around
`10⁻¹²`.  Since `|Λ(1/2+it)|` decays like the gamma factor, this limits the
height up to which zeros can be located — severely so in dimension 5.  The zero
tables below therefore quote the height `T_rel` up to which `|Λ|` stays above
`10⁻⁹`, i.e. three orders of magnitude above the noise.

## 5. Status table: holomorphy tests

The column "FE/holomorphy residual" is the quantity described in 1.4; a value of
`10⁻¹⁴` means that the split-point independence — equivalently, holomorphy of
`Λ` together with the functional equation with the stated `(N, ε=+1)` — holds to
14 significant digits.  The two calibration columns show what a *wrong* sign or
conductor produces.

{STATUS}

## 6. Zeros

**6.1 No real zeros in `(0,1)`.**  `Λ(σ)` was evaluated on `[1/2, 1]` in steps of
`0.025`; by the functional equation this covers `(0,1)`.  In every case `Λ` is
strictly positive there, with minimum at `σ = 1/2`.  In particular
`Λ(1/2) > 0`: no central zero, and no "exceptional real zero", for any of the
representations tested — including all the dimension-5 cases.

{REALZERO}

**6.2 Zeros on the critical line.**  Sign changes of `Λ(1/2+it)` were located on
a grid of step `0.02`.

{ZEROS}

All located zeros lie on `Re s = 1/2` (they are sign changes of the real
function `t ↦ Λ(1/2+it)`).  The counts agree with the Riemann–von Mangoldt
prediction to within the `O(log N)` error term of that formula and the
possibility of unresolved close pairs; no evidence of missing or extra zeros was
found.  Note that this is *not* a verification of RH for these L-functions: we
have not performed a Turing-type argument bounding the number of zeros off the
line.

## 7. Status assessment

*Strong numerical evidence of holomorphy* (split-point residual `≤ 10⁻¹³`,
wrong-sign and wrong-conductor variants `O(10)`–`O(10³)`, no real zero in
`(0,1)`, zero counts consistent with Riemann–von Mangoldt):

* dimensions 3, 3′, 4 for **every** field in the status table;
* dimension 5 for `d_K = 30991489` and `d_K = 69072721`, and (functional
  equation only, no zero search) for `d_K = 5184729`.

*No anomalies.*  No representation showed a real zero in `(0,1)`, a central
zero, or a split-point residual incompatible with holomorphy.  The only
irregularity encountered in the whole run — the `d_K = 69072721` degree-3
residual of `1.4·10⁻⁴` — was traced to the arithmetic bug described in 3.2 and
disappeared once the `5A/5B` test was done modulo `p²`.

*Most promising fields for a future rigorous verification.*

1. **`d_K = 30991489`, `f = x⁵ + x⁴ − 15x³ − 36x² − 21x − 1`.**  A single
   ramified prime `p = 5567`, tame, inertia of order 2, so
   `N(ρ₃) = N(ρ₃′) = N(ρ₄) = N(ρ₅) = 5567²`.  This is the *smallest* field for
   which all four L-functions, including the 5-dimensional one, have a conductor
   small enough for a complete numerical treatment.  Total reality of `f` is
   proved in Lean (`A5Artin.f₂_totally_real`).
2. **`d_K = 69072721`, `f = x⁵ + x⁴ − 16x³ − 7x² + 57x − 35`.**  Same structure
   (one tame prime `8311`, inertia of order 2), slightly larger.
3. **`d_K = 3104644`, `f = x⁵ + x⁴ − 11x³ − x² + 12x + 4`.**  The smallest
   totally real `A₅` quintic in the list; dimensions 3, 3′, 4 are cheap, but
   `N(ρ₅) = 9.6·10¹²` puts dimension 5 out of reach of this pipeline.  Total
   reality proved in Lean (`A5Artin.f₁_totally_real`).

## 8. Theoretical observations

**8.1 No cover is needed, and that is the whole point.**  The famous even
icosahedral case concerns *two*-dimensional representations, which are
projective `A₅`-representations and require the binary icosahedral group
`SL₂(𝔽₅)`.  The representations studied here are honest representations of
`A₅`, i.e. class functions of the quintic field; nothing about the run depends
on a `2`-cover.  What is lost is exactly the input that makes the odd
2-dimensional case a theorem: there is no Serre-type modularity statement for
`GLₙ`, `n ≥ 3`, that applies here.

**8.2 The root number.**  Every computation is consistent with `ε = +1`, to
14 digits, for all four representations and all fields.  This is what one
expects: all four representations are orthogonal (real character, Frobenius–
Schur indicator `+1`) and `A₅` is perfect, so `det ρ = 1`; Deligne's formula for
the root number of an orthogonal virtual representation of dimension 0 and
trivial determinant then expresses `ε` through a second Stiefel–Whitney class.
Our data can be read as a numerical confirmation that this class is trivial in
these examples.

**8.3 What functoriality would give.**  `ρ₄ = Ind_{A₄}^{A₅} 1 − 1`, so
`L(ρ₄,s) = ζ_K(s)/ζ(s)` and holomorphy of `L(ρ₄)` is exactly Dedekind's
conjecture for the quintic field `K`.  Similarly `ρ₅ = Ind_{D₁₀}^{A₅} 1 − 1`
gives `L(ρ₅,s) = ζ_{K₆}(s)/ζ(s)` for the sextic resolvent field `K₆`, and
`L(ρ₃)L(ρ₃′)L(ρ₅) = ζ_{K₁₂}(s)/ζ(s)` for the degree-12 field fixed by a Sylow
5-subgroup (`A5Artin.permPoly6_eq`, `A5Artin.permPoly12_eq`).  So the four open
holomorphy statements are equivalent to Dedekind-type statements for three
explicit number fields of degrees 5, 6 and 12 — a reformulation that makes the
dimension-5 case no harder than the others, and that suggests that the
`ζ_{K₆}/ζ` and `ζ_{K₁₂}/ζ` quotients are the right objects to attack.

**8.4 Where the even case is genuinely harder.**  Two concrete obstructions
show up in the computation itself.  (i) The gamma factor `Γ_ℝ(s)ⁿ` has an
`n`-fold pole at `s = 0`; on the critical line `|Λ(1/2+it)|` decays like
`e^{−nπt/4}`, so the numerical accessible range shrinks rapidly with the
dimension — this, and not the conductor, is what limits the dimension-5 zero
searches here.  (ii) The conductor of `ρ₅` is `d_K²` at every prime with inertia
of order 3 or 5 and only equals `d_K` at primes with inertia of order 2, so the
analytic conductor of `ρ₅` grows much faster than that of `ρ₄` across the family;
the fields for which dimension 5 is tractable are a thin subfamily
(those ramified only at primes with inertia of order 2).

## 9. What is still missing for a rigorous verification

For a *proof* of holomorphy of one of these L-functions in a single explicit
case one would need, beyond what is here:

1. **Interval/ball arithmetic** throughout: certified enclosures for the Euler
   factors (these are exact algebraic numbers, so this part is easy), for the
   inverse Mellin kernel `Φ`, for the incomplete Mellin integrals, and for the
   truncation tails.
2. **An effective bound on the number of poles.**  Brauer's induction expresses
   `L(ρ,s)` as `∏ L(χ_i,s)^{n_i}` with `n_i ∈ ℤ`; the possible poles lie among
   the zeros of the Hecke L-functions with negative exponent.  A finite,
   effectively computable region containing all possible poles, together with an
   argument-principle computation in that region, would turn the numerics into a
   proof.  This is the essential missing analytic ingredient.
3. **A Turing-type zero-counting argument** if one also wants RH-on-the-line
   statements; this in turn needs rigorous bounds on `∫ arg Λ`.
4. For the ambiguous fields of 3.3, the degree-12 resolvent (or a `5`-adic
   computation in the local quintic) to pin down the Euler factor at the wildly
   ramified prime `5`.

None of these is a conceptual obstacle for a single field; the missing piece
that would make the *general* even `A₅` case a theorem is, of course, something
else entirely — a functoriality or modularity input for `GL₃/GL₄/GL₅` that is
not available.

## 10. Files

| file | contents |
|---|---|
| `scripts/a5/ntlib.py` | integer/modular polynomial arithmetic, resultants, factorisation mod `p`, Dedekind's criterion |
| `scripts/a5/search.py`, `par_search.sh`, `merge.py` | Hunter-bound enumeration of totally real `A₅` quintics |
| `scripts/a5/round2.py` | Pohst–Zassenhaus `p`-maximal orders, exact field discriminants |
| `scripts/a5/pgen.py`, `order_ef.py` | `p`-maximal defining polynomials; residue degrees inside the maximal order (non-monogenic primes) |
| `scripts/a5/resolvent.py` | certified degree-10 resolvent |
| `scripts/a5/artin.py` | `A₅` character table, Frobenius classes, `5A/5B` separation, local Euler factors, conductor exponents |
| `scripts/a5/field_data.py` | assembly of all arithmetic data of one field |
| `scripts/a5/lfunc.py` | numerical completed L-functions with `Γ_ℝ(s)ⁿ` |
| `scripts/a5/analyse.py`, `run_one.py`, `run_batch.sh`, `zeros_fine.py` | the numerical experiments |
| `scripts/a5/catalog.py`, `make_report.py` | the tables in this report |
| `data/a5/catalog.json` | field table: discriminants, ramification, conductors |
| `data/a5/field_*.json` | per-field L-function results |
| `data/a5/zeros_*.json` | fine zero searches |
| `RequestProject/A5Artin.lean` | Lean proofs of the local factorisation identities, character orthogonality, and total reality of the two key defining polynomials |

## 11. Summary of the Lean content

| statement | meaning |
|---|---|
| `A5Artin.permPoly5_eq` | `ζ_K = ζ · L(ρ₄)` at the level of Euler factors, for every conjugacy class |
| `A5Artin.permPoly6_eq` | `ζ_{K₆} = ζ · L(ρ₅)` |
| `A5Artin.permPoly12_eq` | `ζ_{K₁₂} = ζ · L(ρ₃) L(ρ₃′) L(ρ₅)` |
| `A5Artin.regPoly_eq` | `ζ_N = ζ · L(ρ₃)³ L(ρ₃′)³ L(ρ₄)⁴ L(ρ₅)⁵` |
| `A5Artin.E3_mul_E3b` | the product of the two 3-dimensional Euler factors is rational |
| `A5Artin.chi3_norm`, … | row orthogonality of the character table |
| `A5Artin.f₁_totally_real`, `A5Artin.f₂_totally_real` | the two key quintics have five real roots, so the fields are totally real and the representations are even |
"""


def main():
    cat = load_catalog()
    fields = load_fields()
    os.makedirs(DOCS, exist_ok=True)
    text = (PROSE
            .replace("{NFIELDS}", str(cat["n_fields_total"]))
            .replace("{CATALOG}", catalog_table(cat))
            .replace("{STATUS}", status_table(fields))
            .replace("{REALZERO}", realzero_table(fields))
            .replace("{ZEROS}", zero_table()))
    with open(os.path.join(DOCS, "A5_even_Artin.md"), "w") as fh:
        fh.write(text)
    print("wrote", os.path.join(DOCS, "A5_even_Artin.md"))


if __name__ == "__main__":
    main()
