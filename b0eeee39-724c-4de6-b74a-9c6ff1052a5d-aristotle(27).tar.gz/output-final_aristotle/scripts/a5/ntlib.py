"""Minimal pure-python number theory library for quintic fields.

Polynomials are python lists of integers, index = degree (little endian),
so [1,2,3] means 1 + 2x + 3x^2.

Contents
--------
* exact integer polynomial arithmetic, resultants and discriminants
* polynomial arithmetic mod p, distinct-degree factorisation patterns
* Dedekind's criterion (p-maximality of Z[x]/(f))
* real-rootedness cascade used to enumerate totally real quintics
"""

from fractions import Fraction
from math import isqrt, gcd


# ---------------------------------------------------------------- integer polys

def pdeg(f):
    d = len(f) - 1
    while d >= 0 and f[d] == 0:
        d -= 1
    return d


def ptrim(f):
    d = pdeg(f)
    return f[:d + 1] if d >= 0 else []


def padd(f, g):
    n = max(len(f), len(g))
    return ptrim([(f[i] if i < len(f) else 0) + (g[i] if i < len(g) else 0) for i in range(n)])


def pmul(f, g):
    if not f or not g:
        return []
    r = [0] * (len(f) + len(g) - 1)
    for i, a in enumerate(f):
        if a:
            for j, b in enumerate(g):
                if b:
                    r[i + j] += a * b
    return ptrim(r)


def pscal(c, f):
    return ptrim([c * a for a in f])


def pderiv(f):
    return ptrim([i * f[i] for i in range(1, len(f))])


def peval(f, x):
    r = 0
    for a in reversed(f):
        r = r * x + a
    return r


def resultant(f, g):
    """Resultant of two integer polynomials, computed over Q (exact)."""
    F = [Fraction(a) for a in f]
    G = [Fraction(a) for a in g]
    res = Fraction(1)
    while True:
        df, dg = pdeg(F), pdeg(G)
        if dg < 0 or df < 0:
            return 0
        if dg == 0:
            res *= G[0] ** df
            return int(res) if res.denominator == 1 else res
        # pseudo-remainder step: F mod G
        R = F[:]
        while pdeg(R) >= dg:
            dr = pdeg(R)
            c = R[dr] / G[dg]
            for i in range(dg + 1):
                R[dr - dg + i] -= c * G[i]
            R = R[:dr]  # drop leading zero
            R = R + [Fraction(0)] * 0
            while len(R) and R[-1] == 0:
                R.pop()
        dr = pdeg(R)
        if dr < 0:
            return 0
        res *= (-1) ** (df * dg) * G[dg] ** (df - dr)
        F, G = G, R


def disc(f):
    """Discriminant of an integer polynomial."""
    n = pdeg(f)
    r = resultant(f, pderiv(f))
    s = (-1) ** (n * (n - 1) // 2)
    q = Fraction(s * r, f[n])
    assert q.denominator == 1
    return int(q)


def is_square(n):
    if n < 0:
        return False
    r = isqrt(n)
    return r * r == n


# ------------------------------------------------------------------ mod p polys

def pmod_p(f, p):
    return ptrim([a % p for a in f])


def mulmod(a, b, f, p):
    """a*b mod (f,p); f monic mod p."""
    if not a or not b:
        return []
    r = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b):
                if y:
                    r[i + j] = (r[i + j] + x * y) % p
    return polymod(r, f, p)


def polymod(r, f, p):
    d = pdeg(f)
    r = [x % p for x in r]
    while len(r) > d:
        c = r[-1] % p
        k = len(r) - 1 - d
        if c:
            for i in range(d + 1):
                r[k + i] = (r[k + i] - c * f[i]) % p
        r.pop()
    return ptrim(r)


def powmod_x(e, f, p):
    """x^e mod (f,p)."""
    result = [1]
    base = polymod([0, 1], f, p)
    while e:
        if e & 1:
            result = mulmod(result, base, f, p)
        base = mulmod(base, base, f, p)
        e >>= 1
    return result


def ppow(a, e, f, p):
    result = [1]
    base = a[:]
    while e:
        if e & 1:
            result = mulmod(result, base, f, p)
        base = mulmod(base, base, f, p)
        e >>= 1
    return result


def pgcd_p(a, b, p):
    a = pmod_p(a, p)
    b = pmod_p(b, p)
    while pdeg(b) >= 0:
        a, b = b, prem_p(a, b, p)
    d = pdeg(a)
    if d < 0:
        return []
    inv = pow(a[d], p - 2, p)
    return ptrim([(x * inv) % p for x in a])


def prem_p(a, b, p):
    a = [x % p for x in a]
    db = pdeg(b)
    inv = pow(b[db], p - 2, p)
    while True:
        da = pdeg(a)
        if da < db or da < 0:
            return ptrim(a)
        c = (a[da] * inv) % p
        for i in range(db + 1):
            a[da - db + i] = (a[da - db + i] - c * b[i]) % p
        a = a[:da]
        if not a:
            return []


def factor_pattern(f, p):
    """Degrees (sorted) of the irreducible factors of f mod p.

    Returns None if f mod p is not squarefree (p ramifies or p | index)."""
    fp = pmod_p(f, p)
    d = pdeg(fp)
    if d != pdeg(f):
        return None
    # make monic
    inv = pow(fp[d], p - 2, p)
    fp = [(x * inv) % p for x in fp]
    if pdeg(pgcd_p(fp, pderiv(fp), p)) > 0:
        return None
    degs = []
    h = polymod([0, 1], fp, p)   # x^(p^k)
    v = fp
    k = 0
    while pdeg(v) > 0:
        k += 1
        h = ppow(h, p, fp, p)
        g = pgcd_p(padd(h, [0, -1]), v, p)
        dg = pdeg(g)
        if dg > 0:
            assert dg % k == 0
            degs.extend([k] * (dg // k))
            v = pdiv_p(v, g, p)
        if k > pdeg(f):
            break
    return sorted(degs)


def pdiv_p(a, b, p):
    a = [x % p for x in a]
    db = pdeg(b)
    inv = pow(b[db], p - 2, p)
    q = [0] * (max(pdeg(a) - db + 1, 1))
    while True:
        da = pdeg(a)
        if da < db or da < 0:
            break
        c = (a[da] * inv) % p
        q[da - db] = c
        for i in range(db + 1):
            a[da - db + i] = (a[da - db + i] - c * b[i]) % p
        a = a[:da]
    return ptrim(q)


def ramified_pattern(f, p):
    """(e_i, f_i) data of p in Z[x]/(f) via factorisation of f mod p.

    Only valid when p does not divide the index [O_K : Z[x]/(f)].
    Returns list of (e, f) pairs."""
    fp = pmod_p(f, p)
    d = pdeg(fp)
    inv = pow(fp[d], p - 2, p)
    fp = [(x * inv) % p for x in fp]
    out = [(e, pdeg(g)) for (g, e) in factor_mod_p(fp, p)]
    return sorted(out)


def squarefree_factor_p(f, p):
    """Crude squarefree decomposition of a small-degree poly mod p:
    returns list of (squarefree part, multiplicity)."""
    out = []
    rest = f
    e = 1
    while pdeg(rest) > 0:
        g = pgcd_p(rest, pderiv(rest), p)
        sf = pdiv_p(rest, g, p) if pdeg(g) > 0 else rest
        if pdeg(sf) > 0:
            out.append((sf, e))
        if pdeg(g) <= 0:
            break
        rest = g
        e += 1
        if e > 10:
            break
    return out


def factor_irred_degrees(f, p):
    """Degrees of irreducible factors of a squarefree poly mod p."""
    degs = []
    h = polymod([0, 1], f, p)
    v = f
    k = 0
    while pdeg(v) > 0:
        k += 1
        h = ppow(h, p, f, p)
        g = pgcd_p(padd(h, [0, -1]), v, p)
        dg = pdeg(g)
        if dg > 0:
            degs.extend([k] * (dg // k))
            v = pdiv_p(v, g, p)
        if k > 20:
            break
    return degs


def factor_mod_p(f, p):
    """Full factorisation of f mod p: list of (monic irreducible, multiplicity)."""
    fp = pmod_p(f, p)
    d = pdeg(fp)
    inv = pow(fp[d], p - 2, p)
    fp = [(x * inv) % p for x in fp]
    n = d
    # distinct-degree parts
    P = {}
    h = polymod([0, 1], fp, p)      # x^(p^0) = x
    for k in range(1, n + 1):
        h = ppow(h, p, fp, p)       # x^(p^k)
        G = pgcd_p(padd(h, [0, -1]), fp, p)
        Q = G
        for e in range(1, k):
            if k % e == 0 and e in P and pdeg(P[e]) > 0:
                Q = pdiv_p(Q, P[e], p)
        if pdeg(Q) > 0:
            P[k] = Q
    irreds = []
    for k, Q in P.items():
        irreds.extend(equal_degree_split(Q, k, p))
    out = []
    for g in irreds:
        m = 0
        cur = fp
        while pdeg(cur) > 0 and pdeg(prem_p(cur[:], g, p)) < 0:
            cur = pdiv_p(cur, g, p)
            m += 1
        out.append((g, m))
    return out


def dedekind_maximal(f, p):
    """Dedekind's criterion: True iff Z[x]/(f) is p-maximal (f monic)."""
    facs = factor_mod_p(f, p)
    gbar = [1]
    hbar = [1]
    for (g, e) in facs:
        gbar = pmod_p(pmul(gbar, g), p)
        for _ in range(e - 1):
            hbar = pmod_p(pmul(hbar, g), p)
    # monic integer lifts with coefficients in [0,p)
    gh = pmul(gbar, hbar)
    num = padd(gh, pscal(-1, f))
    assert all(c % p == 0 for c in num), (f, p, num)
    F = [c // p for c in num]
    d = pgcd_p(pgcd_p(pmod_p(F, p), gbar, p), hbar, p)
    return pdeg(d) == 0


def factor_p_full(f, p):
    """Full factorisation of a squarefree poly mod p into monic irreducibles
    (Cantor-Zassenhaus, small degrees)."""
    import random
    d = pdeg(f)
    if d <= 0:
        return []
    inv = pow(f[d], p - 2, p)
    f = [(x * inv) % p for x in f]
    # distinct degree
    out = []
    h = polymod([0, 1], f, p)
    v = f
    k = 0
    while pdeg(v) > 0:
        k += 1
        h = ppow(h, p, f, p)
        g = pgcd_p(padd(h, [0, -1]), v, p)
        if pdeg(g) > 0:
            out.extend(equal_degree_split(g, k, p))
            v = pdiv_p(v, g, p)
        if k > d:
            break
    if pdeg(v) > 0:
        out.append(v)
    return out


def equal_degree_split(f, d, p):
    import random
    if pdeg(f) == d:
        return [f]
    rnd = random.Random(12345 + p)
    while True:
        a = [rnd.randrange(p) for _ in range(pdeg(f))]
        a = ptrim(a)
        if pdeg(a) < 1:
            continue
        g = pgcd_p(a, f, p)
        if 0 < pdeg(g) < pdeg(f):
            return equal_degree_split(g, d, p) + equal_degree_split(pdiv_p(f, g, p), d, p)
        if p == 2:
            # trace map
            t = a[:]
            s = a[:]
            for _ in range(d - 1):
                s = mulmod(s, s, f, 2)
                t = padd(t, s)
                t = polymod(t, f, 2)
            g = pgcd_p(t, f, 2)
        else:
            b = ppow(a, (p ** d - 1) // 2, f, p)
            g = pgcd_p(padd(b, [-1]), f, p)
        if 0 < pdeg(g) < pdeg(f):
            return equal_degree_split(g, d, p) + equal_degree_split(pdiv_p(f, g, p), d, p)


# ------------------------------------------------------------- real rootedness

def real_roots(coeffs, tol=1e-13):
    """All real roots of a real polynomial (list of floats, little endian),
    via Sturm-free recursive derivative method: exact for our small degrees."""
    d = len(coeffs) - 1
    while d >= 0 and abs(coeffs[d]) < 1e-300:
        d -= 1
    coeffs = coeffs[:d + 1]
    if d <= 0:
        return []
    if d == 1:
        return [-coeffs[0] / coeffs[1]]
    crit = real_roots([i * coeffs[i] for i in range(1, d + 1)], tol)
    crit = sorted(crit)
    # bound on roots (Cauchy)
    M = 1 + max(abs(c / coeffs[d]) for c in coeffs[:-1])
    pts = [-M] + crit + [M]
    ev = [peval_f(coeffs, x) for x in pts]
    roots = []
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        fa, fb = ev[i], ev[i + 1]
        if fa == 0.0:
            roots.append(a)
            continue
        if fa * fb < 0:
            for _ in range(200):
                m = 0.5 * (a + b)
                fm = peval_f(coeffs, m)
                if fa * fm <= 0:
                    b, fb = m, fm
                else:
                    a, fa = m, fm
                if b - a < tol * max(1.0, abs(a)):
                    break
            roots.append(0.5 * (a + b))
    if ev[-1] == 0.0:
        roots.append(pts[-1])
    return roots


def peval_f(c, x):
    r = 0.0
    for a in reversed(c):
        r = r * x + a
    return r
