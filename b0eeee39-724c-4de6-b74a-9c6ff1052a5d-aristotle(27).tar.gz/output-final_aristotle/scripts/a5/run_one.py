import json, sys, time
from field_data import FieldAnalysis
from analyse import analyse_rep

poly = json.loads(sys.argv[1])
out_file = sys.argv[2]
reps = sys.argv[3].split(",") if len(sys.argv) > 3 else ["3", "3b", "4", "5"]
T = float(sys.argv[4]) if len(sys.argv) > 4 else 10.0
t0 = time.time()
F = FieldAnalysis(poly, X=1000)
res = F.summary()
res["dedekind_factorisation_failures"] = F.check_dedekind_factorisation(300)
res["reps"] = []
for rep in reps:
    N = F.conductor[rep]
    light = N > 1e9
    res["reps"].append(analyse_rep(F, rep, T=T, verbose=False,
                                   coeff_cap=6000000,
                                   tcut=(6.0 if light else None),
                                   light=light))
    with open(out_file, "w") as fh:
        json.dump(res, fh, indent=1)
res["total_time"] = round(time.time() - t0, 1)
with open(out_file, "w") as fh:
    json.dump(res, fh, indent=1)
print("done", time.time() - t0)
