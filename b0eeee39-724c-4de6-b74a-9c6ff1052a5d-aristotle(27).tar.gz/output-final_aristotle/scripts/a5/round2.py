"""Pohst--Zassenhaus round-2 p-maximal order algorithm (pure Python, Fractions).

Given a monic irreducible integer polynomial f of degree n and a prime p, compute
the p-maximal order containing Z[theta], and hence v_p(d_K).

Orders are represented by an n x n matrix W of Fraction rows: row i gives the
coordinates of the i-th basis element in the power basis 1, theta, ..., theta^(n-1).
"""

from fractions import Fraction
from ntlib import disc


# ---------- polynomial arithmetic mod f (coefficients Fraction/int) ----------

def polmulmod(a, b, f):
    """a, b: coefficient lists length n (index = power of theta). f monic, len n+1."""
    n = len(f) - 1
    res = [0] * (2 * n - 1)
    for i, ai in enumerate(a):
        if ai == 0:
            continue
        for j, bj in enumerate(b):
            if bj == 0:
                continue
            res[i + j] += ai * bj
    # reduce
    for k in range(2 * n - 2, n - 1, -1):
        c = res[k]
        if c == 0:
            continue
        res[k] = 0
        for j in range(n):
            res[k - n + j] -= c * f[j]
    return res[:n]


def polpowmod(a, e, f):
    n = len(f) - 1
    r = [0] * n
    r[0] = 1
    base = list(a)
    while e:
        if e & 1:
            r = polmulmod(r, base, f)
        base = polmulmod(base, base, f)
        e >>= 1
    return r


# ---------- linear algebra ----------

def solve_rows(W, v):
    """Express vector v (length n) as rational combination c with c * W = v."""
    n = len(W)
    # build augmented system: unknowns c_0..c_{n-1}; equations sum_i c_i W[i][j] = v[j]
    A = [[Fraction(W[i][j]) for i in range(n)] + [Fraction(v[j])] for j in range(n)]
    # gaussian elimination
    row = 0
    piv = []
    for col in range(n):
        sel = None
        for r in range(row, n):
            if A[r][col] != 0:
                sel = r
                break
        if sel is None:
            raise ValueError("singular")
        A[row], A[sel] = A[sel], A[row]
        pv = A[row][col]
        A[row] = [x / pv for x in A[row]]
        for r in range(n):
            if r != row and A[r][col] != 0:
                fac = A[r][col]
                A[r] = [x - fac * y for x, y in zip(A[r], A[row])]
        piv.append(col)
        row += 1
        if row == n:
            break
    c = [Fraction(0)] * n
    for k, col in enumerate(piv):
        c[col] = A[k][n]
    return c


def hnf(rows, n):
    """Row-style HNF of an integer lattice spanned by `rows` (full rank n).
    Returns n x n lower-echelon integer basis."""
    mat = [list(r) for r in rows if any(r)]
    basis = [None] * n
    for r in mat:
        r = list(r)
        while True:
            # leading index
            lead = None
            for j in range(n):
                if r[j] != 0:
                    lead = j
                    break
            if lead is None:
                break
            if basis[lead] is None:
                if r[lead] < 0:
                    r = [-x for x in r]
                basis[lead] = r
                break
            b = basis[lead]
            # gcd combine
            a1, a2 = b[lead], r[lead]
            import math
            g = math.gcd(a1, a2)
            # extended gcd
            def egcd(a, b):
                if b == 0:
                    return (a, 1, 0)
                gg, x, y = egcd(b, a % b)
                return (gg, y, x - (a // b) * y)
            g, x, y = egcd(a1, a2)
            newb = [x * u + y * v for u, v in zip(b, r)]
            newr = [(a1 // g) * v - (a2 // g) * u for u, v in zip(b, r)]
            basis[lead] = newb
            r = newr
    for j in range(n):
        if basis[j] is None:
            raise ValueError("not full rank")
    # reduce above
    for j in range(n):
        for k in range(j):
            pass
    return basis


def kernel_mod_p(M, p, ncols):
    """M: list of rows (each length ncols) over F_p, viewed as a linear map
    x (length nrows) -> x*M ?  We want kernel of the map sending basis vector e_i
    to row i, i.e. vectors c with sum c_i M[i] = 0.  Returns list of basis vectors."""
    nrows = len(M)
    A = [[x % p for x in row] + [1 if k == i else 0 for k in range(nrows)]
         for i, row in enumerate(M)]
    # row reduce on first ncols columns
    row = 0
    for col in range(ncols):
        sel = None
        for r in range(row, nrows):
            if A[r][col] % p != 0:
                sel = r
                break
        if sel is None:
            continue
        A[row], A[sel] = A[sel], A[row]
        inv = pow(A[row][col], p - 2, p) if p > 2 else A[row][col] % p
        inv = pow(A[row][col], -1, p)
        A[row] = [(x * inv) % p for x in A[row]]
        for r in range(nrows):
            if r != row and A[r][col] % p != 0:
                fac = A[r][col]
                A[r] = [(x - fac * y) % p for x, y in zip(A[r], A[row])]
        row += 1
        if row == nrows:
            break
    ker = []
    for r in range(nrows):
        if all(A[r][c] % p == 0 for c in range(ncols)):
            ker.append([A[r][ncols + k] % p for k in range(nrows)])
    return ker


# ---------- round 2 ----------

def p_maximal(f, p, verbose=False):
    """Return (W, index) where W is a basis matrix (Fractions, rows) of the
    p-maximal order containing Z[theta], and index = [O_p : Z[theta]]."""
    n = len(f) - 1
    W = [[Fraction(1 if i == j else 0) for j in range(n)] for i in range(n)]
    total_index = 1
    k = 1
    while p ** k < n:
        k += 1
    q = p ** k
    while True:
        # elements of O in power basis
        elts = W
        # Frobenius^k map on O/pO
        rows = []
        for w in elts:
            wq = polpowmod(list(w), q, [Fraction(c) for c in f])
            c = solve_rows(W, wq)
            for x in c:
                assert x.denominator == 1, "not an order?"
            rows.append([int(x) % p for x in c])
        ker = kernel_mod_p(rows, p, n)
        # radical lattice in O-coords
        gens = [list(v) for v in ker] + [[p if i == j else 0 for j in range(n)]
                                         for i in range(n)]
        B = hnf(gens, n)   # basis of I in O-coords
        # elements of I in power basis
        Ielts = []
        for b in B:
            v = [Fraction(0)] * n
            for i in range(n):
                if b[i]:
                    for j in range(n):
                        v[j] += b[i] * W[i][j]
            Ielts.append(v)
        # map y in O/pO -> (y*b_j mod pI)_j
        rows2 = []
        for w in elts:
            row = []
            for bel in Ielts:
                prod = polmulmod(list(w), bel, [Fraction(c) for c in f])
                cO = solve_rows(W, prod)          # coords in O
                cO = [int(x) for x in cO]
                cI = solve_rows([[Fraction(x) for x in bb] for bb in B], cO)
                for x in cI:
                    assert x.denominator == 1
                row += [int(x) % p for x in cI]
            rows2.append(row)
        ker2 = kernel_mod_p(rows2, p, n * n)
        gens2 = [list(v) for v in ker2] + [[p if i == j else 0 for j in range(n)]
                                           for i in range(n)]
        L = hnf(gens2, n)
        detL = 1
        for i in range(n):
            detL *= L[i][i]
        idx = p ** n // detL
        if idx == 1:
            return W, total_index
        total_index *= idx
        # new basis: (1/p) L * W
        neW = []
        for r in L:
            v = [Fraction(0)] * n
            for i in range(n):
                if r[i]:
                    for j in range(n):
                        v[j] += Fraction(r[i], p) * W[i][j]
            neW.append(v)
        W = neW
        if verbose:
            print("  index step", idx)


def field_disc(f, verbose=False):
    """Return d_K for the field Q[x]/(f), f monic irreducible with integer coeffs."""
    D = disc(f)
    d = D
    # factor the square part
    m = abs(D)
    sq = []
    i = 2
    tmp = m
    while i * i <= tmp and i < 10 ** 7:
        if tmp % (i * i) == 0:
            sq.append(i)
            while tmp % i == 0:
                tmp //= i
        elif tmp % i == 0:
            while tmp % i == 0:
                tmp //= i
        i += 1
    if tmp > 1:
        pass  # tmp squarefree leftover (assumed)
    for p in sq:
        _, idx = p_maximal(f, p, verbose=verbose)
        if verbose:
            print("p =", p, "index", idx)
        d //= idx * idx
    return d


if __name__ == "__main__":
    import sys, json
    f = json.loads(sys.argv[1])
    print("disc(f) =", disc(f))
    print("d_K     =", field_disc(f, verbose=True))
