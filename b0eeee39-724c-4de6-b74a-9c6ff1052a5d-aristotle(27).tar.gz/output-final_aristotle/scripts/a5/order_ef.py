"""Residue degrees of the primes above p, computed inside the p-maximal order.

This works also when the field is not monogenic at p (so that no defining
polynomial has a p-maximal equation order).

Method: let O be the p-maximal order, A = O/pO, I = rad(A).  Then B = A/I is a
product of the residue fields F_{p^{f_i}}, and for the Frobenius phi(x) = x^p
on B one has dim_{F_p} ker(phi^k - 1) = sum_i gcd(k, f_i), which determines the
multiset {f_i}.
"""
from fractions import Fraction

from round2 import p_maximal, polmulmod, solve_rows, kernel_mod_p


def _mul_mod_p(u, v, W, fr, p):
    """u, v in O-coordinates mod p; return u*v in O-coordinates mod p."""
    n = len(W)
    up = [Fraction(0)] * n
    vp = [Fraction(0)] * n
    for i in range(n):
        if u[i]:
            for j in range(n):
                up[j] += u[i] * W[i][j]
        if v[i]:
            for j in range(n):
                vp[j] += v[i] * W[i][j]
    prod = polmulmod(up, vp, fr)
    c = solve_rows(W, prod)
    return [int(x) % p for x in c]


def _pow_mod_p(u, e, W, fr, p):
    n = len(W)
    r = [0] * n
    # the element 1 in O-coordinates
    one = solve_rows(W, [Fraction(1)] + [Fraction(0)] * (n - 1))
    r = [int(x) % p for x in one]
    base = list(u)
    while e:
        if e & 1:
            r = _mul_mod_p(r, base, W, fr, p)
        base = _mul_mod_p(base, base, W, fr, p)
        e >>= 1
    return r


def _rref(rows, n, p):
    A = [[x % p for x in r] for r in rows]
    piv = []
    row = 0
    for col in range(n):
        sel = None
        for r in range(row, len(A)):
            if A[r][col] % p:
                sel = r
                break
        if sel is None:
            continue
        A[row], A[sel] = A[sel], A[row]
        inv = pow(A[row][col], -1, p)
        A[row] = [(x * inv) % p for x in A[row]]
        for r in range(len(A)):
            if r != row and A[r][col] % p:
                fac = A[r][col]
                A[r] = [(x - fac * y) % p for x, y in zip(A[r], A[row])]
        piv.append(col)
        row += 1
    return A[:row], piv


def residue_degrees(f, p):
    """Sorted list of residue degrees f_i of the primes of K above p."""
    n = len(f) - 1
    fr = [Fraction(c) for c in f]
    W, _ = p_maximal(f, p)
    k = 1
    while p ** k < n:
        k += 1
    # radical
    rows = []
    for i in range(n):
        e = [0] * n
        e[i] = 1
        rows.append(_pow_mod_p(e, p ** k, W, fr, p))
    ker = kernel_mod_p(rows, p, n)
    J, piv = _rref(ker, n, p)
    free = [c for c in range(n) if c not in piv]
    m = len(free)

    def reduce_vec(v):
        v = [x % p for x in v]
        for r, c in zip(J, piv):
            if v[c] % p:
                fac = v[c]
                v = [(x - fac * y) % p for x, y in zip(v, r)]
        return [v[c] for c in free]

    lifts = []
    for c in free:
        e = [0] * n
        e[c] = 1
        lifts.append(e)
    degs = {}
    for kk in range(1, n + 1):
        rows2 = []
        for lf in lifts:
            img = _pow_mod_p(lf, p ** kk, W, fr, p)
            b = reduce_vec(img)
            b0 = reduce_vec(lf)
            rows2.append([(x - y) % p for x, y in zip(b, b0)])
        ker2 = kernel_mod_p(rows2, p, m)
        degs[kk] = len(ker2)
    # solve for the multiset {f_i} with sum_i gcd(k, f_i) = degs[k]
    import itertools
    from math import gcd
    g = degs[1]
    best = None
    for comb in itertools.combinations_with_replacement(range(1, n + 1), g):
        if sum(comb) != m:
            continue
        if all(sum(gcd(kk, fi) for fi in comb) == degs[kk]
               for kk in range(1, n + 1)):
            best = sorted(comb)
            break
    if best is None:
        raise ValueError(f"cannot determine residue degrees at p={p}: {degs}")
    return best


if __name__ == "__main__":
    import json, sys
    f = json.loads(sys.argv[1])
    for p in [int(x) for x in sys.argv[2].split(",")]:
        print(p, residue_degrees(f, p))
