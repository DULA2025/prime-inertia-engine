"""Numerical evaluation of completed Artin L-functions with gamma factor
Gamma_R(s)^n (the even case), in pure python double precision.

Setup
-----
  Lambda(s) = N^{s/2} gamma(s) L(s),   gamma(s) = (pi^{-s/2} Gamma(s/2))^n,
  Lambda(s) = eps * Lambda(1-s),  eps = +-1,  a_k real.

With Phi = inverse Mellin transform of gamma and Q = sqrt(N),

  Lambda(s) = G(s) + eps * G(1-s),
  G(w) = sum_k a_k F(w, k/Q),  F(w,y) = y^{-w} Psi(w,y),
  Psi(w,y) = int_y^infty Phi(t) t^{w-1} dt.

The identity is *equivalent* to the functional equation together with the
holomorphy of Lambda (a pole would add an explicit extra term).  Comparing the
right hand side with the absolutely convergent Dirichlet series in Re(s) > 1 is
therefore a genuine numerical test of the functional equation and of the
absence of poles.

Phi is tabulated once per degree n on a uniform grid in xi = log t by numerical
inversion of the Mellin transform on a saddle point contour; Psi is obtained
from the table by cumulative Newton-Cotes integration and 6-point interpolation.
"""

import cmath
import json
import math
import os

# ------------------------------------------------------------------ gamma

_LANCZOS = [
    676.5203681218851, -1259.1392167224028, 771.32342877765313,
    -176.61502916214059, 12.507343278686905, -0.13857109526572012,
    9.9843695780195716e-6, 1.5056327351493116e-7]


def cgamma(z):
    if z.real < 0.5:
        return math.pi / (cmath.sin(math.pi * z) * cgamma(1 - z))
    z = z - 1
    x = 0.99999999999980993
    for i, c in enumerate(_LANCZOS):
        x += c / (z + i + 1)
    t = z + 7.5
    return math.sqrt(2 * math.pi) * t ** (z + 0.5) * cmath.exp(-t) * x


def clgamma(z):
    """log Gamma (principal branch, Re z > 0)."""
    z = complex(z)
    r = 0j
    while z.real < 12:
        r -= cmath.log(z)
        z += 1
    inv = 1 / z
    inv2 = inv * inv
    s = (z - 0.5) * cmath.log(z) - z + 0.5 * math.log(2 * math.pi)
    s += inv * (1.0 / 12) - inv * inv2 * (1.0 / 360) + inv * inv2 * inv2 * (1.0 / 1260) \
        - inv * inv2 * inv2 * inv2 * (1.0 / 1680)
    return s + r


def log_gamma_factor(n, s):
    """log of (pi^{-s/2} Gamma(s/2))^n."""
    return n * (-0.5 * s * math.log(math.pi) + clgamma(0.5 * s))


# -------------------------------------------------------------------- Phi

def Phi(n, t):
    """Inverse Mellin transform of (pi^{-s/2}Gamma(s/2))^n at t > 0."""
    lt = math.log(t)
    if t >= 1.0:
        c = max(0.6, 2 * math.pi * t ** (2.0 / n))
    else:
        c = max(0.2, min(2.0, n / abs(lt)))
    h = min(0.05, 0.30 / (1.0 + abs(lt)))
    total = 0.0
    logbase = log_gamma_factor(n, complex(c, 0.0)) - c * lt
    scale = logbase.real
    u = 0.0
    k = 0
    while True:
        u = k * h
        lg = log_gamma_factor(n, complex(c, u)) - (complex(c, u)) * lt - scale
        term = cmath.exp(lg)
        w = 0.5 if k == 0 else 1.0
        total += w * term.real
        if u > max(2.0, c) and abs(term) < 1e-22:
            break
        k += 1
        if k > 200000:
            break
    return math.exp(scale) * total * h / math.pi


def phi_table(n, xi_min=-13.0, xi_max=None, M=None, cachedir="phi_cache"):
    """Table of phi(xi) = Phi(n, e^xi) on a uniform grid."""
    if xi_max is None:
        # exp(-n pi t^{2/n}) = 1e-20
        tmax = (46.0 / (n * math.pi)) ** (n / 2.0)
        xi_max = math.log(tmax)
    if M is None:
        M = int((xi_max - xi_min) / 0.002) + 1
    os.makedirs(cachedir, exist_ok=True)
    fn = os.path.join(cachedir, f"phi_n{n}_{M}_{xi_min:.2f}_{xi_max:.3f}.json")
    if os.path.exists(fn):
        with open(fn) as fh:
            d = json.load(fh)
        return d["xi_min"], d["h"], d["vals"]
    h = (xi_max - xi_min) / (M - 1)
    vals = [Phi(n, math.exp(xi_min + j * h)) for j in range(M)]
    with open(fn, "w") as fh:
        json.dump({"xi_min": xi_min, "h": h, "vals": vals}, fh)
    return xi_min, h, vals


# ------------------------------------------------------------- L-function

class LFunction:
    """Completed L-function with gamma factor Gamma_R(s)^n."""

    def __init__(self, n, N, coeffs, eps=1.0, table=None, umin=0.7, tcut=None):
        self.n = n
        self.N = N
        self.Q = math.sqrt(N)
        self.a = coeffs                      # a[0] unused, a[1] = 1
        self.eps = eps
        self.xi_min, self.h, self.phi = table if table else phi_table(n)
        self.M = len(self.phi)
        self.xi_max = self.xi_min + (self.M - 1) * self.h
        # k <= K with log(k/Q) <= xi_max
        tc = tcut if tcut else math.exp(self.xi_max)
        self.tcut = tc
        self.K = min(len(self.a) - 1, int(tc * self.Q / umin) + 1)
        self.logs = [0.0] * (self.K + 1)
        for k in range(1, self.K + 1):
            self.logs[k] = math.log(k / self.Q)

    # cumulative integral C_j = int_{xi_j}^{xi_max} phi(xi) e^{w xi} dxi
    def _cumulative(self, w):
        h = self.h
        v = [0j] * self.M
        xi = self.xi_min
        for j in range(self.M):
            v[j] = self.phi[j] * cmath.exp(w * (self.xi_min + j * h))
        C = [0j] * self.M
        # 4th order symmetric cumulative integration from the right:
        # int_{x_j}^{x_{j+1}} f = h(-f_{j-1} + 13 f_j + 13 f_{j+1} - f_{j+2})/24
        C[self.M - 1] = 0j
        for j in range(self.M - 2, -1, -1):
            if 1 <= j <= self.M - 3:
                C[j] = C[j + 1] + h * (-v[j - 1] + 13 * v[j] + 13 * v[j + 1]
                                       - v[j + 2]) / 24.0
            else:
                C[j] = C[j + 1] + 0.5 * h * (v[j] + v[j + 1])
        return C

    def _interp(self, C, xi):
        """6-point Lagrange interpolation of C at xi."""
        x = (xi - self.xi_min) / self.h
        j = int(math.floor(x)) - 2
        if j < 0:
            j = 0
        if j > self.M - 6:
            j = self.M - 6
        d = x - j
        # Lagrange on nodes 0..5
        res = 0j
        for i in range(6):
            num = 1.0
            den = 1.0
            for m in range(6):
                if m != i:
                    num *= (d - m)
                    den *= (i - m)
            res += C[j + i] * (num / den)
        return res

    def G(self, w, u=1.0):
        C = self._cumulative(w)
        lu = math.log(u)
        tot = 0j
        for k in range(1, self.K + 1):
            ak = self.a[k]
            if ak == 0:
                continue
            xi = self.logs[k]
            if xi + lu > self.xi_max:
                break
            tot += ak * cmath.exp(-w * xi) * self._interp(C, xi + lu)
        return tot

    def Lambda(self, s, u=1.0):
        """Completed L-value.  Lambda(s) = int_0^oo theta(v)v^{s-1}dv is split
        at v = u, the functional equation being applied to the part over (0,u).
        The result is mathematically independent of u, so agreement of the
        values for different u is a numerical test of the functional equation
        with the given conductor and sign."""
        s = complex(s)
        return self.G(s, u) + self.eps * self.G(1 - s, 1.0 / u)

    def Lambda_direct(self, s, terms=None):
        """N^{s/2} gamma(s) L(s) with L(s) summed directly (needs Re s > 1)."""
        s = complex(s)
        K = terms or (len(self.a) - 1)
        L = 0j
        for k in range(1, K + 1):
            if self.a[k]:
                L += self.a[k] * cmath.exp(-s * math.log(k))
        return cmath.exp(0.5 * s * math.log(self.N) + log_gamma_factor(self.n, s)) * L

    def L(self, s):
        """L(s) from the completed function."""
        s = complex(s)
        return self.Lambda(s) * cmath.exp(-0.5 * s * math.log(self.N)
                                          - log_gamma_factor(self.n, s))

    # ------------------------------------------------------------ zeros

    def theta(self, T):
        """(1/2)*arg of the gamma factor on the critical line: the smooth
        counting function is N(T) ~ (2/pi) theta(T)."""
        s = complex(0.5, T)
        return (0.5 * T * math.log(self.N) +
                log_gamma_factor(self.n, s).imag)

    def expected_zero_count(self, T):
        """Approximate number of zeros with |Im| <= T."""
        return (2.0 / math.pi) * self.theta(T)

    def critical_line_values(self, T0, T1, step):
        out = []
        t = T0
        while t <= T1 + 1e-12:
            out.append((t, self.Lambda(complex(0.5, t)).real))
            t += step
        return out

    def find_zeros(self, T0, T1, step, refine=60):
        vals = self.critical_line_values(T0, T1, step)
        zeros = []
        for i in range(len(vals) - 1):
            t0, v0 = vals[i]
            t1, v1 = vals[i + 1]
            if v0 == 0.0:
                zeros.append(t0)
            elif v0 * v1 < 0:
                a, b, fa = t0, t1, v0
                for _ in range(refine):
                    m = 0.5 * (a + b)
                    fm = self.Lambda(complex(0.5, m)).real
                    if fa * fm <= 0:
                        b = m
                    else:
                        a, fa = m, fm
                    if b - a < 1e-11:
                        break
                zeros.append(0.5 * (a + b))
        return zeros, vals
