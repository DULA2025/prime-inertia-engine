"""Numerical tests for the Artin L-functions of an A5 quintic field.

For each irreducible representation of dimension 3, 3', 4, 5 we test

  (FE)  the functional equation / holomorphy certificate:
        Lambda(s) computed from the smoothed approximate functional equation
        agrees with N^{s/2} gamma(s) L(s) computed from the (absolutely
        convergent) Dirichlet series at points with Re(s) >= 3.5;
  (SENS) the same comparison with a deliberately wrong sign or conductor,
        to show that the test really pins down (N, eps);
  (ZEROS) zeros on the critical line, and their number compared with the
        Riemann-von Mangoldt prediction (2/pi) theta(T);
  (REAL) the values of Lambda on the real segment (0,1): a real zero there
        would be an obstruction to (a strong form of) Artin's conjecture.
"""

import json
import math
import sys
import time

from field_data import FieldAnalysis, REPS
from artin import DIM
from lfunc import LFunction, phi_table


def tmax_for(n, thresh=20.0):
    return (thresh * 2.3 / (n * math.pi)) ** (n / 2.0)


def analyse_rep(F, rep, T=12.0, zstep=0.25, coeff_cap=400000, verbose=True,
                tcut=None, light=False):
    n = DIM[rep]
    N = F.conductor[rep]
    Q = math.sqrt(N)
    tab = phi_table(n)
    xi_max = tab[0] + (len(tab[2]) - 1) * tab[1]
    tc = tcut if tcut else math.exp(xi_max)
    Kterms = int(tc * Q / 0.7) + 5
    out = {"rep": rep, "dim": n, "conductor": N, "terms": Kterms,
           "tail_cut": tc}
    if Kterms > coeff_cap:
        out["skipped"] = f"needs {Kterms} coefficients (> {coeff_cap})"
        return out
    t0 = time.time()
    a = F.coefficients(rep, Kterms)
    L = LFunction(n, N, a, 1.0, tab, tcut=tc)
    out["coeff_time"] = round(time.time() - t0, 1)

    # ---------------------------------------- normalisation of coefficients
    d = L.Lambda_direct(4.0)
    v = L.Lambda(4.0)
    out["dirichlet_series_check_s4"] = {"Lambda_direct": d.real,
                                        "Lambda": v.real,
                                        "rel_err": abs(d - v) / abs(d)}

    # ------------------------------------------------------------------ FE
    pts_default = ((0.5, 1.0) if light else
                   (0.5, complex(0.5, 2.0), complex(0.5, 6.0), 1.0))

    def uspread(LL, pts=pts_default):
        """Largest disagreement between Lambda(s) computed with three different
        split points u.  Reported both relative to |Lambda(s)| (meaningless when
        s happens to sit near a zero) and, more robustly, relative to the
        overall scale |Lambda(1/2)|."""
        worst = 0.0
        worst_scaled = 0.0
        scale = abs(LL.Lambda(0.5)) or 1.0
        detail = []
        for s in pts:
            vals = [LL.Lambda(s, u) for u in (1.0, 0.75, 1.35)]
            m = max(abs(x) for x in vals)
            dev = max(abs(vals[0] - vals[1]), abs(vals[0] - vals[2]))
            e = dev / (m if m else 1.0)
            detail.append({"s": str(s), "value": [vals[0].real, vals[0].imag],
                           "rel_spread": e, "spread_over_Lambda_half": dev / scale})
            worst = max(worst, e)
            worst_scaled = max(worst_scaled, dev / scale)
        return worst_scaled, worst, detail

    worst_scaled, worst, detail = uspread(L)
    out["functional_equation"] = {
        "worst_spread_over_Lambda_half": worst_scaled,
        "worst_rel_spread_over_split_points": worst,
        "points": detail}

    # --------------------------------------------------------- sensitivity
    sens = []
    Lm = LFunction(n, N, a, -1.0, tab, tcut=tc)
    sens.append({"variant": "eps=-1",
                 "worst_spread_over_Lambda_half": uspread(Lm)[0]})
    for factor in ((4,) if light else (4, 9, 0.25)):
        L2 = LFunction(n, int(N * factor), a, 1.0, tab, tcut=tc)
        sens.append({"variant": f"N*{factor}",
                     "worst_spread_over_Lambda_half": uspread(L2)[0]})
    out["sensitivity"] = sens

    # --------------------------------------------------------------- zeros
    if light:
        out["zero_search"] = "skipped (conductor too large for this budget)"
        return out
    t0 = time.time()
    zeros, vals = L.find_zeros(0.0, T, zstep)
    out["zeros"] = [round(z, 9) for z in zeros]
    out["expected_zero_count_2T"] = L.expected_zero_count(T)
    out["zeros_found_in_0_T"] = len(zeros)
    out["Lambda_half"] = L.Lambda(0.5).real
    out["max_imag_on_critical_line"] = max(
        abs(L.Lambda(complex(0.5, t)).imag) for t in (0.3, 1.7, 4.1))
    out["zero_time"] = round(time.time() - t0, 1)

    # ----------------------------------------------------------- real axis
    real_vals = []
    sigma = 0.5
    while sigma <= 1.0001:
        real_vals.append((round(sigma, 3), L.Lambda(sigma).real))
        sigma += 0.025
    out["Lambda_real_segment"] = real_vals
    signs = set(1 if v > 0 else (-1 if v < 0 else 0) for _, v in real_vals)
    out["real_zero_in_(0,1)"] = len(signs) > 1
    out["min_abs_Lambda_real"] = min(abs(v) for _, v in real_vals)
    if verbose:
        print(json.dumps(out, indent=1)[:2000])
    return out


def analyse_field(f, reps=("3", "3b", "4", "5"), T=12.0, coeff_cap=400000,
                  X=60000):
    F = FieldAnalysis(f, X=X)
    res = F.summary()
    res["dedekind_factorisation_failures"] = F.check_dedekind_factorisation(300)
    res["reps"] = []
    for rep in reps:
        res["reps"].append(analyse_rep(F, rep, T=T, coeff_cap=coeff_cap))
    return res


if __name__ == "__main__":
    poly = json.loads(sys.argv[1])
    T = float(sys.argv[2]) if len(sys.argv) > 2 else 12.0
    cap = int(sys.argv[3]) if len(sys.argv) > 3 else 400000
    print(json.dumps(analyse_field(poly, T=T, coeff_cap=cap), indent=1))
