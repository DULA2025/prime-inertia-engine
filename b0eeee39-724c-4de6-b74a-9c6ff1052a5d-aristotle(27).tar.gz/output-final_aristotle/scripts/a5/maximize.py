"""Find a generator of an A5 quintic field whose order Z[theta] is p-maximal.

K is primitive (A4 is maximal in A5), so *every* element of K \ Q generates K.
We therefore run through elements g(theta) with g a small integer polynomial,
compute the characteristic polynomial of multiplication by g(theta) on Z[theta]
(an exact integer 5x5 matrix computation), and test Dedekind's criterion at the
primes where the original order fails to be maximal.
"""

import json
import sys
from fractions import Fraction
from math import isqrt

from ntlib import disc, dedekind_maximal, is_square, pdeg


def companion(f):
    """Matrix of multiplication by theta on Z[theta], f monic of degree n."""
    n = len(f) - 1
    C = [[0] * n for _ in range(n)]
    for i in range(1, n):
        C[i][i - 1] = 1
    for i in range(n):
        C[i][n - 1] = -f[i]
    return C


def matmul(A, B):
    n = len(A)
    return [[sum(A[i][k] * B[k][j] for k in range(n)) for j in range(n)]
            for i in range(n)]


def matadd(A, B):
    return [[A[i][j] + B[i][j] for j in range(len(A))] for i in range(len(A))]


def matscal(c, A):
    return [[c * A[i][j] for j in range(len(A))] for i in range(len(A))]


def identity(n):
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]


def charpoly(A):
    """Faddeev-LeVerrier: returns coefficients (little endian) of det(xI - A)."""
    n = len(A)
    M = identity(n)
    coeffs = [1]           # leading
    Mk = identity(n)
    c = [Fraction(1)]
    Mprev = identity(n)
    for k in range(1, n + 1):
        AM = matmul(A, Mprev)
        tr = sum(AM[i][i] for i in range(n))
        ck = Fraction(-tr, k)
        c.append(ck)
        Mprev = matadd(AM, matscal(ck, identity(n)))
    # det(xI - A) = x^n + c1 x^{n-1} + ... + cn
    out = [int(c[n - i]) for i in range(n + 1)]
    return out


def apply_poly(C, g):
    n = len(C)
    R = [[0] * n for _ in range(n)]
    P = identity(n)
    for coef in g:
        if coef:
            R = matadd(R, matscal(coef, P))
        P = matmul(C, P)
    return R


def find_maximal_poly(f, bad_primes, rng=6):
    C = companion(f)
    best = None
    for a in range(-rng, rng + 1):
        for b in range(-rng, rng + 1):
            for c2 in range(0, 3):
                for d3 in range(0, 2):
                    g = [b, a, c2, d3]
                    if c2 == 0 and d3 == 0:
                        continue
                    M = apply_poly(C, g)
                    h = charpoly(M)
                    if pdeg(h) != 5:
                        continue
                    D = disc(h)
                    if D == 0 or not is_square(D):
                        continue
                    if all(dedekind_maximal(h, p) for p in bad_primes):
                        if best is None or D < best[1]:
                            best = (h, D, g)
    return best


def bad_primes_of(f):
    D = disc(f)
    out = []
    m = D
    p = 2
    while p * p <= m:
        if m % p == 0:
            e = 0
            while m % p == 0:
                m //= p
                e += 1
            if e >= 2 and not dedekind_maximal(f, p):
                out.append(p)
        p += 1
    if m > 1 and False:
        pass
    return out


if __name__ == "__main__":
    f = json.loads(sys.argv[1])
    bp = bad_primes_of(f)
    print("poly", f, "disc", disc(f), "non-maximal at", bp)
    r = find_maximal_poly(f, bp)
    if r:
        h, D, g = r
        print("maximal generator g =", g, "min poly", h, "disc", D,
              "sqrt", isqrt(D))
    else:
        print("no maximal generator found in the search range")
