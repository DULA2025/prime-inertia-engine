"""Merge the parallel search parts into one table of fields."""

import glob
import json
import sys
from math import isqrt

from search import fingerprint, PRIMES
from ntlib import dedekind_maximal


def main(pattern, out):
    polys = []
    ntot = 0
    B = None
    for fn in glob.glob(pattern):
        try:
            d = json.load(open(fn))
        except Exception:
            print("unreadable:", fn, file=sys.stderr)
            continue
        B = d.get("B", B)
        ntot += d.get("n_totally_real_sq_disc", 0)
        for fld in d["fields"]:
            for (f, D, cert) in fld["polys"]:
                polys.append((f, D, cert))
    groups = {}
    for (f, D, cert) in polys:
        fp = fingerprint(f, D)
        g = groups.setdefault(fp, {"polys": [], "dK": None})
        g["polys"].append((f, D, cert))
        if cert and (g["dK"] is None or D < g["dK"]):
            g["dK"] = D
    fields = []
    for fp, g in groups.items():
        g["polys"].sort(key=lambda t: t[1])
        dmin = g["polys"][0][1]
        fields.append({"dK": g["dK"], "dK_certified": g["dK"] is not None,
                       "disc_poly_min": dmin,
                       "sqrt_dK": isqrt(g["dK"]) if g["dK"] else None,
                       "polys": [{"poly": p, "disc": D, "maximal_order": c}
                                 for (p, D, c) in g["polys"][:4]]})
    fields.sort(key=lambda r: (r["dK"] if r["dK"] else r["disc_poly_min"]))
    json.dump({"B": B, "n_candidates": ntot, "n_fields": len(fields),
               "fields": fields}, open(out, "w"), indent=1)
    print(f"{len(fields)} fields written to {out}")
    for r in fields[:15]:
        print(r["dK"], r["dK_certified"], r["polys"][0]["poly"])


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
