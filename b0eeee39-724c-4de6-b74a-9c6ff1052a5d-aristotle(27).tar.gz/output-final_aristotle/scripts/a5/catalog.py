"""Canonical catalogue of the smallest totally real A5 quintic fields.

Deduplicates the raw search output by Frobenius fingerprint (using only primes
that divide no polynomial discriminant in the class), keeps the polynomial of
smallest |disc|, and records the exact field discriminant, the ramification
data and the conductors of the four nontrivial Artin representations.
"""
import collections
import json
import sys

from ntlib import factor_pattern, disc
from field_data import FieldAnalysis

IN = "../../data/a5/fields_B60_exact.json"
OUT = "../../data/a5/catalog.json"


def sieve(n):
    s = [True] * (n + 1)
    s[0] = s[1] = False
    for i in range(2, int(n ** 0.5) + 1):
        if s[i]:
            for j in range(i * i, n + 1, i):
                s[j] = False
    return [i for i in range(n + 1) if s[i]]


def main(nfields=20):
    recs = json.load(open(IN))["fields"]
    P = [p for p in sieve(700) if p > 100]
    byd = collections.defaultdict(list)
    for r in recs:
        byd[r["dK"]].append(r)
    fields = []
    for dk in sorted(byd):
        grp = byd[dk]
        sigs = []
        for r in grp:
            D = disc(r["poly"])
            sigs.append({p: tuple(factor_pattern(r["poly"], p)) for p in P if D % p})
        classes = []
        for i, s in enumerate(sigs):
            placed = False
            for C in classes:
                j = C[0]
                common = set(s) & set(sigs[j])
                if all(s[p] == sigs[j][p] for p in common):
                    C.append(i)
                    placed = True
                    break
            if not placed:
                classes.append([i])
        for C in classes:
            best = min((grp[i] for i in C), key=lambda r: abs(r["disc_poly"]))
            fields.append(best)
    fields.sort(key=lambda r: (r["dK"], r["disc_poly"]))
    out = []
    for r in fields[:nfields]:
        try:
            F = FieldAnalysis(r["poly"], X=1000)
            s = F.summary()
            assert s["dK"] == r["dK"], (s["dK"], r["dK"])
            s["dedekind_factorisation_failures"] = len(
                F.check_dedekind_factorisation(300))
        except Exception as exc:                       # noqa: BLE001
            s = {"dK": r["dK"], "poly": r["poly"], "error": repr(exc)}
        out.append(s)
        print(r["dK"], r["poly"], s.get("conductors", s.get("error")),
              flush=True)
    json.dump({"n_fields_total": len(fields),
               "complete_for_dK_up_to": 15350000,
               "fields": out}, open(OUT, "w"), indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 20)
