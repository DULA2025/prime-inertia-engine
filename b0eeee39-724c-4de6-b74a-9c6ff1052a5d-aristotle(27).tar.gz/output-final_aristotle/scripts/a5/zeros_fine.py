import json, sys, math, time
from field_data import FieldAnalysis
from lfunc import LFunction, phi_table
from artin import DIM

poly = json.loads(sys.argv[1]); rep = sys.argv[2]
T = float(sys.argv[3]); step = float(sys.argv[4]); out = sys.argv[5]
F = FieldAnalysis(poly, X=1000)
n = DIM[rep]; N = F.conductor[rep]
tab = phi_table(n); xi_max = tab[0] + (len(tab[2])-1)*tab[1]
tc = math.exp(xi_max)
K = int(tc*math.sqrt(N)/0.7)+5
a = F.coefficients(rep, K)
L = LFunction(n, N, a, 1.0, tab, tcut=tc)
t0=time.time()
zeros, vals = L.find_zeros(0.0, T, step)
res = {"poly": poly, "rep": rep, "conductor": N, "T": T, "step": step,
       "zeros": [round(z,10) for z in zeros], "count": len(zeros),
       "riemann_von_mangoldt_count_0_T": L.theta(T)/math.pi + 1.0,
       "values": [(round(t,4), v) for t, v in vals],
       "time": round(time.time()-t0,1)}
json.dump(res, open(out,"w"), indent=1)
print(rep, len(zeros), res["riemann_von_mangoldt_count_0_T"], res["time"])
