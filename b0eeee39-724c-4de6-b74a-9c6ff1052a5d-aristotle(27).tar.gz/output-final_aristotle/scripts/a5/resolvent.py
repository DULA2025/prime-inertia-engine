"""Degree-10 resolvent of a quintic: the polynomial whose roots are the sums
r_i + r_j of pairs of distinct roots.

It is used to resolve the local ambiguities that the quintic field alone cannot
see.  Concretely, for a wildly ramified prime with inertia V4 the quintic
splitting type is the same whether the decomposition group is V4 or A4, but the
two cases give different residue degrees in the degree-10 resolvent algebra
(1,1,1,1 versus 3,1) and hence different Euler factors for rho_5.

The resolvent is first computed in floating point from the real roots and then
*certified exactly*: with f2(x) = prod_i (x - 2 r_i) one has the polynomial
identity

    Res_y( f(y), f(x-y) ) = f2(x) * R10(x)^2      (degree 25 in x),

which we verify at 26 distinct integers, thereby proving it.
"""
from fractions import Fraction

from ntlib import resultant, real_roots, disc, pmul


def _f2(f):
    """prod_i (x - 2 r_i) = 2^5 f(x/2)."""
    n = len(f) - 1
    return [f[k] * 2 ** (n - k) for k in range(n + 1)]


def resolvent10(f, certify=True):
    """Monic integer polynomial of degree 10 with roots r_i + r_j (i<j)."""
    r = real_roots(f)
    assert len(r) == 5, "expected a totally real quintic"
    sums = [r[i] + r[j] for i in range(5) for j in range(i + 1, 5)]
    coeffs = [1.0]
    for s in sums:
        nc = [0.0] * (len(coeffs) + 1)
        for i, c in enumerate(coeffs):
            nc[i + 1] += c
            nc[i] -= c * s
        coeffs = nc
    R = [int(round(c)) for c in coeffs]
    err = max(abs(c - round(c)) for c in coeffs)
    assert err < 0.2, f"rounding error {err} too large"
    assert R[10] == 1
    if certify:
        f2 = _f2(f)
        for x0 in range(-13, 13):
            lhs = resultant(f, [f[k] * (-1) ** k for k in range(len(f))]
                            if False else _shift(f, x0))
            rhs = _peval(f2, x0) * _peval(R, x0) ** 2
            assert lhs == rhs, (x0, lhs, rhs)
    return R


def _shift(f, x0):
    """coefficients of y -> f(x0 - y)."""
    n = len(f) - 1
    out = [0] * (n + 1)
    # f(x0 - y) = sum_k f_k (x0 - y)^k
    for k in range(n + 1):
        if f[k] == 0:
            continue
        # (x0 - y)^k
        c = [0] * (k + 1)
        b = 1
        for j in range(k + 1):
            # binomial(k,j) x0^{k-j} (-y)^j
            c[j] = b * x0 ** (k - j) * (-1) ** j
            b = b * (k - j) // (j + 1)
        for j in range(k + 1):
            out[j] += f[k] * c[j]
    return out


def _peval(c, x):
    v = 0
    for a in reversed(c):
        v = v * x + a
    return v


if __name__ == "__main__":
    import json
    import sys
    f = json.loads(sys.argv[1])
    R = resolvent10(f)
    print("R10 =", R)
    print("disc(R10) != 0:", disc(R) != 0)
