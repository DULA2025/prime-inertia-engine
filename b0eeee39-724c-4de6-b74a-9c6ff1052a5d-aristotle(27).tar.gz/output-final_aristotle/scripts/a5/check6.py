"""Diagnostic: test the functional equation of the degree-6 L-function
L(rho_3) * L(rho_3'), whose Euler factors are rational and do not depend on the
separation of the two classes of 5-cycles.  If this test passes while the
individual degree-3 tests fail, the discrepancy lies in the 5A/5B separation.
"""
import json
import math
import sys

from field_data import FieldAnalysis
from lfunc import LFunction, phi_table


def main(poly):
    F = FieldAnalysis(poly, X=1000)
    N = F.conductor["3"] * F.conductor["3b"]
    n = 6
    tab = phi_table(n)
    xi_max = tab[0] + (len(tab[2]) - 1) * tab[1]
    tc = math.exp(xi_max)
    Q = math.sqrt(N)
    K = int(tc * Q / 0.7) + 5
    print("N =", N, "terms =", K)

    # multiply the two Euler factors prime by prime
    orig = F.euler_factor

    def ef6(rep, p):
        a = orig("3", p)
        b = orig("3b", p)
        out = [0.0] * (len(a) + len(b) - 1)
        for i, x in enumerate(a):
            for j, y in enumerate(b):
                out[i + j] += x * y
        return out

    F.euler_factor = ef6
    a = F.coefficients("3x3b", K)
    L = LFunction(n, N, a, 1.0, tab, tcut=tc)
    d = L.Lambda_direct(4.0)
    v = L.Lambda(4.0)
    print("dirichlet check", abs(d - v) / abs(d))
    for s in (0.5, complex(0.5, 2.0), 1.0):
        vals = [L.Lambda(s, u) for u in (1.0, 0.75, 1.35)]
        m = max(abs(x) for x in vals)
        e = max(abs(vals[0] - vals[1]), abs(vals[0] - vals[2])) / m
        print(s, vals[0], "rel spread", e)


if __name__ == "__main__":
    main(json.loads(sys.argv[1]))
