#!/bin/bash
# Run the full numerical analysis for a list of fields in parallel.
# usage: run_batch.sh <njobs> <file with one "dK polynomial" per line>
cd "$(dirname "$0")"
N=${1:-7}
LIST=${2:-fields_batch.txt}
mkdir -p /tmp/a5logs
while read -r dk poly; do
  [ -z "$dk" ] && continue
  echo "$dk|$poly"
done < "$LIST" | xargs -P "$N" -I{} bash -c '
  entry="{}"; dk="${entry%%|*}"; poly="${entry#*|}"
  python3 run_one.py "$poly" ../../data/a5/field_${dk}.json 3,3b,4,5 10 \
      > /tmp/a5logs/${dk}.log 2>&1
  echo "done $dk"
'
echo BATCHDONE
