import math, sys
sys.path.insert(0,'/workspace/request-project/scripts')
from sharp import piece_bracket_sharp
from analyze2 import req, cosbracket
def vBP(q): return 2*math.log(q)

def make_partition(q_end, base=0.06, near1=0.0008):
    """adaptive: near q=1 use small steps (Phi varies fast), else phase-limited"""
    pts=[1.0]; q=1.0
    while q<q_end:
        dq_phase = 0.06/(2*math.pi*2*q)      # 2*pi*dr <= 0.06
        dq_var = near1*(1+ (q-1)*60)          # grow away from 1
        dq=min(dq_phase,dq_var,0.02*q)
        q=min(q+dq,q_end); pts.append(q)
    return list(zip(pts[:-1],pts[1:]))

def build(partition):
    ps=[]
    for q0,q1 in partition:
        Lo,Hi,bm=piece_bracket_sharp(q0,q1)
        w=1/q0-1/q1; M=max(abs(Lo),abs(Hi))
        ps.append(dict(q0=q0,q1=q1,P0=2*Lo*w,P1=2*Hi*w,S=2*M*w))
    return ps

def group_budget(pieces,t0,t1,budget):
    """greedy: extend block while estimated loss h*S <= budget"""
    groups=[];cur=[]
    for p in pieces:
        trial=cur+[p]
        a=vBP(trial[0]['q0']); b=vBP(trial[-1]['q1'])
        C,h=cosbracket(t0*a,t1*b)
        S=sum(x['S'] for x in trial)
        if h*S>budget and cur: groups.append(cur); cur=[p]
        else: cur=trial
    if cur: groups.append(cur)
    return groups

def eta(pieces,t0,t1,budget,tail):
    gs=group_budget(pieces,t0,t1,budget); tot=0
    for g in gs:
        a=vBP(g[0]['q0']); b=vBP(g[-1]['q1'])
        P0=sum(x['P0'] for x in g); P1=sum(x['P1'] for x in g); S=sum(x['S'] for x in g)
        C,h=cosbracket(t0*a,t1*b)
        tot+=min(C*P0,C*P1)-h*S
    return tot-tail,len(gs)

if __name__=='__main__':
    qc=3.0
    part=make_partition(qc); ps=build(part)
    print('npieces',len(ps),'sumS %.5f'%sum(p['S'] for p in ps),'spread/2 %.5f'%sum((p['P1']-p['P0'])/2 for p in ps))
    print('sum v*S %.5f'%sum(vBP((p['q0']+p['q1'])/2)*p['S'] for p in ps))
    tl=0.0035
    for t0 in [3.0,4.0,5.0]:
        for dt in [0.03125,0.0625,0.125,0.25,0.5]:
            for budget in [2e-5,5e-5,1e-4]:
                e,n=eta(ps,t0,t0+dt,budget,tl)
                print('t0=%.2f dt=%.4f bud=%.0e nblk=%4d eta=%+.5f req=%+.5f margin=%+.5f'%(t0,dt,budget,n,e,req(t0,t0+dt),e-req(t0,t0+dt)))
        print()
