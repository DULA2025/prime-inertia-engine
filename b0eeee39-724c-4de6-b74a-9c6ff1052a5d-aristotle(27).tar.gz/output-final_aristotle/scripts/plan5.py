"""Greedy band planner for the linear-phase-correction scheme.

Walks down from t = 5.5 choosing, at each step, the widest admissible band, and
reports the total number of (band x block) lemmas needed to reach a given threshold.
"""
import math, sys
sys.path.insert(0, '/workspace/request-project/scripts')
from plan4 import build, group_phase, eta_lin, req, rng, cos_crit, sin_crit, min4, max4
from analyze2 import vBP


def block_data2(g):
    a = g[0]['a']; b = g[-1]['b']; mid = (a + b) / 2
    cands = [g[0]['a']] + [x['b'] for x in g]
    m = min(cands, key=lambda x: abs(x - mid))
    P0 = sum(x['P0'] for x in g); P1 = sum(x['P1'] for x in g)
    S = sum(x['S'] for x in g)
    R0 = R1 = 0.0
    for x in g:
        w = 1 / x['q0'] - 1 / x['q1']
        W = 2 * (x['a'] + 2) / x['q0'] - 2 * (x['b'] + 2) / x['q1']
        K = W - 2 * m * w
        R0 += min(x['Lo'] * K, x['Hi'] * K); R1 += max(x['Lo'] * K, x['Hi'] * K)
    d = max(b - m, m - a)
    return dict(a=a, b=b, m=m, P0=P0, P1=P1, R0=R0, R1=R1, S=S, S2=d * d * S, S3=d ** 3 * S)


def eta_tail(B, t0, t1, tail):
    return eta_lin(B, t0, t1, tail)


def plan(B, tail, tstop=1.0, safety=0.0005,
         widths=(0.5, 0.25, 0.125, 0.0625, 0.03125, 0.015625)):
    t1 = 5.5
    bands = []
    while t1 > tstop + 1e-9:
        ok = None
        for dt in widths:
            t0 = t1 - dt
            if t0 < tstop - 1e-12:
                continue
            if eta_tail(B, t0, t1, tail) - req(t0, t1) > safety:
                ok = dt; break
        if ok is None:
            # try to land exactly on tstop with the smallest width
            break
        bands.append((t1 - ok, t1))
        t1 -= ok
    return bands, t1


if __name__ == '__main__':
    ps = build(True)
    for phimax in [0.15, 0.2, 0.25, 0.35, 0.5]:
        gs = group_phase(ps, 5.5, phimax); B = [block_data2(g) for g in gs]
        for tail in [0.013709, 0.007, 0.004]:
            bands, tmin = plan(B, tail)
            print('phimax=%.2f nblk=%3d tail=%.5f  -> threshold %.4f, %d bands, %d block-lemmas'
                  % (phimax, len(B), tail, tmin, len(bands), len(bands) * len(B)))
        print()
