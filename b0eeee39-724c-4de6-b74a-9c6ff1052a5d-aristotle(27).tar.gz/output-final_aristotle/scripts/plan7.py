"""Planner variant: allow merging consecutive raw pieces (keeping the quadrant
constraint) to reduce the number of generated Lean lemmas."""
import sys, math
sys.path.insert(0, '/workspace/request-project/scripts')
from fractions import Fraction as F
from gen import (quadrant, trig_from_quadrant, sharp_bracket, crude_bracket, rd, ru,
                 vbp_bracket, cosLoP, cosHiP, sinLoP, sinHiP, QUAD)
from analyze2 import pieces as rawpieces
import plan6
from plan6 import mn4, mx4, point_trig, theta, req, TAIL


def merged_pieces(maxmerge, maxdr):
    """Merge consecutive raw pieces of the same kind while the merged r-range still
    fits in one quadrant, at most `maxmerge` pieces and r-width <= maxdr."""
    out = []
    i = 0
    n = len(rawpieces)
    while i < n:
        best = None
        for k in range(1, maxmerge + 1):
            if i + k > n:
                break
            grp = rawpieces[i:i + k]
            if any(g['kind'] != grp[0]['kind'] for g in grp):
                break
            q0 = F(str(grp[0]['q0'])); q1 = F(str(grp[-1]['q1']))
            if q1**2 - q0**2 > maxdr:
                break
            qd = quadrant(q0**2, q1**2)
            if qd is None:
                break
            best = (q0, q1, grp[0]['kind'], qd, k)
        if best is None:
            q0 = F(str(rawpieces[i]['q0'])); q1 = F(str(rawpieces[i]['q1']))
            out.append(dict(q0=q0, q1=q1, kind=rawpieces[i]['kind'], trig=None))
            i += 1
            continue
        q0, q1, kind, qd, k = best
        out.append(dict(q0=q0, q1=q1, kind=kind, trig=qd))
        i += k
    # finalise brackets
    res = []
    for p in out:
        q0, q1 = p['q0'], p['q1']
        if p['trig'] is None:
            Lo, Hi = crude_bracket(q0, q1, p['kind'])
            trig = None
        else:
            K, j, u0, u1 = p['trig']
            C = trig_from_quadrant(K, u0, u1)
            Cr = (rd(C[0], 9), ru(C[1], 9), rd(C[2], 9), ru(C[3], 9))
            Lo, Hi = sharp_bracket(q0, q1, p['kind'], Cr[0], Cr[1], Cr[2], Cr[3])
            trig = (K, j, u0, u1, Cr)
        res.append(dict(q0=q0, q1=q1, kind=p['kind'], Lo=rd(Lo, 8), Hi=ru(Hi, 8), trig=trig))
    return res


def install(pieces):
    plan6.PIECES = pieces
    QS = [pieces[0]['q0']] + [p['q1'] for p in pieces]
    VBR = {}
    for q in QS:
        VBR[q] = (F(0), F(0)) if q == 1 else vbp_bracket(q, 9)
    plan6.VBR = VBR
    plan6.QS = QS


def scan(maxmerge, maxdr, phimaxes=(F('0.25'),), tail=TAIL):
    P = merged_pieces(maxmerge, F(str(maxdr)))
    ncrude = sum(1 for p in P if p['trig'] is None)
    spread = sum((p['Hi'] - p['Lo']) * (1 / p['q0'] - 1 / p['q1']) for p in P)
    print('maxmerge=%d maxdr=%s -> %d pieces (%d crude), total spread/2 = %.6f'
          % (maxmerge, maxdr, len(P), ncrude, float(spread)))
    install(P)
    for phimax in phimaxes:
        blocks = plan6.make_blocks(phimax)
        print('   phimax=%s -> %d blocks' % (phimax, len(blocks)))
        for t0f in ['3.0', '3.5', '4.0', '4.5', '5.0', '5.5']:
            t0 = F(t0f); row = []
            for dtf in ['0.0625', '0.125']:
                dt = F(dtf); t1 = t0 + dt
                e = plan6.eta(blocks, t0, t1, tail)
                row.append('dt=%s m=%s' % (dtf, ('None' if e is None
                                                 else '%+.5f' % float(e - req(t0, t1)))))
            print('      t0=%s ' % t0f + ' | '.join(row))


if __name__ == '__main__':
    for mm, md in [(1, 1.0), (2, 0.2), (3, 0.2), (4, 0.2), (6, 0.2), (8, 0.2)]:
        scan(mm, md)
