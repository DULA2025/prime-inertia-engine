"""Exact planner for the linear-phase-correction scheme, using the same rational
arithmetic as the generated Lean code."""
import sys, math
sys.path.insert(0, '/workspace/request-project/scripts')
from fractions import Fraction as F
from gen import (quadrant, trig_from_quadrant, sharp_bracket, crude_bracket, rd, ru, dec, lit,
                 vbp_bracket, cosLoP, cosHiP, sinLoP, sinHiP, QUAD)
from analyze2 import pieces as rawpieces

PI_LO = F('3.14159265358979323846')
PI_HI = F('3.14159265358979323847')

TAIL = F('0.013709')


def mn4(x0, x1, y0, y1): return min(x0*y0, x0*y1, x1*y0, x1*y1)
def mx4(x0, x1, y0, y1): return max(x0*y0, x0*y1, x1*y0, x1*y1)


def build_pieces():
    out = []
    for p in rawpieces:
        q0, q1 = F(str(p['q0'])), F(str(p['q1']))
        qd = quadrant(q0**2, q1**2)
        if qd is None:
            Lo, Hi = crude_bracket(q0, q1, p['kind'])
            trig = None
        else:
            K, j, u0, u1 = qd
            C = trig_from_quadrant(K, u0, u1)
            Cr = (rd(C[0], 9), ru(C[1], 9), rd(C[2], 9), ru(C[3], 9))
            Lo, Hi = sharp_bracket(q0, q1, p['kind'], Cr[0], Cr[1], Cr[2], Cr[3])
            trig = (K, j, u0, u1, Cr)
        Lo, Hi = rd(Lo, 8), ru(Hi, 8)
        out.append(dict(q0=q0, q1=q1, kind=p['kind'], Lo=Lo, Hi=Hi, trig=trig))
    return out


PIECES = build_pieces()
# breakpoints: q values, with rational brackets for vBP q
QS = [PIECES[0]['q0']] + [p['q1'] for p in PIECES]
VBR = {}
for q in QS:
    VBR[q] = (F(0), F(0)) if q == 1 else vbp_bracket(q, 9)


def piece_data(p, m0, m1):
    """P0,P1,R0,R1,S for one piece with base point m in [m0,m1] outside the piece."""
    q0, q1, Lo, Hi = p['q0'], p['q1'], p['Lo'], p['Hi']
    A0, A1 = VBR[q0]; B0, B1 = VBR[q1]
    w = 1/q0 - 1/q1
    P0, P1 = 2*Lo*w, 2*Hi*w
    S = 2*max(-Lo, Hi)*w
    Klo = 2*(A0 + 2 - m1)/q0 - 2*(B1 + 2 - m0)/q1
    Khi = 2*(A1 + 2 - m0)/q0 - 2*(B0 + 2 - m1)/q1
    Klo, Khi = rd(Klo, 12), ru(Khi, 12)
    return P0, P1, mn4(Lo, Hi, Klo, Khi), mx4(Lo, Hi, Klo, Khi), S


def make_blocks(phimax, tref=F('5.5')):
    """group consecutive pieces so that tref*(b-a) <= phimax"""
    groups, cur = [], []
    for i, p in enumerate(PIECES):
        trial = cur + [i]
        a = VBR[PIECES[trial[0]]['q0']][0]
        b = VBR[PIECES[trial[-1]]['q1']][1]
        if tref*(b-a) > phimax and cur:
            groups.append(cur); cur = [i]
        else:
            cur = trial
    if cur: groups.append(cur)
    blocks = []
    for g in groups:
        qa = PIECES[g[0]]['q0']; qb = PIECES[g[-1]]['q1']
        a = VBR[qa][0]; b = VBR[qb][1]
        mid = (a + b) / 2
        cands = [PIECES[i]['q1'] for i in g[:-1]] + [qa]
        qm = min(cands, key=lambda q: abs((VBR[q][0]+VBR[q][1])/2 - mid))
        m0, m1 = VBR[qm]
        P0 = P1 = R0 = R1 = S = F(0)
        for i in g:
            p0, p1, r0, r1, s = piece_data(PIECES[i], m0, m1)
            P0 += p0; P1 += p1; R0 += r0; R1 += r1; S += s
        d = max(m1 - VBR[qa][0], VBR[qb][1] - m0)
        blocks.append(dict(g=g, qa=qa, qb=qb, qm=qm, m0=m0, m1=m1,
                           P0=rd(P0, 10), P1=ru(P1, 10), R0=rd(R0, 10), R1=ru(R1, 10),
                           S=ru(S, 10), d=ru(d, 8)))
    return blocks


def point_trig(X0):
    """rigorous rational (K, j, ylo, yhi, c0,c1,s0,s1) for cos/sin at the rational X0>=0."""
    x = float(X0)
    tp = float(2*PI_LO)
    j = int(math.floor(x / tp))
    y = x - j*tp
    K = min(3, int(y / (float(PI_LO)/2)))
    ylo = rd(X0 - j*2*PI_HI - K*PI_HI/2, 12)
    yhi = ru(X0 - j*2*PI_LO - K*PI_LO/2, 12)
    if ylo < 0 or yhi > QUAD:
        return None
    a, b = ylo, yhi
    if K == 0:
        c0, c1, s0, s1 = cosLoP(b), cosHiP(a), sinLoP(a), sinHiP(b)
    elif K == 1:
        c0, c1, s0, s1 = -sinHiP(b), -sinLoP(a), cosLoP(b), cosHiP(a)
    elif K == 2:
        c0, c1, s0, s1 = -cosHiP(a), -cosLoP(b), -sinHiP(b), -sinLoP(a)
    else:
        c0, c1, s0, s1 = sinLoP(a), sinHiP(b), -cosHiP(a), -cosLoP(b)
    return (K, j, ylo, yhi, rd(c0, 10), ru(c1, 10), rd(s0, 10), ru(s1, 10))


def band_block(B, t0, t1):
    """rational data for one block on one band; returns dict or None"""
    X0 = rd(t0 * B['m0'], 9)
    W = ru(t1 * B['m1'] - X0, 7)
    if W < 0 or W > F('1.5'):
        return None
    pt = point_trig(X0)
    if pt is None:
        return None
    K, j, ylo, yhi, c0, c1, s0, s1 = pt
    cw, sw = cosLoP(W), sinHiP(W)
    ulo = rd(mn4(c0, c1, cw, F(1)) - mx4(s0, s1, F(0), sw), 10)
    uhi = ru(mx4(c0, c1, cw, F(1)) - mn4(s0, s1, F(0), sw), 10)
    vlo = rd(mn4(s0, s1, cw, F(1)) + mn4(c0, c1, F(0), sw), 10)
    vhi = ru(mx4(s0, s1, cw, F(1)) + mx4(c0, c1, F(0), sw), 10)
    zlo = mn4(t0, t1, vlo, vhi); zhi = mx4(t0, t1, vlo, vhi)
    L = (mn4(ulo, uhi, B['P0'], B['P1']) - mx4(zlo, zhi, B['R0'], B['R1'])
         - (t1**2/2)*B['d']**2*B['S'] - (t1**3/6)*B['d']**3*B['S'])
    return dict(X0=X0, W=W, K=K, j=j, ylo=ylo, yhi=yhi, c0=c0, c1=c1, s0=s0, s1=s1,
                ulo=ulo, uhi=uhi, vlo=vlo, vhi=vhi, L=rd(L, 10))


def eta(blocks, t0, t1, tail=TAIL):
    tot = F(0)
    for B in blocks:
        d = band_block(B, t0, t1)
        if d is None:
            return None
        tot += d['L']
    return tot - tail


def theta(t):
    return sum((t*t/4)/((F(n)+F(1,4))*((F(n)+F(1,4))**2 + t*t/4)) for n in range(80))


def req(a, b):
    return -(theta(a) - F('5.37221') + 1/(F(1,4)+b*b) + F('12.66')/(9+b*b))/2


if __name__ == '__main__':
    for phimax in [F('0.25'), F('0.35'), F('0.5'), F('0.7')]:
        blocks = make_blocks(phimax)
        print('=== phimax %s -> %d blocks' % (phimax, len(blocks)))
        for t0f in ['1.5', '2.0', '2.5', '3.0', '3.5', '4.0', '4.5', '5.0', '5.5']:
            t0 = F(t0f); row = []
            for dtf in ['0.0625', '0.125', '0.25']:
                dt = F(dtf); t1 = t0 + dt
                e = eta(blocks, t0, t1)
                row.append('dt=%s m=%s' % (dtf, ('None' if e is None
                                                 else '%+.5f' % float(e - req(t0, t1)))))
            print('   t0=%s ' % t0f + ' | '.join(row))
