#!/usr/bin/env python3
"""Regenerate the figures of `RequestProject/REPO_INVENTORY.md`.

Conventions (the same ones the inventory documents):

* a *declaration* is a line beginning in column 0 with one of
  `def theorem lemma instance abbrev structure class inductive`, optionally preceded by
  attributes (`@[...]`) and by modifiers such as `noncomputable`, `private`, `protected`,
  `partial`, `nonrec`, `unsafe`, `scoped`, `open ... in` is *not* stripped;
* comments (`-- ...`, `/- ... -/`, including `/-! ... -/`) are removed before counting,
  so declarations and `sorry`s occurring inside comments are not counted.

Usage: python3 scripts/inventory.py [--table]
"""

import os
import re
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir)
SRC = os.path.join(ROOT, "RequestProject")

KINDS = ["def", "theorem", "lemma", "instance", "abbrev", "structure", "class", "inductive"]
MODIFIERS = {"noncomputable", "private", "protected", "partial", "nonrec", "unsafe", "scoped",
             "local", "mutual"}
DECL_RE = re.compile(r"^(?:@\[[^\]]*\]\s*)*((?:\w+\s+)*)(" + "|".join(KINDS) + r")\b")


def strip_comments(text: str) -> str:
    out = []
    i, n, depth = 0, len(text), 0
    while i < n:
        if text.startswith("/-", i):
            depth += 1
            i += 2
        elif text.startswith("-/", i) and depth:
            depth -= 1
            i += 2
        elif depth:
            out.append("\n" if text[i] == "\n" else " ")
            i += 1
        elif text.startswith("--", i):
            j = text.find("\n", i)
            if j < 0:
                break
            i = j
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def analyse(path):
    raw = open(path, encoding="utf-8").read()
    code = strip_comments(raw)
    lines = raw.count("\n") + (0 if raw.endswith("\n") else 1)
    kinds = {}
    for line in code.splitlines():
        m = DECL_RE.match(line)
        if not m:
            continue
        mods = m.group(1).split()
        if mods and not set(mods) <= MODIFIERS:
            continue
        kinds[m.group(2)] = kinds.get(m.group(2), 0) + 1
    sorries = len(re.findall(r"\bsorry\b", code))
    return lines, kinds, sorries


FAMILIES = [
    ("PolyaLinBand", "RequestProject/PolyaLinBand*.lean"),
    ("PolyaLinBlocks", "RequestProject/PolyaLinBlocks*.lean"),
    ("PolyaLinPieces", "RequestProject/PolyaLinPieces*.lean"),
    ("PolyaLinVbp", "RequestProject/PolyaLinVbp*.lean"),
    ("PolyaLowBand", "RequestProject/PolyaLowBand*.lean"),
    ("PolyaLowBlocks", "RequestProject/PolyaLowBlocks*.lean"),
    ("PolyaLowPieces", "RequestProject/PolyaLowPieces*.lean"),
    ("PolyaLowVbp", "RequestProject/PolyaLowVbp*.lean"),
    ("PolyaOscBand", "RequestProject/PolyaOscBand*.lean"),
    ("PolyaOscBlocks", "RequestProject/PolyaOscBlocks*.lean"),
    ("PolyaPartition", "RequestProject/PolyaPartition*.lean"),
]


def family_of(name):
    for prefix, pattern in FAMILIES:
        if name.startswith(prefix) and name[len(prefix):].rstrip("0123456789") == "":
            return prefix, pattern
    return None, None


def main():
    files = sorted(f for f in os.listdir(SRC) if f.endswith(".lean"))
    rows, groups = [], {}
    tot_lines = tot_decls = tot_sorry = 0
    files_with_sorry = []
    for f in files:
        name = f[:-5]
        lines, kinds, sorries = analyse(os.path.join(SRC, f))
        decls = sum(kinds.values())
        tot_lines += lines
        tot_decls += decls
        tot_sorry += sorries
        if sorries:
            files_with_sorry.append(f)
        fam, pattern = family_of(name)
        if fam:
            g = groups.setdefault(fam, [pattern, 0, 0, {}, 0])
            g[1] += 1
            g[2] += lines
            for k, v in kinds.items():
                g[3][k] = g[3].get(k, 0) + v
            g[4] += sorries
        else:
            rows.append((f"RequestProject/{f}", lines, kinds, sorries))
    for fam, (pattern, count, lines, kinds, sorries) in groups.items():
        rows.append((f"{pattern} ({count} files)", lines, kinds, sorries))
    rows.sort(key=lambda r: r[0])

    def breakdown(kinds):
        return ", ".join(f"{k} {v}" for k, v in sorted(kinds.items())) or "—"

    if "--table" in sys.argv:
        print("| File | Lines | Declarations | Breakdown | Sorries |")
        print("|---|---:|---|---|---:|")
        for name, lines, kinds, sorries in rows:
            print(f"| `{name}` | {lines} | {sum(kinds.values())} | {breakdown(kinds)} | {sorries} |")
    print(f"modules       : {len(files)}")
    print(f"lines         : {tot_lines}")
    print(f"declarations  : {tot_decls}")
    print(f"sorries (code): {tot_sorry} {files_with_sorry}")


if __name__ == "__main__":
    main()
