"""Generate a refined certified quadrature for the head integral
`∫_1^{49/25} gMinus` of RequestProject/DeltaFourierZero.lean."""
import math
from fractions import Fraction as F

PLO = {1: F('9.8696'), 2: F('97.408'), 3: F('961.38'), 4: F('9488.4'),
       5: F('93646'), 6: F('924248'), 7: F('9121950')}
PHI = {1: F('9.8697'), 2: F('97.41'), 3: F('961.41'), 4: F('9488.9'),
       5: F('93653'), 6: F('924333'), 7: F('9123090')}


def coeffs(a, b, s):
    """coefficients c_k of pi^{2k} in (siDivIntPart 8 (2pi) C (b-1)
       - siDivIntPart 8 (2pi) C (a-1))/(2 s^3)."""
    C = 3 * s * s - 1
    out = []
    for k in range(8):
        base = F((-1) ** k * 4 ** k, (2 * k + 1) * math.factorial(2 * k + 1))

        def g(u):
            return C * u ** (2 * k + 1) / (2 * k + 1) - u ** (2 * k + 2) / (2 * k + 2)
        out.append(base * (g(b - 1) - g(a - 1)) / (2 * s ** 3))
    return out


def lower(a, b, s):
    c = coeffs(a, b, s)
    tot = c[0]
    for k in range(1, 8):
        tot += c[k] * (PLO[k] if c[k] > 0 else PHI[k])
    return tot


def rd(x, nd):
    sc = F(10) ** nd
    return F(math.floor(x * sc)) / sc


def dec(x, nd=None):
    if nd is None:
        d = x.denominator
        n2 = n5 = 0
        while d % 2 == 0:
            d //= 2; n2 += 1
        while d % 5 == 0:
            d //= 5; n5 += 1
        assert d == 1, x
        nd = max(n2, n5)
    v = x * F(10) ** nd
    assert v.denominator == 1
    v = int(v)
    sg = '-' if v < 0 else ''
    v = abs(v)
    t = str(v).rjust(nd + 1, '0')
    return sg + (t if nd == 0 else t[:-nd] + '.' + t[-nd:])


def frac(x):
    return '%d/%d' % (x.numerator, x.denominator) if x.denominator != 1 else str(x.numerator)


def build(npc):
    B = F(49, 25)
    pts = [1 + (B - 1) * F(i, npc) for i in range(npc + 1)]
    rows = []
    tot = F(0)
    for i in range(npc):
        a, b = pts[i], pts[i + 1]
        mid = (a + b) / 2
        s = F(round(float(mid) ** 0.5 * 10 ** 5), 10 ** 5)
        assert b <= 3 * s * s
        L = rd(lower(a, b, s), 6)
        tot += L
        rows.append((a, b, s, L))
    return rows, tot


if __name__ == '__main__':
    import sys
    npc = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    rows, tot = build(npc)
    print('-- total = %s  (%.6f)' % (dec(tot), float(tot)))
    body = []
    for i, (a, b, s, L) in enumerate(rows):
        body.append(
            '  have n%d : (%s:ℝ) ≤ ∫ r in (%s:ℝ)..(%s), gMinus r := by\n'
            '    refine le_trans ?_ (integral_head_piece_ge (a := %s) (b := %s) (s := %s)\n'
            '      (by norm_num) (by norm_num) (by norm_num) (by norm_num))\n'
            '    simp only [siDivIntPart, Finset.sum_range_succ, Finset.sum_range_zero]\n'
            '    norm_num [Nat.factorial]\n'
            '    linarith\n'
            % (i, dec(L), frac(a), frac(b), frac(a), frac(b), frac(s)))
    for i in range(1, npc):
        body.append(
            '  have s%d := intervalIntegral.integral_add_adjacent_intervals\n'
            '    (intervalIntegrable_gMinus (a := 1) (b := %s) one_pos (by norm_num))\n'
            '    (intervalIntegrable_gMinus (a := %s) (b := %s) (by norm_num) (by norm_num))\n'
            % (i, frac(rows[i][0]), frac(rows[i][0]), frac(rows[i][1])))
    print(''.join(body) + '  linarith\n')
