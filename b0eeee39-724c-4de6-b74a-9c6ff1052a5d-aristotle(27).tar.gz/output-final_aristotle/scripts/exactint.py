"""Numerical study of the exact-integration variant of the block estimate.

E(t) = int_0^infty err(v) cos(t v) dv.
We compute the *true* value of the truncated integral M(t) = int_0^{vcut} err cos(tv) dv
and compare with the requirement req(t) coming from the theta side.
"""
import math

PI = math.pi

def Si(x):
    # Simpson on [0,x] of sin(u)/u
    if x == 0.0:
        return 0.0
    n = max(200, int(x * 200))
    if n % 2:
        n += 1
    h = x / n
    s = 1.0  # u=0 -> sinc=1
    for i in range(1, n):
        u = i * h
        w = 4 if i % 2 else 2
        s += w * math.sin(u) / u
    s += math.sin(x) / x
    return s * h / 3

def siDiv(a):
    return 1.0 if a == 0 else Si(a) / a

def PhiErr(v):
    e = math.exp(v)
    return 2 * e * (siDiv(2 * PI * (1 + e)) + siDiv(2 * PI * (e - 1))) - 1 - 2.11 * math.exp(-2.5 * v)

def errFun(v):
    return math.exp(-v / 2) * PhiErr(v)

VCUT = 2 * math.log(2.094)

# precompute err on a fine grid in q (uniform in q gives uniform-ish phase 2 pi q^2 spacing? use r=q^2)
NG = 40000
GRID = []
for i in range(NG + 1):
    v = VCUT * i / NG
    GRID.append((v, errFun(v)))

def M(t):
    h = VCUT / NG
    s = 0.0
    for i, (v, e) in enumerate(GRID):
        w = 1 if i in (0, NG) else (4 if i % 2 else 2)
        s += w * e * math.cos(t * v)
    return s * h / 3

def theta(t):
    return sum((t * t / 4) / ((n + 0.25) * ((n + 0.25) ** 2 + t * t / 4)) for n in range(80))

def req(t):
    return -(theta(t) - 5.37221 + 1 / (0.25 + t * t) + 12.66 / (9 + t * t)) / 2

if __name__ == '__main__':
    print('vcut =', VCUT)
    print('%6s %10s %10s %10s %10s' % ('t', 'M(t)', 'req(t)', 'marg_cur', 'marg_sharp'))
    t = 1.0
    while t <= 6.001:
        m = M(t)
        r = req(t)
        print('%6.2f %10.5f %10.5f %10.5f %10.5f' % (t, m, r, m - 0.039 - 0.0137 - r, m - 0.009 - 0.0068 - r))
        t += 0.25
