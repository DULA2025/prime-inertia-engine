import re, math
from fractions import Fraction as F

FILES = ['RequestProject/PolyaOscBlocks%d.lean'%i for i in (1,2,3,4)]

def load_blocks(root='/workspace/request-project/'):
    txt = ''.join(open(root+f).read() for f in FILES)
    parts = re.split(r'theorem oscBlock(\d+) : errIntBracket \(vBP ([0-9.]+)\) \(vBP ([0-9.]+)\) \(([-0-9.]+)\) \(([-0-9.]+)\) ([0-9.]+) :=', txt)
    blocks = []
    # parts[0] preamble; then groups of 7
    for i in range(1, len(parts), 7):
        n = int(parts[i]); q0=float(parts[i+1]); q1=float(parts[i+2])
        P0=float(parts[i+3]); P1=float(parts[i+4]); S=float(parts[i+5])
        body = parts[i+6]
        pieces = []
        for m in re.finditer(r'errPiece_(taylor|asymp) \(q0 := ([0-9.]+)\) \(q1 := ([0-9.]+)\) \(Lo := \(?(-?[0-9.]+)\)?\) \(Hi := \(?(-?[0-9.]+)\)?\) \(M := ([0-9.]+)\)', body):
            kind, a,b,Lo,Hi,M = m.group(1), float(m.group(2)), float(m.group(3)), float(m.group(4)), float(m.group(5)), float(m.group(6))
            pieces.append(dict(kind=kind,q0=a,q1=b,Lo=Lo,Hi=Hi,M=M))
        blocks.append(dict(n=n,q0=q0,q1=q1,P0=P0,P1=P1,S=S,pieces=pieces))
    return blocks

def piece_int(p):
    """returns (P0,P1,S) integral bracket for the piece"""
    w = 1.0/p['q0'] - 1.0/p['q1']
    return (2*p['Lo']*w, 2*p['Hi']*w, 2*p['M']*w)

def vBP(q): return 2*math.log(q)

if __name__ == '__main__':
    bl = load_blocks()
    print('blocks', len(bl), 'pieces', sum(len(b['pieces']) for b in bl))
    tot0=tot1=totS=0
    for b in bl:
        for p in b['pieces']:
            a,c,s = piece_int(p); tot0+=a; tot1+=c; totS+=s
    print('sum P0 %.6f  sum P1 %.6f  sum S %.6f'%(tot0,tot1,totS))
    # check block consistency
    for b in bl[:3]:
        s0=sum(piece_int(p)[0] for p in b['pieces']); s1=sum(piece_int(p)[1] for p in b['pieces']); ss=sum(piece_int(p)[2] for p in b['pieces'])
        print(b['n'], b['P0'], s0, b['P1'], s1, b['S'], ss)
