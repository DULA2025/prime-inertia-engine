"""Generator for the low-frequency bands `0.18 <= t <= 1.8`.

Two new ingredients compared with `emit.py`:

* the partition is extended from `q = 2.094` to `q = 5` with quadrant-resolved pieces,
  so that the unresolved tail costs `0.0022` instead of `0.013709`;
* the band criterion is `fourierSide_nonneg_band_sharp` (first poles cancelled), which
  costs only `P(a) - P(b)` per band instead of `M(a) - M(b)`.
"""
import sys, os, math
sys.path.insert(0, '/workspace/request-project/scripts')
from fractions import Fraction as F
from gen import (quadrant, trig_from_quadrant, sharp_bracket, crude_bracket, rd, ru, dec, lit,
                 vbp_bracket, cosLoP, cosHiP, sinLoP, sinHiP, QUAD, siLoSharp,
                 TPLO, TPHI)
import plan6
from plan6 import (PIECES, VBR, QS, band_block, point_trig, mn4, mx4, piece_data)

ROOT = '/workspace/request-project/RequestProject'

QCUT = F('2.094')      # end of the existing partition
QEND = F('5')          # end of the extended partition
TAIL = F('0.0022')     # bound for the L1 mass beyond q = QEND (proved in PolyaLowTail)

# --------------------------------------------------------------- 1. tail pieces
def make_tail_pieces(qstart=QCUT, qend=QEND):
    out = []
    q = qstart
    while q < qend:
        r = q * q
        k = math.floor(float(r) * 4) + 1
        rb = F(k, 4)
        qb_f = math.sqrt(float(rb))
        qa = rd(F(qb_f) - F('0.0000005'), 7)
        while qa * qa >= rb:
            qa -= F(1, 10 ** 7)
        if qa >= qend:
            out.append((q, qend))
            break
        if qa > q:
            out.append((q, qa))
        qc = ru(F(qb_f) + F('0.0000005'), 7)
        while qc * qc <= rb:
            qc += F(1, 10 ** 7)
        out.append((qa, min(qc, qend)))
        q = qc
    pieces = []
    for (q0, q1) in out:
        qd = quadrant(q0 ** 2, q1 ** 2)
        if qd is None:
            Lo, Hi = crude_bracket(q0, q1, 'asymp')
            trig = None
        else:
            K, j, u0, u1 = qd
            C = trig_from_quadrant(K, u0, u1)
            Cr = (rd(C[0], 9), ru(C[1], 9), rd(C[2], 9), ru(C[3], 9))
            Lo, Hi = sharp_bracket(q0, q1, 'asymp', *Cr)
            # side conditions of errPiece_sharp_asymp
            for (X0, X1) in ((TPLO * (1 + q0 ** 2), TPHI * (1 + q1 ** 2)),
                             (TPLO * (q0 ** 2 - 1), TPHI * (q1 ** 2 - 1))):
                assert 1 / X1 - 2 / X0 ** 3 >= 0, (q0, q1)
                assert 1 / X1 ** 2 - 6 / X0 ** 4 >= 0, (q0, q1)
                assert siLoSharp(X0, X1, Cr[1], Cr[3]) >= 0, (q0, q1)
            trig = (K, j, u0, u1, Cr)
        pieces.append(dict(q0=q0, q1=q1, kind='asymp', Lo=rd(Lo, 8), Hi=ru(Hi, 8), trig=trig))
    return pieces


TAILP = make_tail_pieces()
ALLP = PIECES + TAILP

# breakpoints of the extended partition, with their Lean names
TQS = [p['q1'] for p in TAILP]
NAME = {}
for i, q in enumerate(QS):
    NAME[q] = 'vbpP%d' % i
for i, q in enumerate(TQS):
    NAME[q] = 'vbpT%d' % i
def vbp_bracket_n(q, n, nd=9):
    x = (q - 1) / q
    s = sum(x ** (i + 1) / (i + 1) for i in range(n))
    err = x ** (n + 1) / (1 - x)
    return rd(2 * (s - err), nd), ru(2 * (s + err), nd)


def adaptive_n(q, tol=F('0.0002'), nmax=70):
    x = (q - 1) / q
    for n in range(8, nmax + 1):
        if 4 * x ** (n + 1) / (1 - x) <= tol:
            return n
    return nmax


VBRL = dict(VBR)
NBR = {}
for q in TQS:
    n = adaptive_n(q)
    NBR[q] = n
    VBRL[q] = vbp_bracket_n(q, n)
PNAME = {}
for i in range(len(PIECES)):
    PNAME[i] = 'errPt%d' % i
for i in range(len(TAILP)):
    PNAME[len(PIECES) + i] = 'errPtT%d' % i


# --------------------------------------------------------------- 2. blocks
def piece_data_l(p, m0, m1):
    q0, q1, Lo, Hi = p['q0'], p['q1'], p['Lo'], p['Hi']
    A0, A1 = VBRL[q0]
    B0, B1 = VBRL[q1]
    w = 1 / q0 - 1 / q1
    P0, P1 = 2 * Lo * w, 2 * Hi * w
    S = 2 * max(-Lo, Hi) * w
    Klo = 2 * (A0 + 2 - m1) / q0 - 2 * (B1 + 2 - m0) / q1
    Khi = 2 * (A1 + 2 - m0) / q0 - 2 * (B0 + 2 - m1) / q1
    Klo, Khi = rd(Klo, 12), ru(Khi, 12)
    return P0, P1, mn4(Lo, Hi, Klo, Khi), mx4(Lo, Hi, Klo, Khi), S


CHUNK = 30


def make_blocks_low(phimax, tref=F('1.8')):
    groups, cur = [], []
    for i, p in enumerate(ALLP):
        trial = cur + [i]
        a = VBRL[ALLP[trial[0]]['q0']][0]
        b = VBRL[ALLP[trial[-1]]['q1']][1]
        if tref * (b - a) > phimax and cur:
            groups.append(cur)
            cur = [i]
        else:
            cur = trial
    if cur:
        groups.append(cur)
    blocks = []
    for g in groups:
        qa = ALLP[g[0]]['q0']
        qb = ALLP[g[-1]]['q1']
        a = VBRL[qa][0]
        b = VBRL[qb][1]
        mid = (a + b) / 2
        cands = [ALLP[i]['q1'] for i in g[:-1]] + [qa]
        qm = min(cands, key=lambda q: abs((VBRL[q][0] + VBRL[q][1]) / 2 - mid))
        m0, m1 = VBRL[qm]
        chunks = [g[i:i + CHUNK] for i in range(0, len(g), CHUNK)]
        cdata = []
        for c in chunks:
            P0 = P1 = R0 = R1 = S = F(0)
            for i in c:
                p0, p1, r0, r1, s = piece_data_l(ALLP[i], m0, m1)
                P0 += p0; P1 += p1; R0 += r0; R1 += r1; S += s
            cdata.append(dict(g=c, P0=rd(P0, 10), P1=ru(P1, 10), R0=rd(R0, 10),
                              R1=ru(R1, 10), S=ru(S, 10)))
        P0 = sum(c['P0'] for c in cdata); P1 = sum(c['P1'] for c in cdata)
        R0 = sum(c['R0'] for c in cdata); R1 = sum(c['R1'] for c in cdata)
        S = sum(c['S'] for c in cdata)
        d = max(m1 - VBRL[qa][0], VBRL[qb][1] - m0)
        blocks.append(dict(g=g, chunks=cdata, qa=qa, qb=qb, qm=qm, m0=m0, m1=m1,
                           P0=rd(P0, 10), P1=ru(P1, 10), R0=rd(R0, 10), R1=ru(R1, 10),
                           S=ru(S, 10), d=ru(d, 8)))
    return blocks


def eta(blocks, t0, t1, tail=TAIL):
    tot = F(0)
    for B in blocks:
        d = band_block(B, t0, t1)
        if d is None:
            return None
        tot += d['L']
    return tot - tail


# --------------------------------------------------------------- 3. requirement
def thn(n, t):
    c = F(n) + F(1, 4)
    return 1 / c - c / (c * c + t * t / 4)


def Ppair(t):
    return F(4, 5) - 5 / (F(25, 4) + t * t) + F('12.66') / (9 + t * t)


def req(a, b):
    """lower bound needed for eta on the band [a,b] with the sharp criterion"""
    s = sum(thn(n, a) for n in range(2, 80))
    return -(4 - F('5.37221') + Ppair(b) + s) / 2


DTS = [F('0.25'), F('0.1875'), F('0.125'), F('0.09375'), F('0.0625'), F('0.046875'),
       F('0.03125'), F('0.015625'), F('0.0078125')]


def plan_bands(blocks, tstart=F('0.18'), tend=F('1.8'), margin=F('0.0002')):
    t = F(tstart)
    out = []
    while t < tend:
        chosen = None
        for dt in DTS:
            t1 = min(t + dt, tend)
            if t1 <= t:
                continue
            e = eta(blocks, t, t1)
            if e is not None and e - req(t, t1) >= margin:
                chosen = (t1, e - req(t, t1), e)
                break
        if chosen is None:
            return None, out, t
        out.append((t, chosen[0], chosen[2], chosen[1]))
        t = chosen[0]
    return True, out, t


if __name__ == '__main__':
    print('tail pieces: %d (%d sharp, %d crude)'
          % (len(TAILP), sum(1 for p in TAILP if p['trig']),
             sum(1 for p in TAILP if not p['trig'])))
    P0 = sum(2 * p['Lo'] * (1 / p['q0'] - 1 / p['q1']) for p in TAILP)
    print('tail signed P0 sum: %.6f' % float(P0))
    for pm in ['0.25', '0.125']:
        bl = make_blocks_low(F(pm))
        print('phimax %s -> %d blocks' % (pm, len(bl)))
        for tf in ['0.18', '0.25', '0.5', '0.75', '1.0', '1.25', '1.5', '1.75']:
            t = F(tf)
            e = eta(bl, t, t)
            print('   t=%s pointwise margin %s' % (tf, 'None' if e is None
                                                   else '%+.5f' % float(e - req(t, t))))
        ok, lst, stuck = plan_bands(bl)
        if ok:
            print('   BANDS OK: %d bands' % len(lst))
            for (a, b, e, m) in lst:
                print('      [%s,%s] eta=%+.6f margin=%+.6f' % (a, b, float(e), float(m)))
        else:
            print('   FAILS at %s after %d bands' % (stuck, len(lst)))


# =============================================================== emission
HEAD = """/-
Copyright (c) 2026. All rights reserved.
Released under Apache 2.0 license.
-/
%s

/-!
%s
-/

set_option maxHeartbeats 4000000

noncomputable section

open MeasureTheory Set Real

namespace ConnesConsani.WeilPositivity

"""

FOOT = "\nend ConnesConsani.WeilPositivity\n"


def write(name, imports, doc, body):
    with open(os.path.join(ROOT, name + '.lean'), 'w') as f:
        f.write(HEAD % ('\n'.join('import ' + i for i in imports), doc))
        f.write(body)
        f.write(FOOT)


def emit_vbp_tail(nfiles=2):
    lines = []
    for i, q in enumerate(TQS):
        lo, hi = VBRL[q]
        lines.append(
            'theorem vbpT%d : (%s:ℝ) ≤ vBP %s ∧ vBP %s ≤ %s := by\n'
            '  have h := vBP_bracket %d (q := %s) (by norm_num)\n'
            '  norm_num [Finset.sum_range_succ, abs_le] at h\n'
            '  constructor <;> linarith [h.1, h.2]\n'
            % (i, dec(lo), dec(q), dec(q), dec(hi), NBR[q], dec(q)))
    names = []
    per = (len(lines) + nfiles - 1) // nfiles
    for k in range(nfiles):
        chunk = lines[k * per:(k + 1) * per]
        if not chunk:
            continue
        nm = 'PolyaLowVbp%d' % (k + 1)
        write(nm, ['RequestProject.PolyaOscLin'],
              '# Rational brackets for the breakpoints of the extended partition (part %d)\n\n'
              'The extended partition reaches `q = 5`, where the logarithmic series converges\n'
              'slowly, so the number of terms is chosen breakpoint by breakpoint.' % (k + 1),
              '\n'.join(chunk))
        names.append(nm)
    return names


def piece_proof_tail(i, p):
    q0, q1, Lo, Hi = p['q0'], p['q1'], p['Lo'], p['Hi']
    head = 'theorem errPtT%d : errPtBracket %s %s %s %s :=\n' % (i, dec(q0), dec(q1),
                                                                 lit(Lo), lit(Hi))
    if p['trig'] is None:
        return head + ('  errPiece_crude_asymp (by norm_num) (by norm_num) (by norm_num)\n'
                       '    (by norm_num) (by norm_num)\n')
    K, j, u0, u1, Cr = p['trig']
    C0, C1, S0, S1 = Cr
    trig = ('    (fun r hr0 hr1 => trigBracket%d (u0 := %s) (u1 := %s) (j := (%d:ℤ))\n'
            '      (by norm_num) (by norm_num)\n'
            '      (by push_cast; linarith) (by push_cast; linarith)\n'
            '      (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])'
            ' (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])\n'
            '      (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])'
            ' (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP]))\n'
            % (K, dec(u0), dec(u1), j))
    named = ('    (C0 := %s) (C1 := %s) (S0 := %s) (S1 := %s)\n'
             % (lit(C0), lit(C1), lit(S0), lit(S1)))
    return (head + '  errPiece_sharp_asymp\n' + named
            + '    (by norm_num) (by norm_num)\n' + trig
            + '    (by norm_num) (by norm_num) (by norm_num [siLoSharp])\n'
            + '    (by norm_num) (by norm_num) (by norm_num [siLoSharp])\n'
            + '    (by norm_num [aLoSharp, bLoSharp, siLoSharp])\n'
            + '    (by norm_num [aHiSharp, bHiSharp, siHiSharp])\n')


def emit_pieces_tail(nfiles=4):
    lines = [piece_proof_tail(i, p) for i, p in enumerate(TAILP)]
    names = []
    per = (len(lines) + nfiles - 1) // nfiles
    for k in range(nfiles):
        chunk = lines[k * per:(k + 1) * per]
        if not chunk:
            continue
        nm = 'PolyaLowPieces%d' % (k + 1)
        write(nm, ['RequestProject.PolyaOscLin'],
              '# Pointwise brackets on the pieces of the extended partition (part %d)\n\n'
              'The `q`-range `[2.094, 5]` is cut at the quadrant boundaries of `2πq²`, so that\n'
              'the oscillating part of the Si-asymptotics is resolved and the bracket is\n'
              'narrow; the short pieces straddling a boundary use the crude bracket.' % (k + 1),
              '\n'.join(chunk))
        names.append(nm)
    return names


COARSE = [F('5'), F('5.5'), F('6'), F('7'), F('9'), F('13.5')]


def emit_far_tail():
    from gen import sharp_bracket as sb
    lines, hs, ss, tot = [], [], [], F(0)
    for i in range(len(COARSE) - 1):
        q0, q1 = COARSE[i], COARSE[i + 1]
        Lo, Hi = sb(q0, q1, 'asymp', F(-1), F(1), F(-1), F(1))
        Lo, Hi = rd(Lo, 8), ru(Hi, 8)
        M = ru(max(-Lo, Hi), 8)
        tot += 2 * M * (1 / q0 - 1 / q1)
        lines.append(
            'theorem errPtC%d : errPtBracket %s %s %s %s :=\n'
            '  errPiece_sharp_asymp (C0 := (-1)) (C1 := 1) (S0 := (-1)) (S1 := 1)\n'
            '    (by norm_num) (by norm_num)\n'
            '    (fun r _ _ => ⟨neg_one_le_cos _, cos_le_one _, neg_one_le_sin _, sin_le_one _⟩)\n'
            '    (by norm_num) (by norm_num) (by norm_num [siLoSharp])\n'
            '    (by norm_num) (by norm_num) (by norm_num [siLoSharp])\n'
            '    (by norm_num [aLoSharp, bLoSharp, siLoSharp])\n'
            '    (by norm_num [aHiSharp, bHiSharp, siHiSharp])\n'
            % (i, dec(q0), dec(q1), lit(Lo), lit(Hi)))
        hs.append(
            '  have e%d := (errIntBracket_of_pointwise (q0 := %s) (q1 := %s) (M := %s)\n'
            '    (by norm_num) (by norm_num) errPtC%d (by norm_num) (by norm_num)).2.2\n'
            % (i, dec(q0), dec(q1), dec(M), i))
        ss.append(
            '  have s%d := integral_Ioi_abs_errFun_split (a := vBP %s) (b := vBP %s)\n'
            '    (vBP_nonneg (by norm_num)) (vBP_mono (by norm_num) (by norm_num))\n'
            % (i, dec(q0), dec(q1)))
    tot = ru(tot + F('0.000498'), 6)
    assert tot <= TAIL, tot
    n = len(COARSE) - 1
    body = ''.join(lines) + (
        '/-- The `L¹` mass of the model error beyond the extended cut `q = 5`.  The pieces\n'
        'up to `q = 13.5` use the sharp Si-asymptotics with the trivial bounds `|cos|,|sin| ≤ 1`,\n'
        'and beyond `13.5` the crude tail estimate is enough. -/\n'
        'theorem integral_Ioi_abs_errFun_tail_five :\n'
        '    (∫ v in Ioi (vBP 5), |errFun v|) ≤ %s := by\n' % dec(TAIL)
        + ''.join(hs)
        + '  have et := integral_tail_le (q0 := 13.5) (M := 0.00336)\n'
          '    (by norm_num) (by norm_num) (by norm_num) (by norm_num)\n'
        + ''.join(ss)
        + '  rw [%s]\n' % ', '.join('s%d' % i for i in range(n))
        + '  norm_num at %s et ⊢\n' % ' '.join('e%d' % i for i in range(n))
        + '  linarith\n')
    write('PolyaLowTail', ['RequestProject.PolyaPartition3', 'RequestProject.PolyaOscLin'],
          '# The unresolved tail of the extended partition\n\n'
          'Beyond `q = 5` the absolute-value estimate is retained, but with the sharp\n'
          'Si-asymptotics it costs only `%s` instead of the `0.013709` of the cut at\n'
          '`q = 2.094`.' % dec(TAIL), body)
    return 'PolyaLowTail'


def emit_blocks_low(blocks, deps, nfiles=4):
    out = []
    for k, B in enumerate(blocks):
        mname = NAME[B['qm']]
        names = []
        for j, C in enumerate(B['chunks']):
            hs = []
            for n, i in enumerate(C['g']):
                p = ALLP[i]
                A0, A1 = VBRL[p['q0']]
                B0, B1 = VBRL[p['q1']]
                m0, m1 = B['m0'], B['m1']
                Klo = rd(2 * (A0 + 2 - m1) / p['q0'] - 2 * (B1 + 2 - m0) / p['q1'], 12)
                Khi = ru(2 * (A1 + 2 - m0) / p['q0'] - 2 * (B0 + 2 - m1) / p['q1'], 12)
                sgn = ('Or.inl' if B['qm'] <= p['q0'] else 'Or.inr')
                hs.append(
                    '  have h%d := errBlockLin_of_piece (q0 := %s) (q1 := %s) (m := vBP %s)\n'
                    '    (Lo := %s) (Hi := %s) (Klo := %s) (Khi := %s)\n'
                    '    (by norm_num) (by norm_num) (by norm_num) %s\n'
                    '    %s.1 %s.2 %s.1 %s.2 %s.1 %s.2\n'
                    '    (%s (vBP_mono (by norm_num) (by norm_num))) (by norm_num) (by norm_num)\n'
                    % (n, dec(p['q0']), dec(p['q1']), dec(B['qm']), lit(p['Lo']), lit(p['Hi']),
                       lit(Klo), lit(Khi), PNAME[i],
                       NAME[p['q0']], NAME[p['q0']], NAME[p['q1']], NAME[p['q1']], mname, mname,
                       sgn))
            chain = 'h0'
            for n in range(1, len(C['g'])):
                chain = '(%s.add h%d)' % (chain, n)
            nm = 'blkLo%d_%d' % (k, j)
            names.append(nm)
            out.append(
                'theorem %s : errBlockLin (vBP %s) (vBP %s) (vBP %s) %s %s %s %s %s := by\n'
                % (nm, dec(ALLP[C['g'][0]]['q0']), dec(ALLP[C['g'][-1]]['q1']), dec(B['qm']),
                   lit(C['P0']), lit(C['P1']), lit(C['R0']), lit(C['R1']), lit(C['S']))
                + ''.join(hs)
                + '  exact %s.mono (by norm_num) (by norm_num) (by norm_num [mn4])\n'
                  '    (by norm_num [mx4]) (by norm_num)\n' % chain)
        chain = names[0]
        for nm in names[1:]:
            chain = '(errBlockLin.add %s %s)' % (chain, nm)
        out.append(
            'theorem blkLo%d : errBlockLin (vBP %s) (vBP %s) (vBP %s) %s %s %s %s %s :=\n'
            '  errBlockLin.mono %s (by norm_num) (by norm_num) (by norm_num) (by norm_num)\n'
            '    (by norm_num)\n'
            % (k, dec(B['qa']), dec(B['qb']), dec(B['qm']), lit(B['P0']), lit(B['P1']),
               lit(B['R0']), lit(B['R1']), lit(B['S']), chain))
    fnames = []
    tot = sum(len(x.split('\n')) for x in out)
    chunks, cur, curn = [], [], 0
    for x in out:
        cur.append(x); curn += len(x.split('\n'))
        if x.startswith('theorem blkLo') and ' : errBlockLin' in x.split('\n')[0] \
                and '_' not in x.split(' ')[1]:
            if curn >= tot / nfiles and len(chunks) < nfiles - 1:
                chunks.append(cur); cur, curn = [], 0
    if cur:
        chunks.append(cur)
    for k, chunk in enumerate(chunks):
        nm = 'PolyaLowBlocks%d' % (k + 1)
        imports = ['RequestProject.' + d for d in deps] if k == 0 \
            else ['RequestProject.PolyaLowBlocks%d' % k]
        write(nm, imports,
              '# The block data for the low-frequency bands (part %d)\n\n'
              'Blocks of the extended partition `q ∈ [1,5]`, grouped so that the phase `tv`\n'
              'varies by at most `0.25` across a block for `t ≤ 1.8`; long blocks are assembled\n'
              'from sub-blocks of at most 30 pieces.' % (k + 1),
              '\n'.join(chunk))
        fnames.append(nm)
    return fnames


def emit_band_low(b, deps, blocks, t0, t1):
    data = [band_block(B, t0, t1) for B in blocks]
    assert all(d is not None for d in data)
    tot = sum(d['L'] for d in data)
    out = []
    for k, (B, d) in enumerate(zip(blocks, data)):
        na, nb, nm_ = NAME[B['qa']], NAME[B['qb']], NAME[B['qm']]
        out.append(
            'theorem cosLBL%d_%d {t : ℝ} (ht0 : (%s:ℝ) ≤ t) (ht1 : t ≤ %s) :\n'
            '    (%s:ℝ) ≤ ∫ v in (vBP %s)..(vBP %s), errFun v * Real.cos (t * v) := by\n'
            '  have hp := trigPoint%d (X := %s) (ylo := %s) (yhi := %s) (j := (%d:ℤ))\n'
            '    (c0 := %s) (c1 := %s) (s0 := %s) (s1 := %s)\n'
            '    (by norm_num) (by linarith [Real.pi_gt_d20])\n'
            '    (by push_cast; linarith [Real.pi_gt_d20, Real.pi_lt_d20])\n'
            '    (by push_cast; linarith [Real.pi_gt_d20, Real.pi_lt_d20])\n'
            '    (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])'
            ' (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])\n'
            '    (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])'
            ' (by norm_num [cosLoP, cosHiP, sinLoP, sinHiP])\n'
            '  have hm := mul_mem_of_bracket (t0 := %s) (t1 := %s) (X0 := %s) (W := %s)\n'
            '    ht0 ht1 %s.1 %s.2 (by norm_num) (by norm_num) (by norm_num) (by norm_num)\n'
            '  have hs := trig_shift_bracket (W := %s) (by norm_num) (by norm_num) hm.1 hm.2\n'
            '    hp.1 hp.2.1 hp.2.2.1 hp.2.2.2\n'
            '  exact errCos_block_ge_lin (t0 := %s) (t1 := %s) (d := %s)\n'
            '    (ulo := %s) (uhi := %s) (vlo := %s) (vhi := %s)\n'
            '    (vBP_mono (by norm_num) (by norm_num)) (by norm_num)\n'
            '    (by linarith [%s.1, %s.2]) (by linarith [%s.2, %s.1])\n'
            '    ht0 ht1 (by norm_num) blkLo%d\n'
            '    (le_trans (by norm_num [mn4, mx4, cosLoP, sinHiP]) hs.1)\n'
            '    (le_trans hs.2.1 (by norm_num [mn4, mx4, cosLoP, sinHiP]))\n'
            '    (le_trans (by norm_num [mn4, mx4, cosLoP, sinHiP]) hs.2.2.1)\n'
            '    (le_trans hs.2.2.2 (by norm_num [mn4, mx4, cosLoP, sinHiP]))\n'
            '    (by norm_num [mn4, mx4])\n'
            % (b, k, dec(t0), dec(t1), lit(d['L']), dec(B['qa']), dec(B['qb']),
               d['K'], dec(d['X0']), dec(d['ylo']), dec(d['yhi']), d['j'],
               lit(d['c0']), lit(d['c1']), lit(d['s0']), lit(d['s1']),
               dec(t0), dec(t1), dec(d['X0']), dec(d['W']), nm_, nm_,
               dec(d['W']), dec(t0), dec(t1), dec(B['d']),
               lit(d['ulo']), lit(d['uhi']), lit(d['vlo']), lit(d['vhi']),
               na, nm_, nb, nm_, k))
    n = len(blocks)
    chain = ('(errCos_add_ge ' * (n - 1)) + '(cosLBL%d_0 ht0 ht1)\n' % b
    for k in range(1, n):
        chain += '    (cosLBL%d_%d ht0 ht1))' % (b, k) + ('\n' if k < n - 1 else '')
    eta_val = rd(tot - TAIL, 10)
    out.append(
        '/-- Lower bound for `∫₀^∞ err(v) cos(tv) dv` on the band `%s ≤ t ≤ %s`. -/\n'
        'theorem oscLowBand%d {t : ℝ} (ht0 : (%s:ℝ) ≤ t) (ht1 : t ≤ %s) :\n'
        '    (%s:ℝ) ≤ ∫ v in Ioi (0:ℝ), errFun v * Real.cos (t * v) := by\n'
        '  have hsum := %s\n'
        '  rw [vBP_one] at hsum\n'
        '  have hsplit := integral_Ioi_errFun_cos_split t (c := vBP 5)'
        ' (vBP_nonneg (by norm_num))\n'
        '  have htail := abs_integral_Ioi_errFun_cos_le (t := t) (c := vBP 5) (S := %s)\n'
        '    (vBP_nonneg (by norm_num)) integral_Ioi_abs_errFun_tail_five\n'
        '  rw [abs_le] at htail\n'
        '  rw [hsplit]\n'
        '  linarith [hsum, htail.1]\n'
        % (dec(t0), dec(t1), b, dec(t0), dec(t1), lit(eta_val), chain, dec(TAIL)))
    nm = 'PolyaLowBand%d' % b
    write(nm, ['RequestProject.PolyaLowTail'] + ['RequestProject.' + d for d in deps],
          '# Oscillatory lower bound on the band `%s ≤ t ≤ %s`\n\n'
          'The partition now reaches `q = 5`; on each block the phase `tv` is linearised at\n'
          'the base point and the signed contributions are summed.'
          % (dec(t0), dec(t1)),
          '\n'.join(out))
    return nm, eta_val


def emit_threshold_low(bandlist, deps):
    """bandlist : list of (b, t0, t1)"""
    body = ['/-- **The Fourier-side inequality on the remaining band `0.18 ≤ |t| ≤ 1.8`.**\n'
            'Together with `fourierSide_nonneg_of_lin_threshold` this covers every `|t| ≥ 0.18`.'
            ' -/\n'
            'theorem fourierSide_nonneg_of_low_threshold {t : ℝ} (ht : (0.18:ℝ) ≤ |t|) :\n'
            '    0 ≤ fourierSide t := by\n'
            '  rcases le_or_gt 1.8 |t| with hb | hb\n'
            '  · exact fourierSide_nonneg_of_lin_threshold hb\n'
            '  rw [← fourierSide_abs t]\n']
    rev = list(reversed(bandlist))
    prevname = 'hb'
    for n, (b, t0, t1) in enumerate(rev):
        last = (n == len(rev) - 1)
        if last:
            body.append(
                '  · refine fourierSide_nonneg_band_sharp (a := %s) (b := %s) (by norm_num) ht'
                ' %s.le\n'
                '      (oscLowBand%d ht %s.le) ?_\n'
                '    simp only [thetaSeriesTerm, poleAbscissa]\n'
                '    norm_num [Finset.sum_Ico_succ_top]\n' % (dec(t0), dec(t1), prevname, b,
                                                              prevname))
        else:
            nm = 'g%d' % n
            body.append(
                '  rcases le_or_gt %s |t| with %s | %s\n'
                '  · refine fourierSide_nonneg_band_sharp (a := %s) (b := %s) (by norm_num) %s'
                ' %s.le\n'
                '      (oscLowBand%d %s %s.le) ?_\n'
                '    simp only [thetaSeriesTerm, poleAbscissa]\n'
                '    norm_num [Finset.sum_Ico_succ_top]\n'
                % (dec(t0), nm, nm, dec(t0), dec(t1), nm, prevname, b, nm, prevname))
            prevname = nm
    body.append(
        '\n/-- **The Fourier-side inequality, unconditionally**: `2θ\'(t) + δ̂(t) ≥ 0` for every\n'
        'real `t`.  Near the origin (`|t| ≤ 0.18`) this is `fourierSide_nonneg_of_abs_le`, and\n'
        'beyond that it is the band argument. -/\n'
        'theorem fourierSide_nonneg (t : ℝ) : 0 ≤ fourierSide t := by\n'
        '  rcases le_or_gt |t| 0.18 with h | h\n'
        '  · exact fourierSide_nonneg_of_abs_le h\n'
        '  · exact fourierSide_nonneg_of_low_threshold h.le\n'
        '\n/-- **Corollary 2.3 (ii) of the paper**: the Fourier transform `2θ\' + δ̂` of the\n'
        'distribution defining `L = D + W_∞` is nonnegative. -/\n'
        'theorem two_thetaDeriv_add_deltaFourier_nonneg (t : ℝ) :\n'
        '    0 ≤ 2 * thetaDeriv t + deltaFourier t := fourierSide_nonneg t\n')
    write('PolyaLowThreshold',
          ['RequestProject.PolyaLinThreshold', 'RequestProject.NearOrigin',
           'RequestProject.PolyaLowBase'] + ['RequestProject.' + d for d in deps],
          '# The low-frequency threshold: the Fourier-side inequality for every `t`\n\n'
          'The bands of `RequestProject/PolyaLowBand*.lean` cover `0.18 ≤ |t| ≤ 1.8`, the gap\n'
          'left between `fourierSide_nonneg_of_abs_le` (`|t| ≤ 0.18`) and\n'
          '`fourierSide_nonneg_of_lin_threshold` (`|t| ≥ 1.8`).\n\n'
          'Two devices make the small-frequency range accessible: the exact cancellation of\n'
          'the first pole of the digamma series against the first pole of the Pólya model\n'
          '(`fourierSide_nonneg_band_sharp`), and the extension of the resolved partition\n'
          'from `q = 2.094` to `q = 5`, which lowers the unresolved tail from `0.013709` to\n'
          '`0.0022`.',
          ''.join(body))
    return 'PolyaLowThreshold'


def emit_all(phimax=F('0.25')):
    blocks = make_blocks_low(phimax)
    ok, lst, stuck = plan_bands(blocks)
    assert ok, 'planner fails at %s' % stuck
    print('%d blocks, %d bands' % (len(blocks), len(lst)))
    vbps = emit_vbp_tail()
    pcs = emit_pieces_tail()
    emit_far_tail()
    deps_blocks = ['PolyaLinVbp1', 'PolyaLinVbp2', 'PolyaLinVbp3', 'PolyaLinVbp4',
                   'PolyaLinPieces1', 'PolyaLinPieces2', 'PolyaLinPieces3', 'PolyaLinPieces4',
                   'PolyaLinPieces5', 'PolyaLinPieces6', 'PolyaLinPieces7', 'PolyaLinPieces8'
                   ] + vbps + pcs
    blks = emit_blocks_low(blocks, deps_blocks)
    bandlist = []
    for b, (t0, t1, e, m) in enumerate(lst):
        nm, ev = emit_band_low(b, blks, blocks, t0, t1)
        bandlist.append((b, t0, t1))
        print('  band %d [%s,%s] eta=%s' % (b, dec(t0), dec(t1), dec(ev)))
    emit_threshold_low(bandlist, ['PolyaLowBand%d' % b for b, _, _ in bandlist])
    return blks, bandlist
