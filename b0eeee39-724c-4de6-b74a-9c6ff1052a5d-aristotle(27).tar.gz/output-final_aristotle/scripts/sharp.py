import math, sys
sys.path.insert(0,'/workspace/request-project/scripts')
from analyze2 import pieces as oldpieces, vBP, req, cosbracket

PILO=3.14159265; PIHI=3.14159266

def trigbracket(x0,x1,which='cos'):
    """rigorous bracket for cos/sin on [x0,x1]"""
    f = math.cos if which=='cos' else math.sin
    vals=[f(x0),f(x1)]
    # critical points: cos -> k*pi ; sin -> pi/2 + k*pi
    if which=='cos':
        k=math.ceil(x0/math.pi)
        while k*math.pi<=x1:
            vals.append(f(k*math.pi)); k+=1
    else:
        k=math.ceil((x0-math.pi/2)/math.pi)
        while math.pi/2+k*math.pi<=x1:
            vals.append(f(math.pi/2+k*math.pi)); k+=1
    return min(vals),max(vals)

def imul(a,b):
    p=[a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]]
    return min(p),max(p)

def taylorQup(x):
    return 1 - x**2/18 + x**4/600 - x**6/35280 + x**8/3265920 - x**10/439084800 + x**12/80951270400 - x**14/19615115520000 + x**16/6046686277632000
def taylorQ(x):
    # one term shorter (degree 14, ending negative)
    return 1 - x**2/18 + x**4/600 - x**6/35280 + x**8/3265920 - x**10/439084800 + x**12/80951270400 - x**14/19615115520000

def si_interval(xlo,xhi,clo,chi,slo,shi):
    """Si(x) bracket given x in [xlo,xhi] and cos x in [clo,chi], sin x in [slo,shi]"""
    f=(1/xhi - 2/xlo**3, 1/xlo)
    g=(1/xhi**2 - 6/xlo**4, 1/xlo**2)
    fc=imul(f,(clo,chi)); gs=imul(g,(slo,shi))
    return (PILO/2 - fc[1] - gs[1], PIHI/2 - fc[0] - gs[0])

def piece_bracket_sharp(q0,q1, bmode=None):
    r0,r1=q0*q0,q1*q1
    # trig brackets for cos(2 pi r), sin(2 pi r)
    x0=2*PILO*r0; x1=2*PIHI*r1
    clo,chi=trigbracket(x0,x1,'cos'); slo,shi=trigbracket(x0,x1,'sin')
    # a-term
    alo=2*PILO*(1+r0); ahi=2*PIHI*(1+r1)
    Si_a=si_interval(alo,ahi,clo,chi,slo,shi)
    Ka=(r0/(PIHI*(1+r0)), r1/(PILO*(1+r1)))
    A=imul(Ka,Si_a)
    # b-term
    if bmode is None:
        bmode = 'asymp' if 2*PILO*(r0-1)>=6.0 else 'taylor'
    if bmode=='taylor':
        B=(2*r0*taylorQ(2*PIHI*(r1-1)), 2*r1*taylorQup(2*PILO*(r0-1)))
    else:
        blo=2*PILO*(r0-1); bhi=2*PIHI*(r1-1)
        Si_b=si_interval(blo,bhi,clo,chi,slo,shi)
        Kb=(r1/(PIHI*(r1-1)), r0/(PILO*(r0-1)))
        B=imul(Kb,Si_b)
    Lo=A[0]+B[0]-1-2.11/q0**5
    Hi=A[1]+B[1]-1-2.11/q1**5
    return Lo,Hi,bmode

def piece_bracket_old(q0,q1,kind):
    r0,r1=q0*q0,q1*q1
    Hi=(r1/(3.14159*(1+r1)))*(1.5708+1/(6.28318*(1+r0))+1/(6.28318*(1+r0))**2)
    Lo=(r0/(3.1416*(1+r0)))*(1.5707-1/(6.28318*(1+r0))-1/(6.28318*(1+r0))**2)
    if kind=='taylor':
        Hi+=2*r1*taylorQup(6.28318*(r0-1)); Lo+=2*r0*taylorQ(6.2832*(r1-1))
    else:
        Hi+=(r0/(3.14159*(r0-1)))*(1.5708+1/(6.28318*(r0-1))+1/(6.28318*(r0-1))**2)
        Lo+=(r1/(3.1416*(r1-1)))*(1.5707-1/(6.28318*(r0-1))-1/(6.28318*(r0-1))**2)
    Hi+=-1-2.11/q1**5; Lo+=-1-2.11/q0**5
    return Lo,Hi

if __name__=='__main__':
    print('%-22s %-28s %-28s'%('piece','old [Lo,Hi]','sharp [Lo,Hi]'))
    tot_old=tot_new=0
    for p in oldpieces[:5]+oldpieces[200:203]+oldpieces[470:474]+oldpieces[556:560]:
        q0,q1=p['q0'],p['q1']
        lo,hi=piece_bracket_old(q0,q1,p['kind'])
        slo,shi,bm=piece_bracket_sharp(q0,q1)
        print('[%.4f,%.4f] %s old[%.5f,%.5f] w=%.5f   sharp[%.5f,%.5f] w=%.5f  (%s)'%(q0,q1,p['kind'],lo,hi,hi-lo,slo,shi,shi-slo,bm))
