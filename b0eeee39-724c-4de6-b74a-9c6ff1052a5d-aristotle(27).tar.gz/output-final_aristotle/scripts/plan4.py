"""Planning for the *linear phase correction* block estimate.

On a block [a,b] with an interior breakpoint m one writes

  cos(t v) = cos(t m) cos(t(v-m)) - sin(t m) sin(t(v-m))

and uses  cos(g) = 1 + e_c (|e_c| <= g^2/2),  sin(g) = g + e_s (|e_s| <= |g|^3/6).
Hence

  int_a^b err cos(tv) >= cos(tm) * P  -  (t sin(tm)) * R  -  (t1^2/2) S2 - (t1^3/6) S3

with  P = int err,  R = int (v-m) err,  S2 = int (v-m)^2 |err|,  S3 = int |v-m|^3 |err|.
S2, S3 are bounded crudely by  max|v-m|^k * S.

Blocks may then be much wider than in the constant-bracket scheme.
"""
import math, sys
sys.path.insert(0, '/workspace/request-project/scripts')
from analyze2 import pieces as oldpieces, vBP, theta
from sharp import piece_bracket_sharp, piece_bracket_old

TAIL = 0.013709


def build(sharp=True):
    out = []
    for p in oldpieces:
        q0, q1 = p['q0'], p['q1']
        if sharp:
            Lo, Hi, bm = piece_bracket_sharp(q0, q1)
        else:
            Lo, Hi = piece_bracket_old(q0, q1, p['kind'])
        M = max(abs(Lo), abs(Hi))
        a, b = vBP(q0), vBP(q1)
        w = 1 / q0 - 1 / q1                      # int_a^b e^{-v/2} dv = 2w
        W = 2 * (a + 2) / q0 - 2 * (b + 2) / q1  # int_a^b v e^{-v/2} dv
        out.append(dict(q0=q0, q1=q1, a=a, b=b, Lo=Lo, Hi=Hi, M=M,
                        P0=2 * Lo * w, P1=2 * Hi * w, S=2 * M * w,
                        V0=Lo * W, V1=Hi * W))
    return out


def rng(f, x0, x1, crit):
    """true range of f on [x0,x1]; crit = list of critical points generator"""
    vals = [f(x0), f(x1)]
    for c in crit(x0, x1):
        vals.append(f(c))
    return min(vals), max(vals)


def cos_crit(x0, x1):
    k = math.ceil(x0 / math.pi)
    while k * math.pi <= x1:
        yield k * math.pi
        k += 1


def sin_crit(x0, x1):
    k = math.ceil((x0 - math.pi / 2) / math.pi)
    while math.pi / 2 + k * math.pi <= x1:
        yield math.pi / 2 + k * math.pi
        k += 1


def min4(x0, x1, y0, y1):
    return min(x0 * y0, x0 * y1, x1 * y0, x1 * y1)


def max4(x0, x1, y0, y1):
    return max(x0 * y0, x0 * y1, x1 * y0, x1 * y1)


def group_phase(ps, tref, phimax):
    """blocks with t_ref*(b-a) <= phimax"""
    groups = []; cur = []
    for p in ps:
        trial = cur + [p]
        if tref * (trial[-1]['b'] - trial[0]['a']) > phimax and cur:
            groups.append(cur); cur = [p]
        else:
            cur = trial
    if cur: groups.append(cur)
    return groups


def block_data(g):
    a = g[0]['a']; b = g[-1]['b']
    # midpoint breakpoint: the piece boundary closest to (a+b)/2
    mid = (a + b) / 2
    cands = [g[0]['a']] + [x['b'] for x in g]
    m = min(cands, key=lambda x: abs(x - mid))
    P0 = sum(x['P0'] for x in g); P1 = sum(x['P1'] for x in g)
    V0 = sum(x['V0'] for x in g); V1 = sum(x['V1'] for x in g)
    S = sum(x['S'] for x in g)
    R0 = V0 - m * P1; R1 = V1 - m * P0
    d = max(b - m, m - a)
    return dict(a=a, b=b, m=m, P0=P0, P1=P1, R0=R0, R1=R1, S=S,
                S2=d * d * S, S3=d ** 3 * S)


def eta_lin(blocks, t0, t1, tail=TAIL):
    tot = 0.0
    for B in blocks:
        m = B['m']
        u0, u1 = rng(math.cos, t0 * m, t1 * m, cos_crit)
        s0, s1 = rng(math.sin, t0 * m, t1 * m, sin_crit)
        z0, z1 = min4(t0, t1, s0, s1), max4(t0, t1, s0, s1)
        tot += (min4(u0, u1, B['P0'], B['P1']) - max4(z0, z1, B['R0'], B['R1'])
                - (t1 ** 2 / 2) * B['S2'] - (t1 ** 3 / 6) * B['S3'])
    return tot - tail


def req(a, b):
    return -(theta(a) - 5.37221 + 1 / (0.25 + b * b) + 12.66 / (9 + b * b)) / 2


if __name__ == '__main__':
    ps = build(True)
    for phimax in [0.25, 0.4, 0.5, 0.7, 1.0]:
        gs = group_phase(ps, 5.5, phimax)
        blocks = [block_data(g) for g in gs]
        print('=== phimax(@5.5) = %.2f  -> %d blocks' % (phimax, len(blocks)))
        for t0 in [2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5]:
            row = []
            for dt in [0.0625, 0.125, 0.25]:
                t1 = t0 + dt
                e = eta_lin(blocks, t0, t1)
                row.append('dt=%.4f m=%+.5f' % (dt, e - req(t0, t1)))
            print('   t0=%.2f  ' % t0 + ' | '.join(row))
