"""Planning: how far down can the large-frequency threshold go with the *sharp*
Si brackets of RequestProject/SiSharp.lean, on the existing 560-piece partition?

Reports, for a range of band left endpoints t0, band widths dt and phase budgets
phimax, the rigorous eta obtainable and the requirement req(t0,t1).
"""
import math, sys
sys.path.insert(0, '/workspace/request-project/scripts')
from analyze2 import pieces as oldpieces, vBP, theta
from sharp import piece_bracket_sharp, piece_bracket_old, trigbracket

TAIL_OLD = 0.013709


def build(sharp=True):
    out = []
    for p in oldpieces:
        q0, q1 = p['q0'], p['q1']
        if sharp:
            Lo, Hi, bm = piece_bracket_sharp(q0, q1)
        else:
            Lo, Hi = piece_bracket_old(q0, q1, p['kind'])
        M = max(abs(Lo), abs(Hi))
        w = 1 / q0 - 1 / q1
        out.append(dict(q0=q0, q1=q1, Lo=Lo, Hi=Hi, M=M,
                        P0=2 * Lo * w, P1=2 * Hi * w, S=2 * M * w, J=2 * w))
    return out


def cosbracket(lo, hi):
    mx = max(math.cos(lo), math.cos(hi)); mn = min(math.cos(lo), math.cos(hi))
    k = math.ceil(lo / math.pi)
    while k * math.pi <= hi:
        if k % 2 == 0: mx = 1.0
        else: mn = -1.0
        k += 1
    return (mx + mn) / 2, (mx - mn) / 2


def group(ps, t0, t1, phimax):
    groups = []; cur = []
    for p in ps:
        trial = cur + [p]
        a = vBP(trial[0]['q0']); b = vBP(trial[-1]['q1'])
        if t1 * b - t0 * a > phimax and cur:
            groups.append(cur); cur = [p]
        else:
            cur = trial
    if cur: groups.append(cur)
    return groups


def eta(ps, t0, t1, phimax, tail):
    gs = group(ps, t0, t1, phimax); tot = 0.0
    for g in gs:
        a = vBP(g[0]['q0']); b = vBP(g[-1]['q1'])
        P0 = sum(x['P0'] for x in g); P1 = sum(x['P1'] for x in g); S = sum(x['S'] for x in g)
        C, h = cosbracket(t0 * a, t1 * b)
        tot += min(C * P0, C * P1) - h * S
    return tot - tail, len(gs)


def req(a, b):
    return -(theta(a) - 5.37221 + 1 / (0.25 + b * b) + 12.66 / (9 + b * b)) / 2


if __name__ == '__main__':
    ps = build(True)
    po = build(False)
    tot_spread = sum((x['P1'] - x['P0']) / 2 for x in ps)
    tot_spread_old = sum((x['P1'] - x['P0']) / 2 for x in po)
    print('sharp: total spread/2 = %.5f ; old: %.5f' % (tot_spread, tot_spread_old))
    print('sum P0 %.5f sum P1 %.5f  sum S %.5f' % (sum(x['P0'] for x in ps),
          sum(x['P1'] for x in ps), sum(x['S'] for x in ps)))
    print()
    for t0 in [2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5]:
        for dt in [0.03125, 0.0625, 0.125]:
            t1 = t0 + dt
            row = []
            for phimax in [0.05, 0.08, 0.12, 0.2]:
                e, n = eta(ps, t0, t1, phimax, TAIL_OLD)
                row.append('phi=%.2f n=%3d m=%+.5f' % (phimax, n, e - req(t0, t1)))
            print('t0=%.3f dt=%.5f  ' % (t0, dt) + ' | '.join(row))
        print()
