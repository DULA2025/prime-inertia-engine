"""Greedy band planner for the linear-phase scheme: from t = TSTART up to 5.5,
choose at each step the largest admissible dt from a dyadic list."""
import sys
sys.path.insert(0, '/workspace/request-project/scripts')
from fractions import Fraction as F
import plan6
from plan6 import make_blocks, eta, req, TAIL

DTS = [F('0.5'), F('0.25'), F('0.1875'), F('0.125'), F('0.09375'), F('0.0625'),
       F('0.03125'), F('0.015625')]


def bands(blocks, tstart, tend=F('5.5'), tail=TAIL, margin=F('0.0002')):
    t = F(tstart)
    out = []
    while t < tend:
        chosen = None
        for dt in DTS:
            t1 = min(t + dt, tend)
            if t1 <= t:
                continue
            e = eta(blocks, t, t1, tail)
            if e is not None and e - req(t, t1) >= margin:
                chosen = (t1, e - req(t, t1))
                break
        if chosen is None:
            return None, out, t
        out.append((t, chosen[0], chosen[1]))
        t = chosen[0]
    return True, out, t


if __name__ == '__main__':
    phimax = F(sys.argv[1]) if len(sys.argv) > 1 else F('0.25')
    blocks = make_blocks(phimax)
    print('phimax=%s -> %d blocks' % (phimax, len(blocks)))
    for ts in ['4.5', '4.25', '4.0', '3.875', '3.75', '3.5']:
        ok, lst, stuck = bands(blocks, ts)
        if ok:
            print('t=%s OK with %d bands: %s' % (ts, len(lst),
                  ' '.join('[%s,%s]%+.5f' % (a, b, float(m)) for a, b, m in lst)))
        else:
            print('t=%s FAILS at %s (after %d bands)' % (ts, stuck, len(lst)))
