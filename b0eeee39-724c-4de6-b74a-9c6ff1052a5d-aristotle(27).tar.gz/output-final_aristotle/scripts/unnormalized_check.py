"""Numerical evaluation of the unnormalized functional L = D + W_infty
(`Lfun` / `LPositivity` of RequestProject/Positivity.lean) and of the
normalized functional `LfunNorm` (RequestProject/ArchimedeanExplicit.lean)
on convolution squares f = G * G~ of triangular bumps G of half-width w.

All formulas are transcriptions of the project's own definitions:

  delta(rho)   = deltaAux(max rho rho^{-1}),
  deltaAux(r)  = 2 sqrt r (siDiv(2 pi (1+r)) + siDiv(2 pi (r-1))),  siDiv x = Si x / x
  Dcomplex(ofLog f) = int_R f(t) delta(e^t) dt                        (Dcomplex_ofLog)
  WeilR(k)     = (log 4pi + gamma) k(1)
                 + int_1^infty (k(x) + x^{-1} k(x^{-1}) - 2 k(1)/x) dx/(x - x^{-1})
  Winfty       = -WeilR
  Lfun(ofLog f)= Dcomplex(ofLog f) + Winfty(ofLog f)          (unnormalized: LPositivity)
  LfunNorm(f)  = Dcomplex(ofLog f) + Winfty(deltaHalfInv(ofLog f))     (normalized)

With x = e^t and f real and even (which holds for f = convLog G (starLog G) with G
real and even) the two archimedean integrals become

  WeilR_unnorm = (log4pi+gamma) f(0) + int_0^infty [(1+e^{-t}) f(t) - 2 e^{-t} f(0)]/(1-e^{-2t}) dt
  WeilR_norm   = (log4pi+gamma) f(0) + int_0^infty [2 e^{-t/2} f(t) - 2 e^{-t} f(0)]/(1-e^{-2t}) dt

so that, for f >= 0,

  L_unnorm = L_norm - int_0^infty f(t) (1-e^{-t/2})^2/(1-e^{-2t}) dt  <=  L_norm .
"""

import math

# ---------------------------------------------------------------- quadrature

# 10-point Gauss-Legendre nodes/weights on [-1,1] (no endpoint evaluations).
GL_X = [-0.9739065285171717, -0.8650633666889845, -0.6794095682990244,
        -0.4333953941292472, -0.1488743389816312, 0.1488743389816312,
        0.4333953941292472, 0.6794095682990244, 0.8650633666889845,
        0.9739065285171717]
GL_W = [0.0666713443086881, 0.1494513491505806, 0.2190863625159820,
        0.2692667193099963, 0.2955242247147529, 0.2955242247147529,
        0.2692667193099963, 0.2190863625159820, 0.1494513491505806,
        0.0666713443086881]


def gl(f, a, b, panels=200):
    """Composite 10-point Gauss-Legendre quadrature of f on [a,b]."""
    h = (b - a) / panels
    total = 0.0
    for k in range(panels):
        c = a + (k + 0.5) * h
        s = 0.0
        for x, w in zip(GL_X, GL_W):
            s += w * f(c + 0.5 * h * x)
        total += 0.5 * h * s
    return total


def Si(x):
    """Sine integral Si(x) = int_0^x sin u / u du.

    Power series for |x| <= 4, Abramowitz & Stegun 5.2.38/5.2.39 rational
    approximations of the auxiliary functions f, g for |x| > 4
    (absolute accuracy better than 5e-9).
    """
    if x < 0:
        return -Si(-x)
    if x <= 4.0:
        # series: sum_{k>=0} (-1)^k x^{2k+1}/((2k+1)(2k+1)!)
        total = 0.0
        t = x            # x^{2k+1}/(2k+1)!
        k = 0
        while True:
            total += t / (2 * k + 1)
            k += 1
            t *= -x * x / ((2 * k) * (2 * k + 1))
            if abs(t) < 1e-18 or k > 200:
                break
        return total
    x2 = x * x
    x4 = x2 * x2
    x6 = x4 * x2
    x8 = x4 * x4
    fnum = x8 + 38.027264 * x6 + 265.187033 * x4 + 335.677320 * x2 + 38.102495
    fden = x8 + 40.021433 * x6 + 322.624911 * x4 + 570.236280 * x2 + 157.105423
    gnum = x8 + 42.242855 * x6 + 302.757865 * x4 + 352.018498 * x2 + 21.821899
    gden = x8 + 48.196927 * x6 + 482.485984 * x4 + 1114.978885 * x2 + 449.690326
    fx = fnum / (fden * x)
    gx = gnum / (gden * x2)
    return math.pi / 2 - fx * math.cos(x) - gx * math.sin(x)


def siDiv(x):
    return 1.0 if x == 0.0 else Si(x) / x


# ---------------------------------------------------------------- the project's delta

def deltaAux(r):
    return 2.0 * math.sqrt(r) * (siDiv(2 * math.pi * (1 + r)) + siDiv(2 * math.pi * (r - 1)))


def deltaLog(t):
    """delta(e^t) = deltaAux(e^{|t|})."""
    return deltaAux(math.exp(abs(t)))


# ------------------------------------------------- the test function f = G * G~

def fbump(t, w):
    """Autocorrelation of the triangular bump G(t) = max(0, 1 - |t|/w).

    f(t) = w * g(|t|/w) with g(u) = 2/3 - u^2 + u^3/2 on [0,1], (2-u)^3/6 on [1,2].
    f >= 0, f even, supported in [-2w, 2w], f(0) = 2w/3, int f = w^2.
    """
    u = abs(t) / w
    if u >= 2.0:
        return 0.0
    if u <= 1.0:
        return w * (2.0 / 3.0 - u * u + u ** 3 / 2.0)
    return w * (2.0 - u) ** 3 / 6.0


EULER = 0.5772156649015328606
CONST = math.log(4 * math.pi) + EULER


def D_of(f, T, panels=4000):
    """Dcomplex(ofLog f) = int_R f(t) delta(e^t) dt, f even supported in [-T,T]."""
    return 2.0 * gl(lambda t: f(t) * deltaLog(t), 0.0, T, panels=panels)


def weilR(f, T, normalized, panels=4000):
    f0 = f(0.0)

    def integrand(t):
        num_f = 2.0 * math.exp(-t / 2.0) * f(t) if normalized \
            else (1.0 + math.exp(-t)) * f(t)
        return (num_f - 2.0 * math.exp(-t) * f0) / (1.0 - math.exp(-2.0 * t))

    body = gl(integrand, 0.0, T, panels=panels)
    # exact tail for t > T (there f(t) = 0):
    y = math.exp(-T)
    tail = -f0 * math.log((1.0 + y) / (1.0 - y))
    return CONST * f0 + body + tail


def deficit(f, T, panels=4000):
    """int_0^infty f(t) (1-e^{-t/2})^2 / (1-e^{-2t}) dt  (= L_norm - L_unnorm)."""
    def integrand(t):
        return f(t) * (1.0 - math.exp(-t / 2.0)) ** 2 / (1.0 - math.exp(-2.0 * t))
    return gl(integrand, 0.0, T, panels=panels)


print(" w        f(0)      D            W_inf(unnorm)  L_unnorm      "
      "W_inf(norm)    L_norm       deficit    check")
for w in [0.25, 0.5, 1.0, 2.0, 3.0, 4.0, 6.0, 8.0]:
    T = 2 * w
    f = lambda t, w=w: fbump(t, w)
    D = D_of(f, T)
    Wu = -weilR(f, T, normalized=False)
    Wn = -weilR(f, T, normalized=True)
    Lu = D + Wu
    Ln = D + Wn
    dfc = deficit(f, T)
    print(f"{w:5.2f} {f(0.0):9.4f} {D:12.6f} {Wu:14.6f} {Lu:13.6f} "
          f"{Wn:14.6f} {Ln:12.6f} {dfc:10.6f} {Ln - dfc - Lu:10.2e}")
