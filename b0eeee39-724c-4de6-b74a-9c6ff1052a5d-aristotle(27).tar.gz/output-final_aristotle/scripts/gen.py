"""Exact-rational generator for the linear-phase-correction oscillatory estimate.

Mirrors, with `fractions.Fraction`, the Lean definitions of
`RequestProject/PolyaErrorSharp.lean` and `RequestProject/PolyaOscLin.lean`.
"""
from fractions import Fraction as F
import math, re, sys

PILO = F('3.14159265')
PIHI = F('3.14159266')
TPLO = F('6.2831853')
TPHI = F('6.28318531')
SILO = F('1.5707963')   # < pi/2
SIHI = F('1.5707964')   # > pi/2
QUAD = F('1.5707963')   # rational bound used for `y <= pi/2`

# ---------------------------------------------------------------- Taylor data
def _sidivpart(n, x):
    s = F(0)
    for k in range(n):
        s += F((-1) ** k) * x ** (2 * k) / F((2 * k + 1) * math.factorial(2 * k + 1))
    return s

def taylorQ(x):   return _sidivpart(8, x)
def taylorQup(x): return _sidivpart(9, x)

def cosLoP(y):
    return 1 - y**2/2 + y**4/24 - y**6/720 + y**8/40320 - y**10/3628800
def cosHiP(y):
    return 1 - y**2/2 + y**4/24 - y**6/720 + y**8/40320
def sinLoP(y):
    return y - y**3/6 + y**5/120 - y**7/5040 + y**9/362880 - y**11/39916800
def sinHiP(y):
    return y - y**3/6 + y**5/120 - y**7/5040 + y**9/362880

# ---------------------------------------------------------------- Si brackets
def siLoSharp(X0, X1, C1, S1):
    return SILO - max((1/X0)*C1, (1/X1 - 2/X0**3)*C1) - max((1/X0**2)*S1, (1/X1**2 - 6/X0**4)*S1)

def siHiSharp(X0, X1, C0, S0):
    return SIHI - min((1/X0)*C0, (1/X1 - 2/X0**3)*C0) - min((1/X0**2)*S0, (1/X1**2 - 6/X0**4)*S0)

def aLoSharp(q0, q1, C1, S1):
    return (q0**2/(PIHI*(1+q0**2))) * siLoSharp(TPLO*(1+q0**2), TPHI*(1+q1**2), C1, S1)

def aHiSharp(q0, q1, C0, S0):
    return (q1**2/(PILO*(1+q1**2))) * siHiSharp(TPLO*(1+q0**2), TPHI*(1+q1**2), C0, S0)

def bLoSharp(q0, q1, C1, S1):
    return (q1**2/(PIHI*(q1**2-1))) * siLoSharp(TPLO*(q0**2-1), TPHI*(q1**2-1), C1, S1)

def bHiSharp(q0, q1, C0, S0):
    return (q0**2/(PILO*(q0**2-1))) * siHiSharp(TPLO*(q0**2-1), TPHI*(q1**2-1), C0, S0)

# ------------------------------------------------------- trig on one quadrant
def quadrant(r0, r1):
    """Return (K, j, u0, u1) if [r0,r1] lies in one quadrant of r mod 1, else None."""
    j = math.floor(float(r0))
    for cand in (j - 1, j, j + 1):
        for K in range(4):
            u0 = r0 - cand - F(K, 4)
            u1 = r1 - cand - F(K, 4)
            if u0 >= 0 and TPHI * u1 <= QUAD:
                return (K, cand, u0, u1)
    return None

def trig_from_quadrant(K, u0, u1):
    """(C0,C1,S0,S1) exactly as the Lean trigBracketK lemmas give them."""
    a, b = TPLO * u0, TPHI * u1
    if K == 0:
        return cosLoP(b), cosHiP(a), sinLoP(a), sinHiP(b)
    if K == 1:
        return -sinHiP(b), -sinLoP(a), cosLoP(b), cosHiP(a)
    if K == 2:
        return -cosHiP(a), -cosLoP(b), -sinHiP(b), -sinLoP(a)
    return sinLoP(a), sinHiP(b), -cosHiP(a), -cosLoP(b)

# ------------------------------------------------------------- crude brackets
def crude_bracket(q0, q1, kind):
    """The old (crude) bracket of PolyaOscBase.errPiece_taylor / errPiece_asymp."""
    r0, r1 = q0**2, q1**2
    Hi = (r1/(F('3.14159')*(1+r1))) * (F('1.5708') + 1/(F('6.28318')*(1+r0))
                                       + 1/(F('6.28318')*(1+r0))**2)
    Lo = (r0/(F('3.1416')*(1+r0))) * (F('1.5707') - 1/(F('6.28318')*(1+r0))
                                      - 1/(F('6.28318')*(1+r0))**2)
    if kind == 'taylor':
        Hi += 2*r1*taylorQup(F('6.28318')*(r0-1))
        Lo += 2*r0*taylorQ(F('6.2832')*(r1-1))
    else:
        Hi += (r0/(F('3.14159')*(r0-1)))*(F('1.5708') + 1/(F('6.28318')*(r0-1))
                                          + 1/(F('6.28318')*(r0-1))**2)
        Lo += (r1/(F('3.1416')*(r1-1)))*(F('1.5707') - 1/(F('6.28318')*(r0-1))
                                         - 1/(F('6.28318')*(r0-1))**2)
    Hi += -1 - F('2.11')/q1**5
    Lo += -1 - F('2.11')/q0**5
    return Lo, Hi

def sharp_bracket(q0, q1, kind, C0, C1, S0, S1):
    if kind == 'taylor':
        Lo = aLoSharp(q0, q1, C1, S1) + 2*q0**2*taylorQ(F('6.2832')*(q1**2-1)) - 1 - F('2.11')/q0**5
        Hi = aHiSharp(q0, q1, C0, S0) + 2*q1**2*taylorQup(F('6.28318')*(q0**2-1)) - 1 - F('2.11')/q1**5
    else:
        Lo = aLoSharp(q0, q1, C1, S1) + bLoSharp(q0, q1, C1, S1) - 1 - F('2.11')/q0**5
        Hi = aHiSharp(q0, q1, C0, S0) + bHiSharp(q0, q1, C0, S0) - 1 - F('2.11')/q1**5
    return Lo, Hi

# ----------------------------------------------------------------- formatting
def rd(x, nd=9):
    """round DOWN to nd decimals"""
    s = F(10) ** nd
    return F(math.floor(x * s), 1) / s

def ru(x, nd=9):
    """round UP to nd decimals"""
    s = F(10) ** nd
    return F(math.ceil(x * s), 1) / s

def dec(x, nd=None):
    """decimal literal string for a Fraction (exact if it terminates)"""
    if nd is None:
        # find a terminating decimal representation
        d = x.denominator
        n2 = n5 = 0
        while d % 2 == 0: d //= 2; n2 += 1
        while d % 5 == 0: d //= 5; n5 += 1
        assert d == 1, 'non terminating: %s' % x
        nd = max(n2, n5)
    v = x * F(10) ** nd
    assert v.denominator == 1
    v = int(v)
    sgn = '-' if v < 0 else ''
    v = abs(v)
    s = str(v).rjust(nd + 1, '0')
    if nd == 0:
        return sgn + s
    return sgn + s[:-nd] + '.' + s[-nd:]

def lit(x, nd=None):
    """Lean literal, parenthesised if negative"""
    s = dec(x, nd)
    return '(' + s + ')' if s.startswith('-') else s

# ------------------------------------------------------------ log/vBP bracket
def vbp_bracket(q, nd=9):
    """rational [lo,hi] with lo <= 2 log q <= hi, matching `vBP_bracket 12`."""
    x = (q - 1) / q
    s = sum(x**(i+1)/(i+1) for i in range(12))
    err = x**13/(1-x)
    lo, hi = 2*(s - err), 2*(s + err)
    return rd(lo, nd), ru(hi, nd)
