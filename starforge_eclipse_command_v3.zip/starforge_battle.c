// STARFORGE: ECLIPSE COMMAND V3.0 // DULA GAME STUDIOS // Windows 11 C + OpenGL 4.6 Compute + NVML + WinMM Audio
// Full HDR Space Combat Game built on the AETHERION V2.5 NVIDIA Graphics Pipeline
// Compiles directly with build_starforge.bat (MinGW-w64 gcc or MSVC cl, zero external SDKs)
//
// FLIGHT & COMBAT CONTROLS:
//   Mouse Move           : Aim & steer starfighter   | Left-Click / Space : Quad Crimson Lasers
//   Right-Click / E      : Homing Proton Torpedoes   | W / S / Wheel      : Throttle Up / Brake
//   A / D                : Barrel Roll / Bank        | Shift              : Ion Afterburner Boost
//   C                    : Toggle S-Foils (X-Wings)  | Tab                : Camera View (Chase/Hero/Cockpit)
//   Enter / Click        : Menu Select / Next Sector | ESC / P : Pause Menu
//
// GRAPHICS & ENGINE HOTKEYS (AETHERION V2.5 HDR PIPELINE):
//   F                    : Optical Filter (Cinema HDR / Cockpit Cam / Anamorphic / Raw Studio)
//   T                    : Tone Mapper (AgX Punchy / ACES / Khronos PBR Neutral / Hable)
//   B  ( [ / ] )         : Split-Screen Raw Linear HDR vs Post-Processed Wipe
//   G                    : Temporal AA (TAA)         | X : HDR Auto-Exposure
//   - / =                : Exposure Bias (EV)        | M : Mute / Unmute Procedural Audio
//   F5 - F8              : Render Scale (0.50x / 0.75x / 1.00x / 1.25x)
//   U                    : VSync (Adaptive-NV / On / Off) | F11 / Alt+Enter : Fullscreen Toggle

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>
#include <GL/gl.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "winmm.lib")

// Force discrete NVIDIA RTX GPU on Windows hybrid/Optimus laptops & desktops
__declspec(dllexport) DWORD NvOptimusEnablement = 0x00000001;
__declspec(dllexport) int   AmdPowerXpressRequestHighPerformance = 1;

// ============================================================================
// RUNTIME NVIDIA MANAGEMENT LIBRARY (nvml.dll — ZERO SDK REQUIRED)
// ============================================================================
typedef struct nvmlDevice_st *nvmlDevice_t;
typedef struct { unsigned int gpu; unsigned int memory; } nvmlUtilization_t;

typedef int (*PFN_nvmlInit_v2)(void);
typedef int (*PFN_nvmlShutdown)(void);
typedef int (*PFN_nvmlDeviceGetHandleByIndex_v2)(unsigned int, nvmlDevice_t *);
typedef int (*PFN_nvmlDeviceGetName)(nvmlDevice_t, char *, unsigned int);
typedef int (*PFN_nvmlDeviceGetTemperature)(nvmlDevice_t, int, unsigned int *);
typedef int (*PFN_nvmlDeviceGetUtilizationRates)(nvmlDevice_t, nvmlUtilization_t *);
typedef int (*PFN_nvmlDeviceGetClockInfo)(nvmlDevice_t, int, unsigned int *);
typedef int (*PFN_nvmlDeviceGetPowerUsage)(nvmlDevice_t, unsigned int *);

typedef struct {
  HMODULE dll;
  int active;
  nvmlDevice_t dev;
  char name[64];
  unsigned int tempC, gpuUtil, clkMHz;
  float powerW;
  PFN_nvmlShutdown shutdown;
  PFN_nvmlDeviceGetTemperature getTemp;
  PFN_nvmlDeviceGetUtilizationRates getUtil;
  PFN_nvmlDeviceGetClockInfo getClock;
  PFN_nvmlDeviceGetPowerUsage getPower;
} NvmlState;

static NvmlState g_nvml;

static void nvml_try_init(void) {
  memset(&g_nvml, 0, sizeof(g_nvml));
  g_nvml.dll = LoadLibraryA("nvml.dll");
  if (!g_nvml.dll) g_nvml.dll = LoadLibraryA("C:\\Program Files\\NVIDIA Corporation\\NVSMI\\nvml.dll");
  if (!g_nvml.dll) return;

  PFN_nvmlInit_v2 fnInit = (PFN_nvmlInit_v2)GetProcAddress(g_nvml.dll, "nvmlInit_v2");
  PFN_nvmlDeviceGetHandleByIndex_v2 fnHandle =
    (PFN_nvmlDeviceGetHandleByIndex_v2)GetProcAddress(g_nvml.dll, "nvmlDeviceGetHandleByIndex_v2");
  PFN_nvmlDeviceGetName fnName = (PFN_nvmlDeviceGetName)GetProcAddress(g_nvml.dll, "nvmlDeviceGetName");

  g_nvml.shutdown = (PFN_nvmlShutdown)GetProcAddress(g_nvml.dll, "nvmlShutdown");
  g_nvml.getTemp  = (PFN_nvmlDeviceGetTemperature)GetProcAddress(g_nvml.dll, "nvmlDeviceGetTemperature");
  g_nvml.getUtil  = (PFN_nvmlDeviceGetUtilizationRates)GetProcAddress(g_nvml.dll, "nvmlDeviceGetUtilizationRates");
  g_nvml.getClock = (PFN_nvmlDeviceGetClockInfo)GetProcAddress(g_nvml.dll, "nvmlDeviceGetClockInfo");
  g_nvml.getPower = (PFN_nvmlDeviceGetPowerUsage)GetProcAddress(g_nvml.dll, "nvmlDeviceGetPowerUsage");

  if (!fnInit || !fnHandle || fnInit() != 0) {
    FreeLibrary(g_nvml.dll); g_nvml.dll = NULL; return;
  }
  if (fnHandle(0, &g_nvml.dev) != 0) {
    if (g_nvml.shutdown) g_nvml.shutdown();
    FreeLibrary(g_nvml.dll); g_nvml.dll = NULL; return;
  }
  if (fnName) fnName(g_nvml.dev, g_nvml.name, sizeof(g_nvml.name));
  const char *rtx = strstr(g_nvml.name, "RTX");
  if (!rtx) rtx = strstr(g_nvml.name, "GTX");
  if (rtx && rtx != g_nvml.name) memmove(g_nvml.name, rtx, strlen(rtx) + 1);
  g_nvml.active = 1;
}

static void nvml_poll(void) {
  if (!g_nvml.active) return;
  if (g_nvml.getTemp)  g_nvml.getTemp(g_nvml.dev, 0, &g_nvml.tempC);
  if (g_nvml.getClock) g_nvml.getClock(g_nvml.dev, 0, &g_nvml.clkMHz);
  if (g_nvml.getUtil) {
    nvmlUtilization_t u = {0, 0};
    if (g_nvml.getUtil(g_nvml.dev, &u) == 0) g_nvml.gpuUtil = u.gpu;
  }
  if (g_nvml.getPower) {
    unsigned int mw = 0;
    if (g_nvml.getPower(g_nvml.dev, &mw) == 0) g_nvml.powerW = (float)mw * 0.001f;
  }
}

static void nvml_cleanup(void) {
  if (g_nvml.active && g_nvml.shutdown) g_nvml.shutdown();
  if (g_nvml.dll) FreeLibrary(g_nvml.dll);
  memset(&g_nvml, 0, sizeof(g_nvml));
}

// ============================================================================
// OPENGL 4.6 CORE + COMPUTE CONSTANTS & FUNCTION POINTERS
// ============================================================================
#ifndef GL_FRAGMENT_SHADER
#define GL_FRAGMENT_SHADER                            0x8B30
#endif
#ifndef GL_VERTEX_SHADER
#define GL_VERTEX_SHADER                              0x8B31
#endif
#ifndef GL_COMPUTE_SHADER
#define GL_COMPUTE_SHADER                             0x91B9
#endif
#ifndef GL_COMPILE_STATUS
#define GL_COMPILE_STATUS                             0x8B81
#endif
#ifndef GL_LINK_STATUS
#define GL_LINK_STATUS                                0x8B82
#endif
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE                              0x812F
#endif
#ifndef GL_TEXTURE0
#define GL_TEXTURE0                                   0x84C0
#endif
#ifndef GL_RGBA16F
#define GL_RGBA16F                                    0x881A
#endif
#ifndef GL_R11F_G11F_B10F
#define GL_R11F_G11F_B10F                             0x8C3A
#endif
#ifndef GL_HALF_FLOAT
#define GL_HALF_FLOAT                                 0x140B
#endif
#ifndef GL_DEPTH_COMPONENT24
#define GL_DEPTH_COMPONENT24                          0x81A6
#endif
#ifndef GL_FRAMEBUFFER
#define GL_FRAMEBUFFER                                0x8D40
#endif
#ifndef GL_COLOR_ATTACHMENT0
#define GL_COLOR_ATTACHMENT0                          0x8CE0
#endif
#ifndef GL_COLOR_ATTACHMENT1
#define GL_COLOR_ATTACHMENT1                          0x8CE1
#endif
#ifndef GL_DEPTH_ATTACHMENT
#define GL_DEPTH_ATTACHMENT                           0x8D00
#endif
#ifndef GL_FRAMEBUFFER_COMPLETE
#define GL_FRAMEBUFFER_COMPLETE                       0x8CD5
#endif
#ifndef GL_ARRAY_BUFFER
#define GL_ARRAY_BUFFER                               0x8892
#endif
#ifndef GL_ELEMENT_ARRAY_BUFFER
#define GL_ELEMENT_ARRAY_BUFFER                       0x8893
#endif
#ifndef GL_R8
#define GL_R8                                         0x8229
#endif
#ifndef GL_RED
#define GL_RED                                        0x1903
#endif
#ifndef GL_DYNAMIC_DRAW
#define GL_DYNAMIC_DRAW                               0x88E8
#endif
#ifndef GL_SRC_ALPHA
#define GL_SRC_ALPHA                                  0x0302
#endif
#ifndef GL_ONE_MINUS_SRC_ALPHA
#define GL_ONE_MINUS_SRC_ALPHA                        0x0303
#endif
#ifndef GL_UNPACK_ALIGNMENT
#define GL_UNPACK_ALIGNMENT                           0x0CF5
#endif
#ifndef GL_STATIC_DRAW
#define GL_STATIC_DRAW                                0x88E4
#endif
#ifndef GL_WRITE_ONLY
#define GL_WRITE_ONLY                                 0x88B9
#endif
#ifndef GL_SHADER_IMAGE_ACCESS_BARRIER_BIT
#define GL_SHADER_IMAGE_ACCESS_BARRIER_BIT            0x00000020
#endif
#ifndef GL_TEXTURE_FETCH_BARRIER_BIT
#define GL_TEXTURE_FETCH_BARRIER_BIT                  0x00000008
#endif
#ifndef GL_TIME_ELAPSED
#define GL_TIME_ELAPSED                               0x88BF
#endif
#ifndef GL_QUERY_RESULT
#define GL_QUERY_RESULT                               0x8866
#endif
#ifndef GL_QUERY_RESULT_AVAILABLE
#define GL_QUERY_RESULT_AVAILABLE                     0x8867
#endif
#ifndef GL_GPU_MEMORY_INFO_DEDICATED_VIDMEM_NVX
#define GL_GPU_MEMORY_INFO_DEDICATED_VIDMEM_NVX       0x9047
#define GL_GPU_MEMORY_INFO_CURRENT_AVAILABLE_VIDMEM_NVX 0x9049
#endif
#ifndef WGL_CONTEXT_MAJOR_VERSION_ARB
#define WGL_CONTEXT_MAJOR_VERSION_ARB                 0x2091
#define WGL_CONTEXT_MINOR_VERSION_ARB                 0x2092
#define WGL_CONTEXT_PROFILE_MASK_ARB                  0x9126
#define WGL_CONTEXT_CORE_PROFILE_BIT_ARB              0x00000001
#endif

typedef ptrdiff_t GLsizeiptr_t;

typedef HGLRC  (WINAPI   *PFNWGLCREATECONTEXTATTRIBSARBPROC)(HDC, HGLRC, const int*);
typedef BOOL   (WINAPI   *PFNWGLSWAPINTERVALEXTPROC)(int);
typedef GLuint (APIENTRY *PFNGLCREATESHADERPROC)(GLenum);
typedef void   (APIENTRY *PFNGLSHADERSOURCEPROC)(GLuint, GLsizei, const char* const*, const GLint*);
typedef void   (APIENTRY *PFNGLCOMPILESHADERPROC)(GLuint);
typedef void   (APIENTRY *PFNGLGETSHADERIVPROC)(GLuint, GLenum, GLint*);
typedef void   (APIENTRY *PFNGLGETSHADERINFOLOGPROC)(GLuint, GLsizei, GLsizei*, char*);
typedef void   (APIENTRY *PFNGLDELETESHADERPROC)(GLuint);
typedef GLuint (APIENTRY *PFNGLCREATEPROGRAMPROC)(void);
typedef void   (APIENTRY *PFNGLATTACHSHADERPROC)(GLuint, GLuint);
typedef void   (APIENTRY *PFNGLLINKPROGRAMPROC)(GLuint);
typedef void   (APIENTRY *PFNGLGETPROGRAMIVPROC)(GLuint, GLenum, GLint*);
typedef void   (APIENTRY *PFNGLGETPROGRAMINFOLOGPROC)(GLuint, GLsizei, GLsizei*, char*);
typedef void   (APIENTRY *PFNGLUSEPROGRAMPROC)(GLuint);
typedef GLint  (APIENTRY *PFNGLGETUNIFORMLOCATIONPROC)(GLuint, const char*);
typedef void   (APIENTRY *PFNGLUNIFORM1FPROC)(GLint, GLfloat);
typedef void   (APIENTRY *PFNGLUNIFORM1IPROC)(GLint, GLint);
typedef void   (APIENTRY *PFNGLUNIFORM2FPROC)(GLint, GLfloat, GLfloat);
typedef void   (APIENTRY *PFNGLUNIFORM2IPROC)(GLint, GLint, GLint);
typedef void   (APIENTRY *PFNGLUNIFORM3FVPROC)(GLint, GLsizei, const GLfloat*);
typedef void   (APIENTRY *PFNGLUNIFORM4FVPROC)(GLint, GLsizei, const GLfloat*);
typedef void   (APIENTRY *PFNGLUNIFORMMATRIX3FVPROC)(GLint, GLsizei, GLboolean, const GLfloat*);
typedef void   (APIENTRY *PFNGLUNIFORMMATRIX4FVPROC)(GLint, GLsizei, GLboolean, const GLfloat*);
typedef void   (APIENTRY *PFNGLACTIVETEXTUREPROC)(GLenum);
typedef void   (APIENTRY *PFNGLGENFRAMEBUFFERSPROC)(GLsizei, GLuint*);
typedef void   (APIENTRY *PFNGLBINDFRAMEBUFFERPROC)(GLenum, GLuint);
typedef void   (APIENTRY *PFNGLFRAMEBUFFERTEXTURE2DPROC)(GLenum, GLenum, GLenum, GLuint, GLint);
typedef GLenum (APIENTRY *PFNGLCHECKFRAMEBUFFERSTATUSPROC)(GLenum);
typedef void   (APIENTRY *PFNGLDELETEFRAMEBUFFERSPROC)(GLsizei, const GLuint*);
typedef void   (APIENTRY *PFNGLDRAWBUFFERSPROC)(GLsizei, const GLenum*);
typedef void   (APIENTRY *PFNGLGENVERTEXARRAYSPROC)(GLsizei, GLuint*);
typedef void   (APIENTRY *PFNGLBINDVERTEXARRAYPROC)(GLuint);
typedef void   (APIENTRY *PFNGLDELETEVERTEXARRAYSPROC)(GLsizei, const GLuint*);
typedef void   (APIENTRY *PFNGLGENBUFFERSPROC)(GLsizei, GLuint*);
typedef void   (APIENTRY *PFNGLBINDBUFFERPROC)(GLenum, GLuint);
typedef void   (APIENTRY *PFNGLBUFFERDATAPROC)(GLenum, GLsizeiptr_t, const void*, GLenum);
typedef void   (APIENTRY *PFNGLBUFFERSUBDATAPROC)(GLenum, GLsizeiptr_t, GLsizeiptr_t, const void*);
typedef void   (APIENTRY *PFNGLDELETEBUFFERSPROC)(GLsizei, const GLuint*);
typedef void   (APIENTRY *PFNGLVERTEXATTRIBPOINTERPROC)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*);
typedef void   (APIENTRY *PFNGLENABLEVERTEXATTRIBARRAYPROC)(GLuint);
typedef void   (APIENTRY *PFNGLDISPATCHCOMPUTEPROC)(GLuint, GLuint, GLuint);
typedef void   (APIENTRY *PFNGLMEMORYBARRIERPROC)(GLbitfield);
typedef void   (APIENTRY *PFNGLBINDIMAGETEXTUREPROC)(GLuint, GLuint, GLint, GLboolean, GLint, GLenum, GLenum);
typedef void   (APIENTRY *PFNGLGENQUERIESPROC)(GLsizei, GLuint*);
typedef void   (APIENTRY *PFNGLBEGINQUERYPROC)(GLenum, GLuint);
typedef void   (APIENTRY *PFNGLENDQUERYPROC)(GLenum);
typedef void   (APIENTRY *PFNGLGETQUERYOBJECTIVPROC)(GLuint, GLenum, GLint*);
typedef void   (APIENTRY *PFNGLGETQUERYOBJECTUI64VPROC)(GLuint, GLenum, uint64_t*);

static PFNWGLCREATECONTEXTATTRIBSARBPROC wglCreateContextAttribsARB;
static PFNWGLSWAPINTERVALEXTPROC         wglSwapIntervalEXT;
static PFNGLCREATESHADERPROC             pglCreateShader;
static PFNGLSHADERSOURCEPROC             pglShaderSource;
static PFNGLCOMPILESHADERPROC            pglCompileShader;
static PFNGLGETSHADERIVPROC              pglGetShaderiv;
static PFNGLGETSHADERINFOLOGPROC         pglGetShaderInfoLog;
static PFNGLDELETESHADERPROC             pglDeleteShader;
static PFNGLCREATEPROGRAMPROC            pglCreateProgram;
static PFNGLATTACHSHADERPROC             pglAttachShader;
static PFNGLLINKPROGRAMPROC              pglLinkProgram;
static PFNGLGETPROGRAMIVPROC             pglGetProgramiv;
static PFNGLGETPROGRAMINFOLOGPROC        pglGetProgramInfoLog;
static PFNGLUSEPROGRAMPROC               pglUseProgram;
static PFNGLGETUNIFORMLOCATIONPROC       pglGetUniformLocation;
static PFNGLUNIFORM1FPROC                pglUniform1f;
static PFNGLUNIFORM1IPROC                pglUniform1i;
static PFNGLUNIFORM2FPROC                pglUniform2f;
static PFNGLUNIFORM2IPROC                pglUniform2i;
static PFNGLUNIFORM3FVPROC               pglUniform3fv;
static PFNGLUNIFORM4FVPROC               pglUniform4fv;
static PFNGLUNIFORMMATRIX3FVPROC         pglUniformMatrix3fv;
static PFNGLUNIFORMMATRIX4FVPROC         pglUniformMatrix4fv;
static PFNGLACTIVETEXTUREPROC            pglActiveTexture;
static PFNGLGENFRAMEBUFFERSPROC          pglGenFramebuffers;
static PFNGLBINDFRAMEBUFFERPROC          pglBindFramebuffer;
static PFNGLFRAMEBUFFERTEXTURE2DPROC     pglFramebufferTexture2D;
static PFNGLCHECKFRAMEBUFFERSTATUSPROC   pglCheckFramebufferStatus;
static PFNGLDELETEFRAMEBUFFERSPROC       pglDeleteFramebuffers;
static PFNGLDRAWBUFFERSPROC              pglDrawBuffers;
static PFNGLGENVERTEXARRAYSPROC          pglGenVertexArrays;
static PFNGLBINDVERTEXARRAYPROC          pglBindVertexArray;
static PFNGLDELETEVERTEXARRAYSPROC       pglDeleteVertexArrays;
static PFNGLGENBUFFERSPROC               pglGenBuffers;
static PFNGLBINDBUFFERPROC               pglBindBuffer;
static PFNGLBUFFERDATAPROC               pglBufferData;
static PFNGLBUFFERSUBDATAPROC            pglBufferSubData;
static PFNGLDELETEBUFFERSPROC            pglDeleteBuffers;
static PFNGLVERTEXATTRIBPOINTERPROC      pglVertexAttribPointer;
static PFNGLENABLEVERTEXATTRIBARRAYPROC  pglEnableVertexAttribArray;
static PFNGLDISPATCHCOMPUTEPROC          pglDispatchCompute;
static PFNGLMEMORYBARRIERPROC            pglMemoryBarrier;
static PFNGLBINDIMAGETEXTUREPROC         pglBindImageTexture;
static PFNGLGENQUERIESPROC               pglGenQueries;
static PFNGLBEGINQUERYPROC               pglBeginQuery;
static PFNGLENDQUERYPROC                 pglEndQuery;
static PFNGLGETQUERYOBJECTIVPROC         pglGetQueryObjectiv;
static PFNGLGETQUERYOBJECTUI64VPROC      pglGetQueryObjectui64v;

static void *gl_proc(const char *name) {
  void *p = (void *)wglGetProcAddress(name);
  if (!p || p == (void *)0x1 || p == (void *)0x2 || p == (void *)0x3 || p == (void *)-1) {
    HMODULE mod = GetModuleHandleA("opengl32.dll");
    if (mod) p = (void *)GetProcAddress(mod, name);
  }
  return p;
}

static int load_gl_functions(void) {
  wglSwapIntervalEXT          = (PFNWGLSWAPINTERVALEXTPROC)gl_proc("wglSwapIntervalEXT");
  pglCreateShader             = (PFNGLCREATESHADERPROC)gl_proc("glCreateShader");
  pglShaderSource             = (PFNGLSHADERSOURCEPROC)gl_proc("glShaderSource");
  pglCompileShader            = (PFNGLCOMPILESHADERPROC)gl_proc("glCompileShader");
  pglGetShaderiv              = (PFNGLGETSHADERIVPROC)gl_proc("glGetShaderiv");
  pglGetShaderInfoLog         = (PFNGLGETSHADERINFOLOGPROC)gl_proc("glGetShaderInfoLog");
  pglDeleteShader             = (PFNGLDELETESHADERPROC)gl_proc("glDeleteShader");
  pglCreateProgram            = (PFNGLCREATEPROGRAMPROC)gl_proc("glCreateProgram");
  pglAttachShader             = (PFNGLATTACHSHADERPROC)gl_proc("glAttachShader");
  pglLinkProgram              = (PFNGLLINKPROGRAMPROC)gl_proc("glLinkProgram");
  pglGetProgramiv             = (PFNGLGETPROGRAMIVPROC)gl_proc("glGetProgramiv");
  pglGetProgramInfoLog        = (PFNGLGETPROGRAMINFOLOGPROC)gl_proc("glGetProgramInfoLog");
  pglUseProgram               = (PFNGLUSEPROGRAMPROC)gl_proc("glUseProgram");
  pglGetUniformLocation       = (PFNGLGETUNIFORMLOCATIONPROC)gl_proc("glGetUniformLocation");
  pglUniform1f                = (PFNGLUNIFORM1FPROC)gl_proc("glUniform1f");
  pglUniform1i                = (PFNGLUNIFORM1IPROC)gl_proc("glUniform1i");
  pglUniform2f                = (PFNGLUNIFORM2FPROC)gl_proc("glUniform2f");
  pglUniform2i                = (PFNGLUNIFORM2IPROC)gl_proc("glUniform2i");
  pglUniform3fv               = (PFNGLUNIFORM3FVPROC)gl_proc("glUniform3fv");
  pglUniform4fv               = (PFNGLUNIFORM4FVPROC)gl_proc("glUniform4fv");
  pglUniformMatrix3fv         = (PFNGLUNIFORMMATRIX3FVPROC)gl_proc("glUniformMatrix3fv");
  pglUniformMatrix4fv         = (PFNGLUNIFORMMATRIX4FVPROC)gl_proc("glUniformMatrix4fv");
  pglActiveTexture            = (PFNGLACTIVETEXTUREPROC)gl_proc("glActiveTexture");
  pglGenFramebuffers          = (PFNGLGENFRAMEBUFFERSPROC)gl_proc("glGenFramebuffers");
  pglBindFramebuffer          = (PFNGLBINDFRAMEBUFFERPROC)gl_proc("glBindFramebuffer");
  pglFramebufferTexture2D     = (PFNGLFRAMEBUFFERTEXTURE2DPROC)gl_proc("glFramebufferTexture2D");
  pglCheckFramebufferStatus   = (PFNGLCHECKFRAMEBUFFERSTATUSPROC)gl_proc("glCheckFramebufferStatus");
  pglDeleteFramebuffers       = (PFNGLDELETEFRAMEBUFFERSPROC)gl_proc("glDeleteFramebuffers");
  pglDrawBuffers              = (PFNGLDRAWBUFFERSPROC)gl_proc("glDrawBuffers");
  pglGenVertexArrays          = (PFNGLGENVERTEXARRAYSPROC)gl_proc("glGenVertexArrays");
  pglBindVertexArray          = (PFNGLBINDVERTEXARRAYPROC)gl_proc("glBindVertexArray");
  pglDeleteVertexArrays       = (PFNGLDELETEVERTEXARRAYSPROC)gl_proc("glDeleteVertexArrays");
  pglGenBuffers               = (PFNGLGENBUFFERSPROC)gl_proc("glGenBuffers");
  pglBindBuffer               = (PFNGLBINDBUFFERPROC)gl_proc("glBindBuffer");
  pglBufferData               = (PFNGLBUFFERDATAPROC)gl_proc("glBufferData");
  pglBufferSubData            = (PFNGLBUFFERSUBDATAPROC)gl_proc("glBufferSubData");
  pglDeleteBuffers            = (PFNGLDELETEBUFFERSPROC)gl_proc("glDeleteBuffers");
  pglVertexAttribPointer      = (PFNGLVERTEXATTRIBPOINTERPROC)gl_proc("glVertexAttribPointer");
  pglEnableVertexAttribArray  = (PFNGLENABLEVERTEXATTRIBARRAYPROC)gl_proc("glEnableVertexAttribArray");
  pglDispatchCompute          = (PFNGLDISPATCHCOMPUTEPROC)gl_proc("glDispatchCompute");
  pglMemoryBarrier            = (PFNGLMEMORYBARRIERPROC)gl_proc("glMemoryBarrier");
  pglBindImageTexture         = (PFNGLBINDIMAGETEXTUREPROC)gl_proc("glBindImageTexture");
  pglGenQueries               = (PFNGLGENQUERIESPROC)gl_proc("glGenQueries");
  pglBeginQuery               = (PFNGLBEGINQUERYPROC)gl_proc("glBeginQuery");
  pglEndQuery                 = (PFNGLENDQUERYPROC)gl_proc("glEndQuery");
  pglGetQueryObjectiv         = (PFNGLGETQUERYOBJECTIVPROC)gl_proc("glGetQueryObjectiv");
  pglGetQueryObjectui64v      = (PFNGLGETQUERYOBJECTUI64VPROC)gl_proc("glGetQueryObjectui64v");

  return (pglCreateShader && pglGenFramebuffers && pglGenVertexArrays && pglGenBuffers &&
          pglDispatchCompute && pglBindImageTexture && pglMemoryBarrier) ? 1 : 0;
}

// ============================================================================
// MATH LIBRARY (3D VECTORS, COLUMN-MAJOR MAT4, HALTON TAA, PRNG)
// ============================================================================
#define PI_F  3.14159265359f
#define TAU_F 6.28318530718f

typedef struct { float x, y, z; } Vec3;

static float clampf(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
static float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static float smoothstep_f(float x) { x = clampf(x, 0.0f, 1.0f); return x * x * (3.0f - 2.0f * x); }

static Vec3 v3(float x, float y, float z) { Vec3 r = {x, y, z}; return r; }
static Vec3 v3_add(Vec3 a, Vec3 b) { return v3(a.x + b.x, a.y + b.y, a.z + b.z); }
static Vec3 v3_sub(Vec3 a, Vec3 b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static Vec3 v3_mul(Vec3 a, float s) { return v3(a.x * s, a.y * s, a.z * s); }
static float v3_dot(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static Vec3 v3_cross(Vec3 a, Vec3 b) {
  return v3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}
static float v3_len(Vec3 a) { return sqrtf(v3_dot(a, a)); }
static Vec3 v3_norm(Vec3 a) {
  float l = v3_len(a);
  return (l > 1e-6f) ? v3_mul(a, 1.0f / l) : v3(0.0f, 0.0f, -1.0f);
}
static Vec3 v3_lerp(Vec3 a, Vec3 b, float t) {
  return v3(lerpf(a.x, b.x, t), lerpf(a.y, b.y, t), lerpf(a.z, b.z, t));
}

static uint32_t g_rngState = 0x57A8F09Eu;
static float frand01(void) {
  uint32_t x = g_rngState;
  x ^= x << 13; x ^= x >> 17; x ^= x << 5;
  g_rngState = x;
  return (float)(x & 0x00FFFFFFu) / 16777216.0f;
}
static float frand_range(float a, float b) { return a + (b - a) * frand01(); }

static void mat4_identity(float m[16]) {
  memset(m, 0, 16 * sizeof(float));
  m[0] = m[5] = m[10] = m[15] = 1.0f;
}

static void mat4_mul(float out[16], const float a[16], const float b[16]) {
  float r[16];
  for (int c = 0; c < 4; c++) {
    for (int row = 0; row < 4; row++) {
      r[c * 4 + row] =
        a[0 * 4 + row] * b[c * 4 + 0] +
        a[1 * 4 + row] * b[c * 4 + 1] +
        a[2 * 4 + row] * b[c * 4 + 2] +
        a[3 * 4 + row] * b[c * 4 + 3];
    }
  }
  memcpy(out, r, sizeof(r));
}

static void mat4_perspective(float m[16], float fovY, float aspect, float zn, float zf) {
  memset(m, 0, 16 * sizeof(float));
  float f = 1.0f / tanf(fovY * 0.5f);
  m[0]  = f / aspect;
  m[5]  = f;
  m[10] = (zf + zn) / (zn - zf);
  m[11] = -1.0f;
  m[14] = (2.0f * zf * zn) / (zn - zf);
}

static void mat4_lookat(float m[16], Vec3 eye, Vec3 center, Vec3 upHint) {
  Vec3 f = v3_norm(v3_sub(center, eye));
  Vec3 r = v3_norm(v3_cross(f, upHint));
  Vec3 u = v3_cross(r, f);
  mat4_identity(m);
  m[0] = r.x;  m[4] = r.y;  m[8]  = r.z;  m[12] = -v3_dot(r, eye);
  m[1] = u.x;  m[5] = u.y;  m[9]  = u.z;  m[13] = -v3_dot(u, eye);
  m[2] = -f.x; m[6] = -f.y; m[10] = -f.z; m[14] =  v3_dot(f, eye);
}

// Local ship basis: -Z = fwd, +Y = up, +X = right (right-handed, det = +1)
static void mat4_from_ship(float m[16], Vec3 pos, Vec3 right, Vec3 up, Vec3 fwd, float scale) {
  mat4_identity(m);
  m[0]  = right.x * scale; m[1]  = right.y * scale; m[2]  = right.z * scale;
  m[4]  = up.x    * scale; m[5]  = up.y    * scale; m[6]  = up.z    * scale;
  m[8]  = -fwd.x  * scale; m[9]  = -fwd.y  * scale; m[10] = -fwd.z  * scale;
  m[12] = pos.x;           m[13] = pos.y;           m[14] = pos.z;
}

static void mat4_rot_z(float m[16], float rad) {
  mat4_identity(m);
  float c = cosf(rad), s = sinf(rad);
  m[0] = c; m[1] = s; m[4] = -s; m[5] = c;
}

static void mat4_translate(float m[16], float x, float y, float z) {
  mat4_identity(m);
  m[12] = x; m[13] = y; m[14] = z;
}

static void mat4_scale_xyz(float m[16], float sx, float sy, float sz) {
  mat4_identity(m);
  m[0] = sx; m[5] = sy; m[10] = sz;
}

static int mat4_invert(float out[16], const float m[16]) {
  float inv[16];
  inv[0]  =  m[5]*m[10]*m[15] - m[5]*m[11]*m[14] - m[9]*m[6]*m[15] + m[9]*m[7]*m[14] + m[13]*m[6]*m[11] - m[13]*m[7]*m[10];
  inv[4]  = -m[4]*m[10]*m[15] + m[4]*m[11]*m[14] + m[8]*m[6]*m[15] - m[8]*m[7]*m[14] - m[12]*m[6]*m[11] + m[12]*m[7]*m[10];
  inv[8]  =  m[4]*m[9]*m[15]  - m[4]*m[11]*m[13] - m[8]*m[5]*m[15] + m[8]*m[7]*m[13] + m[12]*m[5]*m[11] - m[12]*m[7]*m[9];
  inv[12] = -m[4]*m[9]*m[14]  + m[4]*m[10]*m[13] + m[8]*m[5]*m[14] - m[8]*m[6]*m[13] - m[12]*m[5]*m[10] + m[12]*m[6]*m[9];
  inv[1]  = -m[1]*m[10]*m[15] + m[1]*m[11]*m[14] + m[9]*m[2]*m[15] - m[9]*m[3]*m[14] - m[13]*m[2]*m[11] + m[13]*m[3]*m[10];
  inv[5]  =  m[0]*m[10]*m[15] - m[0]*m[11]*m[14] - m[8]*m[2]*m[15] + m[8]*m[3]*m[14] + m[12]*m[2]*m[11] - m[12]*m[3]*m[10];
  inv[9]  = -m[0]*m[9]*m[15]  + m[0]*m[11]*m[13] + m[8]*m[1]*m[15] - m[8]*m[3]*m[13] - m[12]*m[1]*m[11] + m[12]*m[3]*m[9];
  inv[13] =  m[0]*m[9]*m[14]  - m[0]*m[10]*m[13] - m[8]*m[1]*m[14] + m[8]*m[2]*m[13] + m[12]*m[1]*m[10] - m[12]*m[2]*m[9];
  inv[2]  =  m[1]*m[6]*m[15]  - m[1]*m[7]*m[14]  - m[5]*m[2]*m[15] + m[5]*m[3]*m[14] + m[13]*m[2]*m[7]  - m[13]*m[3]*m[6];
  inv[6]  = -m[0]*m[6]*m[15]  + m[0]*m[7]*m[14]  + m[4]*m[2]*m[15] - m[4]*m[3]*m[14] - m[12]*m[2]*m[7]  + m[12]*m[3]*m[6];
  inv[10] =  m[0]*m[5]*m[15]  - m[0]*m[7]*m[13]  - m[4]*m[1]*m[15] + m[4]*m[3]*m[13] + m[12]*m[1]*m[7]  - m[12]*m[3]*m[5];
  inv[14] = -m[0]*m[5]*m[14]  + m[0]*m[6]*m[13]  + m[4]*m[1]*m[14] - m[4]*m[2]*m[13] - m[12]*m[1]*m[6]  + m[12]*m[2]*m[5];
  inv[3]  = -m[1]*m[6]*m[11]  + m[1]*m[7]*m[10]  + m[5]*m[2]*m[11] - m[5]*m[3]*m[10] - m[9]*m[2]*m[7]   + m[9]*m[3]*m[6];
  inv[7]  =  m[0]*m[6]*m[11]  - m[0]*m[7]*m[10]  - m[4]*m[2]*m[11] + m[4]*m[3]*m[10] + m[8]*m[2]*m[7]   - m[8]*m[3]*m[6];
  inv[11] = -m[0]*m[5]*m[11]  + m[0]*m[7]*m[9]   + m[4]*m[1]*m[11] - m[4]*m[3]*m[9]  - m[8]*m[1]*m[7]   + m[8]*m[3]*m[5];
  inv[15] =  m[0]*m[5]*m[10]  - m[0]*m[6]*m[9]   - m[4]*m[1]*m[10] + m[4]*m[2]*m[9]  + m[8]*m[1]*m[6]   - m[8]*m[2]*m[5];
  float det = m[0]*inv[0] + m[1]*inv[4] + m[2]*inv[8] + m[3]*inv[12];
  if (fabsf(det) < 1e-12f) return 0;
  float idet = 1.0f / det;
  for (int i = 0; i < 16; i++) out[i] = inv[i] * idet;
  return 1;
}

static int project_to_uv(const float vp[16], Vec3 p, float outUv[2], float *outClipZ) {
  float cx = vp[0]*p.x + vp[4]*p.y + vp[8]*p.z  + vp[12];
  float cy = vp[1]*p.x + vp[5]*p.y + vp[9]*p.z  + vp[13];
  float cz = vp[2]*p.x + vp[6]*p.y + vp[10]*p.z + vp[14];
  float cw = vp[3]*p.x + vp[7]*p.y + vp[11]*p.z + vp[15];
  if (outClipZ) *outClipZ = cw;
  if (cw <= 0.1f) {
    // Behind camera: flip direction for off-screen edge arrow
    float invW = 1.0f / (fabsf(cw) + 0.1f);
    outUv[0] = 0.5f - (cx * invW) * 0.5f;
    outUv[1] = 0.5f - (cy * invW) * 0.5f;
    return 0;
  }
  outUv[0] = (cx / cw) * 0.5f + 0.5f;
  outUv[1] = (cy / cw) * 0.5f + 0.5f;
  return (cz >= -cw && outUv[0] >= 0.0f && outUv[0] <= 1.0f && outUv[1] >= 0.0f && outUv[1] <= 1.0f) ? 1 : 0;
}

static float halton_seq(int index, int base) {
  float f = 1.0f, r = 0.0f;
  int i = index;
  while (i > 0) { f /= (float)base; r += f * (float)(i % base); i /= base; }
  return r;
}
static float g_halton[16][2];
static void init_halton(void) {
  for (int i = 0; i < 16; i++) {
    g_halton[i][0] = halton_seq(i + 1, 2) - 0.5f;
    g_halton[i][1] = halton_seq(i + 1, 3) - 0.5f;
  }
}

// ============================================================================
// REAL-TIME PROCEDURAL WINMM STEREO AUDIO SYNTHESIZER (ZERO .WAV FILES)
// ============================================================================
#define AUDIO_SR        44100
#define AUDIO_BUF_COUNT 4
#define AUDIO_BUF_SMPS  1024
#define MAX_VOICES      24

enum {
  SFX_LASER_RED = 1,
  SFX_LASER_GREEN,
  SFX_TORPEDO,
  SFX_EXPLOSION,
  SFX_BIG_BOOM,
  SFX_SHIELD_HIT,
  SFX_LOCKON,
  SFX_SFOIL,
  SFX_SPLASH_CHORD,
  SFX_UI_HOVER,
  SFX_UI_CLICK
};

typedef struct {
  int   active;
  int   type;
  float t;
  float dur;
  float vol;
  float pan;
  float pitch;
  float phase;
  float lpState;
} SynthVoice;

static HWAVEOUT g_hWaveOut = NULL;
static HANDLE   g_audioThread = NULL;
static volatile int g_audioRunning = 0;
static volatile int g_audioMuted = 0;
static volatile float g_audioThrottle = 0.35f;
static volatile float g_audioBoost = 0.0f;
static volatile float g_audioEngineVol = 0.0f;
static CRITICAL_SECTION g_audioCS;
static SynthVoice g_voices[MAX_VOICES];
static WAVEHDR  g_waveHdrs[AUDIO_BUF_COUNT];
static int16_t  g_waveBufs[AUDIO_BUF_COUNT][AUDIO_BUF_SMPS * 2];
static uint32_t g_audioNoise = 0x12345678u;

static float audio_white(void) {
  uint32_t x = g_audioNoise;
  x ^= x << 13; x ^= x >> 17; x ^= x << 5;
  g_audioNoise = x;
  return ((float)(x & 0xFFFFu) / 32767.5f) - 1.0f;
}

static void audio_play_sfx(int type, float vol, float pan, float pitch) {
  if (!g_audioRunning || g_audioMuted) return;
  EnterCriticalSection(&g_audioCS);
  int slot = -1;
  float oldest = -1.0f;
  for (int i = 0; i < MAX_VOICES; i++) {
    if (!g_voices[i].active) { slot = i; break; }
    if (g_voices[i].t > oldest) { oldest = g_voices[i].t; slot = i; }
  }
  if (slot >= 0) {
    SynthVoice *v = &g_voices[slot];
    memset(v, 0, sizeof(*v));
    v->active = 1;
    v->type = type;
    v->vol = vol;
    v->pan = clampf(pan, -0.85f, 0.85f);
    v->pitch = pitch;
    if      (type == SFX_LASER_RED)   v->dur = 0.19f;
    else if (type == SFX_LASER_GREEN) v->dur = 0.16f;
    else if (type == SFX_TORPEDO)     v->dur = 0.58f;
    else if (type == SFX_EXPLOSION)   v->dur = 0.95f;
    else if (type == SFX_BIG_BOOM)    v->dur = 2.40f;
    else if (type == SFX_SHIELD_HIT)  v->dur = 0.24f;
    else if (type == SFX_LOCKON)      v->dur = 0.09f;
    else if (type == SFX_SPLASH_CHORD)v->dur = 3.85f;
    else if (type == SFX_UI_HOVER)    v->dur = 0.055f;
    else if (type == SFX_UI_CLICK)    v->dur = 0.12f;
    else                              v->dur = 0.32f;
  }
  LeaveCriticalSection(&g_audioCS);
}

static DWORD WINAPI audio_thread_proc(LPVOID param) {
  (void)param;
  float engPhase1 = 0.0f, engPhase2 = 0.0f, subPhase = 0.0f, brown = 0.0f;
  const float invSR = 1.0f / (float)AUDIO_SR;

  while (g_audioRunning) {
    int filledAny = 0;
    for (int b = 0; b < AUDIO_BUF_COUNT; b++) {
      if ((g_waveHdrs[b].dwFlags & WHDR_DONE) || !(g_waveHdrs[b].dwFlags & WHDR_INQUEUE)) {
        int16_t *out = g_waveBufs[b];
        float thr = g_audioThrottle;
        float bst = g_audioBoost;
        float engVol = g_audioEngineVol;
        int muted = g_audioMuted;

        EnterCriticalSection(&g_audioCS);
        for (int s = 0; s < AUDIO_BUF_SMPS; s++) {
          float mixL = 0.0f, mixR = 0.0f;
          if (!muted) {
            // Continuous X-Wing Ion Engine Hum + Afterburner Roar
            float baseF = 56.0f + thr * 42.0f + bst * 55.0f;
            engPhase1 += baseF * invSR; if (engPhase1 > 1.0f) engPhase1 -= 1.0f;
            engPhase2 += (baseF * 1.498f) * invSR; if (engPhase2 > 1.0f) engPhase2 -= 1.0f;
            subPhase  += 36.0f * invSR; if (subPhase > 1.0f) subPhase -= 1.0f;
            brown = (brown + 0.035f * audio_white()) / 1.035f;

            float eng = (sinf(engPhase1 * TAU_F) * 0.055f + sinf(engPhase2 * TAU_F) * 0.030f
                      + sinf(subPhase * TAU_F) * 0.035f
                      + brown * (0.045f + bst * 0.14f)) * engVol;
            mixL += eng; mixR += eng;

            // Mix polyphonic SFX voices
            for (int i = 0; i < MAX_VOICES; i++) {
              SynthVoice *v = &g_voices[i];
              if (!v->active) continue;
              v->t += invSR;
              if (v->t >= v->dur) { v->active = 0; continue; }
              float u = v->t / v->dur;
              float smp = 0.0f;

              if (v->type == SFX_LASER_RED) {
                // Iconic Star Wars blaster chirp: sharp exponential downward sweep + FM grit
                float f = (1650.0f * expf(-v->t * 24.0f) + 140.0f) * v->pitch;
                v->phase += f * invSR;
                float env = expf(-u * 4.5f) * (1.0f - expf(-v->t * 600.0f));
                float w = sinf(v->phase * TAU_F + 0.9f * sinf(v->phase * TAU_F * 2.0f));
                smp = (w * 0.85f + audio_white() * 0.18f * expf(-u * 12.0f)) * env;
              } else if (v->type == SFX_LASER_GREEN) {
                // TIE-style screeching dual-harmonic green laser
                float f = (2250.0f * expf(-v->t * 28.0f) + 210.0f) * v->pitch;
                v->phase += f * invSR;
                float env = expf(-u * 5.0f);
                float sq = (sinf(v->phase * TAU_F) > 0.0f) ? 0.55f : -0.55f;
                smp = (sq * 0.55f + sinf(v->phase * TAU_F * 1.5f) * 0.45f) * env;
              } else if (v->type == SFX_TORPEDO) {
                // Rising plasma whoosh + resonant lock whistle
                float f = (320.0f + 620.0f * u) * v->pitch;
                v->phase += f * invSR;
                v->lpState += 0.12f * (audio_white() - v->lpState);
                float env = sinf(u * PI_F);
                smp = (v->lpState * 0.9f + sinf(v->phase * TAU_F) * 0.35f) * env;
              } else if (v->type == SFX_EXPLOSION || v->type == SFX_BIG_BOOM) {
                // Deep cinematic plasma detonation: sub-bass punch + cracking filtered noise
                float decay = (v->type == SFX_BIG_BOOM) ? 2.4f : 4.2f;
                float subF = ((v->type == SFX_BIG_BOOM) ? 68.0f : 95.0f) * expf(-v->t * 4.5f) + 28.0f;
                v->phase += subF * invSR;
                float cutoff = (v->type == SFX_BIG_BOOM) ? (0.18f * (1.0f - 0.7f * u)) : (0.28f * (1.0f - 0.6f * u));
                v->lpState += cutoff * (audio_white() - v->lpState);
                float env = expf(-u * decay) * (1.0f - expf(-v->t * 180.0f));
                smp = (v->lpState * 1.45f + sinf(v->phase * TAU_F) * 0.75f * expf(-u * 3.0f)) * env;
              } else if (v->type == SFX_SHIELD_HIT) {
                float f = (240.0f + 160.0f * sinf(v->t * 95.0f)) * v->pitch;
                v->phase += f * invSR;
                smp = (sinf(v->phase * TAU_F) * 0.6f + audio_white() * 0.35f) * expf(-u * 5.0f);
              } else if (v->type == SFX_LOCKON) {
                v->phase += 1760.0f * v->pitch * invSR;
                smp = sinf(v->phase * TAU_F) * expf(-u * 6.0f) * 0.45f;
              } else if (v->type == SFX_SPLASH_CHORD) {
                // Cinematic DULA Game Studios 4-second cosmic synth chord swell (D2-A2-D3-F#3-A3)
                float swell = sinf(clampf(u / 0.55f, 0.0f, 1.0f) * PI_F * 0.5f) * powf(clampf(1.0f - (u - 0.65f) / 0.35f, 0.0f, 1.0f), 1.6f);
                float rise = 0.88f + 0.12f * smoothstep_f(u * 2.2f);
                float t0 = v->t;
                float c1 = sinf(TAU_F * 73.42f  * rise * t0) * 0.38f;
                float c2 = sinf(TAU_F * 110.00f * rise * t0) * 0.28f;
                float c3 = sinf(TAU_F * 146.83f * rise * t0 + 0.35f * sinf(t0 * 2.1f)) * 0.22f;
                float c4 = sinf(TAU_F * 185.00f * rise * t0) * 0.16f * smoothstep_f((u - 0.12f) * 3.0f);
                float c5 = sinf(TAU_F * 220.00f * rise * t0 + 0.25f * sinf(t0 * 3.4f)) * 0.14f * smoothstep_f((u - 0.22f) * 3.0f);
                float boom = sinf(TAU_F * (52.0f * expf(-t0 * 3.2f) + 28.0f) * t0) * expf(-t0 * 2.2f) * 0.45f;
                smp = (c1 + c2 + c3 + c4 + c5) * swell + boom;
              } else if (v->type == SFX_UI_HOVER) {
                v->phase += (880.0f + 220.0f * u) * invSR;
                smp = sinf(v->phase * TAU_F) * expf(-u * 6.0f) * 0.32f;
              } else if (v->type == SFX_UI_CLICK) {
                v->phase += (1240.0f - 460.0f * u) * invSR;
                smp = (sinf(v->phase * TAU_F) * 0.7f + sinf(v->phase * TAU_F * 2.0f) * 0.3f) * expf(-u * 7.0f) * 0.55f;
              } else {
                // S-foil servo whirr
                v->phase += (180.0f + 220.0f * u) * invSR;
                smp = sinf(v->phase * TAU_F) * sinf(u * PI_F) * 0.35f;
              }

              float gL = v->vol * (1.0f - clampf(v->pan, 0.0f, 1.0f));
              float gR = v->vol * (1.0f + clampf(v->pan, -1.0f, 0.0f));
              mixL += smp * gL;
              mixR += smp * gR;
            }
          }
          // Soft tanh limiter prevents clipping during intense dogfights
          mixL = tanhf(mixL * 0.92f);
          mixR = tanhf(mixR * 0.92f);
          out[s * 2 + 0] = (int16_t)(mixL * 30000.0f);
          out[s * 2 + 1] = (int16_t)(mixR * 30000.0f);
        }
        LeaveCriticalSection(&g_audioCS);

        waveOutWrite(g_hWaveOut, &g_waveHdrs[b], sizeof(WAVEHDR));
        filledAny = 1;
      }
    }
    if (!filledAny) Sleep(5);
  }
  return 0;
}

static void audio_init(void) {
  InitializeCriticalSection(&g_audioCS);
  memset(g_voices, 0, sizeof(g_voices));
  WAVEFORMATEX wf;
  memset(&wf, 0, sizeof(wf));
  wf.wFormatTag      = WAVE_FORMAT_PCM;
  wf.nChannels       = 2;
  wf.nSamplesPerSec  = AUDIO_SR;
  wf.wBitsPerSample  = 16;
  wf.nBlockAlign     = 4;
  wf.nAvgBytesPerSec = AUDIO_SR * 4;
  if (waveOutOpen(&g_hWaveOut, WAVE_MAPPER, &wf, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
    g_hWaveOut = NULL;
    return;
  }
  memset(g_waveBufs, 0, sizeof(g_waveBufs));
  for (int b = 0; b < AUDIO_BUF_COUNT; b++) {
    memset(&g_waveHdrs[b], 0, sizeof(WAVEHDR));
    g_waveHdrs[b].lpData = (LPSTR)g_waveBufs[b];
    g_waveHdrs[b].dwBufferLength = AUDIO_BUF_SMPS * 4;
    waveOutPrepareHeader(g_hWaveOut, &g_waveHdrs[b], sizeof(WAVEHDR));
  }
  g_audioRunning = 1;
  g_audioThread = CreateThread(NULL, 0, audio_thread_proc, NULL, 0, NULL);
}

static void audio_shutdown(void) {
  if (g_audioRunning) {
    g_audioRunning = 0;
    if (g_audioThread) { WaitForSingleObject(g_audioThread, 500); CloseHandle(g_audioThread); g_audioThread = NULL; }
  }
  if (g_hWaveOut) {
    waveOutReset(g_hWaveOut);
    for (int b = 0; b < AUDIO_BUF_COUNT; b++) waveOutUnprepareHeader(g_hWaveOut, &g_waveHdrs[b], sizeof(WAVEHDR));
    waveOutClose(g_hWaveOut);
    g_hWaveOut = NULL;
  }
  DeleteCriticalSection(&g_audioCS);
}


// ============================================================================
// PROCEDURAL RUNTIME WIN32 ICON BUILDER (TASKBAR, TITLEBAR & ALT-TAB ICON)
// ============================================================================
static HICON create_runtime_icon(int size) {
  BITMAPV5HEADER bi;
  memset(&bi, 0, sizeof(bi));
  bi.bV5Size        = sizeof(BITMAPV5HEADER);
  bi.bV5Width       = size;
  bi.bV5Height      = -size; // top-down DIB
  bi.bV5Planes      = 1;
  bi.bV5BitCount    = 32;
  bi.bV5Compression = BI_BITFIELDS;
  bi.bV5RedMask     = 0x00FF0000u;
  bi.bV5GreenMask   = 0x0000FF00u;
  bi.bV5BlueMask    = 0x000000FFu;
  bi.bV5AlphaMask   = 0xFF000000u;

  HDC screenDC = GetDC(NULL);
  uint32_t *bits = NULL;
  HBITMAP hColor = CreateDIBSection(screenDC, (BITMAPINFO *)&bi, DIB_RGB_COLORS, (void **)&bits, NULL, 0);
  ReleaseDC(NULL, screenDC);
  if (!hColor || !bits) return NULL;

  float cx = (float)(size - 1) * 0.5f;
  float cy = (float)(size - 1) * 0.5f;
  float rad = (float)size * 0.48f;

  for (int y = 0; y < size; y++) {
    for (int x = 0; x < size; x++) {
      float nx = ((float)x - cx) / rad;
      float ny = ((float)y - cy) / rad;
      float d = sqrtf(nx * nx + ny * ny);
      if (d > 1.03f) { bits[y * size + x] = 0; continue; }

      float alpha = clampf((1.02f - d) / 0.06f, 0.0f, 1.0f);
      float r = 0.03f + 0.04f * fmaxf(0.0f, 1.0f - d);
      float g = 0.05f + 0.07f * fmaxf(0.0f, 1.0f - d);
      float b = 0.11f + 0.12f * fmaxf(0.0f, 1.0f - d);

      float ring = expf(-powf((d - 0.90f) / 0.055f, 2.0f));
      r += 0.14f * ring; g += 0.72f * ring; b += 1.00f * ring;

      float dd = sqrtf((nx + 0.25f) * (nx + 0.25f) + (ny + 0.22f) * (ny + 0.22f));
      if (dd < 0.52f) {
        float lit = clampf(0.35f - (nx + 0.15f) * 0.8f - (ny + 0.20f) * 0.5f, 0.0f, 1.0f);
        float sh = 0.10f + 0.22f * lit;
        if (sqrtf((nx + 0.36f)*(nx + 0.36f) + (ny + 0.30f)*(ny + 0.30f)) < 0.16f) sh *= 0.65f;
        r = r * 0.4f + sh * 0.65f; g = g * 0.4f + sh * 0.72f; b = b * 0.4f + sh * 0.84f;
      }

      float th = sqrtf((nx * 1.1f)*(nx * 1.1f) + ((ny - 0.42f) * 1.35f)*((ny - 0.42f) * 1.35f));
      float flare = expf(-powf(th / 0.34f, 2.0f));
      r += 0.95f * flare; g += 0.12f * flare; b += 0.41f * flare;

      float ax = fabsf(nx);
      int inShip = 0; float shipShade = 0.0f;
      if (ny >= -0.68f && ny <= 0.42f) {
        float hw = 0.035f + 0.115f * fmaxf(0.0f, (ny + 0.68f) / 1.10f);
        if (ax <= hw) {
          inShip = 1;
          shipShade = 0.86f - 0.25f * (ax / fmaxf(hw, 0.01f));
          if (ny >= -0.42f && ny <= -0.10f && ax < hw * 0.48f) { r = 0.88f; g = 0.14f; b = 0.14f; shipShade = -1.0f; }
          else if (ny >= -0.05f && ny <= 0.20f && ax < hw * 0.52f) { r = 0.08f; g = 0.16f; b = 0.26f; shipShade = -1.0f; }
        }
      }
      if (ny >= 0.02f && ny <= 0.46f && ax >= 0.09f && ax <= 0.72f) {
        float yt = 0.04f + (ax - 0.09f) * 0.30f;
        float yb = 0.34f + (ax - 0.09f) * 0.18f;
        if (ny >= yt && ny <= yb) {
          inShip = 1; shipShade = 0.82f - 0.12f * ax;
          if (ax >= 0.32f && ax <= 0.46f) { r = 0.86f; g = 0.14f; b = 0.14f; shipShade = -1.0f; }
        }
      }
      if (ax >= 0.66f && ax <= 0.74f && ny >= -0.28f && ny <= 0.46f) { inShip = 1; shipShade = 0.75f; }
      if (inShip && shipShade >= 0.0f) { r = shipShade; g = shipShade * 1.02f; b = fminf(1.0f, shipShade * 1.07f); }

      float ld = fabsf((ny + 0.10f) + nx * 0.55f - 0.32f);
      if (ld < 0.045f && nx > 0.15f && ny < 0.15f) {
        float lg = expf(-powf(ld / 0.028f, 2.0f));
        r = lerpf(r, 0.35f, lg); g = lerpf(g, 1.00f, lg); b = lerpf(b, 0.45f, lg);
      }

      uint32_t R = (uint32_t)(clampf(r, 0.0f, 1.0f) * 255.0f);
      uint32_t G = (uint32_t)(clampf(g, 0.0f, 1.0f) * 255.0f);
      uint32_t B = (uint32_t)(clampf(b, 0.0f, 1.0f) * 255.0f);
      uint32_t A = (uint32_t)(clampf(alpha, 0.0f, 1.0f) * 255.0f);
      bits[y * size + x] = (A << 24) | (R << 16) | (G << 8) | B;
    }
  }

  HBITMAP hMask = CreateBitmap(size, size, 1, 1, NULL);
  ICONINFO ii;
  memset(&ii, 0, sizeof(ii));
  ii.fIcon    = TRUE;
  ii.hbmMask  = hMask;
  ii.hbmColor = hColor;
  HICON hIcon = CreateIconIndirect(&ii);
  DeleteObject(hMask);
  DeleteObject(hColor);
  return hIcon;
}

// ============================================================================
// PROCEDURAL 3D MESH BUILDER (STARFIGHTERS, DREADNOUGHT, FREIGHTER, BEAMS)
// ============================================================================
typedef struct {
  float pos[3];
  float norm[3];
  float uv[2];
  float col[3];
  float matId;
} Vertex;

typedef struct {
  GLuint vao;
  GLuint vbo;
  int    vertCount;
} Mesh;

typedef struct {
  Vertex *data;
  int     count;
  int     cap;
} MeshBuilder;

static void mb_init(MeshBuilder *mb) {
  mb->cap = 4096;
  mb->count = 0;
  mb->data = (Vertex *)malloc((size_t)mb->cap * sizeof(Vertex));
}

static void mb_free(MeshBuilder *mb) {
  free(mb->data);
  mb->data = NULL;
  mb->count = mb->cap = 0;
}

static void mb_push(MeshBuilder *mb, Vec3 p, Vec3 n, float u, float v, Vec3 col, float matId) {
  if (mb->count >= mb->cap) {
    mb->cap *= 2;
    mb->data = (Vertex *)realloc(mb->data, (size_t)mb->cap * sizeof(Vertex));
  }
  Vertex *vt = &mb->data[mb->count++];
  vt->pos[0] = p.x; vt->pos[1] = p.y; vt->pos[2] = p.z;
  vt->norm[0] = n.x; vt->norm[1] = n.y; vt->norm[2] = n.z;
  vt->uv[0] = u; vt->uv[1] = v;
  vt->col[0] = col.x; vt->col[1] = col.y; vt->col[2] = col.z;
  vt->matId = matId;
}

static void mb_tri(MeshBuilder *mb, Vec3 a, Vec3 b, Vec3 c, Vec3 col, float matId) {
  Vec3 n = v3_norm(v3_cross(v3_sub(b, a), v3_sub(c, a)));
  mb_push(mb, a, n, 0.0f, 0.0f, col, matId);
  mb_push(mb, b, n, 1.0f, 0.0f, col, matId);
  mb_push(mb, c, n, 0.5f, 1.0f, col, matId);
}

static void mb_quad(MeshBuilder *mb, Vec3 a, Vec3 b, Vec3 c, Vec3 d, Vec3 col, float matId) {
  Vec3 n = v3_norm(v3_cross(v3_sub(b, a), v3_sub(c, a)));
  mb_push(mb, a, n, 0.0f, 0.0f, col, matId);
  mb_push(mb, b, n, 1.0f, 0.0f, col, matId);
  mb_push(mb, c, n, 1.0f, 1.0f, col, matId);
  mb_push(mb, a, n, 0.0f, 0.0f, col, matId);
  mb_push(mb, c, n, 1.0f, 1.0f, col, matId);
  mb_push(mb, d, n, 0.0f, 1.0f, col, matId);
}

// Tapered box along Z (z0 = front, z1 = back) with distinct front/back half-extents
static void mb_taper_box(MeshBuilder *mb, Vec3 c0, float wx0, float hy0, Vec3 c1, float wx1, float hy1, Vec3 col, float matId) {
  Vec3 fbl = v3(c0.x - wx0, c0.y - hy0, c0.z);
  Vec3 fbr = v3(c0.x + wx0, c0.y - hy0, c0.z);
  Vec3 ftr = v3(c0.x + wx0, c0.y + hy0, c0.z);
  Vec3 ftl = v3(c0.x - wx0, c0.y + hy0, c0.z);

  Vec3 bbl = v3(c1.x - wx1, c1.y - hy1, c1.z);
  Vec3 bbr = v3(c1.x + wx1, c1.y - hy1, c1.z);
  Vec3 btr = v3(c1.x + wx1, c1.y + hy1, c1.z);
  Vec3 btl = v3(c1.x - wx1, c1.y + hy1, c1.z);

  // Front (-Z), Back (+Z), Top (+Y), Bottom (-Y), Right (+X), Left (-X)
  mb_quad(mb, fbr, fbl, ftl, ftr, col, matId);
  mb_quad(mb, bbl, bbr, btr, btl, col, matId);
  mb_quad(mb, ftl, btl, btr, ftr, col, matId);
  mb_quad(mb, fbr, bbr, bbl, fbl, col, matId);
  mb_quad(mb, ftr, btr, bbr, fbr, col, matId);
  mb_quad(mb, fbl, bbl, btl, ftl, col, matId);
}

static void mb_box(MeshBuilder *mb, Vec3 center, Vec3 halfExt, Vec3 col, float matId) {
  mb_taper_box(mb,
    v3(center.x, center.y, center.z - halfExt.z), halfExt.x, halfExt.y,
    v3(center.x, center.y, center.z + halfExt.z), halfExt.x, halfExt.y,
    col, matId);
}

// Cylinder oriented along Z axis (z0 to z1)
static void mb_cyl_z(MeshBuilder *mb, float cx, float cy, float z0, float z1, float r0, float r1, int segs,
                     Vec3 sideCol, float sideMat, Vec3 cap0Col, float cap0Mat, Vec3 cap1Col, float cap1Mat) {
  for (int i = 0; i < segs; i++) {
    float a0 = (float)i * TAU_F / (float)segs;
    float a1 = (float)(i + 1) * TAU_F / (float)segs;
    float c0 = cosf(a0), s0 = sinf(a0);
    float c1 = cosf(a1), s1 = sinf(a1);
    Vec3 p00 = v3(cx + c0 * r0, cy + s0 * r0, z0);
    Vec3 p10 = v3(cx + c1 * r0, cy + s1 * r0, z0);
    Vec3 p11 = v3(cx + c1 * r1, cy + s1 * r1, z1);
    Vec3 p01 = v3(cx + c0 * r1, cy + s0 * r1, z1);
    Vec3 n0 = v3(c0, s0, 0.0f);
    Vec3 n1 = v3(c1, s1, 0.0f);
    float u0 = (float)i / (float)segs, u1 = (float)(i + 1) / (float)segs;
    mb_push(mb, p00, n0, u0, 0.0f, sideCol, sideMat);
    mb_push(mb, p01, n0, u0, 1.0f, sideCol, sideMat);
    mb_push(mb, p11, n1, u1, 1.0f, sideCol, sideMat);
    mb_push(mb, p00, n0, u0, 0.0f, sideCol, sideMat);
    mb_push(mb, p11, n1, u1, 1.0f, sideCol, sideMat);
    mb_push(mb, p10, n1, u1, 0.0f, sideCol, sideMat);
    if (cap0Mat >= 0.0f) mb_tri(mb, v3(cx, cy, z0), p10, p00, cap0Col, cap0Mat);
    if (cap1Mat >= 0.0f) mb_tri(mb, v3(cx, cy, z1), p01, p11, cap1Col, cap1Mat);
  }
}

static void mb_sphere(MeshBuilder *mb, Vec3 center, float rx, float ry, float rz, int stacks, int slices, Vec3 col, float matId) {
  for (int j = 0; j < stacks; j++) {
    float v0 = (float)j / (float)stacks;
    float v1 = (float)(j + 1) / (float)stacks;
    float th0 = v0 * PI_F, th1 = v1 * PI_F;
    for (int i = 0; i < slices; i++) {
      float u0 = (float)i / (float)slices;
      float u1 = (float)(i + 1) / (float)slices;
      float ph0 = u0 * TAU_F, ph1 = u1 * TAU_F;
      Vec3 d00 = v3(sinf(th0)*cosf(ph0), cosf(th0), sinf(th0)*sinf(ph0));
      Vec3 d10 = v3(sinf(th0)*cosf(ph1), cosf(th0), sinf(th0)*sinf(ph1));
      Vec3 d11 = v3(sinf(th1)*cosf(ph1), cosf(th1), sinf(th1)*sinf(ph1));
      Vec3 d01 = v3(sinf(th1)*cosf(ph0), cosf(th1), sinf(th1)*sinf(ph0));
      Vec3 p00 = v3(center.x + d00.x*rx, center.y + d00.y*ry, center.z + d00.z*rz);
      Vec3 p10 = v3(center.x + d10.x*rx, center.y + d10.y*ry, center.z + d10.z*rz);
      Vec3 p11 = v3(center.x + d11.x*rx, center.y + d11.y*ry, center.z + d11.z*rz);
      Vec3 p01 = v3(center.x + d01.x*rx, center.y + d01.y*ry, center.z + d01.z*rz);
      mb_push(mb, p00, d00, u0, v0, col, matId);
      mb_push(mb, p01, d01, u0, v1, col, matId);
      mb_push(mb, p11, d11, u1, v1, col, matId);
      mb_push(mb, p00, d00, u0, v0, col, matId);
      mb_push(mb, p11, d11, u1, v1, col, matId);
      mb_push(mb, p10, d10, u1, v0, col, matId);
    }
  }
}

static Mesh mb_upload(MeshBuilder *mb) {
  Mesh m = {0, 0, mb->count};
  pglGenVertexArrays(1, &m.vao);
  pglBindVertexArray(m.vao);
  pglGenBuffers(1, &m.vbo);
  pglBindBuffer(GL_ARRAY_BUFFER, m.vbo);
  pglBufferData(GL_ARRAY_BUFFER, (GLsizeiptr_t)(mb->count * (int)sizeof(Vertex)), mb->data, GL_STATIC_DRAW);
  pglEnableVertexAttribArray(0);
  pglVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const void *)0);
  pglEnableVertexAttribArray(1);
  pglVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const void *)(3 * sizeof(float)));
  pglEnableVertexAttribArray(2);
  pglVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const void *)(6 * sizeof(float)));
  pglEnableVertexAttribArray(3);
  pglVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const void *)(8 * sizeof(float)));
  pglEnableVertexAttribArray(4);
  pglVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const void *)(11 * sizeof(float)));
  pglBindVertexArray(0);
  return m;
}

static void mesh_destroy(Mesh *m) {
  if (m->vbo) { pglDeleteBuffers(1, &m->vbo); m->vbo = 0; }
  if (m->vao) { pglDeleteVertexArrays(1, &m->vao); m->vao = 0; }
  m->vertCount = 0;
}

static Mesh g_meshXBody, g_meshXWing, g_meshTie, g_meshBomber, g_meshFreighter;
static Mesh g_meshDreadnought, g_meshRelay, g_meshBeam, g_meshPlume, g_meshCruiser;

// 1. X-Vanguard Fuselage (-Z nose, +Z rear)
static Mesh build_xwing_body(void) {
  MeshBuilder mb; mb_init(&mb);
  Vec3 hull = v3(0.58f, 0.59f, 0.60f);
  Vec3 dark = v3(0.18f, 0.19f, 0.22f);
  Vec3 red  = v3(0.68f, 0.11f, 0.10f);
  Vec3 glass= v3(0.05f, 0.08f, 0.12f);

  // Tapered nose cone & forward fuselage
  mb_taper_box(&mb, v3(0.0f, -0.02f, -3.55f), 0.14f, 0.12f, v3(0.0f, -0.01f, -2.55f), 0.28f, 0.22f, dark, 2.0f);
  mb_taper_box(&mb, v3(0.0f, -0.01f, -2.55f), 0.30f, 0.24f, v3(0.0f,  0.02f, -0.75f), 0.48f, 0.34f, hull, 0.0f);
  // Squadron red nose markings
  mb_taper_box(&mb, v3(0.0f,  0.22f, -2.10f), 0.14f, 0.04f, v3(0.0f,  0.34f, -0.95f), 0.24f, 0.04f, red,  1.0f);
  // Central armored core & rear engine fuselage
  mb_taper_box(&mb, v3(0.0f,  0.02f, -0.75f), 0.50f, 0.36f, v3(0.0f,  0.04f,  1.85f), 0.56f, 0.42f, hull, 0.0f);
  // Rear gunmetal bulkhead panel
  mb_box(&mb, v3(0.0f, 0.04f, 1.98f), v3(0.46f, 0.34f, 0.15f), dark, 2.0f);
  // Raised glossy cockpit canopy
  mb_taper_box(&mb, v3(0.0f,  0.35f, -0.82f), 0.24f, 0.12f, v3(0.0f,  0.52f,  0.25f), 0.32f, 0.22f, glass, 3.0f);
  mb_taper_box(&mb, v3(0.0f,  0.52f,  0.25f), 0.33f, 0.22f, v3(0.0f,  0.42f,  1.05f), 0.36f, 0.16f, hull,  0.0f);
  // Astromech droid dome behind cockpit
  mb_sphere(&mb, v3(0.0f, 0.54f, 1.18f), 0.21f, 0.21f, 0.21f, 8, 12, v3(0.22f, 0.38f, 0.72f), 0.0f);
  // Ventral chin keel
  mb_taper_box(&mb, v3(0.0f, -0.25f, -1.9f), 0.16f, 0.08f, v3(0.0f, -0.34f, 1.4f), 0.28f, 0.10f, dark, 2.0f);

  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

// 2. X-Vanguard Articulated Single Wing (+X side; rotated 4x for full X-foil)
static Mesh build_xwing_wing(void) {
  MeshBuilder mb; mb_init(&mb);
  Vec3 hull = v3(0.60f, 0.61f, 0.62f);
  Vec3 dark = v3(0.18f, 0.20f, 0.23f);
  Vec3 red  = v3(0.72f, 0.10f, 0.09f);
  Vec3 pink = v3(1.00f, 0.18f, 0.48f);

  // Main swept beveled wing blade extending from x=0.45 to x=3.15
  Vec3 rfl = v3(0.42f,  0.06f,  0.15f), rbl = v3(0.42f,  0.06f, 1.55f);
  Vec3 tfl = v3(3.12f,  0.04f,  0.72f), tbl = v3(3.12f,  0.04f, 1.48f);
  Vec3 rfd = v3(0.42f, -0.06f,  0.15f), rbd = v3(0.42f, -0.06f, 1.55f);
  Vec3 tfd = v3(3.12f, -0.04f,  0.72f), tbd = v3(3.12f, -0.04f, 1.48f);
  mb_quad(&mb, rfl, rbl, tbl, tfl, hull, 0.0f); // Top
  mb_quad(&mb, tfd, tbd, rbd, rfd, hull, 0.0f); // Bottom
  mb_quad(&mb, rfd, rfl, tfl, tfd, dark, 2.0f); // Leading edge
  mb_quad(&mb, tbd, tbl, rbl, rbd, dark, 2.0f); // Trailing edge
  mb_quad(&mb, tfd, tfl, tbl, tbd, dark, 2.0f); // Wingtip cap

  // Red squadron stripes on upper wing surface
  mb_box(&mb, v3(1.85f, 0.065f, 1.05f), v3(0.42f, 0.015f, 0.26f), red, 1.0f);
  mb_box(&mb, v3(1.85f, -0.065f, 1.05f), v3(0.42f, 0.015f, 0.26f), red, 1.0f);

  // Cylindrical Turbo-Ion Engine Nacelle mounted at wing root (x=0.92, y=0.18)
  mb_cyl_z(&mb, 0.92f, 0.22f, -0.15f, 1.75f, 0.30f, 0.27f, 14, hull, 0.0f, dark, 2.0f, dark, 2.0f);
  // Dark metallic rear exhaust nozzle shroud
  mb_cyl_z(&mb, 0.92f, 0.22f,  1.75f, 2.18f, 0.26f, 0.22f, 14, dark, 2.0f, dark, -1.0f, pink, 5.0f);
  // Blazing Pink/Magenta Ion Thruster Core (matId 5.0 = intense HDR magenta-pink glow!)
  mb_cyl_z(&mb, 0.92f, 0.22f,  2.10f, 2.30f, 0.19f, 0.15f, 12, pink, 5.0f, pink, -1.0f, pink, 5.0f);

  // Wingtip Laser Cannon Housing & Long Barrel extending forward (-Z)
  mb_box(&mb, v3(3.15f, 0.0f, 0.88f), v3(0.11f, 0.11f, 0.56f), hull, 0.0f);
  mb_cyl_z(&mb, 3.15f, 0.0f, -1.15f, 0.35f, 0.055f, 0.075f, 8, dark, 2.0f, dark, 2.0f, dark, -1.0f);
  // Forked flash suppressor tip
  mb_box(&mb, v3(3.15f, 0.0f, -1.25f), v3(0.085f, 0.085f, 0.14f), hull, 0.0f);

  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

// 3. Viper-TIE Interceptor (Iconic ball cockpit + twin hexagonal solar panels)
static Mesh build_tie_fighter(void) {
  MeshBuilder mb; mb_init(&mb);
  Vec3 steel = v3(0.42f, 0.45f, 0.50f);
  Vec3 dark  = v3(0.14f, 0.16f, 0.20f);
  Vec3 solar = v3(0.04f, 0.06f, 0.10f);
  Vec3 glass = v3(0.04f, 0.07f, 0.11f);
  Vec3 ion   = v3(0.45f, 0.95f, 1.00f);

  // Central spherical cockpit pod
  mb_sphere(&mb, v3(0.0f, 0.0f, 0.0f), 0.74f, 0.74f, 0.78f, 10, 14, steel, 0.0f);
  // Front faceted dark glass viewport
  mb_cyl_z(&mb, 0.0f, 0.02f, -0.82f, -0.58f, 0.42f, 0.50f, 8, dark, 2.0f, glass, 3.0f, dark, -1.0f);
  // Twin rear glowing ion vents
  mb_cyl_z(&mb, -0.18f, 0.0f, 0.65f, 0.86f, 0.11f, 0.10f, 8, dark, 2.0f, dark, -1.0f, ion, 6.0f);
  mb_cyl_z(&mb,  0.18f, 0.0f, 0.65f, 0.86f, 0.11f, 0.10f, 8, dark, 2.0f, dark, -1.0f, ion, 6.0f);
  // Twin chin blaster tips
  mb_cyl_z(&mb, -0.22f, -0.52f, -0.88f, -0.35f, 0.05f, 0.06f, 6, dark, 2.0f, dark, 2.0f, dark, -1.0f);
  mb_cyl_z(&mb,  0.22f, -0.52f, -0.88f, -0.35f, 0.05f, 0.06f, 6, dark, 2.0f, dark, 2.0f, dark, -1.0f);

  // Horizontal wing support pylons
  mb_box(&mb, v3(0.0f, 0.0f, 0.0f), v3(1.85f, 0.17f, 0.24f), steel, 0.0f);

  // Twin Hexagonal Solar Array Wings (left & right at x = +-1.85)
  for (int side = -1; side <= 1; side += 2) {
    float wx = (float)side * 1.85f;
    // Main tall hexagonal solar plate (matId 4.0 = solar grid shader)
    mb_box(&mb, v3(wx, 0.0f, 0.0f), v3(0.06f, 1.55f, 1.35f), solar, 4.0f);
    // Tapered upper & lower wing tips (Interceptor flair!)
    mb_taper_box(&mb, v3(wx,  1.55f, -1.35f), 0.07f, 0.07f, v3(wx - (float)side * 0.28f,  2.15f, -0.55f), 0.06f, 0.06f, steel, 0.0f);
    mb_taper_box(&mb, v3(wx, -1.55f, -1.35f), 0.07f, 0.07f, v3(wx - (float)side * 0.28f, -2.15f, -0.55f), 0.06f, 0.06f, steel, 0.0f);
    // Outer metallic structural frame struts
    mb_box(&mb, v3(wx,  1.56f, 0.0f), v3(0.09f, 0.09f, 1.42f), steel, 0.0f);
    mb_box(&mb, v3(wx, -1.56f, 0.0f), v3(0.09f, 0.09f, 1.42f), steel, 0.0f);
    mb_box(&mb, v3(wx, 0.0f, -1.36f), v3(0.09f, 1.58f, 0.09f), steel, 0.0f);
    mb_box(&mb, v3(wx, 0.0f,  1.36f), v3(0.09f, 1.58f, 0.09f), steel, 0.0f);
    // Cross-bracing ribs
    mb_box(&mb, v3(wx, 0.0f, 0.0f), v3(0.10f, 0.08f, 1.38f), steel, 0.0f);
    mb_box(&mb, v3(wx, 0.0f, 0.0f), v3(0.10f, 1.56f, 0.08f), steel, 0.0f);
  }

  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

// 4. Heavy Strike Bomber (Twin armored pods + bent solar arrays)
static Mesh build_bomber(void) {
  MeshBuilder mb; mb_init(&mb);
  Vec3 steel = v3(0.36f, 0.40f, 0.46f);
  Vec3 dark  = v3(0.15f, 0.17f, 0.20f);
  Vec3 solar = v3(0.04f, 0.06f, 0.10f);
  Vec3 amber = v3(1.00f, 0.45f, 0.12f);

  // Dual armored hulls
  mb_cyl_z(&mb, -0.68f, 0.0f, -1.35f, 1.25f, 0.56f, 0.60f, 12, steel, 0.0f, dark, 3.0f, dark, 2.0f);
  mb_cyl_z(&mb,  0.68f, 0.0f, -1.25f, 1.25f, 0.56f, 0.60f, 12, steel, 0.0f, amber, 11.0f, dark, 2.0f);
  mb_box(&mb, v3(0.0f, 0.0f, 0.0f), v3(2.35f, 0.24f, 0.42f), steel, 0.0f);
  // Bent heavy solar wings
  for (int side = -1; side <= 1; side += 2) {
    float wx = (float)side * 2.35f;
    mb_box(&mb, v3(wx, 0.0f, 0.0f), v3(0.08f, 1.45f, 1.55f), solar, 4.0f);
    mb_box(&mb, v3(wx,  1.46f, 0.0f), v3(0.11f, 0.11f, 1.60f), steel, 0.0f);
    mb_box(&mb, v3(wx, -1.46f, 0.0f), v3(0.11f, 0.11f, 1.60f), steel, 0.0f);
  }

  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

// 5. Allied Escort Freighter (Saucer hull + twin mandibles + wide cyan engine strip)
static Mesh build_freighter(void) {
  MeshBuilder mb; mb_init(&mb);
  Vec3 hull = v3(0.66f, 0.65f, 0.62f);
  Vec3 dark = v3(0.22f, 0.23f, 0.26f);
  Vec3 eng  = v3(0.45f, 0.85f, 1.00f);

  // Main flattened circular saucer hull
  mb_sphere(&mb, v3(0.0f, 0.0f, 0.2f), 3.6f, 0.85f, 3.6f, 10, 24, hull, 0.0f);
  // Twin forward notched mandibles (-Z)
  mb_taper_box(&mb, v3(-1.05f, 0.0f, -5.2f), 0.52f, 0.28f, v3(-1.35f, 0.0f, -1.8f), 1.05f, 0.48f, hull, 0.0f);
  mb_taper_box(&mb, v3( 1.05f, 0.0f, -5.2f), 0.52f, 0.28f, v3( 1.35f, 0.0f, -1.8f), 1.05f, 0.48f, hull, 0.0f);
  // Offset starboard cockpit corridor & dome
  mb_cyl_z(&mb, 2.75f, 0.15f, -3.55f, -0.55f, 0.42f, 0.52f, 10, hull, 0.0f, v3(0.06f, 0.10f, 0.14f), 3.0f, dark, -1.0f);
  // Dorsal radar dish & quad turret
  mb_cyl_z(&mb, 0.0f, 0.88f, -0.45f, 0.45f, 0.55f, 0.55f, 10, dark, 2.0f, dark, 2.0f, dark, 2.0f);
  // Blazing wide cyan rear sublight thruster bar
  mb_box(&mb, v3(0.0f, 0.0f, 3.55f), v3(2.35f, 0.34f, 0.22f), eng, 6.0f);

  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

// 6. Massive Sculpted Orbital Dreadnought (Concave Superlaser Dish + Equatorial Trench!)
static const float DREAD_RADIUS = 165.0f;
static Vec3 get_dread_pos(void) { return v3(0.0f, 38.0f, -345.0f); }
static Vec3 get_dish_dir(void)  { return v3_norm(v3(-0.30f, 0.33f, 0.895f)); }

static float smoothstep_c(float x) { x = clampf(x, 0.0f, 1.0f); return x * x * (3.0f - 2.0f * x); }

static float eval_dread_radius(Vec3 dir) {
  float r = DREAD_RADIUS;
  Vec3 dishDir = get_dish_dir();
  float dDot = v3_dot(dir, dishDir);
  // Deep spherical concave Superlaser Dish indentation (angular radius ~24 deg)
  const float cosOuter = 0.914f;
  if (dDot > cosOuter) {
    float t = (dDot - cosOuter) / (1.0f - cosOuter); // 0 at rim, 1 at center
    float bowl = sinf(t * PI_F * 0.5f);
    r -= 24.5f * powf(bowl, 1.35f);
    // Concentric stepped focus rings inside the dish
    r += 0.95f * sinf(t * 28.0f) * (1.0f - t * 0.5f);
    // Central emitter spire
    if (t > 0.91f) r += 11.0f * (t - 0.91f) / 0.09f;
  } else if (dDot > cosOuter - 0.015f) {
    // Raised armored rim lip around superlaser dish
    r += 1.8f;
  }
  // Carved Equatorial Trench around the middle
  float ay = fabsf(dir.y);
  if (ay < 0.042f) {
    float depth = 1.0f - ay / 0.042f;
    r -= 9.5f * smoothstep_c(depth);
  }
  return r;
}


static Mesh build_dreadnought(void) {
  MeshBuilder mb; mb_init(&mb);
  const int STACKS = 64, SLICES = 96;
  Vec3 hullCol = v3(0.24f, 0.26f, 0.30f);
  Vec3 dishDir = get_dish_dir();

  // Helper lambda via macro to evaluate position on sculpted Dreadnought surface
  for (int j = 0; j < STACKS; j++) {
    float v0 = (float)j / (float)STACKS;
    float v1 = (float)(j + 1) / (float)STACKS;
    float th0 = v0 * PI_F, th1 = v1 * PI_F;
    for (int i = 0; i < SLICES; i++) {
      float u0 = (float)i / (float)SLICES;
      float u1 = (float)(i + 1) / (float)SLICES;
      float ph0 = u0 * TAU_F, ph1 = u1 * TAU_F;

      Vec3 dirs[4] = {
        v3(sinf(th0)*cosf(ph0), cosf(th0), sinf(th0)*sinf(ph0)),
        v3(sinf(th1)*cosf(ph0), cosf(th1), sinf(th1)*sinf(ph0)),
        v3(sinf(th1)*cosf(ph1), cosf(th1), sinf(th1)*sinf(ph1)),
        v3(sinf(th0)*cosf(ph1), cosf(th0), sinf(th0)*sinf(ph1))
      };
      Vec3 pts[4];
      for (int k = 0; k < 4; k++) pts[k] = v3_mul(dirs[k], eval_dread_radius(dirs[k]));

      // Compute crisp geometric facet/smooth normals so dish bowl & trench rims catch dramatic light
      Vec3 nA = v3_norm(v3_cross(v3_sub(pts[1], pts[0]), v3_sub(pts[2], pts[0])));
      Vec3 nB = v3_norm(v3_cross(v3_sub(pts[2], pts[0]), v3_sub(pts[3], pts[0])));
      Vec3 nAvg = v3_norm(v3_add(nA, nB));
      if (v3_dot(nAvg, dirs[0]) < 0.0f) nAvg = v3_mul(nAvg, -1.0f);

      // Slight tint shift inside dish vs main armored hull
      float dDot = v3_dot(dirs[0], dishDir);
      Vec3 col = (dDot > 0.914f) ? v3(0.19f, 0.21f, 0.25f) : hullCol;

      mb_push(&mb, pts[0], nAvg, u0, v0, col, 7.0f);
      mb_push(&mb, pts[1], nAvg, u0, v1, col, 7.0f);
      mb_push(&mb, pts[2], nAvg, u1, v1, col, 7.0f);
      mb_push(&mb, pts[0], nAvg, u0, v0, col, 7.0f);
      mb_push(&mb, pts[2], nAvg, u1, v1, col, 7.0f);
      mb_push(&mb, pts[3], nAvg, u1, v0, col, 7.0f);
    }
  }
  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

// 7. Destructible Shield Relay Dome / Reactor Core
static Mesh build_relay(void) {
  MeshBuilder mb; mb_init(&mb);
  mb_cyl_z(&mb, 0.0f, 0.0f, -1.2f, 1.2f, 3.6f, 4.2f, 12, v3(0.32f, 0.35f, 0.40f), 2.0f, v3(0.32f,0.35f,0.40f), 2.0f, v3(0.32f,0.35f,0.40f), 2.0f);
  mb_sphere(&mb, v3(0.0f, 0.0f, 0.0f), 2.8f, 2.8f, 2.8f, 10, 14, v3(0.35f, 0.92f, 1.0f), 8.0f);
  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

// 8. Stretched 3D Glowing Laser Bolt & Ion Exhaust Plume Capsules
static Mesh build_beam_capsule(void) {
  MeshBuilder mb; mb_init(&mb);
  Vec3 w = v3(1.0f, 1.0f, 1.0f);
  // Tapered diamond-capsule along Z from -1.0 to +1.0
  mb_cyl_z(&mb, 0.0f, 0.0f, -1.0f, -0.65f, 0.02f, 1.0f, 8, w, 9.0f, w, -1.0f, w, -1.0f);
  mb_cyl_z(&mb, 0.0f, 0.0f, -0.65f, 0.65f, 1.0f,  1.0f, 8, w, 9.0f, w, -1.0f, w, -1.0f);
  mb_cyl_z(&mb, 0.0f, 0.0f,  0.65f, 1.00f, 1.0f, 0.02f, 8, w, 9.0f, w, -1.0f, w, -1.0f);
  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

static Mesh build_plume_cone(void) {
  MeshBuilder mb; mb_init(&mb);
  Vec3 w = v3(1.0f, 1.0f, 1.0f);
  // Exhaust cone stretching from z=0 (wide engine exit) to z=+1.0 (tapered hot tail)
  mb_cyl_z(&mb, 0.0f, 0.0f, 0.0f, 0.25f, 0.92f, 1.00f, 10, w, 5.0f, w, -1.0f, w, -1.0f);
  mb_cyl_z(&mb, 0.0f, 0.0f, 0.25f, 1.00f, 1.00f, 0.04f, 10, w, 5.0f, w, -1.0f, w, -1.0f);
  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}


// 9. Imperial Escort Star Cruiser (Iconic wedge dagger silhouette + command bridge + glowing blue ion engines)
static Mesh build_cruiser(void) {
  MeshBuilder mb; mb_init(&mb);
  Vec3 hull = v3(0.30f, 0.33f, 0.38f);
  Vec3 dark = v3(0.14f, 0.16f, 0.20f);
  Vec3 eng  = v3(0.35f, 0.78f, 1.00f);

  // Main upper & lower wedge dagger hull (-Z sharp prow, +Z wide stern)
  mb_taper_box(&mb, v3(0.0f,  0.00f, -14.0f), 0.35f, 0.25f, v3(0.0f,  0.00f,  8.5f), 7.8f, 1.45f, hull, 0.0f);
  // Stepped armored dorsal superstructure decks
  mb_taper_box(&mb, v3(0.0f,  1.25f,  -4.5f), 1.4f,  0.45f, v3(0.0f,  1.75f,  6.5f), 4.2f, 0.85f, hull, 0.0f);
  mb_taper_box(&mb, v3(0.0f,  2.45f,   1.2f), 1.0f,  0.42f, v3(0.0f,  2.75f,  5.8f), 2.4f, 0.55f, hull, 0.0f);
  // Command bridge neck & horizontal T-bar tower with twin shield domes
  mb_box(&mb, v3(0.0f, 3.85f, 4.4f), v3(0.55f, 0.85f, 0.75f), dark, 2.0f);
  mb_box(&mb, v3(0.0f, 4.75f, 4.3f), v3(2.15f, 0.42f, 0.58f), hull, 0.0f);
  mb_sphere(&mb, v3(-1.15f, 5.45f, 4.3f), 0.38f, 0.38f, 0.38f, 6, 8, hull, 0.0f);
  mb_sphere(&mb, v3( 1.15f, 5.45f, 4.3f), 0.38f, 0.38f, 0.38f, 6, 8, hull, 0.0f);
  // Dark recessed rear engine bay + 3 huge glowing blue main ion engines + 4 auxiliary thrusters
  mb_box(&mb, v3(0.0f, 0.0f, 8.65f), v3(7.1f, 1.15f, 0.25f), dark, 2.0f);
  mb_cyl_z(&mb,  0.0f, 0.0f, 8.55f, 9.20f, 0.95f, 0.85f, 12, dark, 2.0f, dark, -1.0f, eng, 6.0f);
  mb_cyl_z(&mb, -2.8f, 0.0f, 8.55f, 9.20f, 0.88f, 0.78f, 12, dark, 2.0f, dark, -1.0f, eng, 6.0f);
  mb_cyl_z(&mb,  2.8f, 0.0f, 8.55f, 9.20f, 0.88f, 0.78f, 12, dark, 2.0f, dark, -1.0f, eng, 6.0f);
  mb_cyl_z(&mb, -4.9f, 0.0f, 8.55f, 9.05f, 0.45f, 0.40f,  8, dark, 2.0f, dark, -1.0f, eng, 6.0f);
  mb_cyl_z(&mb,  4.9f, 0.0f, 8.55f, 9.05f, 0.45f, 0.40f,  8, dark, 2.0f, dark, -1.0f, eng, 6.0f);

  Mesh m = mb_upload(&mb); mb_free(&mb); return m;
}

static void init_all_meshes(void) {
  g_meshXBody       = build_xwing_body();
  g_meshXWing       = build_xwing_wing();
  g_meshTie         = build_tie_fighter();
  g_meshBomber      = build_bomber();
  g_meshFreighter   = build_freighter();
  g_meshDreadnought = build_dreadnought();
  g_meshRelay       = build_relay();
  g_meshBeam        = build_beam_capsule();
  g_meshPlume       = build_plume_cone();
  g_meshCruiser     = build_cruiser();
}

static void destroy_all_meshes(void) {
  mesh_destroy(&g_meshXBody);
  mesh_destroy(&g_meshXWing);
  mesh_destroy(&g_meshTie);
  mesh_destroy(&g_meshBomber);
  mesh_destroy(&g_meshFreighter);
  mesh_destroy(&g_meshDreadnought);
  mesh_destroy(&g_meshRelay);
  mesh_destroy(&g_meshBeam);
  mesh_destroy(&g_meshPlume);
  mesh_destroy(&g_meshCruiser);
}

// ============================================================================
// GLSL 430 CORE SHADERS V2.0 (CALIBRATED DEEP-SPACE HDR, TRIPLANAR PBR,
// VOLUMETRIC GOD-RAYS, ZERO-GHOSTING MRT TAA, LENS FLARE & SLEEK HUD)
// ============================================================================
static const char *VS_QUAD_SRC =
"#version 430 core\n"
"out vec2 vUv;\n"
"void main() {\n"
"  vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);\n"
"  vUv = p;\n"
"  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n"
"}\n";

// --- PASS 1A: INKY DEEP-SPACE HDR SKYBOX, SUBTLE NEBULA & WARP STREAKS ---
static const char *FS_SKYBOX_SRC =
"#version 430 core\n"
"in vec2 vUv;\n"
"layout(location = 0) out vec4 outColor;\n"
"uniform mat4  uInvViewProj;\n"
"uniform vec3  uCamPos;\n"
"uniform vec3  uCamFwd;\n"
"uniform vec3  uSunDir;\n"
"uniform float uTime;\n"
"uniform float uBoost;\n"
"\n"
"vec3 hash33(vec3 p3) {\n"
"  p3 = fract(p3 * vec3(0.1031, 0.1030, 0.0973));\n"
"  p3 += dot(p3, p3.yxz + 33.33);\n"
"  return fract((p3.xxy + p3.yxx) * p3.zyx);\n"
"}\n"
"float hash13(vec3 p3) {\n"
"  p3 = fract(p3 * 0.1031);\n"
"  p3 += dot(p3, p3.zyx + 31.32);\n"
"  return fract((p3.x + p3.y) * p3.z);\n"
"}\n"
"float vnoise3(vec3 p) {\n"
"  vec3 i = floor(p), f = fract(p);\n"
"  vec3 u = f * f * (3.0 - 2.0 * f);\n"
"  return mix(\n"
"    mix(mix(hash13(i+vec3(0,0,0)), hash13(i+vec3(1,0,0)), u.x),\n"
"        mix(hash13(i+vec3(0,1,0)), hash13(i+vec3(1,1,0)), u.x), u.y),\n"
"    mix(mix(hash13(i+vec3(0,0,1)), hash13(i+vec3(1,0,1)), u.x),\n"
"        mix(hash13(i+vec3(0,1,1)), hash13(i+vec3(1,1,1)), u.x), u.y), u.z);\n"
"}\n"
"float fbm3(vec3 p) {\n"
"  float v = 0.0, a = 0.5;\n"
"  for (int i = 0; i < 4; i++) { v += a * vnoise3(p); p = p * 2.04 + vec3(11.3, 27.1, 7.9); a *= 0.5; }\n"
"  return v;\n"
"}\n"
"vec3 starLayer(vec3 dir, float scale, float thresh, float bright) {\n"
"  vec3 p = dir * scale;\n"
"  vec3 rnd = hash33(floor(p));\n"
"  vec3 f = (fract(p) - 0.5) - (rnd - 0.5) * 0.60;\n"
"  float d = length(f);\n"
"  float s = smoothstep(0.085, 0.010, d) * step(thresh, rnd.z);\n"
"  vec3 tint = mix(vec3(0.62, 0.80, 1.0), vec3(1.0, 0.82, 0.58), rnd.x);\n"
"  float tw = 0.85 + 0.15 * sin(uTime * (1.8 + rnd.y * 4.5) + rnd.x * 40.0);\n"
"  return tint * s * (bright + bright * 2.8 * pow(rnd.y, 4.0)) * tw;\n"
"}\n"
"void main() {\n"
"  vec4 wp = uInvViewProj * vec4(vUv * 2.0 - 1.0, 1.0, 1.0);\n"
"  vec3 rd = normalize(wp.xyz / wp.w - uCamPos);\n"
"  // True pitch-black deep-space vacuum floor\n"
"  vec3 col = vec3(0.0007, 0.0010, 0.0020);\n"
"  // Subtle, deep-contrast distant galactic nebula band (rich indigo + crimson dust)\n"
"  float band = exp(-pow(dot(rd, normalize(vec3(0.28, 0.85, -0.44))) * 3.4, 2.0));\n"
"  float n1 = fbm3(rd * 3.6 + vec3(1.2, -0.4, 2.1));\n"
"  float n2 = fbm3(rd * 7.5 + vec3(n1 * 1.5));\n"
"  float dustLane = smoothstep(0.32, 0.68, fbm3(rd * 5.2 + vec3(4.1, 1.7, -2.3)));\n"
"  col += vec3(0.006, 0.014, 0.032) * band * pow(n1, 1.6) * (1.0 - dustLane * 0.72);\n"
"  col += vec3(0.022, 0.006, 0.014) * band * pow(n2, 2.4) * (1.0 - dustLane * 0.65);\n"
"  // Crisp multi-scale pinpoint starfield\n"
"  col += starLayer(rd, 135.0, 0.940, 1.55);\n"
"  col += starLayer(rd + vec3(0.37), 255.0, 0.958, 0.95);\n"
"  col += starLayer(rd + vec3(0.71), 410.0, 0.972, 0.55);\n"
"  // Warp-speed radial star streaks when boosting\n"
"  if (uBoost > 0.02) {\n"
"    vec3 perp = rd - uCamFwd * dot(rd, uCamFwd);\n"
"    float ang = atan(perp.y, perp.x);\n"
"    float radial = length(perp);\n"
"    float sn = fract(sin(floor(ang * 44.0) * 127.1) * 43758.5453);\n"
"    float streak = smoothstep(0.93, 0.996, sin(ang * 44.0 + sn * 6.28) * 0.5 + 0.5);\n"
"    float move = fract(radial * 4.2 - uTime * (4.8 + uBoost * 6.5) + sn);\n"
"    float dash = smoothstep(0.0, 0.22, move) * smoothstep(0.85, 0.32, move);\n"
"    col += vec3(0.72, 0.86, 1.0) * streak * dash * smoothstep(0.20, 0.65, radial) * uBoost * 1.45;\n"
"  }\n"
"  // Distant Ringed Gas Giant Planet on the upper-left horizon (cinematic orbital scale!)\n"
"  vec3 pCenter = normalize(vec3(-0.62, 0.27, -0.73)) * 900.0;\n"
"  float pRad = 128.0;\n"
"  vec3 rNorm = normalize(vec3(0.28, 0.92, 0.26));\n"
"  float bP = dot(-pCenter, rd);\n"
"  float hP = bP * bP - (dot(pCenter, pCenter) - pRad * pRad);\n"
"  float tPlanet = 1e9;\n"
"  bool hitPlanet = false;\n"
"  if (hP > 0.0) {\n"
"    float t0 = -bP - sqrt(hP);\n"
"    if (t0 > 0.0) {\n"
"      tPlanet = t0; hitPlanet = true;\n"
"      vec3 hp = rd * t0;\n"
"      vec3 nP = normalize(hp - pCenter);\n"
"      float ndl = max(dot(nP, uSunDir), 0.0);\n"
"      float lat = dot(nP, rNorm);\n"
"      float bands = 0.5 + 0.5 * sin(lat * 26.0 + fbm3(nP * 5.0) * 3.5);\n"
"      vec3 pCol = mix(vec3(0.11, 0.16, 0.24), vec3(0.36, 0.30, 0.25), bands);\n"
"      float limb = pow(1.0 - max(dot(nP, -rd), 0.0), 3.2);\n"
"      col = pCol * (0.015 + 1.35 * smoothstep(0.0, 0.65, ndl)) + vec3(0.16, 0.36, 0.72) * limb * (0.12 + 0.85 * ndl);\n"
"    }\n"
"  }\n"
"  // Translucent Planetary Ring System (depth-tested against planet sphere)\n"
"  float denomR = dot(rd, rNorm);\n"
"  if (abs(denomR) > 1e-4) {\n"
"    float tR = dot(pCenter, rNorm) / denomR;\n"
"    if (tR > 0.0 && tR < tPlanet) {\n"
"      vec3 rp = rd * tR - pCenter;\n"
"      float rr = length(rp) / pRad;\n"
"      if (rr > 1.32 && rr < 2.28) {\n"
"        float rBand = smoothstep(1.32, 1.42, rr) * smoothstep(2.28, 2.15, rr);\n"
"        float cassini = 1.0 - smoothstep(1.78, 1.82, rr) * smoothstep(1.90, 1.86, rr) * 0.85;\n"
"        float rings = (0.55 + 0.45 * sin(rr * 68.0)) * rBand * cassini;\n"
"        // Planet shadow cast onto its own rings\n"
"        float bS = dot(rp, uSunDir);\n"
"        float pSh = 1.0;\n"
"        if (bS < 0.0) { float d2 = dot(rp, rp) - bS * bS; pSh = smoothstep(pRad*pRad*0.96, pRad*pRad*1.04, d2); }\n"
"        vec3 rCol = mix(vec3(0.24, 0.26, 0.32), vec3(0.52, 0.45, 0.38), 0.5 + 0.5 * sin(rr * 24.0));\n"
"        col = mix(col, rCol * (0.04 + 0.95 * pSh), rings * 0.42);\n"
"      }\n"
"    }\n"
"  }\n"
"  // Distant blazing star sun disk + tight HDR solar corona\n"
"  float sunMu = dot(rd, uSunDir);\n"
"  float disk = smoothstep(0.99935, 0.99985, sunMu);\n"
"  float corona = pow(max(sunMu, 0.0), 42.0) * 0.22 + pow(max(sunMu, 0.0), 380.0) * 3.8;\n"
"  col += vec3(1.18, 0.95, 0.76) * (disk * 22.0 + corona);\n"
"  outColor = vec4(col, 1.0);\n"
"}\n";

// --- PASS 1B: GGX MICROFACET PBR WITH 3D TRIPLANAR NORMAL-MAP GREEBLING ---
static const char *VS_MESH_SRC =
"#version 430 core\n"
"layout(location = 0) in vec3 aPos;\n"
"layout(location = 1) in vec3 aNorm;\n"
"layout(location = 2) in vec2 aUv;\n"
"layout(location = 3) in vec3 aCol;\n"
"layout(location = 4) in float aMatId;\n"
"\n"
"uniform mat4 uModel;\n"
"uniform mat4 uViewProj;\n"
"\n"
"out vec3 vWorldPos;\n"
"out vec3 vLocalPos;\n"
"out vec3 vNormal;\n"
"out vec2 vUv;\n"
"out vec3 vCol;\n"
"out float vMatId;\n"
"\n"
"void main() {\n"
"  vec4 wp = uModel * vec4(aPos, 1.0);\n"
"  vWorldPos = wp.xyz;\n"
"  vLocalPos = aPos;\n"
"  vNormal   = normalize(mat3(uModel) * aNorm);\n"
"  vUv       = aUv;\n"
"  vCol      = aCol;\n"
"  vMatId    = aMatId;\n"
"  gl_Position = uViewProj * wp;\n"
"}\n";

static const char *FS_MESH_PBR_A_SRC =
"#version 430 core\n"
"in vec3 vWorldPos;\n"
"in vec3 vLocalPos;\n"
"in vec3 vNormal;\n"
"in vec2 vUv;\n"
"in vec3 vCol;\n"
"in float vMatId;\n"
"layout(location = 0) out vec4 outColor;\n"
"\n"
"uniform vec3  uCamPos;\n"
"uniform vec3  uSunDir;\n"
"uniform vec3  uDreadPos;\n"
"uniform float uDreadRad;\n"
"uniform vec3  uDishDir;\n"
"uniform float uTime;\n"
"uniform float uEmissiveScale;\n"
"uniform float uShieldFlash;\n"
"uniform float uDishCharge;\n"
"uniform int   uDynLightCount;\n"
"uniform vec4  uDynLightPos[8];\n"
"uniform vec4  uDynLightCol[8];\n"
"\n"
"const float PI = 3.14159265359;\n"
"\n"
"float hash12(vec2 p) {\n"
"  vec3 p3 = fract(vec3(p.xyx) * 0.1031);\n"
"  p3 += dot(p3, p3.yzx + 33.33);\n"
"  return fract((p3.x + p3.y) * p3.z);\n"
"}\n"
"float vnoise2(vec2 p) {\n"
"  vec2 i = floor(p), f = fract(p);\n"
"  vec2 u = f * f * (3.0 - 2.0 * f);\n"
"  return mix(mix(hash12(i), hash12(i + vec2(1,0)), u.x),\n"
"             mix(hash12(i + vec2(0,1)), hash12(i + vec2(1,1)), u.x), u.y);\n"
"}\n"
"float triNoise(vec3 p, vec3 n, float sc) {\n"
"  vec3 w = pow(abs(n), vec3(4.0)); w /= max(w.x + w.y + w.z, 1e-4);\n"
"  return vnoise2(p.yz * sc) * w.x + vnoise2(p.xz * sc) * w.y + vnoise2(p.xy * sc) * w.z;\n"
"}\n"
"// Crisp 2D sci-fi hull panel heightfield (returns vec2(height, seamMask))\n"
"vec2 hullPanel2D(vec2 uv) {\n"
"  vec2 idA = floor(uv);\n"
"  vec2 fA  = fract(uv);\n"
"  float hA = hash12(idA);\n"
"  // Sub-divide half of the tiles asymmetrically for authentic ILM kitbash plating\n"
"  vec2 uvB = uv * ((hA > 0.5) ? vec2(2.0, 1.0) : vec2(1.0, 2.0));\n"
"  vec2 idB = floor(uvB);\n"
"  vec2 fB  = abs(fract(uvB) - 0.5);\n"
"  float hB = hash12(idB + 31.7);\n"
"  float seam = max(smoothstep(0.455, 0.495, fB.x), smoothstep(0.455, 0.495, fB.y));\n"
"  vec2 fC = abs(fA - 0.5);\n"
"  float seamMajor = max(smoothstep(0.465, 0.498, fC.x), smoothstep(0.465, 0.498, fC.y));\n"
"  float s = max(seam * 0.72, seamMajor);\n"
"  float height = (0.35 + 0.65 * hB) * (1.0 - s * 0.85);\n"
"  return vec2(height, s);\n"
"}\n"
"vec2 triPanel(vec3 p, vec3 n, float sc) {\n"
"  vec3 w = pow(abs(n), vec3(6.0)); w /= max(w.x + w.y + w.z, 1e-4);\n"
"  return hullPanel2D(p.yz * sc) * w.x + hullPanel2D(p.xz * sc) * w.y + hullPanel2D(p.xy * sc) * w.z;\n"
"}\n"
"float D_GGX(float NoH, float a) {\n"
"  float a2 = a * a;\n"
"  float d = (NoH * NoH) * (a2 - 1.0) + 1.0;\n"
"  return a2 / (PI * d * d + 1e-6);\n"
"}\n"
"float V_SmithGGX(float NoV, float NoL, float a) {\n"
"  float a2 = a * a;\n"
"  return 0.5 / max(NoL * sqrt(NoV*NoV*(1.0-a2)+a2) + NoV * sqrt(NoL*NoL*(1.0-a2)+a2), 1e-5);\n"
"}\n"
"vec3 F_Schlick(float VoH, vec3 F0) { return F0 + (1.0 - F0) * pow(1.0 - clamp(VoH, 0.0, 1.0), 5.0); }\n"
"vec3 evalPBR(vec3 N, vec3 V, vec3 L, vec3 alb, float rough, float metal, vec3 rad) {\n"
"  float NoL = max(dot(N, L), 0.0);\n"
"  if (NoL <= 0.0) return vec3(0.0);\n"
"  float NoV = max(dot(N, V), 1e-4);\n"
"  vec3 H = normalize(V + L);\n"
"  float a = max(rough * rough, 0.0025);\n"
"  vec3 F0 = mix(vec3(0.04), alb, metal);\n"
"  vec3 F = F_Schlick(max(dot(V, H), 0.0), F0);\n"
"  vec3 spec = D_GGX(max(dot(N, H), 0.0), a) * V_SmithGGX(NoV, NoL, a) * F * (1.0 + F0 * rough * 0.42);\n"
"  return ((1.0 - F) * (1.0 - metal) * alb / PI + spec) * rad * NoL;\n"
"}\n"
"float dreadShadow(vec3 p, vec3 sunDir) {\n"
"  vec3 oc = p - uDreadPos;\n"
"  float r = length(oc);\n"
"  if (r < uDreadRad + 3.0) return 1.0;\n"
"  float b = dot(oc, sunDir);\n"
"  if (b > 0.0) return 1.0;\n"
"  float d2 = dot(oc, oc) - b * b;\n"
"  float rad = uDreadRad * 0.97;\n"
"  return smoothstep(rad * rad * 0.92, rad * rad * 1.07, d2);\n"
"}\n";

static const char *FS_MESH_PBR_B_SRC =
"void main() {\n"
"  vec3 geomN = normalize(vNormal);\n"
"  vec3 N = geomN;\n"
"  vec3 V = normalize(uCamPos - vWorldPos);\n"
"  vec3 alb = vCol;\n"
"  float rough = 0.42;\n"
"  float metal = 0.55;\n"
"  float ao = 1.0;\n"
"  vec3 emissive = vec3(0.0);\n"
"\n"
"  if (vMatId < 0.5) {\n"
"    // 0: Battle-Worn Titanium Starfighter Hull + 3D Triplanar Panel Bump & Rear Soot\n"
"    vec2 pan = triPanel(vLocalPos, geomN, 1.35);\n"
"    float grime = triNoise(vLocalPos, geomN, 3.2);\n"
"    float micro = triNoise(vLocalPos, geomN, 11.5);\n"
"    float soot = smoothstep(0.6, 2.2, vLocalPos.z) * 0.38;\n"
"    alb *= mix(0.76, 1.08, pan.x) * mix(0.84, 1.05, grime) * (1.0 - pan.y * 0.42) * (1.0 - soot);\n"
"    rough = clamp(0.28 + micro * 0.34 + pan.y * 0.28 + soot * 0.35, 0.14, 0.88);\n"
"    metal = 0.62;\n"
"    // Finite-difference panel normal bump\n"
"    float e = 0.035;\n"
"    vec3 grad = vec3(\n"
"      triPanel(vLocalPos + vec3(e,0,0), geomN, 1.35).x - pan.x,\n"
"      triPanel(vLocalPos + vec3(0,e,0), geomN, 1.35).x - pan.x,\n"
"      triPanel(vLocalPos + vec3(0,0,e), geomN, 1.35).x - pan.x) / e;\n"
"    N = normalize(geomN - grad * 0.045);\n"
"  } else if (vMatId < 1.5) {\n"
"    // 1: Weathered Squadron Red Markings\n"
"    float wear = triNoise(vLocalPos, geomN, 5.0);\n"
"    alb = mix(alb * 0.82, vec3(0.38, 0.39, 0.41), smoothstep(0.70, 0.90, wear) * 0.55);\n"
"    rough = 0.42; metal = 0.20;\n"
"  } else if (vMatId < 2.5) {\n"
"    // 2: Dark Gunmetal Frame & Laser Barrels\n"
"    rough = 0.32; metal = 0.88;\n"
"  } else if (vMatId < 3.5) {\n"
"    // 3: Glossy Tinted Cockpit Glass\n"
"    rough = 0.05; metal = 0.22;\n"
"  } else if (vMatId < 4.5) {\n"
"    // 4: TIE Hexagonal Ribbed Solar Array Panels\n"
"    float lines = smoothstep(0.82, 0.96, abs(sin(vLocalPos.y * 24.0))) +\n"
"                  smoothstep(0.88, 0.98, abs(sin(vLocalPos.z * 16.0)));\n"
"    float lm = clamp(lines, 0.0, 1.0);\n"
"    alb = mix(vec3(0.018, 0.030, 0.055), vec3(0.11, 0.14, 0.19), lm);\n"
"    rough = mix(0.14, 0.40, lm); metal = 0.82;\n"
"  } else if (vMatId < 5.5) {\n"
"    // 5: Sculpted Hot Pink/Magenta X-Wing Ion Thruster Core (controlled HDR!)\n"
"    emissive = vec3(5.4, 0.58, 2.35) * uEmissiveScale;\n"
"    alb = vec3(0.85, 0.25, 0.52); rough = 0.25; metal = 0.0;\n"
"  } else if (vMatId < 6.5) {\n"
"    // 6: Blazing Cyan-Blue Ion Engine Strip\n"
"    emissive = vec3(1.4, 5.2, 10.5) * uEmissiveScale;\n"
"    alb = vec3(0.45, 0.85, 1.0); rough = 0.2; metal = 0.0;\n"
"  } else if (vMatId < 7.5) {\n"
"    // 7: MASSIVE ORBITAL DREADNOUGHT — Dark Imperial Gunmetal + 3D Triplanar Armor Bump + Pinpoint Lights!\n"
"    vec3 dDir = normalize(vLocalPos);\n"
"    vec2 pMacro = triPanel(vLocalPos, dDir, 0.075);\n"
"    vec2 pMicro = triPanel(vLocalPos, dDir, 0.26);\n"
"    float macroH = pMacro.x * 0.62 + pMicro.x * 0.38;\n"
"    float seam = max(pMacro.y * 0.85, pMicro.y * 0.55);\n"
"    // Dark imposing imperial titanium slate (matches image_ad05dc.jpg!)\n"
"    alb = mix(vec3(0.048, 0.054, 0.066), vec3(0.195, 0.210, 0.235), macroH);\n"
"    alb *= (1.0 - seam * 0.58);\n"
"    rough = clamp(0.32 + (1.0 - pMicro.x) * 0.42 + seam * 0.25, 0.16, 0.90);\n"
"    metal = 0.74;\n"
"    // 3D Triplanar Hull Normal Perturbation (crisp sunlit panel bevels up close!)\n"
"    float e = 0.42;\n"
"    float h0 = macroH;\n"
"    vec3 grad = vec3(\n"
"      (triPanel(vLocalPos + vec3(e,0,0), dDir, 0.075).x * 0.62 + triPanel(vLocalPos + vec3(e,0,0), dDir, 0.26).x * 0.38) - h0,\n"
"      (triPanel(vLocalPos + vec3(0,e,0), dDir, 0.075).x * 0.62 + triPanel(vLocalPos + vec3(0,e,0), dDir, 0.26).x * 0.38) - h0,\n"
"      (triPanel(vLocalPos + vec3(0,0,e), dDir, 0.075).x * 0.62 + triPanel(vLocalPos + vec3(0,0,e), dDir, 0.26).x * 0.38) - h0) / e;\n"
"    N = normalize(geomN - grad * 0.65);\n"
"    // Deep Equatorial Trench shadow AO & industrial deck glow\n"
"    float trench = 1.0 - smoothstep(0.012, 0.048, abs(dDir.y));\n"
"    ao *= mix(1.0, 0.24, trench);\n"
"    alb *= mix(1.0, 0.42, trench);\n"
"    // Concave Superlaser Dish concentric reflector ribs + analytical bowl AO\n"
"    float dishDot = dot(dDir, uDishDir);\n"
"    if (dishDot > 0.914) {\n"
"      float dt = (dishDot - 0.914) / (1.0 - 0.914);\n"
"      float ribs = smoothstep(0.68, 0.96, abs(sin(dt * 34.0)));\n"
"      float spokes = smoothstep(0.86, 0.98, abs(sin(atan(dDir.y - uDishDir.y, dDir.x - uDishDir.x) * 8.0)));\n"
"      alb = mix(alb * 0.72, vec3(0.24, 0.27, 0.31), max(ribs, spokes * 0.6) * 0.55);\n"
"      ao *= mix(0.85, 0.32, sin(dt * PI * 0.85));\n"
"      if (uDishCharge > 0.01) {\n"
"        float centerGlow = exp(-pow((1.0 - dt) * 6.5, 2.0));\n"
"        float ringGlow = pow(max(sin(dt * 24.0 - uTime * 6.0), 0.0), 6.0) * (1.0 - dt);\n"
"        emissive += vec3(0.6, 12.0, 2.6) * uDishCharge * (centerGlow * 2.2 + ringGlow * 0.55);\n"
"      }\n"
"    } else {\n"
"      // Crisp Pinpoint Hangar & City Lights (3D triplanar grid -> zero polar stretching!)\n"
"      vec3 wP = vLocalPos * 0.85;\n"
"      vec3 wAbs = pow(abs(dDir), vec3(6.0)); wAbs /= max(wAbs.x + wAbs.y + wAbs.z, 1e-4);\n"
"      vec2 gXY = wP.xy, gXZ = wP.xz, gYZ = wP.yz;\n"
"      vec2 uWin = (wAbs.z > wAbs.x && wAbs.z > wAbs.y) ? gXY : ((wAbs.y > wAbs.x) ? gXZ : gYZ);\n"
"      vec2 wId = floor(uWin);\n"
"      float wRnd = hash12(wId);\n"
"      vec2 wf = abs(fract(uWin) - 0.5);\n"
"      float wMask = step(0.952, wRnd) * step(wf.x, 0.19) * step(wf.y, 0.19) * (1.0 - seam);\n"
"      float nightSide = 1.0 - smoothstep(-0.12, 0.32, dot(geomN, uSunDir));\n"
"      vec3 winCol = mix(vec3(1.8, 2.8, 4.4), vec3(4.5, 2.8, 1.1), hash12(wId + 19.3));\n"
"      emissive += winCol * wMask * (0.22 + 1.45 * nightSide + trench * 1.8);\n"
"    }\n"
"  } else if (vMatId < 8.5) {\n"
"    // 8: Shield Relay Dome / Reactor Core\n"
"    float pulse = 0.82 + 0.22 * sin(uTime * 7.0);\n"
"    emissive = vCol * 5.2 * pulse * uEmissiveScale;\n"
"    rough = 0.16; metal = 0.25;\n"
"  } else {\n"
"    emissive = vCol * 7.5 * uEmissiveScale;\n"
"  }\n"
"\n"
"  // Direct Blazing 3/4 Key Sunlight + Analytical Dreadnought Eclipse Shadow\n"
"  float sh = (vMatId > 6.5 && vMatId < 7.5) ? 1.0 : dreadShadow(vWorldPos, uSunDir);\n"
"  vec3 sunCol = vec3(4.4, 4.1, 3.7);\n"
"  vec3 col = evalPBR(N, V, uSunDir, alb, rough, metal, sunCol) * sh * ao;\n"
"\n"
"  // Subtle Cool Galactic Rim Fill (sculpts dark night-side silhouettes without washing out blacks)\n"
"  vec3 rimDir = normalize(-uSunDir + vec3(0.0, 0.35, 0.45));\n"
"  col += evalPBR(N, V, rimDir, alb, rough, metal, vec3(0.28, 0.44, 0.72)) * ao;\n"
"  float NoV = max(dot(N, V), 0.0);\n"
"  col += alb * vec3(0.018, 0.025, 0.042) * ao * (1.0 - metal * 0.55);\n"
"  col += vec3(0.16, 0.28, 0.48) * pow(1.0 - NoV, 5.0) * (0.18 + 0.38 * (1.0 - rough)) * ao;\n"
"\n"
"  // Dynamic Point Lights from Explosions & X-Wing Engines\n"
"  for (int i = 0; i < 8; i++) {\n"
"    if (i >= uDynLightCount) break;\n"
"    vec3 toL = uDynLightPos[i].xyz - vWorldPos;\n"
"    float d2 = dot(toL, toL) + 1.8;\n"
"    float range = uDynLightPos[i].w;\n"
"    if (d2 < range * range) {\n"
"      float atten = 1.0 - sqrt(d2) / range;\n"
"      atten = (atten * atten) / (d2 * 0.055 + 0.45);\n"
"      col += evalPBR(N, V, normalize(toL), alb, rough, metal, uDynLightCol[i].rgb * atten);\n"
"    }\n"
"  }\n"
"\n"
"  // Player Deflector Shield Impact Fresnel Ripple\n"
"  if (uShieldFlash > 0.01) {\n"
"    float hex = 0.6 + 0.4 * sin(vLocalPos.x * 16.0) * sin(vLocalPos.z * 16.0);\n"
"    emissive += vec3(0.9, 4.8, 11.0) * pow(1.0 - NoV, 2.2) * uShieldFlash * hex;\n"
"  }\n"
"\n"
"  col += emissive;\n"
"  if (any(isnan(col)) || any(isinf(col))) col = vec3(0.0);\n"
"  outColor = vec4(clamp(col, 0.0, 50.0), 1.0);\n"
"}\n";

// --- PASS 3B: POST-TAA DEPTH-TESTED ADDITIVE HDR LASERS, PLUMES & SPARKS ---
static const char *VS_FX_SRC =
"#version 430 core\n"
"layout(location = 0) in vec3 aPos;\n"
"layout(location = 1) in vec3 aNorm;\n"
"uniform mat4 uModel;\n"
"uniform mat4 uViewProj;\n"
"out vec3 vWorldPos;\n"
"out vec3 vNormal;\n"
"out float vLocalZ;\n"
"void main() {\n"
"  vec4 wp = uModel * vec4(aPos, 1.0);\n"
"  vWorldPos = wp.xyz;\n"
"  vNormal   = normalize(mat3(uModel) * aNorm);\n"
"  vLocalZ   = aPos.z;\n"
"  gl_Position = uViewProj * wp;\n"
"}\n";

static const char *FS_FX_SRC =
"#version 430 core\n"
"in vec3 vWorldPos;\n"
"in vec3 vNormal;\n"
"in float vLocalZ;\n"
"layout(location = 0) out vec4 outColor;\n"
"uniform vec3  uCamPos;\n"
"uniform vec3  uCoreColor;\n"
"uniform vec3  uEdgeColor;\n"
"uniform float uIntensity;\n"
"uniform int   uIsPlume;\n"
"void main() {\n"
"  vec3 N = normalize(vNormal);\n"
"  vec3 V = normalize(uCamPos - vWorldPos);\n"
"  float core = pow(clamp(abs(dot(N, V)), 0.0, 1.0), 1.75);\n"
"  float tailFade = (uIsPlume == 1) ? pow(clamp(1.0 - vLocalZ, 0.0, 1.0), 2.15) : 1.0;\n"
"  vec3 col = mix(uEdgeColor, uCoreColor, core) * uIntensity * tailFade;\n"
"  float alpha = clamp((0.20 + 0.80 * core) * tailFade, 0.0, 1.0);\n"
"  outColor = vec4(col * alpha, alpha);\n"
"}\n";

// --- PASS 2: HALF-RES 8x4 NVIDIA COMPUTE — VOLUMETRIC GOD-RAYS, EXPLOSIONS & SUPERLASER ---
static const char *CS_VOL_SRC =
"#version 430 core\n"
"layout(local_size_x = 8, local_size_y = 4, local_size_z = 1) in;\n"
"layout(rgba16f, binding = 0) writeonly uniform image2D uVolOut;\n"
"uniform sampler2D uDepthTex;\n"
"uniform ivec2 uMainSize;\n"
"uniform ivec2 uVolSize;\n"
"uniform mat4  uInvViewProj;\n"
"uniform vec3  uCamPos;\n"
"uniform vec3  uDreadPos;\n"
"uniform float uDreadRad;\n"
"uniform vec3  uSunDir;\n"
"uniform float uTime;\n"
"uniform int   uFrame;\n"
"uniform int   uExplCount;\n"
"uniform vec4  uExplPosRad[16];\n"
"uniform vec4  uExplData[16];\n"
"uniform vec4  uBeamStart;\n"
"uniform vec4  uBeamEnd;\n"
"\n"
"const float PI = 3.14159265359;\n"
"float ign(vec2 p, int f) {\n"
"  vec2 q = p + float(f & 63) * vec2(5.588238, 7.129413);\n"
"  return fract(52.9829189 * fract(dot(q, vec2(0.06711056, 0.00583715))));\n"
"}\n"
"float hash13(vec3 p3) {\n"
"  p3 = fract(p3 * 0.1031);\n"
"  p3 += dot(p3, p3.zyx + 31.32);\n"
"  return fract((p3.x + p3.y) * p3.z);\n"
"}\n"
"float vnoise3(vec3 p) {\n"
"  vec3 i = floor(p), f = fract(p);\n"
"  vec3 u = f * f * (3.0 - 2.0 * f);\n"
"  return mix(\n"
"    mix(mix(hash13(i+vec3(0,0,0)), hash13(i+vec3(1,0,0)), u.x),\n"
"        mix(hash13(i+vec3(0,1,0)), hash13(i+vec3(1,1,0)), u.x), u.y),\n"
"    mix(mix(hash13(i+vec3(0,0,1)), hash13(i+vec3(1,0,1)), u.x),\n"
"        mix(hash13(i+vec3(0,1,1)), hash13(i+vec3(1,1,1)), u.x), u.y), u.z);\n"
"}\n"
"float fbm3(vec3 p) {\n"
"  float v = 0.0, a = 0.5;\n"
"  for (int i = 0; i < 3; i++) { v += a * vnoise3(p); p = p * 2.05 + vec3(7.1, 13.7, 5.3); a *= 0.5; }\n"
"  return v;\n"
"}\n"
"float hgPhase(float cosTheta, float g) {\n"
"  float g2 = g * g;\n"
"  float d = max(1.0 + g2 - 2.0 * g * cosTheta, 1e-3);\n"
"  return (1.0 - g2) / (4.0 * PI * d * sqrt(d));\n"
"}\n"
"vec2 raySphere(vec3 ro, vec3 rd, vec3 c, float r) {\n"
"  vec3 oc = ro - c;\n"
"  float b = dot(oc, rd);\n"
"  float h = b * b - (dot(oc, oc) - r * r);\n"
"  if (h < 0.0) return vec2(-1.0);\n"
"  h = sqrt(h);\n"
"  return vec2(-b - h, -b + h);\n"
"}\n"
"float dreadShadowVol(vec3 p, vec3 sunDir) {\n"
"  vec3 oc = p - uDreadPos;\n"
"  float b = dot(oc, sunDir);\n"
"  if (b > 0.0) return 1.0;\n"
"  float d2 = dot(oc, oc) - b * b;\n"
"  float r = uDreadRad * 0.99;\n"
"  return smoothstep(r * r * 0.96, r * r * 1.04, d2);\n"
"}\n"
"void main() {\n"
"  ivec2 gid = ivec2(gl_GlobalInvocationID.xy);\n"
"  if (gid.x >= uVolSize.x || gid.y >= uVolSize.y) return;\n"
"  ivec2 fullPix = min(gid * 2, uMainSize - 1);\n"
"  float rawDepth = texelFetch(uDepthTex, fullPix, 0).r;\n"
"  vec2 uv = (vec2(fullPix) + 0.5) / vec2(uMainSize);\n"
"  vec4 farP = uInvViewProj * vec4(uv * 2.0 - 1.0, 1.0, 1.0);\n"
"  vec3 rd = normalize(farP.xyz / farP.w - uCamPos);\n"
"  float tLimit = 1800.0;\n"
"  if (rawDepth < 0.99999) {\n"
"    vec4 hitP = uInvViewProj * vec4(uv * 2.0 - 1.0, rawDepth * 2.0 - 1.0, 1.0);\n"
"    tLimit = length(hitP.xyz / hitP.w - uCamPos);\n"
"  }\n"
"  float dither = ign(vec2(gid), uFrame);\n"
"  vec3 accum = vec3(0.0);\n"
"\n"
"  // 1. Volumetric Sun Crepuscular God-Rays through Cosmic Battle Dust (ZERO soap-bubble edge!)\n"
"  float cosSun = dot(rd, uSunDir);\n"
"  float phase = hgPhase(cosSun, 0.78) * 0.90 + hgPhase(cosSun, 0.22) * 0.12;\n"
"  float marchMax = min(tLimit, 460.0);\n"
"  if (marchMax > 8.0 && phase > 0.015) {\n"
"    const int VSTEPS = 10;\n"
"    float stepL = marchMax / float(VSTEPS);\n"
"    vec3 rayAcc = vec3(0.0);\n"
"    for (int i = 0; i < VSTEPS; i++) {\n"
"      float t = (float(i) + dither) * stepL;\n"
"      vec3 p = uCamPos + rd * t;\n"
"      float sh = dreadShadowVol(p, uSunDir);\n"
"      if (sh > 0.01) {\n"
"        float dust = 0.45 + 0.75 * vnoise3(p * 0.0085 + vec3(uTime * 0.015, 0.0, -uTime * 0.01));\n"
"        rayAcc += vec3(0.95, 0.82, 0.68) * sh * dust * phase * 0.00028 * stepL;\n"
"      }\n"
"    }\n"
"    accum += rayAcc;\n"
"  }\n"
"\n"
"  // 2. Razor-Thin Sunlit Horizon Diffraction Rim on Dreadnought (smoothly zeroed before outer bound!)\n"
"  float rimOuter = uDreadRad * 1.04;\n"
"  vec2 dh = raySphere(uCamPos, rd, uDreadPos, rimOuter);\n"
"  if (dh.y > 0.0 && dh.x < tLimit) {\n"
"    float tClosest = clamp(dot(uDreadPos - uCamPos, rd), max(dh.x, 0.0), min(dh.y, tLimit));\n"
"    vec3 pNear = uCamPos + rd * tClosest;\n"
"    float rRatio = length(pNear - uDreadPos) / uDreadRad;\n"
"    // Smooth quartic fade to exact 0.0 at rRatio = 1.04 -> ZERO hard sphere edge!\n"
"    float rimFalloff = pow(clamp((1.04 - rRatio) / 0.04, 0.0, 1.0), 4.0) * smoothstep(0.992, 1.004, rRatio);\n"
"    float sunLit = smoothstep(-0.1, 0.55, dot(normalize(pNear - uDreadPos), uSunDir));\n"
"    accum += vec3(0.32, 0.55, 0.95) * rimFalloff * sunLit * 0.35;\n"
"  }\n"
"\n"
"  // 3. Depth-Occluded 3D FBM Volumetric Plasma Explosions + Shockwaves + Late Smoke\n"
"  for (int e = 0; e < 16; e++) {\n"
"    if (e >= uExplCount) break;\n"
"    vec3  c    = uExplPosRad[e].xyz;\n"
"    float rad  = uExplPosRad[e].w;\n"
"    float age  = uExplData[e].x;\n"
"    float typ  = uExplData[e].y;\n"
"    float seed = uExplData[e].z;\n"
"    vec2 hit = raySphere(uCamPos, rd, c, rad);\n"
"    if (hit.y <= 0.0 || hit.x >= tLimit) continue;\n"
"    float t0 = max(hit.x, 0.0), t1 = min(hit.y, tLimit);\n"
"    if (t1 <= t0) continue;\n"
"    const int STEPS = 10;\n"
"    float dt = (t1 - t0) / float(STEPS);\n"
"    vec3 fireAcc = vec3(0.0);\n"
"    float trans = 1.0;\n"
"    float lifeFade = pow(clamp(1.0 - age, 0.0, 1.0), 1.45);\n"
"    for (int s = 0; s < STEPS; s++) {\n"
"      float t = t0 + (float(s) + dither) * dt;\n"
"      vec3 p = uCamPos + rd * t;\n"
"      vec3 rel = (p - c) / max(rad, 0.1);\n"
"      float rNorm = length(rel);\n"
"      float turb = fbm3(rel * 2.6 + vec3(seed * 7.3, -age * 3.0, seed * 3.1));\n"
"      float edgeSmooth = smoothstep(1.0, 0.72, rNorm);\n"
"      float shellDens = clamp(1.0 - rNorm + (turb - 0.44) * 0.78, 0.0, 1.0) * edgeSmooth;\n"
"      float shock = exp(-pow((rNorm - (0.32 + age * 0.64)) * 14.0, 2.0)) * (1.0 - age) * edgeSmooth;\n"
"      float dens = pow(shellDens, 1.5) * lifeFade + shock * 0.50;\n"
"      if (dens > 0.008) {\n"
"        float heat = clamp((1.0 - rNorm * 0.88) * (1.0 - age * 0.65) + turb * 0.32, 0.0, 1.0);\n"
"        vec3 thermal = (typ > 0.5 && typ < 1.5)\n"
"          ? mix(vec3(0.18, 0.55, 1.45), vec3(1.5, 1.4, 1.8), heat)\n"
"          : mix(vec3(0.55, 0.08, 0.01), mix(vec3(1.55, 0.48, 0.05), vec3(2.2, 1.75, 1.25), smoothstep(0.42, 0.90, heat)), smoothstep(0.10, 0.62, heat));\n"
"        float power = (typ > 1.5) ? 16.0 : 9.5;\n"
"        fireAcc += trans * thermal * dens * power * (dt / max(rad, 0.5));\n"
"        trans *= exp(-dens * 1.9 * (dt / max(rad, 0.5)));\n"
"        if (trans < 0.03) break;\n"
"      }\n"
"    }\n"
"    accum += fireAcc;\n"
"  }\n"
"\n"
"  // 4. Phase-3 Superlaser Volumetric Emerald Plasma Beam\n"
"  if (uBeamEnd.w > 0.01) {\n"
"    vec3 ba = uBeamEnd.xyz - uBeamStart.xyz;\n"
"    float bLen = max(length(ba), 1.0);\n"
"    vec3 bDir = ba / bLen;\n"
"    vec3 w0 = uCamPos - uBeamStart.xyz;\n"
"    float b = dot(rd, bDir), d = dot(rd, w0), e = dot(bDir, w0);\n"
"    float denom = max(1.0 - b * b, 1e-4);\n"
"    float tRay = clamp((b * e - d) / denom, 0.0, tLimit);\n"
"    float tSeg = clamp((e - b * d) / denom, 0.0, bLen);\n"
"    float distBeam = length((uCamPos + rd * tRay) - (uBeamStart.xyz + bDir * tSeg));\n"
"    float beamRad = 4.2 + 9.0 * uBeamEnd.w;\n"
"    float core = exp(-pow(distBeam / (beamRad * 0.25), 2.0));\n"
"    float halo = exp(-distBeam / (beamRad * 1.35));\n"
"    accum += (vec3(1.2, 2.2, 1.3) * core * 14.0 + vec3(0.15, 3.8, 0.65) * halo * 2.2) * uBeamEnd.w;\n"
"  }\n"
"\n"
"  imageStore(uVolOut, gid, vec4(clamp(accum, 0.0, 42.0), tLimit));\n"
"}\n";

// --- PASS 3: ZERO-GHOSTING DUAL-MRT TAA (PURE OPAQUE HISTORY + BILATERAL VOLUMETRIC SCENE) ---
static const char *FS_TAA_SRC =
"#version 430 core\n"
"in vec2 vUv;\n"
"layout(location = 0) out vec4 outHistory;\n"
"layout(location = 1) out vec4 outScene;\n"
"uniform sampler2D uCurrTex;\n"
"uniform sampler2D uDepthTex;\n"
"uniform sampler2D uVolTex;\n"
"uniform sampler2D uHistTex;\n"
"uniform vec2  uResolution;\n"
"uniform int   uEnableTAA;\n"
"uniform float uBlendFactor;\n"
"uniform vec3  uCamPos;\n"
"uniform mat4  uInvViewProj;\n"
"uniform mat4  uPrevViewProj;\n"
"\n"
"vec3 rgb2ycocg(vec3 c) {\n"
"  return vec3(0.25*c.r + 0.5*c.g + 0.25*c.b, 0.5*c.r - 0.5*c.b, -0.25*c.r + 0.5*c.g - 0.25*c.b);\n"
"}\n"
"vec3 ycocg2rgb(vec3 c) {\n"
"  return vec3(c.x + c.y - c.z, c.x + c.z, c.x - c.y - c.z);\n"
"}\n"
"vec3 sampleVolBilateral(vec2 uv, float centerDist) {\n"
"  ivec2 volSize = textureSize(uVolTex, 0);\n"
"  vec2 fCoord = uv * vec2(volSize) - 0.5;\n"
"  ivec2 base = ivec2(floor(fCoord));\n"
"  vec2 f = clamp(fCoord - vec2(base), 0.0, 1.0);\n"
"  vec3 sum = vec3(0.0); float wSum = 0.0;\n"
"  float depthScale = max(centerDist * 0.14, 1.2);\n"
"  for (int dy = 0; dy <= 1; dy++) {\n"
"    for (int dx = 0; dx <= 1; dx++) {\n"
"      ivec2 tc = clamp(base + ivec2(dx, dy), ivec2(0), volSize - 1);\n"
"      vec4 tap = texelFetch(uVolTex, tc, 0);\n"
"      float bw = ((dx == 0) ? (1.0 - f.x) : f.x) * ((dy == 0) ? (1.0 - f.y) : f.y);\n"
"      float dw = exp(-abs(centerDist - tap.a) / depthScale);\n"
"      float w = bw * (dw + 1e-4);\n"
"      sum += tap.rgb * w; wSum += w;\n"
"    }\n"
"  }\n"
"  return sum / max(wSum, 1e-4);\n"
"}\n"
"void main() {\n"
"  vec3 curr = texture(uCurrTex, vUv).rgb;\n"
"  float rawDepth = texture(uDepthTex, vUv).r;\n"
"  vec4 wp = uInvViewProj * vec4(vUv * 2.0 - 1.0, rawDepth * 2.0 - 1.0, 1.0);\n"
"  vec3 worldPos = wp.xyz / wp.w;\n"
"  float linDist = (rawDepth < 0.99999) ? length(worldPos - uCamPos) : 1800.0;\n"
"  vec3 vol = sampleVolBilateral(vUv, linDist);\n"
"  if (uEnableTAA == 0 || uBlendFactor <= 0.001) {\n"
"    outHistory = vec4(curr, 1.0);\n"
"    outScene   = vec4(curr + vol, 1.0);\n"
"    return;\n"
"  }\n"
"  vec4 prevClip = uPrevViewProj * vec4(worldPos, 1.0);\n"
"  vec2 prevUv = (prevClip.xy / max(prevClip.w, 1e-4)) * 0.5 + 0.5;\n"
"  if (prevClip.w <= 0.05 || prevUv.x < 0.002 || prevUv.x > 0.998 || prevUv.y < 0.002 || prevUv.y > 0.998) {\n"
"    outHistory = vec4(curr, 1.0);\n"
"    outScene   = vec4(curr + vol, 1.0);\n"
"    return;\n"
"  }\n"
"  // Tight 3x3 YCoCg variance clamp on pure opaque buffer (zero laser/plume ghosting!)\n"
"  vec2 texel = 1.0 / uResolution;\n"
"  vec3 m1 = vec3(0.0), m2 = vec3(0.0);\n"
"  for (int y = -1; y <= 1; y++) {\n"
"    for (int x = -1; x <= 1; x++) {\n"
"      vec3 ycc = rgb2ycocg(texture(uCurrTex, vUv + vec2(float(x), float(y)) * texel).rgb);\n"
"      m1 += ycc; m2 += ycc * ycc;\n"
"    }\n"
"  }\n"
"  vec3 mu = m1 / 9.0;\n"
"  vec3 sigma = sqrt(max(m2 / 9.0 - mu * mu, vec3(0.0)));\n"
"  vec3 histClamped = ycocg2rgb(clamp(rgb2ycocg(texture(uHistTex, prevUv).rgb), mu - 0.92 * sigma, mu + 0.92 * sigma));\n"
"  float lCurr = dot(curr, vec3(0.2126, 0.7152, 0.0722));\n"
"  float lHist = dot(histClamped, vec3(0.2126, 0.7152, 0.0722));\n"
"  float wCurr = 1.0 / (1.0 + lCurr);\n"
"  float wHist = 1.0 / (1.0 + lHist);\n"
"  // Suppress TAA on high-emissive pixels & fast silhouette transitions\n"
"  float alpha = clamp(uBlendFactor, 0.0, 0.76) * smoothstep(5.5, 1.2, max(lCurr, lHist));\n"
"  vec3 blended = (curr * (1.0 - alpha) * wCurr + histClamped * alpha * wHist)\n"
"               / max((1.0 - alpha) * wCurr + alpha * wHist, 1e-4);\n"
"  blended = max(blended, vec3(0.0));\n"
"  outHistory = vec4(blended, 1.0);\n"
"  outScene   = vec4(blended + vol, 1.0);\n"
"}\n";

// --- PASS 4: SPACE-CALIBRATED 8x8 SHARED-MEMORY EYE ADAPTATION COMPUTE ---
static const char *CS_ADAPT_SRC =
"#version 430 core\n"
"layout(local_size_x = 8, local_size_y = 8, local_size_z = 1) in;\n"
"layout(rgba16f, binding = 0) writeonly uniform image2D uLumOut;\n"
"uniform sampler2D uHdrTex;\n"
"uniform sampler2D uPrevLumTex;\n"
"uniform float uDt;\n"
"uniform int uReset;\n"
"shared float sLog[64];\n"
"shared float sWeight[64];\n"
"void main() {\n"
"  uint idx = gl_LocalInvocationIndex;\n"
"  vec2 uv = (vec2(gl_LocalInvocationID.xy) + 0.5) / 8.0;\n"
"  float lum = dot(texture(uHdrTex, uv).rgb, vec3(0.2126, 0.7152, 0.0722));\n"
"  float d = length(uv - 0.5);\n"
"  // Highlight-biased weighting so black space never overexposes ships or Dreadnought!\n"
"  float w = exp(-d * d * 2.8) * (0.25 + smoothstep(0.05, 0.65, lum));\n"
"  sLog[idx] = log2(clamp(lum, 0.16, 20.0)) * w;\n"
"  sWeight[idx] = w;\n"
"  barrier();\n"
"  for (uint stride = 32u; stride > 0u; stride >>= 1u) {\n"
"    if (idx < stride) { sLog[idx] += sLog[idx + stride]; sWeight[idx] += sWeight[idx + stride]; }\n"
"    barrier();\n"
"  }\n"
"  if (idx == 0u) {\n"
"    float avgLum = exp2(sLog[0] / max(sWeight[0], 1e-4));\n"
"    float prevLum = texelFetch(uPrevLumTex, ivec2(0, 0), 0).r;\n"
"    float adapted = (uReset == 1 || isnan(prevLum) || prevLum <= 0.001)\n"
"      ? avgLum : (prevLum + (avgLum - prevLum) * (1.0 - exp(-uDt * ((avgLum > prevLum) ? 3.2 : 1.6))));\n"
"    imageStore(uLumOut, ivec2(0, 0), vec4(clamp(adapted, 0.20, 10.0), 0.0, 0.0, 1.0));\n"
"  }\n"
"}\n";

// --- PASS 5 & 6: KARIS BRIGHT-PASS & SEPARABLE GAUSSIAN / ANAMORPHIC BLUR ---
static const char *FS_BRIGHT_SRC =
"#version 430 core\n"
"in vec2 vUv;\n"
"out vec4 outColor;\n"
"uniform sampler2D uHdrTex;\n"
"uniform vec2 uTexelSize;\n"
"uniform float uThreshold;\n"
"float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }\n"
"vec3 karisSample(vec2 uv) { vec3 c = texture(uHdrTex, uv).rgb; return c / (1.0 + luma(c)); }\n"
"void main() {\n"
"  vec3 avg = 0.25 * (\n"
"    karisSample(vUv + vec2(-0.5, -0.5) * uTexelSize) + karisSample(vUv + vec2( 0.5, -0.5) * uTexelSize) +\n"
"    karisSample(vUv + vec2(-0.5,  0.5) * uTexelSize) + karisSample(vUv + vec2( 0.5,  0.5) * uTexelSize));\n"
"  avg = avg / max(1.0 - luma(avg), 0.04);\n"
"  float br = max(avg.r, max(avg.g, avg.b));\n"
"  float knee = uThreshold * 0.50;\n"
"  float soft = clamp(br - uThreshold + knee, 0.0, 2.0 * knee);\n"
"  soft = (soft * soft) / max(4.0 * knee, 1e-4);\n"
"  outColor = vec4(max(avg * (max(soft, br - uThreshold) / max(br, 1e-4)), vec3(0.0)), 1.0);\n"
"}\n";

static const char *FS_BLUR_SRC =
"#version 430 core\n"
"in vec2 vUv;\n"
"out vec4 outColor;\n"
"uniform sampler2D uTex;\n"
"uniform vec2 uDir;\n"
"void main() {\n"
"  const float w[5] = float[](0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216);\n"
"  vec3 sum = texture(uTex, vUv).rgb * w[0];\n"
"  for (int i = 1; i < 5; i++) {\n"
"    vec2 off = uDir * float(i) * 1.45;\n"
"    sum += (texture(uTex, vUv + off).rgb + texture(uTex, vUv - off).rgb) * w[i];\n"
"  }\n"
"  outColor = vec4(sum, 1.0);\n"
"}\n";

// --- PASS 7: CINEMATIC COMPOSITOR + LENS FLARE + RCAS + SLEEK TACTICAL HUD ---
static const char *FS_COMPOSITE_A_SRC =
"#version 430 core\n"
"in vec2 vUv;\n"
"out vec4 outColor;\n"
"uniform sampler2D uHdrTex;\n"
"uniform sampler2D uBloomTex;\n"
"uniform sampler2D uStreakTex;\n"
"uniform sampler2D uLumTex;\n"
"uniform vec2  uResolution;\n"
"uniform float uTime;\n"
"uniform int   uFilter;\n"
"uniform int   uToneMap;\n"
"uniform int   uAutoExp;\n"
"uniform float uExposureBias;\n"
"uniform float uBoost;\n"
"uniform float uDamageFlash;\n"
"uniform float uHitFlash;\n"
"uniform vec3  uSunScreen;     // xy=uv, z=visibility(0..1)\n"
"uniform int   uSplitEnabled;\n"
"uniform float uSplitPos;\n"
"uniform int   uGameState;\n"
"uniform int   uMissionPhase;\n"
"uniform vec2  uAimUv;\n"
"uniform vec4  uHudVitals;\n"
"uniform vec4  uHudMeta;\n"
"uniform vec4  uLockPos;\n"
"uniform vec4  uLeadPos;\n"
"uniform int   uMarkerCount;\n"
"uniform vec4  uMarkers[16];\n"
"\n"
"vec3 agxDefaultContrastApprox(vec3 x) {\n"
"  vec3 x2 = x * x, x4 = x2 * x2;\n"
"  return + 15.5 * x4 * x2 - 40.14 * x4 * x + 31.96 * x4 - 6.868 * x2 * x + 0.4298 * x2 + 0.1191 * x - 0.00232;\n"
"}\n"
"vec3 toneMapAgX(vec3 val) {\n"
"  const mat3 m1 = mat3(0.842479,0.042328,0.042376, 0.078434,0.878469,0.078434, 0.079224,0.079166,0.879143);\n"
"  const mat3 m2 = mat3(1.196879,-0.052897,-0.052972, -0.098021,1.151903,-0.098043, -0.099030,-0.098961,1.151074);\n"
"  val = m1 * max(val, vec3(1e-6));\n"
"  val = (clamp(log2(val), -12.47393, 4.026069) + 12.47393) / (4.026069 + 12.47393);\n"
"  val = m2 * agxDefaultContrastApprox(val);\n"
"  float luma = dot(val, vec3(0.2126, 0.7152, 0.0722));\n"
"  val = pow(max(val, vec3(0.0)), vec3(1.12));\n"
"  return clamp(mix(vec3(luma), val, 1.18), 0.0, 1.0);\n"
"}\n"
"vec3 toneMapACES(vec3 x) { return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }\n"
"vec3 toneMapPBRNeutral(vec3 c) {\n"
"  float x = min(c.r, min(c.g, c.b));\n"
"  c -= (x < 0.08) ? (x - 6.25 * x * x) : 0.04;\n"
"  float pk = max(c.r, max(c.g, c.b));\n"
"  if (pk < 0.76) return clamp(c, 0.0, 1.0);\n"
"  float np = 1.0 - 0.0576 / (pk - 0.52);\n"
"  return clamp(mix(c * (np / pk), vec3(np), 1.0 - 1.0 / (0.15 * (pk - np) + 1.0)), 0.0, 1.0);\n"
"}\n"
"vec3 hableP(vec3 x) { return ((x*(0.15*x+0.05)+0.004)/(x*(0.15*x+0.50)+0.06)) - 0.02/0.30; }\n"
"vec3 applyToneMap(vec3 h) {\n"
"  if (uToneMap == 0) return toneMapAgX(h);\n"
"  if (uToneMap == 1) return toneMapACES(h);\n"
"  if (uToneMap == 2) return toneMapPBRNeutral(h);\n"
"  return clamp(hableP(h * 2.0) / hableP(vec3(11.2)), 0.0, 1.0);\n"
"}\n"
"vec2 distortUV(vec2 uv, float k1, float k2) {\n"
"  vec2 p = uv * 2.0 - 1.0;\n"
"  float asp = uResolution.x / uResolution.y;\n"
"  p.x *= asp; float r2 = dot(p, p);\n"
"  p *= (1.0 + k1 * r2 + k2 * r2 * r2) / (1.0 + k1 * 1.15 + k2 * 1.32);\n"
"  p.x /= asp;\n"
"  return p * 0.5 + 0.5;\n"
"}\n"
"float filmHash(vec2 p, float t) {\n"
"  vec3 p3 = fract(vec3(p.xyx) * 0.1031 + fract(t * 17.31));\n"
"  p3 += dot(p3, p3.yzx + 33.33);\n"
"  return fract((p3.x + p3.y) * p3.z);\n"
"}\n"
"float sdSeg(vec2 p, vec2 a, vec2 b, float r) {\n"
"  vec2 pa = p - a, ba = b - a;\n"
"  return length(pa - ba * clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0)) - r;\n"
"}\n"
"float drawDigit(vec2 p, int d) {\n"
"  const int mask[10] = int[](0x77,0x24,0x5D,0x6D,0x2E,0x6B,0x7B,0x25,0x7F,0x6F);\n"
"  int m = mask[clamp(d, 0, 9)];\n"
"  float dist = 1e5, r = 0.082;\n"
"  if ((m & 0x01) != 0) dist = min(dist, sdSeg(p, vec2(-0.35, 0.80), vec2( 0.35, 0.80), r));\n"
"  if ((m & 0x02) != 0) dist = min(dist, sdSeg(p, vec2(-0.40, 0.72), vec2(-0.40, 0.08), r));\n"
"  if ((m & 0x04) != 0) dist = min(dist, sdSeg(p, vec2( 0.40, 0.72), vec2( 0.40, 0.08), r));\n"
"  if ((m & 0x08) != 0) dist = min(dist, sdSeg(p, vec2(-0.35, 0.00), vec2( 0.35, 0.00), r));\n"
"  if ((m & 0x10) != 0) dist = min(dist, sdSeg(p, vec2(-0.40,-0.08), vec2(-0.40,-0.72), r));\n"
"  if ((m & 0x20) != 0) dist = min(dist, sdSeg(p, vec2( 0.40,-0.08), vec2( 0.40,-0.72), r));\n"
"  if ((m & 0x40) != 0) dist = min(dist, sdSeg(p, vec2(-0.35,-0.80), vec2( 0.35,-0.80), r));\n"
"  return smoothstep(0.06, -0.02, dist);\n"
"}\n"
"float drawNumber(vec2 p, int val, int digits) {\n"
"  float a = 0.0;\n"
"  int v = max(val, 0);\n"
"  for (int i = 0; i < 6; i++) {\n"
"    if (i >= digits) break;\n"
"    int dig = v % 10; v /= 10;\n"
"    vec2 dp = p - vec2(float(digits - 1 - i) * 1.28, 0.0);\n"
"    if (abs(dp.x) < 0.75 && abs(dp.y) < 1.05) a = max(a, drawDigit(dp, dig));\n"
"  }\n"
"  return a;\n"
"}\n"
"// Subtle Multi-Element Cinema Optical Lens Flare when facing the distant star\n"
"vec3 evalLensFlare(vec2 uv, vec3 sunScr) {\n"
"  if (sunScr.z <= 0.005) return vec3(0.0);\n"
"  float asp = uResolution.x / uResolution.y;\n"
"  vec2 axis = vec2(0.5) - sunScr.xy;\n"
"  vec3 fl = vec3(0.0);\n"
"  // 3 soft chromatic bokeh ghosts + subtle anamorphic blue starburst\n"
"  vec2 g1 = (uv - (sunScr.xy + axis * 0.45)) * vec2(asp, 1.0);\n"
"  vec2 g2 = (uv - (sunScr.xy + axis * 1.25)) * vec2(asp, 1.0);\n"
"  vec2 g3 = (uv - (sunScr.xy + axis * 1.78)) * vec2(asp, 1.0);\n"
"  fl += vec3(0.28, 0.58, 1.0) * exp(-dot(g1, g1) * 42.0) * 0.22;\n"
"  fl += vec3(0.95, 0.55, 0.22) * smoothstep(0.065, 0.015, length(g2)) * 0.14;\n"
"  fl += vec3(0.32, 0.85, 0.75) * smoothstep(0.018, 0.004, abs(length(g3) - 0.075)) * 0.12;\n"
"  vec2 sd = (uv - sunScr.xy) * vec2(asp, 1.0);\n"
"  fl += vec3(0.45, 0.75, 1.25) * exp(-abs(sd.y) * 95.0) * exp(-abs(sd.x) * 3.2) * 0.28;\n"
"  return fl * sunScr.z;\n"
"}\n";

static const char *FS_COMPOSITE_B_SRC =
"vec3 sampleFilteredHDR(vec2 uv, float exposure, float sharpAmt, float caAmt, float boostBlur) {\n"
"  vec2 texel = 1.0 / vec2(textureSize(uHdrTex, 0));\n"
"  vec2 toC = uv - 0.5;\n"
"  vec2 caOff = toC * dot(toC, toC) * (0.010 * caAmt + 0.013 * boostBlur);\n"
"  vec3 c0 = vec3(\n"
"    texture(uHdrTex, clamp(uv + caOff, 0.001, 0.999)).r,\n"
"    texture(uHdrTex, uv).g,\n"
"    texture(uHdrTex, clamp(uv - caOff, 0.001, 0.999)).b);\n"
"  if (sharpAmt > 0.01) {\n"
"    vec3 n = texture(uHdrTex, uv + vec2(0.0,  texel.y)).rgb;\n"
"    vec3 s = texture(uHdrTex, uv + vec2(0.0, -texel.y)).rgb;\n"
"    vec3 e = texture(uHdrTex, uv + vec2( texel.x, 0.0)).rgb;\n"
"    vec3 w = texture(uHdrTex, uv + vec2(-texel.x, 0.0)).rgb;\n"
"    vec3 mn = min(c0, min(min(n, s), min(e, w)));\n"
"    vec3 mx = max(c0, max(max(n, s), max(e, w)));\n"
"    vec3 amp = clamp(min(mn, 2.0 - mx) / max(mx, vec3(1e-4)), 0.0, 1.0);\n"
"    vec3 wt = sqrt(amp) * (-1.0 / mix(8.0, 5.0, sharpAmt));\n"
"    c0 = max((c0 + (n + s + e + w) * wt) / (1.0 + 4.0 * wt), vec3(0.0));\n"
"  }\n"
"  if (boostBlur > 0.02) {\n"
"    vec3 acc = c0 * 0.54;\n"
"    float r = length(toC);\n"
"    vec2 dir = toC * (0.024 * boostBlur * r);\n"
"    acc += texture(uHdrTex, clamp(uv - dir * 0.5, 0.001, 0.999)).rgb * 0.27;\n"
"    acc += texture(uHdrTex, clamp(uv - dir * 1.0, 0.001, 0.999)).rgb * 0.19;\n"
"    c0 = acc;\n"
"  }\n"
"  return c0 * exposure;\n"
"}\n"
"\n"
"vec3 overlayTacticalHUD(vec3 srgb, vec2 uv) {\n"
"  float asp = uResolution.x / uResolution.y;\n"
"  vec2 p = (uv - 0.5) * vec2(asp, 1.0);\n"
"  vec3 hudCol = vec3(0.0);\n"
"  float hudA = 0.0;\n"
"\n"
"  if (uGameState == 2) {\n"
"    float cr = length(p);\n"
"    // 2. Subtle Center Boresight Reference\n"
"    float crossX = step(abs(p.y), 0.0011) * step(0.011, abs(p.x)) * step(abs(p.x), 0.021);\n"
"    float crossY = step(abs(p.x), 0.0011) * step(0.011, abs(p.y)) * step(abs(p.y), 0.021);\n"
"    float ch = max(crossX, crossY);\n"
"    hudCol += vec3(0.35, 0.85, 1.0) * ch * 0.50; hudA = max(hudA, ch * 0.48);\n"
"\n"
"    // 3. Mouse Aim Steering Reticle + Crisp Combat Hitmarker 'X'\n"
"    vec2 ap = (uv - uAimUv) * vec2(asp, 1.0);\n"
"    float ar = length(ap);\n"
"    float aimRing = smoothstep(0.0020, 0.0005, abs(ar - 0.024));\n"
"    float aimDot  = smoothstep(0.0032, 0.0012, ar);\n"
"    float aimTicks = (step(abs(ap.y), 0.0012) * step(0.024, abs(ap.x)) * step(abs(ap.x), 0.033)) +\n"
"                     (step(abs(ap.x), 0.0012) * step(0.024, abs(ap.y)) * step(abs(ap.y), 0.033));\n"
"    float aimMask = clamp(aimRing * 0.72 + aimDot + aimTicks * 0.70, 0.0, 1.0);\n"
"    vec3 aimTint = (uLockPos.w > 0.5 && uLockPos.z > 0.8) ? vec3(1.0, 0.25, 0.22) : vec3(0.42, 0.94, 1.0);\n"
"    hudCol += aimTint * aimMask; hudA = max(hudA, aimMask * 0.84);\n"
"    if (uHitFlash > 0.02) {\n"
"      vec2 rp = vec2(ap.x + ap.y, ap.x - ap.y) * 0.7071;\n"
"      float hx = (step(abs(rp.y), 0.0018) * step(0.007, abs(rp.x)) * step(abs(rp.x), 0.020)) +\n"
"                 (step(abs(rp.x), 0.0018) * step(0.007, abs(rp.y)) * step(abs(rp.y), 0.020));\n"
"      hudCol += vec3(1.0, 0.92, 0.35) * hx * uHitFlash; hudA = max(hudA, hx * uHitFlash * 0.95);\n"
"    }\n"
"\n"
"    // 4. Sleeker, Wider Translucent Cockpit Arcs (gives X-Wing wide visual breathing room!)\n"
"    if (abs(p.x) > 0.22 && abs(p.y) < 0.20) {\n"
"      float tArc = clamp((p.y + 0.17) / 0.34, 0.0, 1.0);\n"
"      float bOuter = smoothstep(0.0034, 0.0009, abs(cr - 0.326));\n"
"      float bInner = smoothstep(0.0034, 0.0009, abs(cr - 0.312));\n"
"      if (p.x < 0.0) {\n"
"        vec3 hCol = mix(vec3(1.0, 0.20, 0.15), vec3(0.24, 0.95, 0.48), smoothstep(0.22, 0.65, uHudVitals.x));\n"
"        hudCol += vec3(0.18, 0.86, 1.0) * bOuter * mix(0.14, 0.92, step(tArc, uHudVitals.y));\n"
"        hudCol += hCol * bInner * mix(0.14, 0.92, step(tArc, uHudVitals.x));\n"
"      } else {\n"
"        hudCol += vec3(1.0, 0.26, 0.30) * bOuter * mix(0.14, 0.90, step(tArc, uHudVitals.z));\n"
"        hudCol += vec3(1.0, 0.22, 0.68) * bInner * mix(0.14, 0.90, step(tArc, uHudVitals.w));\n"
"      }\n"
"      hudA = max(hudA, max(bOuter, bInner) * 0.58);\n"
"    }\n"
"\n"
"    // 5. Sleek Top-Center Mission Phase / Boss Bar\n"
"    vec2 bp = uv - vec2(0.5, 0.954);\n"
"    if (abs(bp.x) < 0.172 && abs(bp.y) < 0.0085) {\n"
"      float border = step(0.168, abs(bp.x)) + step(0.0065, abs(bp.y));\n"
"      float fill = step((bp.x + 0.168) / 0.336, clamp(uHudMeta.x, 0.0, 1.0));\n"
"      vec3 barCol = (uMissionPhase == 3) ? vec3(0.22, 1.0, 0.35) : ((uMissionPhase == 2) ? vec3(1.0, 0.68, 0.18) : vec3(0.32, 0.85, 1.0));\n"
"      hudCol += barCol * (border > 0.5 ? 0.50 : mix(0.10, 0.88, fill));\n"
"      hudA = max(hudA, 0.72);\n"
"    }\n"
"\n"
"    // 6. Bottom-Center Proton Torpedo Pips\n"
"    int torps = int(uHudMeta.y + 0.5);\n"
"    for (int t = 0; t < 6; t++) {\n"
"      vec2 tp = (uv - vec2(0.455 + float(t) * 0.018, 0.044)) * vec2(asp, 1.0);\n"
"      float dPip = smoothstep(0.0075, 0.0045, abs(tp.x) + abs(tp.y));\n"
"      vec3 pCol = (t < torps) ? vec3(0.35, 0.95, 1.0) : vec3(0.22, 0.25, 0.30);\n"
"      hudCol += pCol * dPip * (t < torps ? 0.92 : 0.30);\n"
"      hudA = max(hudA, dPip * 0.68);\n"
"    }\n"
"\n"
"    // 7. Ballistic Lead Indicator Pip\n"
"    if (uLeadPos.w > 0.5) {\n"
"      vec2 lp = (uv - uLeadPos.xy) * vec2(asp, 1.0);\n"
"      float lr = length(lp);\n"
"      float lm = max(smoothstep(0.0018, 0.0005, abs(lr - 0.012)), smoothstep(0.0026, 0.0010, lr));\n"
"      hudCol += vec3(1.0, 0.86, 0.24) * lm; hudA = max(hudA, lm * 0.88);\n"
"    }\n"
"\n"
"    // 8. Animated Missile Lock-On Diamond\n"
"    if (uLockPos.w > 0.5) {\n"
"      vec2 kp = (uv - uLockPos.xy) * vec2(asp, 1.0);\n"
"      float sz = mix(0.052, 0.024, uLockPos.z);\n"
"      float ring = smoothstep(0.0022, 0.0006, abs(abs(kp.x) + abs(kp.y) - sz));\n"
"      vec3 lCol = mix(vec3(1.0, 0.75, 0.2), vec3(1.0, 0.16, 0.16), step(0.85, uLockPos.z));\n"
"      hudCol += lCol * ring; hudA = max(hudA, ring * 0.92);\n"
"    }\n"
"\n"
"    // 9. Enemy & Objective Corner Brackets / Off-Screen Perimeter Chevrons\n"
"    for (int i = 0; i < 16; i++) {\n"
"      if (i >= uMarkerCount) break;\n"
"      vec4 m = uMarkers[i];\n"
"      vec3 mCol = (m.z > 1.5) ? vec3(1.0, 0.72, 0.15) : ((m.z > 0.5) ? vec3(1.0, 0.42, 0.16) : vec3(0.32, 1.0, 0.45));\n"
"      if (m.w > 0.5) {\n"
"        vec2 mp = (uv - m.xy) * vec2(asp, 1.0);\n"
"        float dBox = max(abs(mp.x), abs(mp.y));\n"
"        float box = smoothstep(0.0018, 0.0005, abs(dBox - 0.014)) * step(0.006, min(abs(mp.x), abs(mp.y)));\n"
"        hudCol += mCol * box * 0.82; hudA = max(hudA, box * 0.72);\n"
"      } else {\n"
"        vec2 dir = normalize((m.xy - 0.5) * vec2(asp, 1.0) + vec2(1e-5));\n"
"        vec2 edgeP = dir * 0.40;\n"
"        float arrow = smoothstep(0.0065, 0.0025, length(p - edgeP));\n"
"        hudCol += mCol * arrow * 0.65; hudA = max(hudA, arrow * 0.62);\n"
"      }\n"
"    }\n"
"  }\n"
"\n"
"  return mix(srgb, clamp(hudCol, 0.0, 1.0), clamp(hudA, 0.0, 0.90));\n"
"}\n"
"\n"
"void main() {\n"
"  // Calibrated Space Exposure: keeps deep space jet-black while adapting down on huge explosions!\n"
"  float avgLum = texelFetch(uLumTex, ivec2(0, 0), 0).r;\n"
"  float autoScale = (uAutoExp == 1) ? clamp(0.24 / max(avgLum, 0.22), 0.38, 1.08) : 1.0;\n"
"  float exposure = autoScale * exp2(uExposureBias);\n"
"  if (uSplitEnabled == 1) {\n"
"    if (abs(vUv.x - uSplitPos) * uResolution.x < 1.5) { outColor = vec4(0.22, 0.74, 0.97, 1.0); return; }\n"
"    if (vUv.x < uSplitPos) {\n"
"      vec3 raw = texture(uHdrTex, vUv).rgb * exp2(uExposureBias) * 0.75;\n"
"      outColor = vec4(pow(clamp(raw, 0.0, 1.0), vec3(1.0 / 2.2)), 1.0);\n"
"      return;\n"
"    }\n"
"  }\n"
"  vec2 uv = vUv;\n"
"  float caMult = 0.65, grainMult = 0.24, sharpMult = 0.58, vigPow = 0.34, streakAmt = 0.24, bloomAmt = 0.56;\n"
"  if (uFilter == 1) {\n"
"    uv = distortUV(vUv, 0.12, 0.032);\n"
"    caMult = 1.25; grainMult = 0.55; sharpMult = 0.82; vigPow = 0.52; streakAmt = 0.18;\n"
"  } else if (uFilter == 2) {\n"
"    uv = distortUV(vUv, 0.04, 0.01);\n"
"    caMult = 0.95; streakAmt = 0.65; vigPow = 0.42;\n"
"  } else if (uFilter == 3) {\n"
"    caMult = 0.12; grainMult = 0.06; vigPow = 0.10; streakAmt = 0.06;\n"
"  }\n"
"  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) { outColor = vec4(0.0,0.0,0.0,1.0); return; }\n"
"  vec3 hdr = sampleFilteredHDR(uv, exposure, sharpMult, caMult, uBoost);\n"
"  vec3 bloom  = texture(uBloomTex, uv).rgb * exposure;\n"
"  vec3 streak = texture(uStreakTex, uv).rgb * exposure;\n"
"  vec3 halation = bloom * vec3(1.16, 0.86, 0.78);\n"
"  vec3 streakTint = (uFilter == 2) ? vec3(0.62, 0.82, 1.35) : vec3(0.95, 0.90, 1.06);\n"
"  hdr += mix(bloom, halation, 0.28) * (0.28 * bloomAmt);\n"
"  hdr += streak * streakTint * (streakAmt * bloomAmt);\n"
"  hdr += evalLensFlare(uv, uSunScreen);\n"
"  float r = length((uv - 0.5) * vec2(uResolution.x / uResolution.y, 1.0));\n"
"  float vig = pow(clamp(cos(min(r * 0.76, 1.35)), 0.0, 1.0), 4.0);\n"
"  hdr *= mix(1.0, vig, clamp(vigPow, 0.0, 0.90));\n"
"  if (uDamageFlash > 0.01) hdr += vec3(1.6, 0.10, 0.06) * uDamageFlash * smoothstep(0.32, 0.95, r);\n"
"  vec3 ldr = applyToneMap(hdr);\n"
"  if (uFilter == 1) {\n"
"    float luma = dot(ldr, vec3(0.2126, 0.7152, 0.0722));\n"
"    ldr = mix(vec3(luma), ldr, 0.88);\n"
"    ldr = clamp((ldr - 0.5) * 1.12 + 0.5, 0.0, 1.0);\n"
"  }\n"
"  if (grainMult > 0.005) {\n"
"    float g = (filmHash(gl_FragCoord.xy, uTime) + filmHash(gl_FragCoord.xy + vec2(37.0, 17.0), uTime * 1.13) - 1.0) * 0.030 * grainMult;\n"
"    float luma = dot(ldr, vec3(0.2126, 0.7152, 0.0722));\n"
"    // Only apply grain to illuminated areas so pitch-black vacuum stays ultra-clean!\n"
"    ldr = clamp(ldr + g * smoothstep(0.01, 0.14, luma) * (1.0 - smoothstep(0.65, 1.0, luma)), 0.0, 1.0);\n"
"  }\n"
"  vec3 srgb = mix(ldr * 12.92, 1.055 * pow(max(ldr, vec3(0.0)), vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), ldr));\n"
"  srgb = overlayTacticalHUD(clamp(srgb, 0.0, 1.0), vUv);\n"
"  outColor = vec4(srgb, 1.0);\n"
"}\n";


// --- PASS 8: FULL-RES GPU 2D UI, ANIMATED SPLASH & CRISP 5x7 BITMAP FONT ENGINE ---
static const char *VS_UI_SRC =
"#version 430 core\n"
"layout(location = 0) in vec2  aPos;\n"
"layout(location = 1) in vec2  aUv;\n"
"layout(location = 2) in vec4  aCol;\n"
"layout(location = 3) in float aMode;\n"
"uniform vec2 uResolution;\n"
"out vec2  vUv;\n"
"out vec4  vCol;\n"
"out float vMode;\n"
"void main() {\n"
"  vec2 ndc = (aPos / max(uResolution, vec2(1.0))) * 2.0 - 1.0;\n"
"  ndc.y = -ndc.y;\n"
"  gl_Position = vec4(ndc, 0.0, 1.0);\n"
"  vUv   = aUv;\n"
"  vCol  = aCol;\n"
"  vMode = aMode;\n"
"}\n";

static const char *FS_UI_SRC =
"#version 430 core\n"
"in vec2  vUv;\n"
"in vec4  vCol;\n"
"in float vMode;\n"
"out vec4 outColor;\n"
"uniform sampler2D uFontTex;\n"
"void main() {\n"
"  if (vMode < 0.5) {\n"
"    // Mode 0: Crisp solid / gradient glass UI rectangle\n"
"    outColor = vCol;\n"
"  } else if (vMode < 1.5) {\n"
"    // Mode 1: Crisp 5x7 bitmap font glyph\n"
"    float cov = texture(uFontTex, vUv).r;\n"
"    if (cov < 0.05) discard;\n"
"    outColor = vec4(vCol.rgb, vCol.a * cov);\n"
"  } else if (vMode < 2.5) {\n"
"    // Mode 2: Smooth radial optical glow / anamorphic splash flare\n"
"    vec2 p = vUv * 2.0 - 1.0;\n"
"    float r2 = dot(p, p);\n"
"    float g = exp(-r2 * 4.5) * smoothstep(1.0, 0.0, sqrt(r2));\n"
"    outColor = vec4(vCol.rgb, vCol.a * g);\n"
"  } else {\n"
"    // Mode 3: Smooth holographic crest ring\n"
"    vec2 p = vUv * 2.0 - 1.0;\n"
"    float r = length(p);\n"
"    float ring = smoothstep(0.06, 0.01, abs(r - 0.88));\n"
"    float glow = exp(-pow((r - 0.88) / 0.09, 2.0)) * 0.45;\n"
"    outColor = vec4(vCol.rgb, vCol.a * clamp(ring + glow, 0.0, 1.0));\n"
"  }\n"
"}\n";

// ============================================================================
// FRAMEBUFFERS (MRT ZERO-GHOSTING TAA + HDR FX), SHADER PROGRAMS & UI ENGINE
// ============================================================================
static HWND  g_hwnd = NULL;
static HDC   g_hdc  = NULL;
static HGLRC g_hrc  = NULL;
static HICON g_hIconBig = NULL;
static HICON g_hIconSmall = NULL;
static int   g_running = 1;
static int   g_keys[256] = {0};
static int   g_mouseL = 0, g_mouseR = 0;
static float g_mouseUvX = 0.5f, g_mouseUvY = 0.5f;
static float g_mousePxX = 640.0f, g_mousePxY = 360.0f;
static int   g_winW = 1280, g_winH = 720;
static int   g_renderW = 1280, g_renderH = 720;
static int   g_fullscreen = 0;
static int   g_windowFocused = 1;
static int   g_cursorHidden = 0;
static WINDOWPLACEMENT g_wpPrev;
static GLuint g_emptyVAO = 0;
static GLuint g_timerQuery[2] = {0, 0};
static int    g_queryIdx = 0, g_queryReady = 0;
static float  g_gpuMs = 0.0f;
static float  g_lastFps = 60.0f;
static int    g_hasNvMemInfo = 0;

typedef struct { GLuint fbo, tex, depthTex; int w, h; } RenderTarget;
static RenderTarget g_fboMain      = {0};
static RenderTarget g_fboVol       = {0};
static RenderTarget g_fboTAA[2]    = {{0}, {0}};
static RenderTarget g_fboSceneHDR  = {0};
static GLuint       g_fboSceneFX   = 0;
static RenderTarget g_fboLum[2]    = {{0}, {0}};
static RenderTarget g_fboBloom[2]  = {{0}, {0}};
static RenderTarget g_fboStreak[2] = {{0}, {0}};
static int g_taaIdx = 0, g_lumIdx = 0;
static int g_resetHistory = 1, g_resetAdapt = 1, g_needResize = 0;

static const char *FILTER_NAMES[4] = { "CINEMA HDR", "COCKPIT CAM", "ANAMORPHIC", "RAW STUDIO" };
static const char *TM_NAMES[4]     = { "AGX", "ACES", "PBR-N", "HABLE" };
static const char *VSYNC_NAMES[3]  = { "UNLIM", "ADAPT-NV", "VSYNC" };
static const char *CAM_NAMES[3]    = { "CHASE", "HERO", "COCKPIT" };

typedef struct {
  int   filter, toneMap, autoExp, taa, split, vsyncMode, camMode;
  float splitPos, renderScale, exposure;
} GfxState;

static GfxState g_gfx = { 0, 0, 1, 1, 0, 1, 0, 0.50f, 1.00f, 0.0f };

static void set_cursor_hidden(int hide) {
  if (hide && !g_cursorHidden) {
    ShowCursor(FALSE);
    g_cursorHidden = 1;
  } else if (!hide && g_cursorHidden) {
    ShowCursor(TRUE);
    g_cursorHidden = 0;
  }
}

static void destroy_target(RenderTarget *t) {
  if (t->tex)      { glDeleteTextures(1, &t->tex); t->tex = 0; }
  if (t->depthTex) { glDeleteTextures(1, &t->depthTex); t->depthTex = 0; }
  if (t->fbo)      { pglDeleteFramebuffers(1, &t->fbo); t->fbo = 0; }
  t->w = t->h = 0;
}

static int create_target(RenderTarget *t, int w, int h, GLenum intFmt, GLenum fmt, GLenum type, int needFbo, int needDepth) {
  destroy_target(t);
  t->w = w; t->h = h;
  glGenTextures(1, &t->tex);
  glBindTexture(GL_TEXTURE_2D, t->tex);
  glTexImage2D(GL_TEXTURE_2D, 0, intFmt, w, h, 0, fmt, type, NULL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  if (!needFbo) return 1;

  pglGenFramebuffers(1, &t->fbo);
  pglBindFramebuffer(GL_FRAMEBUFFER, t->fbo);
  pglFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t->tex, 0);

  if (needDepth) {
    glGenTextures(1, &t->depthTex);
    glBindTexture(GL_TEXTURE_2D, t->depthTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, w, h, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    pglFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, t->depthTex, 0);
  }
  GLenum status = pglCheckFramebufferStatus(GL_FRAMEBUFFER);
  pglBindFramebuffer(GL_FRAMEBUFFER, 0);
  return (status == GL_FRAMEBUFFER_COMPLETE) ? 1 : 0;
}

static void rebuild_targets(void) {
  if (g_winW < 1) g_winW = 1;
  if (g_winH < 1) g_winH = 1;
  g_renderW = (int)(g_winW * g_gfx.renderScale + 0.5f);
  g_renderH = (int)(g_winH * g_gfx.renderScale + 0.5f);
  if (g_renderW < 160) g_renderW = 160;
  if (g_renderH < 90)  g_renderH = 90;

  int halfW = g_renderW >> 1; if (halfW < 80) halfW = 80;
  int halfH = g_renderH >> 1; if (halfH < 45) halfH = 45;
  int qtrW  = g_renderW >> 2; if (qtrW  < 40) qtrW  = 40;
  int qtrH  = g_renderH >> 2; if (qtrH  < 24) qtrH  = 24;

  if (g_fboSceneFX) { pglDeleteFramebuffers(1, &g_fboSceneFX); g_fboSceneFX = 0; }

  create_target(&g_fboMain,     g_renderW, g_renderH, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 1, 1);
  create_target(&g_fboVol,      halfW,     halfH,     GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 0, 0);
  create_target(&g_fboSceneHDR, g_renderW, g_renderH, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 0, 0);
  create_target(&g_fboTAA[0],   g_renderW, g_renderH, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 1, 0);
  create_target(&g_fboTAA[1],   g_renderW, g_renderH, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 1, 0);

  const GLenum mrtBufs[2] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1 };
  for (int i = 0; i < 2; i++) {
    pglBindFramebuffer(GL_FRAMEBUFFER, g_fboTAA[i].fbo);
    pglFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, g_fboSceneHDR.tex, 0);
    if (pglDrawBuffers) pglDrawBuffers(2, mrtBufs);
  }
  pglGenFramebuffers(1, &g_fboSceneFX);
  pglBindFramebuffer(GL_FRAMEBUFFER, g_fboSceneFX);
  pglFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_fboSceneHDR.tex, 0);
  pglFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,  GL_TEXTURE_2D, g_fboMain.depthTex, 0);
  pglBindFramebuffer(GL_FRAMEBUFFER, 0);

  if (!create_target(&g_fboBloom[0], halfW, halfH, GL_R11F_G11F_B10F, GL_RGB, GL_FLOAT, 1, 0)) {
    create_target(&g_fboBloom[0],  halfW, halfH, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 1, 0);
    create_target(&g_fboBloom[1],  halfW, halfH, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 1, 0);
    create_target(&g_fboStreak[0], qtrW,  qtrH,  GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 1, 0);
    create_target(&g_fboStreak[1], qtrW,  qtrH,  GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 1, 0);
  } else {
    create_target(&g_fboBloom[1],  halfW, halfH, GL_R11F_G11F_B10F, GL_RGB, GL_FLOAT, 1, 0);
    create_target(&g_fboStreak[0], qtrW,  qtrH,  GL_R11F_G11F_B10F, GL_RGB, GL_FLOAT, 1, 0);
    create_target(&g_fboStreak[1], qtrW,  qtrH,  GL_R11F_G11F_B10F, GL_RGB, GL_FLOAT, 1, 0);
  }

  if (!g_fboLum[0].tex) {
    create_target(&g_fboLum[0], 1, 1, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 0, 0);
    create_target(&g_fboLum[1], 1, 1, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, 0, 0);
  }
  g_resetHistory = 1;
}

// --- SHADER COMPILER & UNIFORM LOCATIONS ---
static GLuint compile_shader_parts(GLenum type, const char **parts, int count, const char *label) {
  GLuint sh = pglCreateShader(type);
  pglShaderSource(sh, count, parts, NULL);
  pglCompileShader(sh);
  GLint ok = 0;
  pglGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
  if (!ok) {
    char log[4096], title[128]; log[0] = '\0';
    pglGetShaderInfoLog(sh, (GLsizei)sizeof(log), NULL, log);
    snprintf(title, sizeof(title), "STARFORGE V3 Shader Error: %s", label);
    MessageBoxA(g_hwnd, log, title, MB_OK | MB_ICONERROR);
    return 0;
  }
  return sh;
}

static GLuint link_prog(GLuint prog, const char *label) {
  pglLinkProgram(prog);
  GLint ok = 0;
  pglGetProgramiv(prog, GL_LINK_STATUS, &ok);
  if (!ok) {
    char log[4096], title[128]; log[0] = '\0';
    pglGetProgramInfoLog(prog, (GLsizei)sizeof(log), NULL, log);
    snprintf(title, sizeof(title), "STARFORGE V3 Link Error: %s", label);
    MessageBoxA(g_hwnd, log, title, MB_OK | MB_ICONERROR);
    return 0;
  }
  return prog;
}

static GLuint make_gfx_prog(const char *vsSrc, const char **fsParts, int fsCnt, const char *label) {
  GLuint vs = compile_shader_parts(GL_VERTEX_SHADER, &vsSrc, 1, label);
  GLuint fs = compile_shader_parts(GL_FRAGMENT_SHADER, fsParts, fsCnt, label);
  if (!vs || !fs) return 0;
  GLuint p = pglCreateProgram();
  pglAttachShader(p, vs); pglAttachShader(p, fs);
  GLuint ok = link_prog(p, label);
  pglDeleteShader(vs); pglDeleteShader(fs);
  return ok;
}

static GLuint make_comp_prog(const char *csSrc, const char *label) {
  GLuint cs = compile_shader_parts(GL_COMPUTE_SHADER, &csSrc, 1, label);
  if (!cs) return 0;
  GLuint p = pglCreateProgram();
  pglAttachShader(p, cs);
  GLuint ok = link_prog(p, label);
  pglDeleteShader(cs);
  return ok;
}

static struct { GLuint prog; GLint uInvViewProj, uCamPos, uCamFwd, uSunDir, uTime, uBoost; } g_pSky;
static struct {
  GLuint prog;
  GLint uModel, uViewProj, uCamPos, uSunDir, uDreadPos, uDreadRad, uDishDir;
  GLint uTime, uEmissiveScale, uShieldFlash, uDishCharge, uDynLightCount, uDynLightPos, uDynLightCol;
} g_pMesh;
static struct { GLuint prog; GLint uModel, uViewProj, uCamPos, uCoreColor, uEdgeColor, uIntensity, uIsPlume; } g_pFX;
static struct {
  GLuint prog;
  GLint uDepthTex, uMainSize, uVolSize, uInvViewProj, uCamPos, uDreadPos, uDreadRad, uSunDir;
  GLint uTime, uFrame, uExplCount, uExplPosRad, uExplData, uBeamStart, uBeamEnd;
} g_pVol;
static struct {
  GLuint prog;
  GLint uCurrTex, uDepthTex, uVolTex, uHistTex, uResolution, uEnableTAA, uBlendFactor;
  GLint uCamPos, uInvViewProj, uPrevViewProj;
} g_pTAA;
static struct { GLuint prog; GLint uHdrTex, uPrevLumTex, uDt, uReset; } g_pAdapt;
static struct { GLuint prog; GLint uHdrTex, uTexelSize, uThreshold; } g_pBright;
static struct { GLuint prog; GLint uTex, uDir; } g_pBlur;
static struct {
  GLuint prog;
  GLint uHdrTex, uBloomTex, uStreakTex, uLumTex, uResolution, uTime, uFilter, uToneMap;
  GLint uAutoExp, uExposureBias, uBoost, uDamageFlash, uHitFlash, uSunScreen, uSplitEnabled, uSplitPos;
  GLint uGameState, uMissionPhase, uAimUv, uHudVitals, uHudMeta, uLockPos, uLeadPos, uMarkerCount, uMarkers;
} g_pComp;
static struct { GLuint prog; GLint uResolution, uFontTex; } g_pUI;

static int init_all_shaders(void) {
  g_pSky.prog = make_gfx_prog(VS_QUAD_SRC, &FS_SKYBOX_SRC, 1, "SKYBOX_V3");
  if (!g_pSky.prog) return 0;
  g_pSky.uInvViewProj = pglGetUniformLocation(g_pSky.prog, "uInvViewProj");
  g_pSky.uCamPos      = pglGetUniformLocation(g_pSky.prog, "uCamPos");
  g_pSky.uCamFwd      = pglGetUniformLocation(g_pSky.prog, "uCamFwd");
  g_pSky.uSunDir      = pglGetUniformLocation(g_pSky.prog, "uSunDir");
  g_pSky.uTime        = pglGetUniformLocation(g_pSky.prog, "uTime");
  g_pSky.uBoost       = pglGetUniformLocation(g_pSky.prog, "uBoost");

  const char *meshParts[2] = { FS_MESH_PBR_A_SRC, FS_MESH_PBR_B_SRC };
  g_pMesh.prog = make_gfx_prog(VS_MESH_SRC, meshParts, 2, "MESH_PBR_V3");
  if (!g_pMesh.prog) return 0;
  g_pMesh.uModel         = pglGetUniformLocation(g_pMesh.prog, "uModel");
  g_pMesh.uViewProj      = pglGetUniformLocation(g_pMesh.prog, "uViewProj");
  g_pMesh.uCamPos        = pglGetUniformLocation(g_pMesh.prog, "uCamPos");
  g_pMesh.uSunDir        = pglGetUniformLocation(g_pMesh.prog, "uSunDir");
  g_pMesh.uDreadPos      = pglGetUniformLocation(g_pMesh.prog, "uDreadPos");
  g_pMesh.uDreadRad      = pglGetUniformLocation(g_pMesh.prog, "uDreadRad");
  g_pMesh.uDishDir       = pglGetUniformLocation(g_pMesh.prog, "uDishDir");
  g_pMesh.uTime          = pglGetUniformLocation(g_pMesh.prog, "uTime");
  g_pMesh.uEmissiveScale = pglGetUniformLocation(g_pMesh.prog, "uEmissiveScale");
  g_pMesh.uShieldFlash   = pglGetUniformLocation(g_pMesh.prog, "uShieldFlash");
  g_pMesh.uDishCharge    = pglGetUniformLocation(g_pMesh.prog, "uDishCharge");
  g_pMesh.uDynLightCount = pglGetUniformLocation(g_pMesh.prog, "uDynLightCount");
  g_pMesh.uDynLightPos   = pglGetUniformLocation(g_pMesh.prog, "uDynLightPos");
  g_pMesh.uDynLightCol   = pglGetUniformLocation(g_pMesh.prog, "uDynLightCol");

  g_pFX.prog = make_gfx_prog(VS_FX_SRC, &FS_FX_SRC, 1, "ADDITIVE_FX");
  if (!g_pFX.prog) return 0;
  g_pFX.uModel     = pglGetUniformLocation(g_pFX.prog, "uModel");
  g_pFX.uViewProj  = pglGetUniformLocation(g_pFX.prog, "uViewProj");
  g_pFX.uCamPos    = pglGetUniformLocation(g_pFX.prog, "uCamPos");
  g_pFX.uCoreColor = pglGetUniformLocation(g_pFX.prog, "uCoreColor");
  g_pFX.uEdgeColor = pglGetUniformLocation(g_pFX.prog, "uEdgeColor");
  g_pFX.uIntensity = pglGetUniformLocation(g_pFX.prog, "uIntensity");
  g_pFX.uIsPlume   = pglGetUniformLocation(g_pFX.prog, "uIsPlume");

  g_pVol.prog = make_comp_prog(CS_VOL_SRC, "VOLUMETRIC_CS_V3");
  if (!g_pVol.prog) return 0;
  g_pVol.uDepthTex    = pglGetUniformLocation(g_pVol.prog, "uDepthTex");
  g_pVol.uMainSize    = pglGetUniformLocation(g_pVol.prog, "uMainSize");
  g_pVol.uVolSize     = pglGetUniformLocation(g_pVol.prog, "uVolSize");
  g_pVol.uInvViewProj = pglGetUniformLocation(g_pVol.prog, "uInvViewProj");
  g_pVol.uCamPos      = pglGetUniformLocation(g_pVol.prog, "uCamPos");
  g_pVol.uDreadPos    = pglGetUniformLocation(g_pVol.prog, "uDreadPos");
  g_pVol.uDreadRad    = pglGetUniformLocation(g_pVol.prog, "uDreadRad");
  g_pVol.uSunDir      = pglGetUniformLocation(g_pVol.prog, "uSunDir");
  g_pVol.uTime        = pglGetUniformLocation(g_pVol.prog, "uTime");
  g_pVol.uFrame       = pglGetUniformLocation(g_pVol.prog, "uFrame");
  g_pVol.uExplCount   = pglGetUniformLocation(g_pVol.prog, "uExplCount");
  g_pVol.uExplPosRad  = pglGetUniformLocation(g_pVol.prog, "uExplPosRad");
  g_pVol.uExplData    = pglGetUniformLocation(g_pVol.prog, "uExplData");
  g_pVol.uBeamStart   = pglGetUniformLocation(g_pVol.prog, "uBeamStart");
  g_pVol.uBeamEnd     = pglGetUniformLocation(g_pVol.prog, "uBeamEnd");

  g_pTAA.prog = make_gfx_prog(VS_QUAD_SRC, &FS_TAA_SRC, 1, "TAA_MRT_V3");
  if (!g_pTAA.prog) return 0;
  g_pTAA.uCurrTex      = pglGetUniformLocation(g_pTAA.prog, "uCurrTex");
  g_pTAA.uDepthTex     = pglGetUniformLocation(g_pTAA.prog, "uDepthTex");
  g_pTAA.uVolTex       = pglGetUniformLocation(g_pTAA.prog, "uVolTex");
  g_pTAA.uHistTex      = pglGetUniformLocation(g_pTAA.prog, "uHistTex");
  g_pTAA.uResolution   = pglGetUniformLocation(g_pTAA.prog, "uResolution");
  g_pTAA.uEnableTAA    = pglGetUniformLocation(g_pTAA.prog, "uEnableTAA");
  g_pTAA.uBlendFactor  = pglGetUniformLocation(g_pTAA.prog, "uBlendFactor");
  g_pTAA.uCamPos       = pglGetUniformLocation(g_pTAA.prog, "uCamPos");
  g_pTAA.uInvViewProj  = pglGetUniformLocation(g_pTAA.prog, "uInvViewProj");
  g_pTAA.uPrevViewProj = pglGetUniformLocation(g_pTAA.prog, "uPrevViewProj");

  g_pAdapt.prog = make_comp_prog(CS_ADAPT_SRC, "ADAPT_CS_V3");
  if (!g_pAdapt.prog) return 0;
  g_pAdapt.uHdrTex     = pglGetUniformLocation(g_pAdapt.prog, "uHdrTex");
  g_pAdapt.uPrevLumTex = pglGetUniformLocation(g_pAdapt.prog, "uPrevLumTex");
  g_pAdapt.uDt         = pglGetUniformLocation(g_pAdapt.prog, "uDt");
  g_pAdapt.uReset      = pglGetUniformLocation(g_pAdapt.prog, "uReset");

  g_pBright.prog = make_gfx_prog(VS_QUAD_SRC, &FS_BRIGHT_SRC, 1, "KARIS_BRIGHT");
  if (!g_pBright.prog) return 0;
  g_pBright.uHdrTex    = pglGetUniformLocation(g_pBright.prog, "uHdrTex");
  g_pBright.uTexelSize = pglGetUniformLocation(g_pBright.prog, "uTexelSize");
  g_pBright.uThreshold = pglGetUniformLocation(g_pBright.prog, "uThreshold");

  g_pBlur.prog = make_gfx_prog(VS_QUAD_SRC, &FS_BLUR_SRC, 1, "BLUR");
  if (!g_pBlur.prog) return 0;
  g_pBlur.uTex = pglGetUniformLocation(g_pBlur.prog, "uTex");
  g_pBlur.uDir = pglGetUniformLocation(g_pBlur.prog, "uDir");

  const char *compParts[2] = { FS_COMPOSITE_A_SRC, FS_COMPOSITE_B_SRC };
  g_pComp.prog = make_gfx_prog(VS_QUAD_SRC, compParts, 2, "COMPOSITE_V3");
  if (!g_pComp.prog) return 0;
  g_pComp.uHdrTex        = pglGetUniformLocation(g_pComp.prog, "uHdrTex");
  g_pComp.uBloomTex      = pglGetUniformLocation(g_pComp.prog, "uBloomTex");
  g_pComp.uStreakTex     = pglGetUniformLocation(g_pComp.prog, "uStreakTex");
  g_pComp.uLumTex        = pglGetUniformLocation(g_pComp.prog, "uLumTex");
  g_pComp.uResolution    = pglGetUniformLocation(g_pComp.prog, "uResolution");
  g_pComp.uTime          = pglGetUniformLocation(g_pComp.prog, "uTime");
  g_pComp.uFilter        = pglGetUniformLocation(g_pComp.prog, "uFilter");
  g_pComp.uToneMap       = pglGetUniformLocation(g_pComp.prog, "uToneMap");
  g_pComp.uAutoExp       = pglGetUniformLocation(g_pComp.prog, "uAutoExp");
  g_pComp.uExposureBias  = pglGetUniformLocation(g_pComp.prog, "uExposureBias");
  g_pComp.uBoost         = pglGetUniformLocation(g_pComp.prog, "uBoost");
  g_pComp.uDamageFlash   = pglGetUniformLocation(g_pComp.prog, "uDamageFlash");
  g_pComp.uHitFlash      = pglGetUniformLocation(g_pComp.prog, "uHitFlash");
  g_pComp.uSunScreen     = pglGetUniformLocation(g_pComp.prog, "uSunScreen");
  g_pComp.uSplitEnabled  = pglGetUniformLocation(g_pComp.prog, "uSplitEnabled");
  g_pComp.uSplitPos      = pglGetUniformLocation(g_pComp.prog, "uSplitPos");
  g_pComp.uGameState     = pglGetUniformLocation(g_pComp.prog, "uGameState");
  g_pComp.uMissionPhase  = pglGetUniformLocation(g_pComp.prog, "uMissionPhase");
  g_pComp.uAimUv         = pglGetUniformLocation(g_pComp.prog, "uAimUv");
  g_pComp.uHudVitals     = pglGetUniformLocation(g_pComp.prog, "uHudVitals");
  g_pComp.uHudMeta       = pglGetUniformLocation(g_pComp.prog, "uHudMeta");
  g_pComp.uLockPos       = pglGetUniformLocation(g_pComp.prog, "uLockPos");
  g_pComp.uLeadPos       = pglGetUniformLocation(g_pComp.prog, "uLeadPos");
  g_pComp.uMarkerCount   = pglGetUniformLocation(g_pComp.prog, "uMarkerCount");
  g_pComp.uMarkers       = pglGetUniformLocation(g_pComp.prog, "uMarkers");

  g_pUI.prog = make_gfx_prog(VS_UI_SRC, &FS_UI_SRC, 1, "GPU_UI_FONT");
  if (!g_pUI.prog) return 0;
  g_pUI.uResolution = pglGetUniformLocation(g_pUI.prog, "uResolution");
  g_pUI.uFontTex    = pglGetUniformLocation(g_pUI.prog, "uFontTex");

  return 1;
}

// ============================================================================
// GPU 2D UI BATCHER & CRISP 5x7 BITMAP FONT ENGINE (PASS 8)
// ============================================================================
static const uint8_t g_font5x7[64][7] = {
  {0x00,0x00,0x00,0x00,0x00,0x00,0x00}, // ' ' (32)
  {0x04,0x04,0x04,0x04,0x04,0x00,0x04}, // '!' (33)
  {0x0A,0x0A,0x0A,0x00,0x00,0x00,0x00}, // '"' (34)
  {0x0A,0x1F,0x0A,0x0A,0x1F,0x0A,0x00}, // '#' (35)
  {0x04,0x0F,0x14,0x0E,0x05,0x1E,0x04}, // '$' (36)
  {0x18,0x19,0x02,0x04,0x08,0x13,0x03}, // '%' (37)
  {0x08,0x14,0x14,0x08,0x15,0x12,0x0D}, // '&' (38)
  {0x04,0x04,0x08,0x00,0x00,0x00,0x00}, // ''' (39)
  {0x02,0x04,0x08,0x08,0x08,0x04,0x02}, // '(' (40)
  {0x08,0x04,0x02,0x02,0x02,0x04,0x08}, // ')' (41)
  {0x00,0x0A,0x04,0x1F,0x04,0x0A,0x00}, // '*' (42)
  {0x00,0x04,0x04,0x1F,0x04,0x04,0x00}, // '+' (43)
  {0x00,0x00,0x00,0x00,0x04,0x04,0x08}, // ',' (44)
  {0x00,0x00,0x00,0x1F,0x00,0x00,0x00}, // '-' (45)
  {0x00,0x00,0x00,0x00,0x00,0x06,0x06}, // '.' (46)
  {0x01,0x01,0x02,0x04,0x08,0x10,0x10}, // '/' (47)
  {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E}, // '0' (48)
  {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E}, // '1' (49)
  {0x0E,0x11,0x01,0x06,0x08,0x10,0x1F}, // '2' (50)
  {0x1F,0x02,0x04,0x06,0x01,0x11,0x0E}, // '3' (51)
  {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02}, // '4' (52)
  {0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E}, // '5' (53)
  {0x06,0x08,0x10,0x1E,0x11,0x11,0x0E}, // '6' (54)
  {0x1F,0x01,0x02,0x04,0x08,0x08,0x08}, // '7' (55)
  {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E}, // '8' (56)
  {0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C}, // '9' (57)
  {0x00,0x06,0x06,0x00,0x06,0x06,0x00}, // ':' (58)
  {0x00,0x04,0x04,0x00,0x04,0x04,0x08}, // ';' (59)
  {0x02,0x04,0x08,0x10,0x08,0x04,0x02}, // '<' (60)
  {0x00,0x00,0x1F,0x00,0x1F,0x00,0x00}, // '=' (61)
  {0x08,0x04,0x02,0x01,0x02,0x04,0x08}, // '>' (62)
  {0x0E,0x11,0x01,0x06,0x04,0x00,0x04}, // '?' (63)
  {0x0E,0x11,0x17,0x15,0x17,0x10,0x0E}, // '@' (64)
  {0x0E,0x11,0x11,0x1F,0x11,0x11,0x11}, // 'A' (65)
  {0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E}, // 'B' (66)
  {0x0E,0x11,0x10,0x10,0x10,0x11,0x0E}, // 'C' (67)
  {0x1E,0x11,0x11,0x11,0x11,0x11,0x1E}, // 'D' (68)
  {0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F}, // 'E' (69)
  {0x1F,0x10,0x10,0x1E,0x10,0x10,0x10}, // 'F' (70)
  {0x0E,0x11,0x10,0x17,0x11,0x11,0x0F}, // 'G' (71)
  {0x11,0x11,0x11,0x1F,0x11,0x11,0x11}, // 'H' (72)
  {0x0E,0x04,0x04,0x04,0x04,0x04,0x0E}, // 'I' (73)
  {0x07,0x02,0x02,0x02,0x02,0x12,0x0C}, // 'J' (74)
  {0x11,0x12,0x14,0x18,0x14,0x12,0x11}, // 'K' (75)
  {0x10,0x10,0x10,0x10,0x10,0x10,0x1F}, // 'L' (76)
  {0x11,0x1B,0x15,0x15,0x11,0x11,0x11}, // 'M' (77)
  {0x11,0x19,0x15,0x13,0x11,0x11,0x11}, // 'N' (78)
  {0x0E,0x11,0x11,0x11,0x11,0x11,0x0E}, // 'O' (79)
  {0x1E,0x11,0x11,0x1E,0x10,0x10,0x10}, // 'P' (80)
  {0x0E,0x11,0x11,0x11,0x15,0x12,0x0D}, // 'Q' (81)
  {0x1E,0x11,0x11,0x1E,0x14,0x12,0x11}, // 'R' (82)
  {0x0E,0x11,0x10,0x0E,0x01,0x11,0x0E}, // 'S' (83)
  {0x1F,0x04,0x04,0x04,0x04,0x04,0x04}, // 'T' (84)
  {0x11,0x11,0x11,0x11,0x11,0x11,0x0E}, // 'U' (85)
  {0x11,0x11,0x11,0x11,0x11,0x0A,0x04}, // 'V' (86)
  {0x11,0x11,0x11,0x15,0x15,0x1B,0x11}, // 'W' (87)
  {0x11,0x11,0x0A,0x04,0x0A,0x11,0x11}, // 'X' (88)
  {0x11,0x11,0x0A,0x04,0x04,0x04,0x04}, // 'Y' (89)
  {0x1F,0x01,0x02,0x04,0x08,0x10,0x1F}, // 'Z' (90)
  {0x0E,0x08,0x08,0x08,0x08,0x08,0x0E}, // '[' (91)
  {0x10,0x10,0x08,0x04,0x02,0x01,0x01}, // '\' (92)
  {0x0E,0x02,0x02,0x02,0x02,0x02,0x0E}, // ']' (93)
  {0x04,0x0A,0x11,0x00,0x00,0x00,0x00}, // '^' (94)
  {0x00,0x00,0x00,0x00,0x00,0x00,0x1F}, // '_' (95)
};


#define UI_MAX_QUADS 4096
#define UI_MAX_VERTS (UI_MAX_QUADS * 6)

typedef struct {
  float x, y;
  float u, v;
  float r, g, b, a;
  float mode;
} UIVertex;

static UIVertex g_uiVerts[UI_MAX_VERTS];
static int      g_uiVertCount = 0;
static GLuint   g_uiVAO = 0, g_uiVBO = 0, g_fontTex = 0;

static void ui_init(void) {
  // Build 384x8 GL_R8 font atlas (64 glyphs x 6px cell stride, 5x7 pixels each + 1px gap)
  uint8_t atlas[8 * 384];
  memset(atlas, 0, sizeof(atlas));
  for (int ch = 0; ch < 64; ch++) {
    for (int row = 0; row < 7; row++) {
      uint8_t bits = g_font5x7[ch][row];
      for (int col = 0; col < 5; col++) {
        if (bits & (1u << (4 - col))) {
          atlas[row * 384 + ch * 6 + col] = 255;
        }
      }
    }
  }
  glGenTextures(1, &g_fontTex);
  glBindTexture(GL_TEXTURE_2D, g_fontTex);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, 384, 8, 0, GL_RED, GL_UNSIGNED_BYTE, atlas);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

  pglGenVertexArrays(1, &g_uiVAO);
  pglBindVertexArray(g_uiVAO);
  pglGenBuffers(1, &g_uiVBO);
  pglBindBuffer(GL_ARRAY_BUFFER, g_uiVBO);
  pglBufferData(GL_ARRAY_BUFFER, (GLsizeiptr_t)(UI_MAX_VERTS * (int)sizeof(UIVertex)), NULL, GL_DYNAMIC_DRAW);
  pglEnableVertexAttribArray(0);
  pglVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(UIVertex), (const void *)0);
  pglEnableVertexAttribArray(1);
  pglVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(UIVertex), (const void *)(2 * sizeof(float)));
  pglEnableVertexAttribArray(2);
  pglVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, sizeof(UIVertex), (const void *)(4 * sizeof(float)));
  pglEnableVertexAttribArray(3);
  pglVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, sizeof(UIVertex), (const void *)(8 * sizeof(float)));
  pglBindVertexArray(0);
}

static void ui_shutdown(void) {
  if (g_fontTex) { glDeleteTextures(1, &g_fontTex); g_fontTex = 0; }
  if (g_uiVBO)   { pglDeleteBuffers(1, &g_uiVBO); g_uiVBO = 0; }
  if (g_uiVAO)   { pglDeleteVertexArrays(1, &g_uiVAO); g_uiVAO = 0; }
}

static void ui_begin(void) { g_uiVertCount = 0; }

static void ui_quad(float x, float y, float w, float h, float u0, float v0, float u1, float v1,
                    float r, float g, float b, float a, float mode) {
  if (g_uiVertCount + 6 > UI_MAX_VERTS || a <= 0.002f) return;
  UIVertex *v = &g_uiVerts[g_uiVertCount];
  g_uiVertCount += 6;
  UIVertex tl = { x,     y,     u0, v0, r, g, b, a, mode };
  UIVertex tr = { x + w, y,     u1, v0, r, g, b, a, mode };
  UIVertex br = { x + w, y + h, u1, v1, r, g, b, a, mode };
  UIVertex bl = { x,     y + h, u0, v1, r, g, b, a, mode };
  v[0] = tl; v[1] = bl; v[2] = br;
  v[3] = tl; v[4] = br; v[5] = tr;
}

static void ui_rect(float x, float y, float w, float h, float r, float g, float b, float a) {
  ui_quad(x, y, w, h, 0.0f, 0.0f, 1.0f, 1.0f, r, g, b, a, 0.0f);
}

static void ui_border(float x, float y, float w, float h, float t, float r, float g, float b, float a) {
  ui_rect(x, y, w, t, r, g, b, a);
  ui_rect(x, y + h - t, w, t, r, g, b, a);
  ui_rect(x, y + t, t, h - 2.0f * t, r, g, b, a);
  ui_rect(x + w - t, y + t, t, h - 2.0f * t, r, g, b, a);
}

static void ui_glow(float cx, float cy, float rx, float ry, float r, float g, float b, float a) {
  ui_quad(cx - rx, cy - ry, rx * 2.0f, ry * 2.0f, 0.0f, 0.0f, 1.0f, 1.0f, r, g, b, a, 2.0f);
}

static void ui_ring(float cx, float cy, float rad, float r, float g, float b, float a) {
  ui_quad(cx - rad, cy - rad, rad * 2.0f, rad * 2.0f, 0.0f, 0.0f, 1.0f, 1.0f, r, g, b, a, 3.0f);
}

static float ui_text_width(const char *txt, float pxScale, float tracking) {
  int len = (int)strlen(txt);
  if (len <= 0) return 0.0f;
  return (float)len * (6.0f * pxScale + tracking) - (pxScale + tracking);
}

static void ui_text(float x, float y, float pxScale, float tracking, const char *txt,
                    float r, float g, float b, float a) {
  float cx = x;
  float gw = 5.0f * pxScale;
  float gh = 7.0f * pxScale;
  for (const char *p = txt; *p; p++) {
    int c = (unsigned char)*p;
    if (c >= 'a' && c <= 'z') c -= 32;
    if (c >= 32 && c <= 95) {
      int idx = c - 32;
      float u0 = ((float)(idx * 6)) / 384.0f;
      float u1 = ((float)(idx * 6 + 5)) / 384.0f;
      float v0 = 0.0f;
      float v1 = 7.0f / 8.0f;
      if (idx > 0) ui_quad(cx, y, gw, gh, u0, v0, u1, v1, r, g, b, a, 1.0f);
    }
    cx += 6.0f * pxScale + tracking;
  }
}

static void ui_text_center(float cx, float y, float pxScale, float tracking, const char *txt,
                           float r, float g, float b, float a) {
  float w = ui_text_width(txt, pxScale, tracking);
  ui_text(cx - w * 0.5f, y, pxScale, tracking, txt, r, g, b, a);
}

static void ui_text_shadow(float x, float y, float pxScale, float tracking, const char *txt,
                           float r, float g, float b, float a) {
  ui_text(x + pxScale * 0.65f, y + pxScale * 0.65f, pxScale, tracking, txt, 0.0f, 0.0f, 0.0f, a * 0.72f);
  ui_text(x, y, pxScale, tracking, txt, r, g, b, a);
}

static void ui_text_center_shadow(float cx, float y, float pxScale, float tracking, const char *txt,
                                  float r, float g, float b, float a) {
  float w = ui_text_width(txt, pxScale, tracking);
  ui_text_shadow(cx - w * 0.5f, y, pxScale, tracking, txt, r, g, b, a);
}

static void ui_flush(void) {
  if (g_uiVertCount <= 0) return;
  pglBindFramebuffer(GL_FRAMEBUFFER, 0);
  glViewport(0, 0, g_winW, g_winH);
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  pglUseProgram(g_pUI.prog);
  pglUniform2f(g_pUI.uResolution, (float)g_winW, (float)g_winH);
  pglActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, g_fontTex);
  pglUniform1i(g_pUI.uFontTex, 0);
  pglBindVertexArray(g_uiVAO);
  pglBindBuffer(GL_ARRAY_BUFFER, g_uiVBO);
  pglBufferSubData(GL_ARRAY_BUFFER, 0, (GLsizeiptr_t)(g_uiVertCount * (int)sizeof(UIVertex)), g_uiVerts);
  glDrawArrays(GL_TRIANGLES, 0, g_uiVertCount);
  glDisable(GL_BLEND);
}

// ============================================================================
// GAME ENTITIES, MENU SYSTEM & 3-PHASE ORBITAL ASSAULT SIMULATION
// ============================================================================
#define MAX_ENEMIES    24
#define MAX_ALLIES     3
#define MAX_LASERS     180
#define MAX_EXPLOSIONS 16
#define MAX_SPARKS     160
#define MAX_RELAYS     4

enum {
  GS_SPLASH   = 0,
  GS_MENU     = 1,
  GS_PLAYING  = 2,
  GS_PAUSE    = 3,
  GS_VICTORY  = 4,
  GS_GAMEOVER = 5
};

typedef struct {
  Vec3  pos, fwd, up, right, vel;
  float speed, throttle, boost, boostActive;
  float hull, maxHull, shield, maxShield, shieldDelay, shieldFlash, damageFlash, hitFlash;
  float laserCap, fireCooldown, torpCooldown;
  int   torpedoes, barrelIdx, sFoilTarget;
  float sFoilAnim, bankRoll, barrelSpin, shake;
  float lockAmt;
  int   lockType, lockIdx;
} PlayerShip;

typedef struct {
  int   alive, type;
  Vec3  pos, fwd, up, right, vel;
  float hp, maxHp, speed, fireTimer, evadeTimer, rollAngle, seed;
} EnemyShip;

typedef struct {
  Vec3  pos, fwd, up, right;
  float fireTimer, phase;
} AllyShip;

typedef struct {
  int   alive;
  Vec3  pos, norm;
  float hp, maxHp, fireTimer;
} ShieldRelay;

typedef struct {
  int   active, isPlayer, isTorp;
  Vec3  pos, vel, colCore, colEdge;
  float life, maxLife, dmg;
  int   targetType, targetIdx;
} Projectile;

typedef struct {
  int   active, type;
  Vec3  pos;
  float age, dur, maxRad, seed;
} Explosion;

typedef struct {
  int   active;
  Vec3  pos, vel, col;
  float age, dur;
} Spark;

typedef struct {
  int   state, sector, phase;
  int   score, kills, phaseKills, phaseTarget;
  float coreHp, coreMaxHp, dishCharge, phaseTimer, finaleTimer;
  float splashTimer, menuFade;
  int   menuSel, prevHover;
  Vec3  corePos;
  Vec3  freighterPos, freighterFwd, freighterUp, freighterRight;
  float freighterFire;
} GameWorld;

static PlayerShip  g_pl;
static EnemyShip   g_enemies[MAX_ENEMIES];
static AllyShip    g_allies[MAX_ALLIES];
static ShieldRelay g_relays[MAX_RELAYS];
static Projectile  g_lasers[MAX_LASERS];
static Explosion   g_expl[MAX_EXPLOSIONS];
static Spark       g_sparks[MAX_SPARKS];
static GameWorld   g_gm;

static void ortho_ship(Vec3 *fwd, Vec3 *up, Vec3 *right) {
  *fwd = v3_norm(*fwd);
  *right = v3_norm(v3_cross(*fwd, *up));
  *up = v3_norm(v3_cross(*right, *fwd));
}

static void spawn_sparks(Vec3 pos, int count, float speed, Vec3 col) {
  for (int k = 0; k < count; k++) {
    for (int i = 0; i < MAX_SPARKS; i++) {
      if (!g_sparks[i].active) {
        Spark *sp = &g_sparks[i];
        sp->active = 1; sp->pos = pos;
        Vec3 dir = v3_norm(v3(frand_range(-1.0f, 1.0f), frand_range(-1.0f, 1.0f), frand_range(-1.0f, 1.0f)));
        sp->vel = v3_mul(dir, speed * frand_range(0.35f, 1.25f));
        sp->col = col; sp->age = 0.0f; sp->dur = frand_range(0.28f, 0.78f);
        break;
      }
    }
  }
}

static void spawn_explosion(Vec3 pos, float maxRad, float dur, int type) {
  int slot = 0; float maxAge = -1.0f;
  for (int i = 0; i < MAX_EXPLOSIONS; i++) {
    if (!g_expl[i].active) { slot = i; break; }
    float a = g_expl[i].age / g_expl[i].dur;
    if (a > maxAge) { maxAge = a; slot = i; }
  }
  Explosion *e = &g_expl[slot];
  e->active = 1; e->pos = pos; e->age = 0.0f; e->dur = dur;
  e->maxRad = maxRad; e->type = type; e->seed = frand01() * 100.0f;

  Vec3 spCol = (type == 1) ? v3(0.35f, 0.85f, 1.0f) : v3(1.0f, 0.62f, 0.16f);
  spawn_sparks(pos, (type == 2) ? 26 : ((maxRad > 6.0f) ? 14 : 6), (type == 2) ? 75.0f : 42.0f, spCol);

  if (g_gm.state == GS_PLAYING || g_gm.state == GS_VICTORY || g_gm.state == GS_GAMEOVER) {
    float d = v3_len(v3_sub(pos, g_pl.pos));
    float vol = clampf(1.0f - d / 260.0f, 0.12f, 1.0f);
    float pan = clampf(v3_dot(v3_norm(v3_sub(pos, g_pl.pos)), g_pl.right), -0.8f, 0.8f);
    audio_play_sfx(type == 2 ? SFX_BIG_BOOM : SFX_EXPLOSION, vol * (type == 2 ? 0.95f : 0.65f), pan, frand_range(0.85f, 1.15f));
    if (d < 95.0f) g_pl.shake = fmaxf(g_pl.shake, (1.0f - d / 95.0f) * (type == 2 ? 2.2f : 0.85f));
  }
}

static void spawn_laser(Vec3 pos, Vec3 dir, float speed, int isPlayer, int isTorp, float dmg, int tType, int tIdx) {
  for (int i = 0; i < MAX_LASERS; i++) {
    if (!g_lasers[i].active) {
      Projectile *p = &g_lasers[i];
      p->active = 1; p->isPlayer = isPlayer; p->isTorp = isTorp;
      p->pos = pos; p->vel = v3_mul(v3_norm(dir), speed);
      p->life = 0.0f; p->maxLife = isTorp ? 4.8f : 1.75f;
      p->dmg = dmg; p->targetType = tType; p->targetIdx = tIdx;
      if (isTorp) { p->colCore = v3(1.0f, 0.94f, 1.0f); p->colEdge = v3(0.18f, 0.82f, 1.0f); }
      else if (isPlayer) { p->colCore = v3(1.0f, 0.85f, 0.78f); p->colEdge = v3(1.0f, 0.06f, 0.04f); }
      else { p->colCore = v3(0.85f, 1.0f, 0.85f); p->colEdge = v3(0.06f, 1.0f, 0.16f); }
      return;
    }
  }
}

static void spawn_enemy(int slot, int type) {
  EnemyShip *e = &g_enemies[slot];
  memset(e, 0, sizeof(*e));
  e->alive = 1; e->type = type;
  e->maxHp = (type == 1) ? (55.0f + g_gm.sector * 12.0f) : (26.0f + g_gm.sector * 6.0f);
  e->hp = e->maxHp;
  e->speed = (type == 1) ? 40.0f : (56.0f + frand_range(0.0f, 14.0f));
  e->seed = frand01() * 100.0f;
  e->fireTimer = frand_range(0.6f, 2.2f);
  float ang = frand_range(0.0f, TAU_F), rad = frand_range(75.0f, 155.0f);
  e->pos = v3(cosf(ang) * rad, frand_range(-38.0f, 52.0f), -135.0f + sinf(ang) * 75.0f);
  e->fwd = v3_norm(v3_sub(g_pl.pos, e->pos)); e->up = v3(0.0f, 1.0f, 0.0f);
  ortho_ship(&e->fwd, &e->up, &e->right);
  e->vel = v3_mul(e->fwd, e->speed);
}

static void init_sector(int sector, int startState) {
  memset(g_enemies, 0, sizeof(g_enemies));
  memset(g_lasers, 0, sizeof(g_lasers));
  memset(g_expl, 0, sizeof(g_expl));
  memset(g_sparks, 0, sizeof(g_sparks));

  g_gm.state = startState; g_gm.sector = sector; g_gm.phase = 1;
  g_gm.phaseKills = 0; g_gm.phaseTarget = 10 + (sector - 1) * 4;
  g_gm.coreMaxHp = 260.0f + (sector - 1) * 70.0f; g_gm.coreHp = g_gm.coreMaxHp;
  g_gm.dishCharge = 0.0f; g_gm.phaseTimer = 0.0f; g_gm.finaleTimer = 0.0f;
  g_gm.menuSel = 0; g_gm.prevHover = -1;

  Vec3 dPos = get_dread_pos(), dDir = get_dish_dir();
  g_gm.corePos = v3_add(dPos, v3_mul(dDir, eval_dread_radius(dDir) + 4.0f));

  const Vec3 relayDirs[MAX_RELAYS] = {
    {  0.54f,  0.18f, 0.82f }, { -0.58f, -0.14f, 0.80f },
    {  0.34f, -0.34f, 0.88f }, {  0.12f,  0.52f, 0.84f }
  };
  for (int i = 0; i < MAX_RELAYS; i++) {
    Vec3 n = v3_norm(relayDirs[i]);
    g_relays[i].alive = 1; g_relays[i].norm = n;
    g_relays[i].pos = v3_add(dPos, v3_mul(n, eval_dread_radius(n) + 2.2f));
    g_relays[i].maxHp = 110.0f + (sector - 1) * 35.0f;
    g_relays[i].hp = g_relays[i].maxHp;
    g_relays[i].fireTimer = frand_range(1.2f, 2.8f);
  }

  memset(&g_pl, 0, sizeof(g_pl));
  g_pl.pos = v3(0.0f, 2.0f, 20.0f);
  g_pl.fwd = v3(0.0f, 0.04f, -1.0f); g_pl.up = v3(0.0f, 1.0f, 0.0f);
  ortho_ship(&g_pl.fwd, &g_pl.up, &g_pl.right);
  g_pl.throttle = 0.52f; g_pl.speed = 46.0f; g_pl.boost = 1.0f;
  g_pl.maxHull = 100.0f; g_pl.hull = 100.0f;
  g_pl.maxShield = 100.0f; g_pl.shield = 100.0f;
  g_pl.laserCap = 1.0f; g_pl.torpedoes = 6;
  g_pl.sFoilTarget = 1; g_pl.sFoilAnim = 1.0f;

  for (int i = 0; i < MAX_ALLIES; i++) {
    g_allies[i].phase = (float)i * 2.094f;
    g_allies[i].pos = v3(((i == 0) ? -22.0f : (i == 1 ? 24.0f : -14.0f)), 4.0f + i * 5.0f, -15.0f - i * 18.0f);
    g_allies[i].fwd = v3(0.0f, 0.0f, -1.0f); g_allies[i].up = v3(0.0f, 1.0f, 0.0f);
    ortho_ship(&g_allies[i].fwd, &g_allies[i].up, &g_allies[i].right);
    g_allies[i].fireTimer = 0.4f + i * 0.35f;
  }

  for (int i = 0; i < 12; i++) spawn_enemy(i, (i % 5 == 4) ? 1 : 0);
  g_resetHistory = 1; g_resetAdapt = 1;
}

static void damage_player(float amt) {
  if (g_gm.state != GS_PLAYING) return;
  g_pl.shieldDelay = 3.6f;
  g_pl.shake = fmaxf(g_pl.shake, 0.65f);
  if (g_pl.shield > 0.0f) {
    float absb = fminf(g_pl.shield, amt);
    g_pl.shield -= absb; amt -= absb;
    g_pl.shieldFlash = 1.0f;
    audio_play_sfx(SFX_SHIELD_HIT, 0.55f, 0.0f, frand_range(0.9f, 1.15f));
  }
  if (amt > 0.0f) {
    g_pl.hull -= amt;
    g_pl.damageFlash = 1.0f;
    if (g_pl.hull <= 0.0f) {
      g_pl.hull = 0.0f; g_gm.state = GS_GAMEOVER;
      g_gm.menuSel = 0; g_gm.prevHover = -1;
      spawn_explosion(g_pl.pos, 18.0f, 1.6f, 2);
    }
  }
}

// Forward declarations for menu actions
static void toggle_fullscreen(void);

static int get_menu_item_count(void) {
  if (g_gm.state == GS_MENU)     return 6;
  if (g_gm.state == GS_PAUSE)    return 7;
  if (g_gm.state == GS_VICTORY)  return 3;
  if (g_gm.state == GS_GAMEOVER) return 3;
  return 0;
}

static void get_menu_item_rect(int idx, float *ox, float *oy, float *ow, float *oh) {
  float w = (float)g_winW, h = (float)g_winH;
  float sc = clampf(h / 720.0f, 0.85f, 1.75f);
  if (g_gm.state == GS_MENU) {
    float bw = 370.0f * sc, bh = 44.0f * sc, gap = 10.0f * sc;
    *ox = w * 0.075f;
    *oy = h * 0.37f + (float)idx * (bh + gap);
    *ow = bw; *oh = bh;
  } else if (g_gm.state == GS_PAUSE) {
    float bw = 360.0f * sc, bh = 42.0f * sc, gap = 9.0f * sc;
    *ox = (w - bw) * 0.5f;
    *oy = h * 0.28f + (float)idx * (bh + gap);
    *ow = bw; *oh = bh;
  } else {
    float bw = 320.0f * sc, bh = 44.0f * sc, gap = 11.0f * sc;
    *ox = (w - bw) * 0.5f;
    *oy = h * 0.52f + (float)idx * (bh + gap);
    *ow = bw; *oh = bh;
  }
}

static void execute_menu_action(int idx) {
  audio_play_sfx(SFX_UI_CLICK, 0.50f, 0.0f, 1.0f);
  if (g_gm.state == GS_MENU) {
    if      (idx == 0) { g_gm.score = 0; g_gm.kills = 0; init_sector(1, GS_PLAYING); }
    else if (idx == 1) { toggle_fullscreen(); }
    else if (idx == 2) { g_gfx.filter = (g_gfx.filter + 1) & 3; g_resetHistory = 1; }
    else if (idx == 3) { g_gfx.toneMap = (g_gfx.toneMap + 1) & 3; }
    else if (idx == 4) { g_audioMuted = !g_audioMuted; }
    else if (idx == 5) { g_running = 0; PostQuitMessage(0); }
  } else if (g_gm.state == GS_PAUSE) {
    if      (idx == 0) { g_gm.state = GS_PLAYING; g_resetHistory = 1; }
    else if (idx == 1) { init_sector(g_gm.sector, GS_PLAYING); }
    else if (idx == 2) { toggle_fullscreen(); }
    else if (idx == 3) { g_gfx.filter = (g_gfx.filter + 1) & 3; g_resetHistory = 1; }
    else if (idx == 4) { g_gfx.toneMap = (g_gfx.toneMap + 1) & 3; }
    else if (idx == 5) { g_gm.menuFade = 0.0f; init_sector(1, GS_MENU); }
    else if (idx == 6) { g_running = 0; PostQuitMessage(0); }
  } else if (g_gm.state == GS_VICTORY) {
    if      (idx == 0) { init_sector(g_gm.sector + 1, GS_PLAYING); }
    else if (idx == 1) { g_gm.menuFade = 0.0f; init_sector(1, GS_MENU); }
    else if (idx == 2) { g_running = 0; PostQuitMessage(0); }
  } else if (g_gm.state == GS_GAMEOVER) {
    if      (idx == 0) { g_gm.score = 0; g_gm.kills = 0; init_sector(1, GS_PLAYING); }
    else if (idx == 1) { g_gm.menuFade = 0.0f; init_sector(1, GS_MENU); }
    else if (idx == 2) { g_running = 0; PostQuitMessage(0); }
  }
}

static void update_menu_hover(void) {
  int cnt = get_menu_item_count();
  if (cnt <= 0) return;
  for (int i = 0; i < cnt; i++) {
    float x, y, w, h;
    get_menu_item_rect(i, &x, &y, &w, &h);
    if (g_mousePxX >= x && g_mousePxX <= x + w && g_mousePxY >= y && g_mousePxY <= y + h) {
      g_gm.menuSel = i;
      if (g_gm.prevHover != i) {
        g_gm.prevHover = i;
        audio_play_sfx(SFX_UI_HOVER, 0.35f, 0.0f, 1.0f);
      }
      return;
    }
  }
}

static void handle_menu_click(void) {
  if (g_gm.state == GS_SPLASH) {
    g_gm.state = GS_MENU; g_gm.menuFade = 0.0f; g_gm.menuSel = 0;
    audio_play_sfx(SFX_UI_CLICK, 0.42f, 0.0f, 1.0f);
    return;
  }
  int cnt = get_menu_item_count();
  for (int i = 0; i < cnt; i++) {
    float x, y, w, h;
    get_menu_item_rect(i, &x, &y, &w, &h);
    if (g_mousePxX >= x && g_mousePxX <= x + w && g_mousePxY >= y && g_mousePxY <= y + h) {
      execute_menu_action(i);
      return;
    }
  }
}

static void update_game(float dt, float elapsed) {
  // Smooth audio engine volume envelope (silent in splash, soft hum in menu/pause, full roar in combat)
  float targetEngVol = (g_gm.state == GS_PLAYING) ? 1.0f : ((g_gm.state == GS_MENU) ? 0.22f : 0.0f);
  g_audioEngineVol = lerpf(g_audioEngineVol, targetEngVol, 1.0f - expf(-dt * 4.0f));

  if (g_gm.state == GS_SPLASH) {
    g_gm.splashTimer += dt;
    if (g_gm.splashTimer >= 4.0f) {
      g_gm.state = GS_MENU;
      g_gm.menuFade = 0.0f;
      g_gm.menuSel = 0;
      g_resetHistory = 1;
    }
    return;
  }

  if (g_gm.state == GS_MENU) {
    g_gm.menuFade = fminf(1.0f, g_gm.menuFade + dt * 1.8f);
  }
  if (g_gm.state == GS_PAUSE) return;

  float fAng = elapsed * 0.14f + 0.4f;
  Vec3 nextF = v3(95.0f + cosf(fAng) * 55.0f, 44.0f + sinf(fAng * 1.4f) * 18.0f, -120.0f + sinf(fAng) * 65.0f);
  g_gm.freighterFwd = v3_norm(v3_sub(nextF, g_gm.freighterPos));
  if (v3_len(g_gm.freighterPos) < 1.0f) g_gm.freighterFwd = v3(-0.6f, -0.1f, -0.8f);
  g_gm.freighterPos = nextF; g_gm.freighterUp = v3(0.18f, 0.96f, 0.12f);
  ortho_ship(&g_gm.freighterFwd, &g_gm.freighterUp, &g_gm.freighterRight);

  g_pl.sFoilAnim    = lerpf(g_pl.sFoilAnim, g_pl.sFoilTarget ? 1.0f : 0.0f, 1.0f - expf(-dt * 6.0f));
  g_pl.shieldFlash  = fmaxf(0.0f, g_pl.shieldFlash - dt * 2.8f);
  g_pl.damageFlash  = fmaxf(0.0f, g_pl.damageFlash - dt * 2.2f);
  g_pl.hitFlash     = fmaxf(0.0f, g_pl.hitFlash    - dt * 5.5f);
  g_pl.shake        = fmaxf(0.0f, g_pl.shake       - dt * 3.5f);
  g_pl.fireCooldown = fmaxf(0.0f, g_pl.fireCooldown - dt);
  g_pl.torpCooldown = fmaxf(0.0f, g_pl.torpCooldown - dt);

  if (g_pl.shieldDelay > 0.0f) g_pl.shieldDelay -= dt;
  else g_pl.shield = fminf(g_pl.maxShield, g_pl.shield + 14.0f * dt);
  g_pl.laserCap = fminf(1.0f, g_pl.laserCap + 0.34f * dt);

  if (g_gm.state == GS_PLAYING) {
    if (g_keys['W']) g_pl.throttle = clampf(g_pl.throttle + 0.65f * dt, 0.15f, 1.0f);
    if (g_keys['S']) g_pl.throttle = clampf(g_pl.throttle - 0.65f * dt, 0.15f, 1.0f);
    int wantBoost = g_keys[VK_SHIFT] && g_pl.boost > 0.06f;
    if (wantBoost) {
      g_pl.boostActive = lerpf(g_pl.boostActive, 1.0f, 1.0f - expf(-dt * 8.0f));
      g_pl.boost = fmaxf(0.0f, g_pl.boost - 0.36f * dt);
    } else {
      g_pl.boostActive = lerpf(g_pl.boostActive, 0.0f, 1.0f - expf(-dt * 5.0f));
      g_pl.boost = fminf(1.0f, g_pl.boost + 0.20f * dt);
    }
    float targetSpd = (28.0f + g_pl.throttle * 42.0f) * (g_pl.sFoilTarget ? 1.0f : 1.15f) + g_pl.boostActive * 48.0f;
    g_pl.speed = lerpf(g_pl.speed, targetSpd, 1.0f - expf(-dt * 4.5f));

    float mx = (g_mouseUvX - 0.5f) * 2.0f, my = (g_mouseUvY - 0.5f) * 2.0f;
    float yawRate   = -mx * fabsf(mx) * 1.95f - mx * 0.55f;
    float pitchRate =  my * fabsf(my) * 1.65f + my * 0.45f;
    float rollInput = (g_keys['A'] ? -2.8f : 0.0f) + (g_keys['D'] ? 2.8f : 0.0f);

    Vec3 dFwd = v3_add(v3_mul(g_pl.right, -yawRate * dt), v3_mul(g_pl.up, pitchRate * dt));
    g_pl.fwd = v3_norm(v3_add(g_pl.fwd, dFwd));
    float desiredRoll = clampf(-mx * 0.72f, -0.85f, 0.85f);
    g_pl.bankRoll = lerpf(g_pl.bankRoll, desiredRoll, 1.0f - expf(-dt * 5.5f));
    if (fabsf(rollInput) > 0.1f) {
      g_pl.up = v3_norm(v3_add(g_pl.up, v3_mul(g_pl.right, rollInput * dt)));
    } else {
      Vec3 worldUp = v3(0.0f, 1.0f, 0.0f);
      Vec3 projUp = v3_sub(worldUp, v3_mul(g_pl.fwd, v3_dot(worldUp, g_pl.fwd)));
      if (v3_len(projUp) > 0.15f) {
        projUp = v3_norm(projUp);
        Vec3 bankRight = v3_norm(v3_cross(g_pl.fwd, projUp));
        Vec3 targetUp = v3_add(v3_mul(projUp, cosf(g_pl.bankRoll)), v3_mul(bankRight, sinf(g_pl.bankRoll)));
        g_pl.up = v3_norm(v3_lerp(g_pl.up, targetUp, 1.0f - expf(-dt * 3.8f)));
      }
    }
    ortho_ship(&g_pl.fwd, &g_pl.up, &g_pl.right);
    g_pl.vel = v3_mul(g_pl.fwd, g_pl.speed);
    g_pl.pos = v3_add(g_pl.pos, v3_mul(g_pl.vel, dt));

    Vec3 dPos = get_dread_pos(), fromD = v3_sub(g_pl.pos, dPos);
    if (v3_len(fromD) < DREAD_RADIUS + 11.0f) {
      Vec3 n = v3_norm(fromD);
      g_pl.pos = v3_add(dPos, v3_mul(n, DREAD_RADIUS + 11.0f));
      g_pl.fwd = v3_norm(v3_add(g_pl.fwd, v3_mul(n, 0.45f)));
      ortho_ship(&g_pl.fwd, &g_pl.up, &g_pl.right);
      damage_player(6.0f * dt * 10.0f);
    }
    if (v3_len(g_pl.pos) > 390.0f) {
      g_pl.fwd = v3_norm(v3_lerp(g_pl.fwd, v3_norm(v3_mul(g_pl.pos, -1.0f)), dt * 1.6f));
      ortho_ship(&g_pl.fwd, &g_pl.up, &g_pl.right);
    }

    if ((g_mouseL || g_keys[VK_SPACE]) && g_pl.fireCooldown <= 0.0f && g_pl.laserCap > 0.06f && g_pl.sFoilTarget) {
      g_pl.fireCooldown = 0.095f;
      g_pl.laserCap = fmaxf(0.0f, g_pl.laserCap - 0.032f);
      float angs[4] = { 0.26f, -0.26f, PI_F - 0.26f, PI_F + 0.26f };
      float a = angs[g_pl.barrelIdx & 3]; g_pl.barrelIdx++;
      Vec3 localOff = v3(cosf(a) * 3.15f, sinf(a) * 3.15f, -1.25f);
      Vec3 muzzle = v3_add(g_pl.pos, v3_add(v3_mul(g_pl.right, localOff.x),
                    v3_add(v3_mul(g_pl.up, localOff.y), v3_mul(g_pl.fwd, -localOff.z))));
      Vec3 aimPoint = v3_add(g_pl.pos, v3_mul(g_pl.fwd, 190.0f));
      if (g_pl.lockType > 0 && g_pl.lockAmt > 0.4f) {
        if (g_pl.lockType == 1 && g_enemies[g_pl.lockIdx].alive) aimPoint = g_enemies[g_pl.lockIdx].pos;
        else if (g_pl.lockType == 2 && g_relays[g_pl.lockIdx].alive) aimPoint = g_relays[g_pl.lockIdx].pos;
        else if (g_pl.lockType == 3) aimPoint = g_gm.corePos;
      }
      Vec3 shotDir = v3_norm(v3_sub(aimPoint, muzzle));
      if (v3_dot(shotDir, g_pl.fwd) < 0.85f) shotDir = g_pl.fwd;
      spawn_laser(muzzle, shotDir, 310.0f, 1, 0, 14.0f, 0, 0);
      audio_play_sfx(SFX_LASER_RED, 0.36f, (cosf(a) > 0.0f ? 0.22f : -0.22f), frand_range(0.94f, 1.07f));
    }

    if ((g_mouseR || g_keys['E']) && g_pl.torpCooldown <= 0.0f && g_pl.torpedoes > 0) {
      g_pl.torpCooldown = 0.65f; g_pl.torpedoes--;
      spawn_laser(v3_add(g_pl.pos, v3_mul(g_pl.up, -0.55f)), g_pl.fwd, 155.0f, 1, 1, 85.0f, g_pl.lockType, g_pl.lockIdx);
      audio_play_sfx(SFX_TORPEDO, 0.62f, 0.0f, 1.0f);
    }
  } else {
    g_pl.speed = 42.0f;
    g_pl.boostActive = 0.22f + 0.14f * sinf(elapsed * 1.2f);
    float a = elapsed * 0.24f;
    Vec3 nextP = v3(sinf(a) * 68.0f, 10.0f + sinf(a * 1.7f) * 14.0f, -65.0f + cosf(a) * 72.0f);
    if (g_gm.state != GS_GAMEOVER) {
      g_pl.fwd = v3_norm(v3_sub(nextP, g_pl.pos));
      g_pl.up  = v3_norm(v3(cosf(a) * 0.45f, 1.0f, 0.0f));
      ortho_ship(&g_pl.fwd, &g_pl.up, &g_pl.right);
      g_pl.pos = nextP;
    }
  }

  g_audioThrottle = g_pl.throttle; g_audioBoost = g_pl.boostActive;

  int bestType = 0, bestIdx = 0; float bestScore = 0.88f;
  for (int i = 0; i < MAX_ENEMIES; i++) {
    if (!g_enemies[i].alive) continue;
    Vec3 toE = v3_sub(g_enemies[i].pos, g_pl.pos); float d = v3_len(toE);
    if (d < 8.0f || d > 280.0f) continue;
    float dp = v3_dot(v3_mul(toE, 1.0f / d), g_pl.fwd);
    if (dp > bestScore) { bestScore = dp; bestType = 1; bestIdx = i; }
  }
  if (g_gm.phase == 2) {
    for (int i = 0; i < MAX_RELAYS; i++) {
      if (!g_relays[i].alive) continue;
      Vec3 toR = v3_sub(g_relays[i].pos, g_pl.pos); float d = v3_len(toR);
      if (d > 340.0f) continue;
      float dp = v3_dot(v3_mul(toR, 1.0f / d), g_pl.fwd) + 0.04f;
      if (dp > bestScore) { bestScore = dp; bestType = 2; bestIdx = i; }
    }
  } else if (g_gm.phase == 3) {
    Vec3 toC = v3_sub(g_gm.corePos, g_pl.pos); float d = v3_len(toC);
    if (d < 360.0f) {
      float dp = v3_dot(v3_mul(toC, 1.0f / d), g_pl.fwd) + 0.06f;
      if (dp > bestScore) { bestScore = dp; bestType = 3; bestIdx = 0; }
    }
  }
  if (bestType != 0 && bestType == g_pl.lockType && bestIdx == g_pl.lockIdx) {
    float prevL = g_pl.lockAmt;
    g_pl.lockAmt = fminf(1.0f, g_pl.lockAmt + dt * 1.45f);
    if (prevL < 0.85f && g_pl.lockAmt >= 0.85f && g_gm.state == GS_PLAYING) audio_play_sfx(SFX_LOCKON, 0.35f, 0.0f, 1.0f);
  } else { g_pl.lockType = bestType; g_pl.lockIdx = bestIdx; g_pl.lockAmt = 0.0f; }

  for (int i = 0; i < MAX_ALLIES; i++) {
    AllyShip *a = &g_allies[i];
    float ang = elapsed * (0.28f + i * 0.06f) + a->phase;
    Vec3 goal = v3(sinf(ang) * (82.0f + i * 16.0f), 12.0f + cosf(ang * 1.5f) * 26.0f, -95.0f + cosf(ang) * 75.0f);
    a->fwd = v3_norm(v3_lerp(a->fwd, v3_norm(v3_sub(goal, a->pos)), dt * 2.2f));
    a->up  = v3_norm(v3_lerp(a->up, v3(sinf(ang) * 0.4f, 1.0f, 0.0f), dt * 2.0f));
    ortho_ship(&a->fwd, &a->up, &a->right);
    a->pos = v3_add(a->pos, v3_mul(a->fwd, 52.0f * dt));
    a->fireTimer -= dt;
    if (a->fireTimer <= 0.0f) {
      a->fireTimer = frand_range(0.55f, 1.35f);
      for (int e = 0; e < MAX_ENEMIES; e++) {
        if (!g_enemies[e].alive) continue;
        Vec3 toE = v3_sub(g_enemies[e].pos, a->pos);
        if (v3_len(toE) < 160.0f && v3_dot(v3_norm(toE), a->fwd) > 0.65f) {
          spawn_laser(v3_add(a->pos, v3_mul(a->right, 2.5f)), toE, 260.0f, 1, 0, 5.0f, 0, 0);
          break;
        }
      }
    }
  }

  int aliveEnemies = 0;
  for (int i = 0; i < MAX_ENEMIES; i++) {
    EnemyShip *e = &g_enemies[i];
    if (!e->alive) continue;
    aliveEnemies++;
    Vec3 toP = v3_sub(g_pl.pos, e->pos); float distP = v3_len(toP);
    Vec3 desiredDir;
    if (distP < 36.0f || e->evadeTimer > 0.0f) {
      if (e->evadeTimer <= 0.0f) e->evadeTimer = frand_range(1.6f, 3.0f);
      e->evadeTimer -= dt;
      desiredDir = v3_norm(v3_add(v3_mul(v3_norm(toP), -0.55f),
                   v3(sinf(elapsed * 2.2f + e->seed), cosf(elapsed * 1.9f + e->seed) * 0.6f, 0.25f)));
    } else {
      Vec3 weave = v3(sinf(elapsed * 1.6f + e->seed) * 18.0f, cosf(elapsed * 1.3f + e->seed) * 12.0f, 0.0f);
      desiredDir = v3_norm(v3_sub(v3_add(g_pl.pos, weave), e->pos));
    }
    Vec3 fromD = v3_sub(e->pos, get_dread_pos());
    if (v3_len(fromD) < DREAD_RADIUS + 24.0f) desiredDir = v3_norm(v3_add(desiredDir, v3_mul(v3_norm(fromD), 1.6f)));
    e->fwd = v3_norm(v3_lerp(e->fwd, desiredDir, dt * (e->type == 1 ? 1.4f : 2.3f)));
    e->up  = v3_norm(v3_lerp(e->up, v3(sinf(elapsed + e->seed) * 0.6f, 1.0f, 0.0f), dt * 2.0f));
    ortho_ship(&e->fwd, &e->up, &e->right);
    e->vel = v3_mul(e->fwd, e->speed);
    e->pos = v3_add(e->pos, v3_mul(e->vel, dt));

    e->fireTimer -= dt;
    if (e->fireTimer <= 0.0f && distP < 210.0f && v3_dot(v3_norm(toP), e->fwd) > 0.72f) {
      e->fireTimer = frand_range(0.85f, 1.95f);
      Vec3 aim = v3_add(toP, v3(frand_range(-4.5f, 4.5f), frand_range(-4.5f, 4.5f), frand_range(-4.5f, 4.5f)));
      spawn_laser(v3_add(e->pos, v3_mul(e->right, -0.35f)), aim, 195.0f, 0, 0, 7.5f, 0, 0);
      spawn_laser(v3_add(e->pos, v3_mul(e->right,  0.35f)), aim, 195.0f, 0, 0, 7.5f, 0, 0);
      if (distP < 110.0f && g_gm.state == GS_PLAYING) {
        float pan = clampf(v3_dot(v3_norm(v3_sub(e->pos, g_pl.pos)), g_pl.right), -0.8f, 0.8f);
        audio_play_sfx(SFX_LASER_GREEN, clampf(0.32f * (1.0f - distP / 120.0f), 0.06f, 0.30f), pan, frand_range(0.9f, 1.15f));
      }
    }
  }

  int desiredEnemies = (g_gm.state == GS_MENU) ? 12 : ((g_gm.phase == 1) ? 12 : 9);
  if (aliveEnemies < desiredEnemies && g_gm.state != GS_VICTORY) {
    for (int i = 0; i < MAX_ENEMIES; i++) {
      if (!g_enemies[i].alive) { spawn_enemy(i, (frand01() < 0.24f) ? 1 : 0); break; }
    }
  }

  if (g_gm.phase == 2 && g_gm.state == GS_PLAYING) {
    int aliveRelays = 0;
    for (int i = 0; i < MAX_RELAYS; i++) {
      if (!g_relays[i].alive) continue;
      aliveRelays++;
      g_relays[i].fireTimer -= dt;
      Vec3 toP = v3_sub(g_pl.pos, g_relays[i].pos);
      if (g_relays[i].fireTimer <= 0.0f && v3_len(toP) < 230.0f) {
        g_relays[i].fireTimer = frand_range(1.4f, 2.5f);
        spawn_laser(g_relays[i].pos, toP, 175.0f, 0, 0, 10.0f, 0, 0);
      }
    }
    if (aliveRelays == 0) {
      g_gm.phase = 3; g_gm.dishCharge = 0.05f; g_pl.torpedoes = 6;
      audio_play_sfx(SFX_BIG_BOOM, 0.8f, 0.0f, 0.85f);
    }
  }

  if (g_gm.phase == 3 && g_gm.state == GS_PLAYING) {
    g_gm.dishCharge = fminf(1.0f, g_gm.dishCharge + dt / 65.0f);
    if (g_gm.dishCharge >= 1.0f) damage_player(500.0f);
  }

  if (g_gm.state == GS_VICTORY) {
    g_gm.finaleTimer += dt;
    if (g_gm.finaleTimer < 4.5f && frand01() < dt * 4.5f) {
      Vec3 rndDir = v3_norm(v3(frand_range(-0.6f, 0.6f), frand_range(-0.5f, 0.5f), 0.75f));
      spawn_explosion(v3_add(get_dread_pos(), v3_mul(rndDir, DREAD_RADIUS + 4.0f)), frand_range(26.0f, 52.0f), frand_range(1.3f, 2.2f), 2);
    }
  }

  for (int i = 0; i < MAX_LASERS; i++) {
    Projectile *p = &g_lasers[i];
    if (!p->active) continue;
    p->life += dt;
    if (p->life >= p->maxLife) { p->active = 0; continue; }

    if (p->isTorp && p->targetType > 0) {
      Vec3 tPos = g_gm.corePos; int valid = 0;
      if (p->targetType == 1 && g_enemies[p->targetIdx].alive) { tPos = g_enemies[p->targetIdx].pos; valid = 1; }
      else if (p->targetType == 2 && g_relays[p->targetIdx].alive) { tPos = g_relays[p->targetIdx].pos; valid = 1; }
      else if (p->targetType == 3 && g_gm.phase == 3) { tPos = g_gm.corePos; valid = 1; }
      if (valid) {
        float spd = v3_len(p->vel);
        p->vel = v3_mul(v3_norm(v3_lerp(v3_norm(p->vel), v3_norm(v3_sub(tPos, p->pos)), dt * 5.2f)), spd);
      }
    }

    p->pos = v3_add(p->pos, v3_mul(p->vel, dt));

    if (p->isPlayer) {
      int hit = 0;
      for (int e = 0; e < MAX_ENEMIES; e++) {
        if (!g_enemies[e].alive) continue;
        float hitR = (g_enemies[e].type == 1 ? 4.8f : 3.9f) + (p->isTorp ? 3.5f : 0.0f);
        if (v3_len(v3_sub(p->pos, g_enemies[e].pos)) < hitR) {
          g_enemies[e].hp -= p->dmg; hit = 1;
          if (g_gm.state == GS_PLAYING) g_pl.hitFlash = 1.0f;
          if (g_enemies[e].hp <= 0.0f) {
            g_enemies[e].alive = 0;
            spawn_explosion(g_enemies[e].pos, g_enemies[e].type == 1 ? 14.0f : 10.5f, 1.05f, p->isTorp ? 1 : 0);
            if (g_gm.state == GS_PLAYING) {
              g_gm.kills++;
              g_gm.score += (g_enemies[e].type == 1 ? 250 : 100) * g_gm.sector;
              g_pl.shield = fminf(g_pl.maxShield, g_pl.shield + 8.0f);
              if (g_gm.phase == 1) {
                g_gm.phaseKills++;
                if (g_gm.phaseKills >= g_gm.phaseTarget) { g_gm.phase = 2; g_pl.torpedoes = 6; }
              }
            }
          } else {
            spawn_explosion(p->pos, 2.8f, 0.32f, 0);
          }
          break;
        }
      }
      if (!hit && g_gm.phase == 2 && g_gm.state == GS_PLAYING) {
        for (int r = 0; r < MAX_RELAYS; r++) {
          if (!g_relays[r].alive) continue;
          if (v3_len(v3_sub(p->pos, g_relays[r].pos)) < 9.5f) {
            g_relays[r].hp -= p->dmg; hit = 1; g_pl.hitFlash = 1.0f;
            if (g_relays[r].hp <= 0.0f) {
              g_relays[r].alive = 0; g_gm.score += 500 * g_gm.sector;
              spawn_explosion(g_relays[r].pos, 24.0f, 1.65f, 2);
            } else spawn_explosion(p->pos, 4.5f, 0.40f, 1);
            break;
          }
        }
      }
      if (!hit && g_gm.phase == 3 && g_gm.state == GS_PLAYING) {
        if (v3_len(v3_sub(p->pos, g_gm.corePos)) < 16.0f) {
          g_gm.coreHp -= p->dmg; hit = 1; g_pl.hitFlash = 1.0f;
          if (g_gm.coreHp <= 0.0f) {
            g_gm.coreHp = 0.0f; g_gm.state = GS_VICTORY;
            g_gm.menuSel = 0; g_gm.prevHover = -1;
            g_gm.score += 2500 * g_gm.sector;
            spawn_explosion(g_gm.corePos, 58.0f, 2.8f, 2);
          } else spawn_explosion(p->pos, 6.5f, 0.45f, 1);
        }
      }
      if (hit) { p->active = 0; continue; }
    } else if (g_gm.state == GS_PLAYING) {
      if (v3_len(v3_sub(p->pos, g_pl.pos)) < 3.1f) {
        damage_player(p->dmg);
        spawn_sparks(p->pos, 8, 28.0f, v3(0.35f, 0.88f, 1.0f));
        p->active = 0; continue;
      }
    }

    if (v3_len(v3_sub(p->pos, get_dread_pos())) < DREAD_RADIUS - 3.0f) {
      spawn_explosion(p->pos, p->isTorp ? 10.0f : 3.2f, 0.45f, 0);
      p->active = 0;
    }
  }

  for (int i = 0; i < MAX_EXPLOSIONS; i++) {
    if (!g_expl[i].active) continue;
    g_expl[i].age += dt;
    if (g_expl[i].age >= g_expl[i].dur) g_expl[i].active = 0;
  }
  for (int i = 0; i < MAX_SPARKS; i++) {
    if (!g_sparks[i].active) continue;
    g_sparks[i].age += dt;
    if (g_sparks[i].age >= g_sparks[i].dur) { g_sparks[i].active = 0; continue; }
    g_sparks[i].pos = v3_add(g_sparks[i].pos, v3_mul(g_sparks[i].vel, dt));
    g_sparks[i].vel = v3_mul(g_sparks[i].vel, 1.0f - dt * 1.4f);
  }
}

// ============================================================================
// UI SCREEN RENDERERS (4-SECOND DULA SPLASH, MAIN MENU, PAUSE & FULLSCREEN HUD)
// ============================================================================
static void draw_menu_button(int idx, const char *label, float fade) {
  float x, y, w, h;
  get_menu_item_rect(idx, &x, &y, &w, &h);
  int sel = (g_gm.menuSel == idx);
  float sc = clampf((float)g_winH / 720.0f, 0.85f, 1.75f);

  // Translucent dark slate glass panel + cyan highlight when hovered/selected
  if (sel) {
    ui_rect(x, y, w, h, 0.06f, 0.22f, 0.34f, 0.86f * fade);
    ui_rect(x, y, 5.0f * sc, h, 0.25f, 0.88f, 1.00f, 0.98f * fade);
    ui_border(x, y, w, h, 1.5f, 0.32f, 0.88f, 1.00f, 0.85f * fade);
    ui_text_shadow(x + 18.0f * sc, y + (h - 7.0f * 2.4f * sc) * 0.5f, 2.4f * sc, 1.5f * sc, ">", 0.32f, 0.95f, 1.0f, fade);
    ui_text_shadow(x + 40.0f * sc, y + (h - 7.0f * 2.4f * sc) * 0.5f, 2.4f * sc, 1.5f * sc, label, 1.0f, 0.98f, 0.95f, fade);
  } else {
    ui_rect(x, y, w, h, 0.03f, 0.06f, 0.11f, 0.70f * fade);
    ui_border(x, y, w, h, 1.0f, 0.28f, 0.45f, 0.65f, 0.32f * fade);
    ui_text_shadow(x + 22.0f * sc, y + (h - 7.0f * 2.3f * sc) * 0.5f, 2.3f * sc, 1.4f * sc, label, 0.72f, 0.84f, 0.94f, 0.92f * fade);
  }
}

static void render_ui_pass(float elapsed) {
  float W = (float)g_winW, H = (float)g_winH;
  float cx = W * 0.5f, cy = H * 0.5f;
  float sc = clampf(H / 720.0f, 0.85f, 1.75f);

  ui_begin();

  if (g_gm.state == GS_SPLASH) {
    // ========================================================================
    // 4.0-SECOND ANIMATED PRESENTATION: "DULA GAME STUDIOS"
    // ========================================================================
    float t = g_gm.splashTimer;
    float fadeIn  = smoothstep_f(t / 0.65f);
    float fadeOut = 1.0f - smoothstep_f((t - 3.25f) / 0.75f);
    float master  = fadeIn * fadeOut;

    // Subtle dark cinematic theater vignette backdrop (lets the ringed planet & stars peek through!)
    ui_rect(0, 0, W, H, 0.01f, 0.015f, 0.03f, 0.64f * fadeOut + 0.36f * (1.0f - fadeIn));
    // Widescreen cinema letterbox bars that open gracefully
    float barH = H * 0.105f * fadeOut;
    ui_rect(0, 0, W, barH, 0.0f, 0.0f, 0.0f, 0.92f * fadeOut);
    ui_rect(0, H - barH, W, barH, 0.0f, 0.0f, 0.0f, 0.92f * fadeOut);

    // Expanding Holographic Crest Rings + Pink/Cyan Energy Core behind logo
    float ringT = smoothstep_f(t / 1.35f);
    float pulse = 0.92f + 0.08f * sinf(t * 5.0f);
    ui_glow(cx, cy - 18.0f * sc, 280.0f * sc * ringT, 120.0f * sc * ringT, 0.10f, 0.48f, 0.88f, 0.38f * master);
    ui_glow(cx, cy - 18.0f * sc, 160.0f * sc * ringT,  70.0f * sc * ringT, 0.95f, 0.14f, 0.45f, 0.32f * master);
    ui_ring(cx, cy - 18.0f * sc, (115.0f + 55.0f * ringT) * sc * pulse, 0.22f, 0.84f, 1.00f, 0.55f * master);
    ui_ring(cx, cy - 18.0f * sc, (150.0f + 80.0f * smoothstep_f((t - 0.25f) / 1.4f)) * sc, 1.00f, 0.20f, 0.52f, 0.30f * master);

    // Sweeping Horizontal Anamorphic Lens Flare Streak across the "DULA" title
    float sweepX = lerpf(cx - 520.0f * sc, cx + 520.0f * sc, smoothstep_f((t - 0.35f) / 1.65f));
    float sweepA = sinf(clampf((t - 0.35f) / 1.65f, 0.0f, 1.0f) * PI_F);
    ui_glow(sweepX, cy - 28.0f * sc, 340.0f * sc, 14.0f * sc, 0.45f, 0.92f, 1.00f, 0.85f * sweepA * master);
    ui_glow(sweepX, cy - 28.0f * sc, 140.0f * sc, 38.0f * sc, 1.00f, 0.96f, 1.00f, 0.65f * sweepA * master);

    // Giant Animated "DULA" Studio Wordmark (letter-spacing gently locks in)
    float titleIn = smoothstep_f((t - 0.20f) / 0.85f);
    float dulaScale = (10.5f + (1.0f - titleIn) * 2.5f) * sc;
    float dulaTrack = (28.0f - 14.0f * titleIn) * sc;
    float dulaY = cy - 74.0f * sc;
    ui_text_center_shadow(cx, dulaY, dulaScale, dulaTrack, "DULA", 0.96f, 0.98f, 1.00f, titleIn * master);
    // Subtle cyan top sheen over DULA
    ui_text_center(cx, dulaY - 1.5f * sc, dulaScale, dulaTrack, "DULA", 0.32f, 0.88f, 1.00f, 0.28f * titleIn * master);

    // Sleek expanding divider wings
    float barW = 240.0f * sc * smoothstep_f((t - 0.55f) / 0.75f);
    ui_rect(cx - barW, cy + 16.0f * sc, barW * 2.0f, 2.5f * sc, 0.28f, 0.86f, 1.00f, 0.85f * master);

    // "GAME STUDIOS" tracked out cleanly beneath divider
    float subIn = smoothstep_f((t - 0.75f) / 0.75f);
    ui_text_center_shadow(cx, cy + 32.0f * sc, 3.8f * sc, 9.5f * sc, "GAME STUDIOS", 0.35f, 0.90f, 1.00f, subIn * master);

    // "PRESENTS" + Tech Badge
    float presIn = smoothstep_f((t - 1.35f) / 0.70f);
    ui_text_center_shadow(cx, cy + 84.0f * sc, 2.0f * sc, 5.0f * sc, "PRESENTS", 0.88f, 0.92f, 0.98f, 0.85f * presIn * master);
    ui_text_center(cx, H - barH - 28.0f * sc, 1.6f * sc, 2.2f * sc,
                   "NVIDIA OPENGL 4.6 COMPUTE // HDR RAY-VOLUMETRIC ENGINE", 0.52f, 0.70f, 0.86f, 0.70f * presIn * master);

  } else if (g_gm.state == GS_MENU) {
    // ========================================================================
    // INTERACTIVE MAIN MENU (LEFT-ANCHORED OVER LIVE 3D ORBITAL BATTLE!)
    // ========================================================================
    float fade = smoothstep_f(g_gm.menuFade);
    float mx = W * 0.075f;

    // Subtle left gradient vignette scrim so menu text pops against bright explosions
    ui_rect(0, 0, W * 0.44f, H, 0.01f, 0.02f, 0.045f, 0.56f * fade);
    ui_rect(W * 0.44f, 0, W * 0.14f, H, 0.01f, 0.02f, 0.045f, 0.22f * fade);

    // Studio badge + Giant On-Screen Game Title: STARFORGE / ECLIPSE COMMAND
    ui_text_shadow(mx, H * 0.105f, 2.0f * sc, 4.0f * sc, "DULA GAME STUDIOS PRESENTS", 0.32f, 0.86f, 1.00f, 0.92f * fade);
    ui_glow(mx + 190.0f * sc, H * 0.19f, 240.0f * sc, 55.0f * sc, 0.18f, 0.62f, 1.00f, 0.25f * fade);
    ui_text_shadow(mx, H * 0.145f, 7.2f * sc, 4.5f * sc, "STARFORGE", 0.98f, 0.99f, 1.00f, fade);
    ui_rect(mx, H * 0.240f, 370.0f * sc, 3.0f * sc, 0.98f, 0.18f, 0.48f, 0.90f * fade);
    ui_text_shadow(mx, H * 0.258f, 3.1f * sc, 5.2f * sc, "ECLIPSE COMMAND", 1.00f, 0.82f, 0.42f, 0.95f * fade);

    char lblDisp[64], lblFilt[64], lblTM[64], lblAud[64];
    snprintf(lblDisp, sizeof(lblDisp), "DISPLAY : %s", g_fullscreen ? "FULLSCREEN" : "WINDOWED");
    snprintf(lblFilt, sizeof(lblFilt), "FILTER  : %s", FILTER_NAMES[g_gfx.filter]);
    snprintf(lblTM,   sizeof(lblTM),   "TONEMAP : %s", TM_NAMES[g_gfx.toneMap]);
    snprintf(lblAud,  sizeof(lblAud),  "AUDIO   : %s", g_audioMuted ? "MUTED" : "ON");

    draw_menu_button(0, "LAUNCH MISSION", fade);
    draw_menu_button(1, lblDisp, fade);
    draw_menu_button(2, lblFilt, fade);
    draw_menu_button(3, lblTM, fade);
    draw_menu_button(4, lblAud, fade);
    draw_menu_button(5, "EXIT TO WINDOWS", fade);

    // Compact bottom control bar + GPU Telemetry
    ui_rect(0, H - 40.0f * sc, W, 40.0f * sc, 0.01f, 0.02f, 0.04f, 0.72f * fade);
    ui_rect(0, H - 40.0f * sc, W, 1.5f, 0.25f, 0.75f, 0.95f, 0.35f * fade);
    ui_text(mx, H - 27.0f * sc, 1.75f * sc, 1.2f * sc,
            "MOUSE: AIM  |  LMB/SPACE: LASERS  |  RMB/E: TORPEDOES  |  SHIFT: BOOST  |  C: S-FOILS  |  TAB: CAM  |  F11: FULLSCREEN",
            0.70f, 0.82f, 0.92f, 0.90f * fade);

    char gpuLine[128];
    snprintf(gpuLine, sizeof(gpuLine), "%.0f FPS  GPU %.1fMS  %s",
             g_lastFps, g_gpuMs, (g_nvml.active && g_nvml.name[0]) ? g_nvml.name : "OPENGL 4.6 HDR");
    float gw = ui_text_width(gpuLine, 1.7f * sc, 1.0f * sc);
    ui_text_shadow(W - gw - 24.0f * sc, 20.0f * sc, 1.7f * sc, 1.0f * sc, gpuLine, 0.38f, 0.92f, 0.62f, 0.88f * fade);

  } else if (g_gm.state == GS_PLAYING) {
    // ========================================================================
    // FULLSCREEN-READY LIVE COMBAT HUD OVERLAY
    // ========================================================================
    char objBuf[96], secBuf[64], scoreBuf[64], statBuf[128], vitL[64], vitR[96];
    snprintf(secBuf, sizeof(secBuf), "STARFORGE // SECTOR %d", g_gm.sector);
    if (g_gm.phase == 1) {
      snprintf(objBuf, sizeof(objBuf), "PHASE 1: DESTROY INTERCEPTORS [%d/%d]", g_gm.phaseKills, g_gm.phaseTarget);
    } else if (g_gm.phase == 2) {
      int rAlive = 0; for (int i = 0; i < MAX_RELAYS; i++) if (g_relays[i].alive) rAlive++;
      snprintf(objBuf, sizeof(objBuf), "PHASE 2: DESTROY SHIELD RELAYS [%d LEFT]", rAlive);
    } else {
      snprintf(objBuf, sizeof(objBuf), "PHASE 3: DESTROY SUPERLASER CORE! [CHARGE %d%%]", (int)(g_gm.dishCharge * 100.0f));
    }

    // Top-Left Mission & GPU Telemetry
    ui_text_shadow(22.0f * sc, 16.0f * sc, 1.9f * sc, 1.5f * sc, secBuf, 0.35f, 0.88f, 1.00f, 0.92f);
    ui_text_shadow(22.0f * sc, 36.0f * sc, 1.75f * sc, 1.2f * sc, objBuf,
                   g_gm.phase == 3 ? 0.35f : (g_gm.phase == 2 ? 1.00f : 0.88f),
                   g_gm.phase == 3 ? 1.00f : (g_gm.phase == 2 ? 0.76f : 0.94f),
                   g_gm.phase == 3 ? 0.45f : (g_gm.phase == 2 ? 0.25f : 1.00f), 0.92f);

    snprintf(statBuf, sizeof(statBuf), "%.0f FPS | GPU %.1fMS%s%s | %s",
             g_lastFps, g_gpuMs,
             g_nvml.active ? " | " : "", (g_nvml.active && g_nvml.name[0]) ? g_nvml.name : "",
             FILTER_NAMES[g_gfx.filter]);
    ui_text_shadow(22.0f * sc, 56.0f * sc, 1.45f * sc, 1.0f * sc, statBuf, 0.56f, 0.72f, 0.84f, 0.78f);

    // Top-Right Score & Kills
    snprintf(scoreBuf, sizeof(scoreBuf), "SCORE %06d   KILLS %02d", g_gm.score, g_gm.kills);
    float sw = ui_text_width(scoreBuf, 2.0f * sc, 1.4f * sc);
    ui_text_shadow(W - sw - 22.0f * sc, 18.0f * sc, 2.0f * sc, 1.4f * sc, scoreBuf, 0.38f, 0.90f, 1.00f, 0.92f);

    // Bottom-Left Shield & Hull Numeric Readout
    snprintf(vitL, sizeof(vitL), "SHIELD %3d%%   HULL %3d%%", (int)g_pl.shield, (int)g_pl.hull);
    ui_text_shadow(22.0f * sc, H - 34.0f * sc, 1.85f * sc, 1.2f * sc, vitL, 0.35f, 0.92f, 1.00f, 0.88f);

    // Bottom-Right Flight Status & Pause Hint
    snprintf(vitR, sizeof(vitR), "THR %3d%%  S-FOILS:%s  TORPS:%d  [ESC:MENU]",
             (int)(g_pl.throttle * 100.0f), g_pl.sFoilTarget ? "X-LOCK" : "CRUISE", g_pl.torpedoes);
    float rw = ui_text_width(vitR, 1.75f * sc, 1.1f * sc);
    ui_text_shadow(W - rw - 22.0f * sc, H - 34.0f * sc, 1.75f * sc, 1.1f * sc, vitR, 0.84f, 0.90f, 0.96f, 0.85f);

  } else if (g_gm.state == GS_PAUSE) {
    // ========================================================================
    // IN-GAME PAUSE & SETTINGS MENU (ESC / P)
    // ========================================================================
    ui_rect(0, 0, W, H, 0.01f, 0.02f, 0.04f, 0.62f);
    float pw = 420.0f * sc, ph = 470.0f * sc;
    float px = (W - pw) * 0.5f, py = H * 0.16f;
    ui_rect(px, py, pw, ph, 0.025f, 0.045f, 0.085f, 0.90f);
    ui_border(px, py, pw, ph, 2.0f, 0.28f, 0.82f, 1.00f, 0.72f);
    ui_text_center_shadow(cx, py + 22.0f * sc, 3.6f * sc, 4.0f * sc, "MISSION PAUSED", 0.96f, 0.98f, 1.00f, 1.0f);
    ui_text_center(cx, py + 58.0f * sc, 1.6f * sc, 2.2f * sc, "STARFORGE: ECLIPSE COMMAND", 0.35f, 0.85f, 1.00f, 0.82f);

    char lblDisp[64], lblFilt[64], lblTM[64];
    snprintf(lblDisp, sizeof(lblDisp), "DISPLAY : %s", g_fullscreen ? "FULLSCREEN" : "WINDOWED");
    snprintf(lblFilt, sizeof(lblFilt), "FILTER  : %s", FILTER_NAMES[g_gfx.filter]);
    snprintf(lblTM,   sizeof(lblTM),   "TONEMAP : %s", TM_NAMES[g_gfx.toneMap]);

    draw_menu_button(0, "RESUME MISSION", 1.0f);
    draw_menu_button(1, "RESTART SECTOR", 1.0f);
    draw_menu_button(2, lblDisp, 1.0f);
    draw_menu_button(3, lblFilt, 1.0f);
    draw_menu_button(4, lblTM, 1.0f);
    draw_menu_button(5, "MAIN MENU", 1.0f);
    draw_menu_button(6, "EXIT TO WINDOWS", 1.0f);

  } else {
    // ========================================================================
    // VICTORY & GAME OVER CINEMATIC SUMMARY OVERLAY
    // ========================================================================
    int win = (g_gm.state == GS_VICTORY);
    ui_rect(0, 0, W, H, 0.01f, 0.015f, 0.03f, 0.48f);
    float pw = 480.0f * sc, ph = 390.0f * sc;
    float px = (W - pw) * 0.5f, py = H * 0.22f;
    ui_rect(px, py, pw, ph, 0.025f, 0.04f, 0.075f, 0.88f);
    ui_border(px, py, pw, ph, 2.0f, win ? 0.25f : 1.00f, win ? 0.98f : 0.22f, win ? 0.45f : 0.18f, 0.85f);

    ui_text_center_shadow(cx, py + 32.0f * sc, 4.0f * sc, 3.0f * sc,
                          win ? "DREADNOUGHT DESTROYED" : "STARFIGHTER LOST",
                          win ? 0.30f : 1.00f, win ? 1.00f : 0.28f, win ? 0.52f : 0.24f, 1.0f);

    char sum[96];
    snprintf(sum, sizeof(sum), "SECTOR %d   |   SCORE %06d   |   KILLS %d", g_gm.sector, g_gm.score, g_gm.kills);
    ui_text_center_shadow(cx, py + 95.0f * sc, 2.1f * sc, 1.8f * sc, sum, 0.88f, 0.94f, 1.00f, 0.95f);

    draw_menu_button(0, win ? "NEXT SECTOR" : "RETRY MISSION", 1.0f);
    draw_menu_button(1, "MAIN MENU", 1.0f);
    draw_menu_button(2, "EXIT TO WINDOWS", 1.0f);
  }

  (void)elapsed;
  ui_flush();
}

// ============================================================================
// WIN32 WINDOW, INPUT, FULLSCREEN & OPENGL 4.6 CORE BOOTSTRAP
// ============================================================================
static void apply_vsync(void) {
  if (!wglSwapIntervalEXT) return;
  if (g_gfx.vsyncMode == 0) wglSwapIntervalEXT(0);
  else if (g_gfx.vsyncMode == 1) { if (!wglSwapIntervalEXT(-1)) wglSwapIntervalEXT(1); }
  else wglSwapIntervalEXT(1);
}

static void toggle_fullscreen(void) {
  DWORD style = (DWORD)GetWindowLongA(g_hwnd, GWL_STYLE);
  if (!g_fullscreen) {
    MONITORINFO mi; memset(&mi, 0, sizeof(mi)); mi.cbSize = sizeof(mi);
    g_wpPrev.length = sizeof(g_wpPrev);
    if (GetWindowPlacement(g_hwnd, &g_wpPrev) &&
        GetMonitorInfoA(MonitorFromWindow(g_hwnd, MONITOR_DEFAULTTOPRIMARY), &mi)) {
      SetWindowLongA(g_hwnd, GWL_STYLE, (LONG)(style & ~WS_OVERLAPPEDWINDOW));
      SetWindowPos(g_hwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top,
        mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top,
        SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
      g_fullscreen = 1;
    }
  } else {
    SetWindowLongA(g_hwnd, GWL_STYLE, (LONG)(style | WS_OVERLAPPEDWINDOW));
    SetWindowPlacement(g_hwnd, &g_wpPrev);
    SetWindowPos(g_hwnd, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
    g_fullscreen = 0;
  }
  g_needResize = 1;
}

static LRESULT CALLBACK wnd_proc(HWND h, UINT msg, WPARAM w, LPARAM l) {
  switch (msg) {
    case WM_CLOSE:
    case WM_DESTROY:
      set_cursor_hidden(0);
      g_running = 0; PostQuitMessage(0); return 0;

    case WM_SETFOCUS:
      g_windowFocused = 1; return 0;
    case WM_KILLFOCUS:
      g_windowFocused = 0;
      set_cursor_hidden(0);
      memset(g_keys, 0, sizeof(g_keys));
      g_mouseL = g_mouseR = 0;
      return 0;

    case WM_SIZE: {
      int nw = (int)LOWORD(l), nh = (int)HIWORD(l);
      if (nw > 0 && nh > 0) { g_winW = nw; g_winH = nh; g_needResize = 1; }
      return 0;
    }

    case WM_MOUSEMOVE: {
      int mx = (int)(short)LOWORD(l), my = (int)(short)HIWORD(l);
      g_mousePxX = (float)mx;
      g_mousePxY = (float)my;
      g_mouseUvX = clampf((float)mx / (float)(g_winW > 1 ? g_winW : 1), 0.0f, 1.0f);
      g_mouseUvY = clampf(1.0f - (float)my / (float)(g_winH > 1 ? g_winH : 1), 0.0f, 1.0f);
      if (g_gm.state != GS_PLAYING && g_gm.state != GS_SPLASH) update_menu_hover();
      return 0;
    }

    case WM_LBUTTONDOWN:
      g_mouseL = 1;
      if (g_gm.state != GS_PLAYING) handle_menu_click();
      return 0;
    case WM_LBUTTONUP:   g_mouseL = 0; return 0;
    case WM_RBUTTONDOWN: g_mouseR = 1; return 0;
    case WM_RBUTTONUP:   g_mouseR = 0; return 0;

    case WM_MOUSEWHEEL: {
      short delta = (short)HIWORD(w);
      if (g_gm.state == GS_PLAYING) {
        g_pl.throttle = clampf(g_pl.throttle + (float)delta * 0.0006f, 0.15f, 1.0f);
      }
      return 0;
    }

    case WM_SYSKEYDOWN: {
      // Support Alt+Enter standard Windows fullscreen toggle
      if (w == VK_RETURN && (l & (1 << 29))) {
        toggle_fullscreen();
        return 0;
      }
      break;
    }

    case WM_KEYDOWN: {
      int vk = (int)(w & 255);
      int first = ((l & (1 << 30)) == 0);
      g_keys[vk] = 1;
      if (first) {
        if (vk == VK_F11) { toggle_fullscreen(); return 0; }

        if (g_gm.state == GS_SPLASH) {
          if (vk == VK_SPACE || vk == VK_RETURN || vk == VK_ESCAPE) {
            g_gm.state = GS_MENU; g_gm.menuFade = 0.0f; g_gm.menuSel = 0;
            audio_play_sfx(SFX_UI_CLICK, 0.40f, 0.0f, 1.0f);
          }
          return 0;
        }

        // Keyboard navigation in Menus (Main, Pause, Victory, Game Over)
        if (g_gm.state == GS_MENU || g_gm.state == GS_PAUSE || g_gm.state == GS_VICTORY || g_gm.state == GS_GAMEOVER) {
          int cnt = get_menu_item_count();
          if (vk == VK_UP || vk == 'W') {
            g_gm.menuSel = (g_gm.menuSel + cnt - 1) % cnt;
            audio_play_sfx(SFX_UI_HOVER, 0.35f, 0.0f, 1.0f);
          } else if (vk == VK_DOWN || vk == 'S') {
            g_gm.menuSel = (g_gm.menuSel + 1) % cnt;
            audio_play_sfx(SFX_UI_HOVER, 0.35f, 0.0f, 1.0f);
          } else if (vk == VK_RETURN || vk == VK_SPACE) {
            execute_menu_action(g_gm.menuSel);
          } else if ((vk == VK_ESCAPE || vk == 'P') && g_gm.state == GS_PAUSE) {
            g_gm.state = GS_PLAYING; g_resetHistory = 1;
            audio_play_sfx(SFX_UI_CLICK, 0.40f, 0.0f, 1.0f);
          } else if (vk == VK_ESCAPE && g_gm.state == GS_MENU) {
            g_running = 0; PostQuitMessage(0);
          } else if (vk == 'M') {
            g_audioMuted = !g_audioMuted;
          }
          return 0;
        }

        // Active Gameplay Hotkeys
        if (vk == VK_ESCAPE || vk == 'P') {
          g_gm.state = GS_PAUSE; g_gm.menuSel = 0; g_gm.prevHover = -1;
          audio_play_sfx(SFX_UI_CLICK, 0.40f, 0.0f, 0.9f);
        } else if (vk == 'C') {
          g_pl.sFoilTarget = !g_pl.sFoilTarget;
          audio_play_sfx(SFX_SFOIL, 0.42f, 0.0f, 1.0f);
        } else if (vk == VK_TAB) { g_gfx.camMode = (g_gfx.camMode + 1) % 3; g_resetHistory = 1; }
        else if (vk == 'F') { g_gfx.filter = (g_gfx.filter + 1) & 3; g_resetHistory = 1; }
        else if (vk == 'T') { g_gfx.toneMap = (g_gfx.toneMap + 1) & 3; }
        else if (vk == 'B') { g_gfx.split = !g_gfx.split; }
        else if (vk == 'G') { g_gfx.taa = !g_gfx.taa; g_resetHistory = 1; }
        else if (vk == 'X') { g_gfx.autoExp = !g_gfx.autoExp; g_resetAdapt = 1; }
        else if (vk == 'M') { g_audioMuted = !g_audioMuted; }
        else if (vk == 'U') { g_gfx.vsyncMode = (g_gfx.vsyncMode + 1) % 3; apply_vsync(); }
        else if (vk == 0xBD) { g_gfx.exposure = clampf(g_gfx.exposure - 0.15f, -2.0f, 2.0f); }
        else if (vk == 0xBB) { g_gfx.exposure = clampf(g_gfx.exposure + 0.15f, -2.0f, 2.0f); }
        else if (vk == VK_F5) { g_gfx.renderScale = 0.50f; g_needResize = 1; }
        else if (vk == VK_F6) { g_gfx.renderScale = 0.75f; g_needResize = 1; }
        else if (vk == VK_F7) { g_gfx.renderScale = 1.00f; g_needResize = 1; }
        else if (vk == VK_F8) { g_gfx.renderScale = 1.25f; g_needResize = 1; }
      }
      return 0;
    }
    case WM_KEYUP:
      g_keys[w & 255] = 0;
      return 0;
  }
  return DefWindowProcA(h, msg, w, l);
}

static int init_gl_context(HWND hwnd) {
  g_hdc = GetDC(hwnd);
  PIXELFORMATDESCRIPTOR pfd;
  memset(&pfd, 0, sizeof(pfd));
  pfd.nSize = sizeof(pfd); pfd.nVersion = 1;
  pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
  pfd.iPixelType = PFD_TYPE_RGBA;
  pfd.cColorBits = 32; pfd.cDepthBits = 24; pfd.cStencilBits = 8;
  pfd.iLayerType = PFD_MAIN_PLANE;

  int pf = ChoosePixelFormat(g_hdc, &pfd);
  if (!pf || !SetPixelFormat(g_hdc, pf, &pfd)) return 0;

  HGLRC tempRC = wglCreateContext(g_hdc);
  if (!tempRC || !wglMakeCurrent(g_hdc, tempRC)) return 0;

  wglCreateContextAttribsARB = (PFNWGLCREATECONTEXTATTRIBSARBPROC)wglGetProcAddress("wglCreateContextAttribsARB");
  if (wglCreateContextAttribsARB) {
    const int vers[4][2] = { {4,6}, {4,5}, {4,4}, {4,3} };
    HGLRC coreRC = NULL;
    for (int i = 0; i < 4 && !coreRC; i++) {
      const int attr[] = {
        WGL_CONTEXT_MAJOR_VERSION_ARB, vers[i][0],
        WGL_CONTEXT_MINOR_VERSION_ARB, vers[i][1],
        WGL_CONTEXT_PROFILE_MASK_ARB,  WGL_CONTEXT_CORE_PROFILE_BIT_ARB, 0
      };
      coreRC = wglCreateContextAttribsARB(g_hdc, 0, attr);
    }
    if (coreRC) {
      wglMakeCurrent(NULL, NULL); wglDeleteContext(tempRC);
      wglMakeCurrent(g_hdc, coreRC); g_hrc = coreRC;
    } else g_hrc = tempRC;
  } else g_hrc = tempRC;

  if (!load_gl_functions()) return 0;
  while (glGetError() != GL_NO_ERROR) {}
  GLint totalKb = 0;
  glGetIntegerv(GL_GPU_MEMORY_INFO_DEDICATED_VIDMEM_NVX, &totalKb);
  if (glGetError() == GL_NO_ERROR && totalKb > 0) g_hasNvMemInfo = 1;
  return 1;
}

static void bind_tex(int unit, GLuint tex, GLint loc) {
  pglActiveTexture(GL_TEXTURE0 + (GLenum)unit);
  glBindTexture(GL_TEXTURE_2D, tex);
  pglUniform1i(loc, unit);
}

static void draw_mesh(const Mesh *m, const float model[16], float emissiveScale, float shieldFlash, float dishCharge) {
  pglUniformMatrix4fv(g_pMesh.uModel, 1, GL_FALSE, model);
  pglUniform1f(g_pMesh.uEmissiveScale, emissiveScale);
  pglUniform1f(g_pMesh.uShieldFlash, shieldFlash);
  pglUniform1f(g_pMesh.uDishCharge, dishCharge);
  pglBindVertexArray(m->vao);
  glDrawArrays(GL_TRIANGLES, 0, m->vertCount);
}

static void draw_xwing_ship(Vec3 pos, Vec3 right, Vec3 up, Vec3 fwd, float sFoilAnim, float engineGlow, float shieldFlash) {
  float shipM[16];
  mat4_from_ship(shipM, pos, right, up, fwd, 1.0f);
  draw_mesh(&g_meshXBody, shipM, engineGlow, shieldFlash, 0.0f);
  float spread = 0.02f + 0.25f * sFoilAnim;
  float wingAngles[4] = { spread, -spread, PI_F - spread, PI_F + spread };
  for (int w = 0; w < 4; w++) {
    float rotM[16], fullM[16];
    mat4_rot_z(rotM, wingAngles[w]);
    mat4_mul(fullM, shipM, rotM);
    draw_mesh(&g_meshXWing, fullM, engineGlow, shieldFlash, 0.0f);
  }
}

static void draw_xwing_plumes(Vec3 pos, Vec3 right, Vec3 up, Vec3 fwd, float sFoilAnim, float boostAmt, float timeNow) {
  float shipM[16];
  mat4_from_ship(shipM, pos, right, up, fwd, 1.0f);
  float spread = 0.02f + 0.25f * sFoilAnim;
  float wingAngles[4] = { spread, -spread, PI_F - spread, PI_F + spread };
  float flicker = 0.93f + 0.07f * sinf(timeNow * 46.0f);
  float len = (1.28f + boostAmt * 2.15f) * flicker;
  float rad = 0.185f + boostAmt * 0.085f;
  float core[3] = { 1.0f, 0.72f, 0.90f };
  float edge[3] = { 0.95f, 0.05f, 0.40f };
  pglUniform3fv(g_pFX.uCoreColor, 1, core);
  pglUniform3fv(g_pFX.uEdgeColor, 1, edge);
  pglUniform1f(g_pFX.uIntensity, (5.2f + boostAmt * 7.8f) * flicker);
  pglUniform1i(g_pFX.uIsPlume, 1);
  pglBindVertexArray(g_meshPlume.vao);
  for (int w = 0; w < 4; w++) {
    float rotM[16], trM[16], scM[16], tmp[16], fullM[16];
    mat4_rot_z(rotM, wingAngles[w]);
    mat4_translate(trM, 0.92f, 0.22f, 2.22f);
    mat4_scale_xyz(scM, rad, rad, len);
    mat4_mul(tmp, rotM, trM);
    mat4_mul(tmp, tmp, scM);
    mat4_mul(fullM, shipM, tmp);
    pglUniformMatrix4fv(g_pFX.uModel, 1, GL_FALSE, fullM);
    glDrawArrays(GL_TRIANGLES, 0, g_meshPlume.vertCount);
  }
}

// ============================================================================
// ENTRY POINT & 8-PASS NVIDIA HDR + COMPUTE + GPU UI GAME LOOP
// ============================================================================
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmd, int show) {
  (void)hPrev; (void)cmd; (void)show;
  memset(&g_wpPrev, 0, sizeof(g_wpPrev));
  g_wpPrev.length = sizeof(g_wpPrev);
  init_halton();
  nvml_try_init();
  audio_init();

  // Build crisp procedural game icons for taskbar, titlebar & Alt-Tab switcher
  g_hIconBig   = create_runtime_icon(64);
  g_hIconSmall = create_runtime_icon(32);

  WNDCLASSA wc;
  memset(&wc, 0, sizeof(wc));
  wc.style         = CS_OWNDC;
  wc.lpfnWndProc   = wnd_proc;
  wc.hInstance     = hInst;
  wc.lpszClassName = "DulaStarforgeEclipseV3";
  wc.hIcon         = g_hIconBig;
  wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
  RegisterClassA(&wc);

  RECT wr = { 0, 0, g_winW, g_winH };
  AdjustWindowRect(&wr, WS_OVERLAPPEDWINDOW, FALSE);
  g_hwnd = CreateWindowA(
    "DulaStarforgeEclipseV3",
    "DULA GAME STUDIOS // STARFORGE: ECLIPSE COMMAND",
    WS_OVERLAPPEDWINDOW | WS_VISIBLE,
    CW_USEDEFAULT, CW_USEDEFAULT,
    wr.right - wr.left, wr.bottom - wr.top,
    NULL, NULL, hInst, NULL
  );

  if (g_hIconBig)   SendMessageA(g_hwnd, WM_SETICON, ICON_BIG,   (LPARAM)g_hIconBig);
  if (g_hIconSmall) SendMessageA(g_hwnd, WM_SETICON, ICON_SMALL, (LPARAM)g_hIconSmall);

  if (!init_gl_context(g_hwnd) || !init_all_shaders()) {
    MessageBoxA(g_hwnd, "OpenGL 4.3+ Compute initialization failed.", "DULA GAME STUDIOS // STARFORGE", MB_OK | MB_ICONERROR);
    audio_shutdown(); nvml_cleanup(); return 1;
  }

  pglGenVertexArrays(1, &g_emptyVAO);
  if (pglGenQueries) pglGenQueries(2, g_timerQuery);
  init_all_meshes();
  ui_init();
  apply_vsync();

  // Launch directly into crisp Windows 11 Borderless Fullscreen mode!
  toggle_fullscreen();
  RECT rc;
  GetClientRect(g_hwnd, &rc);
  g_winW = rc.right - rc.left; g_winH = rc.bottom - rc.top;
  rebuild_targets();

  g_gm.score = 0; g_gm.kills = 0;
  g_gm.splashTimer = 0.0f; g_gm.menuFade = 0.0f;
  init_sector(1, GS_SPLASH);
  audio_play_sfx(SFX_SPLASH_CHORD, 0.78f, 0.0f, 1.0f);

  Vec3 camPos = v3(0.0f, 6.0f, 34.0f);
  Vec3 camUp  = v3(0.0f, 1.0f, 0.0f);
  float camFov = 60.0f * PI_F / 180.0f;
  float prevViewProj[16];
  mat4_identity(prevViewProj);

  LARGE_INTEGER freq, tStart, tLast, tNow;
  QueryPerformanceFrequency(&freq);
  QueryPerformanceCounter(&tStart);
  tLast = tStart;

  int frameCount = 0, fpsFrames = 0;
  float fpsAccum = 0.0f;
  MSG msg;

  while (g_running) {
    while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE)) {
      if (msg.message == WM_QUIT) g_running = 0;
      TranslateMessage(&msg);
      DispatchMessageA(&msg);
    }
    if (!g_running) break;

    if (g_needResize) { rebuild_targets(); g_needResize = 0; }

    // Hide OS cursor during active flight (GPU reticle tracks cursor), show in menus/splash/pause
    set_cursor_hidden(g_windowFocused && g_gm.state == GS_PLAYING);

    QueryPerformanceCounter(&tNow);
    float dt = clampf((float)(tNow.QuadPart - tLast.QuadPart) / (float)freq.QuadPart, 0.001f, 0.05f);
    tLast = tNow;
    float elapsed = (float)(tNow.QuadPart - tStart.QuadPart) / (float)freq.QuadPart;

    if (g_keys[0xDB]) g_gfx.splitPos = clampf(g_gfx.splitPos - 0.45f * dt, 0.04f, 0.96f);
    if (g_keys[0xDD]) g_gfx.splitPos = clampf(g_gfx.splitPos + 0.45f * dt, 0.04f, 0.96f);

    update_game(dt, elapsed);

    fpsAccum += dt; fpsFrames++;
    if (fpsAccum >= 0.30f || frameCount < 2) {
      g_lastFps = (float)fpsFrames / (fpsAccum > 1e-4f ? fpsAccum : 0.016f);
      nvml_poll();
      const char *stStr =
        (g_gm.state == GS_SPLASH)   ? "DULA GAME STUDIOS PRESENTS" :
        (g_gm.state == GS_MENU)     ? "MAIN MENU" :
        (g_gm.state == GS_PAUSE)    ? "PAUSED" :
        (g_gm.state == GS_VICTORY)  ? "VICTORY" :
        (g_gm.state == GS_GAMEOVER) ? "SHIP LOST" :
        (g_gm.phase == 1)           ? "PHASE 1: INTERCEPTORS" :
        (g_gm.phase == 2)           ? "PHASE 2: SHIELD RELAYS" : "PHASE 3: SUPERLASER CORE";
      char nvBuf[96] = "";
      if (g_nvml.active) {
        snprintf(nvBuf, sizeof(nvBuf), " | %s %u%% %uMHz %uC",
          g_nvml.name[0] ? g_nvml.name : "RTX", g_nvml.gpuUtil, g_nvml.clkMHz, g_nvml.tempC);
      }
      char title[360];
      snprintf(title, sizeof(title),
        "STARFORGE: ECLIPSE COMMAND [DULA GAME STUDIOS] | %s | SCORE %d | %.0f FPS (GPU %.1fms)%s | %s",
        stStr, g_gm.score, g_lastFps, g_gpuMs, nvBuf, VSYNC_NAMES[g_gfx.vsyncMode]);
      SetWindowTextA(g_hwnd, title);
      fpsAccum = 0.0f; fpsFrames = 0;
    }

    // Dynamic Camera Framing
    Vec3 goalCamPos, camTarget, goalCamUp;
    float goalFov = (58.0f + g_pl.boostActive * 15.0f) * PI_F / 180.0f;
    if (g_gm.state == GS_SPLASH) {
      // Sweeping deep-space presentation shot facing the Ringed Gas Giant & Orbital Dreadnought
      float st = g_gm.splashTimer;
      goalCamPos = v3(-35.0f + st * 9.0f, 26.0f - st * 2.5f, 110.0f - st * 18.0f);
      camTarget  = v3(-95.0f + st * 18.0f, 48.0f, -260.0f);
      goalCamUp  = v3(0.08f, 1.0f, 0.0f);
      goalFov    = 54.0f * PI_F / 180.0f;
    } else if (g_gm.state == GS_MENU) {
      // Offset right-side hero framing so the X-Vanguard & Dreadnought shine cleanly beside the left menu!
      goalCamPos = v3_add(g_pl.pos, v3_add(v3_mul(g_pl.fwd, -12.5f),
                   v3_add(v3_mul(g_pl.up, 3.0f), v3_mul(g_pl.right, -4.8f))));
      camTarget  = v3_lerp(v3_add(g_pl.pos, v3_mul(g_pl.fwd, 42.0f)), get_dread_pos(), 0.22f);
      goalCamUp  = v3_norm(v3_add(g_pl.up, v3_mul(g_pl.right, 0.18f)));
    } else if (g_gfx.camMode == 2 && (g_gm.state == GS_PLAYING || g_gm.state == GS_PAUSE)) {
      goalCamPos = v3_add(g_pl.pos, v3_add(v3_mul(g_pl.up, 0.65f), v3_mul(g_pl.fwd, 0.35f)));
      camTarget  = v3_add(g_pl.pos, v3_mul(g_pl.fwd, 120.0f));
      goalCamUp  = g_pl.up;
      goalFov    = (70.0f + g_pl.boostActive * 12.0f) * PI_F / 180.0f;
    } else {
      float back = (g_gfx.camMode == 1) ? 8.8f : 12.2f;
      float lift = (g_gfx.camMode == 1) ? 2.4f : 3.2f;
      goalCamPos = v3_add(g_pl.pos, v3_add(v3_mul(g_pl.fwd, -(back + g_pl.boostActive * 2.2f)), v3_mul(g_pl.up, lift)));
      camTarget  = v3_add(g_pl.pos, v3_mul(g_pl.fwd, 75.0f));
      goalCamUp  = g_pl.up;
    }

    float camLerp = (g_gm.state == GS_SPLASH || (g_gfx.camMode == 2 && g_gm.state == GS_PLAYING)) ? 1.0f : (1.0f - expf(-dt * 9.5f));
    camPos = v3_lerp(camPos, goalCamPos, camLerp);
    camUp  = v3_norm(v3_lerp(camUp, goalCamUp, 1.0f - expf(-dt * 7.0f)));
    camFov = lerpf(camFov, goalFov, 1.0f - expf(-dt * 6.0f));

    Vec3 renderCamPos = camPos;
    if (g_pl.shake > 0.01f && g_gm.state == GS_PLAYING) {
      renderCamPos = v3_add(renderCamPos, v3(
        sinf(elapsed * 53.0f) * g_pl.shake * 0.42f,
        cosf(elapsed * 67.0f) * g_pl.shake * 0.42f,
        sinf(elapsed * 41.0f) * g_pl.shake * 0.22f));
    }

    float aspect = (float)g_renderW / (float)g_renderH;
    float viewM[16], projM[16], projJit[16], viewProj[16], viewProjJit[16], invViewProj[16];
    mat4_lookat(viewM, renderCamPos, camTarget, camUp);
    mat4_perspective(projM, camFov, aspect, 0.5f, 1800.0f);
    memcpy(projJit, projM, sizeof(projM));
    if (g_gfx.taa) {
      projJit[8] += (2.0f * g_halton[frameCount & 15][0]) / (float)g_renderW;
      projJit[9] += (2.0f * g_halton[frameCount & 15][1]) / (float)g_renderH;
    }
    mat4_mul(viewProj, projM, viewM);
    mat4_mul(viewProjJit, projJit, viewM);
    mat4_invert(invViewProj, viewProj);
    if (frameCount == 0) memcpy(prevViewProj, viewProj, sizeof(viewProj));

    Vec3 camFwd   = v3_norm(v3_sub(camTarget, renderCamPos));
    Vec3 sunDir   = v3_norm(v3(-0.76f, 0.44f, 0.48f));
    Vec3 dreadPos = get_dread_pos();
    Vec3 dishDir  = get_dish_dir();

    float sunScreen[3] = { 0.5f, 0.5f, 0.0f };
    {
      Vec3 sunFar = v3_add(renderCamPos, v3_mul(sunDir, 1200.0f));
      float suv[2];
      if (project_to_uv(viewProj, sunFar, suv, NULL)) {
        Vec3 oc = v3_sub(renderCamPos, dreadPos);
        float b = v3_dot(oc, sunDir), vis = 1.0f;
        if (b < 0.0f) {
          float d2 = v3_dot(oc, oc) - b * b;
          vis = smoothstep_c((sqrtf(fmaxf(d2, 0.0f)) - DREAD_RADIUS * 0.96f) / 14.0f);
        }
        float edgeFade = smoothstep_c(1.0f - fmaxf(fabsf(suv[0] - 0.5f), fabsf(suv[1] - 0.5f)) * 1.6f);
        sunScreen[0] = suv[0]; sunScreen[1] = suv[1]; sunScreen[2] = vis * edgeFade;
      }
    }

    float dynPos[8 * 4] = {0}, dynCol[8 * 4] = {0};
    int dynCnt = 0;
    for (int i = 0; i < MAX_EXPLOSIONS && dynCnt < 8; i++) {
      if (!g_expl[i].active) continue;
      float fade = 1.0f - (g_expl[i].age / g_expl[i].dur);
      dynPos[dynCnt*4+0] = g_expl[i].pos.x; dynPos[dynCnt*4+1] = g_expl[i].pos.y;
      dynPos[dynCnt*4+2] = g_expl[i].pos.z; dynPos[dynCnt*4+3] = g_expl[i].maxRad * 6.5f;
      if (g_expl[i].type == 1) { dynCol[dynCnt*4+0] = 5.0f*fade; dynCol[dynCnt*4+1] = 16.0f*fade; dynCol[dynCnt*4+2] = 26.0f*fade; }
      else { dynCol[dynCnt*4+0] = 30.0f*fade; dynCol[dynCnt*4+1] = 13.0f*fade; dynCol[dynCnt*4+2] = 3.0f*fade; }
      dynCnt++;
    }
    if (dynCnt < 8 && g_gm.state != GS_GAMEOVER && g_gm.state != GS_SPLASH) {
      Vec3 engP = v3_add(g_pl.pos, v3_mul(g_pl.fwd, -2.9f));
      dynPos[dynCnt*4+0] = engP.x; dynPos[dynCnt*4+1] = engP.y; dynPos[dynCnt*4+2] = engP.z; dynPos[dynCnt*4+3] = 24.0f;
      float bg = 0.85f + g_pl.boostActive * 1.4f;
      dynCol[dynCnt*4+0] = 9.0f*bg; dynCol[dynCnt*4+1] = 1.2f*bg; dynCol[dynCnt*4+2] = 4.2f*bg;
      dynCnt++;
    }

    if (pglBeginQuery && g_timerQuery[0]) {
      if (g_queryReady) {
        GLint avail = 0;
        pglGetQueryObjectiv(g_timerQuery[1 - g_queryIdx], GL_QUERY_RESULT_AVAILABLE, &avail);
        if (avail) {
          uint64_t ns = 0;
          pglGetQueryObjectui64v(g_timerQuery[1 - g_queryIdx], GL_QUERY_RESULT, &ns);
          g_gpuMs = lerpf(g_gpuMs, (float)ns * 1e-6f, g_gpuMs < 0.01f ? 1.0f : 0.25f);
        }
      }
      pglBeginQuery(GL_TIME_ELAPSED, g_timerQuery[g_queryIdx]);
    }

    // ========================================================================
    // PASS 1: OPAQUE HDR SCENE (RINGED PLANET SKYBOX + PBR FLEET & DREADNOUGHT)
    // ========================================================================
    pglBindFramebuffer(GL_FRAMEBUFFER, g_fboMain.fbo);
    glViewport(0, 0, g_renderW, g_renderH);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE);
    pglUseProgram(g_pSky.prog);
    pglUniformMatrix4fv(g_pSky.uInvViewProj, 1, GL_FALSE, invViewProj);
    pglUniform3fv(g_pSky.uCamPos, 1, &renderCamPos.x);
    pglUniform3fv(g_pSky.uCamFwd, 1, &camFwd.x);
    pglUniform3fv(g_pSky.uSunDir, 1, &sunDir.x);
    pglUniform1f(g_pSky.uTime, elapsed);
    pglUniform1f(g_pSky.uBoost, g_gm.state == GS_SPLASH ? 0.35f : g_pl.boostActive);
    pglBindVertexArray(g_emptyVAO);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDepthFunc(GL_LESS); glDisable(GL_BLEND);
    pglUseProgram(g_pMesh.prog);
    pglUniformMatrix4fv(g_pMesh.uViewProj, 1, GL_FALSE, viewProjJit);
    pglUniform3fv(g_pMesh.uCamPos, 1, &renderCamPos.x);
    pglUniform3fv(g_pMesh.uSunDir, 1, &sunDir.x);
    pglUniform3fv(g_pMesh.uDreadPos, 1, &dreadPos.x);
    pglUniform1f(g_pMesh.uDreadRad, DREAD_RADIUS);
    pglUniform3fv(g_pMesh.uDishDir, 1, &dishDir.x);
    pglUniform1f(g_pMesh.uTime, elapsed);
    pglUniform1i(g_pMesh.uDynLightCount, dynCnt);
    pglUniform4fv(g_pMesh.uDynLightPos, 8, dynPos);
    pglUniform4fv(g_pMesh.uDynLightCol, 8, dynCol);

    // Orbital Dreadnought
    {
      float dm[16]; mat4_translate(dm, dreadPos.x, dreadPos.y, dreadPos.z);
      draw_mesh(&g_meshDreadnought, dm, 1.0f, 0.0f, g_gm.phase == 3 ? (0.35f + g_gm.dishCharge * 1.4f) : 0.0f);
    }

    // 2 Imperial Escort Star Cruisers flanking the Dreadnought
    {
      Vec3 cPos[2] = { v3(-225.0f, -22.0f, -235.0f), v3(210.0f, 78.0f, -255.0f) };
      Vec3 cFwd[2] = { v3_norm(v3(0.45f, 0.08f, 0.89f)), v3_norm(v3(-0.38f, -0.10f, 0.92f)) };
      for (int c = 0; c < 2; c++) {
        Vec3 cf = cFwd[c], cu = v3(0.0f, 1.0f, 0.0f), cr;
        ortho_ship(&cf, &cu, &cr);
        float cm[16];
        mat4_from_ship(cm, cPos[c], cr, cu, cf, 4.2f);
        draw_mesh(&g_meshCruiser, cm, 1.35f, 0.0f, 0.0f);
      }
    }

    if (g_gm.state != GS_SPLASH) {
      for (int i = 0; i < MAX_RELAYS; i++) {
        if (!g_relays[i].alive) continue;
        float rm[16]; mat4_translate(rm, g_relays[i].pos.x, g_relays[i].pos.y, g_relays[i].pos.z);
        draw_mesh(&g_meshRelay, rm, g_gm.phase == 2 ? 1.7f : 0.55f, 0.0f, 0.0f);
      }
      if (g_gm.phase == 3 && g_gm.state != GS_VICTORY) {
        float cm[16], sm[16], fullM[16];
        mat4_translate(cm, g_gm.corePos.x, g_gm.corePos.y, g_gm.corePos.z);
        mat4_scale_xyz(sm, 1.9f, 1.9f, 1.9f);
        mat4_mul(fullM, cm, sm);
        draw_mesh(&g_meshRelay, fullM, 2.2f + g_gm.dishCharge * 2.2f, 0.0f, 0.0f);
      }
      {
        float fm[16]; mat4_from_ship(fm, g_gm.freighterPos, g_gm.freighterRight, g_gm.freighterUp, g_gm.freighterFwd, 2.2f);
        draw_mesh(&g_meshFreighter, fm, 1.25f, 0.0f, 0.0f);
      }
      if (g_gm.state != GS_GAMEOVER && !(g_gfx.camMode == 2 && (g_gm.state == GS_PLAYING || g_gm.state == GS_PAUSE))) {
        draw_xwing_ship(g_pl.pos, g_pl.right, g_pl.up, g_pl.fwd, g_pl.sFoilAnim, 0.95f + g_pl.boostActive * 1.15f, g_pl.shieldFlash);
      }
      for (int i = 0; i < MAX_ALLIES; i++) {
        draw_xwing_ship(g_allies[i].pos, g_allies[i].right, g_allies[i].up, g_allies[i].fwd, 1.0f, 1.0f, 0.0f);
      }
      for (int i = 0; i < MAX_ENEMIES; i++) {
        if (!g_enemies[i].alive) continue;
        float em[16];
        mat4_from_ship(em, g_enemies[i].pos, g_enemies[i].right, g_enemies[i].up, g_enemies[i].fwd, g_enemies[i].type == 1 ? 1.25f : 1.05f);
        draw_mesh(g_enemies[i].type == 1 ? &g_meshBomber : &g_meshTie, em, 1.0f, 0.0f, 0.0f);
      }
    }
    glDisable(GL_DEPTH_TEST);

    // ========================================================================
    // PASS 2: HALF-RES 8x4 NVIDIA COMPUTE — GOD-RAYS, EXPLOSIONS & SUPERLASER
    // ========================================================================
    float explPR[16 * 4] = {0}, explData[16 * 4] = {0};
    int explCnt = 0;
    if (g_gm.state != GS_SPLASH) {
      for (int i = 0; i < MAX_EXPLOSIONS; i++) {
        if (!g_expl[i].active) continue;
        float age01 = clampf(g_expl[i].age / g_expl[i].dur, 0.0f, 1.0f);
        float curRad = g_expl[i].maxRad * (0.28f + 0.72f * powf(age01, 0.42f));
        explPR[explCnt*4+0] = g_expl[i].pos.x; explPR[explCnt*4+1] = g_expl[i].pos.y;
        explPR[explCnt*4+2] = g_expl[i].pos.z; explPR[explCnt*4+3] = curRad;
        explData[explCnt*4+0] = age01;
        explData[explCnt*4+1] = (float)g_expl[i].type;
        explData[explCnt*4+2] = g_expl[i].seed;
        explCnt++;
      }
    }
    float beamStart[4] = { g_gm.corePos.x, g_gm.corePos.y, g_gm.corePos.z, 0.0f };
    Vec3 beamEndV = v3_add(g_gm.corePos, v3_mul(dishDir, 420.0f));
    float beamPow = (g_gm.phase == 3 && g_gm.state == GS_PLAYING) ? (0.15f + g_gm.dishCharge * 1.45f) : 0.0f;
    float beamEnd[4] = { beamEndV.x, beamEndV.y, beamEndV.z, beamPow };

    pglBindFramebuffer(GL_FRAMEBUFFER, 0);
    pglUseProgram(g_pVol.prog);
    bind_tex(0, g_fboMain.depthTex, g_pVol.uDepthTex);
    pglBindImageTexture(0, g_fboVol.tex, 0, GL_FALSE, 0, GL_WRITE_ONLY, GL_RGBA16F);
    pglUniform2i(g_pVol.uMainSize, g_renderW, g_renderH);
    pglUniform2i(g_pVol.uVolSize, g_fboVol.w, g_fboVol.h);
    pglUniformMatrix4fv(g_pVol.uInvViewProj, 1, GL_FALSE, invViewProj);
    pglUniform3fv(g_pVol.uCamPos, 1, &renderCamPos.x);
    pglUniform3fv(g_pVol.uDreadPos, 1, &dreadPos.x);
    pglUniform1f(g_pVol.uDreadRad, DREAD_RADIUS);
    pglUniform3fv(g_pVol.uSunDir, 1, &sunDir.x);
    pglUniform1f(g_pVol.uTime, elapsed);
    pglUniform1i(g_pVol.uFrame, frameCount);
    pglUniform1i(g_pVol.uExplCount, explCnt);
    pglUniform4fv(g_pVol.uExplPosRad, 16, explPR);
    pglUniform4fv(g_pVol.uExplData, 16, explData);
    pglUniform4fv(g_pVol.uBeamStart, 1, beamStart);
    pglUniform4fv(g_pVol.uBeamEnd, 1, beamEnd);
    pglDispatchCompute((GLuint)((g_fboVol.w + 7) / 8), (GLuint)((g_fboVol.h + 3) / 4), 1);
    pglMemoryBarrier(GL_TEXTURE_FETCH_BARRIER_BIT | GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);

    // ========================================================================
    // PASS 3A: DUAL-MRT OPAQUE TAA + BILATERAL VOLUMETRIC COMPOSITE
    // ========================================================================
    RenderTarget *taaRead  = &g_fboTAA[g_taaIdx];
    RenderTarget *taaWrite = &g_fboTAA[1 - g_taaIdx];
    pglBindFramebuffer(GL_FRAMEBUFFER, taaWrite->fbo);
    glViewport(0, 0, g_renderW, g_renderH);
    pglUseProgram(g_pTAA.prog);
    bind_tex(0, g_fboMain.tex,      g_pTAA.uCurrTex);
    bind_tex(1, g_fboMain.depthTex, g_pTAA.uDepthTex);
    bind_tex(2, g_fboVol.tex,       g_pTAA.uVolTex);
    bind_tex(3, taaRead->tex,       g_pTAA.uHistTex);
    pglUniform2f(g_pTAA.uResolution, (float)g_renderW, (float)g_renderH);
    pglUniform1i(g_pTAA.uEnableTAA, (g_gfx.taa && !g_resetHistory) ? 1 : 0);
    pglUniform1f(g_pTAA.uBlendFactor, g_resetHistory ? 0.0f : 0.72f);
    pglUniform3fv(g_pTAA.uCamPos, 1, &renderCamPos.x);
    pglUniformMatrix4fv(g_pTAA.uInvViewProj, 1, GL_FALSE, invViewProj);
    pglUniformMatrix4fv(g_pTAA.uPrevViewProj, 1, GL_FALSE, prevViewProj);
    pglBindVertexArray(g_emptyVAO);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    g_taaIdx = 1 - g_taaIdx;

    // ========================================================================
    // PASS 3B: POST-TAA DEPTH-TESTED ADDITIVE LASERS, ION PLUMES & 3D SPARKS
    // ========================================================================
    if (g_gm.state != GS_SPLASH) {
      pglBindFramebuffer(GL_FRAMEBUFFER, g_fboSceneFX);
      glViewport(0, 0, g_renderW, g_renderH);
      glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LESS); glDepthMask(GL_FALSE);
      glEnable(GL_BLEND); glBlendFunc(GL_ONE, GL_ONE);
      pglUseProgram(g_pFX.prog);
      pglUniformMatrix4fv(g_pFX.uViewProj, 1, GL_FALSE, viewProj);
      pglUniform3fv(g_pFX.uCamPos, 1, &renderCamPos.x);

      if (g_gm.state != GS_GAMEOVER && !(g_gfx.camMode == 2 && (g_gm.state == GS_PLAYING || g_gm.state == GS_PAUSE))) {
        draw_xwing_plumes(g_pl.pos, g_pl.right, g_pl.up, g_pl.fwd, g_pl.sFoilAnim, g_pl.boostActive, elapsed);
      }
      for (int i = 0; i < MAX_ALLIES; i++) {
        draw_xwing_plumes(g_allies[i].pos, g_allies[i].right, g_allies[i].up, g_allies[i].fwd, 1.0f, 0.20f, elapsed + i);
      }

      pglUniform1i(g_pFX.uIsPlume, 0);
      pglBindVertexArray(g_meshBeam.vao);
      for (int i = 0; i < MAX_LASERS; i++) {
        Projectile *p = &g_lasers[i];
        if (!p->active) continue;
        Vec3 bFwd = v3_norm(p->vel);
        Vec3 bUp  = (fabsf(bFwd.y) > 0.95f) ? v3(1.0f, 0.0f, 0.0f) : v3(0.0f, 1.0f, 0.0f);
        Vec3 bRight; ortho_ship(&bFwd, &bUp, &bRight);
        float bm[16], scM[16], fullM[16];
        mat4_from_ship(bm, p->pos, bRight, bUp, bFwd, 1.0f);
        float bRad = p->isTorp ? 0.45f : 0.19f, bLen = p->isTorp ? 3.4f : 6.4f;
        mat4_scale_xyz(scM, bRad, bRad, bLen);
        mat4_mul(fullM, bm, scM);
        pglUniformMatrix4fv(g_pFX.uModel, 1, GL_FALSE, fullM);
        pglUniform3fv(g_pFX.uCoreColor, 1, &p->colCore.x);
        pglUniform3fv(g_pFX.uEdgeColor, 1, &p->colEdge.x);
        pglUniform1f(g_pFX.uIntensity, p->isTorp ? 18.0f : 13.5f);
        glDrawArrays(GL_TRIANGLES, 0, g_meshBeam.vertCount);
      }
      for (int i = 0; i < MAX_SPARKS; i++) {
        Spark *sp = &g_sparks[i];
        if (!sp->active) continue;
        float fade = 1.0f - (sp->age / sp->dur);
        Vec3 sFwd = v3_norm(sp->vel);
        Vec3 sUp  = (fabsf(sFwd.y) > 0.95f) ? v3(1.0f, 0.0f, 0.0f) : v3(0.0f, 1.0f, 0.0f);
        Vec3 sRight; ortho_ship(&sFwd, &sUp, &sRight);
        float sm[16], scM[16], fullM[16];
        mat4_from_ship(sm, sp->pos, sRight, sUp, sFwd, 1.0f);
        mat4_scale_xyz(scM, 0.11f * fade + 0.03f, 0.11f * fade + 0.03f, 0.85f + v3_len(sp->vel) * 0.03f);
        mat4_mul(fullM, sm, scM);
        float coreW[3] = { 1.0f, 0.96f, 0.85f };
        pglUniformMatrix4fv(g_pFX.uModel, 1, GL_FALSE, fullM);
        pglUniform3fv(g_pFX.uCoreColor, 1, coreW);
        pglUniform3fv(g_pFX.uEdgeColor, 1, &sp->col.x);
        pglUniform1f(g_pFX.uIntensity, 14.0f * fade * fade);
        glDrawArrays(GL_TRIANGLES, 0, g_meshBeam.vertCount);
      }
      glDisable(GL_BLEND); glDisable(GL_DEPTH_TEST); glDepthMask(GL_TRUE);
    }

    // ========================================================================
    // PASS 4: SPACE-CALIBRATED 8x8 SHARED-MEMORY EYE ADAPTATION COMPUTE
    // ========================================================================
    RenderTarget *lumRead  = &g_fboLum[g_lumIdx];
    RenderTarget *lumWrite = &g_fboLum[1 - g_lumIdx];
    pglBindFramebuffer(GL_FRAMEBUFFER, 0);
    pglUseProgram(g_pAdapt.prog);
    bind_tex(0, g_fboSceneHDR.tex, g_pAdapt.uHdrTex);
    bind_tex(1, lumRead->tex,      g_pAdapt.uPrevLumTex);
    pglBindImageTexture(0, lumWrite->tex, 0, GL_FALSE, 0, GL_WRITE_ONLY, GL_RGBA16F);
    pglUniform1f(g_pAdapt.uDt, dt);
    pglUniform1i(g_pAdapt.uReset, g_resetAdapt ? 1 : 0);
    pglDispatchCompute(1, 1, 1);
    pglMemoryBarrier(GL_TEXTURE_FETCH_BARRIER_BIT | GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);
    g_lumIdx = 1 - g_lumIdx;
    RenderTarget *lumCurrent = &g_fboLum[g_lumIdx];

    // ========================================================================
    // PASS 5 & 6: KARIS HDR BLOOM & QUARTER-RES ANAMORPHIC LENS STREAKS
    // ========================================================================
    pglBindVertexArray(g_emptyVAO);
    int bW = g_fboBloom[0].w, bH = g_fboBloom[0].h;
    pglBindFramebuffer(GL_FRAMEBUFFER, g_fboBloom[0].fbo);
    glViewport(0, 0, bW, bH);
    pglUseProgram(g_pBright.prog);
    bind_tex(0, g_fboSceneHDR.tex, g_pBright.uHdrTex);
    pglUniform2f(g_pBright.uTexelSize, 1.0f / (float)g_renderW, 1.0f / (float)g_renderH);
    pglUniform1f(g_pBright.uThreshold, 1.45f);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    pglUseProgram(g_pBlur.prog);
    for (int p = 0; p < 2; p++) {
      pglBindFramebuffer(GL_FRAMEBUFFER, g_fboBloom[1].fbo);
      glViewport(0, 0, bW, bH);
      bind_tex(0, g_fboBloom[0].tex, g_pBlur.uTex);
      pglUniform2f(g_pBlur.uDir, (1.4f + (float)p * 0.9f) / (float)bW, 0.0f);
      glDrawArrays(GL_TRIANGLES, 0, 3);

      pglBindFramebuffer(GL_FRAMEBUFFER, g_fboBloom[0].fbo);
      glViewport(0, 0, bW, bH);
      bind_tex(0, g_fboBloom[1].tex, g_pBlur.uTex);
      pglUniform2f(g_pBlur.uDir, 0.0f, (1.4f + (float)p * 0.9f) / (float)bH);
      glDrawArrays(GL_TRIANGLES, 0, 3);
    }

    int sW = g_fboStreak[0].w, sH = g_fboStreak[0].h;
    pglBindFramebuffer(GL_FRAMEBUFFER, g_fboStreak[0].fbo);
    glViewport(0, 0, sW, sH);
    pglUseProgram(g_pBright.prog);
    bind_tex(0, g_fboSceneHDR.tex, g_pBright.uHdrTex);
    pglUniform2f(g_pBright.uTexelSize, 2.0f / (float)g_renderW, 2.0f / (float)g_renderH);
    pglUniform1f(g_pBright.uThreshold, 3.25f);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    pglUseProgram(g_pBlur.prog);
    for (int p = 0; p < 3; p++) {
      pglBindFramebuffer(GL_FRAMEBUFFER, g_fboStreak[1].fbo);
      glViewport(0, 0, sW, sH);
      bind_tex(0, g_fboStreak[0].tex, g_pBlur.uTex);
      pglUniform2f(g_pBlur.uDir, (2.4f + (float)p * 2.0f) / (float)sW, 0.0f);
      glDrawArrays(GL_TRIANGLES, 0, 3);

      pglBindFramebuffer(GL_FRAMEBUFFER, g_fboStreak[0].fbo);
      glViewport(0, 0, sW, sH);
      bind_tex(0, g_fboStreak[1].tex, g_pBlur.uTex);
      pglUniform2f(g_pBlur.uDir, (3.0f + (float)p * 2.4f) / (float)sW, 0.0f);
      glDrawArrays(GL_TRIANGLES, 0, 3);
    }

    // ========================================================================
    // PASS 7: FINAL OPTICAL FILTER, LENS FLARE, RCAS & DIEGETIC RETICLE
    // ========================================================================
    float lockPos[4] = {0, 0, 0, 0}, leadPos[4] = {0, 0, 0, 0};
    if (g_gm.state == GS_PLAYING && g_pl.lockType > 0) {
      Vec3 tPos = g_gm.corePos, tVel = v3(0, 0, 0); int ok = 0;
      if (g_pl.lockType == 1 && g_enemies[g_pl.lockIdx].alive) { tPos = g_enemies[g_pl.lockIdx].pos; tVel = g_enemies[g_pl.lockIdx].vel; ok = 1; }
      else if (g_pl.lockType == 2 && g_relays[g_pl.lockIdx].alive) { tPos = g_relays[g_pl.lockIdx].pos; ok = 1; }
      else if (g_pl.lockType == 3 && g_gm.phase == 3) { tPos = g_gm.corePos; ok = 1; }
      if (ok) {
        float uvT[2], uvL[2];
        if (project_to_uv(viewProj, tPos, uvT, NULL)) {
          lockPos[0] = uvT[0]; lockPos[1] = uvT[1]; lockPos[2] = g_pl.lockAmt; lockPos[3] = 1.0f;
          float dist = v3_len(v3_sub(tPos, g_pl.pos));
          if (project_to_uv(viewProj, v3_add(tPos, v3_mul(tVel, dist / 310.0f)), uvL, NULL)) {
            leadPos[0] = uvL[0]; leadPos[1] = uvL[1]; leadPos[2] = dist; leadPos[3] = 1.0f;
          }
        }
      }
    }

    float markers[16 * 4] = {0}; int mCnt = 0;
    if (g_gm.state == GS_PLAYING) {
      if (g_gm.phase == 2) {
        for (int i = 0; i < MAX_RELAYS && mCnt < 16; i++) {
          if (!g_relays[i].alive) continue;
          float uvM[2]; int on = project_to_uv(viewProj, g_relays[i].pos, uvM, NULL);
          markers[mCnt*4+0] = uvM[0]; markers[mCnt*4+1] = uvM[1]; markers[mCnt*4+2] = 2.0f; markers[mCnt*4+3] = (float)on;
          mCnt++;
        }
      } else if (g_gm.phase == 3) {
        float uvM[2]; int on = project_to_uv(viewProj, g_gm.corePos, uvM, NULL);
        markers[mCnt*4+0] = uvM[0]; markers[mCnt*4+1] = uvM[1]; markers[mCnt*4+2] = 2.0f; markers[mCnt*4+3] = (float)on;
        mCnt++;
      }
      for (int i = 0; i < MAX_ENEMIES && mCnt < 16; i++) {
        if (!g_enemies[i].alive) continue;
        float uvM[2]; int on = project_to_uv(viewProj, g_enemies[i].pos, uvM, NULL);
        markers[mCnt*4+0] = uvM[0]; markers[mCnt*4+1] = uvM[1];
        markers[mCnt*4+2] = (float)g_enemies[i].type; markers[mCnt*4+3] = (float)on;
        mCnt++;
      }
    }

    float bossProg = 1.0f;
    if (g_gm.phase == 1) bossProg = 1.0f - (float)g_gm.phaseKills / (float)(g_gm.phaseTarget > 0 ? g_gm.phaseTarget : 1);
    else if (g_gm.phase == 2) {
      int rAlive = 0; for (int i = 0; i < MAX_RELAYS; i++) if (g_relays[i].alive) rAlive++;
      bossProg = (float)rAlive / (float)MAX_RELAYS;
    } else bossProg = g_gm.coreHp / g_gm.coreMaxHp;

    float vitals[4] = { g_pl.hull / g_pl.maxHull, g_pl.shield / g_pl.maxShield, g_pl.laserCap, g_pl.boost };
    float meta[4]   = { bossProg, (float)g_pl.torpedoes, (float)g_gm.score, (float)g_gm.kills };

    pglBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, g_winW, g_winH);
    pglUseProgram(g_pComp.prog);
    bind_tex(0, g_fboSceneHDR.tex,  g_pComp.uHdrTex);
    bind_tex(1, g_fboBloom[0].tex,  g_pComp.uBloomTex);
    bind_tex(2, g_fboStreak[0].tex, g_pComp.uStreakTex);
    bind_tex(3, lumCurrent->tex,    g_pComp.uLumTex);
    pglUniform2f(g_pComp.uResolution, (float)g_winW, (float)g_winH);
    pglUniform1f(g_pComp.uTime, elapsed);
    pglUniform1i(g_pComp.uFilter, g_gfx.filter);
    pglUniform1i(g_pComp.uToneMap, g_gfx.toneMap);
    pglUniform1i(g_pComp.uAutoExp, g_gfx.autoExp);
    pglUniform1f(g_pComp.uExposureBias, g_gfx.exposure);
    pglUniform1f(g_pComp.uBoost, g_gm.state == GS_SPLASH ? 0.0f : g_pl.boostActive);
    pglUniform1f(g_pComp.uDamageFlash, g_pl.damageFlash);
    pglUniform1f(g_pComp.uHitFlash, g_pl.hitFlash);
    pglUniform3fv(g_pComp.uSunScreen, 1, sunScreen);
    pglUniform1i(g_pComp.uSplitEnabled, g_gfx.split);
    pglUniform1f(g_pComp.uSplitPos, g_gfx.splitPos);
    pglUniform1i(g_pComp.uGameState, g_gm.state);
    pglUniform1i(g_pComp.uMissionPhase, g_gm.phase);
    pglUniform2f(g_pComp.uAimUv, g_mouseUvX, g_mouseUvY);
    pglUniform4fv(g_pComp.uHudVitals, 1, vitals);
    pglUniform4fv(g_pComp.uHudMeta, 1, meta);
    pglUniform4fv(g_pComp.uLockPos, 1, lockPos);
    pglUniform4fv(g_pComp.uLeadPos, 1, leadPos);
    pglUniform1i(g_pComp.uMarkerCount, mCnt);
    pglUniform4fv(g_pComp.uMarkers, 16, markers);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    // ========================================================================
    // PASS 8: FULL-RES GPU 2D UI (DULA SPLASH, INTERACTIVE MENUS & HUD TEXT)
    // ========================================================================
    render_ui_pass(elapsed);

    if (pglEndQuery && g_timerQuery[0]) {
      pglEndQuery(GL_TIME_ELAPSED);
      g_queryIdx = 1 - g_queryIdx;
      g_queryReady = 1;
    }

    SwapBuffers(g_hdc);

    memcpy(prevViewProj, viewProj, sizeof(viewProj));
    g_resetHistory = 0;
    g_resetAdapt = 0;
    frameCount++;
  }

  set_cursor_hidden(0);
  ui_shutdown();
  destroy_all_meshes();
  if (g_fboSceneFX) pglDeleteFramebuffers(1, &g_fboSceneFX);
  destroy_target(&g_fboMain);
  destroy_target(&g_fboVol);
  destroy_target(&g_fboSceneHDR);
  destroy_target(&g_fboTAA[0]);
  destroy_target(&g_fboTAA[1]);
  destroy_target(&g_fboLum[0]);
  destroy_target(&g_fboLum[1]);
  destroy_target(&g_fboBloom[0]);
  destroy_target(&g_fboBloom[1]);
  destroy_target(&g_fboStreak[0]);
  destroy_target(&g_fboStreak[1]);

  wglMakeCurrent(NULL, NULL);
  wglDeleteContext(g_hrc);
  ReleaseDC(g_hwnd, g_hdc);
  if (g_hIconBig)   DestroyIcon(g_hIconBig);
  if (g_hIconSmall) DestroyIcon(g_hIconSmall);
  audio_shutdown();
  nvml_cleanup();
  return 0;
}
