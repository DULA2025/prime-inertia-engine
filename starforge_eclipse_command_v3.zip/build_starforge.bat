@echo off
title DULA GAME STUDIOS // STARFORGE: ECLIPSE COMMAND - Windows 11 Build
echo.
echo  DULA GAME STUDIOS - STARFORGE: ECLIPSE COMMAND V3.0
echo  (NVIDIA OpenGL 4.6 HDR Compute + GPU UI + WinMM Audio)
echo  ======================================================
echo.

where gcc >nul 2>&1
if %errorlevel%==0 (
  echo Found MinGW GCC.
  set RES_OBJ=
  where windres >nul 2>&1
  if %errorlevel%==0 (
    if exist starforge.rc (
      echo Embedding custom game icon via windres...
      windres starforge.rc -O coff -o starforge_res.o
      if exist starforge_res.o set RES_OBJ=starforge_res.o
    )
  )
  echo Compiling starforge.exe with -O3...
  gcc starforge_battle.c %RES_OBJ% -o starforge.exe -lopengl32 -lgdi32 -luser32 -lwinmm -lm -mwindows -O3
  if exist starforge_res.o del starforge_res.o >nul 2>&1
  if exist starforge.exe (
    echo.
    echo  SUCCESS: starforge.exe created with icon & Fullscreen HDR engine!
    echo  Launching STARFORGE: ECLIPSE COMMAND...
    echo.
    start starforge.exe
  ) else (
    echo Compile failed. Check errors above.
  )
  goto end
)

where cl >nul 2>&1
if %errorlevel%==0 (
  echo Found Visual Studio cl.
  set RES_FILE=
  where rc >nul 2>&1
  if %errorlevel%==0 (
    if exist starforge.rc (
      echo Embedding custom game icon via rc...
      rc /nologo starforge.rc
      if exist starforge.res set RES_FILE=starforge.res
    )
  )
  echo Compiling starforge.exe with /O2...
  cl starforge_battle.c %RES_FILE% /Fe:starforge.exe /O2 /link opengl32.lib gdi32.lib user32.lib winmm.lib
  if exist starforge.res del starforge.res >nul 2>&1
  if exist starforge.exe (
    echo.
    echo  SUCCESS: starforge.exe created!
    start starforge.exe
  ) else (
    echo Compile failed. Check errors above.
  )
  goto end
)

echo.
echo  No C compiler found in PATH.
echo  Install MinGW-w64 and add it to PATH, or run from a
echo  "Developer Command Prompt for VS".
echo.

:end
pause
