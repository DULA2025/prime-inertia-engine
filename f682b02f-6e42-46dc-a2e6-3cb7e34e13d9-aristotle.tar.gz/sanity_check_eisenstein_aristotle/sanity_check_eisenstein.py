#!/usr/bin/env python3
"""
sanity_check_eisenstein.py
==========================

Numerical sanity check for EisensteinIntegers.lean.

We verify each theorem stated in the Lean file by direct computation on
many random Eisenstein integers, both via the abstract (a, b) integer
representation AND via embedding into C.
"""

import numpy as np
import math
from itertools import product

# Eisenstein integers as (a, b) pairs representing a + b·ω.
# We define operations directly, matching the Lean implementation.

def add(z, w):
    return (z[0] + w[0], z[1] + w[1])

def neg(z):
    return (-z[0], -z[1])

def sub(z, w):
    return add(z, neg(w))

def mul(z, w):
    """(a + bω)(c + dω) = (ac - bd) + (ad + bc - bd)ω"""
    a, b = z
    c, d = w
    return (a*c - b*d, a*d + b*c - b*d)

def norm(z):
    """N(a + bω) = a² - ab + b²"""
    a, b = z
    return a*a - a*b + b*b

def conj(z):
    """bar(a + bω) = (a - b) + (-b)ω"""
    a, b = z
    return (a - b, -b)

def red_mod3(z):
    """a + bω ↦ (a + b) mod 3"""
    a, b = z
    return (a + b) % 3

# Embedding into C for cross-checking
omega_c = np.exp(2j * np.pi / 3)
def to_complex(z):
    return z[0] + z[1] * omega_c

# Test set
TEST_VALUES = [
    (0, 0), (1, 0), (0, 1), (-1, 0), (0, -1),
    (1, 1), (1, -1), (-1, 1), (-1, -1), (2, 3),
    (3, -2), (-4, 5), (7, 11), (-13, 17), (-100, 50),
]

# Useful named elements
ZERO = (0, 0)
ONE = (1, 0)
OMEGA = (0, 1)
THETA = (1, -1)

ok = True
print("=" * 70)
print(" Sanity check: EisensteinIntegers.lean")
print("=" * 70)

# === Check 1: Ring axioms (on a sample) ===
print("\nCheck 1: Ring axioms on a sample of triples")
fail = 0
for z in TEST_VALUES[:7]:
    for w in TEST_VALUES[:7]:
        for v in TEST_VALUES[:7]:
            # Associativity of +
            if add(add(z, w), v) != add(z, add(w, v)):
                fail += 1
            # Associativity of *
            if mul(mul(z, w), v) != mul(z, mul(w, v)):
                fail += 1
            # Left distributivity
            if mul(z, add(w, v)) != add(mul(z, w), mul(z, v)):
                fail += 1
print(f"  {7*7*7*3 - fail} of {7*7*7*3} ring axioms hold "
      f"{'✓' if fail == 0 else '✗'}")
if fail > 0: ok = False

# Commutativity
fail_comm = 0
for z in TEST_VALUES:
    for w in TEST_VALUES:
        if mul(z, w) != mul(w, z):
            fail_comm += 1
print(f"  Multiplication commutative: "
      f"{len(TEST_VALUES)**2 - fail_comm}/{len(TEST_VALUES)**2} "
      f"{'✓' if fail_comm == 0 else '✗'}")
if fail_comm > 0: ok = False

# === Check 2: ω² + ω + 1 = 0 ===
print("\nCheck 2: ω² + ω + 1 = 0")
result = add(add(mul(OMEGA, OMEGA), OMEGA), ONE)
print(f"  ω² + ω + 1 = {result} (should be {ZERO}) {'✓' if result == ZERO else '✗'}")
if result != ZERO: ok = False

# === Check 3: ω² = (-1, -1) ===
print("\nCheck 3: ω² = -1 - ω = (-1, -1)")
omega_sq = mul(OMEGA, OMEGA)
print(f"  ω² = {omega_sq} (should be (-1, -1)) {'✓' if omega_sq == (-1, -1) else '✗'}")
if omega_sq != (-1, -1): ok = False

# === Check 4: Norm formula ===
print("\nCheck 4: norm(a, b) = a² - ab + b²")
fail = 0
for z in TEST_VALUES:
    n_lean = norm(z)
    n_complex = abs(to_complex(z))**2
    if abs(n_lean - n_complex) > 1e-9:
        fail += 1
        print(f"  FAIL: norm({z}) = {n_lean}, but |z|² = {n_complex}")
print(f"  All {len(TEST_VALUES)} norm values match |z|² in ℂ "
      f"{'✓' if fail == 0 else '✗'}")
if fail > 0: ok = False

# === Check 5: Norm is multiplicative ===
print("\nCheck 5: norm(z·w) = norm(z)·norm(w)")
fail = 0
for z in TEST_VALUES:
    for w in TEST_VALUES:
        if norm(mul(z, w)) != norm(z) * norm(w):
            fail += 1
print(f"  {len(TEST_VALUES)**2 - fail}/{len(TEST_VALUES)**2} "
      f"{'✓' if fail == 0 else '✗'}")
if fail > 0: ok = False

# === Check 6: Norm non-negative ===
print("\nCheck 6: norm(z) ≥ 0 always")
fail = sum(1 for z in TEST_VALUES if norm(z) < 0)
print(f"  All {len(TEST_VALUES)} norms non-negative "
      f"{'✓' if fail == 0 else '✗'}")
if fail > 0: ok = False

# === Check 7: Conjugation ===
print("\nCheck 7: Conjugation properties")
# Involutive
fail_inv = sum(1 for z in TEST_VALUES if conj(conj(z)) != z)
print(f"  Involutive: {len(TEST_VALUES) - fail_inv}/{len(TEST_VALUES)} "
      f"{'✓' if fail_inv == 0 else '✗'}")
if fail_inv > 0: ok = False

# Additive
fail_add = sum(1 for z in TEST_VALUES for w in TEST_VALUES
               if conj(add(z, w)) != add(conj(z), conj(w)))
print(f"  Additive: {len(TEST_VALUES)**2 - fail_add}/{len(TEST_VALUES)**2} "
      f"{'✓' if fail_add == 0 else '✗'}")
if fail_add > 0: ok = False

# Multiplicative
fail_mul = sum(1 for z in TEST_VALUES for w in TEST_VALUES
               if conj(mul(z, w)) != mul(conj(z), conj(w)))
print(f"  Multiplicative: {len(TEST_VALUES)**2 - fail_mul}/{len(TEST_VALUES)**2} "
      f"{'✓' if fail_mul == 0 else '✗'}")
if fail_mul > 0: ok = False

# === Check 8: conj(z) * z = norm(z) ===
print("\nCheck 8: conj(z) · z = norm(z) (as Eisenstein integer)")
fail = 0
for z in TEST_VALUES:
    prod = mul(conj(z), z)
    expected = (norm(z), 0)
    if prod != expected:
        fail += 1
        print(f"  FAIL: conj({z})·{z} = {prod}, expected {expected}")
print(f"  {len(TEST_VALUES) - fail}/{len(TEST_VALUES)} "
      f"{'✓' if fail == 0 else '✗'}")
if fail > 0: ok = False

# === Check 9: θ = 1 - ω ===
print("\nCheck 9: θ = 1 - ω")
theta_via_sub = sub(ONE, OMEGA)
print(f"  1 - ω = {theta_via_sub} (should be {THETA}) "
      f"{'✓' if theta_via_sub == THETA else '✗'}")
if theta_via_sub != THETA: ok = False

# === Check 10: N(θ) = 3 ===
print("\nCheck 10: N(θ) = 3")
n_theta = norm(THETA)
print(f"  N(θ) = {n_theta} (should be 3) {'✓' if n_theta == 3 else '✗'}")
if n_theta != 3: ok = False

# === Check 11: redMod3 is well-defined map to F_3 ===
print("\nCheck 11: Reduction mod θ to F_3")
print(f"  redMod3(0) = {red_mod3(ZERO)} (should be 0) "
      f"{'✓' if red_mod3(ZERO) == 0 else '✗'}")
print(f"  redMod3(1) = {red_mod3(ONE)} (should be 1) "
      f"{'✓' if red_mod3(ONE) == 1 else '✗'}")
print(f"  redMod3(ω) = {red_mod3(OMEGA)} (should be 1) "
      f"{'✓' if red_mod3(OMEGA) == 1 else '✗'}")
print(f"  redMod3(θ) = {red_mod3(THETA)} (should be 0) "
      f"{'✓' if red_mod3(THETA) == 0 else '✗'}")
if red_mod3(THETA) != 0: ok = False

# === Check 12: redMod3 is a ring hom ===
print("\nCheck 12: redMod3 is a ring homomorphism")
fail_add = 0
fail_mul = 0
for z in TEST_VALUES:
    for w in TEST_VALUES:
        if red_mod3(add(z, w)) != (red_mod3(z) + red_mod3(w)) % 3:
            fail_add += 1
        if red_mod3(mul(z, w)) != (red_mod3(z) * red_mod3(w)) % 3:
            fail_mul += 1
print(f"  Additive: {len(TEST_VALUES)**2 - fail_add}/{len(TEST_VALUES)**2} "
      f"{'✓' if fail_add == 0 else '✗'}")
print(f"  Multiplicative: {len(TEST_VALUES)**2 - fail_mul}/{len(TEST_VALUES)**2} "
      f"{'✓' if fail_mul == 0 else '✗'}")
if fail_add > 0 or fail_mul > 0: ok = False

# === Check 13: redMod3 is surjective ===
print("\nCheck 13: redMod3 is surjective (hits all of {0, 1, 2})")
witnesses = {0: ZERO, 1: ONE, 2: (-1, 0)}
hits = {red_mod3(witnesses[i]) for i in [0, 1, 2]}
print(f"  redMod3(0) = {red_mod3(ZERO)}: {'✓' if red_mod3(ZERO) == 0 else '✗'}")
print(f"  redMod3(1) = {red_mod3(ONE)}: {'✓' if red_mod3(ONE) == 1 else '✗'}")
print(f"  redMod3(-1) = {red_mod3((-1, 0))}: "
      f"{'✓' if red_mod3((-1, 0)) == 2 else '✗'}")
if hits != {0, 1, 2}: ok = False

# === Check 14: kernel of redMod3 contains (θ) ===
print("\nCheck 14: All multiples of θ are in ker(redMod3)")
fail = 0
for z in TEST_VALUES:
    multiple = mul(z, THETA)
    if red_mod3(multiple) != 0:
        fail += 1
print(f"  {len(TEST_VALUES) - fail}/{len(TEST_VALUES)} multiples of θ map to 0 "
      f"{'✓' if fail == 0 else '✗'}")
if fail > 0: ok = False

# === Check 15: Six units in Eisenstein integers ===
print("\nCheck 15: The six units of Z[ω]")
# Units: ±1, ±ω, ±ω² (i.e., (1,0), (-1,0), (0,1), (0,-1), (-1,-1), (1,1))
unit_candidates = [(1, 0), (-1, 0), (0, 1), (0, -1), (-1, -1), (1, 1)]
print("  Element  | Norm")
print("  ---------|-----")
for u in unit_candidates:
    n = norm(u)
    status = '✓' if n == 1 else '✗'
    print(f"  {str(u):8} | {n}  {status}")
fail = sum(1 for u in unit_candidates if norm(u) != 1)
if fail > 0: ok = False

# === Final ===
print()
print("=" * 70)
if ok:
    print(" ✓ All checks pass — EisensteinIntegers.lean math verified")
else:
    print(" ✗ Some checks failed")
print("=" * 70)
