"""Evaluation of the odd Fourier series and its gradient at one point, with a
rigorous bound on the float64 error.

    f~(x+iy)  = sum_{n=1}^M c_n W_n(y) (e(nx) - e(-nx)) = 2i S0
    f~*(x+iy) = 2i conj(S0)                    (W_n, sin, cos are real)
    d/dx f~   = 2i S1,   d/dy f~ = 2i S2,  and conjugates for f~*

    S0 = sum c_n W_n sin(2 pi n x),  S1 = sum c_n k_n W_n cos(2 pi n x),
    S2 = sum c_n W'_n sin(2 pi n x), W_n = sqrt(y) K_0(k_n y),
    W'_n = K_0/(2 sqrt y) - k_n sqrt(y) K_1,  k_n = 2 pi n.

The abscissa is a double-double X = X_hi + X_lo: the phase n X is reduced mod 1
in double-double, so the phase error is <= 10 eps for every n, however large n X
is.  (In plain float64, at n = 10^4 and X ~ 0.5 the phase alone would carry
~5e-12 of error.)
"""
import numpy as np
from kb_fast import k01, k0_up, k1_up, XMAX, EPS

TWO_PI = 2.0 * np.pi
SPLIT = 134217729.0


def _two_prod(a, b):
    p = a * b
    c = SPLIT * a
    ah = c - (c - a)
    al = a - ah
    c = SPLIT * b
    bh = c - (c - b)
    bl = b - bh
    err = ((ah * bh - p) + ah * bl + al * bh) + al * bl
    return p, err


def reduced_phase(n, X_hi, X_lo):
    """frac(n X) in [-1/2, 1/2], absolute error <= 2^-54 (1 + tiny)."""
    p, e = _two_prod(n, X_hi)
    e = e + n * X_lo
    u = p - np.rint(p)            # exact
    return u + e


class OddSeries:
    def __init__(self, c):
        """c: complex array, c[k] = c_{k+1}, k = 0..M-1 (f~ is odd)."""
        self.c = np.asarray(c, dtype=np.complex128)
        self.M = len(self.c)
        self.n = np.arange(1, self.M + 1, dtype=np.float64)
        self.k = TWO_PI * self.n
        self.ac = np.abs(self.c)
        self.log2M = np.ceil(np.log2(self.M)) + 2

    def eval(self, X_hi, X_lo, y):
        """Return dict with S0, S1, S2 (complex), their error bounds e0, e1, e2,
        and crude magnitudes A0 = sum|c||W|, A1 = sum|c| k|W|, A2 = sum|c||W'|,
        B = sum|c| (k^2|W| + 2k|W'| + |W''|)  (second-derivative scale)."""
        k = self.k
        xarg = k * y
        live = xarg <= XMAX
        nl = int(np.count_nonzero(live))           # xarg increasing in n
        sy = np.sqrt(y)
        K0, K1, a0, a1, rel = k01(xarg[:nl])
        # argument rounding: xarg = fl(fl(2pi n) y) carries 3 eps relative
        rel_arg = 3.0 * EPS * (xarg[:nl] + 1.0)
        eK0 = a0 + K0 * (rel + rel_arg)
        eK1 = a1 + K1 * (rel + rel_arg)
        W = sy * K0
        Wp = K0 / (2.0 * sy) - k[:nl] * sy * K1
        eW = sy * eK0 + 3.0 * EPS * W
        eWp = eK0 / (2.0 * sy) + k[:nl] * sy * eK1 + 6.0 * EPS * (K0 / (2.0 * sy) + k[:nl] * sy * K1)
        th = TWO_PI * reduced_phase(self.n[:nl], X_hi, X_lo)
        s = np.sin(th)
        co = np.cos(th)
        eph = 10.0 * EPS                          # |computed sin/cos - exact|
        c = self.c[:nl]
        ac = self.ac[:nl]
        aW = np.abs(W)
        aWp = np.abs(Wp)
        S0 = np.sum(c * (W * s))
        S1 = np.sum(c * (k[:nl] * W * co))
        S2 = np.sum(c * (Wp * s))
        A0 = float(np.sum(ac * aW))
        A1 = float(np.sum(ac * k[:nl] * aW))
        A2 = float(np.sum(ac * aWp))
        srel = 2.0 * self.log2M * EPS + 8.0 * EPS    # products + pairwise complex sum
        e0 = float(np.sum(ac * (eW + aW * eph))) + srel * A0
        e1 = float(np.sum(ac * k[:nl] * (eW + aW * eph))) + srel * A1
        e2 = float(np.sum(ac * (eWp + aWp * eph))) + srel * A2
        cW2 = k[:nl] ** 2 + 1.0 / (4.0 * y * y)
        B = float(np.sum(ac * (k[:nl] ** 2 * aW + 2.0 * k[:nl] * aWp + cW2 * aW)))
        if nl < self.M:
            # rigorous tail: W_n <= sqrt(y) K_{1/2}, |W'| <= K_0/(2 sqrt y) + k sqrt(y) K_1
            kt = k[nl:]
            xt = xarg[nl:]
            act = self.ac[nl:]
            with np.errstate(under='ignore'):
                t0 = sy * k0_up(xt)
                t2 = k0_up(xt) / (2.0 * sy) + kt * sy * k1_up(xt)
            tail0 = float(np.sum(act * t0))
            tail1 = float(np.sum(act * kt * t0))
            tail2 = float(np.sum(act * t2))
            e0 += tail0
            e1 += tail1
            e2 += tail2
            A0 += tail0
            A1 += tail1
            A2 += tail2
            B += float(np.sum(act * (kt ** 2 * t0 * 2 + 2 * kt * t2 + t0 / (4 * y * y))))
        return dict(S0=S0, S1=S1, S2=S2, e0=e0, e1=e1, e2=e2, A0=A0, A1=A1, A2=A2, B=B)

    def ellipse_bound(self, Ymin, ymax_abs, sinb, cosb):
        """Upper bounds on |f~| and on |grad f~| (|d_x| + |d_y|) over complexified
        points (x, y) with Re y >= Ymin, |y| <= ymax_abs, |Im x| <= sinb * Re y.

        Uses |K_nu(w)| <= K_nu(Re w), K_nu(v) e^{v sinb} decreasing in v, and
        the K_{1/2}, K_{3/2} majorants."""
        k = self.k
        v = k * Ymin
        with np.errstate(under='ignore', over='ignore'):
            g = np.exp(v * sinb)
            b0 = k0_up(v) * g
            b1 = k1_up(v) * g
        sq = np.sqrt(ymax_abs)
        F = 2.0 * sq * float(np.sum(self.ac * b0))
        Dx = 2.0 * sq * float(np.sum(self.ac * k * b0))
        Dy = 2.0 * float(np.sum(self.ac * (b0 / (2.0 * np.sqrt(Ymin)) + k * sq * b1)))
        return F, Dx + Dy


if __name__ == "__main__":
    import mpmath as mp
    import sys
    sys.path.insert(0, "..")
    from measure_dd_defect import load_coeffs
    mp.mp.dps = 30
    C, Mf = load_coeffs(None, sys.argv[1])
    M = 400
    c = np.array([(C[n] - C[-n]) / 2 for n in range(1, M + 1)])
    ser = OddSeries(c)
    rng = np.random.default_rng(5)
    worst = 0.0
    for trial in range(6):
        X = mp.mpf(rng.uniform(-0.5, 0.5)) + mp.mpf(rng.uniform(-1, 1)) * mp.mpf(10) ** -18
        X_hi = float(X)
        X_lo = float(X - X_hi)
        y = float(rng.choice([2e-3, 5e-3, 0.02, 0.1]))
        r = ser.eval(X_hi, X_lo, y)
        Xe = mp.mpf(X_hi) + mp.mpf(X_lo)
        S0 = S1 = S2 = mp.mpc(0)
        for n in range(1, M + 1):
            kk = 2 * mp.pi * n
            Wn = mp.sqrt(y) * mp.besselk(0, kk * y)
            Wpn = mp.besselk(0, kk * y) / (2 * mp.sqrt(y)) - kk * mp.sqrt(y) * mp.besselk(1, kk * y)
            cn = mp.mpc(c[n - 1].real, c[n - 1].imag)
            S0 += cn * Wn * mp.sin(kk * Xe)
            S1 += cn * kk * Wn * mp.cos(kk * Xe)
            S2 += cn * Wpn * mp.sin(kk * Xe)
        d0 = float(abs(S0 - mp.mpc(r['S0'].real, r['S0'].imag)))
        d1 = float(abs(S1 - mp.mpc(r['S1'].real, r['S1'].imag)))
        d2 = float(abs(S2 - mp.mpc(r['S2'].real, r['S2'].imag)))
        worst = max(worst, d0 / r['e0'], d1 / r['e1'], d2 / r['e2'])
        print("y=%-6g  S0 err %.1e / %.1e   S1 err %.1e / %.1e   S2 err %.1e / %.1e"
              % (y, d0, r['e0'], d1, r['e1'], d2, r['e2']))
    print("worst error / bound = %.3f" % worst)
