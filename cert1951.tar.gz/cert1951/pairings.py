"""Side pairings, vertex cycles, angles and vertex fans of the Ford domain of
Gamma_0(N)^+ (N prime), from the exact side list written by ford_domain.py.

Group elements are stored exactly as (M, w): M an integer 2x2 matrix and
w in {0, 1}; the element is M if w = 0 (Gamma_0(N), det M = 1) and M/sqrt(N)
if w = 1 (Atkin-Lehner coset, det M = N).  Products of two w = 1 elements are
divided by N, which is exact.
"""
import pickle
import sys
from fractions import Fraction as Fr
from math import gcd
import mpmath as mp

mp.mp.dps = 40
N = 1951


# ------------------------------------------------------------ group elements
def mul(A, B):
    (M1, w1), (M2, w2) = A, B
    (a, b), (c, d) = M1
    (e, f), (g, h) = M2
    P = [[a * e + b * g, a * f + b * h], [c * e + d * g, c * f + d * h]]
    w = w1 ^ w2
    if w1 and w2:
        assert all(x % N == 0 for row in P for x in row)
        P = [[x // N for x in row] for row in P]
    # normalise sign: first nonzero of bottom row positive
    if P[1][0] < 0 or (P[1][0] == 0 and P[1][1] < 0):
        P = [[-x for x in row] for row in P]
    return (P, w)


def inv(A):
    (M, w) = A
    (a, b), (c, d) = M
    P = [[d, -b], [-c, a]]
    if P[1][0] < 0 or (P[1][0] == 0 and P[1][1] < 0):
        P = [[-x for x in row] for row in P]
    return (P, w)


def is_identity(A):
    (M, w) = A
    return w == 0 and M[1][0] == 0 and M[0][1] == 0 and abs(M[0][0]) == 1


def act(A, z):
    (M, w) = A
    (a, b), (c, d) = M
    return (a * z + b) / (c * z + d)


def T(k):
    return ([[1, k], [0, 1]], 0)


# ---------------------------------------------------------------- the sides
def load():
    raw = pickle.load(open("sides_%d.pkl" % N, "rb"))
    sides = []
    for (ctr, r2, tag, xl, xr) in raw:
        a, r = mp.mpf(ctr.numerator) / ctr.denominator, mp.sqrt(mp.mpf(r2.numerator) / r2.denominator)
        yl = mp.sqrt(mp.mpf((r2 - (xl - ctr) ** 2).numerator) / (r2 - (xl - ctr) ** 2).denominator)
        yr = mp.sqrt(mp.mpf((r2 - (xr - ctr) ** 2).numerator) / (r2 - (xr - ctr) ** 2).denominator)
        zl = mp.mpc(mp.mpf(xl.numerator) / xl.denominator, yl)
        zr = mp.mpc(mp.mpf(xr.numerator) / xr.denominator, yr)
        sides.append(dict(kind=tag[0], u=tag[1], v=tag[2], a=a, r=r, zl=zl, zr=zr,
                          ctr=ctr, r2=r2, xl=xl, xr=xr))
    return sides


def element_for(s):
    """The element g with isometric circle = the circle of side s."""
    u, v = s['u'], s['v']
    if s['kind'] == 'W':
        c, d = v, -u                      # centre -d/c = u/v
        dN = d * N
        a = pow(dN % c, -1, c) if c > 1 else 0
        b = (a * dN - 1) // c
        assert a * dN - b * c == 1
        return ([[a * N, b], [c * N, dN]], 1)
    else:
        c, d = v, -u                      # v = N c'
        a = pow(d % c, -1, c)
        b = (a * d - 1) // c
        assert a * d - b * c == 1
        return ([[a, b], [c, d]], 0)


def close(z, w, tol=mp.mpf(10) ** -25):
    return abs(z - w) < tol


def pair_sides(sides):
    """For each side find g (up to translation) mapping it onto another side."""
    out = []
    for i, s in enumerate(sides):
        g = element_for(s)
        zl, zr = act(g, s['zl']), act(g, s['zr'])
        # translate so the image lies in [-1/2, 1/2]
        mid = (zl.real + zr.real) / 2
        k = -int(mp.floor(mid + mp.mpf(1) / 2))
        gk = mul(T(k), g)
        zl, zr = act(gk, s['zl']), act(gk, s['zr'])
        match = None
        for j, t in enumerate(sides):
            if (close(zl, t['zl']) and close(zr, t['zr'])) or (close(zl, t['zr']) and close(zr, t['zl'])):
                match = j
                break
        if match is None:
            raise RuntimeError("side %d (%s %d/%d) has no partner" % (i, s['kind'], s['u'], s['v']))
        out.append((gk, match))
    return out


# ----------------------------------------------------------------- angles
def tangent_dir(s, z, toward):
    """unit tangent (as complex) of side s at its endpoint z, pointing along
    the side toward the point `toward`."""
    a = s['a']
    t = mp.mpc(0, 1) * (z - a)            # tangent to the circle at z
    t = t / abs(t)
    if mp.re(mp.conj(t) * (toward - z)) < 0:
        t = -t
    return t


def interior_angle(t1, t2):
    return abs(mp.arg(t2 / t1))


def main():
    sides = load()
    n = len(sides)
    pairs = pair_sides(sides)
    # vertices: v_0 = left corner, v_i = right end of side i-1 = left end of side i
    verts = [sides[0]['zl']] + [sides[i]['zr'] for i in range(n)]
    nv = len(verts)
    # the sides of F+ at vertex i: (side index or 'VL'/'VR', ...)
    #   vertex 0      : VL (vertical x=-1/2) and floor side 0
    #   vertex i      : floor side i-1 and floor side i
    #   vertex n      : floor side n-1 and VR
    def sides_at(i):
        if i == 0:
            return ('VL', 0)
        if i == n:
            return (n - 1, 'VR')
        return (i - 1, i)

    def g_of(sidx):
        if sidx == 'VL':
            return T(1), 'VR'
        if sidx == 'VR':
            return T(-1), 'VL'
        g, j = pairs[sidx]
        return g, j

    def vertex_index(z):
        for i, w in enumerate(verts):
            if close(z, w):
                return i
        return None

    def angle_at(i):
        sa, sb = sides_at(i)
        z = verts[i]
        up = z + mp.mpc(0, 1)
        dirs = []
        for sidx in (sa, sb):
            if sidx in ('VL', 'VR'):
                dirs.append(mp.mpc(0, 1))
            else:
                s = sides[sidx]
                other = s['zr'] if close(z, s['zl']) else s['zl']
                dirs.append(tangent_dir(s, z, other))
        return interior_angle(dirs[0], dirs[1])

    angles = [angle_at(i) for i in range(nv)]

    # vertex fans
    fans = []
    for i0 in range(nv):
        h = ([[1, 0], [0, 1]], 0)
        i = i0
        sa, sb = sides_at(i)
        cross = sb
        tiles = []
        total = mp.mpf(0)
        for step in range(10000):
            total += angles[i]
            g, partner = g_of(cross)
            h = mul(g, h)
            j = vertex_index(act(h, verts[i0]))
            assert j is not None, "fan walk left the vertex set"
            if is_identity(h):
                assert j == i0
                break
            tiles.append((h, j))
            # the side we entered through, in F+ coordinates, is `partner`;
            # continue across the OTHER side at vertex j
            s1, s2 = sides_at(j)
            cross = s2 if s1 == partner else s1
            i = j
        fans.append(dict(vertex=i0, tiles=tiles, angle_sum=total))
    bad = [f for f in fans if abs(f['angle_sum'] - 2 * mp.pi) > mp.mpf(10) ** -20]
    print("sides %d, vertices %d (corners identified by T)" % (n, nv))
    print("every side has a partner: yes")
    print("fan angle sums equal to 2 pi: %d of %d%s"
          % (nv - len(bad), nv, "" if not bad else "   <-- CHECK"))
    sizes = sorted(len(f['tiles']) + 1 for f in fans)
    print("tiles around a vertex: min %d, max %d" % (sizes[0], sizes[-1]))
    amin = min(angles)
    print("smallest interior angle: %.6f rad (%.3f deg)" % (float(amin), float(amin) * 180 / float(mp.pi)))
    self_paired = sum(1 for k, (g, j) in enumerate(pairs) if j == k)
    print("self-paired sides (elliptic of order 2 on the side): %d" % self_paired)
    pickle.dump(dict(pairs=[(g, j) for (g, j) in pairs], fans=[(f['vertex'], f['tiles']) for f in fans],
                     angles=[float(a) for a in angles],
                     verts=[(float(z.real), float(z.imag)) for z in verts]),
                open("pairings_%d.pkl" % N, "wb"))
    print("wrote pairings_%d.pkl" % N)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        N = int(sys.argv[1])
    main()
