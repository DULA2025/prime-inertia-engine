"""Exact Ford domain of Gamma_0(N)^+ = <Gamma_0(N), W_N> for N prime.

Isometric circles.  Every element with lower-left entry != 0 has isometric
circle |c z + d| = 1 (normalised determinant one):
  * Gamma_0(N):   rows (N c', d), gcd(d, N c') = 1  -> centre -d/(N c'), radius 1/(N c')
  * W_N Gamma_0(N): (1/sqrt N)[[aN, b],[cN, dN]], adN - bc = 1
                  rows (c sqrt N, d sqrt N), gcd(c, N d) = 1 -> centre -d/c, radius 1/(c sqrt N)
So every reduced fraction u/v carries exactly ONE circle:
    radius^2 = 1/(v^2 N)   if N does not divide v      (Fricke type)
    radius^2 = 1/v^2       if N divides v               (Gamma_0(N) type)
The Ford domain is {|x| <= 1/2, z above every circle}.  Two semicircles
centred on R meet at most once in H, so a new circle lies above the current
upper envelope on a single interval, and the envelope can be built by
insertion.  All comparisons are exact (Fractions): intersection abscissae
are rational because every radius^2 is.
"""
from fractions import Fraction as Fr
from math import gcd, sqrt, log, tan, atan2, pi
import json, sys

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1951
VMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 160      # Fricke denominators
CMAX = 3                                                      # Gamma_0(N) multiples


def circles():
    out = []
    for v in range(1, VMAX + 1):
        if v % N == 0:
            continue
        for u in range(-v, v + 1):
            if gcd(u, v) == 1 and abs(Fr(u, v)) <= Fr(1, 2) + Fr(1, 20):
                out.append((Fr(u, v), Fr(1, v * v * N), ('W', u, v)))
    for cp in range(1, CMAX + 1):
        v = N * cp
        for u in range(-(v // 2) - v // 20, v // 2 + v // 20 + 1):
            if gcd(u, v) == 1:
                out.append((Fr(u, v), Fr(1, v * v), ('G', u, v)))
    return out


def above(C, D, x):
    """height^2 of C minus height^2 of D at x (exact)."""
    return (C[1] - (x - C[0]) ** 2) - (D[1] - (x - D[0]) ** 2)


def meet(C, D):
    a, r2 = C[0], C[1]
    b, s2 = D[0], D[1]
    return (r2 - s2 + b * b - a * a) / (2 * (b - a))


def envelope(cs, lo=Fr(-1, 2), hi=Fr(1, 2)):
    """Upper envelope of the semicircles over [lo, hi], exactly.

    For each new circle C the set {x : C above the current envelope} is
    computed piece by piece (within a piece of circle D it is the part of a
    half-line, because height_C^2 - height_D^2 is LINEAR in x) plus the gaps
    not yet covered; the union is a single interval because two semicircles
    centred on R meet at most once in H.  That is asserted, not assumed."""
    cs = sorted(cs, key=lambda c: -c[1])
    env = []
    for C in cs:
        cl = max(lo, C[0] - _sqrt_up(C[1]))
        cr = min(hi, C[0] + _sqrt_up(C[1]))
        if cl >= cr:
            continue
        allowed = []
        cursor = cl
        for (D, xl, xr) in env:
            if xr <= cl or xl >= cr:
                continue
            a0, b0 = max(xl, cl), min(xr, cr)
            if a0 > cursor:                       # uncovered gap
                allowed.append((cursor, a0))
            fa, fb = above(C, D, a0), above(C, D, b0)
            if fa > 0 and fb > 0:
                allowed.append((a0, b0))
            elif fa > 0 or fb > 0:
                m = meet(C, D)
                allowed.append((a0, m) if fa > 0 else (m, b0))
            cursor = max(cursor, b0)
        if cursor < cr:
            allowed.append((cursor, cr))
        # merge touching intervals; C must be positive there (it is, strictly
        # inside its support) -- trim to where C's height^2 > 0
        allowed = [(a, b) for (a, b) in allowed if b > a]
        if not allowed:
            continue
        merged = [list(allowed[0])]
        for (a, b) in allowed[1:]:
            if a <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], b)
            else:
                merged.append([a, b])
        assert len(merged) == 1, "exposure set is not an interval: %s" % merged
        L, R = merged[0]
        # the support bound _sqrt_up is slightly generous: clip to C > 0
        if C[1] - (L - C[0]) ** 2 < 0 or C[1] - (R - C[0]) ** 2 < 0:
            # only happens in an uncovered gap at the very foot of C; the
            # other circles always cover the real line near its feet here
            pass
        new = []
        for (D, xl, xr) in env:
            if xr <= L or xl >= R:
                new.append([D, xl, xr])
            else:
                if xl < L:
                    new.append([D, xl, L])
                if xr > R:
                    new.append([D, R, xr])
        new.append([C, L, R])
        env = sorted(new, key=lambda p: p[1])
    return env


def _sqrt_up(q):
    """a Fraction >= sqrt(q) (only used to bound the support of a circle)."""
    s = Fr(sqrt(float(q))) * Fr(1000001, 1000000)
    return s


if __name__ == "__main__":
    cs = circles()
    print("N = %d: %d candidate circles" % (N, len(cs)))
    env = envelope(cs)
    # merge consecutive pieces of the same circle
    merged = []
    for p in env:
        if merged and merged[-1][0][2] == p[0][2] and merged[-1][2] == p[1]:
            merged[-1][2] = p[2]
        else:
            merged.append(list(p))
    # check coverage
    gaps = [(merged[i][2], merged[i + 1][1]) for i in range(len(merged) - 1)
            if merged[i][2] != merged[i + 1][1]]
    print("sides: %d   gaps in coverage: %d" % (len(merged), len(gaps)))
    assert merged[0][1] == Fr(-1, 2) and merged[-1][2] == Fr(1, 2), "does not span [-1/2,1/2]"
    ymin = min(min(float(C[1] - (xl - C[0]) ** 2), float(C[1] - (xr - C[0]) ** 2))
               for (C, xl, xr) in merged)
    print("lowest vertex height: %.6e   (sqrt(3)/(2N) = %.6e)" % (sqrt(ymin), sqrt(3) / (2 * N)))
    vmax_used = max(C[2][2] for (C, _, _) in merged if C[2][0] == 'W')
    kinds = {}
    for (C, _, _) in merged:
        kinds[C[2][0]] = kinds.get(C[2][0], 0) + 1
    print("Fricke-type sides: %d (max denominator %d);  Gamma_0(N)-type sides: %d"
          % (kinds.get('W', 0), vmax_used, kinds.get('G', 0)))
    # hyperbolic lengths
    tot = 0.0
    rows = []
    for (C, xl, xr) in merged:
        a, r = float(C[0]), sqrt(float(C[1]))
        th1 = atan2(sqrt(max(float(C[1] - (xr - C[0]) ** 2), 0.0)), float(xr - C[0]))
        th2 = atan2(sqrt(max(float(C[1] - (xl - C[0]) ** 2), 0.0)), float(xl - C[0]))
        L = log(tan(th2 / 2) / tan(th1 / 2))
        tot += L
        rows.append(dict(kind=C[2][0], u=C[2][1], v=C[2][2], xl=str(xl), xr=str(xr),
                         length=L, ytop=r, ylow=min(r * __import__('math').sin(th1), r * __import__('math').sin(th2))))
    print("total hyperbolic length of the non-vertical sides: %.4f" % tot)
    json.dump(dict(N=N, sides=rows), open("ford_%d.json" % N, "w"), indent=0)
    print("wrote ford_%d.json" % N)
