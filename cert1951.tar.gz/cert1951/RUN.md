# The eigenvalue certificate: running it on the double-double coefficients

Everything runs from this one folder. Copy your coefficient files into it first:

    coeffs_1951_dd_M12000_hi.npy   coeffs_1951_dd_M12000_lo.npy
    coeffs_1951_dd_M8000_hi.npy    coeffs_1951_dd_M8000_lo.npy     (optional)

Python 3 with numpy and mpmath. No Sage.

## Steps (M = 12000; replace 12000 by 8000 for the other file)

```
python3 side_nodes.py                          # geometry: 3114 segments, 124,560 nodes (seconds)
python3 eval_nodes.py 12000 --procs=16         # f~ and d_nu f~ at every node, rigorous errors
python3 assemble_jumps.py nodevals_dd_M12000.npz              # Q0, Q1   -> jumps_dd_M12000.json
python3 run_jumps.py dd:12000 --tol 1e-16 --tol1 1e-15 --workers 16 --out indep_dd_M12000.json
python3 certificate.py jumps_dd_M12000.json 12000 indep_dd_M12000.json
```

`eval_nodes.py` is the heavy step. Here, M = 8000 on 2 cores took 15 minutes.
Expect a few minutes at M = 12000 on 16 cores. `run_jumps.py` is the independent
second computation of Q0 and Q1. `certificate.py` uses the larger of the two
results and refuses to print a certificate unless both cover all 921 sides.

## What to look for

* `assemble_jumps.py` prints the least-squares Fricke eigenvalue next to the
  pinned Gauss-sum value tau(chi) zeta_5^3 / sqrt(1951). With the float64
  coefficients they differ by 1.3e-5. With the double-double ones they should
  agree to about 1e-12.
* By default λ~ is the pinned value, which is what the dd solve used. To use the
  fitted value, run `assemble_jumps.py ... --lam=opt` and pass the same number to
  `run_jumps.py --lam re,im`. Theorem 2 holds for any λ~.
* The bound is linear in the jumps. The float64 run gives 5.33e-5 with an rms jump
  of 1.4e-7. If the dd jumps are about 1e-12 everywhere, expect roughly 1e-9.

## Reference results (float64 coefficients, M = 8000)

`reference_*.json`: Q0 <= 2.3833e-11, Q1 <= 1.6192e-10, |λ1 - 1/4| <= 5.329e-5 at δ = 0.75.

## Files

| file | role |
|---|---|
| `ford_domain.py`, `pairings.py` | exact Ford domain of Γ0(1951)+ and its side pairings (already computed: `sides_1951.pkl`, `pairings_1951.pkl`) |
| `side_nodes.py` | node layout; pairings map nodes to nodes |
| `eval_nodes.py` | certified f~, d_nu f~ (double-double phases, certified K0/K1) |
| `assemble_jumps.py` | Chebyshev + Bernstein-ellipse bounds for Q0, Q1 |
| `run_jumps.py`, `series.py`, `kb_fast.py` | independent second computation of Q0, Q1 |
| `ell_max.py`, `ellmax_*.json` | rigorous seam-length bound by tile enumeration (precomputed; rerun with `python3 ell_max.py 0.75`) |
| `certificate.py`, `fricke_defect.py` | final bound (Theorem 2 of the note) |
| `certificate_criterion.pdf` | the criterion, its proof and the certified theorem |
