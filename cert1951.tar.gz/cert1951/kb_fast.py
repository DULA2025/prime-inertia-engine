"""Certified K_0, K_1 in float64, fast: exponentially scaled trapezoid with a
per-argument cut-off.

    k0s(x) = K_0(x) e^x = int_0^inf exp(-x (cosh t - 1)) dt
    k1s(x) = K_1(x) e^x = int_0^inf exp(-x (cosh t - 1)) cosh t dt

Step h = 1/16 (nodes and weights exact).  The sum for x stops at the first node
t_m with x (cosh t_m - 1) >= LCUT, so large arguments need few nodes (about 20
at x = 50, 16 at x = 100).  Valid for 0 < x <= XMAX; beyond XMAX callers use
the crude upper bounds k0_up, k1_up.

Error bounds (all rigorous):
  discretisation  |S - int| <= M_a / (e^{2 pi a/h} - 1) with a = 1.5 and
                  M_a <= 2 sqrt(pi/(2 x cos a)) e^{x (1 - cos a)} (times (1 + 1/(x cos a))
                  for K_1), from |K_nu(v)| <= K_{1/2 or 3/2}(v).  For x <= 100
                  this is below e^{-57}.
  truncation      sum_{k>m} h g(t_k) <= int_{t_m}^inf g <= e^{-x (cosh t_m - 1)} / (x sinh t_m)
                  (times coth t_m for K_1): convexity of cosh.
  rounding        (m + 20) eps relative: positive terms, exponent x * 2 sinh^2(t/2)
                  carries 4 eps relative and has weighted mean <= 2.
"""
import numpy as np

EPS = 2.0 ** -53
H = 1.0 / 16.0
LCUT = 50.0
XMAX = 100.0
A_STRIP = 1.5


def k0_up(v):
    """K_0(v) <= K_{1/2}(v) = sqrt(pi/(2v)) e^{-v}."""
    return np.sqrt(np.pi / (2.0 * v)) * np.exp(-v)


def k1_up(v):
    """K_1(v) <= K_{3/2}(v) = sqrt(pi/(2v)) e^{-v} (1 + 1/v)."""
    return np.sqrt(np.pi / (2.0 * v)) * np.exp(-v) * (1.0 + 1.0 / v)


def _nodes_needed(x):
    T = np.arccosh(1.0 + LCUT / x)
    return np.ceil(T / H).astype(np.int64)


def k01_scaled(x):
    """Return (k0s, k1s, abs0, abs1, rel) for 0 < x <= XMAX (1-D array)."""
    x = np.asarray(x, dtype=np.float64)
    assert x.ndim == 1 and np.all(x > 0) and np.all(x <= XMAX * (1 + 1e-12))
    m = _nodes_needed(x)
    # bucket node counts to multiples of 8 to keep the number of blocks small
    mb = ((m + 7) // 8) * 8
    k0s = np.empty_like(x)
    k1s = np.empty_like(x)
    tm = np.empty_like(x)
    for mm in np.unique(mb):
        sel = np.nonzero(mb == mm)[0]
        t = H * np.arange(mm + 1)
        s2 = 2.0 * np.sinh(0.5 * t) ** 2            # cosh t - 1, no cancellation
        w = np.full(mm + 1, H)
        w[0] = 0.5 * H
        with np.errstate(under='ignore'):
            E = np.exp(-np.outer(x[sel], s2))
        k0s[sel] = E @ w
        k1s[sel] = E @ (w * np.cosh(t))
        tm[sel] = t[-1]
    # truncation
    with np.errstate(under='ignore'):
        e_tr = np.exp(-x * (np.cosh(tm) - 1.0))
    tr0 = e_tr / (x * np.sinh(tm))
    tr1 = tr0 * np.cosh(tm)                           # coth(t_m) e/(x) = cosh/sinh * e / x
    # discretisation
    ca = np.cos(A_STRIP)
    q = np.exp(-2.0 * np.pi * A_STRIP / H)
    Ma0 = 2.0 * np.sqrt(np.pi / (2.0 * x * ca)) * np.exp(x * (1.0 - ca))
    Ma1 = Ma0 * (1.0 + 1.0 / (x * ca))
    d0 = Ma0 * q / (1.0 - q)
    d1 = Ma1 * q / (1.0 - q)
    rel = (mb.astype(np.float64) + 20.0) * EPS
    return k0s, k1s, tr0 + d0 + 1e-300, tr1 + d1 + 1e-300, rel


def k01(x):
    """Unscaled K_0, K_1 with absolute and relative error bounds (0 < x <= XMAX)."""
    k0s, k1s, a0, a1, rel = k01_scaled(x)
    ex = np.exp(-x)
    return k0s * ex, k1s * ex, a0 * ex, a1 * ex, rel + 2 * EPS


if __name__ == "__main__":
    import mpmath as mp
    mp.mp.dps = 40
    xs = np.array([1e-4, 3e-3, 0.02, 0.1, 0.5, 1.0, 2.5, 7.0, 20.0, 45.0, 80.0, 100.0])
    K0, K1, a0, a1, rel = k01(xs)
    worst = 0.0
    print("   x         K0 err / bound     K1 err / bound    nodes")
    for i, x in enumerate(xs):
        t0 = mp.besselk(0, mp.mpf(x)); t1 = mp.besselk(1, mp.mpf(x))
        e0 = float(abs(mp.mpf(K0[i]) - t0)); e1 = float(abs(mp.mpf(K1[i]) - t1))
        b0 = a0[i] + rel[i] * K0[i]; b1 = a1[i] + rel[i] * K1[i]
        worst = max(worst, e0 / b0, e1 / b1)
        print("  %-8g   %.2e / %.2e    %.2e / %.2e    %d" % (x, e0, b0, e1, b1, _nodes_needed(np.array([x]))[0]))
    print("worst error/bound ratio: %.3f  (must be < 1)" % worst)
    # random stress test
    rng = np.random.default_rng(3)
    xs = np.exp(rng.uniform(np.log(1e-4), np.log(100), 400))
    K0, K1, a0, a1, rel = k01(xs)
    w = 0.0
    for i, x in enumerate(xs[:400]):
        t0 = mp.besselk(0, mp.mpf(x)); t1 = mp.besselk(1, mp.mpf(x))
        w = max(w, float(abs(mp.mpf(K0[i]) - t0)) / (a0[i] + rel[i] * K0[i]),
                float(abs(mp.mpf(K1[i]) - t1)) / (a1[i] + rel[i] * K1[i]))
    print("random 400 arguments in [1e-4, 100]: worst error/bound = %.3f" % w)
    import time
    xs = 2 * np.pi * np.arange(1, 8001) * 5e-4
    t0 = time.time()
    for _ in range(20):
        k01(xs)
    print("8000 arguments at y = 5e-4: %.2f ms per call" % ((time.time() - t0) / 20 * 1000))
