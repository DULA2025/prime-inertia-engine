"""Rigorous bound for l_max(delta) = sup_z length(Sigma ∩ B(z, delta)).

    python3 ell_max.py 0.1 [rho]

Sigma = every edge of the tiling of H by Gamma_0(N)^+ that is an image of a
non-vertical side of F+ (the images of the vertical sides carry no jump).
It is convenient to work with the super-tiles h^{-1} P, P = U_k T^k F+:
their boundaries are exactly the seams, and Sigma is Gamma^+ invariant, so
the supremum may be taken over z in F+.

For z in F+, every super-tile meeting B(z, R) is reached from P by crossing
seams INSIDE B(z, R): a geodesic from z to a point of that tile stays in the
(convex) ball.  So a breadth-first walk that, in each tile's own coordinates
w = h z, crosses only the floor sides meeting B(w, R), finds all of them, and

    length(Sigma ∩ B(z, R)) = 1/2 sum_tiles length(floor ∩ B(h z, R)),

each seam being counted by its two tiles.  Chord lengths are exact: B(w, R)
is the Euclidean disk with centre (Re w, Im w cosh R), radius Im w sinh R.

z is restricted to cells covering {z in F+ : dist(z, floor) <= delta} (other
z see no seam).  A cell of size [x0, x0 + rho y0] x [y0, y0 e^rho] lies in a
ball of radius rho about its centre, so B(z, delta) ⊂ B(z_c, delta + rho) and
the maximum over cells of length(Sigma ∩ B(z_c, delta + rho)) bounds l_max.
"""
import sys
import pickle
import json
import numpy as np

N = 1951


def load():
    raw = pickle.load(open("sides_%d.pkl" % N, "rb"))
    P = pickle.load(open("pairings_%d.pkl" % N, "rb"))
    A = np.array([float(c) for (c, r2, t, xl, xr) in raw])
    R = np.array([np.sqrt(float(r2)) for (c, r2, t, xl, xr) in raw])
    XL = np.array([float(xl) for (c, r2, t, xl, xr) in raw])
    XR = np.array([float(xr) for (c, r2, t, xl, xr) in raw])
    G = np.array([np.array(g[0], dtype=float) for (g, j) in P['pairs']])
    return A, R, XL, XR, G


A, R, XL, XR, G = load()
NS = A.size
TH_R = np.arccos(np.clip((XR - A) / R, -1, 1))       # right end angle (smaller)
TH_L = np.arccos(np.clip((XL - A) / R, -1, 1))       # left end angle


def floor_height(x):
    x = ((x + 0.5) % 1.0) - 0.5
    i = np.clip(np.searchsorted(XR, x), 0, NS - 1)
    return np.sqrt(np.maximum(R[i] ** 2 - (x - A[i]) ** 2, 0))


def chords(wx, wy, Rb, i, k):
    """hyperbolic length of (side i translated by k) ∩ B(w, Rb), vectorised in w."""
    a, r = A[i] + k, R[i]
    cx, cy = wx, wy * np.cosh(Rb)
    e = wy * np.sinh(Rb)
    al, be = a - cx, cy
    nrm = np.sqrt(al ** 2 + be ** 2)
    Kc = (e ** 2 - al ** 2 - r ** 2 - be ** 2) / (2 * r * nrm)
    psi = np.arctan2(be, al)
    ac = np.arccos(np.clip(Kc, -1, 1))
    # condition cos(theta + psi) <= Kc  <=>  theta + psi in [ac, 2 pi - ac]
    lo = ac - psi
    hi = 2 * np.pi - ac - psi
    # bring into a window overlapping (0, pi)
    shift = np.where(hi < 0, 2 * np.pi, np.where(lo > np.pi, -2 * np.pi, 0.0))
    lo, hi = lo + shift, hi + shift
    ta = np.maximum(lo, TH_R[i])
    tb = np.minimum(hi, TH_L[i])
    full = Kc >= 1
    ta = np.where(full, TH_R[i], ta)
    tb = np.where(full, TH_L[i], tb)
    ok = (tb > ta) & (Kc >= -1)
    ta = np.clip(ta, 1e-300, np.pi - 1e-15)
    tb = np.clip(tb, 1e-300, np.pi - 1e-15)
    L = np.where(ok, np.log(np.tan(tb / 2) / np.tan(ta / 2)), 0.0)
    return np.maximum(L, 0.0)


PE = [g for (g, j) in pickle.load(open("pairings_%d.pkl" % N, "rb"))['pairs']]


def emul(A_, B_):
    """exact product of group elements (M, w); w = 1 means M / sqrt(N)."""
    (M1, w1), (M2, w2) = A_, B_
    (a, b), (c, d) = M1
    (e, f), (g, h) = M2
    P_ = [[a * e + b * g, a * f + b * h], [c * e + d * g, c * f + d * h]]
    if w1 and w2:
        P_ = [[x // N for x in row] for row in P_]
    return (P_, w1 ^ w2)


def ekey(E_):
    """key of the super-tile h^{-1} P: h modulo sign and LEFT translations."""
    (M, w) = E_
    (a, b), (c, d) = M
    if c < 0 or (c == 0 and d < 0):
        a, b, c, d = -a, -b, -c, -d
    if c == 0:
        return ('T',)
    m = -(a // c)
    return (a + m * c, b + m * d, c, d, w)


def ell_for_points(zx, zy, Rb, maxlevel=16):
    """length(Sigma ∩ B(z, Rb)) for arrays of points z (in F+).  Tiles are
    identified by their exact group element, so no tile is counted twice."""
    npt = zx.size
    total = np.zeros(npt)
    ident = ([[1, 0], [0, 1]], 0)
    fp = np.arange(npt); fx = zx.copy(); fy = zy.copy()
    fe = [ident] * npt
    seen = [{ekey(ident)} for _ in range(npt)]
    ntiles = np.ones(npt, dtype=int)
    for level in range(maxlevel):
        if fp.size == 0:
            break
        cand = []                                  # (frontier index, side, k, child x, child y)
        ex = fy * np.sinh(Rb)
        for k in (-1, 0, 1):
            for i in range(NS):
                near = (fx + ex >= XL[i] + k) & (fx - ex <= XR[i] + k)
                if not near.any():
                    continue
                sel = np.nonzero(near)[0]
                L = chords(fx[sel], fy[sel], Rb, i, k)
                hit = L > 0
                if not hit.any():
                    continue
                s2 = sel[hit]
                np.add.at(total, fp[s2], 0.5 * L[hit])
                w = (fx[s2] - k) + 1j * fy[s2]
                M = G[i]
                wn = (M[0, 0] * w + M[0, 1]) / (M[1, 0] * w + M[1, 1])
                for t_, q in enumerate(s2):
                    cand.append((int(q), i, k, wn[t_].real, wn[t_].imag))
        nfp, nfx, nfy, nfe = [], [], [], []
        for (q, i, k, cx_, cy_) in cand:
            p_ = int(fp[q])
            # child element: g_i T^{-k} h
            Tk = ([[1, -k], [0, 1]], 0)
            child = emul(PE[i], emul(Tk, fe[q]))
            kk = ekey(child)
            if kk not in seen[p_]:
                seen[p_].add(kk)
                ntiles[p_] += 1
                nfp.append(p_); nfx.append(cx_); nfy.append(cy_); nfe.append(child)
        fp = np.array(nfp, dtype=int); fx = np.array(nfx); fy = np.array(nfy); fe = nfe
    else:
        raise RuntimeError("tile walk did not terminate")
    return total, ntiles


# vertices of the (periodic) floor and tops of the side arcs
VX = np.concatenate([XL, XR[-1:]])
VY = np.sqrt(np.maximum(R[np.minimum(np.arange(VX.size), NS - 1)] ** 2
                        - (VX - A[np.minimum(np.arange(VX.size), NS - 1)]) ** 2, 0))
TOPS = [(A[i], R[i]) for i in range(NS) if XL[i] <= A[i] <= XR[i]]
TX = np.array([t[0] for t in TOPS]); TY = np.array([t[1] for t in TOPS])


def _range_extreme(xq0, xq1, px, py, fn):
    """fn (np.minimum or np.maximum) of py over px in [xq0, xq1] (periodic
    copies included); returns +-inf where empty."""
    pxx = np.concatenate([px - 1, px, px + 1]); pyy = np.concatenate([py, py, py])
    o = np.argsort(pxx); pxx, pyy = pxx[o], pyy[o]
    i0 = np.searchsorted(pxx, xq0, side='left')
    i1 = np.searchsorted(pxx, xq1, side='right')
    fill = np.inf if fn is np.minimum else -np.inf
    out = np.full(xq0.size, fill)
    nz = i1 > i0
    if nz.any():
        red = fn.reduceat(np.concatenate([pyy, [fill]]), np.stack([i0[nz], i1[nz]], 1).ravel())[::2]
        out[nz] = red
    return out


def cells(delta, rho):
    """centres of cells covering {z in F+ : dist(z, floor) <= delta}.

    A cell [x0, x0 + rho y0] x [y0, y0 e^rho] is kept unless it provably misses
    the region: it must reach above the floor somewhere (min of the floor over
    the cell, attained at an end point or a vertex, <= cell top), and it must
    be within delta of the floor (y0 <= e^delta * max of the floor over the
    cell widened by the largest horizontal reach of a delta-ball, the max
    being attained at an end point, a vertex or the top of an arc)."""
    ymin = 3 ** 0.5 / (2 * N)
    ytop = 1 / np.sqrt(N) * np.exp(delta) * 1.001
    dx_max = (1 / np.sqrt(N)) * np.exp(delta) * np.sinh(delta) * 1.01
    out_x, out_y = [], []
    y0 = ymin * np.exp(-rho)
    while y0 < ytop:
        y1 = y0 * np.exp(rho)
        step = rho * y0
        x0 = np.arange(-0.5, 0.5, step)
        x1 = x0 + step
        fmin = np.minimum(floor_height(x0), floor_height(x1))
        fmin = np.minimum(fmin, _range_extreme(x0, x1, VX, VY, np.minimum))
        w0, w1 = x0 - dx_max, x1 + dx_max
        fmax = np.maximum(floor_height(np.clip(w0, -1.5, 1.5)), floor_height(np.clip(w1, -1.5, 1.5)))
        fmax = np.maximum(fmax, _range_extreme(w0, w1, VX, VY, np.maximum))
        fmax = np.maximum(fmax, _range_extreme(w0, w1, TX, TY, np.maximum))
        keep = (fmin <= y1 * (1 + 1e-12)) & (y0 <= np.exp(delta) * fmax * (1 + 1e-12))
        cx = x0[keep] + step / 2
        out_x.append(cx)
        out_y.append(np.full(cx.size, y0 * np.exp(rho / 2)))
        y0 = y1
    return np.concatenate(out_x), np.concatenate(out_y)


def main():
    delta = float(sys.argv[1]) if len(sys.argv) > 1 else 0.1
    rho = float(sys.argv[2]) if len(sys.argv) > 2 else delta / 4
    zx, zy = cells(delta, rho)
    print("delta = %g, rho = %g: %d cells" % (delta, rho, zx.size), flush=True)
    Rb = delta + rho
    best = 0.0; arg = None; nt_max = 0
    B = 20000
    for s0 in range(0, zx.size, B):
        L, nt = ell_for_points(zx[s0:s0 + B], zy[s0:s0 + B], Rb)
        j = int(np.argmax(L))
        if L[j] > best:
            best, arg = float(L[j]), (float(zx[s0 + j]), float(zy[s0 + j]))
        nt_max = max(nt_max, int(nt.max()))
        print("  cells %d/%d: running l_max = %.4f (tiles per ball <= %d)"
              % (min(s0 + B, zx.size), zx.size, best, nt_max), flush=True)
    bound = best * (1 + 1e-9) + 1e-12
    print("l_max(%g) <= %.6f   (attained near z = %.6f + %.3e i); crude n pi sinh(delta) with n = %d: %.4f"
          % (delta, bound, arg[0], arg[1], nt_max, nt_max * np.pi * np.sinh(delta)))
    json.dump(dict(delta=delta, rho=rho, cells=int(zx.size), l_max=bound, at=arg,
                   max_tiles_per_ball=nt_max), open("ellmax_%g.json" % delta, "w"), indent=1)


if __name__ == "__main__":
    main()
