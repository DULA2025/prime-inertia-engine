"""Certified values of f~ and of its outward normal derivative at every side node.

    python3 eval_nodes.py 12000               # dd coefficients coeffs_1951_dd_M12000_{hi,lo}.npy
    python3 eval_nodes.py file.npy            # a single float64 coefficient file
    options:  --sides 0,1,460   --procs 8

Writes nodevals_<tag>.npz with, for every node, f~ (F0), d_nu f~ (F1) and
rigorous bounds E0, E1 on their evaluation errors.

f~ is the exactly odd series defined by the float64 numbers
    c_n = (c~_n - c~_{-n}) / 2,   c~_n = fl(hi_n + lo_n),
so
    f~   = i sum_n c_n 2 W_n(y) sin(2 pi n x),       W_n = sqrt(y) K_0(2 pi n y)
    f~_x = i sum_n c_n 4 pi n W_n cos(2 pi n x)
    f~_y = i sum_n c_n 2 W_n'(y) sin(2 pi n x),      W_n' = K_0/(2 sqrt y) - 2 pi n sqrt(y) K_1
    d_nu f~ = CX f~_x + CY f~_y   (CX = y(a-x)/r, CY = -y^2/r: hyperbolic unit outward normal).

Accuracy measures, each of which matters at the 1e-12 level we certify:
  * phases: n x mod 1 is formed EXACTLY (Dekker two_prod on the double-double x),
    so the phase error is ~1e-15 however large n x is;
  * Bessel: K_0, K_1 by the trapezoidal rule with h = 1/16 (exact nodes), the
    exponent x cosh t_k formed in double-double, and exp(-a_hi - a_lo)
    = exp(-a_hi)(1 - a_lo); the sums over t_k (positive terms) are pairwise
    trees (error <= 8u), the sums over n are double-double trees.
Error model (u = 2^-53, tau = 8u allowed for exp/cosh/sin/cos, i.e. 4 ulp):
  K_0: rel tau+13u, abs  2 K_0(x/sqrt2) e^{-8pi^2}/(1-e^{-8pi^2}) + e^{-x cosh T'}/(x sinh T')
  K_1: rel tau+15u, abs  analogous with K_1 and e^{T'} e^{-x cosh T'}/(x sinh T' - 1)
  (T' = T - h, T the truncation point), sin/cos: abs 18u; products: 6u per term;
  the tail n > n_cut is bounded from the STORED |c_n|.
"""
import sys
import os
import time
import numpy as np
import mpmath as mp
from multiprocessing import Pool

N = 1951
U = 2.0 ** -53
TAU = 8 * U
H = 1.0 / 16.0
XCUT = 60.0
TWO_PI = 2 * np.pi

# 2 pi as a double-double
mp.mp.dps = 40
_2PI_HI = float(2 * mp.pi)
_2PI_LO = float(2 * mp.pi - mp.mpf(_2PI_HI))
# cosh(k h) as double-doubles, k = 0..KMAX
KMAX = 16 * 14
_CH_HI = np.array([float(mp.cosh(mp.mpf(k) / 16)) for k in range(KMAX + 1)])
_CH_LO = np.array([float(mp.cosh(mp.mpf(k) / 16) - mp.mpf(float(mp.cosh(mp.mpf(k) / 16))))
                   for k in range(KMAX + 1)])
_W = np.full(KMAX + 1, H); _W[0] = H / 2


# ------------------------------------------------------------ dd primitives
_SPLIT = 134217729.0


def two_sum(a, b):
    s = a + b
    bb = s - a
    return s, (a - (s - bb)) + (b - bb)


def quick_two_sum(a, b):
    s = a + b
    return s, b - (s - a)


def _split(a):
    c = _SPLIT * a
    hi = c - (c - a)
    return hi, a - hi


def two_prod(a, b):
    p = a * b
    ah, al = _split(a)
    bh, bl = _split(b)
    return p, ((ah * bh - p) + ah * bl + al * bh) + al * bl


def dd_add(ah, al, bh, bl):
    s, e = two_sum(ah, bh)
    e = e + (al + bl)
    return quick_two_sum(s, e)


def dd_mul(ah, al, bh, bl):
    p, e = two_prod(ah, bh)
    e = e + (ah * bl + al * bh)
    return quick_two_sum(p, e)


def dd_tree_sum(x, axis):
    """Sum of a float array along `axis` in double-double (pairwise tree).
    The axis is zero-padded to a power of two once; each level is one dd_add
    of the two halves (views, no copies)."""
    x = np.moveaxis(np.asarray(x, dtype=float), axis, -1)
    L = x.shape[-1]
    P2 = 1 << max(0, int(np.ceil(np.log2(max(L, 1)))))
    if P2 != L:
        x = np.concatenate([x, np.zeros(x.shape[:-1] + (P2 - L,))], axis=-1)
    hi, lo = x, np.zeros_like(x)
    while hi.shape[-1] > 1:
        h = hi.shape[-1] // 2
        hi, lo = dd_add(hi[..., :h], lo[..., :h], hi[..., h:], lo[..., h:])
    return hi[..., 0] + lo[..., 0]


# ------------------------------------------------------------ Bessel K0, K1
def _tree(a):
    """pairwise sum along the last axis (length a power of two)."""
    while a.shape[-1] > 1:
        h = a.shape[-1] // 2
        a = a[..., :h] + a[..., h:]
    return a[..., 0]


def _k_upper(v, nu):
    s = np.sqrt(np.pi / (2 * v)) * np.exp(-v)
    return s if nu == 0 else s * (1 + 1 / v)


def k01_block(x_hi, x_lo, T):
    """K_0, K_1 at x = x_hi + x_lo (arrays), trapezoid to T; returns values and
    absolute error bounds (relative parts are added by the caller)."""
    nt = int(np.ceil(T / H)) + 1
    assert nt <= KMAX + 1
    P2 = 1 << int(np.ceil(np.log2(nt)))
    ch_hi = np.ones(P2); ch_lo = np.zeros(P2); w = np.zeros(P2)
    ch_hi[:nt], ch_lo[:nt], w[:nt] = _CH_HI[:nt], _CH_LO[:nt], _W[:nt]
    a_hi, a_lo = dd_mul(x_hi[:, None], x_lo[:, None], ch_hi[None, :], ch_lo[None, :])
    with np.errstate(under='ignore'):
        E = np.exp(-a_hi) * (1.0 - a_lo)
    # positive terms: a plain pairwise tree over <= 256 terms has relative
    # error <= 8u (log2 of the length), which is added to rel0/rel1 below
    K0 = _tree(E * w[None, :])
    K1 = _tree(E * (w * ch_hi)[None, :])
    x = x_hi
    q = np.exp(-8 * np.pi ** 2)
    v = x / np.sqrt(2.0)
    disc0 = 2 * _k_upper(v, 0) * q / (1 - q)
    disc1 = 2 * _k_upper(v, 1) * q / (1 - q)
    Tp = (nt - 1) * H - H              # last node minus one step
    with np.errstate(under='ignore', over='ignore'):
        tr0 = np.exp(-x * np.cosh(Tp)) / (x * np.sinh(Tp))
        den = x * np.sinh(Tp) - 1.0
        tr1 = np.where(den > 0, np.exp(Tp - x * np.cosh(Tp)) / np.maximum(den, 1e-300), np.inf)
    return K0, K1, disc0 + tr0, disc1 + tr1


def truncation_T(x):
    return max(np.arccosh(1 + XCUT / x), np.arcsinh(2.0 / x) + H, 1.0) + H


# ------------------------------------------------------------ one node
def eval_node(xh, xl, yh, yl, cx, cy, cn, absc):
    """f~, d_nu f~ at one node, with error bounds."""
    M = cn.size
    ncut = int(min(M, np.floor(XCUT / (TWO_PI * yh)) + 1))
    n = np.arange(1, ncut + 1, dtype=float)
    # x_n = 2 pi n y in double-double
    ty_h, ty_l = dd_mul(_2PI_HI, _2PI_LO, yh, yl)
    xn_h, xn_l = two_prod(n, ty_h)
    xn_l = xn_l + n * ty_l
    xn_h, xn_l = quick_two_sum(xn_h, xn_l)
    K0 = np.empty(ncut); K1 = np.empty(ncut); A0 = np.empty(ncut); A1 = np.empty(ncut)
    # blocks of n sharing a truncation point
    edges = [0.0, 0.05, 0.3, 1.0, 3.0, 6.0, 10.0, 16.0, 25.0, 38.0, np.inf]
    for lo_, hi_ in zip(edges[:-1], edges[1:]):
        sel = np.nonzero((xn_h > lo_) & (xn_h <= hi_))[0]
        if sel.size == 0:
            continue
        T = truncation_T(float(xn_h[sel].min()))
        k0, k1, a0, a1 = k01_block(xn_h[sel], xn_l[sel], T)
        K0[sel], K1[sel], A0[sel], A1[sel] = k0, k1, a0, a1
    rel0 = TAU + 5 * U + 8 * U        # + pairwise summation of <= 256 positive terms
    rel1 = TAU + 7 * U + 8 * U
    # exact phase: frac(n x), x = xh + xl
    p, e1 = two_prod(n, xh)
    q = p - np.rint(p)
    frac = q + (e1 + n * xl)
    th = TWO_PI * frac
    sn, cs = np.sin(th), np.cos(th)
    sy = np.sqrt(yh)
    W = sy * K0
    Wp = K0 / (2 * sy) - TWO_PI * n * sy * K1
    c = cn[:ncut]
    ac = absc[:ncut]
    g0 = 2 * W * sn
    gx = 2 * TWO_PI * n * W * cs
    gy = 2 * Wp * sn
    S0 = dd_tree_sum(c.real * g0, 0) + 1j * dd_tree_sum(c.imag * g0, 0)
    Sx = dd_tree_sum(c.real * gx, 0) + 1j * dd_tree_sum(c.imag * gx, 0)
    Sy = dd_tree_sum(c.real * gy, 0) + 1j * dd_tree_sum(c.imag * gy, 0)
    F0 = 1j * S0
    fx, fy = 1j * Sx, 1j * Sy
    F1 = cx * fx + cy * fy
    # error bounds -------------------------------------------------------
    # K: |dK0| <= rel0 K0 + A0 ; also y_lo and float x_n shift the argument:
    #    relative change <= (x K1/K0) * 4u <= (x+1) 4u  (and the same for K1)
    shift = 4 * U * (xn_h + 1)
    dK0 = (rel0 + shift) * K0 + A0
    dK1 = (rel1 + shift) * K1 + A1
    PH = 18 * U                       # |d sin|, |d cos|
    PR = 6 * U                        # products per term
    e0 = np.sum(2 * ac * (sy * (dK0 + (PR + PH) * K0))) * (1 + 1e-10)
    ex = np.sum(2 * ac * TWO_PI * n * (sy * (dK0 + (PR + PH + U) * K0))) * (1 + 1e-10)
    ey = np.sum(2 * ac * ((dK0 + (PR + PH) * K0) / (2 * sy)
                          + TWO_PI * n * sy * (dK1 + (PR + PH + U) * K1)
                          + U * (K0 / (2 * sy) + TWO_PI * n * sy * K1))) * (1 + 1e-10)
    # tail n > ncut, from the stored coefficients (K_nu <= K_{nu+1/2} bounds)
    if ncut < M:
        nt_ = np.arange(ncut + 1, M + 1, dtype=float)
        xt = TWO_PI * nt_ * yh * (1 - 4 * U)
        with np.errstate(under='ignore'):
            k0u = _k_upper(xt, 0); k1u = _k_upper(xt, 1)
        act = absc[ncut:]
        t0 = np.sum(2 * act * sy * k0u)
        tx = np.sum(2 * act * TWO_PI * nt_ * sy * k0u)
        ty = np.sum(2 * act * (k0u / (2 * sy) + TWO_PI * nt_ * sy * k1u))
        e0 += t0 * 1.01; ex += tx * 1.01; ey += ty * 1.01
    # rounding of the final dd -> float and of the combinations
    e0 += 2 * U * abs(F0)
    ex += 2 * U * abs(fx); ey += 2 * U * abs(fy)
    e1 = abs(cx) * ex + abs(cy) * ey + 3 * U * (abs(cx * fx) + abs(cy * fy)) + 2 * U * abs(F1)
    return F0, F1, e0, e1


# ------------------------------------------------------------ driver
_G = {}


def _init(cn, absc):
    _G['cn'], _G['absc'] = cn, absc


def _work(args):
    X, Y, CX, CY = args
    out = np.empty((X.shape[0], 4), dtype=np.complex128)
    for i in range(X.shape[0]):
        F0, F1, e0, e1 = eval_node(X[i, 0], X[i, 1], Y[i, 0], Y[i, 1], CX[i], CY[i],
                                   _G['cn'], _G['absc'])
        out[i] = (F0, F1, e0, e1)
    return out


def load_coefficients(arg):
    if arg.endswith(".npy"):
        hi = np.load(arg); lo = np.zeros_like(hi); tag = os.path.basename(arg)[:-4]
    else:
        M = int(arg)
        hi = np.load("coeffs_1951_dd_M%d_hi.npy" % M)
        lo = np.load("coeffs_1951_dd_M%d_lo.npy" % M)
        tag = "dd_M%d" % M
    n = hi[0].astype(int)
    c = (hi[1] + lo[1]) + 1j * (hi[2] + lo[2])
    C = {int(k): v for k, v in zip(n, c)}
    M = int(np.max(np.abs(n)))
    cn = np.array([(C[k] - C[-k]) / 2 for k in range(1, M + 1)])     # defines f~
    return cn, tag


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    opts = dict(a[2:].split("=") for a in sys.argv[1:] if a.startswith("--") and "=" in a)
    cn, tag = load_coefficients(args[0] if args else "12000")
    absc = np.abs(cn) * (1 + 1e-12)
    Z = np.load("nodes_%d.npz" % N)
    K = int(Z['K'])
    seg_side = Z['seg_side']
    if 'sides' in opts:
        want = set(int(s) for s in opts['sides'].split(","))
        # include partners so every jump can be formed
        want |= set(int(Z['side_partner'][s]) for s in list(want))
        segs = np.nonzero(np.isin(seg_side, list(want)))[0]
    else:
        segs = np.arange(seg_side.size)
    idx = (segs[:, None] * K + np.arange(K)[None, :]).ravel()
    X, Y, CX, CY = Z['X'][idx], Z['Y'][idx], Z['CX'][idx], Z['CY'][idx]
    procs = int(opts.get('procs', os.cpu_count() or 1))
    chunk = 64
    jobs = [(X[i:i + chunk], Y[i:i + chunk], CX[i:i + chunk], CY[i:i + chunk])
            for i in range(0, idx.size, chunk)]
    print("evaluating f~ and d_nu f~ at %d nodes (%d segments), M = %d, %d processes"
          % (idx.size, segs.size, cn.size, procs), flush=True)
    t0 = time.time()
    res = []
    with Pool(procs, initializer=_init, initargs=(cn, absc)) as pool:
        for k, r in enumerate(pool.imap(_work, jobs)):
            res.append(r)
            if (k + 1) % max(1, len(jobs) // 20) == 0:
                el = time.time() - t0
                print("  %5.1f%%  %7.1f s  eta %7.1f s" % (100.0 * (k + 1) / len(jobs), el,
                      el / (k + 1) * (len(jobs) - k - 1)), flush=True)
    R = np.concatenate(res)
    np.savez("nodevals_%s.npz" % tag, idx=idx, F0=R[:, 0], F1=R[:, 1],
             E0=R[:, 2].real, E1=R[:, 3].real, cn=cn)
    print("wrote nodevals_%s.npz in %.1f s;  max E0 = %.2e, max E1 = %.2e"
          % (tag, time.time() - t0, R[:, 2].real.max(), R[:, 3].real.max()))


if __name__ == "__main__":
    main()
