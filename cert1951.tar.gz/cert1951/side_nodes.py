"""Nodes on the 921 sides of the Ford domain F+ of Gamma_0(N)^+, for the jump
certificate (Theorem 2 of certificate_criterion.pdf).

    python3 side_nodes.py            ->  nodes_1951.npz

Each side lies on a circle |z - a| = r and is parametrised by hyperbolic arc
length sigma from its LEFT end:

    t = t_l - sigma,   x = a - r tanh t,   y = r sech t,

(t is arc length from the top of the circle).  A side of length l is cut into
m = ceil(l / H_SEG) equal segments carrying K Chebyshev points of the first
kind each.  The pairing g_s maps side s isometrically onto its partner s', so
arc length is preserved: sigma' = sigma or l - sigma.  Segments and nodes are
therefore laid out so that g_s maps the nodes of s EXACTLY onto the nodes of
s' (first-kind Chebyshev points are symmetric), and f~ need only be evaluated
once per node.

Positions are computed in 40-digit arithmetic and stored as double-doubles:
at height ~5e-4 the Fourier phases e(n x) move by 2 pi n dx, and a float64
x (error ~5e-17) would already shift f~ by ~1e-12, the size of the defect we
are certifying.

Checks performed here (all must pass):
  * isometry: l(s) = l(s') to 1e-25 for every pair,
  * the pairing maps a node of s onto the corresponding node of s' to 1e-28,
  * the pairing maps the outward normal of F+ at s onto the inward normal at s'.

For every segment it also records, on the boundary of the Bernstein ellipse
E_rho of the segment (in sigma), rigorous extremes of |y|, Re y, |Im x| and
|a - x|; these feed the interpolation error bound.
"""
import pickle
import sys
from fractions import Fraction as Fr
import numpy as np
import mpmath as mp

mp.mp.dps = 40
N = 1951
H_SEG = 0.5            # maximal segment length (hyperbolic)
K = 40                 # Chebyshev points per segment
RHO = 3.0              # Bernstein ellipse parameter
NTHETA = 2048          # samples on the ellipse boundary


def fr2mp(q):
    return mp.mpf(q.numerator) / q.denominator


def dd(v):
    hi = float(v)
    lo = float(v - mp.mpf(hi))
    return hi, lo


def chi_table():
    dl, x = {}, 1
    for k in range(N - 1):
        dl[x] = k
        x = (x * 3) % N
    assert len(dl) == N - 1
    return dl


def main():
    raw = pickle.load(open("sides_%d.pkl" % N, "rb"))
    P = pickle.load(open("pairings_%d.pkl" % N, "rb"))
    pairs = P['pairs']
    dl = chi_table()
    ns = len(raw)
    sides = []
    for (ctr, r2, tag, xl, xr) in raw:
        a, r = fr2mp(ctr), mp.sqrt(fr2mp(r2))
        tl = mp.atanh((a - fr2mp(xl)) / r)
        tr = mp.atanh((a - fr2mp(xr)) / r)
        sides.append(dict(a=a, r=r, tl=tl, tr=tr, ell=tl - tr, tag=tag))

    def point(i, sigma):
        s = sides[i]
        t = s['tl'] - sigma
        return s['a'] - s['r'] * mp.tanh(t), s['r'] * mp.sech(t)

    def act(g, z):
        (M, w) = g
        (A, B), (C, D) = M
        return (A * z + B) / (C * z + D)

    # ---- pairings: partner, orientation, character factor, type
    meta = []
    worst_len = worst_pt = mp.mpf(0)
    for i, (g, j) in enumerate(pairs):
        li, lj = sides[i]['ell'], sides[j]['ell']
        worst_len = max(worst_len, abs(li - lj))
        x0, y0 = point(i, mp.mpf(0))
        z = act(g, mp.mpc(x0, y0))
        xl_j, yl_j = point(j, mp.mpf(0))
        xr_j, yr_j = point(j, sides[j]['ell'])
        dl_ = abs(z - mp.mpc(xl_j, yl_j))
        dr_ = abs(z - mp.mpc(xr_j, yr_j))
        rev = dr_ < dl_
        # check an interior point
        sg = li * mp.mpf("0.3721")
        xi, yi = point(i, sg)
        zi = act(g, mp.mpc(xi, yi))
        xj, yj = point(j, (lj - sg) if rev else sg)
        worst_pt = max(worst_pt, abs(zi - mp.mpc(xj, yj)))
        # normal check: outward normal of F+ at s_i points INTO the circle;
        # g must map it to the inward normal at s_j (pointing OUT of circle j)
        eps_ = mp.mpf(10) ** -12
        a_i, a_j = sides[i]['a'], sides[j]['a']
        w_out = mp.mpc(xi, yi) + eps_ * (mp.mpc(a_i, 0) - mp.mpc(xi, yi)) / sides[i]['r']
        img = act(g, w_out)
        inside_j = abs(img - a_j) < sides[j]['r']
        assert not inside_j, "normal orientation check failed at side %d" % i
        (M, w) = g
        if w == 0:
            chi_arg = M[0][0] % N                  # chi(a_g)
        else:
            assert M[1][0] % N == 0
            chi_arg = (M[1][0] // N) % N           # chi(c) = chi(a_{W g}) (chi even)
        k5 = (2 * dl[chi_arg]) % 5
        meta.append(dict(partner=j, rev=bool(rev), fricke=int(w), k5=k5))
    print("pairings: max |l(s)-l(s')| = %.1e, max node mismatch = %.1e"
          % (float(worst_len), float(worst_pt)))
    assert worst_len < mp.mpf(10) ** -25 and worst_pt < mp.mpf(10) ** -28

    # ---- segments and nodes
    u = np.cos((2 * np.arange(K) + 1) * np.pi / (2 * K))
    u_mp = [mp.cos((2 * jj + 1) * mp.pi / (2 * K)) for jj in range(K)]
    m_of = []
    for i in range(ns):
        m = int(mp.ceil(sides[i]['ell'] / H_SEG))
        m_of.append(m)
    for i in range(ns):
        assert m_of[i] == m_of[meta[i]['partner']]
    seg_start = np.zeros(ns + 1, dtype=np.int64)
    seg_start[1:] = np.cumsum(m_of)
    nseg = int(seg_start[-1])
    nnode = nseg * K
    X = np.zeros((nnode, 2)); Yv = np.zeros((nnode, 2)); CX = np.zeros(nnode); CY = np.zeros(nnode)
    seg_side = np.zeros(nseg, dtype=np.int64); seg_len = np.zeros(nseg)
    seg_partner = np.zeros(nseg, dtype=np.int64); seg_rev = np.zeros(nseg, dtype=bool)
    ell_bounds = np.zeros((nseg, 5))      # max|y|, min Re y, max|Im x|, max|a-x|, r
    th = np.linspace(0, 2 * np.pi, NTHETA, endpoint=False)
    uell = (RHO * np.exp(1j * th) + np.exp(-1j * th) / RHO) / 2
    for i in range(ns):
        s = sides[i]
        m = m_of[i]
        hseg = s['ell'] / m
        a_f, r_f, tl_f = float(s['a']), float(s['r']), float(s['tl'])
        for k in range(m):
            sidx = int(seg_start[i]) + k
            seg_side[sidx] = i
            seg_len[sidx] = float(hseg)
            kk = (m - 1 - k) if meta[i]['rev'] else k
            seg_partner[sidx] = int(seg_start[meta[i]['partner']]) + kk
            seg_rev[sidx] = meta[i]['rev']
            mid = (k + mp.mpf(1) / 2) * hseg
            for jj in range(K):
                sg = mid + u_mp[jj] * hseg / 2
                x, y = point(i, sg)
                n_ = sidx * K + jj
                X[n_] = dd(x); Yv[n_] = dd(y)
                CX[n_] = float(y * (s['a'] - x) / s['r'])
                CY[n_] = float(-y * y / s['r'])
            # Bernstein ellipse boundary in sigma, mapped through t = t_l - sigma
            sig = float(mid) + float(hseg) / 2 * uell
            t = tl_f - sig
            xc = a_f - r_f * np.tanh(t)
            yc = r_f / np.cosh(t)
            b = float(hseg) / 2 * (RHO - 1 / RHO) / 2
            assert b < 1.2, "ellipse too wide"
            # rigorous margin between samples: |dx/dt|,|dy/dt| <= r / cos(b)^2,
            # |d sigma / d theta| <= (h/2)(rho + 1/rho)/2, spacing 2 pi / NTHETA
            marg = (np.pi / NTHETA) * float(hseg) / 2 * (RHO + 1 / RHO) / 2 * r_f / np.cos(b) ** 2
            ell_bounds[sidx] = (np.max(np.abs(yc)) + marg,
                                np.min(yc.real) - marg,
                                np.max(np.abs(xc.imag)) + marg,
                                np.max(np.abs(a_f - xc)) + marg,
                                r_f)
    assert np.all(ell_bounds[:, 1] > 0), "Re y not positive on some ellipse"
    ratio = ell_bounds[:, 2] / ell_bounds[:, 1]
    print("segments %d, nodes %d; worst |Im x|/Re y on the ellipses = %.3f"
          % (nseg, nnode, ratio.max()))
    np.savez("nodes_%d.npz" % N, X=X, Y=Yv, CX=CX, CY=CY, K=K, RHO=RHO, H_SEG=H_SEG,
             seg_side=seg_side, seg_len=seg_len, seg_partner=seg_partner, seg_rev=seg_rev,
             ell_bounds=ell_bounds,
             side_partner=np.array([mm['partner'] for mm in meta]),
             side_rev=np.array([mm['rev'] for mm in meta]),
             side_fricke=np.array([mm['fricke'] for mm in meta]),
             side_k5=np.array([mm['k5'] for mm in meta]),
             side_len=np.array([float(s['ell']) for s in sides]),
             seg_start=seg_start)
    print("wrote nodes_%d.npz" % N)


if __name__ == "__main__":
    main()
