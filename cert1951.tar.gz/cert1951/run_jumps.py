"""Rigorous upper bounds for the jump norms of the certificate,

    Q0 = sum_s int_s |D_s|^2 ds,     Q1 = sum_s int_s |d_nu D_s|^2 ds,

over the 921 non-vertical sides of the Ford domain of Gamma_0(1951)^+, where
D_s = G_s - f~ is the jump of the automorphization across s (see the note):

    s paired by g in Gamma_0(N):   G_s(w) = chi(a_g) f~(g w)
    s paired by g in W Gamma_0(N): G_s(w) = chi(c_g) lambda~ f~*(g w),  c_g = M_21 / N

Method, per side: split into pieces of hyperbolic length <= 1, parametrised by
arc length sigma (w = a - r tanh sigma + i r sech sigma).  On each piece:

  1. crude bounds M for |D| and |d_nu D| on a Bernstein ellipse E_rho in sigma
     with semi-minor axis b = 0.6: along the complexified geodesic
     |Im x| <= sin(b) Re y, so the series converges with room to spare;
     the image piece is handled on the PARTNER geodesic, since g maps one
     geodesic to the other isometrically and the identity continues analytically;
  2. K = degree from 4 M rho^-K / (rho - 1) <= tol;
  3. samples at the K+1 Chebyshev points (second kind): f~ and grad f~ at the
     point P (double-double abscissa) and at its EXACT image g(P), computed in
     50-digit arithmetic from the integer matrix; every sample carries a bound;
  4. || D ||_L2(piece) <= sqrt(h) ( ||p||_L2[-1,1] + sqrt2 (4 M rho^-K/(rho-1) + Lambda_K max err) ).

Usage:
    python3 run_jumps.py COEFFS [--tol 1e-10] [--workers 2] [--sides 0-920]
        COEFFS: a float64 .npy (vstack([n, re, im])) or  dd:M  for the
        coeffs_1951_dd_M{M}_{hi,lo}.npy pair (rounded: f~ is defined by fl(hi+lo)).
"""
import sys
import os
import json
import time
import pickle
import argparse
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from series import OddSeries, EPS

mp.mp.dps = 50
N = 1951
B_STRIP = 0.6
SINB, COSB = np.sin(B_STRIP), np.cos(B_STRIP)
PIECE = 1.0
KMAX = 160


# ------------------------------------------------------------- coefficients
def load_odd_coeffs(spec):
    if spec.startswith("dd:"):
        M = int(spec[3:])
        hi = np.load("coeffs_1951_dd_M%d_hi.npy" % M)
        lo = np.load("coeffs_1951_dd_M%d_lo.npy" % M)
    else:
        hi = np.load(spec)
        lo = np.zeros_like(hi)
    n = hi[0].astype(int)
    c = (hi[1] + lo[1]) + 1j * (hi[2] + lo[2])
    C = {int(k): v for k, v in zip(n, c)}
    M = int(np.max(np.abs(n)))
    codd = np.array([(C[k] - C[-k]) / 2 for k in range(1, M + 1)])
    return codd


def chi_table():
    dl, x = {}, 1
    for k in range(N - 1):
        dl[x] = k
        x = (x * 3) % N
    z5 = np.exp(2j * np.pi / 5)
    tab = np.zeros(N, dtype=np.complex128)
    for k in range(1, N):
        tab[k] = z5 ** ((2 * dl[k]) % 5)
    a = np.arange(1, N)
    tau = np.sum(tab[1:] * np.exp(2j * np.pi * a / N)) / np.sqrt(float(N))
    lam = tau * np.exp(2j * np.pi * 3.0 / 5.0)
    return tab, lam / abs(lam)


# ----------------------------------------------------------------- geometry
class Side:
    def __init__(self, idx, ctr, r2, tag, xl, xr, g, partner):
        self.idx, self.tag, self.partner = idx, tag, partner
        self.a = mp.mpf(ctr.numerator) / ctr.denominator
        self.r = mp.sqrt(mp.mpf(r2.numerator) / r2.denominator)
        self.xl = mp.mpf(xl.numerator) / xl.denominator
        self.xr = mp.mpf(xr.numerator) / xr.denominator
        self.M, self.w = g
        # sigma decreases as x increases
        self.s_hi = mp.atanh((self.a - self.xl) / self.r)
        self.s_lo = mp.atanh((self.a - self.xr) / self.r)
        self.length = float(self.s_hi - self.s_lo)

    def point(self, s):
        return mp.mpc(self.a - self.r * mp.tanh(s), self.r * mp.sech(s))

    def sigma_of(self, z):
        return mp.atanh((self.a - z.real) / self.r)

    def mob(self, z):
        (a, b), (c, d) = self.M
        return (a * z + b) / (c * z + d)

    def dmob(self, z):
        (a, b), (c, d) = self.M
        return (a * d - b * c) / (c * z + d) ** 2


def load_sides(ford_dir):
    raw = pickle.load(open(os.path.join(ford_dir, "sides_1951.pkl"), "rb"))
    P = pickle.load(open(os.path.join(ford_dir, "pairings_1951.pkl"), "rb"))
    return [Side(i, *raw[i], *P['pairs'][i]) for i in range(len(raw))]


# ---------------------------------------------------------------- chebyshev
def cheb2(K):
    return np.cos(np.pi * np.arange(K + 1) / K)


def bary_weights(K):
    w = (-1.0) ** np.arange(K + 1)
    w[0] *= 0.5
    w[-1] *= 0.5
    return w


def bary_eval(xn, fn, w, x):
    d = x[:, None] - xn[None, :]
    exact = np.isclose(d, 0.0, atol=0.0, rtol=0.0)
    d[exact] = 1.0
    t = w[None, :] / d
    out = (t @ fn) / t.sum(axis=1)
    rows, cols = np.nonzero(exact)
    out[rows] = fn[cols]
    return out


def l2_norm_poly(xn, fn, K):
    """|| p ||_{L2[-1,1]} for the interpolant of (xn, fn): Gauss-Legendre is
    exact for |p|^2 (degree 2K) with K+2 nodes."""
    gx, gw = np.polynomial.legendre.leggauss(K + 2)
    p = bary_eval(xn, fn, bary_weights(K), gx)
    return float(np.sqrt(np.sum(gw * np.abs(p) ** 2))) * (1.0 + 1e-12)


# ---------------------------------------------------------- the per-piece bound
def ellipse_params(h):
    rho = B_STRIP / h + np.sqrt((B_STRIP / h) ** 2 + 1.0)
    aE = h * (rho + 1.0 / rho) / 2.0
    return rho, aE


def geodesic_box(r, sc, aE):
    lo, hi = sc - aE, sc + aE
    maxabs = max(abs(lo), abs(hi))
    minabs = 0.0 if lo <= 0.0 <= hi else min(abs(lo), abs(hi))
    Ymin = r * COSB / np.cosh(maxabs)
    ymax = r / np.sqrt(np.cosh(minabs) ** 2 - SINB ** 2)
    return Ymin, ymax


class JumpCertifier:
    def __init__(self, codd, sides, tol0, tol1, lam=None):
        self.ser = OddSeries(codd)
        self.sides = sides
        self.tab, self.lam = chi_table()
        if lam is not None:            # lambda~ is a free parameter of Theorem 2
            self.lam = complex(lam)
        self.tol0, self.tol1 = tol0, tol1

    def kappa(self, s):
        (a, b), (c, d) = s.M
        if s.w == 0:
            return complex(self.tab[int(a) % N]), False
        return complex(self.tab[int(c // N) % N] * self.lam), True

    def piece(self, s, sa, sb):
        """Rigorous L2 bounds of D and d_nu D over sigma in [sa, sb] (mp values)."""
        ser = self.ser
        t = self.sides[s.partner]
        kap, conj = self.kappa(s)
        akap = abs(kap) * (1 + 4 * EPS)
        h = float(sb - sa) / 2.0
        sc = float(sa + sb) / 2.0
        rho, aE = ellipse_params(h)
        # partner parameter interval (affine image of [sa, sb])
        ta = t.sigma_of(s.mob(s.point(sa)))
        tb = t.sigma_of(s.mob(s.point(sb)))
        tc = float(ta + tb) / 2.0
        assert abs(abs(float(tb - ta)) - 2 * h) < 1e-12 * max(1.0, 2 * h), "pairing is not an isometry here"
        Ymin_s, ymax_s = geodesic_box(float(s.r), sc, aE)
        Ymin_t, ymax_t = geodesic_box(float(t.r), tc, aE)
        Fs, Gs = ser.ellipse_bound(Ymin_s, ymax_s, SINB, COSB)
        Ft, Gt = ser.ellipse_bound(Ymin_t, ymax_t, SINB, COSB)
        MD = Fs + akap * Ft
        MN = (ymax_s * Gs + akap * ymax_t * Gt) / COSB
        need = lambda M, tol: np.log(4.0 * M / ((rho - 1.0) * tol)) / np.log(rho)
        K = int(np.ceil(max(need(MD, self.tol0), need(MN, self.tol1), 4)))
        if K > KMAX:
            sm = (sa + sb) / 2
            a = self.piece(s, sa, sm)
            b = self.piece(s, sm, sb)
            return dict(L2D2=a['L2D2'] + b['L2D2'], L2N2=a['L2N2'] + b['L2N2'],
                        maxD=max(a['maxD'], b['maxD']), maxN=max(a['maxN'], b['maxN']),
                        nodes=a['nodes'] + b['nodes'], maxerr=max(a['maxerr'], b['maxerr']))
        xn = cheb2(K)
        Dv = np.empty(K + 1, dtype=np.complex128)
        Nv = np.empty(K + 1, dtype=np.complex128)
        eD = np.empty(K + 1)
        eN = np.empty(K + 1)
        for m, tt in enumerate(xn):
            sig = mp.mpf(sc) + mp.mpf(h) * mp.mpf(tt)
            P = s.point(sig)
            Xh = float(P.real)
            Xl = float(P.real - Xh)
            Y = float(P.imag)
            Pf = mp.mpc(mp.mpf(Xh) + mp.mpf(Xl), mp.mpf(Y))
            u = s.mob(Pf)
            Uh = float(u.real)
            Ul = float(u.real - Uh)
            Uy = float(u.imag)
            gp = complex(s.dmob(Pf))
            nx, ny = float(-mp.tanh(sig)), float(mp.sech(sig))
            ef = ser.eval(Xh, Xl, Y)
            eg = ser.eval(Uh, Ul, Uy)
            fP = 2j * ef['S0']
            fxP, fyP = 2j * ef['S1'], 2j * ef['S2']
            if conj:
                Gu = 2j * np.conj(eg['S0'])
                Gx, Gy = 2j * np.conj(eg['S1']), 2j * np.conj(eg['S2'])
            else:
                Gu = 2j * eg['S0']
                Gx, Gy = 2j * eg['S1'], 2j * eg['S2']
            V = gp * Y * complex(nx, ny)
            Dv[m] = kap * Gu - fP
            Nv[m] = kap * (V.real * Gx + V.imag * Gy) - Y * (nx * fxP + ny * fyP)
            # evaluation errors
            aV = abs(V) * (1 + 1e-12)
            gradP = 2 * Y * (ef['A1'] + ef['A2'])          # |grad_hyp f~(P)| crude
            gradU = 2 * Uy * (eg['A1'] + eg['A2'])
            hessP = 2 * Y * Y * ef['B']
            hessU = 2 * Uy * Uy * eg['B']
            eD[m] = (2 * ef['e0'] + akap * 2 * eg['e0'] + 8 * EPS * (2 * ef['A0'] + akap * 2 * eg['A0'])
                     + 1.01 * EPS * (gradP + 2 * akap * gradU))
            eN[m] = (Y * 2 * (ef['e1'] + ef['e2']) + akap * aV * 2 * (eg['e1'] + eg['e2'])
                     + 8 * EPS * (Y * 2 * (ef['A1'] + ef['A2']) + akap * aV * 2 * (eg['A1'] + eg['A2']))
                     + 1.01 * EPS * (hessP + gradP + 2 * akap * (hessU + gradU)))
        lam_K = 2.0 / np.pi * np.log(K + 1.0) + 1.0
        interpD = 4.0 * MD * rho ** (-K) / (rho - 1.0)
        interpN = 4.0 * MN * rho ** (-K) / (rho - 1.0)
        l2D = l2_norm_poly(xn, Dv, K) + np.sqrt(2.0) * (interpD + lam_K * eD.max())
        l2N = l2_norm_poly(xn, Nv, K) + np.sqrt(2.0) * (interpN + lam_K * eN.max())
        return dict(L2D2=h * l2D ** 2 * (1 + 1e-12), L2N2=h * l2N ** 2 * (1 + 1e-12),
                    maxD=float(np.abs(Dv).max()), maxN=float(np.abs(Nv).max()),
                    nodes=K + 1, maxerr=float(eD.max()))

    def side(self, i):
        s = self.sides[i]
        npieces = max(1, int(np.ceil(s.length / PIECE)))
        edges = [s.s_lo + (s.s_hi - s.s_lo) * mp.mpf(k) / npieces for k in range(npieces + 1)]
        tot = dict(L2D2=0.0, L2N2=0.0, maxD=0.0, maxN=0.0, nodes=0, maxerr=0.0)
        for k in range(npieces):
            r = self.piece(s, edges[k], edges[k + 1])
            tot['L2D2'] += r['L2D2']
            tot['L2N2'] += r['L2N2']
            tot['maxD'] = max(tot['maxD'], r['maxD'])
            tot['maxN'] = max(tot['maxN'], r['maxN'])
            tot['nodes'] += r['nodes']
            tot['maxerr'] = max(tot['maxerr'], r['maxerr'])
        tot.update(idx=i, kind=s.tag[0], u=s.tag[1], v=s.tag[2], length=s.length,
                   ytop=float(s.r))
        return tot


_CERT = None


def _init(spec, ford_dir, tol0, tol1, lam):
    global _CERT
    _CERT = JumpCertifier(load_odd_coeffs(spec), load_sides(ford_dir), tol0, tol1, lam)


def _work(i):
    return _CERT.side(i)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("coeffs")
    ap.add_argument("--ford", default=HERE if os.path.exists(os.path.join(HERE, "sides_1951.pkl")) else os.path.join(HERE, "..", "ford"))
    ap.add_argument("--tol", type=float, default=1e-10)
    ap.add_argument("--tol1", type=float, default=None)
    ap.add_argument("--workers", type=int, default=os.cpu_count())
    ap.add_argument("--sides", default=None, help="e.g. 0-99 or 460")
    ap.add_argument("--out", default="jumps_result.json")
    ap.add_argument("--lam", default=None, help="lambda~ as re,im (default: pinned Gauss-sum value)")
    a = ap.parse_args()
    lam = complex(*map(float, a.lam.split(","))) if a.lam else None
    tol1 = a.tol1 if a.tol1 is not None else 10 * a.tol
    nside = 921
    if a.sides:
        if "-" in a.sides:
            lo, hi = map(int, a.sides.split("-"))
            idx = list(range(lo, hi + 1))
        else:
            idx = [int(x) for x in a.sides.split(",")]
    else:
        idx = list(range(nside))
    done = {}
    if os.path.exists(a.out):
        for r in json.load(open(a.out))["sides"]:
            done[r["idx"]] = r
    todo = [i for i in idx if i not in done]
    print("certifying %d sides (%d already done) with %d workers, tol %.1e / %.1e"
          % (len(todo), len(idx) - len(todo), a.workers, a.tol, tol1), flush=True)
    t0 = time.time()
    import multiprocessing as mpc
    with mpc.Pool(a.workers, initializer=_init, initargs=(a.coeffs, a.ford, a.tol, tol1, lam)) as pool:
        for k, r in enumerate(pool.imap_unordered(_work, todo)):
            done[r["idx"]] = r
            if (k + 1) % 20 == 0 or k + 1 == len(todo):
                el = time.time() - t0
                print("  %4d/%d sides   %.0f s   (eta %.0f s)" % (k + 1, len(todo), el,
                      el / (k + 1) * (len(todo) - k - 1)), flush=True)
                json.dump(dict(coeffs=a.coeffs, tol=a.tol, tol1=tol1, lam=a.lam,
                               sides=sorted(done.values(), key=lambda r: r["idx"])),
                          open(a.out, "w"))
    res = sorted(done.values(), key=lambda r: r["idx"])
    json.dump(dict(coeffs=a.coeffs, tol=a.tol, tol1=tol1, lam=a.lam, sides=res), open(a.out, "w"))
    sel = [r for r in res if r["idx"] in set(idx)]
    Q0 = sum(r["L2D2"] for r in sel)
    Q1 = sum(r["L2N2"] for r in sel)
    print()
    print("sides certified: %d   nodes: %d" % (len(sel), sum(r["nodes"] for r in sel)))
    print("Q0 <= %.6e   (sqrt %.6e)" % (Q0, np.sqrt(Q0)))
    print("Q1 <= %.6e   (sqrt %.6e)" % (Q1, np.sqrt(Q1)))
    print("largest jump seen at a node: %.3e;  largest normal-derivative jump: %.3e"
          % (max(r["maxD"] for r in sel), max(r["maxN"] for r in sel)))


if __name__ == "__main__":
    main()
