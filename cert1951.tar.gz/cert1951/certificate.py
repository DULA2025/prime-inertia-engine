"""Assemble the eigenvalue certificate of Theorem 2.

    python3 certificate.py jumps_<tag>.json <coefficients: 12000 | file.npy>

Reads Q0, Q1 and lambda~ from the jumps file, l_max(delta) from every
ellmax_<delta>.json present, and bounds ||f~||_{Y1} from below.  For each delta

    |lambda_1 - 1/4| <= sqrt((1 + max(1,|lam|^2))/2) (alpha0 sqrt(Q0) + alpha1 sqrt(Q1)) / (k0 ||f~||_{Y1}),

(the set of sides of F+ and of W F+ meets every Gamma-orbit of seams exactly twice, hence the 1/2),

    Y      = 1 / sinh^2(delta/2)                (kernel phi(Y u), phi = 3(1-x)^2, support d <= delta)
    k0     = (4 pi / Y) / sqrt(1 + 1/Y)          (P_{-1/2}(cosh d) >= sech(d/2))
    alpha0 = sqrt( 46.4333 (1 + 1/Y) l_max )     (kappa1 G1 <= 4 pi * 1.6 * (4/sqrt 3) (1 + 1/Y) = 46.43326.. (1 + 1/Y))
    alpha1 = sqrt( 12 pi l_max / Y )
    ||f~||^2_{Y1} >= 2 sum_{n<=40} |c_n|^2 * (right-endpoint Riemann sum of the
                     decreasing K_0(2 pi t)^2 / t on [n Y1, n Y1 + 4], certified K_0 lower values)

The best delta is reported, and everything is written to certificate_<tag>.json.
"""
import sys
import glob
import json
import numpy as np
sys.path.insert(0, "..")
from fricke_defect import k01_certified

N = 1951


def load_cn(arg):
    if arg.endswith(".npy"):
        hi = np.load(arg); lo = np.zeros_like(hi)
    else:
        M = int(arg)
        hi = np.load("coeffs_1951_dd_M%d_hi.npy" % M)
        lo = np.load("coeffs_1951_dd_M%d_lo.npy" % M)
    n = hi[0].astype(int)
    c = (hi[1] + lo[1]) + 1j * (hi[2] + lo[2])
    C = {int(k): v for k, v in zip(n, c)}
    M = int(np.max(np.abs(n)))
    return np.array([(C[k] - C[-k]) / 2 for k in range(1, M + 1)])


def norm_lower(cn, Y1, nmax=40, span=4.0, steps=40000):
    tot = 0.0
    for n in range(1, nmax + 1):
        a = n * Y1
        t = a + span * np.arange(1, steps + 1) / steps        # right end points
        K0, K1, ab, rel = k01_certified(2 * np.pi * t)
        K0lo = np.maximum(K0 * (1 - rel) - ab, 0.0)
        integ = np.sum(K0lo ** 2 / t) * (span / steps) * (1 - 1e-12)
        tot += 2 * abs(cn[n - 1]) ** 2 * integ * (1 - 1e-12)
    return np.sqrt(tot)


def main():
    J = json.load(open(sys.argv[1]))
    cn = load_cn(sys.argv[2])
    Q0, Q1 = J['Q0'], J['Q1']
    # Theorem 2 needs the jumps over ALL 921 sides: refuse a partial run
    nsides = len(J.get('per_side', {}))
    if nsides != 921 or J.get('segments') != 3114:
        print("INCOMPLETE: the jumps file covers %d of 921 sides (%s of 3114 segments);"
              " no certificate can be issued." % (nsides, J.get('segments')))
        sys.exit(1)
    # optional: an independent jump computation (certify/jumps/run_jumps.py);
    # the certificate uses the larger of the two bounds for each norm
    if len(sys.argv) > 3:
        I = json.load(open(sys.argv[3]))
        if len(I['sides']) != 921:
            print("INCOMPLETE independent run: %d of 921 sides." % len(I['sides']))
            sys.exit(1)
        q0i = sum(r['L2D2'] for r in I['sides']); q1i = sum(r['L2N2'] for r in I['sides'])
        print("independent jump computation: Q0 <= %.6e, Q1 <= %.6e  (primary: %.6e, %.6e)"
              % (q0i, q1i, Q0, Q1))
        Q0, Q1 = max(Q0, q0i), max(Q1, q1i)
    lam = complex(*J['lambda_tilde'])
    pref = np.sqrt((1 + max(1.0, abs(lam) ** 2)) / 2)
    rows = []
    for fn in sorted(glob.glob("ellmax_*.json")):
        E = json.load(open(fn))
        d, lmax = E['delta'], E['l_max']
        Y = 1 / np.sinh(d / 2) ** 2
        k0 = (4 * np.pi / Y) / np.sqrt(1 + 1 / Y)
        a0 = np.sqrt(46.4333 * (1 + 1 / Y) * lmax)
        a1 = np.sqrt(12 * np.pi * lmax / Y)
        Y1 = np.exp(d) / np.sqrt(N)
        nrm = norm_lower(cn, Y1)
        eps = pref * (a0 * np.sqrt(Q0) + a1 * np.sqrt(Q1)) / (k0 * nrm)
        rows.append(dict(delta=d, l_max=lmax, Y=Y, k0=k0, alpha0=a0, alpha1=a1,
                         norm_lower=nrm, c0=pref * a0 / (k0 * nrm), c1=pref * a1 / (k0 * nrm),
                         epsilon=eps))
    rows.sort(key=lambda r: r['epsilon'])
    print("jumps: Q0 <= %.4e, Q1 <= %.4e  (rms %.3e, %.3e);  lambda~ = %.12f%+.12fi"
          % (Q0, Q1, J['rms_jump'], J['rms_normal_jump'], lam.real, lam.imag))
    print("  delta   l_max     k0        alpha0   alpha1   ||f||_Y1   c0        c1       |lambda_1 - 1/4| <=")
    for r in sorted(rows, key=lambda r: r['delta']):
        print("  %-5g  %7.4f  %.4e  %7.3f  %7.4f  %7.4f   %.3e  %.3e  %.4e"
              % (r['delta'], r['l_max'], r['k0'], r['alpha0'], r['alpha1'], r['norm_lower'],
                 r['c0'], r['c1'], r['epsilon']))
    best = rows[0]
    print()
    print("CERTIFIED: there is an odd Maass cusp newform on Gamma_0(1951), nebentypus chi_780")
    print("           (chi(3) = e(2/5); Conrey label 1951.908),")
    print("           with Laplace eigenvalue in [1/4 - %.3e, 1/4 + %.3e]   (delta = %g)"
          % (best['epsilon'], best['epsilon'], best['delta']))
    out = dict(jumps=J, rows=rows, best=best)
    json.dump(out, open("certificate_%s.json" % J['tag'], "w"), indent=1)
    print("wrote certificate_%s.json" % J['tag'])


if __name__ == "__main__":
    main()
