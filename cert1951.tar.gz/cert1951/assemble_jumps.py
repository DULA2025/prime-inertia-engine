"""Rigorous upper bounds for the jump norms Q0, Q1 of Theorem 2.

    python3 assemble_jumps.py nodevals_<tag>.npz          ->  jumps_<tag>.json

For every segment of every side s (paired with s' by g_s):

    Gamma-type:  D = chi_s f~(w') - f~(w),                 d_nu D = -chi_s d_nu' f~(w') - d_nu f~(w)
    Fricke-type: D = -chi_s lam conj f~(w') - f~(w),        d_nu D =  chi_s lam conj d_nu' f~(w') - d_nu f~(w)

(w' = g_s w; f~* = -conj f~ because f~ is exactly odd; g_s maps the outward
normal at s to the inward normal at s').  On each segment D is interpolated at
the K first-kind Chebyshev nodes, and

    ||D||_{L2(seg)} <= sqrt(h/2) [ ||p||_{L2[-1,1]} (1 + 1e-12)
                                   + sqrt2 ( Lambda_K max_j e_j + 4 M_rho rho^(1-K)/(rho-1) + e_fp ) ]

with Lambda_K <= (2/pi) ln K + 1 (Rivlin), ||p||_{L2} exact by Gauss-Legendre
(K+2 nodes; |p|^2 has degree 2K-2), e_j the certified node errors, and M_rho a
crude bound of |D| on the Bernstein ellipse E_rho of the segment:

    |f~|     <= 2 |y|^(1/2) sum_n |c_n| K0(2 pi n Re y) cosh(2 pi n |Im x|)
    |d_nu f~| <= |CX| sum |c_n| 4 pi n |y|^(1/2) K0 cosh(..) + |CY| sum 2|c_n| (K0/(2 (Re y)^(1/2)) + 2 pi n |y|^(1/2) K1) cosh(..)

using |K_nu(w)| <= K_nu(Re w), K_0(v) <= sqrt(pi/2v) e^-v, K_1(v) <= sqrt(pi/2v) e^-v (1+1/v),
and the ellipse extremes of |y|, Re y, |Im x|, |a-x| recorded in nodes_1951.npz.
"""
import sys
import json
import numpy as np

N = 1951
U = 2.0 ** -53


def chi780_tau():
    dl, x = {}, 1
    for k in range(N - 1):
        dl[x] = k
        x = (x * 3) % N
    z5 = np.exp(2j * np.pi / 5)
    tab = np.zeros(N, dtype=np.complex128)
    for k in range(1, N):
        tab[k] = z5 ** ((2 * dl[k]) % 5)
    a = np.arange(1, N)
    return np.sum(tab[1:] * np.exp(2j * np.pi * a / N)) / np.sqrt(float(N))


def crude_bounds(cabs, ymax, reymin, imxmax, amxmax, r):
    """(B0, B1): bounds for |f~| and |d_nu f~| on a complexified segment."""
    n = np.arange(1, cabs.size + 1, dtype=float)
    v = 2 * np.pi * n * reymin
    damp = np.exp(-2 * np.pi * n * (reymin - imxmax)) * np.sqrt(np.pi / (2 * v))  # K0(v) cosh(..) <= this (cosh <= e^.)
    k1f = 1 + 1 / v
    sy = np.sqrt(ymax)
    B0 = 2 * sy * np.sum(cabs * damp)
    Fx = np.sum(cabs * 4 * np.pi * n * sy * damp)
    Fy = np.sum(2 * cabs * (damp / (2 * np.sqrt(reymin)) + 2 * np.pi * n * sy * damp * k1f))
    CX = ymax * amxmax / r
    CY = ymax * ymax / r
    B1 = CX * Fx + CY * Fy
    return B0 * (1 + 1e-9), B1 * (1 + 1e-9)


def main():
    V = np.load(sys.argv[1])
    tag = sys.argv[1].replace("nodevals_", "").replace(".npz", "")
    if "--lam=opt" in sys.argv:
        tag += "_lamopt"
    Z = np.load("nodes_%d.npz" % N)
    K, RHO = int(Z['K']), float(Z['RHO'])
    seg_side, seg_len = Z['seg_side'], Z['seg_len']
    seg_partner = Z['seg_partner']; seg_rev = Z['seg_rev']
    ellb = Z['ell_bounds']
    fricke = Z['side_fricke']; k5 = Z['side_k5']
    idx = V['idx']
    pos = -np.ones(seg_side.size * K, dtype=np.int64)
    pos[idx] = np.arange(idx.size)
    F0, F1, E0, E1 = V['F0'], V['F1'], V['E0'], V['E1']
    cabs = np.abs(V['cn']) * (1 + 1e-12)
    lam = chi780_tau() * np.exp(2j * np.pi * 3.0 / 5.0)
    lam /= abs(lam)
    lam_pinned = lam
    # lambda~ is a free parameter of the construction (Theorem 2 holds for any
    # lambda~ != 0).  --lam=opt uses the least-squares value over the Fricke
    # sides; it is also a diagnostic: it should agree with tau(chi) zeta_5^3.
    jj0 = np.arange(K)
    num = den = 0.0
    for sg in range(seg_side.size):
        s_ = seg_side[sg]
        if not fricke[s_]:
            continue
        sp_ = seg_partner[sg]
        a_ = pos[sg * K + jj0]; b_ = pos[sp_ * K + (K - 1 - jj0 if seg_rev[sg] else jj0)]
        if np.any(a_ < 0) or np.any(b_ < 0):
            continue
        A_ = np.exp(2j * np.pi * k5[s_] / 5.0) * np.conj(F0[b_])
        num += np.sum(np.conj(A_) * F0[a_]); den += np.sum(np.abs(A_) ** 2)
    lam_ls = -num / den if den > 0 else lam
    if "--lam=opt" in sys.argv:
        lam = lam_ls
    print("lambda~ used: %.13f %+.13fi   (pinned Gauss-sum value %.13f %+.13fi; "
          "least-squares fit differs by %.2e, |fit| - 1 = %.1e)"
          % (lam.real, lam.imag, lam_pinned.real, lam_pinned.imag, abs(lam_ls - lam_pinned), abs(lam_ls) - 1))
    lamf = max(1.0, abs(lam)) * (1 + 1e-15)
    lebesgue = 2 / np.pi * np.log(K) + 1
    # Chebyshev machinery
    jj = np.arange(K)
    theta = (2 * jj + 1) * np.pi / (2 * K)
    Ccos = np.cos(np.outer(np.arange(K), theta))          # C[k, j] = T_k(u_j)
    ug, wg = np.polynomial.legendre.leggauss(K + 2)
    Tg = np.polynomial.chebyshev.chebvander(ug, K - 1)     # T_k(u_i)
    have = np.all(pos.reshape(-1, K) >= 0, axis=1)
    Q0 = Q1 = 0.0
    parts = dict(poly0=0.0, samp0=0.0, interp0=0.0, poly1=0.0, samp1=0.0, interp1=0.0)
    per_side = {}
    worst = []
    crude_cache = {}

    def crude(sg):
        if sg not in crude_cache:
            crude_cache[sg] = crude_bounds(cabs, *ellb[sg])
        return crude_cache[sg]

    nseg_done = 0
    for sg in range(seg_side.size):
        sp = seg_partner[sg]
        if not (have[sg] and have[sp]):
            continue
        s = seg_side[sg]
        chi = np.exp(2j * np.pi * k5[s] / 5.0)
        a = pos[sg * K + jj]
        b = pos[sp * K + (K - 1 - jj if seg_rev[sg] else jj)]
        if fricke[s]:
            D = -chi * lam * np.conj(F0[b]) - F0[a]
            dD = chi * lam * np.conj(F1[b]) - F1[a]
            fac = lamf
        else:
            D = chi * F0[b] - F0[a]
            dD = -chi * F1[b] - F1[a]
            fac = 1.0
        eD = fac * E0[b] + E0[a] + 6 * U * (np.abs(F0[b]) + np.abs(F0[a]))
        edD = fac * E1[b] + E1[a] + 6 * U * (np.abs(F1[b]) + np.abs(F1[a]))
        B0s, B1s = crude(sg)
        B0p, B1p = crude(sp)
        M0 = B0s + fac * B0p
        M1 = B1s + fac * B1p
        interp = 4 * RHO ** (1 - K) / (RHO - 1)
        h = seg_len[sg]
        out = []
        for vals, errs, Mr in ((D, eD, M0), (dD, edD, M1)):
            coef = (2.0 / K) * (Ccos @ vals)
            coef[0] /= 2
            pg = Tg @ coef
            l2p = np.sqrt(np.sum(wg * np.abs(pg) ** 2)) * (1 + 1e-12)
            efp = 10 * K * U * np.sum(np.abs(vals))
            samp = lebesgue * np.max(errs)
            itp = interp * Mr
            bound = np.sqrt(h / 2) * (l2p + np.sqrt(2) * (samp + itp + efp))
            out.append((bound, np.sqrt(h / 2) * l2p, np.sqrt(h) * samp, np.sqrt(h) * itp,
                        np.max(np.abs(vals))))
        (b0, p0, s0, i0, m0), (b1, p1, s1, i1, m1) = out
        Q0 += b0 ** 2; Q1 += b1 ** 2
        parts['poly0'] += p0 ** 2; parts['samp0'] += s0 ** 2; parts['interp0'] += i0 ** 2
        parts['poly1'] += p1 ** 2; parts['samp1'] += s1 ** 2; parts['interp1'] += i1 ** 2
        d = per_side.setdefault(int(s), [0.0, 0.0, 0.0, 0.0])
        d[0] += b0 ** 2; d[1] += b1 ** 2; d[2] = max(d[2], m0); d[3] = max(d[3], m1)
        worst.append((b0 ** 2 / h, int(s), int(sg), m0, float(M0), float(i0)))
        nseg_done += 1
    Q0 *= 1 + 1e-10; Q1 *= 1 + 1e-10
    worst.sort(reverse=True)
    L = float(np.sum(seg_len[[sg for sg in range(seg_side.size) if have[sg] and have[seg_partner[sg]]]]))
    res = dict(tag=tag, segments=nseg_done, length=L, Q0=Q0, Q1=Q1,
               rms_jump=float(np.sqrt(Q0 / L)), rms_normal_jump=float(np.sqrt(Q1 / L)),
               contributions={k: float(v) for k, v in parts.items()},
               K=K, rho=RHO, lebesgue=lebesgue, lambda_tilde=[lam.real, lam.imag],
               lambda_fit=[lam_ls.real, lam_ls.imag], lambda_pinned=[lam_pinned.real, lam_pinned.imag],
               worst_segments=[dict(q_per_length=w[0], side=w[1], seg=w[2], max_node_jump=w[3],
                                    M_rho=w[4], interp_l2=w[5]) for w in worst[:10]],
               per_side={k: dict(Q0=v[0], Q1=v[1], max_jump=v[2], max_normal_jump=v[3])
                         for k, v in per_side.items()})
    json.dump(res, open("jumps_%s.json" % tag, "w"), indent=1)
    print("segments %d  (length %.2f)" % (nseg_done, L))
    print("  Q0 <= %.4e   rms jump        <= %.3e" % (Q0, res['rms_jump']))
    print("  Q1 <= %.4e   rms normal jump <= %.3e" % (Q1, res['rms_normal_jump']))
    print("  squared contributions (polynomial / sample errors / interpolation):")
    print("    Q0: %.3e / %.3e / %.3e" % (parts['poly0'], parts['samp0'], parts['interp0']))
    print("    Q1: %.3e / %.3e / %.3e" % (parts['poly1'], parts['samp1'], parts['interp1']))
    print("  worst segments (Q0 per unit length, side, max node jump, M_rho):")
    for w in worst[:5]:
        print("    %.3e  side %4d  %.3e  %.2e" % (w[0], w[1], w[3], w[4]))
    print("wrote jumps_%s.json" % tag)


if __name__ == "__main__":
    main()
